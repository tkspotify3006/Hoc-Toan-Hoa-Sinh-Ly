---
title: Alcol, phenol, ether
thoi-gian: 50 phút
muc-tieu:
- Gọi được tên alcol, phenol, ether (và thiol, thioether) theo danh pháp IUPAC và danh pháp thông thường.
- Trình bày và giải thích được tính acid của alcol, thiol, phenol; so sánh được chúng với nước, acid carbonic, acid acetic.
- Trình bày được các phản ứng chính của alcol, thioalcol, phenol, ether, thioether; dùng phản ứng để phân biệt alcol bậc I/II/III, alcol với phenol, monoalcol với polyalcol.
- Nêu được ví dụ về phản ứng khác nhau giữa monoalcol và polyalcol, giữa monophenol và polyphenol.
- Nêu được các phương pháp điều chế chính và ý nghĩa y học: ethanol, methanol, glycerol, mannitol, phenol, cresol, ether mê, dimercaprol; liên hệ dược liệu và bào chế YHCT.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. **Alcol** R–OH: –OH gắn vào **C no** (sp^3^). **Phenol** Ar–OH: –OH gắn **thẳng vào vòng thơm**. **Ether** R–O–R′. Thay O bằng S → **thiol** R–SH và **thioether** R–S–R′.
> 2. Tính acid: **alcol < nước < phenol < acid carbonic < acid acetic**. Alcol chỉ phản ứng với Na; phenol phản ứng thêm với **NaOH** nhưng **không** đẩy được CO~2~ khỏi NaHCO~3~. Thiol acid hơn alcol (tác dụng với NaOH, với oxid kim loại nặng).
> 3. Bậc alcol quyết định phản ứng: oxy hóa **bậc I → aldehyd → acid; bậc II → ceton; bậc III khó oxy hóa**. Thuốc thử **Lucas** (HCl đặc/ZnCl~2~): bậc III vẩn đục ngay, bậc II sau vài phút, bậc I không phản ứng ở nhiệt độ thường.
> 4. Nhận biết: **polyalcol có 2 –OH kề nhau + Cu(OH)~2~ → xanh lam**; **phenol + FeCl~3~ → tím**; **phenol + nước brom → tủa trắng**.
> 5. Y học: **ethanol 70%** sát khuẩn; **methanol** gây mù, toan chuyển hóa (do acid formic); **glycerol, mannitol**; **phenol, cresol** sát khuẩn và ăn da; **ether** mê (cũ); **dimercaprol** (2 nhóm –SH) giải độc arsen, thủy ngân.

## 1. Alcol

### 1.1. Định nghĩa và phân loại

**Alcol** là dẫn xuất của hydrocarbon khi thay một hay nhiều nguyên tử H bằng nhóm **hydroxyl –OH** (Giáo trình tr. 140). Điều kiện ngầm: –OH gắn vào **carbon no (sp^3^)**.

| Căn cứ | Các loại | Ví dụ (theo sách) |
|---|---|---|
| Gốc hydrocarbon | **Alcol béo**: no, không no, vòng | CH~3~CH~2~OH (alcol ethylic); CH~2~=CH–CH~2~OH (alcol allylic); cyclohexanol |
| | **Alcol thơm**: –OH ở **mạch nhánh** của gốc thơm | C~6~H~5~–CH~2~OH (alcol benzylic) |
| Số nhóm –OH | **Monoalcol**; **polyalcol** (dialcol, trialcol…) | Ethylen glycol HOCH~2~–CH~2~OH (dialcol); glycerol HOCH~2~–CHOH–CH~2~OH (trialcol) |
| Bậc của C mang –OH | **Bậc I** (C nối với 1 C khác), **bậc II** (2 C), **bậc III** (3 C) | CH~3~CH~2~CH~2~OH (I); (CH~3~)~2~CH–OH (II); (CH~3~)~3~C–OH (III) |

> [!bay]
> - **Alcol thơm ≠ phenol.** Alcol benzylic C~6~H~5~–**CH~2~**–OH: –OH gắn vào C no của nhánh → là **alcol**, không có tính chất phenol (không tác dụng NaOH, không tạo màu với FeCl~3~). Còn C~6~H~5~–OH: –OH gắn thẳng vào vòng → **phenol**.
> - **Bậc alcol** tính theo **carbon mang –OH** (nó nối với mấy carbon khác). Methanol CH~3~OH thường được xếp cùng nhóm bậc I.
> - –OH gắn vào C mang nối đôi (enol, CH~2~=CH–OH) **không bền**, tự chuyển thành aldehyd/ceton. Vì vậy alcol allylic CH~2~=CH–**CH~2~**–OH bền, còn "alcol vinylic" thì không tồn tại ở dạng tự do.

### 1.2. Danh pháp

**IUPAC: tên hydrocarbon tương ứng + đuôi -ol** (Giáo trình tr. 141). Chọn mạch dài nhất **chứa C mang –OH**; đánh số từ đầu **gần –OH nhất**; ghi vị trí –OH trước đuôi -ol.

**Thông thường: alcol + tên gốc hydrocarbon + đuôi -ic** (alcol ethylic, alcol isopropylic). Một số tên riêng: glycol, glycerol, mannitol, sorbitol.

| Công thức | IUPAC | Thông thường |
|---|---|---|
| CH~3~–OH | methanol | alcol methylic |
| CH~3~–CH~2~–OH | ethanol | alcol ethylic |
| CH~3~–CH~2~–CH~2~–OH | propan-1-ol | alcol propylic |
| (CH~3~)~2~CH–OH | propan-2-ol | alcol isopropylic |
| (CH~3~)~3~C–OH | 2-methyl propan-2-ol | alcol tert-butylic |
| (CH~3~)~2~CH–CH~2~–CH~2~–OH | 3-methyl butan-1-ol | alcol isoamylic |
| CH~3~–CH~2~–CH(OH)–CH~2~–CH~3~ | pentan-3-ol | — |
| CH~3~–CH=CH–CH~2~–OH | but-2-en-1-ol | — |
| CH~2~=CH–CH~2~–OH | prop-2-en-1-ol | alcol allylic |
| C~6~H~5~–CH~2~–OH | phenyl methanol | alcol benzylic |
| HO–CH~2~–CH~2~–OH | ethan-1,2-diol (sách: ethandiol) | ethylen glycol |
| HOCH~2~–CHOH–CH~2~OH | propan-1,2,3-triol | glycerol |

> [!bay] Đánh số theo –OH, không theo nhánh
> But-2-en-1-ol: số 1 dành cho C mang **–OH** (nhóm chức chính), dù đánh từ đầu kia thì nối đôi cũng ở vị trí 2. Với 2-methyl propan-2-ol: mạch chính là 3 C chứa C mang –OH, nhánh CH~3~ ở C2.

### 1.3. Đồng phân

- **Vị trí nhóm –OH** (từ C~3~): propan-1-ol và **propan-2-ol**. *Sách in ví dụ "propan-1-ol và propan-1,2-diol" (tr. 142) — hai chất này khác công thức phân tử nên không phải đồng phân; ví dụ đúng là propan-1-ol / propan-2-ol.*
- **Mạch carbon** (từ C~4~): butan-1-ol (alcol butylic) và 2-methyl propan-1-ol (alcol isobutylic).
- **Nhóm chức**: alcol đồng phân với **ether** cùng số C. C~2~H~6~O: ethanol CH~3~CH~2~OH và dimethyl ether CH~3~–O–CH~3~.

### 1.4. Tính chất vật lý

- Monoalcol béo thấp (C~1~–C~11~) là chất lỏng (alcol tert-butylic là chất rắn dễ chảy, nóng chảy ≈ 25 °C); từ C~12~ trở lên là chất rắn.
- Polyalcol (glycol, glycerol): lỏng, không màu, **sánh, vị ngọt, rất dễ tan** trong nước.
- Methanol, ethanol, propanol **tan vô hạn** trong nước; butanol, pentanol ít tan; alcol cao không tan.

**Vì sao?** Nhóm –OH tạo **liên kết hydro** giữa các phân tử alcol với nhau (làm nhiệt độ sôi cao) và với nước (làm alcol tan). Gốc R càng dài, phần "kỵ nước" càng lớn nên độ tan giảm.

| Alcol | t~s~ (°C) | Ghi chú |
|---|---|---|
| CH~3~OH | 64,7 | |
| C~2~H~5~OH | 78,5 | |
| n-C~3~H~7~OH / iso-C~3~H~7~OH | 97,2 / 82,3 | Phân nhánh → t~s~ **thấp hơn** |
| n-C~4~H~9~OH / (CH~3~)~3~COH | 117,7 / 83,0 | |
| Glycol / glycerol | 197,2 / 290 | Nhiều –OH → nhiều liên kết hydro → t~s~ rất cao |
| C~6~H~5~CH~2~OH | 205,5 | |

Quy luật (Giáo trình tr. 142–143): alcol bậc I mạch thẳng có t~s~ **tăng dần** theo dãy đồng đẳng và **cao hơn** đồng phân phân nhánh (phân nhánh làm phân tử gọn hơn, tiếp xúc kém hơn).

> [!bay] Số liệu cần đọc cẩn thận
> Bảng 5 của sách ghi alcol n-dodecylic (C~12~H~25~OH) sôi ở 143 °C — thấp hơn cả alcol benzylic, trái với quy luật sách vừa nêu. Giá trị tham khảo ở áp suất thường là khoảng **259 °C**; nhiều khả năng sách ghi số đo ở áp suất thấp hoặc in nhầm. Đi thi chỉ cần nắm **quy luật**.

### 1.5. Tính chất hóa học

Phân tử alcol có hai liên kết phân cực về phía O: **O–H** và **C–O**. Phản ứng xảy ra ở **H của –OH** (tính acid, tạo ester), ở **cả nhóm –OH** (thế bằng halogen, tách nước), và ở **C mang –OH cùng H của nó** (oxy hóa).

#### 1.5.1. Phản ứng với kim loại kiềm — tính acid rất yếu

=> 2C~2~H~5~OH + 2Na → 2C~2~H~5~ONa (natri ethylat) + H~2~↑

=> 2C~6~H~5~CH~2~OH + 2Na → 2C~6~H~5~CH~2~ONa (natri benzylat) + H~2~↑

(Sách in hệ số "+ Na" ở cả hai phương trình — thiếu hệ số 2 trước Na, tr. 143.)

Glycol phản ứng từng nấc: ở khoảng 50 °C tạo **mononatri glycolat** HO–CH~2~–CH~2~–ONa, ở 160 °C tạo **dinatri glycolat** NaO–CH~2~–CH~2~–ONa.

**Vì sao alcol phản ứng với Na yếu hơn nước?** Gốc alkyl R có hiệu ứng **cảm ứng dương (+I)**, đẩy electron về phía O. O "đỡ thiếu" electron nên kéo cặp electron O–H ít hơn → H **khó tách** thành H^+^ hơn so với H của nước. Theo sách: K~a~ (H~2~O) = 10^−16^, K~a~ (CH~3~OH) = 10^−17^, K~a~ (C~2~H~5~OH) = 10^−18^.

- Gốc R càng lớn, càng phân nhánh (bậc cao) → +I càng mạnh → H càng kém linh động. CH~3~OH, C~2~H~5~OH phản ứng khá mạnh với Na; alcol trung bình phản ứng yếu; alcol cao phải đun nóng.
- Alcol **không** tác dụng với NaOH. Ngược lại, alcolat bị nước thủy phân trở lại: C~2~H~5~ONa + H~2~O → C~2~H~5~OH + NaOH — chứng tỏ alcol là acid yếu hơn nước.

> [!cap-nhat] Trị số K~a~ của alcol
> Giáo trình ghi K~a~ của methanol (10^−17^) nhỏ hơn của nước (10^−16^). Số liệu hiện nay trong nước: pK~a~ của H~2~O ≈ 15,7; CH~3~OH ≈ 15,5; C~2~H~5~OH ≈ 16; (CH~3~)~3~COH ≈ 18. Nghĩa là **methanol có độ acid xấp xỉ nước**, còn thứ tự ethanol < nước và bậc III < bậc I thì vẫn đúng. Đi thi trả lời theo sách: alcol có tính acid **rất yếu, yếu hơn nước**.

![Hình 1. Vì sao phenol acid hơn alcol: so sánh ion ethoxid và ion phenoxid](acid-alcol-phenol.svg)

#### 1.5.2. Phản ứng tạo ester

Alcol + acid (vô cơ hoặc hữu cơ) ⇌ ester + nước. Phản ứng **thuận nghịch**, cần xúc tác acid.

=> CH~3~OH + H~3~PO~4~ ⇌ CH~3~O–PO(OH)~2~ (methyl phosphat) + H~2~O

=> CH~3~OH + CH~3~COOH ⇌(H~2~SO~4~ đặc) CH~3~COOCH~3~ + H~2~O

Sản phẩm là methyl acetat.

- H~2~SO~4~ đặc đóng **hai vai**: xúc tác, và **hút nước** để kéo cân bằng về phía ester (tăng hiệu suất).
- Với cùng một acid, tốc độ ester hóa: **bậc I > bậc II > bậc III**. Sách dẫn số liệu ở 150 °C: bậc I 44,4–46,7 %/giờ; bậc II 16,9–26,5; bậc III chỉ 0,9–2,2. Lý do: gốc R lớn **che chắn không gian** quanh nhóm –OH, và +I làm O–H kém phân cực.

> [!ung-dung] Ester của alcol trong cơ thể và trong thuốc
> - **Ester phosphat** là dạng "hoạt hóa" của nhiều chất trong tế bào: glucose-6-phosphat, glycerol-3-phosphat, nucleotid (ATP).
> - **Nitroglycerin** (sách gọi "trinitro glycerol") thực chất là **ester** của glycerol với acid nitric: **glyceryl trinitrat** C~3~H~5~(ONO~2~)~3~. Đây không phải hợp chất nitro (nhóm –NO~2~ gắn vào O chứ không gắn vào C). Thuốc giải phóng **NO** làm giãn mạch, dùng **ngậm dưới lưỡi** cắt cơn đau thắt ngực.

#### 1.5.3. Phản ứng thế nhóm –OH bằng halogen

Với phospho halid (PCl~5~, PBr~3~, PI~3~) hoặc hydro halid (HCl, HBr, HI) kèm chất hút nước (H~2~SO~4~ đặc, ZnCl~2~ khan, CaCl~2~ khan), –OH bị thay bằng halogen:

=> C~2~H~5~OH + PCl~5~ → C~2~H~5~Cl + POCl~3~ + HCl

=> HOCH~2~CH~2~OH + HCl →(160 °C) ClCH~2~CH~2~OH + H~2~O

=> ClCH~2~CH~2~OH + HCl →(200 °C) ClCH~2~CH~2~Cl + H~2~O

Hai sản phẩm lần lượt là 2-cloro ethanol và 1,2-dicloro ethan.

Đây là phản ứng **ngược** với thủy phân dẫn xuất halogen ở bài trước.

**Thuốc thử Lucas — phân biệt alcol bậc I, II, III** (bổ sung, rất hay dùng)

Thuốc thử Lucas là **ZnCl~2~ khan hòa trong HCl đặc**. Alcol (tan được trong thuốc thử, thường ≤ 6 C) bị thế thành alkyl clorid. Alkyl clorid **không tan** nên làm dung dịch **vẩn đục** rồi tách lớp.

| Bậc alcol | Hiện tượng ở nhiệt độ thường | Ví dụ |
|---|---|---|
| **Bậc III** | Vẩn đục **ngay lập tức** | (CH~3~)~3~C–OH |
| **Bậc II** | Vẩn đục sau **vài phút** (khoảng 3–10 phút) | (CH~3~)~2~CH–OH |
| **Bậc I** | **Không** vẩn đục (chỉ phản ứng khi đun nóng) | CH~3~CH~2~CH~2~OH |

**Vì sao?** ZnCl~2~ (acid Lewis) kéo O của –OH, giúp nhóm này rời đi để lại **carbocation** (cơ chế S~N~1, xem bài *Phản ứng của hợp chất hữu cơ* (hc-04) và *Dẫn xuất halogen* (hc-06)). Carbocation bậc III bền nhất (nhiều gốc alkyl +I "đỡ" điện tích dương) nên sinh ra nhanh nhất; carbocation bậc I quá kém bền nên gần như không hình thành.

> [!bay] Lucas
> - Alcol **benzylic, allylic** (dù là bậc I) phản ứng **nhanh như bậc III**, vì carbocation benzyl, allyl được liên hợp làm bền.
> - Phép thử chỉ dùng tốt cho alcol **tan trong thuốc thử** (khoảng ≤ 6 C). Alcol lớn không tan sẵn thì vẩn đục ngay từ đầu, không có giá trị.
> - Đây là phép thử **bổ sung ngoài sách** (sách nêu phản ứng HX/ZnCl~2~ nhưng không gọi tên Lucas). Câu 7.7 của sách phân biệt propan-1-ol / propan-2-ol bằng **oxy hóa rồi tráng gương** (mục 1.5.6).

#### 1.5.4. Tách nước giữa hai phân tử → ether

Đun alcol với H~2~SO~4~ đặc ở **khoảng 140 °C** (hoặc cho hơi alcol qua Al~2~O~3~ nóng, ≈ 300 °C), hai phân tử alcol mất một phân tử nước:

=> 2C~2~H~5~OH →(H~2~SO~4~ đặc, 140 °C) C~2~H~5~–O–C~2~H~5~ + H~2~O

Sản phẩm là diethyl ether.

Polyalcol cũng tách nước tương tự. Hai phân tử glycol tách 2 H~2~O tạo ether vòng 6 cạnh (sách gọi **glyoxan**, nay gọi **1,4-dioxan**).

#### 1.5.5. Tách nước nội phân tử → olefin (alken)

Đun monoalcol (**trừ methanol**, vì chỉ có 1 C) với lượng lớn H~2~SO~4~ đặc ở nhiệt độ cao hơn (**≈ 170 °C**), hoặc với ZnCl~2~, hoặc cho hơi qua Al~2~O~3~ ở 375 °C → alken:

=> CH~3~–CH(OH)–CH~3~ → CH~3~–CH=CH~2~ + H~2~O

Với alcol bất đối xứng, H bị tách chủ yếu ở **C bậc cao hơn** bên cạnh (quy tắc **Zaitsev**, giống tách HX). Butan-2-ol cho chủ yếu but-2-en.

> [!bay] Cùng H~2~SO~4~ đặc, khác nhiệt độ → khác sản phẩm
> Với ethanol: **140 °C → diethyl ether** (tách nước liên phân tử); **170 °C → ethylen** (tách nước nội phân tử). Nhớ: "nhiệt độ thấp hơn → hai phân tử nối nhau; cao hơn → một phân tử tự tách".

#### 1.5.6. Phản ứng oxy hóa

Chất oxy hóa mạnh: K~2~Cr~2~O~7~/H~2~SO~4~; CrO~3~/H~2~SO~4~ + aceton (**thuốc thử Jones**); KMnO~4~/H~2~SO~4~. Chất oxy hóa nhẹ, chọn lọc: **PCC** (CrO~3~/HCl + pyridin). Trong phòng thí nghiệm phổ thông còn dùng **CuO nung nóng**.

| Bậc | Sản phẩm oxy hóa | Ví dụ (theo sách) |
|---|---|---|
| **I** | **Aldehyd** → (oxy hóa tiếp) **acid carboxylic**. Dừng ở aldehyd nếu dùng **PCC** | Octan-1-ol —Jones→ octanal → acid octanoic; octan-1-ol —PCC→ octanal; alcol benzylic —PCC→ aldehyd benzoic |
| **II** | **Ceton** (dừng ở đó) | Cyclohexanol → cyclohexanon; 1-phenyl ethanol → acetophenon |
| **III** | **Rất khó**. Điều kiện mạnh thì **gãy mạch C** → hỗn hợp ceton, acid ít C hơn | (CH~3~)~3~C–OH → aceton + acid formic |

**Vì sao?** Muốn tạo C=O, carbon mang –OH phải **còn H để mất**. Bậc I có 2 H → mất 1 H thành aldehyd, aldehyd còn H nên oxy hóa tiếp được thành acid. Bậc II có 1 H → thành ceton, không còn H để đi tiếp. Bậc III **không có H** → muốn oxy hóa phải bẻ liên kết C–C.

Sách mô tả bậc I oxy hóa qua **gemdiol** (2 –OH trên cùng 1 C): R–CH~2~OH →[O] R–CH(OH)~2~ → R–CHO + H~2~O. Gemdiol không bền, tự tách nước thành aldehyd.

=> CH~3~CH~2~OH + CuO → CH~3~CHO + Cu + H~2~O  (t°)

=> 3C~2~H~5~OH + K~2~Cr~2~O~7~ + 4H~2~SO~4~ → 3CH~3~CHO + Cr~2~(SO~4~)~3~ + K~2~SO~4~ + 7H~2~O

> [!ung-dung] Từ ống nghiệm đến thực tế
> - **Máy đo nồng độ cồn kiểu cũ**: hơi thở đi qua ống chứa K~2~Cr~2~O~7~/H~2~SO~4~ (màu **da cam**). Ethanol khử Cr^+6^ thành Cr^3+^ (màu **xanh lục**). Ngày nay máy đo dùng pin điện hóa hoặc hồng ngoại, nhưng nguyên lý vẫn là **oxy hóa ethanol**.
> - **Phản ứng iodoform** (I~2~ + NaOH → kết tủa vàng CHI~3~) dương tính với alcol có nhóm **CH~3~–CH(OH)–**: ethanol, propan-2-ol, butan-2-ol; âm tính với methanol, propan-1-ol. Có thể dùng để phân biệt propan-1-ol và propan-2-ol (xem bài Dẫn xuất halogen, mục iodoform).
>
> => C~2~H~5~OH + 4I~2~ + 6NaOH → CHI~3~↓ + HCOONa + 5NaI + 5H~2~O

#### 1.5.7. Phản ứng riêng

- **Alcol không no** còn có phản ứng của liên kết bội: CH~2~=CH–CH~2~OH + Br~2~ → CH~2~Br–CHBr–CH~2~OH (2,3-dibromo propan-1-ol).
- **Alcol thơm** còn có phản ứng thế vào nhân thơm.
- **Polyalcol có các nhóm –OH ở hai C kề nhau** hòa tan **Cu(OH)~2~** ở nhiệt độ thường tạo **phức đồng màu xanh lam** đặc trưng:

=> 2C~3~H~5~(OH)~3~ + Cu(OH)~2~ → [C~3~H~5~(OH)~2~O]~2~Cu + 2H~2~O

Phức đồng(II) glycerat tạo dung dịch **xanh lam**.

> [!bay] Monoalcol hay polyalcol?
> - Phản ứng với Cu(OH)~2~ là cách phân biệt **polyalcol** (glycol, glycerol, glucose, saccharose) với **monoalcol** (ethanol không hòa tan Cu(OH)~2~).
> - Cần hai –OH **kề nhau**. Propan-1,3-diol HOCH~2~CH~2~CH~2~OH (hai –OH cách nhau một C) **không** cho phản ứng này.
> - Sách viết phương trình với 1 phân tử glycol (tr. 147), nhưng phức tạo thành chứa **2 phân tử** glycol quanh 1 ion Cu^2+^, nên phải là **2** glycol + Cu(OH)~2~.

### 1.6. Điều chế

| Phương pháp | Phương trình | Ghi chú |
|---|---|---|
| Thủy phân dẫn xuất halogen bằng kiềm | C~2~H~5~Br + NaOH → C~2~H~5~OH + NaBr; C~6~H~5~CH~2~Cl + NaOH → C~6~H~5~CH~2~OH + NaCl; BrCH~2~CH~2~Br + 2KOH → HOCH~2~CH~2~OH + 2KBr | Thế nucleophil |
| Grignard + aldehyd/ceton | C~6~H~5~MgBr + CH~3~CHO → C~6~H~5~CH(OMgBr)CH~3~ —H~2~O/H^+^→ C~6~H~5~CH(OH)CH~3~ | HCHO → alcol bậc I; aldehyd khác → bậc II; ceton → bậc III. Sách viết gộp, bỏ bước thủy phân |
| Hydrat hóa olefin (H~2~SO~4~ hoặc ZnCl~2~, t°) | CH~2~=CH~2~ + H~2~O → CH~3~CH~2~OH; CH~3~CH=CH~2~ + H~2~O → CH~3~CH(OH)CH~3~ | Theo **Markovnikov**: –OH vào C bậc cao hơn. Nguyên liệu từ cracking dầu mỏ |
| **Lên men đường** | C~6~H~12~O~6~ → 2C~2~H~5~OH + 2CO~2~; C~12~H~22~O~11~ + H~2~O → 4C~2~H~5~OH + 4CO~2~ | Cách chính sản xuất ethanol (từ tinh bột, rỉ đường, cellulose) |
| Thủy phân ester tự nhiên | Chất béo + 3NaOH → glycerol + 3RCOONa (xà phòng hóa) | Nguồn glycerol; tinh dầu hoa có benzyl acetat |
| Tổng hợp từ khí | CO + 2H~2~ → CH~3~OH  (ZnO + Cr~2~O~3~, t°, p) | Sản xuất methanol công nghiệp |

### 1.7. Ứng dụng và ý nghĩa y học

**Ethanol C~2~H~5~OH**: chất lỏng vị cay, tan vô hạn trong nước. Dùng **sát khuẩn ngoài da**; dung môi pha **rượu thuốc**, cồn thuốc, dung môi phòng thí nghiệm; nguyên liệu công nghiệp (acid acetic, cao su). Liều vừa phải kích thích tiêu hóa và thần kinh; dùng nhiều thường xuyên gây **nghiện**, viêm dây thần kinh, **xơ gan**, bệnh tim mạch. Sách còn nêu: người nghiện rượu, nhất là công nhân hóa chất, dễ bị nhiễm độc arsen, thủy ngân, anilin, nitrobenzen… hơn, vì ethanol giúp cơ thể hấp thu các chất này dễ hơn (Giáo trình tr. 149–150).

**Ethanol chuyển hóa ở gan** qua hai bước oxy hóa:

=> C~2~H~5~OH →(ADH) CH~3~CHO →(ALDH) CH~3~COOH

ADH là **alcol dehydrogenase**, ALDH là **aldehyd dehydrogenase**; acid acetic sau đó được chuyển hóa tiếp đến CO~2~ + H~2~O.

**Acetaldehyd** cũng độc: gây đỏ mặt, tim nhanh, buồn nôn. Nhiều người Đông Á mang biến thể **ALDH2** kém hoạt động nên tích acetaldehyd, "uống ít đã đỏ mặt". Thuốc cai rượu **disulfiram** ức chế ALDH, cố ý gây phản ứng khó chịu này khi người bệnh uống rượu.

> [!ung-dung] Vì sao cồn sát khuẩn là 70% mà không phải 96%?
> - Ethanol diệt vi khuẩn bằng cách **làm biến tính protein** và hòa tan màng lipid. Quá trình biến tính protein **cần có nước**.
> - Cồn quá đặc (≥ 95%) làm **đông vón protein bề mặt** tế bào vi khuẩn rất nhanh. Lớp vỏ đông vón này cản cồn thấm sâu hơn vào trong. Cồn đặc còn **bay hơi quá nhanh**, thời gian tiếp xúc ngắn.
> - Vùng nồng độ hiệu quả nhất là khoảng **60–90%**; **70%** là mức hay dùng nhất. Dung dịch sát khuẩn tay nhanh theo công thức WHO chứa ethanol khoảng 80% (thể tích).
> - Giới hạn: cồn **không diệt bào tử** (ví dụ bào tử *Clostridioides difficile*), kém hiệu quả với một số virus không vỏ (norovirus). Không dùng cồn để rửa vết thương hở rộng (gây đau, hại mô).

> [!ung-dung] Ngộ độc methanol — "rượu giả"
> - Methanol CH~3~OH bản thân ít độc, nhưng bị **chính enzym ADH** chuyển thành **formaldehyd** rồi **acid formic** HCOOH:
>
> => CH~3~OH →(ADH) HCHO →(ALDH) HCOOH
>
> - **Acid formic (formiat)** gây **toan chuyển hóa** nặng và ức chế hô hấp tế bào ở **thần kinh thị giác** → nhìn mờ, **mù vĩnh viễn**; tổn thương nhân bèo ở não; tử vong. Triệu chứng thường xuất hiện **muộn sau 12–24 giờ** (thời gian chuyển hóa), nên dễ bị bỏ sót. Chỉ vài chục mL methanol đã có thể gây tử vong.
> - **Giải độc dựa vào cạnh tranh enzym**: **fomepizol** (4-methylpyrazol) ức chế ADH; hoặc truyền **ethanol** — ADH ưa ethanol hơn methanol nhiều lần, nên ethanol "chiếm chỗ" enzym, methanol không bị chuyển thành acid formic mà được thải dần ra ngoài. Kết hợp **lọc máu** (thải methanol và formiat), bù **bicarbonat**, acid folinic/folic (giúp chuyển hóa formiat). Đây là việc của bệnh viện; không tự xử trí tại nhà.
> - Ở Việt Nam, phần lớn các vụ ngộ độc hàng loạt là do **rượu pha cồn công nghiệp** (methanol). Ethylen glycol (chất chống đông) gây ngộ độc theo cơ chế tương tự (sinh acid glycolic, acid oxalic → suy thận) và cũng được giải bằng fomepizol/ethanol.

**Methanol** chủ yếu dùng để sản xuất formaldehyd và hóa chất khác. Rất độc: lượng nhỏ đã gây mù vĩnh viễn, có thể tử vong (Giáo trình tr. 150).

**Polyalcol làm thuốc** (Giáo trình tr. 149):

| Chất | Cấu tạo | Ứng dụng |
|---|---|---|
| **Glycerol** | Trialcol C~3~H~5~(OH)~3~ | **Tá dược** (giữ ẩm, làm dẻo, dung môi): glycerol iod, glycerol borat; **thuốc đạn glycerin** (nhuận tràng do kích thích và hút nước); nguyên liệu sản xuất **nitroglycerin** (chữa cơn đau thắt ngực) |
| **Mannitol** | Hexol CH~2~OH(CHOH)~4~CH~2~OH (đồng phân lập thể của sorbitol) | **Lợi tiểu thẩm thấu**: không qua hàng rào máu – não, không bị tái hấp thu ở ống thận → kéo nước ra khỏi mô. Dùng giảm **phù não**, **hạ nhãn áp** |
| **Sorbitol** | Hexol, sản phẩm khử glucose | Chất tạo ngọt, nhuận tràng thẩm thấu (xem bài Glucid) |

> [!cap-nhat] Mannitol và glycerol borat
> - Giáo trình ghi mannitol "chữa phù não trong tai biến mạch máu não". Hiện nay mannitol được dùng khi **tăng áp lực nội sọ** có dấu hiệu nặng lên (chấn thương sọ não, đột quỵ có phù não tiến triển) và trong **glôcôm góc đóng cấp**; các hướng dẫn **không khuyến cáo dùng thường quy** cho mọi bệnh nhân đột quỵ. Cần theo dõi nước – điện giải và chức năng thận.
> - Các chế phẩm chứa **borat** (glycerol borat, borax) **không nên dùng cho trẻ nhỏ**, nhất là bôi diện rộng hay lên niêm mạc tổn thương, vì nguy cơ ngộ độc bor.

> [!yhct] Ethanol là dung môi chiết — "độ rượu" quyết định chiết được gì
> - Hỗn hợp **ethanol – nước** hòa tan được cả chất **phân cực** (glycosid, saponin, muối alkaloid, tannin, đường) lẫn chất **kém phân cực** (tinh dầu, nhựa, aglycon, nhiều alkaloid dạng base). Thay đổi tỉ lệ ethanol là "chỉnh" độ phân cực của dung môi. Nguyên tắc chung: **độ cồn cao (70–90%)** chiết tốt tinh dầu, nhựa, chất béo; **độ cồn thấp hơn (khoảng 30–60%)** chiết tốt glycosid, saponin, tannin nhưng chiết theo cả chất nhầy, đường. Dược điển quy định độ cồn riêng cho từng loại **cồn thuốc**.
> - **Rượu thuốc** dân gian thường ngâm với rượu trắng khoảng **30–40 độ** (độ rượu = % thể tích ethanol): ở mức này rượu vừa chiết được cả hai nhóm chất ở mức vừa phải, vừa **ức chế vi sinh vật** nên bảo quản được lâu. Độ rượu quá thấp dễ hỏng, mốc.
> - **Tẩm rượu (tửu chế)** trong bào chế (ví dụ Đương quy, Đại hoàng tẩm rượu): ethanol thấm vào dược liệu, giúp hòa tan một phần thành phần ít phân cực; khi sao, phần lớn ethanol bay hơi. Cơ sở hóa học này mới giải thích một phần; tác dụng "dẫn thuốc", "hoạt huyết" theo lý luận YHCT chưa quy được hết về hóa học.
> - **Cảnh báo an toàn**: ethanol chiết **rất tốt** các alkaloid độc như **aconitin** (Ô đầu, Phụ tử sống, "củ ấu tạu") và **strychnin** (Mã tiền). Rượu ngâm các vị này chưa chế biến là nguyên nhân của nhiều vụ ngộ độc nặng, tử vong. Chỉ dùng **rượu có nguồn gốc rõ ràng** (tránh rượu pha cồn công nghiệp chứa methanol). Rượu thuốc không phù hợp cho người bệnh gan, phụ nữ có thai, người đang dùng thuốc an thần hoặc thuốc tương tác với rượu.

## 2. Thioalcol (thiol)

### 2.1. Định nghĩa và danh pháp

**Thiol** (thioalcol, **mercaptan**) có công thức chung **R–SH**, tương tự alcol R–OH nhưng O được thay bằng S. Nhóm –SH gọi là **nhóm thiol** (sulfhydryl).

Tên IUPAC: **tên hydrocarbon + đuôi thiol**. Ví dụ: C~2~H~5~SH **ethanthiol** (ethyl mercaptan); CH~3~SH methanthiol (methyl mercaptan).

### 2.2. Tính chất vật lý

- t~s~ **thấp hơn nhiều** so với alcol tương ứng, dù khối lượng phân tử lớn hơn: CH~3~SH 7,6 °C (CH~3~OH 64,7 °C); C~2~H~5~SH 34,7 °C (C~2~H~5~OH 78,5 °C).
- **Vì sao?** S kém âm điện hơn O nhiều, liên kết S–H gần như không phân cực → thiol **không tạo liên kết hydro** đáng kể giữa các phân tử.
- Rất **khó tan trong nước** (cũng do không tạo liên kết hydro với nước), tan nhiều trong ethanol, ether.
- **Mùi rất khó chịu, rất mạnh**: mũi người nhận ra methanthiol ở nồng độ chỉ khoảng 2,1·10^−8^ mg/L không khí.

> [!ung-dung] Mùi thiol trong đời sống và lâm sàng
> - Khí đốt (gas) vốn không mùi; người ta **thêm một lượng nhỏ mercaptan** để phát hiện rò rỉ bằng mũi.
> - **Methyl mercaptan** sinh ra khi protein chứa lưu huỳnh (keratin của lông, protein thịt) bị thối rữa; có trong **phân** người, góp phần gây **hôi miệng** (vi khuẩn trên lưỡi phân giải protein).

### 2.3. Tính chất hóa học

**a) Giống alcol**

=> 2C~2~H~5~SH + 2K → 2C~2~H~5~SK (kali ethyl mercaptid) + H~2~↑

=> C~2~H~5~SH + CH~3~COOH →(H^+^) CH~3~CO–S–C~2~H~5~ + H~2~O

=> 2C~2~H~5~SH → C~2~H~5~–S–C~2~H~5~ (thioether) + H~2~S  (CdS, 250 °C)

(Sách in "→ 2C~2~H~5~–S–C~2~H~5~ + H~2~S", thừa hệ số 2; tr. 151.)

**b) Khác alcol**

- **Tính acid mạnh hơn alcol** (pK~a~ ethanthiol ≈ 10,6, so với ethanol ≈ 16): thiol tác dụng được với **kiềm** và với **oxid kim loại nặng** tạo muối **mercaptid**.

=> CH~3~SH + NaOH → CH~3~SNa (natri methyl mercaptid) + H~2~O

=> 2C~2~H~5~SH + HgO → (C~2~H~5~S)~2~Hg + H~2~O

**Vì sao thiol acid hơn alcol?** Nguyên tử S **lớn hơn** O nhiều; liên kết S–H dài và **yếu** hơn O–H, và điện tích âm của RS^−^ được "trải" trên một nguyên tử lớn nên bền hơn. Cái tên *mercaptan* đến từ tiếng Latin *mercurium captans* — "bắt giữ thủy ngân".

- **Dễ bị oxy hóa** (ngay cả bởi oxy không khí) thành **disulfid** R–S–S–R:

=> 4C~2~H~5~SH + O~2~ → 2C~2~H~5~–S–S–C~2~H~5~ (diethyl disulfid) + 2H~2~O

(Sách in "→ C~2~H~5~–S–S–C~2~H~5~ + 2H~2~O", thiếu hệ số 2 trước disulfid; tr. 152.)

> [!ung-dung] Nhóm –SH trong cơ thể
> - **Cystein** HS–CH~2~–CH(NH~2~)–COOH (sách: acid α-amino β-thiol propionic) là amino acid (acid amin) có nhóm thiol. Nhóm –SH của cystein nằm ở **trung tâm hoạt động** của nhiều enzym (ví dụ glyceraldehyd-3-phosphat dehydrogenase, sách gọi phosphoglyceraldehydrase).
> - Hai cystein bị oxy hóa nối với nhau bằng **cầu disulfid** –S–S– (tạo **cystin**). Cầu disulfid giữ hình dạng của **insulin**, kháng thể, và làm **keratin** của tóc, móng bền chắc.
> - **Glutathion** (chứa cystein) chuyển qua lại giữa dạng khử G–SH và dạng oxy hóa G–S–S–G, là hệ chống oxy hóa chính trong tế bào.
> - **Acetyl-CoA** là một **thioester** — dạng "hoạt hóa" của acid acetic trong chuyển hóa.
> - **Kim loại nặng (Hg, As, Pb, Cd) gắn mạnh vào –SH** của enzym làm enzym mất hoạt tính → đây là cơ chế độc chung của chúng.

### 2.4. Điều chế

=> C~2~H~5~I + KSH → C~2~H~5~SH + KI

(Alkyl halid + kali hydrosulfid, phản ứng thế nucleophil.)

### 2.5. Ứng dụng y học

- **Dimercaprol** (2,3-dimercapto propan-1-ol, **BAL**): HS–CH~2~–CH(SH)–CH~2~OH. Hai nhóm –SH **kề nhau** "kẹp" ion kim loại thành vòng 5 cạnh bền, kéo kim loại ra khỏi enzym, sau đó phức được thải qua nước tiểu. Dùng giải độc **arsen, thủy ngân**, chì (phối hợp). Xem thêm bảng thuốc tạo phức ở bài *Kim loại khối d (chuyển tiếp)* (vc-03).
- **Ethanthiol** dùng tổng hợp thuốc ngủ **sulfonal** (Giáo trình tr. 152).

> [!cap-nhat] Dimercaprol và yperit; sulfonal
> - Giáo trình ghi dimercaprol "điều trị nhiễm độc yperit". Thực ra BAL (*British Anti-Lewisite*) được phát triển để giải độc **lewisit** — một **chất độc chiến tranh chứa arsen**. **Yperit** (khí mù tạt lưu huỳnh, mục 5) gây độc bằng cách **alkyl hóa**, **không có thuốc giải đặc hiệu**; dimercaprol không có tác dụng với yperit.
> - Hiện nay dimercaprol (tiêm bắp, đau, nhiều tác dụng phụ) phần lớn đã được thay bằng các chất cùng nguyên lý nhưng dùng đường uống, ít độc hơn: **DMSA (succimer)**, **DMPS**.
> - **Sulfonal** là thuốc ngủ cổ (cuối thế kỷ XIX), đã bị loại bỏ từ lâu vì độc (tích lũy, gây porphyrin niệu).

## 3. Phenol

### 3.1. Định nghĩa và phân loại

**Phenol** là dẫn xuất của hydrocarbon thơm khi thay một hay nhiều H **của vòng benzen** bằng nhóm –OH (Giáo trình tr. 152).

- **Monophenol** (1 nhóm –OH): phenol, o-cresol, α-naphtol.
- **Polyphenol** (2 hoặc 3 nhóm –OH; sách gọi chung di- và triphenol): pyrocatechin, resorcinol, hydroquinon, pyrogalol.

### 3.2. Danh pháp và đồng phân

**IUPAC: tên hydrocarbon + số chỉ vị trí –OH + đuôi -ol.** Ví dụ benzen-1,2,4-triol; naphtalen-1,3-diol. Bản thân C~6~H~5~OH giữ tên **phenol**. Phenol có **đồng phân vị trí** của nhóm chức (o-, m-, p-).

| Công thức | Tên IUPAC | Tên thông thường |
|---|---|---|
| C~6~H~5~OH | phenol (hydroxy benzen) | acid phenic, acid carbolic |
| CH~3~–C~6~H~4~–OH | 2-, 3-, 4-methyl phenol | **o-, m-, p-cresol** |
| 1,2-(OH)~2~C~6~H~4~ | benzen-1,2-diol | **pyrocatechin** (catechol); sách: o-hydroquinon |
| 1,3-(OH)~2~C~6~H~4~ | benzen-1,3-diol | **resorcinol**; sách: m-hydroquinon |
| 1,4-(OH)~2~C~6~H~4~ | benzen-1,4-diol | **hydroquinon** (p-hydroquinon) |
| 1,2,3-(OH)~3~C~6~H~3~ | benzen-1,2,3-triol | **pyrogalol** |
| 1,3,5-(OH)~3~C~6~H~3~ | benzen-1,3,5-triol | phloroglucinol |
| C~10~H~7~OH | naphtalen-1-ol / naphtalen-2-ol | **α-naphtol / β-naphtol** |

> [!bay] Tên các diphenol
> - Tên quốc tế thường dùng: **catechol (1,2) – resorcinol (1,3) – hydroquinon (1,4)**. Sách dùng "o-, m-, p-hydroquinon" cho cả ba (tr. 153); khi đọc tài liệu khác chỉ **1,4** mới là hydroquinon.
> - Hình resorcinol ở tr. 153 của sách vẽ 3 nhóm –OH, trùng với kiểu triphenol. **Resorcinol là diphenol, hai –OH ở vị trí 1,3 (meta).** **Pyrogalol là 1,2,3-triol**, không phải 1,3,5 (1,3,5 là phloroglucinol).
> - Tên sách "1,4-hydroxy benzen" cần đọc là 1,4-**di**hydroxy benzen.

### 3.3. Tính chất vật lý

Đa số phenol là **chất kết tinh không màu**, mùi đặc biệt, **ít tan trong nước lạnh** nhưng tan nhiều trong ether, benzen (và tan tốt trong nước nóng). Phenol: t~nc~ 41 °C, t~s~ 182 °C; các cresol: t~s~ 191–203 °C. Phenol để lâu ngoài không khí bị **oxy hóa chậm** thành chất màu, chuyển **hồng → đỏ nâu**; phenol **hút ẩm** nên dễ "chảy nước".

### 3.4. Tính chất hóa học

Nhóm –OH của phenol gắn trực tiếp vào vòng benzen. Cặp electron chưa liên kết của O **liên hợp với hệ π** của vòng (liên hợp p–π, hiệu ứng **+C** của –OH). Từ một nguyên nhân này sinh ra **ba hệ quả** khác hẳn alcol:

1. Liên kết **O–H phân cực mạnh hơn** → phenol có **tính acid**.
2. Liên kết **C–O bền hơn** (mang một phần tính chất liên kết đôi) → –OH **rất khó bị thế**.
3. Vòng **giàu electron ở o-, p-** → **thế electrophil** vào nhân rất dễ.

#### 3.4.1. Tính acid (phản ứng của H trong –OH)

Phenol tác dụng với **kiềm** (alcol thì không), nên còn gọi là **acid phenic**:

=> C~6~H~5~OH + NaOH → C~6~H~5~ONa (natri phenolat, tan) + H~2~O

Nhưng phenol **yếu hơn cả acid carbonic**, nên CO~2~ đẩy được phenol ra khỏi phenolat (dung dịch **vẩn đục** vì phenol ít tan):

=> C~6~H~5~ONa + CO~2~ + H~2~O → C~6~H~5~OH + NaHCO~3~

| Chất | K~a~ (25 °C, theo sách) | pK~a~ |
|---|---|---|
| Acid carbonic | 3,5·10^−7^ | 6,5 |
| Phenol | 1,0·10^−10^ | 10,0 |
| m-cresol | 9,8·10^−11^ | 10,0 |
| p-cresol | 6,7·10^−11^ | 10,2 |
| o-cresol | 6,3·10^−11^ | 10,2 |

**Vì sao phenol acid hơn alcol?** (Hình 1) Khi mất H^+^, ion **phenoxid** C~6~H~5~O^−^ có điện tích âm **được giải tỏa** vào vòng (lên 2 vị trí ortho và vị trí para) → ion bền → cân bằng phân li dịch về phía tạo ion. Ion **alkoxid** RO^−^ thì điện tích âm **dồn hết trên O**, lại bị gốc R đẩy thêm electron (+I) → kém bền. Chi tiết các công thức cộng hưởng xem bài Hiệu ứng cấu trúc, mục 4.2.

**Ảnh hưởng của nhóm thế** (sách tr. 155):

- Nhóm **hút electron** (–NO~2~) làm phenoxid bền hơn → acid **mạnh hơn**: phenol < p-nitrophenol < **2,4,6-trinitrophenol** (acid picric, pK~a~ ≈ 0,4 — mạnh ngang acid vô cơ).
- Nhóm **đẩy electron** (–CH~3~) → acid **yếu hơn**: các cresol yếu hơn phenol một chút.

![Hình 2. Thang tính acid của alcol, nước, thiol, phenol và các acid; mỗi thuốc thử Na, NaOH, NaHCO₃ phản ứng được với vùng nào](thang-acid.svg)

> [!bay] Đọc thang acid để trả lời câu phân biệt
> - **Na** phản ứng với **mọi** chất có H linh động: alcol, phenol, acid, cả **nước**. Không dùng Na để phân biệt alcol với phenol trong dung dịch nước.
> - **NaOH** chỉ "lấy" được H^+^ của chất **acid mạnh hơn nước**: phenol, thiol, acid carboxylic → có phản ứng; **alcol không**.
> - **NaHCO~3~** (sủi bọt CO~2~) chỉ phản ứng với acid **mạnh hơn H~2~CO~3~**: acid acetic, acid picric → có; **phenol không**.
> - Thứ tự đáp án câu 7.13 của sách: **C~6~H~5~OH < H~2~CO~3~ < CH~3~COOH**.

#### 3.4.2. Phản ứng thế nhóm –OH — rất khó

Khác alcol, phenol **không tác dụng với HCl**; với PCl~5~ chỉ cho rất ít clorobenzen, chủ yếu tạo **triphenyl phosphat** (C~6~H~5~O)~3~P=O. Lý do: liên hợp p–π làm liên kết C–O **chặt hơn**.

#### 3.4.3. Tạo ester

Phenol **khó** ester hóa trực tiếp với acid carboxylic (O kém nucleophil vì cặp electron đã "chia" cho vòng). Phải dùng tác nhân mạnh hơn: **anhydrid acid** hoặc **clorid acid**.

=> C~6~H~5~OH + (CH~3~CO)~2~O → CH~3~COOC~6~H~5~ (phenyl acetat) + CH~3~COOH

=> C~6~H~5~OH + CH~3~COCl → CH~3~COOC~6~H~5~ + HCl

> [!ung-dung] Aspirin được tổng hợp đúng theo cách này
> **Acid salicylic** (o-hydroxybenzoic) có nhóm –OH phenol. Acetyl hóa nhóm này bằng **anhydrid acetic** cho **acid acetylsalicylic (aspirin)** — một **ester của phenol**:
>
> => HO–C~6~H~4~–COOH + (CH~3~CO)~2~O → CH~3~COO–C~6~H~4~–COOH + CH~3~COOH
>
> Aspirin để ẩm bị thủy phân trở lại thành acid salicylic (có mùi giấm). Acid salicylic tự do có –OH phenol nên cho **màu tím với FeCl~3~**, còn aspirin tinh khiết thì không — cơ sở của phép thử **giới hạn acid salicylic tự do** trong kiểm nghiệm aspirin.

#### 3.4.4. Tạo ether

Phenol không tạo ether trực tiếp với alcol. Phải cho **phenolat** phản ứng với **dẫn xuất halogen** (tổng hợp Williamson):

=> C~6~H~5~ONa + CH~3~Cl → C~6~H~5~–O–CH~3~ + NaCl

Sản phẩm là methyl phenyl ether (anisol).

#### 3.4.5. Thế vào nhân thơm — rất dễ, ở o- và p-

**Với nước brom**: ngay ở nhiệt độ thường, không cần xúc tác, cả 3 vị trí o, o′, p bị thế → **kết tủa trắng** 2,4,6-tribromophenol (dùng để **nhận biết** phenol):

=> C~6~H~5~OH + 3Br~2~ → C~6~H~2~Br~3~OH↓ (trắng) + 3HBr

**Nitro hóa** bằng HNO~3~ **loãng** → hỗn hợp **o-nitrophenol** và **p-nitrophenol**. Với HNO~3~ đặc (có H~2~SO~4~) → 2,4,6-trinitrophenol (acid picric).

> [!bay] So với benzen
> Benzen chỉ phản ứng với Br~2~ **khan** khi có **xúc tác Fe/FeBr~3~**, và chỉ thế 1 H. Phenol phản ứng với **nước brom** không cần xúc tác và thế **3 H**. Đó là "chữ ký" của hiệu ứng +C của –OH (vòng giàu electron).

#### 3.4.6. Tạo phức màu với FeCl~3~

**Các phenol** tác dụng với dung dịch FeCl~3~ tạo phức có màu **tím** hoặc **xanh tím** (tùy cấu tạo):

=> 6C~6~H~5~OH + FeCl~3~ → [Fe(OC~6~H~5~)~6~]^3−^ + 3Cl^−^ + 6H^+^

Alcol (kể cả alcol benzylic, glycerol) **không** cho màu này. Đây là đáp án câu 7.14: phân biệt **phenol** (FeCl~3~ → tím) với **polyalcol** (Cu(OH)~2~ → xanh lam).

#### 3.4.7. Phản ứng oxy hóa

Phenol **dễ bị oxy hóa hơn nhiều** so với benzen và alcol thơm; nhân thơm dễ bị phá vỡ:

- Với không khí: oxy hóa chậm thành sản phẩm màu (hồng, đỏ nâu).
- Với H~2~O~2~ hoặc acid cromic: phenol → **p-hydroquinon** → **p-benzoquinon** → cuối cùng vỡ vòng thành acid oxalic.
- Với KMnO~4~: vỡ vòng tạo **acid muconic** HOOC–CH=CH–CH=CH–COOH.

Cặp **hydroquinon ⇌ quinon** chuyển hóa **thuận nghịch** (cho/nhận 2 H, tức 2 e^−^ + 2 H^+^):

=> HO–C~6~H~4~–OH ⇌ O=C~6~H~4~=O + 2H^+^ + 2e^−^

> [!ung-dung] Hệ quinon trong cơ thể và trong thuốc
> - **Ubiquinon (coenzym Q)** trong chuỗi hô hấp tế bào và **vitamin K** (một naphtoquinon) hoạt động đúng nhờ chuyển hóa qua lại quinon ⇌ hydroquinon. Đây là "các quá trình oxy hóa sinh học" mà sách nhắc đến (tr. 157).
> - Hydroquinon khử được ion Ag^+^ nên được dùng làm **thuốc hiện ảnh** (phim ảnh). Hydroquinon còn là thuốc bôi **làm giảm sắc tố** (nám); ở nhiều nước chỉ được dùng theo đơn và bị cấm trong mỹ phẩm vì nguy cơ kích ứng, sạm da ngược (ochronosis).

### 3.5. Điều chế

- **Từ nhựa than đá**: chưng cất ở 170–240 °C lấy **dầu trung bình** (chứa phenol, đồng đẳng và naphtalen). Làm nguội, lọc bỏ naphtalen kết tinh. Phần dầu còn lại cho tác dụng với kiềm → phenolat **tan**, tách khỏi phần không tan. Sục CO~2~ (hoặc thêm H~2~SO~4~) giải phóng phenol, rồi cất phân đoạn. *(Đây đúng là ứng dụng thang acid ở mục 3.4.1.)*
- **Từ dẫn xuất halogen thơm** (phải dùng điều kiện khắc nghiệt vì Cl gắn vào vòng rất kém linh động, xem bài Dẫn xuất halogen):

=> C~6~H~5~Cl + 2NaOH → C~6~H~5~ONa + NaCl + H~2~O  (≈ 300 °C, áp suất cao)

=> C~6~H~5~ONa + HCl → C~6~H~5~OH + NaCl

Hoặc thủy phân bằng hơi nước có xúc tác ở nhiệt độ cao: C~6~H~5~Cl + H~2~O → C~6~H~5~OH + HCl.

> [!vi-du] Ngoài sách: phương pháp cumen
> Ngày nay phần lớn phenol công nghiệp được sản xuất bằng **phương pháp cumen**: benzen + propen → cumen (isopropyl benzen); oxy hóa cumen bằng không khí rồi phân hủy bằng acid → **phenol + aceton** (hai sản phẩm có giá trị cùng lúc).

### 3.6. Ứng dụng và ý nghĩa y học

**Phenol (acid phenic)**: chất kết tinh mùi hắc, dễ hút nước. Dùng **tẩy uế nhà cửa, sát trùng dụng cụ**; nguyên liệu sản xuất phẩm nhuộm, chất dẻo (Giáo trình tr. 157).

**Hydroquinon** và dẫn xuất: dùng trong công nghệ phim ảnh vì khử được ion bạc.

**Polyphenol thực vật** (chè xanh) và **α-tocopherol (vitamin E)** — một phenol có vòng chroman — là chất **chống oxy hóa**, phá hủy gốc tự do peroxid ROO• (sách viết RCOO•). Cơ chế và mức bằng chứng đã trình bày ở bài *Phản ứng của hợp chất hữu cơ* (hc-04) (mục peroxy hóa lipid); không nhắc lại ở đây.

> [!ung-dung] Phenol, cresol: sát khuẩn mạnh nhưng ăn da
> - **Cơ chế**: phenol làm **biến tính protein** và phá màng tế bào vi khuẩn. Năm 1867, Joseph Lister dùng phenol (acid carbolic) phun phòng mổ, mở đầu kỷ nguyên **phẫu thuật vô khuẩn**. Phenol từng là "chuẩn" để so sánh các chất sát khuẩn (**hệ số phenol**).
> - **Ăn da**: phenol đậm đặc cũng biến tính protein **của da người** → bỏng màu trắng, sau thành nâu; do phenol **làm tê đầu mút thần kinh** nên lúc đầu **ít đau**, dễ bị coi nhẹ. Phenol **thấm nhanh qua da** → ngộ độc toàn thân (loạn nhịp tim, co giật, suy thận) dù chỉ bỏng một vùng da không quá rộng. Sơ cứu: cởi bỏ quần áo dính hóa chất, lau rửa bằng **polyethylen glycol (PEG 300/400)** nếu có, nếu không thì **xả nước thật nhiều, kéo dài**.
> - **Cresol** (hỗn hợp o-, m-, p-) sát khuẩn **mạnh hơn** phenol và cũng độc. Dung dịch **cresol – xà phòng** (lysol, "nước crezyl") dùng tẩy uế nhà vệ sinh, chất thải, chuồng trại; **không** dùng cho da, niêm mạc.
> - Ngày nay phenol hầu như **không còn dùng sát khuẩn da**. Phenol loãng (khoảng 1–1,5%) còn có trong một số thuốc xịt họng giảm đau; phenol đậm đặc dùng trong **lột da hóa học** và **tiêm hủy thần kinh** — đều là thủ thuật chuyên khoa.
> - Nhiều thuốc có nhóm –OH phenol: **paracetamol**, salbutamol, adrenalin, morphin, estradiol.

> [!yhct] Phenol trong dược liệu: eugenol, thymol và tannin
> - **Eugenol** (2-methoxy-4-allyl phenol) là thành phần chính của tinh dầu nụ **Đinh hương** (thường > 70%), có cả trong **Hương nhu tía**. **Thymol** (2-isopropyl-5-methyl phenol) có trong cỏ **Xạ hương** (*Thymus*). Cả hai là **phenol** thật sự (–OH gắn vào vòng), khác menthol của Bạc hà là **alcol vòng** (bài *Cấu trúc phân tử hợp chất hữu cơ — đồng phân*, hc-01). Tên IUPAC của eugenol đã gặp ở bài *Danh pháp hóa học hữu cơ* (hc-02).
> - **Hóa học áp dụng ngay**: vì có tính acid phenol, eugenol **tan trong dung dịch NaOH/KOH** thành phenolat, còn các thành phần không phải phenol của tinh dầu thì không. Phương pháp kinh điển dựa vào đó để **định lượng eugenol** trong tinh dầu Đinh hương (đo thể tích tinh dầu bị kiềm "hút" mất) và để **tách** eugenol (acid hóa lại phenolat). Eugenol, thymol cho **màu với FeCl~3~**.
> - **Ứng dụng có cơ sở**: eugenol sát khuẩn, **giảm đau tại chỗ** — dùng trong **nha khoa** (xi măng kẽm oxid – eugenol trám tạm, giảm đau tủy). Thymol sát khuẩn, có trong một số nước súc miệng. Bằng chứng chủ yếu cho **dùng tại chỗ**. **Thận trọng**: tinh dầu Đinh hương nguyên chất gây **kích ứng, bỏng niêm mạc**; trẻ nhỏ uống nhầm có thể **tổn thương gan**.
> - **Tannin** là **polyphenol phân tử lớn** (Ngũ bội tử, vỏ Măng cụt, lá Ổi, lá Chè, búp Sim): nhiều nhóm –OH phenol **kết tủa protein** bề mặt niêm mạc (cơ sở của tác dụng **thu liễm**) và cho **màu xanh đen** với muối sắt (lý do không sắc bằng nồi sắt). Chi tiết về Ngũ bội tử, acid gallic, tương tác của tannin với alkaloid và thuốc (xem bài *Acid carboxylic, ester, hợp chất tạp chức*, mã hc-09).

## 4. Ether

### 4.1. Định nghĩa và danh pháp

**Ether** có công thức chung **R–O–R′** (R, R′ là gốc hydrocarbon, giống hoặc khác nhau).

- **IUPAC: tên nhóm alkoxy (RO–) + tên hydrocarbon** (gốc nhỏ hơn làm alkoxy): CH~3~–O–CH~3~ **methoxy methan**; C~2~H~5~–O–CH~3~ **methoxy ethan** (sách ghi *ethoxy methan* — xem bẫy).
- **Thông thường: tên các gốc hydrocarbon + ether**: CH~3~–O–C~3~H~7~ methyl propyl ether; C~2~H~5~–O–C~2~H~5~ **diethyl ether**.

> [!bay] Gốc nào làm "alkoxy"?
> Theo IUPAC, **mạch dài hơn** làm hydrocarbon chính, gốc **ngắn hơn** làm alkoxy. C~2~H~5~–O–CH~3~ là **methoxy ethan**. Sách (tr. 158) ghi "ethoxy methan" — ngược quy ước; khi viết bài nên dùng **methoxy ethan** (hoặc tên thông thường **ethyl methyl ether**, các gốc xếp theo chữ cái).

### 4.2. Đồng phân

- **Mạch carbon**: C~4~H~10~O có methyl n-propyl ether CH~3~–O–CH~2~CH~2~CH~3~, methyl isopropyl ether CH~3~–O–CH(CH~3~)~2~, diethyl ether C~2~H~5~–O–C~2~H~5~.
- **Nhóm chức**: ether đồng phân với **alcol** cùng công thức: methyl propyl ether và alcol butylic đều là C~4~H~10~O.

### 4.3. Tính chất vật lý

- Dimethyl ether là **khí**; các ether cao hơn là chất lỏng không màu, **rất dễ bay hơi**; từ (C~17~H~35~)~2~O trở lên là chất rắn.
- **Nhẹ hơn nước**, rất ít tan trong nước, hòa tan được nhiều chất hữu cơ.
- t~s~ của ether **luôn thấp hơn** alcol đồng phân: CH~3~OCH~3~ −23,7 °C so với C~2~H~5~OH 78,5 °C; C~2~H~5~OC~2~H~5~ 34,6 °C so với C~4~H~9~OH 117,7 °C.

**Vì sao?** Ether **không có H gắn vào O**, nên các phân tử ether **không tạo liên kết hydro với nhau**; chúng tồn tại dạng đơn phân tử, dễ bay hơi. Alcol thì "nối" với nhau thành chuỗi ···O–H···O–H··· (sách gọi là *liên hợp phân tử*), phải tốn thêm năng lượng để phá. (O của ether vẫn **nhận** được liên kết hydro từ nước, nên diethyl ether tan trong nước một ít, khoảng 6–7 g/100 mL.)

### 4.4. Tính chất hóa học

**a) Khá bền (trơ)**

- **Không** tác dụng với kim loại kiềm (không có H linh động). Vì vậy người ta dùng **Na để làm khan ether** (Na phản ứng hết với nước lẫn trong ether).
- Không tác dụng với acid loãng, nhưng bị **acid vô cơ đậm đặc** (HI) cắt mạch:

=> CH~3~–O–C~2~H~5~ + 2HI → CH~3~I + C~2~H~5~I + H~2~O

Phản ứng này dùng để **xác định cấu tạo** hai gốc của ether (phân tích hai iodid sinh ra).

**b) Tạo peroxid** khi để lâu tiếp xúc oxy không khí và ánh sáng. Diethyl ether tạo nhiều peroxid, trong đó có CH~3~–CH(OH)–O–O–CH(OH)–CH~3~ (sách gọi *peroxid oxy ethyl*). Peroxid hữu cơ **khó bay hơi, kém bền, dễ nổ** — khi chưng cất ether, peroxid **dồn lại ở đáy bình** và có thể phát nổ. Đây là nguyên nhân các vụ cháy nổ ether mê.

> [!ung-dung] An toàn khi dùng ether trong phòng thí nghiệm
> Ether **cực kỳ dễ cháy** (hơi nặng hơn không khí, lan dọc mặt bàn đến ngọn lửa). Bảo quản trong **chai tối màu, kín, nơi mát**, ghi ngày mở nắp; **thử peroxid** (bằng KI: peroxid oxy hóa I^−^ thành I~2~ màu vàng – nâu) trước khi chưng cất ether đã để lâu. Không bao giờ cất ether đến khô bình.

### 4.5. Điều chế

Đun alcol với H~2~SO~4~ đặc (≈ 140 °C) hoặc cho hơi alcol qua Al~2~O~3~ ở 300 °C (mục 1.5.4). Ether **bất đối xứng** thì dùng **alcolat (hoặc phenolat) + dẫn xuất halogen** (Williamson):

=> CH~3~ONa + C~2~H~5~Cl → CH~3~–O–C~2~H~5~ + NaCl

=> C~6~H~5~ONa + C~2~H~5~Cl → C~6~H~5~–O–C~2~H~5~ (ethyl phenyl ether) + NaCl

### 4.6. Ứng dụng và ý nghĩa y học

- **Dung môi chiết tách**, tinh chế trong phòng thí nghiệm (hòa tan nhiều chất hữu cơ, dễ bay hơi nên dễ loại bỏ).
- **Thuốc gây mê**: **diethyl ether** ("ether mê") — chất lỏng không màu, mùi dễ chịu, dễ bay hơi, **dễ bắt lửa**; **divinyl ether** CH~2~=CH–O–CH=CH~2~ gây mê nhanh hơn.
- Trong cơ thể, **thyroxin** (hormon tuyến giáp) có liên kết ether giữa hai vòng thơm.

> [!cap-nhat] Ether mê ngày nay
> Năm 1846, diethyl ether được dùng gây mê công khai lần đầu, mở đầu ngành gây mê. Hiện nay diethyl ether và divinyl ether **không còn dùng** trong gây mê vì **dễ cháy nổ**, kích ứng đường thở, khởi mê và hồi tỉnh chậm, nôn nhiều sau mổ. Thuốc mê hô hấp hiện dùng (isofluran, sevofluran, desfluran) **vẫn là ether** nhưng được **fluor hóa** nên không cháy — xem bài Dẫn xuất halogen, khung "Cloroform không còn là thuốc mê".

## 5. Thioether

**Thioether** có cấu tạo chung **R–S–R′**, tương tự ether R–O–R′. Theo sách, tên gồm **tên gốc hydrocarbon + chữ thioether**; vì giống muối của hydrosulfid nên còn gọi là **sulfid**. Ví dụ: C~2~H~5~–S–C~2~H~5~ **diethyl thioether** = **diethyl sulfid**.

**Điều chế**: alkyl halid + kali sulfid:

=> 2C~2~H~5~I + K~2~S → C~2~H~5~–S–C~2~H~5~ + 2KI

**Tính chất**: thioether là chất **trung tính**, nhưng S dễ bị **oxy hóa** từng nấc thành **sulfoxid** rồi **sulfon**:

=> (C~2~H~5~)~2~S →[O] (C~2~H~5~)~2~S=O (sulfoxid) →[O] (C~2~H~5~)~2~SO~2~ (sulfon)

**Yperit** (dicloro diethyl sulfid, khí mù tạt) S(CH~2~CH~2~Cl)~2~ là **chất độc hóa học** dùng trong chiến tranh: gây bỏng phồng da, mắt, đường hô hấp.

> [!ung-dung] Thioether, sulfoxid trong cơ thể và trong thuốc
> - **Methionin** (amino acid thiết yếu) là một thioether CH~3~–S–CH~2~CH~2~–CH(NH~2~)COOH. Dạng hoạt hóa S-adenosyl methionin là chất **cho nhóm methyl** quan trọng nhất của cơ thể.
> - **Yperit** độc vì nó **alkyl hóa** DNA (ADN) và protein (Cl ở vị trí β so với S rất linh động). Biến đổi cấu trúc yperit (thay S bằng N) tạo ra các **"mù tạt nitơ"** — những **thuốc hóa trị ung thư** đầu tiên (cyclophosphamid, clorambucil thuộc họ này). Xem thêm "Thuốc alkyl hóa" ở bài *Phản ứng của hợp chất hữu cơ* (hc-04).
> - Nhóm **sulfoxid** gặp trong **DMSO** (dimethyl sulfoxid, dung môi thấm qua da) và trong thuốc ức chế bơm proton **omeprazol**.
>
> **Hành, tỏi**: sách nêu thioether và dẫn xuất có nhiều trong hành, tỏi. Cụ thể, tỏi nguyên chứa **alliin** — một **sulfoxid** của cystein. Khi giã, enzym alliinase chuyển alliin thành **allicin** (mùi tỏi đặc trưng), rồi thành các **diallyl sulfid, disulfid, trisulfid**. Vì vậy tỏi phải **giã/thái và để vài phút** thì mới nồng mùi.

## 6. So sánh tổng hợp và nhận biết

| Phản ứng | Alcol (monoalcol) | Polyalcol (2 –OH kề) | Phenol | Thiol | Ether |
|---|---|---|---|---|---|
| Na | + (H~2~↑) | + | + | + | **−** |
| NaOH | **−** | − | **+** (tan) | **+** | − |
| NaHCO~3~ (CO~2~↑) | − | − | **−** | − | − |
| Cu(OH)~2~, nhiệt độ thường | − | **+ xanh lam** | − | − | − |
| FeCl~3~ | − | − | **+ tím** | − | − |
| Nước brom | − (trừ alcol không no) | − | **+ tủa trắng** | (bị oxy hóa) | − |
| Liên kết hydro giữa các phân tử | Có → t~s~ cao | Rất nhiều → t~s~ rất cao | Có | **Không** → t~s~ thấp | **Không** → t~s~ thấp |

**Phân biệt bậc alcol**: (1) **Lucas** — III ngay, II vài phút, I không; (2) **oxy hóa nhẹ (CuO, t°)** rồi thử sản phẩm: bậc I → aldehyd (**tráng gương +**), bậc II → ceton (tráng gương −), bậc III → không bị oxy hóa.

## 7. Tự lượng giá — đáp án và lưu ý (Giáo trình tr. 161–163; hướng dẫn tr. 253–255)

> [!vi-du] 7.1 — Gọi tên
> a) (CH~3~)~3~C–OH: **2-methyl propan-2-ol**, alcol tert-butylic · b) CH~3~CH(OH)CH~3~: **propan-2-ol**, alcol **isopropylic** · c) C~6~H~5~CH~2~OH: **phenyl methanol**, alcol benzylic · d) vòng 6 cạnh có nối đôi cạnh C mang –OH: **cyclohex-2-en-1-ol** (sách: 2-cyclohexenol) · e) (C~6~H~5~)~3~C–OH: **triphenyl methanol** · f) CH~2~=CH–CH~2~–OH: **prop-2-en-1-ol**, alcol allylic · g) CH~3~–C(CH~3~)(OH)–CH~2~–CH~3~: **2-methyl butan-2-ol** · h) **2-methyl cyclobutan-1-ol**.
>
> Lưu ý về đáp án in cuối sách: ý b) in "alcol iso butylic" — **sai**, phải là alcol **isopropylic** (chỉ có 3 C). Ý f) in "propanol" — **thiếu nối đôi**; đúng là prop-2-en-1-ol (alcol allylic). Đề ý g) in "CH" ở nhánh trên, hiểu là CH~3~.

> [!vi-du] 7.2 — Viết công thức
> a) pentan-3-ol: CH~3~CH~2~CH(OH)CH~2~CH~3~ · b) 2-phenyl ethanol: C~6~H~5~–CH~2~–CH~2~–OH · c) pent-3-yn-2-ol: CH~3~–C≡C–CH(OH)–CH~3~ · d) 2,2-dimethyl butan-1-ol: CH~3~CH~2~C(CH~3~)~2~CH~2~OH · e) 2-methyl cyclopentanol: vòng 5 cạnh, –OH ở C1, CH~3~ ở C2 · f) alcol isopropylic: CH~3~CH(OH)CH~3~ · g) alcol amylic: CH~3~(CH~2~)~4~OH (C~5~H~11~OH mạch thẳng) · h) **alcol isoamylic: (CH~3~)~2~CH–CH~2~–CH~2~–OH** (3-methyl butan-1-ol) · i) glycerol: HOCH~2~–CHOH–CH~2~OH.
>
> Đáp án sách ý h) in "C~2~H~5~–CHOH–C~2~H~5~" — đó là **pentan-3-ol**, không phải alcol isoamylic. Chính Bảng 5 của sách (tr. 142) ghi đúng isoamylic là (CH~3~)~2~CH–CH~2~–CH~2~–OH.

> [!vi-du] 7.3 – 7.5 — So sánh
> - **7.3**: từ bậc I → III, số gốc alkyl đẩy electron (+I) tăng → liên kết O–H **kém phân cực dần** (tính acid giảm), còn liên kết C–O phân cực mạnh dần (bậc III dễ tách –OH, tạo carbocation: Lucas nhanh nhất). Khả năng **tạo ester giảm**: I > II > III. Sản phẩm oxy hóa: I → aldehyd → acid; II → ceton; III → khó, gãy mạch.
> - **7.4**: a) alcol – phenol: so sánh phản ứng với Na, **NaOH**, Na~2~CO~3~, **FeCl~3~**, thế vào nhân; b) mono – polyalcol: **Cu(OH)~2~**; c) **alcol thơm – phenol**: alcol benzylic không phản ứng NaOH, FeCl~3~, nước brom; phenol có (đáp án sách ý c) lại bàn alcol – thiol, không khớp đề).
> - **7.5**: a) alcol > ether đồng phân; b) alcol > thiol tương ứng — đều do alcol có **liên kết hydro** liên phân tử.

> [!vi-du] 7.6 – 7.8 — Phản ứng và điều chế
> - **7.6**: a) cyclopentanol —Jones→ **cyclopentanon** · b) 2-methyl hexan-1-ol —PCC→ **2-methyl hexanal** · c) pentan-1-ol —Jones→ **acid pentanoic**; —PCC→ **pentanal**. (Sách in "PPC" là lỗi in của PCC.)
> - **7.7**: CH~3~CH~2~CH~2~OH —(H~2~SO~4~ đặc, 170 °C)→ CH~3~CH=CH~2~ —(H~2~O, H^+^; Markovnikov)→ CH~3~CH(OH)CH~3~. Phân biệt: oxy hóa nhẹ (CuO, t°) rồi **tráng gương** — propan-1-ol → propanal (+); propan-2-ol → aceton (−). Cũng có thể dùng **iodoform** (propan-2-ol +) hoặc **Lucas** (propan-2-ol vẩn đục sau vài phút).
> - **7.8a** propandiol từ propan: CH~3~CH~2~CH~3~ —(t°, xt; tách H~2~)→ CH~3~CH=CH~2~ —(+Cl~2~)→ CH~3~CHCl–CH~2~Cl —(+2NaOH)→ **CH~3~CH(OH)–CH~2~OH** (propan-1,2-diol) + 2NaCl. *Đáp án sách đi qua alcol allylic rồi cộng nước ra HO–CH~2~–CH~2~–CH~2~–OH; bước cộng nước này trái quy tắc Markovnikov (thực tế cho propan-1,2-diol), nên nên dùng đường trên.*
> - **7.8b** p-cresol từ toluen: C~6~H~5~CH~3~ + Cl~2~ (Fe) → p-ClC~6~H~4~CH~3~ (cùng đồng phân ortho) → + NaOH (t°, p cao) → p-CH~3~C~6~H~4~ONa → + HCl → **p-cresol**.
> - **7.8c** 2,4-dinitrophenol từ clorobenzen: C~6~H~5~Cl → (NaOH, t°, p; rồi H^+^) C~6~H~5~OH → (HNO~3~) **2,4-dinitrophenol**. (Cách khác: nitro hóa clorobenzen thành 2,4-dinitroclorobenzen trước; khi có 2 nhóm –NO~2~ hút electron, Cl bị thủy phân dễ dàng.)

> [!vi-du] 7.9 – 7.14
> - **7.9** (theo thứ tự hình của đề): a) **2-nitrophenol** (o-nitrophenol) · b) **benzen-1,2-diol** (pyrocatechin; sách: o-hydroquinon) · c) **benzen-1,2,4-triol** · d) **benzen-1,3,5-triol** (phloroglucinol) · e) **naphtalen-1,3-diol**. Đáp án in cuối sách bị **lệch thứ tự** (gán benzen-1,2-diol cho a, 2-nitrophenol cho b) và gọi benzen-1,3,5-triol là "pyrogalol" — pyrogalol là **1,2,3**-triol.
> - **7.10**: a) p-Cl–C~6~H~4~–OH · b) 2,4,6-(O~2~N)~3~C~6~H~2~OH (acid picric) · c) p-C~2~H~5~–C~6~H~4~–OH · d) C~6~Cl~5~OH · e) o-HO–C~6~H~4~–CO–CH~3~.
> - **7.11**: a) **CH~3~ONa + C~2~H~5~Cl → CH~3~–O–C~2~H~5~ + NaCl** (hoặc C~2~H~5~ONa + CH~3~Cl); b) **C~6~H~5~ONa + C~2~H~5~Cl → C~6~H~5~–O–C~2~H~5~ + NaCl**. Đáp án sách ý a) viết "C~2~H~5~Cl + HO–C~6~H~5~ → C~2~H~5~–O–C~6~H~5~ + HCl" — đó là ethyl **phenyl** ether (đề ý b), và phenol **tự do** không phản ứng trực tiếp như vậy; phải dùng **phenolat** (chính sách nêu ở tr. 155).
> - **7.12**: a) propan-1-ol, H~2~SO~4~, 140 °C → **dipropyl ether** (C~3~H~7~)~2~O; b) K~2~Cr~2~O~7~/H~2~SO~4~ → **acid propanoic** (theo đáp án sách; nếu cất ngay sản phẩm khỏi hỗn hợp thì thu được propanal); c) 4,4-dimethyl cyclohexanol (alcol bậc II) → **4,4-dimethyl cyclohexanon**; d) naphtalen-1,4-diol —oxy hóa nhẹ→ **1,4-naphtoquinon** (giống hydroquinon → quinon).
> - **7.13**: C~6~H~5~OH < H~2~CO~3~ < CH~3~COOH.
> - **7.14**: phenol + **FeCl~3~ → tím**; polyalcol + **Cu(OH)~2~ → xanh lam**. (Cũng có thể dùng nước brom: phenol cho tủa trắng.)

## Tóm tắt

| Chủ đề | Ghi nhớ |
|---|---|
| Định nghĩa | Alcol R–OH (–OH ở C no); phenol Ar–OH (–OH ở vòng); ether R–O–R′; thiol R–SH; thioether R–S–R′ |
| Danh pháp | Alcol, phenol: hydrocarbon + **-ol**; thiol: + **thiol**; ether: **alkoxy + hydrocarbon** (methoxy ethan) hoặc gốc + **ether** |
| Bậc alcol | Theo C mang –OH; I > II > III về tính acid, tốc độ ester hóa; III > II > I về tốc độ thế bằng HX (Lucas) |
| Nhiệt độ sôi | Alcol > ether, thiol (liên kết hydro); polyalcol rất cao; nhánh → thấp hơn mạch thẳng |
| Tính acid | Alcol (≈ nước, sách: yếu hơn nước) < thiol ≈ phenol < H~2~CO~3~ < CH~3~COOH; –NO~2~ tăng, –CH~3~ giảm tính acid phenol |
| Alcol – phản ứng | Na; ester (I > II > III); HX/PX~n~; 140 °C → ether, 170 °C → alken (Zaitsev); oxy hóa I → aldehyd → acid (PCC dừng ở aldehyd), II → ceton, III khó |
| Polyalcol | 2 –OH kề + Cu(OH)~2~ → **xanh lam** |
| Phenol – phản ứng | NaOH (+), CO~2~ đẩy phenol ra; –OH khó thế; ester cần anhydrid/clorid acid; ether qua phenolat; **nước brom → tủa trắng**; HNO~3~ loãng → o-, p-nitro; **FeCl~3~ → tím**; dễ oxy hóa: hydroquinon ⇌ quinon |
| Ether | Trơ với Na, acid loãng; HI đặc cắt mạch; để lâu tạo **peroxid dễ nổ** |
| Thiol | t~s~ thấp, mùi hôi; acid hơn alcol (NaOH, HgO → mercaptid); oxy hóa → **disulfid** (cầu S–S của protein) |
| Thioether | Oxy hóa → sulfoxid → sulfon; yperit (độc chiến tranh); methionin |
| Y học | Ethanol 70% sát khuẩn; methanol → acid formic (mù, toan), giải bằng fomepizol/ethanol; glycerol (tá dược, nitroglycerin); mannitol (lợi tiểu thẩm thấu); phenol, cresol sát khuẩn – ăn da; ether mê (cũ); dimercaprol (As, Hg); eugenol, thymol, tannin trong dược liệu |
