---
title: Dẫn xuất halogen của hydrocarbon
thoi-gian: 30 phút
muc-tieu:
- Gọi được tên dẫn xuất halogen theo danh pháp IUPAC (tên halogen + tên hydrocarbon) và danh pháp thông thường (tên gốc + halid).
- Phân loại được dẫn xuất halogen theo gốc hydrocarbon (béo, thơm) và theo số nguyên tử halogen.
- Trình bày được các phản ứng chính: thế nucleophil (–OH, –NH~2~, –CN…), tách HX (quy tắc Zaitsev), phản ứng với Na (Wurtz) và Mg (thuốc thử Grignard); giải thích được vì sao halogen ở benzyl/allyl linh động còn ở vinyl/phenyl kém linh động.
- Nêu được các phương pháp điều chế chính (từ hydrocarbon, từ alcol).
- Nêu được ứng dụng và ý nghĩa y học: ethyl clorid, cloroform, iodoform, thyroxin, DDT; liên hệ thuốc mê halogen và CFC – tầng ozon.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Dẫn xuất halogen = hydrocarbon có **H được thay bằng halogen** (R–X). Tên IUPAC: **tên halogen + tên hydrocarbon** (bromo ethan); tên thông thường: **tên gốc + halid** (ethyl bromid).
> 2. Liên kết C–X **phân cực về phía X** → C mang δ+ → dễ bị tác nhân nucleophil tấn công → phản ứng đặc trưng là **thế nucleophil (S~N~)**.
> 3. Độ linh động của X: **benzyl ≈ allyl > alkyl > vinyl ≈ phenyl** (ở vinyl, phenyl có liên hợp p–π làm C–X bền); theo X: **I > Br > Cl >> F**.
> 4. Đun với **KOH/alcol** → **tách HX** tạo alken, H bị tách chủ yếu ở **C bậc cao hơn** (quy tắc **Zaitsev**). Với **Mg/ether khan** → **thuốc thử Grignard** R–Mg–X.
> 5. Y học: **ethyl clorid** gây tê lạnh, **cloroform** thuốc mê cũ (độc gan), **iodoform** sát trùng, **thyroxin** hormon giáp chứa iod, **DDT** trừ sâu độc thần kinh.

## 1. Định nghĩa và phân loại

**Định nghĩa.** Thay một hay nhiều nguyên tử H của hydrocarbon bằng một hay nhiều nguyên tử halogen (F, Cl, Br, I) ta được **dẫn xuất halogen của hydrocarbon**, ký hiệu chung **R–X** (sách viết R–Hal) (Giáo trình tr. 133).

**Phân loại theo gốc hydrocarbon:**

| Loại | Đặc điểm | Ví dụ (theo sách) |
|---|---|---|
| **Dẫn xuất halogen béo** | X gắn vào gốc no hoặc không no, không vòng thơm | CH~3~–CH~2~–Cl (ethyl clorid), CH~2~=CH–Cl (vinyl clorid) |
| **Dẫn xuất halogen thơm** | Phân tử có gốc thơm | C~6~H~5~–CH~2~–Cl (benzyl clorid), C~6~H~5~–Cl (phenyl clorid) |

**Phân loại theo số nguyên tử halogen:** **monohalogen** (CH~3~CH~2~Cl — cloroethan) và **polyhalogen** (CH~2~Cl~2~ — dicloro methan; CHCl~3~ — tricloro methan).

> [!bay] Benzyl clorid và phenyl clorid — cùng "thơm" nhưng khác hẳn nhau
> - **Phenyl clorid** C~6~H~5~–Cl: Cl gắn **thẳng vào vòng** benzen (vào C lai hóa sp^2^).
> - **Benzyl clorid** C~6~H~5~–CH~2~–Cl: Cl gắn vào **C no (sp^3^) của nhánh**, cạnh vòng.
> Sách xếp cả hai vào nhóm "thơm", nhưng về **khả năng phản ứng** chúng ở hai đầu ngược nhau (mục 4.2): benzyl clorid rất linh động, phenyl clorid rất trơ. Điều quyết định là **loại carbon mang halogen**, không phải phân tử có vòng hay không.

Trong hóa học người ta còn phân loại theo **bậc của carbon mang X**: bậc I (RCH~2~–X), bậc II (R~2~CH–X), bậc III (R~3~C–X). Bậc này quyết định cơ chế phản ứng (mục 4.1).

## 2. Danh pháp

### 2.1. Danh pháp IUPAC (thay thế)

Halogen được coi là **nhóm thế** (tiền tố fluoro-, cloro-, bromo-, iodo-), gắn vào tên hydrocarbon (Giáo trình tr. 134):

**tên = (vị trí) + tên halogen + tên hydrocarbon**

| Công thức | Tên IUPAC | Ghi chú |
|---|---|---|
| CH~3~–CH~2~–Br | bromo ethan | |
| CH~3~–CH=CH–Cl | 1-cloro propen | Đánh số để C=C và X có số nhỏ |
| CH~3~–CH~2~–C(CH~3~)(I)–CH~3~ | 2-iodo-2-methyl butan | Nhóm thế xếp theo **thứ tự chữ cái**: iodo trước methyl |
| Cl–C~6~H~4~–Cl (hai Cl đối diện) | para-dicloro benzen = **1,4-dicloro benzen** | o- = 1,2; m- = 1,3; p- = 1,4 |
| CH~2~Cl~2~, CHCl~3~, CCl~4~ | dicloro methan, tricloro methan, tetracloro methan | |

Cách làm: chọn mạch carbon dài nhất (chứa nối đôi/ba nếu có) → đánh số sao cho **tổng số chỉ vị trí nhỏ nhất** → gọi tên các nhóm thế (halogen, alkyl) theo **thứ tự a, b, c**, kèm tiền tố di-, tri-, tetra- khi có nhiều nhóm giống nhau.

### 2.2. Danh pháp thông thường (gốc – chức)

Dùng cho dẫn xuất **monohalogen đơn giản**: **tên gốc hydrocarbon + tên halid** (florid, clorid, bromid, iodid).

| Công thức | Tên thông thường | Tên IUPAC |
|---|---|---|
| CH~3~–I | methyl iodid | iodo methan |
| CH~3~CH~2~Cl | ethyl clorid | cloro ethan |
| (CH~3~)~3~C–Br | tert-butyl bromid | 2-bromo-2-methyl propan |
| CH~2~=CH–Cl | vinyl clorid | cloro ethen |
| CH~2~=CH–CH~2~–Cl | allyl clorid | 3-cloro propen |
| C~6~H~5~–CH~2~–Br | benzyl bromid | (bromo methyl) benzen |
| C~6~H~5~–Cl | phenyl clorid | cloro benzen |

Một số tên riêng còn dùng nhiều trong y dược: **cloroform** (CHCl~3~), **iodoform** (CHI~3~), **carbon tetraclorid** (CCl~4~), **methylen clorid** (CH~2~Cl~2~).

> [!bay]
> - Tên IUPAC dùng **tiền tố** "cloro-" (cloro ethan); tên thông thường dùng **hậu tố** "clorid" và đi sau tên gốc (ethyl clorid). Không viết lẫn kiểu "ethan clorid".
> - Gốc **vinyl** = CH~2~=CH–; gốc **allyl** = CH~2~=CH–CH~2~–. Một chữ khác nhau nhưng tính chất ngược nhau: vinyl clorid **trơ**, allyl clorid **rất linh động**.

## 3. Tính chất vật lý

- Ở điều kiện thường **phần lớn là chất lỏng hoặc rắn**; chỉ vài chất đầu dãy là **khí**: CH~3~Cl, CH~3~Br, C~2~H~5~Cl (Giáo trình tr. 134).
- Có **mùi đặc trưng**; **rất khó tan trong nước** nhưng **dễ tan trong dung môi hữu cơ**. Lý do: R–X không tạo được liên kết hydro với nước.
- **Nhiệt độ sôi tăng** khi khối lượng phân tử tăng: theo chiều dài mạch carbon và theo halogen (R–F < R–Cl < R–Br < R–I).

| Dẫn xuất | Công thức | t~s~ (°C) theo giáo trình |
|---|---|---|
| methyl clorid | CH~3~Cl | −24,2 |
| ethyl clorid | CH~3~CH~2~Cl | 12,2 |
| propyl clorid | CH~3~CH~2~CH~2~Cl | 47,2 |
| cloroform | CHCl~3~ | 63,3 |
| carbon tetraclorid | CCl~4~ | 76,8 |
| phenyl clorid | C~6~H~5~Cl | 78,0 (*) |
| benzyl clorid | C~6~H~5~CH~2~Cl | 179,0 |

(*) Xem khung cập nhật bên dưới.

> [!cap-nhat] Số liệu nhiệt độ sôi
> Giáo trình (Bảng 3, tr. 134) ghi phenyl clorid sôi ở 78,0 °C và cloroform ở 63,3 °C. Theo các sổ tay hóa học hiện nay, **cloro benzen sôi ở khoảng 132 °C**, cloroform ở khoảng **61 °C**. Con số 78 °C của phenyl clorid nhiều khả năng là lỗi in (nó còn trái với quy luật "phân tử lớn sôi cao hơn"). Khi thi, nếu hỏi đúng bảng thì trả lời theo sách.

> [!vi-du] Vì sao CHCl~3~, CCl~4~ "chìm" dưới nước?
> Nguyên tử Cl nặng, nên các dẫn xuất polyclo **nặng hơn nước** (cloroform khoảng 1,48 g/mL). Khi chiết bằng cloroform hay dicloro methan trong phòng thí nghiệm dược liệu, lớp dung môi hữu cơ nằm **phía dưới**, lớp nước ở trên.

## 4. Tính chất hóa học

**Gốc rễ mọi phản ứng:** liên kết C–X là liên kết σ (orbital lai hóa của C xen phủ với orbital p của X). Halogen có độ âm điện lớn hơn C, nên kéo cặp electron về phía mình:

=> C^δ+^ → X^δ−^

- C mang **δ+** → bị các **tác nhân nucleophil** (giàu electron: OH^−^, NH~3~, CN^−^, RO^−^…) tấn công.
- X dễ tách ra dưới dạng ion **X^−^** mang theo cặp electron → X là "nhóm rời đi" tốt.
- Vì vậy phản ứng quan trọng nhất của R–X là **phản ứng thế** (Giáo trình tr. 135).

### 4.1. Phản ứng thế nucleophil (S~N~)

Sơ đồ chung (Giáo trình tr. 135):

=> R–X + A–B ⇌ R–B + A–X

Trong đó B là nhóm thế: –OH, –NH~2~, –CN, –OR, gốc acid…

#### a) Thế bằng nhóm –OH → alcol (thủy phân)

Với nước, phản ứng **rất chậm và thuận nghịch**, có khi không xảy ra:

=> R–X + H–OH ⇌ R–OH + H–X

Muốn phản ứng đi hết theo chiều thuận, phải **loại HX ra khỏi cân bằng** bằng kiềm (NaOH, KOH) hoặc AgOH. Thực chất là **thủy phân trong môi trường kiềm**:

=> CH~3~Cl + NaOH → CH~3~OH (methanol) + NaCl

=> C~6~H~5~Cl + NaOH —(t°, p)→ C~6~H~5~OH + NaCl

=> R–CH~2~Cl + AgOH → R–CH~2~OH + AgCl↓

Phenyl clorid chỉ phản ứng ở điều kiện **rất khắc nghiệt** (công nghiệp: trên 300 °C, áp suất cao; vì NaOH dùng dư nên thực tế thu **natri phenolat** C~6~H~5~ONa, acid hóa mới được phenol). Đây là ví dụ đầu tiên cho thấy Cl gắn vào vòng thơm **kém linh động**.

#### b) Thế bằng nhóm –NH~2~ → amin

=> CH~3~Cl + NH~3~ → CH~3~NH~2~ (methylamin) + HCl

=> C~6~H~5~Cl + 2 NH~3~ —(t°, Cu~2~Cl~2~)→ C~6~H~5~NH~2~ + NH~4~Cl

Sản phẩm thứ hai là **anilin**.

(HCl sinh ra sẽ kết hợp với amin/NH~3~ dư thành muối amoni; phương trình 2 đã viết theo cách đó.)

#### c) Thế bằng –CN và –OR — kéo dài mạch carbon, tạo ether

=> R–Cl + KCN → R–CN + KCl

=> R–CN + 2 H~2~O —(H^+^)→ R–COOH + NH~3~

R–CN là **nitril**. Nitril thủy phân thành **acid carboxylic dài hơn 1 C**. Ví dụ: isobutyl clorid → nitril → **acid 3-methyl butanoic** (acid isovaleric).

Thế bằng ion alcolat RO^−^ cho **ether** (Giáo trình tr. 111):

=> CH~3~–I + C~2~H~5~ONa → CH~3~–O–C~2~H~5~ + NaI

#### d) Hai cơ chế: S~N~2 và S~N~1 (nhắc lại Bài 4, Giáo trình tr. 112–114)

![Hình 1. Hai cơ chế thế nucleophil: S~N~2 (một giai đoạn, đảo cấu hình) và S~N~1 (qua carbocation)](sn1-sn2.svg)

| | **S~N~2** (lưỡng phân tử) | **S~N~1** (đơn phân tử) |
|---|---|---|
| Số giai đoạn | **1** giai đoạn, qua trạng thái chuyển tiếp | **2** giai đoạn, qua **carbocation** trung gian |
| Tốc độ | v = k[RX][Nu^−^] — bậc 2 | v = k[RX] — bậc 1 |
| Cách tấn công | Nu^−^ vào **từ phía sau** X | Nu^−^ vào carbocation phẳng **từ cả hai phía** |
| Lập thể (RX quang hoạt) | **Đảo cấu hình** | **Racemic** hóa |
| Thuận lợi cho | Halogen ở **C bậc I** (CH~3~X, RCH~2~X) | Halogen ở **C bậc III** (R~3~CX) — carbocation bền |
| C bậc II | Tùy dung môi: phân cực → S~N~1; kém phân cực → S~N~2 | |

**Vì sao bậc III đi theo S~N~1?** Ba nhóm alkyl đẩy electron (+I) làm **carbocation R~3~C^+^ bền**, đồng thời chúng "che chắn" phía sau C nên Nu^−^ khó chen vào theo kiểu S~N~2. Ngược lại CH~3~^+^ rất kém bền, nhưng CH~3~X lại thoáng, nên đi S~N~2. Độ bền carbocation: CH~3~^+^ < bậc I < bậc II < bậc III.

### 4.2. Độ linh động của halogen phụ thuộc vào gốc R

Đây là điểm trọng tâm của bài (Giáo trình tr. 136).

![Hình 2. Vì sao Cl trong vinyl clorid, phenyl clorid kém linh động: liên hợp p–π làm C–Cl ngắn và bền hơn](lien-hop.svg)

- Trong **ethyl clorid**, Cl gắn vào C **no (sp^3^)**: chỉ có **hiệu ứng cảm ứng −I**, liên kết C–Cl **phân cực mạnh** → Cl dễ bị thế.
- Trong **vinyl clorid** và **phenyl clorid**, Cl gắn vào C **chưa no (sp^2^)**. Cặp electron p của Cl **liên hợp** với electron π của nối đôi/vòng (hiệu ứng **+C**), **ngược chiều** với −I. Kết quả: C–Cl có một phần tính chất liên kết đôi, **ngắn và bền hơn**, momen lưỡng cực **nhỏ hơn** → Cl **kém linh động**.
- Trong **benzyl clorid** và **allyl clorid**, Cl gắn vào C no **kề** vòng thơm/nối đôi. Khi Cl^−^ tách ra, carbocation C~6~H~5~CH~2~^+^ hay CH~2~=CH–CH~2~^+^ được **liên hợp làm bền** (điện tích dương trải ra cả hệ π) → Cl **rất linh động**, còn hơn alkyl clorid thường.

| Dẫn xuất | Momen lưỡng cực (D) — Bảng 4, tr. 136 |
|---|---|
| CH~3~–CH~2~–Cl | 2,0 |
| CH~2~=CH–Cl | 1,44 |
| C~6~H~5~–Cl | 1,56 |

**Thứ tự khả năng phản ứng thế (thủy phân):**

**benzyl clorid ≈ allyl clorid > alkyl clorid (ethyl clorid) >> vinyl clorid ≈ phenyl clorid ≈ α-cloro propylen** (CH~3~–CH=CH–Cl)

**Theo bản chất halogen** (cùng gốc R): **R–I > R–Br > R–Cl >> R–F** (Giáo trình tr. 114). Nguyên tử X càng lớn, liên kết C–X càng dài, càng yếu, X^−^ càng dễ tách.

> [!vi-du] Nhận biết bằng AgNO~3~ (mở rộng, rất hay dùng trong thực hành)
> Khi R–X bị thủy phân, X^−^ được giải phóng và tạo kết tủa với AgNO~3~: AgCl **trắng**, AgBr **vàng nhạt**, AgI **vàng**.
> - **Benzyl/allyl clorid**: có kết tủa **ngay ở nhiệt độ thường**.
> - **Alkyl clorid** (ethyl clorid…): có kết tủa **khi đun nóng**.
> - **Phenyl/vinyl clorid**: **không có kết tủa** kể cả khi đun.
> Đây chính là cách trả lời các câu "so sánh khả năng thủy phân" bằng thực nghiệm.

> [!bay]
> - **Hai phản ứng của phenyl clorid với NaOH và NH~3~ trong sách có ghi "t°" (và Cu~2~Cl~2~)** — đó là dấu hiệu chúng khó xảy ra. Đừng cho rằng C~6~H~5~Cl thủy phân dễ như C~2~H~5~Cl.
> - Hiệu ứng **+C** của Cl không mạnh hơn **−I**; nó chỉ **làm giảm** độ phân cực của C–Cl. Vì vậy C~6~H~5~Cl vẫn có momen lưỡng cực (1,56 D), chỉ nhỏ hơn C~2~H~5~Cl (2,0 D).

### 4.3. Phản ứng tách hydrohalid — quy tắc Zaitsev

Đun R–X với **KOH trong ethanol** (kiềm đặc, dung môi alcol, nhiệt độ cao), phân tử **mất HX** — H ở carbon **bên cạnh** (C~β~) cùng X ở C~α~ — tạo **alken** (Giáo trình tr. 118):

=> C~2~H~5~Br + KOH —(ethanol, t°)→ C~2~H~4~ + KBr + H~2~O

Dẫn xuất bậc I thường chỉ cho **một** alken. Dẫn xuất bậc II, bậc III có thể tách theo hai, ba hướng:

![Hình 3. Tách HBr khỏi 2-bromo butan: sản phẩm chính theo quy tắc Zaitsev](zaitsev.svg)

Với **2-bromo butan** CH~3~–CH~2~–CHBr–CH~3~ (KOH/ethanol, t°):

=> → CH~3~–CH=CH–CH~3~ (but-2-en): **81%**

=> → CH~2~=CH–CH~2~–CH~3~ (but-1-en): 19%

> [!ghi-nho] Quy tắc Zaitsev (sách viết Zaicev)
> Khi tách HX, X tách ra chủ yếu **cùng với H của carbon bậc cao hơn** (C bên cạnh có **ít H hơn**), tạo **alken có nhiều nhóm thế hơn** ở hai C mang nối đôi — alken này **bền hơn**.
> Mẹo nhớ: "**nghèo càng nghèo thêm**" — C nào ít H thì bị lấy mất H.
> Ngược lại, với nhóm rời đi **mang điện dương, cồng kềnh** (–N^+^R~3~…) thì sản phẩm chính là alken **ít nhóm thế** nhất — **quy tắc Hofmann** (tr. 119).

> [!bay] Thế hay tách? — xem điều kiện phản ứng
> | Điều kiện | Hướng chính | Sản phẩm |
> |---|---|---|
> | NaOH/KOH **trong nước**, đun nhẹ | **Thế** (S~N~) | Alcol |
> | KOH **trong ethanol**, đun nóng | **Tách** (E) | Alken |
>
> Hai phản ứng luôn **cạnh tranh** nhau. Dẫn xuất **bậc III** dễ bị tách nhất: thực tế (CH~3~)~3~C–Cl gặp kiềm mạnh, nóng cho nhiều **isobutylen** (CH~3~)~2~C=CH~2~. Tuy vậy khi đề hỏi "thủy phân tert-butyl clorid bằng NaOH" (câu 6.4), trả lời theo sách: tạo **alcol tert-butylic** theo **S~N~1**; ethyl clorid tạo ethanol theo **S~N~2**.

### 4.4. Phản ứng với kim loại

#### a) Với natri — phản ứng Wurtz

Trong **ether khan**, Na lấy halogen của hai phân tử R–X và "nối" hai gốc lại (Giáo trình tr. 136):

=> R–X + 2 Na + X–R′ → R–R′ + 2 NaX

=> 2 C~2~H~5~Br + 2 Na → C~4~H~10~ (butan) + 2 NaBr

Áp dụng cho một dẫn xuất thơm và một dẫn xuất béo (biến thể **Wurtz–Fittig**) để điều chế **alkyl benzen**:

=> C~6~H~5~Br + 2 Na + CH~3~Br → C~6~H~5~CH~3~ + 2 NaBr

Sản phẩm là **toluen**.

#### b) Với magnesi — thuốc thử Grignard

Trong **ether khan**, R–X tác dụng với Mg tạo **cơ magnesi** R–Mg–X, gọi là **thuốc thử Grignard** (Giáo trình tr. 137):

=> C~2~H~5~Br + Mg —(ether khan)→ C~2~H~5~MgBr

=> C~6~H~5~Br + Mg —(ether khan)→ C~6~H~5~MgBr

Hai sản phẩm là ethyl magnesi bromid và phenyl magnesi bromid.

**Vì sao Grignard mạnh?** Trong R–X, carbon mang δ+. Khi Mg chen vào giữa, liên kết C–Mg phân cực **ngược lại**: C mang **δ−** (Mg kém âm điện hơn C nhiều). Carbon trở thành một **nucleophil rất mạnh**, như một "carbanion". Nó tấn công C^δ+^ của nhóm **carbonyl** — cách quan trọng để **tạo liên kết C–C** và điều chế alcol (sẽ học ở Bài 7, 8):

| R–Mg–X + … | Sau khi thủy phân thu được |
|---|---|
| HCHO (aldehyd formic) | Alcol **bậc I** R–CH~2~OH |
| Aldehyd khác R′CHO | Alcol **bậc II** |
| Ceton | Alcol **bậc III** |
| CO~2~ | Acid carboxylic R–COOH |

> [!bay] Vì sao phải dùng ether **khan**?
> Grignard là base rất mạnh: gặp **nước** (hay alcol, acid) nó lập tức bị phá hủy thành hydrocarbon: R–MgX + H~2~O → R–H + Mg(OH)X. Một chút ẩm cũng làm hỏng phản ứng.

## 5. Điều chế

Hai phương pháp chung (Giáo trình tr. 137):

### 5.1. Cho halogen (hoặc HX) tác dụng trực tiếp với hydrocarbon

- **Thế** halogen vào **alkan** (chiếu sáng, cơ chế gốc S~R~) và vào **vòng thơm** (xúc tác Fe/FeBr~3~, cơ chế S~E~):

=> C~2~H~6~ + Cl~2~ —(as)→ C~2~H~5~Cl + HCl

=> C~6~H~6~ + Br~2~ —(Fe, t°)→ C~6~H~5~Br + HBr

- **Cộng** HX hoặc X~2~ vào **hydrocarbon chưa no** (cộng HX theo quy tắc Markovnikov):

=> CH~2~=CH~2~ + HCl → CH~3~–CH~2~Cl

=> CH~3~–CH=CH~2~ + HBr → CH~3~–CHBr–CH~3~

### 5.2. Đi từ alcol

Thay nhóm –OH bằng halogen, dùng HX (kèm **chất hút nước**: H~2~SO~4~ đặc, CaCl~2~ khan hoặc ZnCl~2~) hoặc phospho halid (PCl~5~):

=> R–OH + HCl → R–Cl + H~2~O

=> R–OH + PCl~5~ → R–Cl + POCl~3~ + HCl

Phương pháp từ alcol hay dùng để điều chế dẫn xuất halogen **không vòng**.

> [!vi-du] Câu 6.7 — hai cách điều chế C~2~H~5~Cl
> - Từ ethylen: CH~2~=CH~2~ + HCl → C~2~H~5~Cl.
> - Từ ethanol: C~2~H~5~OH + HCl —(ZnCl~2~ khan)→ C~2~H~5~Cl + H~2~O (hoặc dùng PCl~5~).
> - (Thêm) Từ ethan: C~2~H~6~ + Cl~2~ —(as)→ C~2~H~5~Cl + HCl, nhưng tạo hỗn hợp sản phẩm.

## 6. Ứng dụng và ý nghĩa y học

### 6.1. Làm thuốc (Giáo trình tr. 137–138)

| Chất | Tính chất | Dùng làm |
|---|---|---|
| **Ethyl clorid** C~2~H~5~Cl | Khí, dễ hóa lỏng, **bay hơi rất nhanh** (t~s~ = 12,2 °C) | **Gây tê tại chỗ** bằng lạnh |
| **Cloroform** CHCl~3~ | Lỏng, không màu, mùi đặc biệt | **Thuốc mê** (theo sách) |
| **Iodoform** CHI~3~ | Tinh thể **vàng nhạt**, mùi hắc | **Sát trùng** |

**Vì sao ethyl clorid gây tê?** Phun lên da, chất lỏng bay hơi tức thì và **thu nhiệt** mạnh, làm lạnh vùng da xuống rất thấp. Lạnh làm các đầu dây thần kinh cảm giác tạm ngừng dẫn truyền. Đây là gây tê **bề mặt, ngắn hạn**.

> [!ung-dung] Ethyl clorid ngày nay
> Bình xịt ethyl clorid vẫn được dùng để **làm lạnh – giảm đau tức thời** trước khi tiêm, chích rạch nhỏ, và trong chấn thương thể thao. Lưu ý: chất **rất dễ cháy**; xịt quá lâu có thể gây **bỏng lạnh**; không xịt vào mắt, niêm mạc; hít phải gây ức chế thần kinh trung ương.

> [!cap-nhat] Cloroform không còn là thuốc mê
> Giáo trình ghi cloroform "được dùng làm thuốc mê". Hiện nay cloroform **đã bị loại bỏ** khỏi gây mê vì **độc gan, độc thận** và gây **loạn nhịp tim**. Trong gan, cloroform bị oxy hóa thành **phosgen** (COCl~2~) rất độc. Cloroform để ngoài ánh sáng và không khí cũng tự oxy hóa:
>
> => 2 CHCl~3~ + O~2~ —(as)→ 2 COCl~2~ + 2 HCl
>
> Vì vậy cloroform phải đựng **chai màu nâu, đầy, kín**, thêm khoảng 1% ethanol làm chất ổn định. Ngày nay cloroform chỉ còn là **dung môi** trong phòng thí nghiệm (chiết alkaloid…). **Carbon tetraclorid** CCl~4~ cũng rất độc gan (dùng để gây tổn thương gan trên động vật thí nghiệm).
>
> **Thuốc mê đường hô hấp hiện dùng** vẫn là hợp chất chứa halogen, nhưng giàu **flo**:
> - **Halothan** CF~3~–CHBrCl (2-bromo-2-cloro-1,1,1-trifluoro ethan) — đúng là dẫn xuất halogen của hydrocarbon; nay ít dùng vì hiếm gặp nhưng nặng **viêm gan do halothan** và gây loạn nhịp.
> - **Isofluran, sevofluran, desfluran** — thực chất là **ether** chứa halogen. **Sevofluran** (CF~3~)~2~CH–O–CH~2~F không mùi hắc, khởi mê êm, rất hay dùng ở trẻ em.
>
> Vì sao giàu F lại an toàn hơn? Liên kết **C–F rất bền** (F kém linh động nhất: I > Br > Cl >> F), nên các thuốc này **ít bị gan chuyển hóa**. Halothan bị chuyển hóa khoảng 20%, sevofluran chỉ vài phần trăm → ít sinh chất độc cho gan.

> [!cap-nhat] Iodoform
> Iodoform giải phóng iod chậm khi tiếp xúc dịch vết thương nên có tác dụng sát khuẩn. Hiện nay nó chủ yếu còn dùng trong **nha khoa** (bột hoặc bột nhão chứa iodoform để trám, sát khuẩn ống tủy) và gạc tẩm iodoform; ngoài ra đa số đã được thay bằng **povidon-iod**. Ở bài sau (alcol, ceton) sẽ gặp **phản ứng iodoform**: chất có nhóm CH~3~–CO– hoặc CH~3~–CHOH– + I~2~/NaOH cho **kết tủa vàng CHI~3~** — dùng để nhận biết ethanol, aceton.

### 6.2. Dẫn xuất halogen trong tự nhiên — thyroxin

Trong tự nhiên rất ít gặp dẫn xuất halogen. Ví dụ quan trọng nhất là **hormon tuyến giáp**:

- **Thyroxin** (T~4~): khung **2 vòng benzen nối qua cầu –O–**, mang **4 nguyên tử iod** (2 ở mỗi vòng), một nhóm –OH phenol và một mạch nhánh **amino acid** (acid amin) –CH~2~–CH(NH~2~)–COOH (Giáo trình tr. 138).
- Thyroxin có C\* nên có đồng phân quang học. Dạng **tự nhiên quay trái** (L-thyroxin) có hoạt tính mạnh gấp **khoảng 3 lần** dạng quay phải (theo sách).
- Thyroxin được dùng chữa **suy giáp** (thiểu năng giáp trạng) và **bướu cổ**.

> [!cap-nhat] Thyroxin — vài điểm sách đã cũ
> - Giáo trình ghi "năm 1914 **Kjeldahl** chiết được thyroxin". Người phân lập thyroxin năm 1914 là **Edward C. Kendall** (Mỹ); Kjeldahl là nhà hóa học Đan Mạch nổi tiếng với phương pháp định lượng nitơ.
> - Hormon thứ hai mà sách gọi "3,5-diiodo thyroxin" là cách gọi cũ, không rõ ràng. Hormon giáp thứ hai quan trọng hiện được biết là **triiodothyronin (T~3~**, 3,5,3′-triiodothyronin, tìm ra năm 1952), có 3 iod, hoạt tính **mạnh hơn T~4~** (T~4~ được khử bớt một iod thành T~3~ ở mô).
> - Thuốc hiện dùng là **levothyroxin** (dạng L tinh khiết), **không phải** dạng racemic như sách ghi.
> - Sách ghi thyroxin dùng chữa "béo phì": **hiện nay không được dùng** hormon giáp để giảm cân ở người chức năng giáp bình thường — liều cao gây cường giáp, loạn nhịp, loãng xương, có thể nguy hiểm tính mạng.

> [!yhct] Hải tảo, Côn bố và bướu cổ — liên hệ có cơ sở với iod
> Tuyến giáp cần **iod** để tổng hợp thyroxin; thiếu iod gây **bướu cổ đơn thuần**. YHCT từ lâu dùng **Hải tảo** (rong mơ, *Sargassum*) và **Côn bố** (tảo bẹ, *Laminaria*) để trị "anh lựu" (bướu cổ) — hai vị này **giàu iod**, nên công dụng với bướu cổ **do thiếu iod** có cơ sở hóa học rõ ràng.
> Thận trọng: thừa iod có thể **làm nặng thêm cường giáp (Basedow)** hoặc viêm giáp tự miễn; người có bệnh tuyến giáp cần xét nghiệm, chẩn đoán trước khi dùng. Theo "thập bát phản", **Hải tảo phản Cam thảo**.

### 6.3. Dẫn xuất halogen thơm là chất độc (Giáo trình tr. 138)

- **Benzyl clorid, bromid, iodid** (C~6~H~5~CH~2~X): gây **cay và chảy nước mắt** mạnh, từng được dùng làm **chất độc chiến tranh**; theo sách benzyl iodid độc nhất. Nguyên nhân: nhóm benzyl-X **rất linh động** (mục 4.2), dễ phản ứng (alkyl hóa) với protein của niêm mạc mắt.
- **DDT** — p,p′-dicloro diphenyl tricloro ethan, tên IUPAC: 1,1,1-tricloro-2,2-bis(4-clorophenyl) ethan, (Cl–C~6~H~4~)~2~CH–CCl~3~. Bột kết tinh không màu, **không tan trong nước** nhưng **tan trong aceton, ether, dầu thực vật**; trước đây là thuốc trừ sâu, rệp phổ biến. Là **chất độc thần kinh**.

> [!cap-nhat] DDT và nhóm "cơ clo" ngày nay
> - DDT rất **bền**, tan trong mỡ nên **tích lũy sinh học** trong mô mỡ và chuỗi thức ăn. Theo **Công ước Stockholm** (2001), DDT bị cấm dùng trong nông nghiệp trên toàn cầu; WHO chỉ còn cho phép phun tồn lưu trong nhà để **phòng chống sốt rét** ở nơi chưa có giải pháp thay thế.
> - Hợp chất **hexacloro cyclohexan** (C~6~H~6~Cl~6~, "666"; đồng phân γ là **lindan**) từng dùng trừ sâu và làm thuốc trị ghẻ, chấy; nay bị hạn chế nghiêm ngặt vì độc thần kinh.
> - Dược liệu có thể nhiễm **dư lượng thuốc bảo vệ thực vật cơ clo**; các dược điển (trong đó có Dược điển Việt Nam) có phép thử và giới hạn cho các chất này. Mua dược liệu cần có nguồn gốc, kiểm nghiệm rõ ràng.

### 6.4. Mở rộng — CFC và tầng ozon; PVC

> [!ung-dung] CFC (freon) — vì sao bị cấm?
> **CFC** (cloro fluoro carbon) như CCl~2~F~2~ (freon-12), CCl~3~F (freon-11): rất bền, không độc, không cháy, nên từng được dùng làm chất làm lạnh, chất đẩy bình xịt — kể cả **bình xịt hen (MDI)**. Bay lên tầng bình lưu, tia tử ngoại cắt C–Cl tạo **gốc Cl•**. Gốc này phá ozon theo **dây chuyền** (cơ chế gốc như ở Bài 4):
>
> => Cl• + O~3~ → ClO• + O~2~
>
> => ClO• + O → Cl• + O~2~
>
> Một gốc Cl• có thể phá hàng chục nghìn phân tử O~3~. Tầng ozon mỏng đi → tăng tia UV → tăng **ung thư da, đục thủy tinh thể**. **Nghị định thư Montreal** (1987) loại bỏ CFC; bình xịt hen chuyển sang chất đẩy **HFA** (hydrofluoroalkan, không chứa Cl) — nay đang tiếp tục chuyển sang chất đẩy ít gây hiệu ứng nhà kính hơn.

> [!ung-dung] Vinyl clorid và PVC
> **Vinyl clorid** CH~2~=CH–Cl trùng hợp thành **PVC** — vật liệu túi máu, dây truyền dịch, ống y tế. Bản thân monome vinyl clorid là chất **gây ung thư** (ung thư mạch máu gan ở công nhân tiếp xúc).

> [!vi-du] Nhiều thuốc hiện đại chứa halogen
> Gắn F, Cl vào phân tử thuốc làm thay đổi độ tan trong lipid, độ bền chuyển hóa và ái lực với đích tác dụng: **5-fluorouracil** (chống ung thư), **ciprofloxacin** (kháng sinh nhóm fluoroquinolon), **cloramphenicol**, **diazepam** (chứa Cl), **fluoxetin**… Lưu ý: đó là những phân tử nhiều nhóm chức, không phải "dẫn xuất halogen của hydrocarbon" đơn thuần.

## 7. Giải câu hỏi tự lượng giá (Giáo trình tr. 138–139)

*Phần "Hướng dẫn trả lời" cuối sách không có đáp án cho Bài 6; các đáp án dưới đây do người soạn đưa ra, có đối chiếu với đáp án Bài 4 (4.2) và Bài 7 (7.8, 7.11).*

> [!vi-du] 6.1 — Gọi tên IUPAC
> - a) Đề in "CH~2~=CH–CH~2~=CH–Cl" là **công thức sai** (C thứ ba có 5 liên kết). Nếu ý đề là CH~2~=CH–CH=CH–Cl thì tên là **1-cloro buta-1,3-dien**.
> - b) CH~3~–CH~2~–CH~2~–Cl: **1-cloro propan** (propyl clorid).
> - c) Cl–C~6~H~4~–Cl (para): **1,4-dicloro benzen**.
> - d) C~6~H~5~–CH~2~Cl: **(cloro methyl) benzen** (benzyl clorid).

> [!vi-du] 6.2 — Viết công thức
> a) tert-butyl bromid: (CH~3~)~3~C–Br · b) 1,2-dicloro benzen: hai Cl ở vị trí ortho · c) 2,3-dibromo-3-ethyl heptan: CH~3~–CHBr–CBr(C~2~H~5~)–CH~2~–CH~2~–CH~2~–CH~3~ · d) vinyl clorid: CH~2~=CH–Cl · e) hexacloro cyclohexan: C~6~H~6~Cl~6~ (mỗi C của vòng mang 1 H, 1 Cl) · f) 1-bromo-2-iodo cyclobuten: vòng 4 cạnh, nối đôi C1=C2, Br ở C1, I ở C2.

> [!vi-du] 6.3 – 6.6, 6.8, 6.9 — Ý chính
> - **6.3**: C~2~H~5~Cl thủy phân **dễ hơn** CH~2~=CHCl; C~6~H~5~CH~2~Cl **dễ hơn nhiều** C~6~H~5~Cl; C~6~H~5~CH~2~Cl **≈** CH~2~=CH–CH~2~Cl (đều rất linh động). Giải thích bằng liên hợp p–π và độ bền carbocation (mục 4.2).
> - **6.4**: (CH~3~)~3~C–Cl + NaOH → (CH~3~)~3~C–OH + NaCl theo **S~N~1**; C~2~H~5~Cl + NaOH → C~2~H~5~OH + NaCl theo **S~N~2**. Khác nhau do bậc của C mang Cl.
> - **6.5**: isobutyl clorid (CH~3~)~2~CH–CH~2~Cl + AgOH → isobutyl alcol + AgCl↓; + KCN → (CH~3~)~2~CH–CH~2~–CN, thủy phân → (CH~3~)~2~CH–CH~2~–COOH (acid 3-methyl butanoic).
> - **6.6**: 2 C~2~H~5~Br + 2 Na → C~4~H~10~ + 2 NaBr; C~2~H~5~Br + Mg → C~2~H~5~MgBr — tên chung **thuốc thử Grignard** (hợp chất cơ magnesi).
> - **6.8**: anilin: C~6~H~5~Cl + 2 NH~3~ —(t°, Cu~2~Cl~2~)→ C~6~H~5~NH~2~ + NH~4~Cl; toluen: C~6~H~5~Br + 2 Na + CH~3~Br → C~6~H~5~CH~3~ + 2 NaBr.
> - **6.9**: CHCl~3~ — thuốc mê (cũ); CHI~3~ — sát trùng; C~6~H~5~CH~2~Cl — chất gây chảy nước mắt (độc).

## Tóm tắt

| Chủ đề | Điểm cần nhớ |
|---|---|
| Định nghĩa | Thay H của hydrocarbon bằng halogen → R–X |
| Phân loại | Béo / thơm; mono- / polyhalogen; bậc I, II, III |
| Danh pháp | IUPAC: **cloro ethan**; thông thường: **ethyl clorid** |
| Vật lý | Không tan trong nước, tan trong dung môi hữu cơ; t~s~ tăng theo M; polyclo nặng hơn nước |
| Bản chất | C^δ+^–X^δ−^ → **thế nucleophil** là phản ứng đặc trưng |
| Thế –OH, –NH~2~, –CN, –OR | Alcol, amin, nitril (+1 C), ether; cần kiềm để đẩy cân bằng |
| Cơ chế | Bậc I → **S~N~2** (đảo cấu hình); bậc III → **S~N~1** (carbocation, racemic) |
| Độ linh động | benzyl ≈ allyl > alkyl >> vinyl ≈ phenyl; I > Br > Cl >> F |
| Tách HX | KOH/ethanol, t° → alken; **Zaitsev**: H tách ở C bậc cao hơn |
| Kim loại | Na → R–R′ (Wurtz); Mg/ether khan → **R–Mg–X (Grignard)** |
| Điều chế | Hydrocarbon + X~2~/HX (thế, cộng); alcol + HX hoặc PCl~5~ |
| Y học | Ethyl clorid (gây tê lạnh), cloroform (mê – nay bỏ, độc gan), iodoform (sát trùng), thyroxin (hormon giáp, 4 I), benzyl halid (chảy nước mắt), DDT (độc thần kinh, đã cấm) |
