---
title: Các nguyên tố kim loại khối d (chuyển tiếp)
thoi-gian: 45 phút
muc-tieu:
- Xác định được vị trí của kim loại khối d trong bảng tuần hoàn và đặc điểm cấu hình electron hóa trị (n−1)d ns của chúng, kể cả các trường hợp ngoại lệ.
- Trình bày được tính chất hóa học chính của các kim loại nhóm VIIIB (họ sắt), IB, IIB, VIB và VIIB.
- Viết được phương trình (đã cân bằng) của các phản ứng và hợp chất tiêu biểu: oxide, hydroxide, muối, phức chất.
- Kể được ứng dụng và vai trò sinh học, độc tính của đơn chất và hợp chất các kim loại trên; liên hệ thuốc giải độc kim loại và khoáng dược YHCT.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Kim loại khối d nằm **giữa khối s và khối p**, electron hóa trị ở **(n−1)d^1–10^ ns^1–2^**. Hai phân mức này có năng lượng gần nhau nên kim loại d có **nhiều số oxy hóa** và **dễ tạo phức** (còn orbital d trống).
> 2. **Họ sắt (VIIIB)**: Fe +2, +3. Fe^2+^ dễ bị oxy hóa thành Fe^3+^. Fe là trung tâm của **hemoglobin** (Fe^2+^) và cytochrom (Fe^2+^ ⇌ Fe^3+^); Co nằm trong **vitamin B~12~**.
> 3. **IB (Cu, Ag, Au)**: cũng có 1 electron ngoài cùng như kim loại kiềm nhưng **tính khử yếu hơn rất nhiều**; chỉ tan trong acid có tính oxy hóa (Au chỉ tan trong **nước cường toan**). Ag^+^ diệt khuẩn.
> 4. **IIB (Zn, Cd, Hg)**: d^10^ bền, chỉ có số oxy hóa **+2** (Hg còn **Hg~2~^2+^**). Zn và Zn(OH)~2~ **lưỡng tính**; Zn cần cho enzym; **Hg, Cd rất độc**.
> 5. **Cr (VIB)** bền ở +3 và +6, cặp **CrO~4~^2−^ (vàng) ⇌ Cr~2~O~7~^2−^ (da cam)** theo pH. **Mn (VIIB)** +2, +4, +7; **KMnO~4~** oxy hóa mạnh, sản phẩm khử tùy môi trường: Mn^2+^ (acid), MnO~2~ (trung tính), MnO~4~^2−^ (kiềm).

## 1. Khái quát về kim loại chuyển tiếp

### 1.1. Vị trí và cấu hình electron

Ở bảng tuần hoàn dạng dài, khối d là "cây cầu" nối khối s (IA, IIA) với khối p (IIIA–VIIIA). Ví dụ ở chu kỳ 4: sau K, Ca là 10 nguyên tố d từ **Sc đến Zn**, rồi mới đến Ga (khối p). Khối d gồm các nhóm phụ (nhóm B) từ IIIB đến IIB. Giáo trình xét kỹ 5 nhóm: **VIIIB, IB, IIB, VIB, VIIB** (tr. 26).

Electron hóa trị có dạng **(n−1)d^1–10^ ns^1–2^**: electron mới thêm vào lớp **sát ngoài** (n−1)d, còn lớp ngoài cùng ns chỉ có 1–2 electron. Vì lớp ngoài cùng ít electron, tất cả nguyên tố d đều là **kim loại**.

![Hình 1. Kim loại khối d chu kỳ 4 — cấu hình electron hóa trị và số oxy hóa thường gặp](cau-hinh-d.svg)

**Các ngoại lệ phải thuộc** (giáo trình tr. 26):

| Kiểu | Nguyên tố | Cấu hình hóa trị | Vì sao |
|---|---|---|---|
| (n−1)d^10^ ns^1^ | Cu, Ag, Au | 3d^10^ 4s^1^ (Cu) | Phân mức d **bão hòa** (10e) bền hơn, nên 1 electron s "nhảy" sang d |
| (n−1)d^5^ ns^1^ | Cr, Mo | 3d^5^ 4s^1^ (Cr) | Phân mức d **bán bão hòa** (5e, mỗi orbital 1e) bền |
| 4d^10^ 5s^0^ | Pd | 4d^10^ | d bão hòa hoàn toàn, lớp 5s trống |

> [!bay]
> - Viết Cr là 3d^4^ 4s^2^ hay Cu là 3d^9^ 4s^2^ là **sai**. Đúng: Cr 3d^5^ 4s^1^, Cu 3d^10^ 4s^1^.
> - Khi tạo ion, kim loại d **mất electron ns trước**, rồi mới đến (n−1)d. Ví dụ Fe (3d^6^ 4s^2^) → Fe^2+^ là **3d^6^** (không phải 3d^4^ 4s^2^); Fe^3+^ là 3d^5^.
> - Đáp án tự lượng giá 3.1 của giáo trình ghi "từ chu kỳ **3** trở đi" là in nhầm: nguyên tố d đầu tiên (Sc) ở **chu kỳ 4**.

### 1.2. Vì sao nhiều số oxy hóa và dễ tạo phức?

- **Nhiều số oxy hóa:** năng lượng của (n−1)d và ns **xấp xỉ nhau**. Nguyên tử có thể nhường 2 electron s, rồi nhường thêm một số electron d tùy chất phản ứng. Ví dụ Mn có thể từ +2 đến +7, Cr từ +2 đến +6.
- **Dễ tạo phức:** ion kim loại d có điện tích lớn, bán kính nhỏ và còn **orbital d (cùng s, p) trống**. Các orbital trống này nhận cặp electron của **phối tử** (NH~3~, CN^−^, H~2~O, Cl^−^, CO…) để tạo liên kết phối trí.

> [!cap-nhat] Khối d và "kim loại chuyển tiếp" không hoàn toàn trùng nhau
> Giáo trình dùng hai tên này như nhau. Theo IUPAC hiện nay, **nguyên tố chuyển tiếp** là nguyên tố mà nguyên tử hoặc ion thường gặp của nó có **phân mức d chưa đầy**. Zn, Cd, Hg có d^10^ ở cả nguyên tử lẫn ion M^2+^, nên thường **không** được coi là kim loại chuyển tiếp "thực thụ", dù vẫn thuộc khối d. Điều này giải thích vì sao chúng chỉ có một số oxy hóa (+2) và hợp chất thường không màu. Đi thi vẫn theo cách gọi của giáo trình.

### 1.3. Tính chất chung (tr. 27)

- **Vật lý:** mạng tinh thể đặc khít nên thường có **nhiệt độ nóng chảy, nhiệt độ sôi cao, khối lượng riêng lớn** hơn kim loại khác (ngoại lệ nổi bật: Hg lỏng ở nhiệt độ thường).
- **Bền với oxy và nước** ở điều kiện thường (hơn hẳn kim loại kiềm, kiềm thổ).
- **Au, Ag, Cu, Hg, Pt** có thế điện cực chuẩn **dương** (đứng sau H), nên **không** tác dụng với acid thường (HCl, H~2~SO~4~ loãng).
- Hầu hết tác dụng được với **acid có tính oxy hóa** (H~2~SO~4~ đặc, HNO~3~). Sản phẩm khử tùy kim loại và điều kiện: với H~2~SO~4~ có thể là SO~2~, S, thậm chí S^2−^ (H~2~S); với HNO~3~ có thể là NO~2~, NO, N~2~O, N~2~, NH~4~^+^.
- **Au** chỉ tan trong **nước cường toan** (HCl đặc : HNO~3~ đặc = 3 : 1):

=> Au + 3HCl + HNO~3~ → AuCl~3~ + NO↑ + 2H~2~O

### 1.4. Phức chất — hình học theo kiểu lai hóa

Giáo trình giải thích cấu trúc phức bằng **thuyết liên kết hóa trị (VB)**: các orbital trống của ion trung tâm lai hóa, mỗi orbital lai hóa nhận một cặp electron của phối tử. Kiểu lai hóa quyết định hình học. Bảng dưới gom các phức chất được nêu rải rác trong bài.

![Hình 2. Hình học phức chất theo kiểu lai hóa (thuyết VB)](phuc-chat.svg)

| Lai hóa | Số phối trí | Hình học | Ví dụ trong giáo trình |
|---|---|---|---|
| sp^3^ | 4 | **Tứ diện** | [Zn(NH~3~)~4~]^2+^, [CoCl~4~]^2−^ |
| dsp^2^ | 4 | **Vuông phẳng** | [Ni(CN)~4~]^2−^, [Au(CN)~4~]^−^, [Cu(NH~3~)~4~]^2+^ |
| dsp^3^ | 5 | Lưỡng tháp tam giác | Fe(CO)~5~ |
| d^2^sp^3^ (lai hóa **trong**) | 6 | **Bát diện** | [Fe(CN)~6~]^3−^, [Fe(CN)~6~]^4−^ |
| sp^3^d^2^ (lai hóa **ngoài**) | 6 | **Bát diện** | [Ni(H~2~O)~6~]^2+^ |

**Vì sao cùng là Ni^2+^ mà khi vuông phẳng, khi bát diện?** CN^−^ là **phối tử mạnh**: nó "ép" các electron d của ion trung tâm ghép đôi, giải phóng một orbital (n−1)d trống để lai hóa **trong** (dsp^2^, d^2^sp^3^). H~2~O, Cl^−^ là phối tử yếu, không ép được, nên ion phải dùng orbital **nd ngoài** (sp^3^d^2^) hoặc chỉ dùng s, p (sp^3^).

> [!vi-du] Đọc ô lượng tử của [Fe(CN)~6~]^3−^ (tr. 29)
> Fe^3+^: 3d^5^. Không có phối tử, 5 electron nằm riêng trong 5 orbital d. Với 6 CN^−^ (phối tử mạnh), 5 electron dồn vào **3 orbital d** (2 cặp + 1 electron độc thân), để trống **2 orbital 3d**. Hai orbital 3d này cùng 4s và ba 4p lai hóa **d^2^sp^3^** → 6 orbital hướng về 6 đỉnh bát diện, mỗi orbital nhận một cặp electron của CN^−^. Tên phức K~3~[Fe(CN)~6~]: **kali hexacyanoferat(III)**.

## 2. Nhóm VIIIB — họ sắt: Fe, Co, Ni

### 2.1. Đặc điểm

- Cấu hình hóa trị: **Fe 3d^6^ 4s^2^, Co 3d^7^ 4s^2^, Ni 3d^8^ 4s^2^**.
- Dễ mất 2 electron 4s và một số electron 3d nên là kim loại **khá hoạt động** (đứng trước H).
- Số oxy hóa thường gặp: **Fe và Co: +2, +3; Ni: +2**.

> [!bay] Giáo trình in nhầm (tr. 27)
> Sách in "số oxy hóa thường gặp của Fe và Co là **−2**, +3". Đúng là **+2, +3**. Kim loại không có số oxy hóa âm trong hợp chất thông thường.

**Vì sao Fe^2+^ dễ bị oxy hóa thành Fe^3+^?** Fe^3+^ có cấu hình **3d^5^ (bán bão hòa)** — bền. Fe^2+^ (3d^6^) chỉ cần mất 1 electron là đạt cấu hình bền đó. Ngược lại, Co^3+^ và Ni^3+^ không có "lợi thế" này nên **kém bền**, có tính oxy hóa mạnh (mục 2.3).

### 2.2. Tính chất hóa học

**Với oxy.** Co, Ni khá bền; Fe phản ứng chậm ở nhiệt độ thường.

Nung đỏ thì tạo **oxide sắt từ** Fe~3~O~4~ (= FeO·Fe~2~O~3~); trong không khí ẩm thì tạo **gỉ sắt**:

=> 3Fe + 2O~2~ → Fe~3~O~4~

=> 4Fe + 3O~2~ + 2xH~2~O → 2Fe~2~O~3~·xH~2~O

> [!bay] Giáo trình in sai (tr. 27)
> Sách in phản ứng của Fe với oxy ở nhiệt độ thường là "6Fe + 4O~2~ → 2Fe~2~O~3~·FeO" — vế phải chỉ có **5** Fe. Viết đúng: **3Fe + 2O~2~ → Fe~3~O~4~** (Fe~3~O~4~ = FeO·Fe~2~O~3~).

**Với halogen, S, C.** Tạo muối **sắt(III)** halid nhưng Co(II), Ni(II) halid. Riêng I~2~ chỉ cho **FeI~2~** vì I~2~ oxy hóa yếu (Fe^3+^ còn oxy hóa ngược được I^−^). Với S khi đun nóng tạo sulfid MS. Với C ở nhiệt độ cao tạo carbid.

> [!bay]
> Giáo trình in carbid sắt là "FeC~3~". Công thức đúng của carbid sắt (cementit, thành phần của gang, thép) là **Fe~3~C**.

**Với nước** — Fe chỉ phản ứng ở trên 500 °C:

=> 3Fe + 4H~2~O (hơi) → Fe~3~O~4~ + 4H~2~↑

**Với CO** — tạo **phức carbonyl** (kim loại có số oxy hóa 0):

- **Fe(CO)~5~**: electron 4s dồn vào 3d (Fe 3d^8^), để trống 4s, 4p và một orbital 3d → lai hóa **dsp^3^**, phức **lưỡng tháp tam giác** (sách gọi là "lục diện", vì hình này có 6 mặt), **nghịch từ** (không còn electron độc thân).
- Giáo trình ghi Co(CO)~4~ lai hóa sp^3^, tứ diện. *Thực tế chất bền tách được là dạng đôi Co~2~(CO)~8~.*

**Với acid.**

- Acid thường: Fe tan dễ, Co và Ni tan chậm, **đều cho muối M^2+^**:

=> M + H~2~SO~4~ (loãng) → MSO~4~ + H~2~↑ (M = Fe, Co, Ni)

- H~2~SO~4~ đặc, HNO~3~ đặc **nguội**: bị **thụ động hóa** (lớp oxide mỏng, bền phủ bề mặt). Chỉ phản ứng khi **đun nóng**, và Fe lên **+3**:

=> 2Fe + 6H~2~SO~4~ (đặc, nóng) → Fe~2~(SO~4~)~3~ + 3SO~2~↑ + 6H~2~O

- HNO~3~ loãng hòa tan cả ba, nhưng **chỉ Fe cho muối +3**:

=> Fe + 4HNO~3~ (loãng) → Fe(NO~3~)~3~ + NO↑ + 2H~2~O

=> 3Ni + 8HNO~3~ (loãng) → 3Ni(NO~3~)~2~ + 2NO↑ + 4H~2~O

> [!bay] Giáo trình in thiếu hệ số (tr. 28 và tr. 38)
> Sách in "Fe + H~2~SO~4~ → Fe~2~(SO~4~)~3~ + SO~2~ + H~2~O" (tr. 28) và "2Fe + 4H~2~SO~4~ → …" (tr. 38). Cả hai chưa cân bằng. Đúng: **2Fe + 6H~2~SO~4~ → Fe~2~(SO~4~)~3~ + 3SO~2~ + 6H~2~O**. (Fe nhường 3e × 2 = 6e; S^+6^ nhận 2e → cần 3 SO~2~.)

### 2.3. Hợp chất

**Oxide.** Có các dạng MO, M~2~O~3~, M~3~O~4~; không tan trong nước, tan dễ trong acid.

**Hydroxide.** Fe(OH)~2~ (trắng xanh) để ngoài không khí **chuyển nhanh** thành Fe(OH)~3~ (nâu đỏ); Co(OH)~2~ chuyển chậm.

=> 4Fe(OH)~2~ + O~2~ + 2H~2~O → 4Fe(OH)~3~

Tất cả tan trong acid, nhưng hydroxide **Co(III), Ni(III)** khác Fe(III): chúng oxy hóa được HCl thành Cl~2~.

=> Fe(OH)~3~ + 3HCl → FeCl~3~ + 3H~2~O

=> 2Co(OH)~3~ + 6HCl → 2CoCl~2~ + Cl~2~↑ + 6H~2~O

→ Tính oxy hóa: **Co^3+^, Ni^3+^ > Fe^3+^**.

**Muối.** Clorid, nitrat, sulfat thường kết tinh **ngậm nước**, dễ tan. Màu đặc trưng: **Fe^2+^ xanh lục nhạt, Co^2+^ hồng, Ni^2+^ xanh lục đậm, Fe^3+^ vàng nâu**.

Hai muối kép của sắt:

| Muối | Công thức | Ghi chú |
|---|---|---|
| Phèn sắt amoni | NH~4~Fe(SO~4~)~2~·12H~2~O | Sắt(III) |
| **Muối Mohr** | FeSO~4~·(NH~4~)~2~SO~4~·6H~2~O | Fe^2+^ trong muối Mohr **rất bền** với không khí, còn muối Fe(II) khác bị oxy hóa dần thành Fe^3+^ → dùng làm **chất chuẩn** trong phân tích |

**Phức chất.** Fe^3+^, Fe^2+^, Co^3+^, Co^2+^, Ni^2+^ đều dễ tạo phức (xem bảng mục 1.4): [Fe(CN)~6~]^3−^ bát diện d^2^sp^3^; [CoCl~4~]^2−^ tứ diện sp^3^; [Ni(CN)~4~]^2−^ vuông phẳng dsp^2^; [Ni(H~2~O)~6~]^2+^ bát diện sp^3^d^2^.

> [!vi-du] Nhận biết Fe^3+^ và Fe^2+^ (bổ sung, hay gặp ở thực tập)
> - Fe^3+^ + SCN^−^ → phức **đỏ máu**.
> - Fe^3+^ + [Fe(CN)~6~]^4−^ → kết tủa **xanh Phổ** (Prussian blue). Fe^2+^ + [Fe(CN)~6~]^3−^ cũng cho kết tủa xanh đậm (xanh Turnbull).
> - Fe^2+^ + OH^−^ → Fe(OH)~2~ trắng xanh, hóa nâu đỏ ngoài không khí; Fe^3+^ + OH^−^ → Fe(OH)~3~ **nâu đỏ** ngay.
> - Xanh Phổ cũng là **thuốc giải độc** thallium và cesi phóng xạ (gắn ion trong ruột, cho thải qua phân).

### 2.4. Trạng thái thiên nhiên

Quặng sắt: **hematit Fe~2~O~3~, manhetit Fe~3~O~4~** (giàu sắt nhất, tới 72% Fe), xiderit FeCO~3~, pirit FeS~2~. Co và Ni có trong CoS~2~, CoAs, NiAs.

> [!bay]
> Giáo trình ghi hematit "chứa 60% Fe", xiderit và pirit "35% Fe". Đây là số liệu của **quặng** (có lẫn tạp chất). Tính theo công thức chất tinh khiết: Fe~2~O~3~ 70%, Fe~3~O~4~ 72,4%, FeCO~3~ 48%, FeS~2~ 47%. Đề hỏi "theo giáo trình" thì trả lời số của sách.

### 2.5. Ứng dụng và vai trò sinh học

- **Hợp kim:** theo hàm lượng carbon, giáo trình chia **sắt mềm** (< 0,2% C), **thép** (0,2–1,7% C), **gang** (1,7–5% C). Co, Ni tạo nhiều hợp kim quan trọng (thép không gỉ có Cr, Ni).
- **Hemoglobin** = globin (protein) + **hem**. Hem là **phức của Fe^2+^ với porphyrin**. Hemoglobin vận chuyển O~2~ từ phổi tới mô.
- **Cytochrom** và các enzym chuỗi hô hấp chứa sắt ở cả hai dạng **Fe^2+^ (khử) và Fe^3+^ (oxy hóa)**. Sắt chuyển qua lại giữa hai số oxy hóa để **chuyền electron** — đây là cơ sở của chức năng xúc tác oxy hóa – khử.
- **Ferrocen** Fe(C~5~H~5~)~2~ dùng làm chất xúc tác trong tổng hợp.
- Thuốc chữa thiếu máu chứa sắt (giáo trình nêu biệt dược Ferrochel, ghi là *ferroglycin sulfat*; thực chất là sắt(II) bisglycinat chelat).
- **Vitamin B~12~** (cobalamin) là **phức chất của coban**.

> [!ung-dung] Fe^2+^, Fe^3+^ và lâm sàng
> - **Hem phải giữ Fe^2+^ mới gắn được O~2~.** Một số chất (nitrit, một số thuốc như dapson, thuốc tê benzocain) oxy hóa Fe^2+^ của hem thành Fe^3+^ → **methemoglobin**, không chở được O~2~ → da tím tái. Thuốc giải là **xanh methylen**, giúp khử Fe^3+^ trở lại Fe^2+^.
> - **Thiếu máu thiếu sắt** (hay gặp nhất): hồng cầu nhỏ, nhược sắc; ferritin huyết thanh giảm. Sắt uống thường là **muối sắt(II)** (sulfat, fumarat, gluconat) vì ruột hấp thu Fe^2+^ tốt hơn Fe^3+^. **Vitamin C** giúp hấp thu (khử Fe^3+^ → Fe^2+^, tạo phức tan). Nên uống xa **trà** (tannin tạo phức với sắt), sữa, calci, thuốc kháng acid. Uống sắt làm phân đen.
> - **Ngộ độc sắt** ở trẻ nhỏ uống nhầm viên sắt có thể gây tử vong; thuốc giải là chất tạo phức **deferoxamin** (xem mục 7).
> - **Thiếu vitamin B~12~** gây thiếu máu hồng cầu to. Hydroxocobalamin (dạng B~12~ mà giáo trình nêu) còn là **thuốc giải độc cyanid**: Co trong phân tử gắn CN^−^ thành cyanocobalamin, thải qua nước tiểu.

## 3. Nhóm IB — Cu, Ag, Au

### 3.1. Đặc điểm

- Cấu hình hóa trị **(n−1)d^10^ ns^1^**. Đứng gần cuối dãy 10 nguyên tố d mỗi chu kỳ.
- **Giống IA:** lớp ngoài cùng có 1 electron, nên cũng có hợp chất hóa trị I.
- **Khác IA:** sát lớp ngoài có phân mức **d bão hòa (10e)**. Electron d **chắn điện tích hạt nhân kém**, nên electron ns bị hạt nhân hút mạnh hơn, bán kính nhỏ hơn, năng lượng ion hóa lớn hơn. Kết quả: **tính khử của IB yếu hơn IA rất nhiều** (thế điện cực chuẩn dương).
- Số oxy hóa đặc trưng: **Cu +2, Ag +1, Au +3**; ngoài ra Cu và Au còn có **+1**. Tất cả đều có khả năng tạo phức.

### 3.2. Tính chất hóa học

**Với phi kim.**

- Oxy: chỉ Cu phản ứng khi đốt nóng (khoảng 800 °C) tạo CuO đen; nung cao hơn nữa thành **Cu~2~O đỏ gạch**.

=> 2Cu + O~2~ → 2CuO

- Halogen: cả ba bị oxy hóa, nhanh hơn khi có hơi ẩm và nhiệt.
- Trong không khí ẩm có CO~2~, Cu phủ lớp **(CuOH)~2~CO~3~** màu xanh lá (**"gỉ đồng"**, giáo trình gọi là *tanh đồng*).

**Với acid.** Đứng sau H nên **không** đẩy được H~2~ khỏi HCl, H~2~SO~4~ loãng. Chỉ tan trong acid có tính oxy hóa:

=> Cu + 2H~2~SO~4~ (đặc, nóng) → CuSO~4~ + SO~2~↑ + 2H~2~O

=> Ag + 2HNO~3~ (đặc) → AgNO~3~ + NO~2~↑ + H~2~O

=> Au + HNO~3~ + 3HCl → AuCl~3~ + NO↑ + 2H~2~O (nước cường toan)

Nước clo (HCl + Cl~2~) cũng hòa tan vàng, tạo phức **H[AuCl~4~]**.

> [!bay]
> - Ở tr. 31 sách in "các nguyên tố nhóm **IA** chỉ tác dụng với acid có tính oxy hóa" — phải đọc là nhóm **IB**.
> - **Cu không tan trong HCl, H~2~SO~4~ loãng** khi không có chất oxy hóa. Nhưng nếu sục **không khí** vào H~2~SO~4~ loãng nóng thì Cu tan (O~2~ làm chất oxy hóa) — đây là cách điều chế CuSO~4~ (mục 3.3).

**Với dung dịch muối.** Cu khử được Ag^+^ và cả Fe^3+^:

=> Cu + 2AgNO~3~ → Cu(NO~3~)~2~ + 2Ag

=> Cu + 2FeCl~3~ → CuCl~2~ + 2FeCl~2~

> [!bay] Giáo trình in thiếu hệ số (tr. 31)
> Sách in "Cu + FeCl~3~ → FeCl~2~ + CuCl~2~". Đúng: **Cu + 2FeCl~3~ → CuCl~2~ + 2FeCl~2~**. Lưu ý Cu **không** khử Fe^3+^ đến Fe kim loại, chỉ đến Fe^2+^. Phản ứng này dùng để ăn mòn mạch in bằng đồng.

**Tạo phức.** Ví dụ [Au(CN)~4~]^−^: Au^3+^ (5d^8^), CN^−^ là phối tử mạnh → lai hóa **dsp^2^**, **vuông phẳng**.

### 3.3. Hợp chất

**Oxide M~2~O** (chỉ có ở Cu, Ag):

- **Cu~2~O** tạo ra khi muối Cu(II) gặp kiềm có mặt **chất khử** (glucose, hydroxylamin…). Đầu tiên là CuOH vàng, đun nóng thành **Cu~2~O đỏ gạch** — chính là phản ứng **Fehling** của đường khử (bài Glucid).
- **Ag~2~O** tạo ngay khi cho OH^−^ vào dung dịch Ag^+^ (AgOH không bền). Nung nóng Ag~2~O dễ phân hủy thành Ag.
- Cu~2~O, Ag~2~O tan trong NH~3~ tạo phức [Cu(NH~3~)~2~]OH và **[Ag(NH~3~)~2~]OH** — chính là **thuốc thử Tollens** (tráng bạc).

**Oxide MO** chỉ đặc trưng cho Cu: CuO tạo khi nung Cu trong không khí, tan dễ trong acid cho muối Cu(II).

**Hydroxide.** Cu(OH)~2~ là kết tủa **nhầy, xanh lam**, đun nhẹ hóa CuO đen. Cu(OH)~2~ tan trong NH~3~ tạo phức **xanh thẫm**:

=> Cu(OH)~2~ + 4NH~3~ → [Cu(NH~3~)~4~](OH)~2~

Dung dịch này (**nước Svayde**, Schweizer) hòa tan được **cellulose**. Phức Cu(II) thường có **số phối trí 4, vuông phẳng**.

**Muối.**

- **CuSO~4~·5H~2~O** (xanh lam) — muối đồng quan trọng nhất. Điều chế: Cu + H~2~SO~4~ loãng nóng + thổi nhiều không khí:

=> Cu + H~2~SO~4~ + ½O~2~ → CuSO~4~ + H~2~O

- **Bạc halid** AgCl (trắng), AgBr (vàng nhạt), AgI (vàng) **rất ít tan** trong nước và acid loãng → dùng để **định tính, định lượng ion halogen**. Chỉ **AgCl tan trong NH~3~**:

=> AgCl + 2NH~3~ → [Ag(NH~3~)~2~]Cl

Acid hóa dung dịch phức bằng HNO~3~ thì AgCl kết tủa trở lại (NH~3~ bị trung hòa, phức bị phá).

- **AgNO~3~** là muối bạc tan dùng rộng rãi nhất; điều chế từ Ag + HNO~3~. Nhiều chất hữu cơ khử AgNO~3~ thành Ag kim loại, nên AgNO~3~ dính vào **da, vải sẽ hóa đen**.
- Hợp chất hóa trị III chỉ đặc trưng cho Au:

=> AuCl~3~ + 3NaOH → Au(OH)~3~ + 3NaCl

Au(OH)~3~ đun cẩn thận cho Au~2~O~3~ nâu (phân hủy ở 160 °C). Au(OH)~3~ **lưỡng tính**:

=> Au(OH)~3~ + 4HCl → H[AuCl~4~] + 3H~2~O

=> Au(OH)~3~ + NaOH → Na[Au(OH)~4~]

### 3.4. Trạng thái thiên nhiên và điều chế

- Cu, Ag chủ yếu ở dạng **sulfid**: quặng đồng quan trọng nhất là **cancopirit CuFeS~2~** và cancozin Cu~2~S; Ag~2~S lẫn trong quặng chì, đồng. **Vàng** chủ yếu ở dạng **tự do** phân tán trong đất đá.
- Luyện đồng: làm giàu quặng, nung với SiO~2~ ở khoảng 1400 °C:

=> 2CuFeS~2~ + 4O~2~ + 2SiO~2~ → Cu~2~S + 2FeSiO~3~ + 3SO~2~↑

=> 2Cu~2~S + 3O~2~ → 2Cu~2~O + 2SO~2~↑

=> 2Cu~2~O + Cu~2~S → 6Cu + SO~2~↑

Đồng thu được tinh khiết khoảng 99%, tinh chế tiếp bằng **điện phân với anod tan**.

> [!bay] Giáo trình thiếu hệ số (tr. 33)
> Sách in "CuFeS~2~ + 4O~2~ + SiO~2~ → Cu~2~S + 2FeSiO~3~ + 3SO~2~" — vế trái chỉ có 1 Cu, 1 Fe. Cần **2CuFeS~2~** và **2SiO~2~** như phương trình ở trên.

- Tách vàng bằng **cyanid**, rồi dùng Zn đẩy vàng ra:

=> 4Au + 8CN^−^ + O~2~ + 2H~2~O → 4[Au(CN)~2~]^−^ + 4OH^−^

=> 2[Au(CN)~2~]^−^ + Zn → 2Au + [Zn(CN)~4~]^2−^

### 3.5. Ứng dụng và vai trò sinh học

- **Cu**: kim loại màu quan trọng nhất; >50% dùng cho công nghiệp điện, khoảng 30% làm hợp kim.
- **Ag**: dẫn điện tốt nhất, bền hóa học → điện, điện tử, thực phẩm, hóa chất. AgNO~3~, AgBr dùng làm gương, phích, phim ảnh.
- **Đồng trong cơ thể:** có trong một số protein–enzym, tập trung ở **gan**; cần cho **tổng hợp hemoglobin** và phospholipid. **Thiếu đồng gây thiếu máu.** Ốc, sò… có **hemocyanin** chứa đồng, làm nhiệm vụ như hemoglobin.
- Với người, hợp chất đồng **ít độc hơn** chì, thủy ngân; nhưng **rất độc với nấm mốc, rêu tảo** → CuSO~4~ chống mốc gỗ, CuSO~4~ + sữa vôi (nước Bordeaux) trừ bệnh cho cây.
- **Ag^+^** có tính oxy hóa, **kìm hãm vi khuẩn ở nồng độ rất nhỏ**. Giáo trình nêu **keo bạc** (có chất làm bền) để khử trùng niêm mạc.

> [!ung-dung] Đồng, bạc trong lâm sàng
> - **Vì sao thiếu đồng gây thiếu máu?** Ceruloplasmin (protein chứa đồng của huyết tương) có hoạt tính **ferroxidase**: oxy hóa Fe^2+^ → Fe^3+^ để sắt gắn được vào transferrin và được vận chuyển tới tủy xương. Thiếu đồng thì sắt bị "kẹt" lại, dù cơ thể không thiếu sắt.
> - **Bệnh Wilson** (di truyền lặn, gen *ATP7B*): gan không thải được đồng qua mật → đồng **tích tụ** ở gan (viêm gan, xơ gan), não (run, rối loạn vận động, tâm thần) và giác mạc (**vòng Kayser–Fleischer** màu nâu). Xét nghiệm: **ceruloplasmin máu giảm**, đồng niệu 24 giờ tăng. Điều trị: thuốc tạo phức **D-penicillamin** (hoặc trientin) kéo đồng thải ra nước tiểu; **muối kẽm** làm giảm hấp thu đồng ở ruột.
> - **AgNO~3~** dung dịch loãng có tác dụng **sát khuẩn, làm se**; bút (que) AgNO~3~ dùng đốt mô sùi, mô hạt thừa. Ag^+^ gắn vào nhóm –SH của protein vi khuẩn. **Bạc sulfadiazin** là kem bôi chống nhiễm khuẩn vết **bỏng**. AgNO~3~ còn là thuốc thử chuẩn độ **ion clorid** (phương pháp Mohr dùng chỉ thị K~2~CrO~4~, xem mục 5).

> [!cap-nhat] Keo bạc và nhỏ mắt AgNO~3~
> Giáo trình ghi keo bạc dùng khử trùng niêm mạc. Hiện nay keo bạc **ít được dùng** trong y khoa chính thống. Các sản phẩm "bạc keo" **uống** quảng cáo chữa bệnh **không có lợi ích được chứng minh**, dùng lâu gây **nhiễm bạc (argyria)**: da xám xanh **vĩnh viễn**. Nhỏ mắt AgNO~3~ 1% cho trẻ sơ sinh (phương pháp Credé, phòng lậu mắt) đã được thay bằng thuốc mỡ kháng sinh vì AgNO~3~ gây viêm kết mạc hóa chất.

## 4. Nhóm IIB — Zn, Cd, Hg

### 4.1. Đặc điểm

- Đứng **cuối cùng** trong 10 nguyên tố d của mỗi chu kỳ. Cấu hình hóa trị **(n−1)d^10^ ns^2^**.
- Lớp d **đã bão hòa** nên rất bền, không tham gia liên kết. Chỉ 2 electron ns tham gia → số oxy hóa tối đa **+2**, giống IIA.
- **Tính khử yếu hơn IIA** vì năng lượng ion hóa khá lớn (cùng lý do như IB so với IA).
- **Hg còn có số oxy hóa +1**, nhưng không tồn tại ion Hg^+^ đơn độc: hai nguyên tử Hg liên kết cộng hóa trị –Hg–Hg– tạo ion **Hg~2~^2+^** (ví dụ calomel **Hg~2~Cl~2~**).
- Có khả năng tạo phức lớn.

### 4.2. Tính chất hóa học

**Với oxy.** Trong không khí ẩm, bề mặt phủ một lớp oxide khá bền. Nung nóng thì cháy tạo MO:

=> 2M + O~2~ → 2MO

Riêng **HgO** dễ phân hủy lại ở khoảng 400 °C (2HgO → 2Hg + O~2~).

**Với halogen, lưu huỳnh** khi đun nóng. Riêng **Hg tác dụng với S ngay ở nhiệt độ thường** tạo HgS:

=> Hg + S → HgS

→ Ứng dụng: **rắc bột lưu huỳnh** lên chỗ thủy ngân rơi vãi (nhiệt kế vỡ) để chuyển Hg thành HgS ít bay hơi, rồi thu gom.

**Với acid.**

- Zn, Cd (thế điện cực khá âm) đẩy được H~2~ khỏi HCl, H~2~SO~4~ loãng; **Hg thì không**:

=> M + 2H^+^ → M^2+^ + H~2~↑ (M = Zn, Cd)

- Với acid có tính oxy hóa (cả ba kim loại):

=> M + 2H~2~SO~4~ (đặc) → MSO~4~ + SO~2~↑ + 2H~2~O

=> 3M + 8HNO~3~ → 3M(NO~3~)~2~ + 2NO↑ + 4H~2~O

Với **Zn** (khử mạnh hơn), H~2~SO~4~ có thể bị khử sâu tới S, H~2~S; HNO~3~ loãng tới N~2~O, N~2~, NH~4~^+^.

**Với kiềm.** Chỉ **Zn** tan trong kiềm (giống Al):

=> Zn + 2NaOH + 2H~2~O → Na~2~[Zn(OH)~4~] + H~2~↑

> [!bay] Zn, Cd đứng trước H mà không đẩy được H~2~ khỏi nước? (Tự lượng giá 3.7)
> Ở nhiệt độ phòng, bề mặt Zn, Cd có lớp **oxide/hydroxide bền**, không tan trong nước, ngăn kim loại tiếp xúc với nước. Phản ứng "về lý thuyết" xảy ra nhưng **bị chặn** ngay từ đầu.

**Tạo phức** với NH~3~, CN^−^, amin…:

=> Zn^2+^ + 4NH~3~ → [Zn(NH~3~)~4~]^2+^

Zn^2+^ (3d^10^) không còn orbital 3d trống, nên dùng 4s và ba 4p → lai hóa **sp^3^**, phức **tứ diện**.

=> Hg^2+^ + 2I^−^ → HgI~2~↓ (đỏ cam)

=> HgI~2~ + 2I^−^ → [HgI~4~]^2−^ (không màu)

Dung dịch K~2~[HgI~4~] trong KOH là **thuốc thử Nessler**, dùng phát hiện NH~3~/NH~4~^+^ (cho kết tủa vàng nâu).

> [!bay] Giáo trình viết nhầm (tr. 35)
> Sách viết "Hg~2~^2+^ + 2I^−^ → Hg~2~I~2~ (đỏ)" rồi "Hg~2~I~2~ + 2I^−^ → [HgI~4~]^2−^". Phương trình sau **không cân bằng** (2 Hg → 1 Hg). Thực tế Hg~2~I~2~ màu vàng lục; khi dư I^−^ nó **tự oxy hóa – khử**: Hg~2~I~2~ + 2I^−^ → [HgI~4~]^2−^ + Hg↓. Kết tủa **đỏ** là **HgI~2~** của ion Hg^2+^ (hai phương trình viết ở trên). Ghi nhớ: phức của thuốc thử Nessler là **[HgI~4~]^2−^**, Hg ở số oxy hóa **+2**.

### 4.3. Hợp chất

**Oxide.** Trong ba oxide, **chỉ ZnO lưỡng tính**:

=> ZnO + 2HCl → ZnCl~2~ + H~2~O

=> ZnO + 2NaOH + H~2~O → Na~2~[Zn(OH)~4~] (natri zincat)

HgO dễ bị nhiệt phân.

**Hydroxide.** Zn(OH)~2~, Cd(OH)~2~ tạo ra từ M^2+^ + 2OH^−^. Riêng Hg^2+^ gặp kiềm chỉ cho **HgO** (vàng), vì Hg(OH)~2~ vừa sinh ra đã phân hủy:

=> Hg^2+^ + 2OH^−^ → HgO↓ + H~2~O

**Zn(OH)~2~ lưỡng tính**, tan trong acid và trong kiềm dư; đặc biệt còn **tan trong NH~3~** (tạo phức) — điểm khác với Al(OH)~3~:

=> Zn(OH)~2~ + 2NaOH → Na~2~[Zn(OH)~4~]

=> Zn(OH)~2~ + 4NH~3~ → [Zn(NH~3~)~4~](OH)~2~

> [!vi-du] Tự lượng giá 3.9 — thêm từ từ thuốc thử vào Zn(NO~3~)~2~
> - NaOH **thiếu**: Zn(NO~3~)~2~ + 2NaOH → Zn(OH)~2~↓ + 2NaNO~3~. NaOH **dư**: kết tủa tan, Zn(NO~3~)~2~ + 4NaOH → Na~2~[Zn(OH)~4~] + 2NaNO~3~.
> - NH~3~ **thiếu**: Zn(NO~3~)~2~ + 2NH~3~ + 2H~2~O → Zn(OH)~2~↓ + 2NH~4~NO~3~. NH~3~ **dư**: Zn(NO~3~)~2~ + **4**NH~3~ → [Zn(NH~3~)~4~](NO~3~)~2~.
> - Đáp án cuối sách in "Zn(NO~3~)~2~ + **2**NH~3~ (dư) → [Zn(NH~3~)~4~](NO~3~)~2~" — thiếu hệ số; phải là **4NH~3~**.
> - Phân biệt Zn^2+^ với Al^3+^: cả hai cho kết tủa trắng tan trong NaOH dư, nhưng **chỉ Zn(OH)~2~ tan trong NH~3~ dư**.

**Muối.**

- Sulfat, nitrat **dễ tan**; carbonat, sulfid **khó tan**.
- Halid: độ tan **giảm từ clorid → iodid** và **từ muối kẽm → muối thủy ngân**.
- **HgI~2~** rất ít tan nhưng **tan khi có KI** (tạo phức [HgI~4~]^2−^).

### 4.4. Trạng thái thiên nhiên và điều chế

- Chủ yếu ở dạng **sulfid** lẫn với chì, đồng. ZnS (lẫn CdS) trong quặng **sphalerit**; **ZnCO~3~** là thành phần chính của quặng **calamin**; **HgS** trong quặng **xinaba** (thần sa, cinnabar). Hg còn có ở dạng tự do vì hợp chất của nó kém bền, dễ phân hủy ra kim loại.
- Việt Nam có mỏ kẽm – chì ở Thái Nguyên, Quảng Nam; quặng xinaba rải rác ở Sơn La, Cao Bằng, Bắc Kạn, Thái Nguyên…
- Zn, Cd điều chế theo sơ đồ **MS → MO → M**:

=> 2ZnS + 3O~2~ → 2ZnO + 2SO~2~ (nung)

=> ZnO + C → Zn + CO (nhiệt luyện)

Hoặc **thủy luyện**: hòa ZnO vào acid rồi điện phân dung dịch muối kẽm — cho kẽm **tinh khiết cao**.

- **Thủy ngân**: **đốt quặng HgS**, Hg thoát ra dạng **hơi** rồi được ngưng tụ:

=> HgS + O~2~ → Hg + SO~2~

### 4.5. Ứng dụng

- **Zn** mạ lên thép chống ăn mòn (**tôn**).
- **Hg** làm cực âm khi điện phân dung dịch NaCl → NaOH đặc, tinh khiết hơn.
- **Hỗn hống** (amalgam) bạc – thiếc làm **chất hàn răng**; hỗn hống natri làm chất khử trong tổng hợp hữu cơ.
- **Hg~2~Cl~2~** (calomel) chế tạo **điện cực calomel chuẩn**; giáo trình còn ghi dùng làm chất xoa trong y học.
- **HgCl~2~** (sublimat) 0,1% từng dùng để **sát trùng**.

### 4.6. Tác dụng sinh học — kẽm thiết yếu, thủy ngân và cadimi độc

**Kẽm.** Là ion kim loại **cần thiết**. Giáo trình ghi người lớn cần khoảng **10–15 mg/ngày**, lấy chủ yếu từ thịt, một phần từ rau quả. Zn^2+^ là thành phần của nhiều enzym: **carbonic anhydrase** (giáo trình gọi *carboanhydrase*, trong **hồng cầu**), **alcol dehydrogenase** (ở **gan**).

**Thủy ngân.**

- **Hơi thủy ngân rất độc** → phải đựng Hg trong bình kín.
- Nhiễm độc cấp: **viêm niêm mạc miệng**, rối loạn tiêu hóa, tổn thương **thận**.
- **Ion Hg^2+^ độc vì gắn rất bền với protein** (đặc biệt nhóm –SH), làm protein, enzym mất chức năng. Cơ quan đích chính là **thận** (mất khả năng bài tiết).
- Giáo trình hướng dẫn sơ cứu: cho **ăn lòng trắng trứng, uống sữa** — protein trong đó kết tủa thủy ngân ngay trong dạ dày, hạn chế hấp thu.

> [!ung-dung] Ba dạng thủy ngân — ba kiểu độc; và bệnh Itai-itai của cadimi
> | Dạng | Vào cơ thể | Đích chính |
> |---|---|---|
> | **Hg nguyên tố** (hơi) | **Hít** (nuốt Hg lỏng thì hấp thu rất ít) | Phổi, **não** (run, rối loạn tâm thần, viêm lợi), thận |
> | **Muối Hg^2+^** (HgCl~2~) | Nuốt, qua da | **Ăn mòn** ống tiêu hóa, **thận** |
> | **Methyl thủy ngân** (hữu cơ) | Ăn cá, hải sản nhiễm | **Não**, thai nhi |
>
> - **Bệnh Minamata** (Nhật Bản, phát hiện năm 1956): nhà máy hóa chất xả thủy ngân ra vịnh Minamata, vi sinh vật chuyển thành **methyl thủy ngân**, chất này tích lũy theo chuỗi thức ăn vào cá. Người ăn cá bị tổn thương thần kinh (tê bì, thất điều, thu hẹp thị trường), trẻ sinh ra bị bại não bẩm sinh.
> - **Bệnh Itai-itai** ("đau quá, đau quá"; tỉnh Toyama, Nhật Bản): nước sông nhiễm **cadimi** từ mỏ kẽm – chì dùng tưới ruộng; người ăn gạo nhiễm Cd bị tổn thương **ống thận**, mất calci, **loãng và nhuyễn xương**, gãy xương, đau dữ dội. Cd đi cùng kẽm trong quặng (sphalerit) — đúng như giáo trình mô tả. Nguồn Cd hiện nay: **khói thuốc lá**, pin Ni–Cd, gạo trồng trên đất ô nhiễm.

> [!cap-nhat] Xử trí ngộ độc thủy ngân và dùng thủy ngân trong y tế
> - Giáo trình ghi khi nhiễm độc cần ăn lòng trắng trứng, uống sữa. Hiện nay đây chỉ là **biện pháp tạm thời** khi nuốt phải muối thủy ngân; người bệnh phải được đưa ngay đến cơ sở y tế để dùng **thuốc tạo phức** (dimercaprol, DMSA, DMPS — mục 7).
> - **HgCl~2~** sát trùng và **calomel** dùng trong điều trị đã **bị loại bỏ** do độc. Theo **Công ước Minamata về thủy ngân** (2013), nhiệt kế, huyết áp kế thủy ngân đang được thay dần bằng loại điện tử; amalgam hàn răng được giảm dần.
> - Giáo trình ghi nhu cầu kẽm 10–15 mg/ngày; khuyến nghị hiện nay (ví dụ của Mỹ) khoảng **8 mg/ngày (nữ), 11 mg/ngày (nam)**.

> [!yhct] Chu sa (HgS) — vì sao "kỵ hỏa"?
> **Chu sa** (thần sa, Cinnabaris) là khoáng vật **thủy ngân(II) sulfid HgS** màu đỏ son — chính là quặng **xinaba** của giáo trình. Trong YHCT, Chu sa thuộc nhóm **trọng trấn an thần** (thanh tâm, trấn kinh, an thần) và thường dùng **làm áo viên hoàn**.
> - **Vì sao kỵ hỏa (không được sao, nung, sắc)?** Phương trình điều chế thủy ngân của giáo trình đã trả lời: **HgS + O~2~ → Hg + SO~2~**. Đun nóng Chu sa trong không khí giải phóng **hơi thủy ngân** — dạng hấp thu qua phổi rất tốt và độc thần kinh. Vì vậy Chu sa chỉ được chế bằng **thủy phi** (nghiền mịn trong nước, gạn lấy phần bột nặng, phơi trong râm). Thủy phi còn giúp bột mịn và loại bớt tạp chất, trong đó có thủy ngân tự do và muối thủy ngân tan.
> - **Vì sao HgS "ít độc" hơn HgCl~2~ mà vẫn nguy hiểm?** HgS cực kỳ ít tan nên hấp thu qua ruột kém hơn nhiều so với muối Hg^2+^ tan. Nhưng dùng **liều cao hoặc kéo dài**, thủy ngân vẫn **tích lũy**, chủ yếu ở **thận** và **não**; đã có báo cáo ngộ độc do lạm dụng thuốc có Chu sa.
> - **Thực hành an toàn:** dùng đúng liều theo Dược điển (liều rất nhỏ, dạng hoàn/tán, **không sắc**), **không dùng lâu**. Dược điển Trung Quốc ghi **cấm dùng** cho phụ nữ có thai và người suy gan, suy thận; tránh dùng cho trẻ nhỏ. Không phơi, sấy, sao Chu sa bằng lửa.

> [!yhct] Từ thạch (Fe~3~O~4~) và Lô cam thạch (ZnCO~3~)
> - **Từ thạch** (Magnetitum) là khoáng **manhetit Fe~3~O~4~** (= FeO·Fe~2~O~3~, chứa cả Fe^2+^ lẫn Fe^3+^, có từ tính) — quặng giàu sắt nhất mà giáo trình nêu. Trong YHCT thuộc nhóm **trọng trấn an thần**, bình can tiềm dương, nạp khí bình suyễn. Thường chế bằng **nung đỏ rồi tôi giấm** nhiều lần: nhiệt độ thay đổi đột ngột làm khoáng **nứt vỡ, dễ tán bột**; acid acetic hòa tan một phần sắt thành muối. Cơ chế tác dụng an thần của Từ thạch **chưa được chứng minh rõ** bằng nghiên cứu hiện đại.
> - **Lô cam thạch** (Calamina) có thành phần chính là **kẽm carbonat ZnCO~3~** (quặng **calamin** của giáo trình). Chế bằng **nung rồi thủy phi**: ZnCO~3~ → ZnO + CO~2~↑. ZnO sinh ra có tác dụng **làm se, hút ẩm, bảo vệ da** — phù hợp với công dụng **dùng ngoài** (thu thấp, liễm sang; trị mắt đỏ, kèm nhèm theo YHCT). Đây cũng là nguyên lý của **kem/hồ kẽm oxide** và lotion calamin trong da liễu hiện đại. Lô cam thạch **chỉ dùng ngoài, không uống**; khoáng thiên nhiên có thể lẫn chì, cadimi nên phải dùng dược liệu đạt chuẩn.

## 5. Nhóm VIB — cromi: Cr, Mo, W

### 5.1. Đặc điểm

- Cấu hình hóa trị: **Cr 3d^5^ 4s^1^, Mo 4d^5^ 5s^1^, W 5d^4^ 6s^2^** (theo giáo trình).
- Dễ mất electron ns và các electron (n−1)d → số oxy hóa **cao nhất +6**. Số oxy hóa **thường gặp và bền của Cr: +3 và +6**.

> [!bay] VIB so với VIA (Tự lượng giá 3.10)
> Cr và S (VIA) đều có **6 electron hóa trị** và cùng số oxy hóa cao nhất +6 (CrO~3~ ↔ SO~3~; CrO~4~^2−^ ↔ SO~4~^2−^). Nhưng VIA có 6 electron ở **ns np** (ns^2^ np^4^) → **phi kim**, có số oxy hóa âm (−2). VIB có electron ở **(n−1)d ns** → **kim loại**, không có số oxy hóa âm. Cùng logic cho VIIB (Mn) so với VIIA (Cl): cả hai có +7 (Mn~2~O~7~ ↔ Cl~2~O~7~, MnO~4~^−^ ↔ ClO~4~^−^), nhưng Cl là phi kim có −1.

### 5.2. Tính chất hóa học

**Với phi kim.** Bền trong không khí ở nhiệt độ thường (vì thế Cr được **mạ** bảo vệ). Bột Cr cháy ở nhiệt độ cao:

=> 4Cr + 3O~2~ → 2Cr~2~O~3~

Phản ứng với F~2~ ở nhiệt độ thường, với Cl~2~, Br~2~ khi đun nóng; với N, C, S chỉ ở nhiệt độ cao.

**Với nước** (> 600 °C):

=> 2Cr + 3H~2~O → Cr~2~O~3~ + 3H~2~↑

**Với acid.** Trong nhóm, chỉ Cr tan **chậm** trong HCl, H~2~SO~4~ loãng, tạo H~2~ và Cr^2+^. Cr^2+^ bị không khí oxy hóa ngay nên thực tế:

=> Cr + 2HCl → CrCl~2~ + H~2~↑

=> 4Cr + 12HCl + 3O~2~ → 4CrCl~3~ + 6H~2~O

Với H~2~SO~4~ đặc, HNO~3~ đặc **nguội**: **thụ động hóa** (như Fe, Al); chỉ phản ứng khi đun nóng, ví dụ 2Cr + 6H~2~SO~4~ (đặc, nóng) → Cr~2~(SO~4~)~3~ + 3SO~2~↑ + 6H~2~O.

### 5.3. Hợp chất

**So sánh Cr(II) – Cr(III) – Cr(VI)** (Tự lượng giá 3.11): **số oxy hóa càng cao, tính acid càng tăng**.

| | Cr(II) | Cr(III) | Cr(VI) |
|---|---|---|---|
| Oxide | CrO | **Cr~2~O~3~** (lục) | **CrO~3~** (đỏ thẫm) |
| Hydroxide | Cr(OH)~2~ | **Cr(OH)~3~** | H~2~CrO~4~, H~2~Cr~2~O~7~ |
| Tính chất | **Base** | **Lưỡng tính**, không tan trong nước | **Acid**, tan trong nước, **oxy hóa mạnh** |
| Oxy hóa – khử | Khử mạnh | Bền | Oxy hóa mạnh |

=> Cr(OH)~2~ + H~2~SO~4~ → CrSO~4~ + 2H~2~O

=> 2Cr(OH)~3~ + 3H~2~SO~4~ → Cr~2~(SO~4~)~3~ + 6H~2~O

=> Cr(OH)~3~ + 3NaOH → Na~3~[Cr(OH)~6~]

=> CrO~3~ + H~2~O → H~2~CrO~4~

**Muối Cr(VI).** **K~2~CrO~4~ (kali cromat) vàng**; **K~2~Cr~2~O~7~ (kali dicromat) đỏ da cam**. Hai ion chuyển hóa qua lại tùy pH:

=> Cr~2~O~7~^2−^ + H~2~O ⇌ 2CrO~4~^2−^ + 2H^+^

- Thêm **kiềm** (lấy bớt H^+^) → cân bằng chuyển sang phải → **cromat (vàng)**.
- Thêm **acid** (tăng H^+^) → chuyển sang trái → **dicromat (da cam)**.

=> K~2~Cr~2~O~7~ + 2KOH → 2K~2~CrO~4~ + H~2~O

=> 2K~2~CrO~4~ + H~2~SO~4~ → K~2~Cr~2~O~7~ + K~2~SO~4~ + H~2~O

> [!bay]
> Chuyển cromat ⇌ dicromat **không phải** phản ứng oxy hóa – khử: Cr vẫn là **+6** ở cả hai ion. Chỉ là phản ứng acid – base (trùng ngưng).

Cr(VI) **oxy hóa mạnh, nhất là trong môi trường acid**, và bị khử về Cr^3+^ (màu **xanh lục**):

=> Cr~2~O~7~^2−^ + 3NO~2~^−^ + 8H^+^ → 2Cr^3+^ + 3NO~3~^−^ + 4H~2~O

### 5.4. Trạng thái thiên nhiên và điều chế

- Quặng **cromit FeO·Cr~2~O~3~**; Việt Nam có mỏ cromit ở **Cổ Định (Thanh Hóa)**.
- Khử cromit bằng than → hợp kim **ferocrom** (luyện thép crom). Cr tinh khiết điều chế bằng **nhiệt nhôm** hoặc điện phân dung dịch dicromat.
- Sản xuất cromat: nung chảy cromit với Na~2~CO~3~ ở 1200 °C, thổi oxy:

=> 4FeO·Cr~2~O~3~ + 8Na~2~CO~3~ + 7O~2~ → 8Na~2~CrO~4~ + 2Fe~2~O~3~ + 8CO~2~↑

rồi acid hóa dung dịch cromat để thu dicromat.

### 5.5. Ứng dụng và vai trò sinh học

- Cr, Mo, W tạo nhiều **hợp kim** quan trọng. **Thép crom** rắn, bền với ăn mòn. **W** tinh khiết dùng trong kỹ thuật điện, vô tuyến, **thiết bị tia Roentgen** (anod ống tia X).
- **Hỗn hợp sulfocromic** (dung dịch K~2~Cr~2~O~7~ bão hòa + H~2~SO~4~ đặc, tỉ lệ 1 : 1) có **tính oxy hóa rất mạnh**, oxy hóa được các chất hữu cơ bám bẩn → dùng **rửa dụng cụ thủy tinh** trong phòng thí nghiệm.
- Giáo trình ghi: Cr có trong máu và mô động vật; ở sản phụ nhiễm độc nội tiết tố tuyến giáp, Cr và Mo giảm, Mn và Cu tăng. Thiếu Cr gây bệnh về mắt, rối loạn chuyển hóa glucid, làm tiến triển bệnh đái tháo đường.
- **Mo** có ở gan, thận, tuyến nội tiết; tham gia các enzym flavin, **aldehyd oxidase** (cùng xanthin oxidase, sulfit oxidase). Lượng sinh lý của Mo kích thích sinh trưởng, tăng miễn dịch với một số bệnh nhiễm trùng.

> [!ung-dung] Cr(VI) độc, Cr(III) ít độc
> - **Cr(VI)** (cromat, dicromat, CrO~3~) **xuyên qua màng tế bào** dễ (vì CrO~4~^2−^ giống SO~4~^2−^, đi qua kênh vận chuyển sulfat), vào trong tế bào bị khử thành Cr(III) và tạo gốc tự do làm **tổn thương DNA** (ADN). Cr(VI) là **chất gây ung thư nhóm 1** (IARC), gây ung thư phổi ở công nhân mạ crom, sản xuất cromat; tiếp xúc nghề nghiệp còn gây **loét da** ("lỗ crom"), **thủng vách ngăn mũi**, viêm da dị ứng (xi măng chứa cromat).
> - **Cr(III)** khó qua màng tế bào nên **ít độc** hơn nhiều.
> - Vì vậy hỗn hợp sulfocromic phải dùng hết sức cẩn thận (vừa ăn mòn, vừa chứa Cr(VI)); nhiều phòng thí nghiệm đã thay bằng chất tẩy rửa khác.
> - Phản ứng **K~2~Cr~2~O~7~ (da cam) → Cr^3+^ (xanh lục)** khi oxy hóa ethanol từng là nguyên lý của **máy đo nồng độ cồn hơi thở** kiểu cũ.
> - **Chuẩn độ Mohr**: định lượng Cl^−^ bằng AgNO~3~ với chỉ thị **K~2~CrO~4~**. Khi Cl^−^ đã kết tủa hết thành AgCl trắng, giọt Ag^+^ dư tạo Ag~2~CrO~4~ **đỏ nâu** báo điểm tương đương.

> [!cap-nhat] Cromi có thật sự là vi chất thiết yếu?
> Giáo trình ghi cromi có trong thành phần của **pepsin** và thiếu cromi gây rối loạn chuyển hóa glucid. Hiện nay: pepsin được xếp là protease **không chứa ion kim loại**. Vai trò thiết yếu của Cr(III) đang **bị nghi ngờ**: Cơ quan An toàn Thực phẩm châu Âu (EFSA, 2014) kết luận **không có bằng chứng thuyết phục** để xác lập nhu cầu cromi, và các thử nghiệm bổ sung cromi cho người đái tháo đường cho kết quả không nhất quán. Đi thi trả lời theo giáo trình.

## 6. Nhóm VIIB — mangan: Mn, Tc, Re

### 6.1. Đặc điểm

- Cấu hình hóa trị **(n−1)d^5^ ns^2^**: **Mn 3d^5^ 4s^2^, Tc 4d^5^ 5s^2^, Re 5d^5^ 6s^2^**.
- Số oxy hóa **cao nhất +7**. Thường gặp và bền của Mn: **+2, +4, +7** (ngoài ra +3, +6).

> [!bay]
> Ở tr. 40, sách in nguyên tố thứ ba là "W 5d^5^ 6s^2^". Nhóm VIIB là **Re (reni)**; W thuộc nhóm VIB.

### 6.2. Tính chất hóa học

- **Phi kim:** bột Mn đun nóng phản ứng mạnh với O~2~ (tạo MnO~2~ hoặc Mn~3~O~4~), halogen (MnX~2~). Với C, N, P, S chỉ phản ứng ở nhiệt độ cao.
- **Nước:** Mn đứng trước H; bột Mn tác dụng với nước nóng:

=> Mn + 2H~2~O → Mn(OH)~2~↓ + H~2~↑

- **Acid:** tan dễ trong HCl, H~2~SO~4~ loãng cho **Mn^2+^**; với acid có tính oxy hóa cũng cho Mn^2+^:

=> Mn + 2HCl → MnCl~2~ + H~2~↑

=> 3Mn + 8HNO~3~ (loãng) → 3Mn(NO~3~)~2~ + 2NO↑ + 4H~2~O

### 6.3. Hợp chất

**Oxide và hydroxide** — lại thấy quy luật "số oxy hóa tăng → tính acid tăng":

| Số oxy hóa | +2 | +3 | +4 | +7 |
|---|---|---|---|---|
| Oxide | MnO | Mn~2~O~3~ | **MnO~2~** | **Mn~2~O~7~** |
| Tính chất | Base | Base | **Lưỡng tính** | **Acid** |
| Hydroxide | Mn(OH)~2~ | Mn(OH)~3~ | — | **HMnO~4~** (acid permanganic, mạnh, chỉ có trong dung dịch) |

Oxide bền: Mn~2~O~3~, MnO~2~, Mn~3~O~4~.

**Vì sao muối Mn^2+^ bền nhất?** Mn^2+^ có cấu hình **3d^5^ bán bão hòa** (giống Fe^3+^).

**KMnO~4~** — tinh thể **tím**, dễ tan, ion MnO~4~^−^ trong dung dịch màu **hồng tím**. Đun nóng bị phân hủy (điều chế ít O~2~ trong phòng thí nghiệm):

=> 2KMnO~4~ → K~2~MnO~4~ + MnO~2~ + O~2~↑

Ion **manganat MnO~4~^2−^** (màu **xanh lục**) chỉ bền trong **môi trường kiềm**. Trong nước hoặc acid nó **tự oxy hóa – khử**:

=> 3MnO~4~^2−^ + 2H~2~O → 2MnO~4~^−^ + MnO~2~↓ + 4OH^−^

> [!bay] Giáo trình in sai (tr. 41)
> Sách in "MnO~4~^2−^ + H~2~O ⇌ 2MnO~4~^−^ + 4OH^−^" — không cân bằng Mn, O, điện tích và không có chất bị khử. Phương trình đúng như trên (đáp án 3.15 cuối sách cũng viết đúng). Giáo trình gọi màu manganat là "xanh"; cụ thể là **xanh lục**.

**Tính oxy hóa của MnO~4~^−^ phụ thuộc môi trường** (Tự lượng giá 3.16) — ví dụ oxy hóa SO~3~^2−^:

![Hình 3. Sản phẩm khử của MnO₄⁻ trong ba môi trường](kmno4.svg)

**Acid** — hồng tím → **mất màu**:

=> 2MnO~4~^−^ + 5SO~3~^2−^ + 6H^+^ → 2Mn^2+^ + 5SO~4~^2−^ + 3H~2~O

**Trung tính** — kết tủa **nâu đen**:

=> 2MnO~4~^−^ + 3SO~3~^2−^ + H~2~O → 2MnO~2~↓ + 3SO~4~^2−^ + 2OH^−^

**Kiềm** — dung dịch **xanh lục**:

=> 2MnO~4~^−^ + SO~3~^2−^ + 2OH^−^ → 2MnO~4~^2−^ + SO~4~^2−^ + H~2~O

**Vì sao acid mạnh nhất?** Trong acid, Mn nhận nhiều electron nhất (+7 → +2, nhận **5e**); trung tính +7 → +4 (**3e**); kiềm +7 → +6 (**1e**). H^+^ "kéo" oxy của MnO~4~^−^ ra thành nước, giúp phản ứng khử sâu hơn.

**Mn nào là chất khử, chất oxy hóa?** (Tự lượng giá 3.15, theo đáp án sách)

- **Mn^7+^ (KMnO~4~): chỉ là chất oxy hóa** (số oxy hóa cao nhất).
- **Mn^2+^: chỉ là chất khử** (theo sách; Mn^0^ mới là thấp nhất về lý thuyết, nhưng trong dung dịch Mn^2+^ không bị khử tiếp).
- **Mn^4+^, Mn^6+^: vừa oxy hóa vừa khử.**

MnO~2~ là **chất oxy hóa** (điều chế clo):

=> MnO~2~ + 4HCl (đặc) → MnCl~2~ + Cl~2~↑ + 2H~2~O

MnO~2~ là **chất khử** (nung chảy với kiềm và chất oxy hóa):

=> MnO~2~ + 2KOH + KNO~3~ → K~2~MnO~4~ + KNO~2~ + H~2~O

Mn(II) là **chất khử**:

=> 2Mn(OH)~2~ + O~2~ + 2H~2~O → 2Mn(OH)~4~

> [!bay] Đáp án cuối sách in "2Mn(OH)~2~ + O~2~ + 2H~2~O → **3**Mn(OH)~4~"
> Sai hệ số: 2 Mn ở vế trái chỉ cho **2**Mn(OH)~4~.

### 6.4. Trạng thái thiên nhiên và điều chế

- Quặng **piroluzit MnO~2~**, hausmanit Mn~3~O~4~ (sách ghi *hotmanit*).
- Mn điều chế bằng điện phân dung dịch MnCl~2~ hoặc MnSO~4~ (có (NH~4~)~2~SO~4~), hoặc khử oxide bằng Si trong lò điện.
- Phần lớn mangan sản xuất dưới dạng **feromangan** (khử hỗn hợp quặng sắt và mangan bằng C):

=> MnO~2~ + Fe~2~O~3~ + 5C → Mn + 2Fe + 5CO↑

> [!bay] Giáo trình in "→ **2**Mn + 2Fe + 5CO" (tr. 42)
> Vế trái chỉ có 1 Mn nên vế phải là **Mn**. Kiểm tra oxy: 2 + 3 = 5 = 5CO. ✓

### 6.5. Ứng dụng và vai trò sinh học

- **Thép mangan** rất rắn, bền → bộ phận máy đập, máy nghiền, **đường ray**. MnO~2~ dùng làm **pin khô**.
- **KMnO~4~** dùng làm thuốc thử chuẩn độ oxy hóa – khử (**phép đo permanganat**), chất oxy hóa trong tổng hợp hữu cơ; trong y học là **chất khử trùng tốt**.
- Mn ảnh hưởng sinh trưởng của động, thực vật, **tăng oxy hóa lipid**. Người lớn cần trung bình **khoảng 0,1 mg/kg cân nặng/ngày**. Mn là thành phần (hoặc chất hoạt hóa) của **phosphatase máu, peptidase huyết thanh, decarboxylase**…
- **Ngộ độc mangan**: cấp tính tổn thương **hệ thần kinh trung ương**; kéo dài có thể gây **xơ gan**.

> [!ung-dung] Thuốc tím KMnO~4~ và mangan nghề nghiệp
> - **Thuốc tím** pha **rất loãng** (khoảng 1/5.000–1/10.000, dung dịch màu hồng nhạt) để rửa, ngâm vết thương bẩn, chàm chảy dịch, nhiễm nấm. Tác dụng nhờ **oxy hóa** vi khuẩn và chất hữu cơ; MnO~4~^−^ bị khử thành MnO~2~ nâu — vì vậy da và móng **bị nhuộm nâu** tạm thời.
> - Dung dịch **đậm đặc** hoặc **tinh thể** gây **bỏng ăn mòn** da, niêm mạc; nuốt phải rất nguy hiểm. Pha phải tan hết tinh thể.
> - Hít bụi/khói mangan lâu ngày (thợ mỏ, thợ hàn) gây **hội chứng giống Parkinson** (manganism) — đúng với "tổn thương thần kinh trung ương" giáo trình nêu.
> - Định lượng **Fe^2+^** (ví dụ trong viên sắt) bằng KMnO~4~ trong H~2~SO~4~ (Tự lượng giá 3.18d): **10FeSO~4~ + 2KMnO~4~ + 8H~2~SO~4~ → 5Fe~2~(SO~4~)~3~ + K~2~SO~4~ + 2MnSO~4~ + 8H~2~O**. Không cần chỉ thị: giọt KMnO~4~ dư đầu tiên làm dung dịch **hồng bền**.

## 7. Phức chất trong y học — thuốc giải độc kim loại (bổ sung)

Giáo trình nhấn mạnh kim loại d **dễ tạo phức**. Y học tận dụng chính tính chất này theo hai hướng: **cơ thể dùng phức kim loại** (hem, cobalamin, enzym chứa Zn, Cu, Mo, Mn) và **thầy thuốc dùng phối tử để kéo kim loại độc ra khỏi cơ thể**.

**Chất tạo phức vòng (chelat, "càng cua")** là phối tử có **nhiều nhóm cho electron** (–SH, –COO^−^, –NH~2~, –OH) cùng kẹp một ion kim loại, tạo vòng bền. Phức chelat **tan trong nước**, ít độc, được **thải qua thận**.

**Vì sao thuốc giải Hg, As, Cd thường chứa nhóm –SH?** Các ion "mềm" như Hg^2+^, Cd^2+^, Pb^2+^, As(III) **ưa lưu huỳnh**: chúng gắn rất bền vào –SH. Đó cũng là lý do chúng **độc** (khóa nhóm –SH của enzym) và lý do lòng trắng trứng (giàu protein chứa –SH) giúp "giữ" thủy ngân trong dạ dày. Thuốc giải chứa –SH sẽ **giành** ion kim loại khỏi enzym.

| Thuốc tạo phức | Nhóm gắn | Dùng cho |
|---|---|---|
| **Dimercaprol** (BAL, 2,3-dimercaptopropanol) | 2 nhóm –SH | **Hg** (muối vô cơ), **As**, Au, Pb (phối hợp) |
| **DMSA** (succimer), **DMPS** | 2 nhóm –SH, tan trong nước | Pb, Hg, As (uống/tiêm, ít độc hơn BAL) |
| **Calci dinatri EDTA** (CaNa~2~EDTA) | 4 –COO^−^ + 2 N | **Chì** |
| **D-penicillamin** | –SH, –NH~2~, –COO^−^ | **Đồng** (bệnh Wilson), chì |
| **Deferoxamin** | Nhóm hydroxamat | **Sắt** (ngộ độc sắt, quá tải sắt do truyền máu) |
| Xanh Phổ Fe~4~[Fe(CN)~6~]~3~ | Mạng tinh thể giữ ion | Thallium, cesi phóng xạ |

> [!bay] EDTA phải là dạng **calci** dinatri
> EDTA cũng tạo phức rất bền với **Ca^2+^**. Nếu tiêm nhầm **Na~2~EDTA** (không chứa Ca), thuốc sẽ "rút" Ca^2+^ của máu → **hạ calci máu cấp**, có thể tử vong. Dạng **CaNa~2~EDTA** đã "bão hòa" Ca nên chỉ đổi Ca lấy Pb^2+^ (phức Pb–EDTA bền hơn Ca–EDTA). EDTA còn là chất **chống đông** trong ống lấy máu xét nghiệm (ống nắp tím) vì bắt Ca^2+^ cần cho đông máu.

> [!vi-du] Phức platin chống ung thư
> **Cisplatin** cis-[Pt(NH~3~)~2~Cl~2~] là phức **vuông phẳng** của Pt(II) (5d^8^, lai hóa dsp^2^, giống [Ni(CN)~4~]^2−^ và [Au(CN)~4~]^−^ của giáo trình). Trong tế bào, Cl^−^ được thay bằng H~2~O rồi Pt gắn vào base **guanin** của DNA, làm DNA không nhân đôi được. Pt cùng nhóm VIIIB với Fe, Co, Ni.

## Tóm tắt

| Nhóm | Cấu hình hóa trị | Số oxy hóa chính | Điểm phải nhớ | Y học |
|---|---|---|---|---|
| **VIIIB** Fe, Co, Ni | 3d^6–8^ 4s^2^ | Fe, Co +2, +3; Ni +2 | Fe^2+^ → Fe^3+^ dễ (3d^5^ bền); thụ động trong acid đặc nguội; Co^3+^, Ni^3+^ oxy hóa HCl → Cl~2~; muối Mohr bền | Hem (Fe^2+^), cytochrom, thiếu máu thiếu sắt; B~12~ (Co); deferoxamin |
| **IB** Cu, Ag, Au | (n−1)d^10^ ns^1^ | Cu +2 (+1), Ag +1, Au +3 (+1) | Khử yếu hơn IA; chỉ tan trong acid oxy hóa; Au tan trong nước cường toan; [Cu(NH~3~)~4~]^2+^ xanh thẫm; AgCl tan trong NH~3~ | Wilson (Cu), AgNO~3~ sát khuẩn, bạc sulfadiazin |
| **IIB** Zn, Cd, Hg | (n−1)d^10^ ns^2^ | +2 (Hg~2~^2+^) | Zn, ZnO, Zn(OH)~2~ lưỡng tính; Zn(OH)~2~ tan trong NH~3~; Hg + S → HgS ở t° thường; HgS + O~2~ → Hg + SO~2~ | Enzym Zn; Minamata (Hg), Itai-itai (Cd); Chu sa kỵ hỏa; Lô cam thạch → ZnO |
| **VIB** Cr, Mo, W | Cr 3d^5^ 4s^1^ | Cr +3, +6 | CrO~4~^2−^ (vàng, kiềm) ⇌ Cr~2~O~7~^2−^ (da cam, acid); Cr(OH)~3~ lưỡng tính; CrO~3~ acid; sulfocromic | Cr(VI) gây ung thư, Cr(III) ít độc |
| **VIIB** Mn, Tc, Re | (n−1)d^5^ ns^2^ | Mn +2, +4, +7 | MnO~4~^−^ → Mn^2+^ (acid), MnO~2~ (trung tính), MnO~4~^2−^ (kiềm); MnO~2~ lưỡng tính; Mn~2~O~7~ acid | Thuốc tím sát khuẩn; manganism |

> [!vi-du] Câu hỏi tự lượng giá của giáo trình — những điểm hay ra
> - **3.1** Vì sao nhiều hóa trị? (n−1)d và ns năng lượng gần nhau, có orbital d trống.
> - **3.3 / 3.6** IB so với IA, IIB so với IIA: cùng số electron ngoài cùng, nhưng IB, IIB có lớp d^10^ sát ngoài → tính khử **yếu hơn**.
> - **3.17** Điều chế Fe trong phòng thí nghiệm: khử oxide sắt bằng CO, H~2~ (FeO + CO → Fe + CO~2~) hoặc điện phân dung dịch muối Fe^2+^.
> - **3.18** Một số phương trình: Fe~2~(SO~4~)~3~ + 2KI → 2FeSO~4~ + K~2~SO~4~ + I~2~; Fe~2~(SO~4~)~3~ + 3Zn (dư) → 3ZnSO~4~ + 2Fe (Zn thiếu thì chỉ đến Fe^2+^: Fe~2~(SO~4~)~3~ + Zn → 2FeSO~4~ + ZnSO~4~); 2Fe(OH)~2~ + H~2~O~2~ → 2Fe(OH)~3~.
> - **3.18h** Đáp án sách in "2FeCl~3~ + 3H~2~S → 2FeS + 6HCl" — **không cân bằng** (3 S → 2 S) và FeS tan trong HCl sinh ra. Đúng: Fe^3+^ oxy hóa H~2~S thành S: **2FeCl~3~ + H~2~S → 2FeCl~2~ + S↓ + 2HCl**.
> - **3.18d** Đáp án sách cho M = Fe, Co. Thực tế KMnO~4~ chỉ oxy hóa được **Fe^2+^**; Co^3+^ là chất oxy hóa còn mạnh hơn MnO~4~^−^ nên Co^2+^ không bị KMnO~4~ oxy hóa trong điều kiện này.
