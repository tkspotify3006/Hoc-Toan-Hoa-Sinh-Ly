---
title: Amin, amid và một số hợp chất tạp chức chứa nhóm amin
thoi-gian: 50 phút
muc-tieu:
- Trình bày được cấu tạo của amin và cách xếp amin theo bậc I, II, III.
- Gọi được tên các amin đơn giản theo danh pháp IUPAC và danh pháp thông thường.
- Giải thích được tính base của amin; so sánh tính base của amin béo với amin thơm, của amin với amid.
- Viết được các phản ứng chính của amin (tạo muối, với acid nitrơ, tạo amid, với cloroform, thế vòng thơm) và của amid, ure.
- Nêu được tính chất hóa học của amino acid (lưỡng tính, điểm đẳng điện, tạo peptid, ninhydrin…) và của amin alcol.
- Nêu được cách điều chế amin và ý nghĩa y học của amin, amid, amino acid, amin alcol.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. **Amin** = NH~3~ bị thay H bằng gốc hydrocarbon. **Bậc amin = số gốc gắn vào N** (khác bậc alcol). N còn **một cặp electron tự do** nên mọi amin đều là **base**.
> 2. Tính base: **amin béo > NH~3~ > amin thơm > amid**. Gốc alkyl đẩy electron (+I) làm tăng; vòng benzen hay nhóm C=O "hút" cặp electron của N (liên hợp) làm giảm.
> 3. **HNO~2~ phân biệt bậc amin**: bậc I béo → **khí N~2~**; bậc I thơm (lạnh) → **muối diazoni** → hợp chất azo có màu; bậc II → **nitrosamin** vàng như dầu; bậc III béo → muối nitrit không bền.
> 4. **Amid** R–CO–NH~2~ gần như trung tính (lưỡng tính rất yếu), bị thủy phân. **Ure** = amid của acid carbonic; ure + acid malonic → **acid barbituric**.
> 5. **Amino acid** lưỡng tính, trong nước tồn tại chủ yếu ở dạng **ion lưỡng cực**; tại **pI** điện tích tổng = 0. Hai amino acid (acid amin) nối nhau bằng **liên kết peptid –CO–NH–**. **Amin alcol**: ethanolamin, **cholin**, acetylcholin, adrenalin.

## 1. Amin

### 1.1. Định nghĩa và phân loại theo bậc

**Amin** là dẫn xuất của amoniac NH~3~, trong đó 1, 2 hoặc cả 3 nguyên tử H được thay bằng gốc hydrocarbon. Gốc này có thể no, không no hoặc thơm (Giáo trình tr. 212).

| Bậc | Số gốc gắn vào N | Dạng chung | Ví dụ |
|---|---|---|---|
| **Bậc I** | 1 | R–NH~2~ | propylamin CH~3~CH~2~CH~2~NH~2~; anilin C~6~H~5~NH~2~ |
| **Bậc II** | 2 | R–NH–R′ | ethyl methyl amin C~2~H~5~–NH–CH~3~; diphenylamin (C~6~H~5~)~2~NH |
| **Bậc III** | 3 | R–N(R′)–R″ | ethyl dimethyl amin C~2~H~5~–N(CH~3~)~2~; trimethylamin (CH~3~)~3~N |

Ngoài ra còn chia theo gốc: **amin béo** (gốc no hoặc không no mạch hở) và **amin thơm** (N gắn trực tiếp vào vòng benzen).

> [!bay] Bậc amin khác bậc alcol
> - **Bậc alcol** tính theo **carbon mang nhóm –OH** (C đó gắn với mấy C khác). **Bậc amin** tính theo **số gốc gắn vào nguyên tử N**.
> - Ví dụ: (CH~3~)~3~C–NH~2~ (tert-butylamin) có N gắn với một carbon bậc III, nhưng N chỉ mang **một gốc**, nên vẫn là **amin bậc I**.
> - **Benzylamin** C~6~H~5~–CH~2~–NH~2~ **không phải amin thơm**: N gắn vào CH~2~, không gắn trực tiếp vào vòng. Về tính base, nó giống amin béo.

### 1.2. Danh pháp

**IUPAC (theo giáo trình):** chữ **amino** + tên hydrocarbon tương ứng (Giáo trình tr. 213).

| Công thức | Tên IUPAC theo giáo trình | Tên thông thường |
|---|---|---|
| CH~3~–NH~2~ | aminomethan | methylamin |
| H~2~N–(CH~2~)~4~–NH~2~ | 1,4-diaminobutan | **putrescin** (tên riêng) |
| C~6~H~11~–NH~2~ | aminocyclohexan | cyclohexylamin |
| C~6~H~5~–NH~2~ | aminobenzen | **anilin**, phenylamin |
| p-CH~3~–C~6~H~4~–NH~2~ | p-aminotoluen | p-toluidin |
| (vòng benzen, CH~3~ ở C1 và C3, NH~2~ ở C4) | 4-amino-1,3-dimethylbenzen | 2,4-dimethylanilin |

**Danh pháp thông thường** — giáo trình nêu 4 cách:

1. **Tên gốc hydrocarbon + amin**: propylamin, ethyl methyl amin, diphenylamin.
2. Với diamin mạch thẳng: **tên chuỗi –CH~2~– (methylen) + diamin**: H~2~N–(CH~2~)~6~–NH~2~ là **hexamethylendiamin** (nguyên liệu làm nylon).
3. **Gốc ngắn + tên amin của phần còn lại**, các gốc gắn vào N ghi kèm chữ *N*: CH~3~CH~2~CH~2~CH~2~–N(CH~3~)(C~2~H~5~) là *N*-ethyl-*N*-methylaminobutan.
4. **Tên riêng**: putrescin, cadaverin, anilin, toluidin…

> [!cap-nhat] Tên IUPAC hiện hành của amin
> Giáo trình dùng kiểu "amino + hydrocarbon" (aminomethan, aminobenzen). IUPAC hiện nay ưu tiên kiểu **tên hydrocarbon + đuôi -amin**: methanamin, butan-1-amin, **anilin** (tên riêng được IUPAC giữ lại; tên hệ thống là benzenamin), cyclohexanamin, *N*-ethyl-*N*-methylbutan-1-amin. Giáo trình cũng dùng kiểu này ở mục đồng phân (butan-1-amin, butan-2-amin). Tiền tố "amino-" vẫn dùng khi nhóm amin không phải nhóm chức chính, ví dụ trong amino acid. Đi thi, cả hai cách đều được hiểu; theo đáp án của sách thì viết "aminobenzen", "propanamid"…

### 1.3. Đồng phân

- **Vị trí nhóm –NH~2~** (từ 3C trở lên): butan-1-amin CH~3~CH~2~CH~2~CH~2~NH~2~ và butan-2-amin CH~3~CH(NH~2~)CH~2~CH~3~. Trên vòng thơm: **o-, m-, p-toluidin**.
- **Mạch carbon**: n-propylamin CH~3~CH~2~CH~2~NH~2~ và isopropylamin (CH~3~)~2~CH–NH~2~.
- **Khác gốc hydrocarbon** (ở amin bậc II, III): methyl propyl amin CH~3~–NH–C~3~H~7~ và diethylamin C~2~H~5~–NH–C~2~H~5~ (cùng C~4~H~11~N).

> [!bay] "Bốn đồng phân của toluidin"
> Giáo trình xếp o-, m-, p-toluidin và **benzylamin** là bốn đồng phân (tr. 213–214). Nói chính xác: cả bốn là đồng phân **cùng công thức C~7~H~9~N**, nhưng chỉ ba chất đầu mới là **toluidin** (CH~3~–C~6~H~4~–NH~2~). Benzylamin là amin béo. C~7~H~9~N còn có đồng phân thứ năm là ***N*-methylanilin** C~6~H~5~–NH–CH~3~ (amin bậc II).

### 1.4. Tính chất vật lý

- Methylamin, ethylamin (và dimethyl-, trimethylamin) là **chất khí** ở nhiệt độ thường, mùi khai giống amoniac, có mùi tanh cá. Amin trung bình là chất lỏng, amin phân tử lớn là chất rắn.
- Anilin, *N*-methylanilin, *N,N*-dimethylanilin là chất lỏng. **Monoamin thơm khó tan** trong nước; diamin thơm dễ tan hơn.
- Amin bậc I, II tạo được **liên kết hydro** N–H···N nên sôi cao hơn hydrocarbon cùng khối lượng. Nhưng liên kết N–H phân cực kém O–H, nên amin **sôi thấp hơn alcol** tương ứng. Amin bậc III không có H trên N nên không tạo liên kết hydro giữa các phân tử với nhau; ví dụ trimethylamin sôi ở 3,5 °C, thấp hơn dimethylamin 7,4 °C (Giáo trình Phụ lục bảng 2, tr. 260).

> [!vi-du] Một số liệu in thiếu dấu
> Phụ lục bảng 2 ghi methylamin sôi ở 6,5 °C. Methylamin thực tế sôi ở khoảng **−6 °C** (dễ thấy là thiếu dấu trừ). Hai giá trị khác trong cùng dãy vẫn ổn: dimethylamin khoảng 7 °C, trimethylamin khoảng 3 °C.

### 1.5. Tính chất hóa học

#### a) Tính base và phản ứng tạo muối

Nguyên tử N trong amin **lai hóa sp^3^** như trong NH~3~. Ba orbital lai hóa dùng để liên kết với H hoặc C. Orbital thứ tư chứa **một cặp electron chưa liên kết**. Cặp electron này nhận được proton H^+^ (liên kết phối trí), nên **mọi amin đều có tính base** (Giáo trình tr. 214–215).

=> R–NH~2~ + H~2~O ⇌ R–NH~3~^+^ + OH^−^

=> (CH~3~)~2~NH + H~2~O ⇌ (CH~3~)~2~NH~2~^+^ + OH^−^

Hằng số base K~b~ càng lớn thì base càng mạnh. Một số giá trị trong Bảng 21 (Giáo trình tr. 215):

| Chất | Bậc | K~b~ |
|---|---|---|
| NH~3~ | — | 1,79·10^−5^ |
| CH~3~NH~2~ | I | 3,70·10^−4^ |
| (CH~3~)~2~NH | II | 5,20·10^−4^ |
| C~2~H~5~NH~2~ | I | 5,60·10^−4^ |
| (C~2~H~5~)~2~NH | II | 9,60·10^−4^ |
| (C~2~H~5~)~3~N | III | 6,40·10^−4^ |
| C~6~H~5~NH~2~ (anilin) | I | 3,82·10^−10^ |
| C~6~H~5~NHCH~3~ | II | 5,00·10^−10^ |
| (C~6~H~5~)~2~NH | II | 7,60·10^−14^ |
| (C~6~H~5~)~3~N | III | ≈ 0 |

**Bốn kết luận của giáo trình (tr. 216):**

1. **Mọi amin béo đều base mạnh hơn NH~3~.** Gốc alkyl đẩy electron (+I) so với H, làm N giàu electron hơn, dễ nhận H^+^ hơn.
2. **Amin béo bậc II > bậc I**, vì N chịu +I của hai gốc.
3. **Amin béo bậc III lại yếu hơn bậc II**, chỉ xấp xỉ bậc I. Ba gốc alkyl "cồng kềnh" che chắn N, cản H^+^ đến gần. Giáo trình gọi đây là **hiệu ứng không gian**.
4. **Amin thơm yếu hơn NH~3~ hàng vạn lần**: K~b~ của anilin nhỏ hơn của NH~3~ khoảng 4,7·10^4^ lần. Nhiều amin thơm **không làm đổi màu quỳ tím**. Lý do: cặp electron của N **liên hợp** với hệ electron π của vòng benzen, nên mật độ electron trên N giảm. Càng nhiều vòng liên hợp thì càng yếu: anilin > diphenylamin > triphenylamin (K~b~ ≈ 0).

Dù yếu, **amin thơm vẫn tạo muối với acid mạnh** như amin béo:

=> C~6~H~5~NH~2~ + HCl → C~6~H~5~NH~3~^+^Cl^−^ (anilin hydroclorid, tan trong nước)

> [!bay]
> - **Thứ tự cần thuộc**: amid < amin thơm < NH~3~ < amin béo. Trong amin béo: bậc II > bậc I ≈ bậc III.
> - Bảng 21 có một số liệu **mâu thuẫn với chính lời giải thích**: trimethylamin được ghi K~b~ = 5,45·10^−4^, lớn hơn dimethylamin. Giá trị đo được thực tế khoảng **6·10^−5^**, tức (CH~3~)~3~N yếu hơn nhiều so với CH~3~NH~2~ và (CH~3~)~2~NH, đúng như kết luận số 3. Khi thi, trả lời theo kết luận "bậc III yếu hơn bậc II". Nguyên nhân sâu hơn (vai trò của nước solvat hóa ion amoni) đã giải thích ở bài *Hiệu ứng cấu trúc* (hc-03), mục 4.3.
> - Cách so sánh tính base bằng hiệu ứng I, C và các bài tập 3.8 đã có ở bài **Hiệu ứng cấu trúc (hc-03, mục 4.3)**.
> - Nhóm thế đẩy electron trên vòng làm amin thơm mạnh hơn anilin một chút: **p-toluidin** (K~b~ 1,18·10^−9^) > anilin.

#### b) Phản ứng với acid nitrơ HNO~2~ — phân biệt bậc amin

HNO~2~ không bền, nên thực tế người ta dùng **NaNO~2~ + HCl** (hoặc muối amin + NaNO~2~). Mỗi bậc amin cho một kiểu sản phẩm (Giáo trình tr. 216–218).

**Amin béo bậc I → alcol + khí N~2~ (sủi bọt)**

=> CH~3~NH~2~ + HNO~2~ → CH~3~OH + N~2~↑ + H~2~O

=> CH~3~NH~2~·HCl + NaNO~2~ → CH~3~OH + N~2~↑ + NaCl + H~2~O

Phản ứng dùng để **định tính amin béo bậc I** và **định lượng nitơ** của nhóm –NH~2~ qua thể tích N~2~ thoát ra (phương pháp **van Slyke**).

**Amin thơm bậc I → muối diazoni (ở nhiệt độ thấp, 0–5 °C)**

=> C~6~H~5~NH~3~^+^Cl^−^ + HNO~2~ → C~6~H~5~–N^+^≡N Cl^−^ + 2 H~2~O (phenyldiazoni clorid)

Ion diazoni **ghép (kết hợp) được với amin thơm hoặc phenol** tạo **hợp chất azo** –N=N– có màu. Đây là cơ sở sản xuất **phẩm nhuộm azo**:

=> C~6~H~5~N~2~^+^Cl^−^ + C~6~H~5~N(CH~3~)~2~ → C~6~H~5~–N=N–C~6~H~4~–N(CH~3~)~2~ (p-, màu vàng) + HCl

=> C~6~H~5~N~2~^+^Cl^−^ + C~6~H~5~OH → C~6~H~5~–N=N–C~6~H~4~–OH (p-hydroxyazobenzen, màu da cam) + HCl

> [!vi-du] Vì sao diazoni thơm bền, diazoni béo thì không?
> Với amin béo, ion R–N~2~^+^ cũng hình thành nhưng tách ngay ra N~2~ (một phân tử rất bền), để lại carbocation phản ứng với nước thành alcol. Ở ion aryldiazoni, điện tích dương được **giải tỏa vào vòng benzen** nên ion bền được ở 0–5 °C. Đun nóng thì nó cũng phân hủy, giải phóng N~2~ và tạo phenol.

**Amin bậc II (béo và thơm) → nitrosamin** — chất lỏng sánh như dầu, màu vàng, không tan trong nước. Dùng để **định tính amin bậc II**.

=> (CH~3~)~2~NH + HO–N=O → (CH~3~)~2~N–N=O + H~2~O (dimethylnitrosamin)

**Amin bậc III**

- **Béo**: chỉ phản ứng ở nhiệt độ thấp, rất chậm, có khi không xảy ra. Sản phẩm là **muối nitrit không bền**: (CH~3~)~3~N + HNO~2~ ⇌ [(CH~3~)~3~NH]^+^NO~2~^−^.
- **Thơm**: nhóm –N=O thế vào **vòng benzen** ở vị trí para, tạo hợp chất **nitroso** bền: C~6~H~5~N(CH~3~)~2~ + HNO~2~ → p-O=N–C~6~H~4~–N(CH~3~)~2~ + H~2~O (p-nitroso-*N,N*-dimethylanilin).

| Amin | + HNO~2~ cho | Dấu hiệu |
|---|---|---|
| Béo bậc I | ROH + N~2~ + H~2~O | **Sủi bọt khí** không màu |
| Thơm bậc I (0–5 °C) | Muối diazoni | Thêm phenol/amin thơm → **màu azo** |
| Bậc II (béo, thơm) | Nitrosamin R~2~N–N=O | Lớp **dầu vàng** không tan |
| Béo bậc III | Muối nitrit không bền | Gần như không thấy gì |
| Thơm bậc III | C-nitroso (nhóm N=O trên vòng) | Hợp chất có màu |

> [!ung-dung] Nitrosamin — chất gây ung thư
> - Nitrosamin (điển hình là **NDMA**, *N*-nitrosodimethylamin) là chất **gây ung thư** mạnh trên động vật thí nghiệm.
> - Trong cơ thể, nitrosamin có thể hình thành ở **dạ dày (môi trường acid)** từ **nitrit** (muối diêm NaNO~2~ trong thịt muối, xúc xích, thịt hun khói) và **amin bậc II** trong thức ăn. Vitamin C cạnh tranh với amin để phản ứng với nitrit, nên hạn chế được phản ứng này.
> - Năm 2018–2020, nhiều lô thuốc (**valsartan**, sau đó **ranitidin**…) bị thu hồi trên toàn thế giới vì nhiễm tạp NDMA. Từ đó, kiểm soát **tạp nitrosamin** trở thành yêu cầu bắt buộc trong sản xuất thuốc.

#### c) Phản ứng tạo amid (acyl hóa)

Amin **bậc I và bậc II** (còn H trên N) phản ứng với acid carboxylic hoặc dẫn xuất của nó (anhydrid acid, halogenid acid) tạo **amid**. Có thể xem amid là sản phẩm thay một H của nhóm –NH~2~ bằng gốc acyl R–CO– (Giáo trình tr. 218). Amin bậc III không còn H trên N nên không cho phản ứng này.

=> R–NH~2~ + HO–CO–R′ → R–NH–CO–R′ + H~2~O

=> C~6~H~5~NH~3~^+^Cl^−^ + (CH~3~CO)~2~O → C~6~H~5~–NH–CO–CH~3~ (**acetanilid**) + CH~3~COOH + HCl

> [!ung-dung] Từ acetanilid đến paracetamol
> **Acetanilid** (giáo trình viết *acetanilit*) từng là thuốc hạ sốt (cuối thế kỷ XIX) nhưng bị bỏ vì một phần chuyển hóa thành anilin, gây **methemoglobin** (máu không chở được oxy, da tím tái). Người ta nhận ra hoạt tính hạ sốt chủ yếu đến từ chất chuyển hóa của nó là **paracetamol** — chính là acetanilid có thêm nhóm –OH ở vị trí para: **N-(4-hydroxyphenyl)acetamid**. Paracetamol được tổng hợp bằng đúng phản ứng acyl hóa trên: p-aminophenol + anhydrid acetic. Paracetamol có nhóm **amid** (không base) và nhóm **–OH phenol**.

#### d) Phản ứng riêng của amin bậc I với cloroform (phản ứng carbylamin)

Đun amin **bậc I** (béo hay thơm) với **cloroform và kiềm** tạo **isonitril** (carbylamin) có **mùi rất khó chịu**. Đây là phản ứng **đặc trưng để nhận biết amin bậc I** (Giáo trình tr. 218–219).

=> R–NH~2~ + CHCl~3~ + 3 NaOH → R–N≡C + 3 NaCl + 3 H~2~O

=> C~6~H~5~NH~2~ + CHCl~3~ + 3 NaOH → C~6~H~5~–N≡C (phenyl isonitril) + 3 NaCl + 3 H~2~O

Trong nhóm isonitril, C nối với N bằng hai liên kết cộng hóa trị và một liên kết phối trí (N cho cặp electron).

#### e) Phản ứng thế H của vòng thơm (riêng amin thơm)

Nhóm –NH~2~ là **nhóm thế loại 1** (đẩy electron vào vòng bằng hiệu ứng +C), nên H ở vị trí **ortho và para** rất dễ bị thay thế (Giáo trình tr. 219).

- **Brom hóa**: anilin tác dụng với nước brom ngay ở nhiệt độ thường, thế cả 3 vị trí (2, 4, 6):

=> C~6~H~5~NH~2~ + 3 Br~2~ → 2,4,6-Br~3~C~6~H~2~NH~2~↓ (trắng) + 3 HBr

Giáo trình viết phản ứng với muối: C~6~H~5~NH~3~Cl + 3 Br~2~ → Br~3~C~6~H~2~NH~3~Cl + 3 HBr. Kết tủa trắng 2,4,6-tribromanilin dùng để **nhận biết anilin** (giống phenol với nước brom).

- **Sulfon hóa**: đun anilin với H~2~SO~4~ đặc thu được **acid sulfanilic** (acid p-aminobenzensulfonic):

=> H~2~N–C~6~H~5~ + HO–SO~3~H → p-H~2~N–C~6~H~4~–SO~3~H + H~2~O

### 1.6. Điều chế amin

| Phương pháp | Phương trình | Ghi chú |
|---|---|---|
| **NH~3~ + dẫn xuất halogen** (phản ứng Hofmann; giáo trình viết "Hoffmann") | CH~3~I + NH~3~ → CH~3~NH~3~^+^I^−^ → … | Đun trong ethanol; thu **hỗn hợp** amin bậc I, II, III và muối amoni bậc IV [(CH~3~)~4~N]^+^I^−^, vì amin vừa tạo lại tiếp tục phản ứng với CH~3~I |
| NH~3~ + dẫn xuất halogen thơm | C~6~H~5~Cl + NH~3~ → C~6~H~5~NH~2~ + HCl | Cần t°, áp suất cao, xúc tác Cu |
| **Alcol + NH~3~** (công nghiệp) | R–OH + H–NH~2~ → R–NH~2~ + H~2~O | Xúc tác ThO~2~ hoặc Al~2~O~3~, đun nóng |
| **Khử hợp chất nitro** — cách cơ bản điều chế amin thơm | C~6~H~5~NO~2~ + 6 [H] → C~6~H~5~NH~2~ + 2 H~2~O | [H] mới sinh từ Fe (hoặc Zn, Sn) + HCl |
| **Amid + Br~2~ trong kiềm** (chuyển vị Hofmann) | R–CO–NH~2~ + Br~2~ + 4 KOH → R–NH~2~ + 2 KBr + K~2~CO~3~ + 2 H~2~O | Amin thu được **ít hơn một C** so với amid |

> [!bay] Cân bằng lại phương trình của sách
> Giáo trình (tr. 220) ghi vế phải "… + K~2~CO~3~ + **H~2~O**". Đếm nguyên tử: vế trái có 6 H (ngoài gốc R) và 5 O; vế phải R–NH~2~ (2 H) + K~2~CO~3~ (3 O) nên cần **2 H~2~O**. Tương tự, phản ứng tạo diazoni ở tr. 217 cần **2 H~2~O** chứ không phải 1.

### 1.7. Ứng dụng và ý nghĩa y học của amin

- **Tổng hợp thuốc và phẩm nhuộm.** Từ methylamin tổng hợp được **adrenalin** (thuốc co mạch; xem mục 4). Từ anilin → acid sulfanilic → **sulfamid** (sulfanilamid, p-H~2~N–C~6~H~4~–SO~2~NH~2~), thuốc kháng khuẩn (Giáo trình tr. 220).
- **Thuốc thử phát hiện nitrit NO~2~^−^** (phản ứng Griess): acid sulfanilic trong acid acetic + NO~2~^−^ → muối diazoni; thêm **α-naphthylamin** → hợp chất azo **màu hồng** (Giáo trình tr. 221).
- **Amin từ sự phân hủy protein.** Thịt, cá ôi do vi khuẩn phân hủy protein sinh ra amin, ví dụ **putrescin** H~2~N–(CH~2~)~4~–NH~2~ và **cadaverin** H~2~N–(CH~2~)~5~–NH~2~ có mùi rất khó chịu.
- **Độc tính**: amin béo độc với **hệ thần kinh trung ương**. Phân tử càng lớn càng độc; **diamin độc hơn monoamin**; gốc alkyl dài độc hơn gốc ngắn. Độc tính của amin không no chủ yếu do gốc không no quyết định.

> [!ung-dung] Sulfamid và phản ứng Griess trong lâm sàng
> - **Sulfamid** có cấu trúc giống **acid p-aminobenzoic (PABA)**, chất vi khuẩn dùng để tự tổng hợp acid folic. Sulfamid "đóng giả" PABA, chặn enzym của vi khuẩn nên kìm khuẩn. Người lấy acid folic từ thức ăn nên ít bị ảnh hưởng.
> - Que thử nước tiểu có ô **nitrit** dựa trên phản ứng Griess: nhiều vi khuẩn Gram âm gây nhiễm khuẩn tiết niệu (như *E. coli*) khử nitrat thành nitrit, làm ô thử chuyển **hồng**.

> [!cap-nhat] Sulfamid và α-naphthylamin hiện nay
> - Giáo trình gọi sulfamid là "thuốc kháng khuẩn mạnh". Hiện nay sulfamid dùng đơn độc **ít còn dùng** vì vi khuẩn kháng nhiều; dạng hay gặp nhất là phối hợp **sulfamethoxazol + trimethoprim** (co-trimoxazol). Sulfamid hay gây dị ứng da, có khi nặng (hội chứng Stevens–Johnson).
> - **α-Naphthylamin** là chất gây ung thư bàng quang. Thuốc thử Griess ngày nay thường thay nó bằng *N*-(1-naphthyl)ethylendiamin; nguyên lý (diazoni hóa rồi ghép azo) vẫn y như giáo trình.

## 2. Amid

### 2.1. Định nghĩa và phân loại

**Amid** là dẫn xuất của acid carboxylic, trong đó nhóm **–OH của nhóm carboxyl được thay bằng nhóm amin**: R–CO–OH → R–CO–NH~2~. Nhóm chức amid là **–CO–NH~2~** (Giáo trình tr. 221–222).

- Thay tiếp H của –NH~2~ bằng gốc hydrocarbon được **amid thế**: R–CO–NH–CH~3~, R–CO–N(CH~3~)~2~.
- Thay nhóm –OH của **acid carbonic** HO–CO–OH bằng nhóm amin: thay 1 nhóm được **acid carbamic** HO–CO–NH~2~; thay cả 2 được **carbamid** H~2~N–CO–NH~2~, tức là **ure**.

### 2.2. Danh pháp

Lấy tên acid, **bỏ chữ "acid"** và đổi đuôi **-ic** thành **amid**:

| Công thức | Acid gốc | Tên amid |
|---|---|---|
| H–CO–NH~2~ | acid formic | formamid |
| CH~3~–CO–NH~2~ | acid acetic | **acetamid** |
| CH~3~CH~2~–CO–NH~2~ | acid propionic (propanoic) | propionamid (IUPAC: **propanamid**) |
| CH~2~=CH–CO–NH~2~ | acid acrylic | acrylamid |
| C~6~H~5~–CO–NH~2~ | acid benzoic | benzamid |
| C~6~H~5~–CH~2~–CO–NH~2~ | acid phenylacetic | phenylacetamid |
| C~6~H~5~–CO–NH–CH~3~ | — | ***N*-methylbenzamid** (amid thế: thêm chữ *N* + tên gốc) |

> [!bay] Amin hay amid?
> - **Amin**: N gắn với gốc hydrocarbon (C~6~H~5~–CH~2~–**NH~2~**: benzyl**amin**).
> - **Amid**: N gắn với nhóm **C=O** (C~6~H~5~–**CO**–NH~2~: benz**amid**).
> - Đáp án câu 10.1b ở cuối sách (tr. 257) ghi C~6~H~5~–CH~2~–NH~2~ là "benzylamid" — đó là lỗi in: chất này là **benzylamin** (IUPAC: phenylmethanamin; theo kiểu của giáo trình: aminomethylbenzen).

### 2.3. Tính chất vật lý

- Ở nhiệt độ thường **chỉ formamid là chất lỏng** (nóng chảy 2,5 °C). Các amid khác là chất rắn kết tinh, nóng chảy trên 80 °C (acetamid 82 °C, benzamid 130 °C).
- Amid thấp tan được trong nước. Amid tinh khiết **không mùi**.
- Amid sôi rất cao (acetamid 221 °C; acid acetic chỉ 118 °C) vì giữa các phân tử có nhiều **liên kết hydro** N–H···O=C rất bền.

### 2.4. Tính chất hóa học

#### a) Tính lưỡng tính (rất yếu)

Amid **vừa có tính base vừa có tính acid, nhưng cả hai đều rất yếu** (Giáo trình tr. 223).

- **Tính base rất yếu**: khác amin, cặp electron của N trong amid **liên hợp với electron π của nhóm C=O**, nên N nghèo electron, khó nhận proton. Amid chỉ tạo muối với acid vô cơ **mạnh**, và muối này **không bền, dễ bị thủy phân**:

=> CH~3~–CO–NH~2~ + HCl → [CH~3~–CO–NH~3~]^+^Cl^−^

- **Tính acid yếu**: cũng do hiệu ứng liên hợp đó, liên kết N–H phân cực hơn, H trên N linh động hơn. Amid tạo muối được với một số oxid kim loại. Muối kim loại cũng không bền, trừ muối thủy ngân:

=> 2 CH~3~–CO–NH~2~ + HgO → (CH~3~–CO–NH)~2~Hg + H~2~O

- Muối natri của amid tác dụng với dẫn xuất halogen cho amid thế:

=> CH~3~–CO–NHNa + CH~3~I → CH~3~–CO–NH–CH~3~ + NaI

> [!vi-du] Đào sâu: amid nhận proton ở đâu?
> Giáo trình vẽ H^+^ gắn vào N. Thực tế, vì cặp electron của N đã "chia" cho nhóm C=O, nên **nguyên tử O** của amid mới là nơi giàu electron nhất và nhận proton (tạo cation được giải tỏa điện tích trên O–C–N). Điều này không ảnh hưởng đến kết luận cần thi: **amid gần như trung tính**, base yếu hơn amin rất nhiều.

#### b) Phản ứng thủy phân

Amid bị thủy phân khi **đun sôi** với acid loãng (hoặc với kiềm), trả lại acid carboxylic và amoniac:

=> CH~3~–CO–NH~2~ + H~2~O → CH~3~COOH + NH~3~ (trong acid: NH~3~ nằm lại dưới dạng muối NH~4~^+^)

=> CH~3~–CO–NH~2~ + NaOH → CH~3~COONa + NH~3~↑ (đun nóng; khí NH~3~ làm xanh quỳ ẩm)

#### c) Phản ứng với acid nitrơ

Giống amin béo bậc I, nhóm –NH~2~ của amid **giải phóng N~2~** (Giáo trình tr. 224):

=> CH~3~–CO–NH~2~ + HNO~2~ → CH~3~COOH + N~2~↑ + H~2~O

=> H~2~N–CO–NH~2~ + 2 HNO~2~ → CO~2~↑ + 2 N~2~↑ + 3 H~2~O

> [!bay] Phương trình của ure với HNO~2~
> Giáo trình in "NH~2~–CO–NH~2~ + HONO → CO~2~ + H~2~O + N~2~", **chưa cân bằng**: ure có **hai** nhóm –NH~2~, mỗi nhóm cần một phân tử HNO~2~. Phương trình đúng: **(NH~2~)~2~CO + 2 HNO~2~ → CO~2~ + 2 N~2~ + 3 H~2~O**.

#### d) Phản ứng riêng của ure: tạo ureit và acid barbituric

H của ure có thể bị thay bằng **gốc acid carboxylic** (gốc acyl), tạo **ureit**:

- Với acid **mono**carboxylic: thay 1 H → **monoureit** H~2~N–CO–NH–CO–R; thay 2 H (mỗi N một H) → **diureit** R–CO–NH–CO–NH–CO–R.
- Với acid **di**carboxylic như **acid malonic** HOOC–CH~2~–COOH: hai đầu acid nối với hai nhóm NH~2~ của ure, tạo **diureit vòng** 6 cạnh là **acid barbituric** (malonylure):

=> H~2~N–CO–NH~2~ + HOOC–CH~2~–COOH → acid barbituric (vòng –NH–CO–NH–CO–CH~2~–CO–) + 2 H~2~O

Thay **hai H ở C5** (nhóm CH~2~) bằng gốc hydrocarbon được các **thuốc ngủ nhóm barbituric**. Ví dụ: acid 5-ethyl-5-phenylbarbituric là **gardenal** (phenobarbital).

> [!cap-nhat] Barbiturat ngày nay
> Giáo trình gọi các dẫn xuất barbituric là "thuốc ngủ". Hiện nay barbiturat **hầu như không còn dùng làm thuốc ngủ**, vì khoảng cách giữa liều điều trị và liều độc hẹp, dễ gây nghiện và quá liều dẫn đến **ức chế hô hấp**. Thuốc ngủ, an thần ngày nay chủ yếu thuộc nhóm khác (ví dụ benzodiazepin). **Phenobarbital (gardenal)** vẫn được dùng làm **thuốc chống động kinh**.

### 2.5. Ứng dụng và ý nghĩa y học của amid

- **Polyamid**: sợi nhân tạo **nylon 6** (capron, perlon) có mắt xích –[NH–(CH~2~)~5~–CO]~n~. Một polyamid làm thuốc kháng sinh là **gramicidin** do vi khuẩn *Bacillus brevis* tiết ra.
- **Nhóm –CO–NH–** (liên kết peptid) là "khung xương" của mọi **protein** (mục 3.5).
- **Ure** là nguyên liệu tổng hợp chất dẻo và một số thuốc, ví dụ **urosulfan** (p-aminobenzensulfonylure H~2~N–C~6~H~4~–SO~2~–NH–CO–NH~2~), một sulfamid trị nhiễm khuẩn đường tiết niệu.
- Trong cơ thể, **ure là sản phẩm chuyển hóa quan trọng** (Giáo trình tr. 225).

> [!ung-dung] Ure trong lâm sàng
> - **Ure là dạng thải nitơ chính** của cơ thể: amoniac (rất độc) sinh ra khi thoái hóa amino acid được **gan** chuyển thành ure (chu trình ure), rồi **thận** đào thải. Vì vậy **ure máu** (cùng creatinin) là xét nghiệm thường quy đánh giá chức năng thận: suy thận thì ure máu tăng. Ở suy gan nặng, gan không tổng hợp được ure, nên amoniac máu tăng.
> - **Test hơi thở ure** (^13^C hoặc ^14^C) chẩn đoán *Helicobacter pylori*: vi khuẩn có enzym **urease** thủy phân ure → NH~3~ + CO~2~; CO~2~ đánh dấu xuất hiện trong hơi thở. Phương trình: (NH~2~)~2~CO + H~2~O → CO~2~ + 2 NH~3~.
> - **Kem bôi ure** (5–10% làm ẩm, nồng độ cao hơn để làm mềm sừng) dùng cho da khô, dày sừng.

## 3. Amino acid

Giáo trình gọi là **amin acid**; tên quốc tế là amino acid.

### 3.1. Định nghĩa và phân loại

**Amino acid** là hợp chất **tạp chức** có cả nhóm **amin –NH~2~** và nhóm **carboxyl –COOH** trong phân tử (Giáo trình tr. 225).

**Theo gốc R:**

| Loại | Ví dụ |
|---|---|
| Amino acid béo | α-alanin CH~3~–CH(NH~2~)–COOH; β-alanin H~2~N–CH~2~–CH~2~–COOH |
| Amino acid thơm | **phenylalanin** C~6~H~5~–CH~2~–CH(NH~2~)–COOH |
| Amino acid dị vòng | **histidin** (vòng imidazol)–CH~2~–CH(NH~2~)–COOH |

**Theo số nhóm –NH~2~ so với –COOH:**

| Loại | Đặc điểm | Ví dụ |
|---|---|---|
| **Trung tính** | số –NH~2~ = số –COOH | **glycin** H~2~N–CH~2~–COOH, alanin |
| **Base** | –NH~2~ **nhiều hơn** | **lysin** H~2~N–(CH~2~)~4~–CH(NH~2~)–COOH |
| **Acid** | –COOH **nhiều hơn** | **acid glutamic** HOOC–(CH~2~)~2~–CH(NH~2~)–COOH |

**Theo cấu hình**: dãy **D** và **L** (so với glyceraldehyd; trong công thức Fischer, –NH~2~ bên phải là D, bên trái là L). **Trừ glycin** (không có C\*), **các amino acid tự nhiên đều thuộc dãy L**.

> [!bay]
> - "Trung tính" ở đây nghĩa là **số nhóm** acid và base bằng nhau, **không** có nghĩa pH dung dịch đúng bằng 7. Dung dịch glycin có pH hơi acid (pI = 5,97).
> - **Glycin là amino acid duy nhất không quang hoạt** (C~α~ gắn hai H).
> - Dãy L của amino acid **ngược** với dãy D quen thuộc của đường. Cả hai đều xác định bằng cách so với glyceraldehyd (xem bài *Cấu trúc phân tử hợp chất hữu cơ — đồng phân*, hc-01, và bài *Glucid*, hc-08b).

### 3.2. Danh pháp

| Kiểu | Quy tắc | Ví dụ |
|---|---|---|
| **IUPAC** | **acid + amino + tên acid IUPAC**, đánh số C từ nhóm COOH | CH~3~(CH~2~)~2~CH(NH~2~)COOH: **acid 2-aminopentanoic**; HOOC(CH~2~)~2~CH(NH~2~)COOH: **acid 2-aminopentandioic** (= acid glutamic) |
| **Thông thường** | **acid + amino + tên thường của acid**, dùng chữ Hy Lạp α, β, γ… (C kề COOH là α) | CH~3~CH(NH~2~)COOH: **acid α-aminopropionic** (= α-alanin) |
| **Tên riêng** | dùng cho amino acid tự nhiên | glycin, alanin, valin, histidin… |

> [!bay] Đánh số bằng chữ số hay chữ Hy Lạp?
> - **Số 2** (IUPAC) và **chữ α** (tên thường) chỉ **cùng một carbon** — carbon kề nhóm COOH. Vậy "acid 2-aminopropanoic" = "acid α-aminopropionic" = α-alanin; β-alanin = acid 3-aminopropanoic.
> - Giáo trình ghi H~2~N–CH~2~–CH~2~–CH(NH~2~)–COOH là "acid 2,4-diaminobutyric" ở mục tên thông thường. Viết đúng một kiểu thì là **acid 2,4-diaminobutanoic** (IUPAC) hoặc **acid α,γ-diaminobutyric** (tên thường).

### 3.3. Đồng phân

- **Đồng phân quang học**: phần lớn amino acid có C\* (ví dụ D- và L-alanin).
- **Đồng phân vị trí nhóm –NH~2~**: α-alanin (acid α-aminopropionic) và β-alanin (acid β-aminopropionic). **Các amino acid cấu tạo nên protein đều là α-amino acid** (Giáo trình tr. 227).

### 3.4. Tính chất vật lý

- Amino acid (nguồn gốc protein) là chất **kết tinh không màu**, bền ở nhiệt độ thường, nóng chảy ở nhiệt độ cao nhưng **không có nhiệt độ nóng chảy xác định** (bị phân hủy khi nóng chảy).
- **Độ tan trong nước** khác nhau nhiều (Bảng 23, tr. 227): glycin 25 g/100 mL, alanin 16,5, valin 8,9, leucin 2,2, phenylalanin 3,0, serin 5,0, threonin 20,5; acid glutamic chỉ 0,84; lysin rất dễ tan.
  - **Mạch carbon càng dài** → càng kém tan trong nước, tan tốt hơn trong alcol.
  - **Có vòng thơm** → giảm độ tan; **có nhóm –OH** → tăng độ tan.

**Vì sao amino acid giống muối (kết tinh, nóng chảy cao, tan trong nước, không tan trong dung môi hữu cơ)?** Vì trong phân tử, nhóm –COOH nhường H^+^ cho nhóm –NH~2~ ngay trong cùng một phân tử:

=> H~2~N–CHR–COOH (dạng A, phân tử) ⇌ H~3~N^+^–CHR–COO^−^ (dạng B, ion lưỡng cực)

Dạng B (giáo trình gọi là **dạng đẳng điện**; còn gọi **ion lưỡng cực**, *zwitterion*) chiếm ưu thế. Mỗi amino acid có hằng số K = [B]/[A] xác định; với alanin K = 10^5,41^, tức dạng ion lưỡng cực nhiều gấp khoảng 250 000 lần dạng phân tử. Tinh thể amino acid thực chất được xây từ các ion lưỡng cực hút nhau bằng lực tĩnh điện, giống tinh thể muối.

### 3.5. Tính chất hóa học

#### a) Tính lưỡng tính — điểm đẳng điện pI

Amino acid **lưỡng tính**: nhóm –COO^−^ nhận H^+^, nhóm –NH~3~^+^ nhường H^+^ (cho OH^−^). Trong acid hay kiềm đều tạo muối dễ tan (Giáo trình tr. 228):

=> H~3~N^+^–CHR–COO^−^ + H^+^ → H~3~N^+^–CHR–COOH (cation)

=> H~3~N^+^–CHR–COO^−^ + OH^−^ → H~2~N–CHR–COO^−^ (anion) + H~2~O

![Hình 1. Ba dạng tồn tại của glycin theo pH và điểm đẳng điện](amino-acid-ph.svg)

**Điểm đẳng điện (pI)** là giá trị pH mà tại đó amino acid tồn tại chủ yếu ở dạng ion lưỡng cực, **điện tích tổng bằng 0**, nên **không di chuyển trong điện trường**. Giáo trình cho các giá trị pK~a~ và pI ở Phụ lục bảng 3 (tr. 261).

| Amino acid | Loại | Cách tính pI | pI |
|---|---|---|---|
| Glycin | trung tính | (pK~a~ COOH + pK~a~ NH~3~^+^)/2 = (2,34 + 9,60)/2 | **5,97** |
| Alanin | trung tính | (2,35 + 9,69)/2 | 6,02 |
| Acid aspartic | acid | trung bình **hai pK~a~ nhóm acid**: (2,09 + 3,86)/2 | **2,98** |
| Acid glutamic | acid | (2,19 + 4,25)/2 | **3,22** |
| Histidin | base | trung bình **hai pK~a~ nhóm base**: (6,00 + 9,17)/2 | 7,59 |
| Lysin | base | (8,95 + 10,53)/2 | **9,74** |
| Arginin | base | (9,04 + 12,48)/2 | **10,76** |

**Quy tắc dùng khi làm bài:**

- **pH < pI** → amino acid tích điện **dương** (thêm H^+^) → chạy về **cực âm**.
- **pH = pI** → điện tích tổng bằng 0 → **không di chuyển**; độ tan **thấp nhất**.
- **pH > pI** → tích điện **âm** → chạy về **cực dương**.
- Amino acid **acid** có pI thấp (≈ 3); amino acid **trung tính** pI ≈ 5–6; amino acid **base** pI cao (≈ 7,6–10,8).

> [!bay] Bảng 3 phụ lục bị đảo tên ở hai dòng
> Ở Phụ lục bảng 3 (tr. 261), hàng "glutamin" lại ghi ký hiệu Glu, gốc HOOC–CH~2~–CH~2~– và pK~a~ R = 4,25 (của acid glutamic) nhưng pI 5,70 (của glutamin); hàng "glutamic" ghi Gln, gốc H~2~N–CO–CH~2~–CH~2~– (của glutamin) nhưng pI 3,22 (của acid glutamic). Nghĩa là ký hiệu, gốc R và các pK~a~ của hai hàng bị lẫn cho nhau, chỉ cột pI là đúng với tên hàng. Đúng là: **acid glutamic (Glu)**, gốc R là HOOC–CH~2~–CH~2~–, pK~a~ R = 4,25, **pI = 3,22**; **glutamin (Gln)**, gốc R là H~2~N–CO–CH~2~–CH~2~–, không có nhóm R ion hóa, **pI ≈ 5,7**. Gốc R của lysin in nhầm thành "H~3~N(CH~3~)~3~CH~2~–"; đúng là **H~2~N–(CH~2~)~4~–**. Gốc R của isoleucin in thành (CH~3~CH~2~)~2~CH– (3-pentyl); đúng là **CH~3~–CH~2~–CH(CH~3~)–** (sec-butyl).

> [!ung-dung] Điện di protein huyết thanh
> Protein là chuỗi amino acid nên cũng có pI riêng. Ở pH 8,6 của dung dịch đệm điện di, hầu hết protein huyết thanh tích điện âm và chạy về cực dương với tốc độ khác nhau. Nhờ vậy tách được **albumin, α~1~, α~2~, β, γ-globulin**. Kỹ thuật này dùng để phát hiện, ví dụ, đa u tủy xương (một "đỉnh" γ-globulin bất thường) hay hội chứng thận hư (albumin giảm). Cũng nhờ pI mà người ta **kết tủa protein** bằng cách chỉnh pH về pI (protein ít tan nhất), như sữa đông lại khi bị chua.

#### b) Phản ứng của nhóm carboxyl –COOH

- **Tạo muối, tạo ester** như acid carboxylic:

=> H~2~N–CHR–COOH + NaOH → H~2~N–CHR–COONa + H~2~O

- **Khử carboxyl (decarboxyl hóa)**: tách CO~2~, tạo **amin**:

=> R–CH(NH~2~)–COOH → R–CH~2~–NH~2~ + CO~2~

> [!ung-dung] Decarboxyl hóa sinh ra các "amin sinh học"
> Trong cơ thể, phản ứng này do enzym **decarboxylase** (coenzym là dẫn xuất vitamin B~6~) xúc tác, tạo ra nhiều chất có hoạt tính rất mạnh:
>
> - **Histidin → histamin**: trung gian của **dị ứng**, phản vệ (giãn mạch, co phế quản, ngứa); kích thích tiết acid dạ dày.
> - **Tyrosin → DOPA → dopamin** → noradrenalin → adrenalin: nhóm **catecholamin** (mục 4.3). Trong dãy này, bước decarboxyl hóa là **DOPA → dopamin**; tyrosin → DOPA là phản ứng gắn thêm –OH vào vòng.
> - **5-Hydroxytryptophan → serotonin**: dẫn truyền thần kinh, cảm xúc, nhu động ruột.
> - **Acid glutamic → GABA** (acid γ-aminobutyric): chất dẫn truyền **ức chế** chính của não.
> - **Ornithin, lysin → putrescin, cadaverin** (do vi khuẩn): mùi thịt cá ôi (mục 1.7).
>
> - Thuốc **kháng histamin H~1~** (chlorpheniramin, loratadin…) chống dị ứng; thuốc **kháng H~2~** (famotidin…) giảm tiết acid dạ dày.
> - **Ngộ độc cá ươn** (cá ngừ, cá thu bảo quản kém): vi khuẩn khử carboxyl histidin trong thịt cá thành histamin. Người ăn bị đỏ bừng mặt, ngứa, nổi mẩn, đau đầu như dị ứng. Nấu chín **không phá hủy** được histamin đã tạo thành.

#### c) Phản ứng của nhóm amin –NH~2~

Nhóm –NH~2~ của amino acid phản ứng như **amin bậc I**:

- **Với acid vô cơ** tạo muối: H~2~N–CHR–COOH + HCl → [H~3~N^+^–CHR–COOH]Cl^−^
- **Với HNO~2~** tạo **hydroxy acid (alcol acid) và khí N~2~**. Đây là cơ sở của **phương pháp van Slyke định lượng nitơ amin**:

=> R–CH(NH~2~)–COOH + HNO~2~ → R–CH(OH)–COOH + N~2~↑ + H~2~O

- **Chuyển nhóm amin sang α-cetoacid**: đun amino acid với một α-cetoacid, nhóm –NH~2~ chuyển sang cetoacid đó (Giáo trình tr. 229):

=> R–CH(NH~2~)–COOH + R′–CO–COOH → R–CO–COOH + R′–CH(NH~2~)–COOH

> [!cap-nhat] "Desamin hóa" hay "chuyển amin"?
> Giáo trình gọi phản ứng trên là *desamin hóa*. Theo cách gọi hiện nay (và ở môn Hóa sinh), phản ứng **chuyển nhóm amin từ amino acid sang α-cetoacid** là **chuyển amin (transamination)**; còn **khử amin (desamin hóa)** là phản ứng **tách nhóm amin thành NH~3~**. Trong cơ thể, chuyển amin do enzym **transaminase** (aminotransferase) xúc tác, với coenzym là dẫn xuất **vitamin B~6~** (pyridoxal phosphat). Hai transaminase quen thuộc là **ALT (GPT)** và **AST (GOT)**; khi tế bào gan bị tổn thương, chúng thoát vào máu, nên **ALT, AST máu tăng** trong viêm gan. Khi thi môn Hóa, ghi tên theo giáo trình nhưng hiểu đúng bản chất.

#### d) Phản ứng của cả hai nhóm –COOH và –NH~2~

**Tạo amid vòng (lactam).** Một **γ-amino acid** (–NH~2~ gắn ở carbon γ, tức C4 nếu đánh số carbon của nhóm COOH là C1) tự tách một phân tử nước giữa –NH~2~ và –COOH của chính nó, khép thành vòng 5 cạnh gọi là **γ-lactam**.

**Tạo liên kết peptid.** Nhóm –COOH của amino acid này ngưng tụ với nhóm –NH~2~ của amino acid kia, **tách một phân tử nước**, tạo **dipeptid**. Liên kết **–CO–NH–** giữa hai gốc amino acid gọi là **liên kết peptid** (Giáo trình tr. 229).

![Hình 2. Sự hình thành liên kết peptid giữa glycin và alanin](lien-ket-peptid.svg)

- Nhiều amino acid nối tiếp nhau như vậy tạo **polypeptid**: H~2~N–CHR–CO–[NH–CHR–CO]~n~–NH–CHR–COOH.
- Chuỗi có **một đầu N** (–NH~2~ tự do) và **một đầu C** (–COOH tự do). Theo quy ước, tên và trình tự peptid **viết từ đầu N sang đầu C**: Gly-Ala khác Ala-Gly (xem đồng phân peptid, bài hc-01 mục 4.2).
- Một chuỗi n gốc amino acid có **n − 1 liên kết peptid** và đã tách **n − 1** phân tử nước.

> [!bay]
> - Liên kết peptid là liên kết giữa **C của nhóm C=O** và **N** — không phải giữa hai carbon α, cũng không phải liên kết C–N trong nhóm –NH~2~ tự do.
> - Peptid là một kiểu **amid** (amid thế ở N). Vì vậy nó bị **thủy phân** (bằng acid, kiềm hoặc enzym tiêu hóa như pepsin, trypsin) để trả lại các amino acid.

**Tạo phức chất (chelat) với ion kim loại.** Amino acid tạo phức với nhiều ion kim loại hóa trị 2 (Mg^2+^, Mn^2+^, Fe^2+^, Cd^2+^, Co^2+^, Zn^2+^, Ni^2+^, Cu^2+^). Mỗi amino acid gắn vào ion kim loại bằng **hai đầu** (N của –NH~2~ cho cặp electron, O của –COO^−^), nên là **phối tử hai càng (bidentat)**. Phức tạo vòng 5 cạnh, gọi là **phức càng cua hay chelat** (Giáo trình tr. 229–230):

=> 2 H~2~N–CH~2~–COOH + Cu^2+^ → (H~2~N–CH~2~–COO)~2~Cu + 2 H^+^

Độ bền của phức tăng dần theo thứ tự:

**Mg^2+^ < Mn^2+^ < Fe^2+^ < Cd^2+^ < Co^2+^ < Zn^2+^ < Ni^2+^ < Cu^2+^**

Phức với **Cu^2+^ bền nhất** (màu xanh lam đậm). Đây là cơ sở của **phương pháp Pope–Stevens** (giáo trình viết "Pope Stiven") định lượng nitơ amin trong các chế phẩm chứa amino acid.

**Phản ứng màu với ninhydrin.** Đa số **α-amino acid** đun với **ninhydrin** cho sản phẩm **màu xanh tím**. Phản ứng dùng để **phát hiện và định lượng amino acid** (Giáo trình tr. 230).

> [!vi-du] Ninhydrin — thêm vài chi tiết hay hỏi
> - Trong phản ứng, amino acid bị khử carboxyl và khử amin (giải phóng CO~2~, NH~3~ và một aldehyd). NH~3~ ngưng tụ với ninhydrin tạo chất màu tím (tím Ruhemann). Vì vậy mọi chất có nhóm –NH~2~ tự do ở carbon α đều dương tính, kể cả peptid và protein (yếu hơn).
> - **Prolin** (nhóm amin bậc II nằm trong vòng) cho màu **vàng**, không cho màu tím — lý do giáo trình viết "đa số".
> - Ứng dụng: phun ninhydrin lên bản **sắc ký lớp mỏng** để hiện vết amino acid; ngành pháp y dùng ninhydrin làm hiện **dấu vân tay** trên giấy (mồ hôi chứa amino acid).

### 3.6. Ứng dụng và ý nghĩa y học

- **Protein** là polyme thiên nhiên cấu tạo chủ yếu từ các gốc amino acid. Ngoài vai trò xây dựng cơ thể, nhiều protein là **hormon** và **enzym**.
- **Oxytocin** (hormon của tuyến yên sau) là peptid gồm **9 gốc amino acid**, có một **cầu disulfid –S–S–** nối hai gốc cystein: Cys-Tyr-Ile-Gln-Asn-Cys-Pro-Leu-Gly-NH~2~ (giáo trình ghi Gln, Asn dưới dạng "Glu, Asp có NH~2~", tức là amid của chúng).
- **Gramicidin** (kháng sinh) cũng là một polypeptid vòng, gồm hai đoạn Val-Orn-Leu-Phe-Pro nối vòng.
- Amino acid có trong dịch thủy phân thịt, cá, đậu nành, khô lạc.
- Dùng làm thuốc: **acid glutamic** (một số bệnh thần kinh; muối **natri glutamat** là **mì chính**, bột ngọt), **methionin** (bệnh gan).

> [!bay] Công thức acid glutamic in sai
> Ở tr. 230, acid glutamic được in là HOOC–(CH~2~)~**4**~–CH(NH~2~)–COOH. Công thức đúng (như chính giáo trình viết ở tr. 226) là **HOOC–(CH~2~)~2~–CH(NH~2~)–COOH**, C~5~H~9~NO~4~, tên IUPAC acid 2-aminopentandioic.

> [!ung-dung] Amino acid trong lâm sàng
> - **Amino acid thiết yếu** (cơ thể không tự tổng hợp, phải lấy từ thức ăn): valin, leucin, isoleucin, threonin, methionin, phenylalanin, tryptophan, lysin, và histidin (cần cho trẻ em; nay thường được tính chung là 9 chất). Dịch truyền **đạm (amino acid)** dùng nuôi dưỡng tĩnh mạch.
> - **Phenylceton niệu (PKU)**: thiếu enzym chuyển phenylalanin thành tyrosin, phenylalanin tích tụ gây tổn thương não ở trẻ. Bệnh được sàng lọc sơ sinh; trẻ bệnh phải ăn chế độ ít phenylalanin. Vì thế đồ uống chứa chất tạo ngọt **aspartam** (một dipeptid có phenylalanin) phải ghi cảnh báo cho người bệnh PKU.
> - **Methionin** (và *N*-acetylcystein) bổ sung nhóm –SH để gan tái tạo glutathion, nên được dùng làm **thuốc giải độc khi quá liều paracetamol**.

> [!yhct] Cao động vật (A giao, Lộc giác giao, cao xương): hóa học của collagen
> - Da, gạc (sừng) hươu, xương chứa nhiều **collagen**, một protein rất giàu **glycin** (khoảng 1/3 số gốc), **prolin** và **hydroxyprolin**.
> - Khi **nấu cao** lâu giờ, chuỗi xoắn ba của collagen bị phá vỡ và một phần **liên kết peptid bị thủy phân**. Collagen chuyển thành **gelatin** và các peptid nhỏ: tan trong nước nóng, đông thành khối khi nguội. Đó là lý do các vị **A giao** (cao da lừa), **Lộc giác giao** (cao sừng hươu) hay cao xương đóng được thành bánh.
> - Thành phần chính của cao vì vậy là **protein thủy phân, peptid và amino acid** (cùng muối calci, phosphat với cao xương). Tác dụng "bổ huyết", "bổ thận" theo YHCT hiện mới có bằng chứng chủ yếu từ thực nghiệm; giá trị dinh dưỡng protein của gelatin lại **không cao** vì thiếu tryptophan. Kiểm nghiệm hiện đại có thể dựa vào **peptid đặc trưng theo loài** để phát hiện cao bị pha trộn da, xương của loài khác.

## 4. Amin alcol

### 4.1. Định nghĩa

**Amin alcol** (aminoalcol) là hợp chất tạp chức chứa đồng thời nhóm **alcol –OH** và nhóm **amin**: H~2~N–R–OH (Giáo trình tr. 231).

| Công thức | Tên | Bậc amin |
|---|---|---|
| HO–CH~2~–CH~2~–NH~2~ | **ethanolamin** (2-aminoethanol) | I |
| HN(CH~2~CH~2~OH)~2~ | diethanolamin | II |
| HO–CH~2~–CH~2~–N(C~2~H~5~)~2~ | α-(diethylamino)ethanol, tức **2-(diethylamino)ethanol** | III |

Loại được nghiên cứu nhiều nhất là **β-amin alcol**: nhóm amin và nhóm –OH gắn ở **hai carbon kề nhau**, công thức chung R–CH(NH~2~)–CH~2~OH.

### 4.2. Tính chất hóa học

Tính chất do cả hai nhóm –OH và nhóm amin quyết định.

- **Nhóm –OH** phản ứng như alcol, ví dụ với natri:

=> 2 H~2~N–CH~2~–CH~2~–OH + 2 Na → 2 H~2~N–CH~2~–CH~2~–ONa + H~2~↑

- **Nhóm amin** có **tính base yếu**, tạo muối kết tinh với acid vô cơ:

=> HO–CH~2~–CH~2~–NH~2~ + HCl → [HO–CH~2~–CH~2~–NH~3~]^+^Cl^−^

- Amin alcol có **nhóm amin bậc III** phản ứng với dẫn xuất halogen tạo **muối amoni bậc IV**:

=> HO–CH~2~–CH~2~–N(CH~3~)~2~ + CH~3~Br → [HO–CH~2~–CH~2~–N(CH~3~)~3~]^+^Br^−^ (**cholin bromid**)

### 4.3. Cholin, acetylcholin và các amin alcol trong y học

- **Cholin** [HO–CH~2~–CH~2~–N(CH~3~)~3~]^+^OH^−^ là **base amoni bậc IV**. Cholin tham gia **chuyển hóa lipid** và là thành phần của **phosphatid** (phosphatidylcholin, tức lecithin, trong màng tế bào). **Ethanolamin** là thành phần của phosphatidylethanolamin (cephalin).
- Trong mô thần kinh, cholin được ester hóa với acid acetic thành **acetylcholin** [CH~3~–CO–O–CH~2~–CH~2~–N(CH~3~)~3~]^+^, chất **dẫn truyền xung động thần kinh** (Giáo trình tr. 232).
- **Adrenalin** cũng là một amin alcol: vòng **catechol** (benzen có 2 nhóm –OH kề nhau) gắn với –CH(OH)–CH~2~–NH–CH~3~. Nhóm –OH và nhóm amin ở hai carbon kề nhau, cùng kiểu khung với **ephedrin** của Ma hoàng (đã học ở bài hc-01).

> [!ung-dung] Catecholamin, acetylcholin và ngộ độc phospho hữu cơ
> - **Catecholamin** gồm dopamin, noradrenalin, adrenalin, đều có vòng catechol và đều sinh ra từ tyrosin (mục 3.5b). **Adrenalin** (epinephrin) là **thuốc cấp cứu hàng đầu trong sốc phản vệ** (tiêm bắp), và còn được trộn vào thuốc tê để co mạch tại chỗ, kéo dài thời gian tê. Noradrenalin, dopamin dùng nâng huyết áp trong sốc. Nhóm catechol rất dễ bị oxy hóa, nên dung dịch adrenalin hóa hồng rồi nâu khi để ra ánh sáng và không khí; ống thuốc đã đổi màu thì không được dùng.
> - **Acetylcholin** bị enzym **acetylcholinesterase** thủy phân rất nhanh (cắt liên kết ester) thành cholin và acid acetic, nhờ vậy xung thần kinh được "tắt" kịp thời. Thuốc trừ sâu **phospho hữu cơ** ức chế enzym này, acetylcholin ứ đọng gây co đồng tử, tăng tiết đờm dãi, mồ hôi, co thắt phế quản, nhịp chậm, liệt cơ. Đây là ngộ độc rất hay gặp ở nông thôn Việt Nam; điều trị bằng **atropin** (và pralidoxim).

> [!cap-nhat] Acetylcholin và bệnh glôcôm (thiên đầu thống)
> Giáo trình viết acetylcholin "được dùng làm thuốc giảm áp lực mắt trong bệnh thiên đầu thống". Acetylcholin bị thủy phân quá nhanh nên **không dùng để điều trị glôcôm lâu dài**. Hiện nay nó chỉ được bơm vào tiền phòng trong lúc **phẫu thuật mắt** để làm co đồng tử. Thuốc nhỏ mắt hạ nhãn áp ngày nay chủ yếu là nhóm tương tự prostaglandin, thuốc chẹn beta (timolol)…; thuốc cường cholinergic **pilocarpin** (một alkaloid) vẫn còn được dùng trong một số trường hợp.

## 5. Nhóm amin trong thuốc — tổng hợp (bổ sung)

Phần này gom các ví dụ thuốc chứa nhóm amin, amid để thấy kiến thức hóa học áp dụng ra sao.

| Thuốc | Nhóm chức chứa N | Hệ quả hóa học – lâm sàng |
|---|---|---|
| **Paracetamol** | **amid** + phenol | N gần như không base; có tính acid yếu của phenol |
| **Sulfamid** (sulfanilamid) | **amin thơm bậc I** + sulfonamid –SO~2~NH~2~ | Giống PABA → kìm khuẩn; amin thơm bậc I cho phản ứng diazoni → dùng định tính, định lượng sulfamid |
| **Procain** (novocain) | **ester** của PABA với **2-(diethylamino)ethanol** (amin alcol bậc III) | Amin bậc III → tạo muối hydroclorid tan, pha thuốc tiêm. Bị **cholinesterase huyết tương** thủy phân nhanh nên tác dụng ngắn; giải phóng PABA nên dễ gây dị ứng và có thể đối kháng tác dụng của sulfamid |
| **Lidocain** (xylocain) | **amid** + amin bậc III | Liên kết amid bền hơn ester, không bị cholinesterase cắt, chuyển hóa ở gan → tác dụng dài hơn, ít dị ứng hơn; còn dùng chống loạn nhịp thất |
| **Adrenalin** | amin bậc II + amin alcol + catechol | Base → muối (adrenalin hydroclorid, tartrat); catechol dễ bị oxy hóa |
| **Histamin / kháng histamin** | amin bậc I + dị vòng imidazol | Nhiều thuốc kháng histamin (như chlorpheniramin) là amin bậc III, dùng dưới dạng muối |

> [!ung-dung] Vì sao thuốc tê kém tác dụng ở vùng viêm nhiễm?
> Thuốc tê (procain, lidocain) là **base yếu** có amin bậc III, được tiêm ở dạng **muối** (tan trong nước). Để thấm qua màng tế bào thần kinh, thuốc phải trở lại **dạng base tự do** (không mang điện, tan trong lipid). Mô bị viêm, áp xe có **pH acid**, giữ thuốc ở dạng muối mang điện, nên thuốc khó thấm vào dây thần kinh và tê kém. Ví dụ này cho thấy cân bằng R~3~N + H^+^ ⇌ R~3~NH^+^ (mục 1.5a) có ý nghĩa thực tế.

> [!yhct] Chiết alkaloid bằng acid và kiềm
> Bài *Hiệu ứng cấu trúc* (hc-03) đã giải thích việc **chế giấm** dựa trên tính base của alkaloid. Ở đây là mặt kỹ thuật chiết xuất. Alkaloid là **amin** (thường là amin dị vòng bậc II, III). Trong cây, chúng thường ở dạng **muối** với acid hữu cơ.
> - **Kiềm hóa** dược liệu (NH~3~, Na~2~CO~3~, vôi) → alkaloid chuyển thành **base tự do**, tan trong dung môi hữu cơ (cloroform, ether…) → chiết bằng dung môi đó.
> - **Lắc dịch chiết với acid loãng** → alkaloid tạo muối, chuyển sang **lớp nước**; tạp chất trung tính (chất béo, sắc tố) ở lại lớp dung môi.
> - **Kiềm hóa lại** lớp nước rồi chiết lại bằng dung môi → alkaloid sạch hơn. Đây là phương pháp chiết **acid–base**, cũng là cách định tính alkaloid bằng các thuốc thử tạo tủa trong môi trường acid (Mayer, Dragendorff).
> - **Ngoại lệ đáng nhớ**: **berberin** (Hoàng liên, Hoàng bá, Vàng đắng) là **muối amoni bậc IV**, giống cholin: N không còn cặp electron tự do, luôn mang điện dương nên kiềm hóa không chuyển được thành base tan trong dung môi hữu cơ. Berberin tan trong nước, chiết bằng nước hoặc cồn và thường dùng dưới dạng **berberin clorid**. **Colchicin** (trong hạt, củ cây Ngót nghẻo *Gloriosa superba* và cây *Colchicum*) có N ở dạng **amid** nên gần như không có tính base, cũng không theo quy luật này.

## 6. Giải câu hỏi tự lượng giá (Giáo trình tr. 232–233; hướng dẫn tr. 257–258)

| Câu | Trả lời |
|---|---|
| **10.1** | a) CH~3~CH~2~CONH~2~: **propanamid** (propionamid). b) C~6~H~5~CH~2~NH~2~: **benzylamin** (theo kiểu của sách: phenyl aminomethan; IUPAC hiện hành: phenylmethanamin) — sách in nhầm "benzylamid". c) C~6~H~5~NH~2~: **aminobenzen, anilin**. d) NH~2~CONH~2~: **carbamid, ure**. |
| **10.2** | a) m-bromanilin: vòng benzen có –NH~2~ ở C1, –Br ở **C3**. b) o-toluidin: –NH~2~ và –CH~3~ ở **hai C kề nhau**. c) trimethylamin: **(CH~3~)~3~N**. d) β-alanin: **H~2~N–CH~2~–CH~2~–COOH**. e) acetamid: **CH~3~CONH~2~**. |
| **10.3** | Bậc I R–NH~2~ (2 H trên N), bậc II R~2~NH (1 H), bậc III R~3~N (0 H). Tính base: II > I ≈ III. Với HNO~2~: I → ROH + N~2~; II → nitrosamin R~2~N–N=O; III → muối nitrit không bền. Chỉ bậc I cho phản ứng carbylamin (R–N≡C); bậc I và II tạo được amid, bậc III thì không. |
| **10.4** | a) **Cyclohexylamin > anilin**: ở anilin cặp e của N liên hợp với vòng. b) **Ethylamin > anilin**: +I của C~2~H~5~ làm N giàu e; anilin có liên hợp. c) **Ethylamin > acetamid**: cặp e của N trong amid liên hợp với C=O. |
| **10.5** | **CH~3~CONH~2~ < C~2~H~5~NH~2~ < CH~3~NHCH~3~** |
| **10.6** | (C~6~H~5~)~2~NH + HNO~2~ → (C~6~H~5~)~2~N–N=O + H~2~O; sản phẩm **diphenylnitrosamin** (*N*-nitrosodiphenylamin). |
| **10.7** | C~2~H~5~NH~2~ + CHCl~3~ + 3 NaOH → C~2~H~5~–N≡C + 3 NaCl + 3 H~2~O; sản phẩm là **isonitril** (carbylamin): ethyl isonitril, mùi rất khó chịu. |
| **10.8** | **CH~3~COCl + CH~3~NH~2~ → CH~3~CO–NH–CH~3~ + HCl** (*N*-methylacetamid). Thường dùng dư amin: CH~3~COCl + 2 CH~3~NH~2~ → CH~3~CONHCH~3~ + CH~3~NH~3~^+^Cl^−^. |
| **10.9** | H~2~N–CH~2~–COOH + HNO~2~ → HO–CH~2~–COOH (acid glycolic) + N~2~ + H~2~O. 2 H~2~N–CH~2~–COOH + Cu^2+^ → (H~2~N–CH~2~–COO)~2~Cu (phức chelat xanh lam) + 2 H^+^. |
| **10.10** | Phân tử có nhóm –COOH (nhường H^+^) và nhóm –NH~2~ (nhận H^+^) nên lưỡng tính. Trong dung dịch tồn tại chủ yếu ở dạng **ion lưỡng cực** H~3~N^+^–CHR–COO^−^ (dạng đẳng điện). |
| **10.11** | CH~3~CONH~2~ + H~2~O → CH~3~COOH + NH~3~ (đun sôi với acid loãng; NH~3~ ở dạng NH~4~^+^). Với kiềm: CH~3~CONH~2~ + NaOH → CH~3~COONa + NH~3~↑. |
| **10.12** | Peptid là sản phẩm ngưng tụ của các α-amino acid, nối nhau bằng **liên kết peptid –CO–NH–** (mỗi liên kết tách 1 H~2~O). Xem Hình 2. |

> [!bay] Đáp án 10.8 in trong sách bị sai
> Hướng dẫn trả lời (tr. 258) in "CH~3~COCl + H~2~N–CH~3~ → CH~3~CONH~2~ + CH~3~Cl". Phương trình này **sai**: methylamin không trao gốc CH~3~ cho Cl. Phản ứng tạo amid là thay **H** trên N bằng gốc acyl CH~3~CO–, nên sản phẩm là ***N*-methylacetamid CH~3~CONHCH~3~ + HCl** (xem mục 1.5c). Đáp án 10.9 cũng in nhầm sản phẩm thành "CH~2~OHCOOOH"; đúng là **HOCH~2~COOH**.

## Tóm tắt

| Nội dung | Ghi nhớ |
|---|---|
| Bậc amin | Số gốc gắn vào **N**: R–NH~2~ (I), R~2~NH (II), R~3~N (III) |
| Tên | Giáo trình: amino + hydrocarbon (aminobenzen); thường: gốc + amin (methylamin), anilin, toluidin |
| Tính base | N có cặp e tự do. Amid < amin thơm < NH~3~ < amin béo; béo: II > I ≈ III |
| HNO~2~ | I béo: N~2~↑ + alcol (van Slyke) · I thơm: diazoni (0–5 °C) → azo màu · II: nitrosamin vàng (gây ung thư) · III béo: muối nitrit |
| Bậc I | + CHCl~3~/kiềm → isonitril mùi khó chịu (carbylamin) |
| Anilin | + Br~2~ → kết tủa trắng 2,4,6-tribromanilin; + H~2~SO~4~ → acid sulfanilic → sulfamid |
| Điều chế amin | NH~3~ + RX (hỗn hợp bậc); alcol + NH~3~; **khử nitro** (Fe/HCl) cho amin thơm; amid + Br~2~/KOH (mất 1 C) |
| Amid | R–CO–NH~2~; lưỡng tính rất yếu; thủy phân → acid + NH~3~; + HNO~2~ → N~2~ |
| Ure | H~2~N–CO–NH~2~ (carbamid); + 2 HNO~2~ → CO~2~ + 2 N~2~ + 3 H~2~O; + acid malonic → acid barbituric |
| Amino acid | Lưỡng tính, dạng **ion lưỡng cực**; protein chỉ gồm **α-, dãy L** (trừ glycin) |
| pI | Trung tính ≈ 6 (glycin 5,97); acid ≈ 3 (Glu 3,22); base cao (Lys 9,74). pH < pI: (+); pH > pI: (−) |
| Phản ứng amino acid | + HNO~2~ → hydroxy acid + N~2~; khử carboxyl → amin (histamin, GABA…); chuyển amin; peptid; chelat Cu^2+^; **ninhydrin → xanh tím** |
| Liên kết peptid | –CO–NH–; n gốc → n − 1 liên kết; viết từ đầu N → đầu C |
| Amin alcol | Ethanolamin, cholin (amoni bậc IV), acetylcholin (dẫn truyền thần kinh), adrenalin |
