---
title: Danh pháp trong hóa học hữu cơ
thoi-gian: 40 phút
muc-tieu:
- Nêu được đặc điểm của ba loại danh pháp dùng trong hóa hữu cơ: tên riêng, tên thông thường và tên IUPAC.
- Chỉ ra được các thành phần cấu tạo của một công thức (mạch chính, nhánh, nhóm thế, nhóm chức) và ba phần của một tên IUPAC (đầu – thân – đuôi).
- Vận dụng được bảng ghép vần, thứ tự ưu tiên nhóm chức và các quy ước chọn mạch chính, đánh số để gọi tên và viết công thức hợp chất hữu cơ.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Có 3 loại tên: **tên riêng** (theo nguồn gốc: acid formic, ure), **tên thông thường** (theo thuyết gốc, thuyết kiểu: ethyl bromid, phenyl aceton) và **tên IUPAC** (theo cấu tạo, thông qua năm 1957).
> 2. Tên IUPAC = **ĐẦU** (vị trí + số lượng + tên nhánh, nhóm thế, nhóm chức phụ) + **THÂN** (mạch chính) + **ĐUÔI** (độ no + nhóm chức chính). Ví dụ: **5,5-dimethyl | heptan | -2-on**.
> 3. **Mạch chính** phải chứa nhóm chức chính, nhiều liên kết bội nhất và dài nhất; mạch no thì chọn mạch dài nhất.
> 4. **Đánh số** sao cho C mang nhóm chức chính có số nhỏ nhất → rồi đến liên kết bội → rồi đến nhánh.
> 5. **Thứ tự ưu tiên** làm đuôi: –COOH > –CHO > C=O (ceton) > –OH > –SH. Nhóm còn lại đưa lên **đầu**, xếp theo **thứ tự chữ cái** (ethyl trước methyl).

## 1. Khái niệm và phân loại danh pháp

**Danh pháp** là bộ quy tắc đặt tên cho hợp chất hữu cơ. Hiện có thể chia làm ba cách gọi tên: **tên riêng**, **tên thông thường** và **tên IUPAC** (tên quốc tế) (Giáo trình tr. 93).

### 1.1. Tên riêng

Đây là cách gọi **ra đời sớm nhất**, khi người ta chưa biết cấu tạo của các chất. Tên **không dựa vào cấu tạo** mà thường lấy theo nguồn gốc thiên nhiên, nguyên liệu, người tìm ra, hoặc mô tả một tính chất.

| Chất | Tên riêng | Nguồn gốc của tên |
|---|---|---|
| HCOOH | Acid **formic** | Lần đầu chiết từ **con kiến** (tiếng Latin *formica*) |
| CH~3~COOH | Acid **acetic** | Có trong **giấm** (*acetum*) |
| H~2~N–CO–NH~2~ | **Ure** | Tách từ **nước tiểu** (*urine*), năm 1773 |

Ngày nay, nhiều chất đã biết rõ cấu tạo nhưng **cấu tạo quá phức tạp**, nên vẫn dùng tên riêng cho tiện: **hemoglobin**, **vitamin B~12~**, và rất nhiều dược phẩm.

### 1.2. Tên thông thường

Tên thông thường **có dựa vào cấu tạo**, theo một số quy tắc nhất định, nhưng chỉ dùng được cho **chất đơn giản**. Giáo trình nêu hai hệ (tr. 94):

**a) Theo thuyết gốc.** Phân tử được coi là do nhiều **gốc** ghép lại, nên tên là tên các gốc ghép với nhau.

- C~2~H~5~Br = gốc ethyl (–C~2~H~5~) + gốc bromid (–Br) → **ethyl bromid**.
- C~6~H~5~COCl → **benzoyl clorid**.

**b) Theo thuyết kiểu (loại chất).** Chọn một **chất đầu loại** (methan, ethylen…). Các chất khác được coi là sản phẩm **thay thế H** của chất đầu loại bằng các nhóm thế. Tên = tên nhóm thế + tên chất đầu loại.

- (CH~3~)~3~C–C~2~H~5~ → **trimethyl ethyl methan** (methan có 3 H bị thay bằng methyl, 1 H bằng ethyl). Tên IUPAC: **2,2-dimethylbutan**.
- CH~3~–CH=CH–CH~3~ (vẽ dạng cis) → **α,β-dimethyl ethylen** (thay H ở C~α~ và C~β~ của ethylen bằng methyl). Tên IUPAC: **but-2-en**.
- C~6~H~5~CH~2~–CO–CH~3~ → **phenyl aceton** (aceton có một H thay bằng phenyl). Tên IUPAC: **1-phenylpropan-2-on**.

### 1.3. Danh pháp IUPAC

Danh pháp IUPAC là hệ tên gọi **chung cho mọi chất hữu cơ**, lấy **cấu tạo** làm cơ sở. Hệ này do Hiệp hội Hóa học thuần túy và ứng dụng quốc tế (*International Union of Pure and Applied Chemistry*) thông qua năm **1957** (Giáo trình tr. 94).

| | Tên riêng | Tên thông thường | Tên IUPAC |
|---|---|---|---|
| Dựa vào cấu tạo? | **Không** | Có, một phần | **Có, hoàn toàn** |
| Phạm vi | Bất kỳ chất nào | Chất đơn giản | Mọi chất |
| Từ tên viết được công thức? | Không | Với chất đơn giản | **Có** |
| Ví dụ | Acid lactic | Alcol ethylic | Acid 2-hydroxypropanoic |

> [!bay]
> - **Tên riêng không nói gì về cấu tạo.** Đừng suy từ "acid formic" ra công thức, phải học thuộc.
> - Kiểu tên theo **thuyết gốc** (danh pháp loại chức) vẫn được IUPAC chấp nhận cho một số loại chất: ethyl bromid (= bromoethan), ethyl methyl ceton (= butan-2-on), ethyl methyl ether (= methoxyethan). Gặp hai tên này trong đề thì **cả hai đều chỉ cùng một chất**.

## 2. Cấu tạo của hợp chất hữu cơ và tên gọi

### 2.1. Các thành phần trong một công thức

Theo IUPAC, phân tử hữu cơ gồm một **mạch chính** (hoặc **vòng chính**), có thể gắn thêm (Giáo trình tr. 94–95):

- **Nhánh** (mạch nhánh): gốc hydrocarbon như –CH~3~, –C~2~H~5~, –C~6~H~5~.
- **Nhóm thế**: nguyên tử hoặc nhóm **không làm đuôi**, như –Cl, –Br, –NO~2~ (và theo giáo trình cả –NH~2~).
- **Nhóm chức**: nhóm quyết định tính chất hóa học đặc trưng (–OH, –CHO, C=O, –COOH…). Khi có nhiều nhóm chức thì có **một nhóm chức chính**, các nhóm còn lại là **nhóm chức phụ**.

### 2.2. Ba phần của một tên IUPAC

Tên IUPAC phản ánh đủ các thành phần trên, theo thứ tự **đầu – thân – đuôi**:

| Phần | Chứa gì | Ví dụ ở hình 1 |
|---|---|---|
| **Đầu** | Vị trí + số lượng + tên của nhánh, nhóm thế, nhóm chức phụ | 5,5-dimethyl |
| **Thân** | Tên mạch chính hoặc vòng chính (số C) | hept- |
| **Đuôi** | Độ no của mạch (-an, -en, -yn) + nhóm chức chính | -an-2-on |

![Hình 1. Cấu tạo tên IUPAC của 5,5-dimethylheptan-2-on (ví dụ 1 của giáo trình)](cau-tao-ten.svg)

Phân tích ví dụ 1 (Giáo trình tr. 95), CH~3~–CH~2~–C(CH~3~)~2~–CH~2~–CH~2~–CO–CH~3~ (C~9~H~18~O):

- **Thân**: mạch chính có 7 C, không có liên kết bội → **heptan**.
- **Đuôi**: nhóm chức ceton ở C2 → **heptan-2-on**.
- **Đầu**: hai nhánh methyl cùng ở C5 → **5,5-dimethyl**.
- Tên: **5,5-dimethylheptan-2-on**.

Ví dụ 2 và 3 của giáo trình có vòng benzen làm **vòng chính**:

- CH~3~–C~6~H~4~–NH~2~ (CH~3~ và NH~2~ ở hai C kề nhau): giáo trình gọi **2-amino-1-methylbenzen**.
- HO–C~6~H~4~–COOH (hai nhóm ở hai C kề nhau): –COOH là nhóm chức chính, –OH là nhóm chức phụ. Giáo trình gọi **acid 2-hydroxybenzen-1-carboxylic**. Tên IUPAC thường dùng: **acid 2-hydroxybenzoic** (acid salicylic).

> [!vi-du] "Acid … benzen-1-carboxylic" và "acid … benzoic"
> Khi –COOH gắn vào vòng, C của –COOH **không** thuộc vòng. Vì vậy tên có đuôi "-carboxylic" (vòng + COOH). Với vòng benzen, IUPAC giữ tên gọn **acid benzoic** cho C~6~H~5~–COOH. Hai tên chỉ cùng một chất. Tương tự, acid phthalic là **acid benzen-1,2-dicarboxylic**.

## 3. Bảng ghép vần

Giáo trình tóm tắt mọi "mảnh" của tên trong **bảng ghép vần** (tr. 100). Gọi tên chỉ là chọn đúng mảnh rồi ghép theo thứ tự đầu – thân – đuôi. **Số chỉ vị trí đặt ngay trước tên** của mảnh mà nó chỉ.

### 3.1. Thân: tên mạch chính theo số carbon

| Số C | Thân | Số C | Thân |
|---|---|---|---|
| 1 | **meth**- | 6 | **hex**- |
| 2 | **eth**- | 7 | **hept**- |
| 3 | **prop**- | 8 | **oct**- |
| 4 | **but**- | 9 | **non**- |
| 5 | **pent**- | 10 | **dec**- |

- 4 thân đầu (meth, eth, prop, but) là tên riêng còn giữ lại; từ 5 C trở đi dùng gốc số đếm Hy Lạp.
- Mạch **vòng**: thêm **cyclo-** (cyclobutan, cyclopentan, cyclohexan). Vòng thơm 6 C: **benzen**.

### 3.2. Đuôi chỉ độ no của mạch

| Liên kết trong mạch chính | Đuôi | Ví dụ |
|---|---|---|
| Chỉ có C–C | **-an** | propan CH~3~CH~2~CH~3~ |
| Có C=C | **-en** | propen CH~2~=CH–CH~3~ |
| Có C≡C | **-yn** | propyn CH≡C–CH~3~ |
| Có cả C=C và C≡C | **-en-…-yn** | pent-1-en-4-yn |

### 3.3. Tiền tố chỉ số lượng

Khi một nhánh, nhóm thế, nhóm chức hay liên kết bội **lặp lại**, thêm tiền tố số lượng:

| Số lượng | Tiền tố | Ví dụ |
|---|---|---|
| 2 | **di**- | 2,3-dimethyl; -dien; -diol |
| 3 | **tri**- | 2,2,4-trimethyl; -triol |
| 4 | **tetra**- | 1,1,2,2-tetracloroethan |
| 5 | **penta**- | pentacloroethan |
| 6 | **hexa**- | hexaclorobenzen |
| 7, 8, 9, 10 | **hepta**-, **octa**-, **nona**-, **deca**- | |

- Có bao nhiêu nhóm thì phải có **bấy nhiêu số chỉ vị trí**, kể cả khi hai nhóm cùng gắn một C: **2,2**-dimethyl (không viết "2-dimethyl").
- Khi nhóm thế là một gốc phức tạp (đã có số bên trong), dùng **bis-, tris-, tetrakis-** thay cho di-, tri-, tetra-.
- Khi mạch có **nhiều liên kết bội** (-dien, -trien, -diyn), thêm **"a"** sau thân để đọc cho xuôi: **buta**-1,3-dien, **hexa**-1,4-dien. Khi lặp **nhóm chức** thì giữ nguyên tên hydrocarbon: ethan-1,2-diol, propan-1,2,3-triol.

### 3.4. Đầu: tên nhánh và nhóm thế

| Nhóm | Tên làm tiền tố | Ghi chú |
|---|---|---|
| –CH~3~, –C~2~H~5~, –C~3~H~7~ | methyl, ethyl, propyl | Gốc alkyl: đổi **-an** thành **-yl** |
| –CH(CH~3~)~2~ | isopropyl (propan-2-yl) | Gắn qua C giữa |
| –CH=CH~2~ | vinyl (ethenyl) | |
| –CH~2~–CH=CH~2~ | allyl (prop-2-en-1-yl) | |
| –CH=CH–CH~3~ | 1-propenyl (prop-1-en-1-yl) | Theo giáo trình |
| –C~6~H~5~ | phenyl | Vòng benzen làm **nhánh** |
| –C~10~H~7~ | naphthyl | |
| –C~6~H~5~CH~2~– | benzyl | |
| CH~3~O–, C~6~H~5~O– | methoxy, phenoxy | Nhóm ether chỉ làm tiền tố |
| CH~3~CO–, C~6~H~5~CO– | acetyl, benzoyl | Gốc acyl |
| –F, –Cl, –Br, –I | floro, cloro, bromo, iodo | Chỉ làm tiền tố |
| –NO~2~, –NO | nitro, nitroso | Chỉ làm tiền tố |
| –NH~2~ | amino | Giáo trình xếp vào nhóm thế |

> [!bay] Hai chỗ trong bảng của giáo trình dễ đọc nhầm
> - Giáo trình ghi "propynyl" cho **–CH~2~–C≡CH**. Tên IUPAC của gốc này là **prop-2-yn-1-yl** (tên thường: propargyl). Còn "prop-1-yn-1-yl" là gốc **–C≡C–CH~3~**. Số trong tên gốc cho biết liên kết ba nằm ở đâu so với C gắn vào mạch chính.
> - Giáo trình in "cyclopet" là lỗi in; đúng là **cyclopent** (vòng 5 C).

### 3.5. Nhóm chức: tiền tố và hậu tố, thứ tự ưu tiên

Mỗi nhóm chức có **hai cách viết**: làm **đuôi** (hậu tố) khi nó là **nhóm chức chính**, hoặc làm **tiền tố** ở phần đầu khi nó là **nhóm chức phụ**. Nhóm chức chính là nhóm **xếp cao nhất** trong bảng sau (giáo trình: nhóm ở dòng trên trong cột "nhóm chức" của bảng ghép vần, tr. 98, 100).

| Ưu tiên | Nhóm chức | Làm đuôi (chính) | Làm tiền tố (phụ) | Ví dụ |
|---|---|---|---|---|
| 1 (cao nhất) | Acid carboxylic –COOH | acid …**oic** | carboxy- | acid propanoic |
| 2 | Aldehyd –CHO | …**al** | aldo- (IUPAC: oxo-, formyl-) | propanal |
| 3 | Ceton C=O | …**on** | ceto- (IUPAC: **oxo-**) | propan-2-on |
| 4 | Alcol –OH | …**ol** | hydroxy- | propan-1-ol |
| 5 | Thiol –SH | …**thiol** | mercapto- (IUPAC: sulfanyl-) | ethanthiol |

**Mẹo nhớ thứ tự.** Đây là quy ước của IUPAC, nhưng dễ nhớ theo **mức oxy hóa** của C mang nhóm chức: C của –COOH có 3 liên kết với O; C của –CHO và của ceton có 2; C của –OH có 1. Nhóm có C bị oxy hóa nhiều hơn xếp trước. Aldehyd và ceton cùng mức, IUPAC quy ước aldehyd đứng trước.

> [!bay] Đuôi acid, aldehyd tính cả C của nhóm chức
> - Trong **acid …oic** và **…al**, C của –COOH hoặc –CHO **thuộc mạch chính** và luôn là **C1**. Vì vậy không cần ghi số 1: viết **propanal**, không viết "propan-1-al".
> - Ngược lại, ceton và alcol phải ghi số vị trí khi có thể ở nhiều vị trí: **butan-2-on**, **propan-2-ol**.
> - Hai đầu đều là –COOH: **acid butandioic** HOOC–CH~2~–CH~2~–COOH (acid succinic), 4 C tính cả hai C của –COOH.

> [!cap-nhat] Bảng ưu tiên đầy đủ hơn và tiền tố hiện hành
> Bảng ghép vần của giáo trình chỉ có 5 nhóm chức chính. Theo IUPAC hiện nay (khuyến nghị 2013), thứ tự ưu tiên giảm dần là:
> **acid carboxylic > anhydrid > ester > halogenid acid > amid > nitril > aldehyd > ceton > alcol, phenol > thiol > amin > imin**.
> - **Amin** cũng làm đuôi được: C~2~H~5~NH~2~ là **ethanamin**, C~6~H~5~NH~2~ là **anilin** (benzenamin). Giáo trình gọi "amino ethan", "amino benzen".
> - Nhóm **chỉ** làm tiền tố, không bao giờ làm đuôi: halogen (cloro…), nitro, nitroso, ether (methoxy…).
> - Tiền tố đúng của C=O ceton là **oxo-** (không phải "ceto-"); của –SH là **sulfanyl-** (tên cũ mercapto-); của –OH là **hydroxy-** (không viết "oxy-").
>
> Đi thi môn này, trả lời theo bảng ghép vần của giáo trình.

## 4. Chọn mạch chính và đánh số

### 4.1. Hydrocarbon no

**Chọn mạch chính**: giáo trình ghi mạch chính là mạch **có nhiều nhánh nhất và dài nhất**. **Đánh số**: C1 là C ở đầu **gần nhánh nhất** (Giáo trình tr. 96).

| Ví dụ (giáo trình) | Công thức | Tên |
|---|---|---|
| Ví dụ 4 | CH~3~–CH(CH~3~)–CH~2~–CH~3~ | **2-methylbutan** |
| Ví dụ 5 | CH~3~–CH~2~–CH(C~2~H~5~)–CH(CH~3~)–CH~2~–CH~3~ | Giáo trình: **4-ethyl-3-methylhexan** |
| Ví dụ 6 | CH~3~–CH(CH~3~)–CH(CH~3~)–CH~2~–CH(C~2~H~5~)–CH~2~–CH~3~ | **5-ethyl-2,3-dimethylheptan** |

- **Hai nhánh ở vị trí cân đối** (ví dụ 5: đánh số từ đầu nào cũng được bộ số 3,4): giáo trình chọn số 1 ở đầu gần **nhánh đơn giản hơn** (methyl).
- **Nhiều nhánh** (ví dụ 6): đánh số sao cho bộ số chỉ vị trí **nhỏ nhất**. Giáo trình dùng "**tổng** nhỏ nhất": 2 + 3 + 5 = 10, còn đánh ngược lại được 3-ethyl-5,6-dimethylheptan, tổng 14.
- **Thứ tự viết** các nhánh trong tên: theo **thứ tự chữ cái** của tên nhánh (ethyl viết trước methyl). Tiền tố số lượng di-, tri- **không tính** khi xếp chữ cái: "**e**thyl" trước "di**m**ethyl".

> [!bay] Mạch dài nhất có thể "rẽ" qua nhánh
> Công thức viết thẳng hàng **chưa chắc** là mạch chính. Ví dụ CH~3~–CH(C~2~H~5~)–CH~2~–CH~3~: nhìn qua tưởng là "2-ethylbutan". Nhưng đi qua nhánh ethyl thì mạch dài **5 C**. Tên đúng: **3-methylpentan**.
> Dấu hiệu nhận ra tên sai: **"1-methyl", "2-ethyl", "3-propyl"…** trên mạch hở. Nhánh như vậy luôn có thể nối dài vào mạch chính.

> [!cap-nhat] Giáo trình dùng quy tắc cũ ở ba điểm
> 1. **Chọn mạch**: IUPAC chọn mạch **dài nhất trước**; chỉ khi có nhiều mạch dài bằng nhau mới chọn mạch **nhiều nhánh hơn**.
> 2. **Bộ số nhỏ nhất** không phải "tổng nhỏ nhất" mà là quy tắc **điểm khác biệt đầu tiên**: so từng số theo thứ tự, bộ nào có số nhỏ hơn ở chỗ khác nhau đầu tiên thì thắng. Hai cách thường cho cùng kết quả (như ví dụ 6), nhưng có lúc khác nhau. Ví dụ decan có ba nhánh methyl: bộ (2,7,8) có tổng 17, bộ (3,4,9) có tổng 16. Theo IUPAC vẫn chọn **2,7,8-trimethyldecan** vì 2 < 3.
> 3. **Hai nhánh cân đối**: IUPAC cho số nhỏ hơn cho nhóm **đứng trước theo chữ cái**, không xét "đơn giản hơn". Ví dụ 5 vì vậy có tên IUPAC là **3-ethyl-4-methylhexan** (ethyl đứng trước methyl theo chữ cái nên nhận số 3).
>
> Đi thi môn này, làm theo giáo trình. Khi đọc tài liệu Hóa dược, Dược điển, tên viết theo quy tắc IUPAC hiện hành.

### 4.2. Hydrocarbon không no

- **Mạch chính** là mạch có **nhiều liên kết bội nhất** và dài nhất. **C1** là C ở đầu **gần liên kết bội** (Giáo trình tr. 96).
- Ví dụ 7: CH~3~–CH=CH–CH(CH~3~)–CH=CH~2~ → đánh số từ đầu =CH~2~: **3-methylhexa-1,4-dien** (C~7~H~12~).
- **Có cả liên kết đôi và ba**: C1 ở đầu gần **liên kết đôi** (tr. 97). Ví dụ 8: CH~2~=CH–CH~2~–C≡CH → **pent-1-en-4-yn** (giáo trình viết kiểu cũ "1-penten-4-yn"). Trong tên, "-en" luôn viết **trước** "-yn".

> [!cap-nhat] Theo IUPAC, liên kết đôi chỉ được ưu tiên khi "hòa"
> Giáo trình viết gọn: "có cả liên kết đôi và ba thì số 1 ở đầu gần liên kết đôi". Quy tắc đầy đủ của IUPAC: trước hết, **tất cả các liên kết bội** (cả đôi lẫn ba) phải nhận bộ số **nhỏ nhất**. Chỉ khi hai cách đánh số cho **cùng bộ số** mới ưu tiên liên kết đôi.
> - Ví dụ 8: hai chiều đều cho bộ (1,4) → hòa → liên kết đôi nhận số 1: pent-**1-en-4-yn**. Ở ví dụ này hai cách hiểu cho cùng kết quả.
> - CH~3~–CH=CH–C≡CH: đánh từ đầu C≡CH được bộ (1,3); đánh từ đầu CH~3~ được (2,4). Theo IUPAC hiện hành, bộ (1,3) nhỏ hơn → **pent-3-en-1-yn**, dù C1 lại gần liên kết ba. Áp dụng đúng câu chữ của giáo trình thì ra *pent-2-en-4-yn*.
>
> Đi thi môn này, nếu đề hỏi theo giáo trình thì đánh số từ đầu gần liên kết đôi; khi đọc tài liệu Hóa dược, Dược điển, tên viết theo quy tắc IUPAC hiện hành.

> [!cap-nhat] Mạch chính của hydrocarbon không no
> Từ khuyến nghị IUPAC 2013, mạch chính được chọn theo **độ dài trước**, rồi mới xét số liên kết bội (ngược với giáo trình). Ví dụ CH~2~=C(C~2~H~5~)–CH~2~CH~2~CH~3~: theo quy tắc cũ (giáo trình, SGK phổ thông) là **2-ethylpent-1-en**. Theo IUPAC 2013 là 3-methylidenhexan. Đa số sách giáo khoa Việt Nam vẫn dùng quy tắc cũ; đi thi dùng tên **2-ethylpent-1-en**.

### 4.3. Hợp chất mạch vòng

- **Vòng là mạch chính**. Số 1 dành cho C vòng mang **nhánh đơn giản nhất**; các số tiếp theo theo quy tắc số nhỏ nhất (Giáo trình tr. 97).
  - Ví dụ 9: giáo trình gọi **3-ethyl-1-methylcyclohexan**, **1-methyl-3-propylbenzen**, **2-ethyl-1-methylnaphthalen**.
- **Nhiều vòng rời rạc** nối với nhau qua mạch thẳng: **mạch thẳng là mạch chính**, các vòng là nhánh. Ví dụ 10: C~6~H~5~–CH~2~–C~6~H~5~ → **diphenylmethan**.
- **Vòng có nhóm thế, nhóm chức**: giáo trình đặt số 1 ở C vòng gắn với nhánh/nhóm có **nguyên tử gắn vào vòng nhẹ hơn**. Ví dụ 11: vòng benzen mang 2 nhóm CH~3~ kề nhau và một –NH~2~ → giáo trình gọi **4-amino-1,2-dimethylbenzen** (số 1 cho C gắn –CH~3~ vì C nhẹ hơn N).

> [!cap-nhat] Đánh số vòng theo IUPAC hiện hành
> - Vòng chỉ có các nhánh, hai cách đánh cho cùng bộ số: số 1 cho nhánh **đứng trước theo chữ cái** (không phải nhánh "đơn giản nhất"). Ví dụ 9a theo IUPAC là **1-ethyl-3-methylcyclohexan**. (Với ví dụ 9b, methyl đứng trước propyl theo chữ cái nên tên giáo trình vẫn đúng.)
> - Vòng có **nhóm chức làm đuôi** (–OH, –NH~2~, –COOH…): C mang nhóm chức chính **luôn là C1**. Quy tắc "nguyên tử nhẹ hơn" không có trong IUPAC. Ví dụ 11 có –NH~2~ là nhóm chức chính, nên tên IUPAC là **3,4-dimethylanilin** (3,4-dimethylbenzenamin). Ví dụ 2 là **2-methylanilin** (o-toluidin).
> - IUPAC giữ các tên gọn của dẫn xuất benzen: **toluen** (C~6~H~5~CH~3~), **phenol** (C~6~H~5~OH), **anilin** (C~6~H~5~NH~2~), **acid benzoic** (C~6~H~5~COOH). Giáo trình (phần đáp án) dùng song song "methylbenzen, hydroxybenzen, aminobenzen".

**Mạch nhiều vòng ghép, có cầu.** Ví dụ 12 của giáo trình (tr. 98) chính là **long não** (camphor, C~10~H~16~O): **1,7,7-trimethylbicyclo[2.2.1]heptan-2-on**.

- **bicyclo**: khung có **2 vòng** dùng chung hai C "đầu cầu" (C1 và C4).
- **heptan**: tổng số C của khung là **7**, không có liên kết bội.
- **[2.2.1]**: số C ở **ba cầu** nối hai đầu cầu, viết từ lớn đến nhỏ: cầu C2–C3 (2 C), cầu C5–C6 (2 C), cầu C7 (1 C). Kiểm tra: 2 + 2 + 1 + 2 đầu cầu = **7** ✓.
- **2-on**: ceton ở C2. **1,7,7-trimethyl**: ba nhánh methyl, một ở C1 và hai ở C7.
- Cách đánh số: bắt đầu từ một đầu cầu (C1), đi theo **cầu dài nhất** sang đầu cầu kia (C4), đi tiếp cầu dài thứ hai quay về, cuối cùng đánh số **cầu ngắn nhất** (C7).

### 4.4. Hợp chất có nhóm thế, nhóm chức

- Mạch chính phải **chứa nhóm chức chính**. Số 1 ở đầu **gần nhóm chức chính** (Giáo trình tr. 98).
  - Ví dụ 13: CH~3~–CH~2~–CH(Cl)–CH~2~–CH~2~–OH → **3-cloropentan-1-ol** (giáo trình viết "3-cloro pentanol"). Đánh số từ C mang –OH; –Cl chỉ là nhóm thế.
- **Từ hai nhóm chức trở lên**: nhóm **đứng trên** trong bảng ưu tiên là **nhóm chức chính** (làm đuôi); các nhóm khác là **nhóm chức phụ** (làm tiền tố).
  - Ví dụ 14: CH~3~–CH~2~–CH(OH)–CH~2~–COOH → **acid 3-hydroxypentanoic**. –COOH là nhóm chức chính (C1), –OH ở C3 thành tiền tố hydroxy-.

> [!vi-du] Quy tắc đánh số gộp lại (theo thứ tự xét)
> Số nhỏ nhất lần lượt dành cho:
> 1. Nhóm chức **chính** (đuôi).
> 2. **Liên kết bội** (IUPAC: cả đôi và ba xét chung, hòa thì ưu tiên liên kết đôi; giáo trình: số 1 ở đầu gần liên kết đôi).
> 3. Tất cả **nhánh, nhóm thế, nhóm chức phụ** (xét chung, bộ số nhỏ nhất).
> 4. Còn hòa: nhóm **đứng trước theo chữ cái** nhận số nhỏ hơn (giáo trình: nhánh đơn giản hơn).
>
> Ví dụ: CH~2~=CH–CH~2~–OH. Nhóm chức chính –OH quyết định C1 = C mang OH, dù liên kết đôi lúc đó ở C2: **prop-2-en-1-ol** (alcol allylic).

## 5. Gọi tên từng bước — ví dụ mẫu

**Quy trình 5 bước**

1. **Tìm nhóm chức chính** (xem bảng 3.5) → biết **đuôi**. Các nhóm còn lại là tiền tố.
2. **Chọn mạch chính**: chứa nhóm chức chính → nhiều liên kết bội nhất → dài nhất → nhiều nhánh nhất.
3. **Đánh số** mạch chính theo thứ tự ưu tiên ở mục 4.4.
4. **Gọi tên phần đầu**: số vị trí + tiền tố số lượng + tên nhánh/nhóm thế; xếp theo **chữ cái**.
5. **Ghép tên**: đầu + thân + đuôi. **Số với số** ngăn bằng **dấu phẩy**, **số với chữ** ngăn bằng **gạch nối**; tiền tố viết **liền** với thân.

**Cuối cùng: đếm lại C** của tên vừa gọi (thân + các nhánh) và so với công thức. Chênh nhau là sai.

> [!vi-du] Ví dụ A — Tự lượng giá 2.2a: CH~3~–C(CH~3~)=CH–C(CH~3~)~2~–CH~2~–OH
> 1. Nhóm chức chính: **–OH** → đuôi **-ol**.
> 2. Mạch chính chứa C mang –OH và liên kết đôi: HO–CH~2~–C–CH=C–CH~3~ → **5 C** (pent-).
> 3. Đánh số từ C mang –OH: C1 (CH~2~OH), C2 (C mang 2 CH~3~), C3=C4, C4 mang 1 CH~3~, C5.
> 4. Nhánh: methyl ở 2, 2, 4 → **2,2,4-trimethyl**.
> 5. Tên: **2,2,4-trimethylpent-3-en-1-ol**.
>
> Đếm C: 5 + 3 = **8**; công thức C~8~H~16~O ✓.

> [!vi-du] Ví dụ B — Tự lượng giá 2.2c: CH~3~–CH(CH~3~)–CH~2~–CO–CH~2~–CHO
> 1. Có –CHO và C=O ceton. **–CHO** đứng trên → đuôi **-al**; ceton thành tiền tố.
> 2. Mạch chính 6 C (hex-), no.
> 3. C1 = C của –CHO. Ceton ở C3, nhánh methyl ở C5.
> 4. Đầu: **5-methyl** và **3-oxo** (giáo trình: 3-ceto). Xếp chữ cái: methyl (m) trước oxo (o).
> 5. Tên: **5-methyl-3-oxohexanal** (giáo trình: 5-methyl-3-cetohexanal). Đếm C: 6 + 1 = 7 ✓ (C~7~H~12~O~2~).

> [!vi-du] Ví dụ C — Tự lượng giá 2.2d: CH~3~–CH(SH)–CH~2~–CH(Cl)–CH~2~OH
> - –OH xếp trên –SH → đuôi **-ol**; –SH thành tiền tố mercapto- (sulfanyl-), –Cl là nhóm thế cloro-.
> - C1 = C mang –OH: Cl ở C2, SH ở C4. Xếp chữ cái: **c**loro trước **m**ercapto.
> - Tên: **2-cloro-4-mercaptopentan-1-ol** (IUPAC hiện hành: 2-cloro-4-sulfanylpentan-1-ol).

> [!vi-du] Ví dụ D — Từ tên viết công thức: acid 2-hydroxypropan-1,2,3-tricarboxylic
> - Thân **propan**: 3 C. Đuôi **-1,2,3-tricarboxylic**: mỗi C mang **một –COOH**, và C của –COOH **không** tính vào 3 C của propan.
> - **2-hydroxy**: thêm –OH ở C2.
> - Công thức: **HOOC–CH~2~–C(OH)(COOH)–CH~2~–COOH** = **acid citric** (C~6~H~8~O~7~), có nhiều trong chanh, cam. Đếm C: 3 + 3 = 6 ✓.

> [!bay] Lỗi hay gặp khi viết tên
> - Quên số chỉ vị trí khi có thể nhầm: "butanol" chưa đủ, phải là butan-**1**-ol hoặc butan-**2**-ol.
> - Không đủ số vị trí cho tiền tố số lượng: "2-dimethyl" ✗ → **2,2-dimethyl** ✓.
> - Xếp chữ cái tính cả "di", "tri": "dimethyl" trước "ethyl" ✗ → **ethyl** trước **dimethyl** ✓.
> - Đánh số mạch chính chỉ vì nhánh mà bỏ qua nhóm chức chính ✗.
> - Gọi "acid … al" hoặc vừa "acid" vừa "-ol" ở đuôi ✗: mỗi tên chỉ có **một** nhóm chức chính làm đuôi. (Đề 2.3c "acid 3-oxy-3-methyl-4-pentenal" của giáo trình mắc lỗi này, xem phần đáp án.)

## 6. Tên IUPAC của hoạt chất dược liệu và thuốc

Biết danh pháp, có thể "đọc" được cấu tạo của các hoạt chất quen thuộc từ tên của chúng.

![Hình 2. Tên IUPAC của bốn hoạt chất tinh dầu, có đánh số mạch chính hoặc vòng chính](tinh-dau.svg)

| Hoạt chất (dược liệu) | Tên IUPAC | Nhóm chức chính → đuôi | CTPT |
|---|---|---|---|
| **Citral a** (Sả, Màng tang) | (2E)-3,7-dimethylocta-2,6-dienal | Aldehyd → **-al** | C~10~H~16~O |
| **Geraniol** (tinh dầu hoa hồng, Sả) | (2E)-3,7-dimethylocta-2,6-dien-1-ol | Alcol → **-ol** | C~10~H~18~O |
| **Menthol** (Bạc hà) | 5-methyl-2-(propan-2-yl)cyclohexan-1-ol | Alcol → **-ol** | C~10~H~20~O |
| **Long não** (camphor) | 1,7,7-trimethylbicyclo[2.2.1]heptan-2-on | Ceton → **-on** | C~10~H~16~O |
| **Eugenol** (Đinh hương, Hương nhu) | 2-methoxy-4-(prop-2-en-1-yl)phenol | Phenol → **phenol** | C~10~H~12~O~2~ |
| **Cinnamaldehyd** (Quế) | (2E)-3-phenylprop-2-enal | Aldehyd → **-al** | C~9~H~8~O |
| **Anethol** (Hồi) | 1-methoxy-4-[(1E)-prop-1-en-1-yl]benzen | Không có nhóm làm đuôi (ether) → **benzen** | C~10~H~12~O |
| **Vanilin** (Vani) | 4-hydroxy-3-methoxybenzaldehyd | Aldehyd → **-aldehyd**; –OH thành hydroxy- | C~8~H~8~O~3~ |

Chú thích: (2E), (1E) là ký hiệu cấu hình của liên kết đôi (xem bài *Cấu trúc phân tử hợp chất hữu cơ — đồng phân* (hc-01), mục 5). Tên menthol trong bảng chưa ghi cấu hình của 3 C\*.

> [!bay] Vài điểm đọc tên trong bảng
> - **Menthol**: đuôi -ol nên C mang –OH là **C1**. Đánh tiếp về phía nhánh isopropyl (C2) để bộ số nhánh là (2,5), nhỏ hơn (3,6). "**m**ethyl" viết trước "(**p**ropan-2-yl)" theo chữ cái. Dùng tên "isopropyl" thì viết 2-isopropyl-5-methylcyclohexan-1-ol (i trước m). Hai tên cùng chỉ một chất.
> - **Vanilin**: có cả –CHO và –OH. –CHO xếp trên → đuôi "-aldehyd" (vòng + CHO); –OH thành tiền tố **hydroxy-**.
> - **Anethol**: nhóm ether (–OCH~3~) **không** làm đuôi được, nên tên chỉ là "…benzen" với tiền tố methoxy-.

> [!yhct] Tinh dầu và tên hóa học của chúng
> - Các vị thuốc **cay, ấm, thơm** (Quế, Đinh hương, Hồi, Sả, Bạc hà, Hương nhu) có hoạt chất chính là các chất trong bảng trên. Phần lớn chúng là **monoterpen** (10 C, như citral, geraniol, menthol, long não) hoặc **phenylpropanoid** (vòng benzen + mạch 3 C, như eugenol, anethol, cinnamaldehyd). Đọc tên IUPAC thấy ngay: "**octa**-…-dien + 2 methyl" = 10 C; "**phenyl** + **prop**" = khung C~6~–C~3~.
> - Nhóm chức trong tên giúp hiểu **tính chất bào chế**: tinh dầu dễ bay hơi nên các vị này thường cho **sau** (hậu hạ) khi sắc, hoặc tán bột, ngâm rượu; aldehyd (citral, cinnamaldehyd) dễ bị **oxy hóa** khi để lâu ngoài không khí, nên dược liệu cần bảo quản kín.
> - **Long não** (*Cinnamomum camphora*, tinh thể còn gọi là Chương não): chủ yếu **dùng ngoài** (dầu xoa, cao xoa giảm đau, sát trùng). **Không uống**: long não hấp thu nhanh, có thể gây **co giật**, nhất là ở **trẻ nhỏ**, kể cả khi nuốt lượng ít. Không bôi dầu chứa long não, menthol đậm đặc gần mũi trẻ nhỏ.
> - Tác dụng kháng khuẩn, giảm đau tại chỗ của eugenol (dùng trong nha khoa), của cinnamaldehyd và citral đã được ghi nhận nhiều trên **thực nghiệm**. Bằng chứng lâm sàng cho các chỉ định dùng đường uống còn hạn chế; dùng đúng liều, đúng chứng.

> [!ung-dung] Một thuốc, nhiều tên: vì sao bác sĩ cần đọc được tên hóa học
> | Loại tên | Paracetamol | Aspirin |
> |---|---|---|
> | Tên IUPAC | N-(4-hydroxyphenyl)acetamid | Acid 2-(acetyloxy)benzoic |
> | Tên chung quốc tế (INN) | Paracetamol (Mỹ: acetaminophen) | Acid acetylsalicylic |
> | Tên biệt dược (ví dụ) | Panadol, Efferalgan, Hapacol… | Aspirin pH8… |
>
> - Tên IUPAC cho biết cấu tạo: paracetamol có nhóm **phenol** (–OH ở vị trí 4) và nhóm **amid**; aspirin có nhóm **acid** (đuôi -oic) và nhóm **ester** (tiền tố acetyloxy-), là ester của acid salicylic (acid 2-hydroxybenzoic).
> - Nhiều biệt dược khác tên nhưng **cùng một hoạt chất**. Người bệnh dùng cùng lúc thuốc hạ sốt và thuốc cảm phối hợp đều chứa paracetamol có thể **quá liều**, gây **hoại tử gan**. Kê đơn và tư vấn luôn dựa trên **tên hoạt chất**, không dựa trên tên biệt dược.
> - Một chữ khác nhau là một chất khác: **methanol** (CH~3~OH, rượu giả, gây mù và tử vong) khác **ethanol** (C~2~H~5~OH).

## Tóm tắt

| Nội dung | Điểm cần nhớ |
|---|---|
| Ba loại tên | Tên riêng (nguồn gốc, không theo cấu tạo) · tên thông thường (thuyết gốc, thuyết kiểu; chất đơn giản) · IUPAC (cấu tạo, 1957, mọi chất) |
| Cấu trúc tên | **Đầu** (vị trí – số lượng – nhánh, nhóm thế, nhóm chức phụ) + **thân** (số C mạch chính) + **đuôi** (an/en/yn + nhóm chức chính) |
| Thân | meth, eth, prop, but, pent, hex, hept, oct, non, dec; vòng: cyclo-; benzen |
| Tiền tố số lượng | di, tri, tetra, penta, hexa…; mỗi nhóm một số vị trí (2,2-dimethyl) |
| Ưu tiên nhóm chức (sách) | –COOH (oic) > –CHO (al) > C=O (on) > –OH (ol) > –SH (thiol) |
| Chọn mạch chính | Chứa nhóm chức chính → nhiều liên kết bội → dài nhất → nhiều nhánh |
| Đánh số | Nhóm chức chính → liên kết bội (sách: gần nối đôi; IUPAC: bộ số nhỏ nhất, hòa thì ưu tiên nối đôi) → nhánh (bộ số nhỏ nhất) |
| Viết tên | Nhánh theo chữ cái (không tính di, tri); số–số dấu phẩy, số–chữ gạch nối |
| Vòng | Vòng là mạch chính; nhiều vòng rời → mạch thẳng là chính (diphenylmethan); cầu: bicyclo[x.y.z] |
| Kiểm tra | Đếm lại số C của tên so với công thức |

> [!vi-du] Đáp án Tự lượng giá (tr. 99) và lưu ý về phần hướng dẫn cuối sách (tr. 250–251)
> **2.1** (tên IUPAC; tên thường):
> a) propanal; aldehyd propionic · b) propanamid · c) acid butandioic (sách: butan-1,4-dioic); acid succinic · d) butan-2-on; ethyl methyl ceton · e) ethan-1,2-diol; ethylen glycol · f) methoxyethan (sách: ethyl methyl ether) · g) ethanamin (sách: amino ethan); ethylamin · h) acid 2-hydroxypropanoic; acid lactic · i) buta-1,3-dien · k) acid propenoic; acid acrylic · l) acid aminoethanoic; glycin · m) methylbenzen; toluen · n) phenol (sách: hydroxybenzen) · p) anilin (sách: aminobenzen) · q) acid 2-hydroxybenzoic; acid salicylic · r) (2-methylphenyl)methanol; alcol 2-methylbenzylic (sách ghi "toluyl methanol", không chuẩn) · s) cyclohexanol · t) diphenylmethan · u) naphthalen-1-ol (sách: 1-hydroxynaphthalen); α-naphthol · **v) acid benzoic** · **x) cyclohexen**. Hướng dẫn cuối sách ghi "v) cyclohexen" và bỏ sót chất benzoic: có lẽ nhảy nhầm một chữ cái.
>
> **2.2**: a) 2,2,4-trimethylpent-3-en-1-ol · b) acid 2-amino-4-hydroxypentanoic · c) 5-methyl-3-oxohexanal (sách: 5-methyl-3-cetohexanal) · d) 2-cloro-4-mercaptopentan-1-ol.
>
> **2.3**: a) 1,2-(CH~3~O)~2~C~6~H~4~ (veratrol) · b) CH~3~–CH(CH~3~)–CH~2~–CO–CH~2~–CHO (chính là chất 2.2c) · c) tên trong đề "acid 3-oxy-3-methyl-4-pentenal" **không hợp lệ**: vừa "acid" vừa đuôi "-al", và C3 không thể vừa mang C=O vừa mang CH~3~ (vượt hóa trị IV). Đáp án sách vẽ CH~2~=CH–CO–CH(CH~3~)–CHO, tên đúng của chất này là **2-methyl-3-oxopent-4-enal** · d) CH~3~–CH(OH)–CH~2~–CH~2~–COOH · e) HO–CH~2~–CH(NH~2~)–COOH = **serin** (tên đúng: acid 2-amino-3-hydroxypropanoic; "oxy" trong đề là cách viết sai của hydroxy) · f) HS–CH~2~–CH(NH~2~)–COOH = **cystein** · g) acid benzen-1,2-dicarboxylic = **acid phthalic**, hai –COOH ở hai C kề nhau của vòng benzen · h) HOOC–CH~2~–C(OH)(COOH)–CH~2~–COOH = **acid citric** (xem Ví dụ D). Phần hướng dẫn cuối sách không có đáp án cho g và h.
