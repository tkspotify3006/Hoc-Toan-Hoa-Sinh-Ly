---
title: Cấu trúc phân tử hợp chất hữu cơ — đồng phân
thoi-gian: 45 phút
muc-tieu:
- Xác định được trạng thái lai hóa (sp³, sp², sp) của từng nguyên tử carbon trong một công thức cấu tạo.
- Chỉ ra được các liên kết σ, π và góc liên kết tương ứng trong một phân tử cho trước.
- Phân biệt được ba khái niệm cấu tạo, cấu dạng và cấu hình.
- Phân biệt được đồng phân mạch carbon, đồng phân vị trí và đồng phân nhóm chức.
- Viết được công thức các đồng phân cis–trans và nêu điều kiện để có loại đồng phân này.
- Xác định được C\*, viết được công thức chiếu Fischer của các đồng phân D, L, meso; hiểu ý nghĩa của đồng phân lập thể trong dược học.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Carbon dùng orbital **lai hóa**: **sp³** (tứ diện, 109°28′), **sp²** (phẳng, 120°, còn 1 p tạo **π**), **sp** (thẳng, 180°, còn 2 p tạo **2 π**).
> 2. Liên kết đơn quay tự do → nhiều **cấu dạng**; dạng **xen kẽ** (ethan), **đối** (butan), **ghế** (cyclohexan) bền nhất.
> 3. **Đồng phân** = cùng công thức phân tử, khác cấu trúc. Hai loại lớn: **cấu tạo** (mạch C, vị trí, nhóm chức) và **lập thể** (hình học, quang học).
> 4. **Cis–trans** cần một bộ phận "cứng" (C=C, vòng) và mỗi C ở đó mang **hai nhóm khác nhau**.
> 5. **C\*** gắn 4 nhóm khác nhau; n C\* → tối đa **2^n^** đồng phân quang học. Hai C\* giống nhau → có dạng **meso** (không quang hoạt). Đồng lượng hai đối quang → **racemic**.

## 1. Cấu trúc electron của carbon và sự lai hóa

### 1.1. Vì sao carbon hóa trị IV?

Carbon có Z = 6, cấu hình electron **1s^2^ 2s^2^ 2p^2^**. Ở **trạng thái cơ bản**, C chỉ có **2 electron độc thân** (hai electron 2p), nên lẽ ra chỉ có hóa trị II.

Thực tế trong hầu hết hợp chất hữu cơ, C có **hóa trị IV**. Lý do: khi tham gia phản ứng, C nhận năng lượng (giáo trình ghi khoảng **96,4 kcal/mol**). Cặp electron 2s tách ra, một electron nhảy lên orbital 2p còn trống. Lúc này C có **4 electron độc thân**: 2s^1^ 2p^3^. Đây là **trạng thái kích thích**, ký hiệu C\*.

> [!vi-du] Vì sao "bỏ năng lượng ra" vẫn có lợi?
> Năng lượng kích thích bị tiêu tốn, nhưng C tạo thêm được **2 liên kết**. Mỗi liên kết tạo thành lại giải phóng năng lượng. Tổng cộng phân tử có 4 liên kết bền hơn hẳn phân tử chỉ có 2 liên kết.
>
> *Lưu ý ký hiệu:* trong mục này, C\* là carbon ở **trạng thái kích thích**. Ở mục 6, C\* lại là **carbon bất đối**. Giáo trình dùng chung ký hiệu cho hai khái niệm khác nhau.

### 1.2. Lai hóa là gì?

Khi tạo liên kết, orbital 2s **trộn** với 1, 2 hoặc 3 orbital 2p. Kết quả là những **orbital lai hóa** giống hệt nhau về hình dạng, kích thước, năng lượng; chúng chỉ khác nhau về **hướng** trong không gian. Các orbital này đẩy nhau ra xa nhất có thể, vì vậy mỗi kiểu lai hóa có một góc liên kết riêng (Giáo trình tr. 74).

![Hình 1. Ba trạng thái lai hóa của carbon và góc liên kết](lai-hoa.svg)

| | **sp³** (lai hóa tứ diện) | **sp²** (lai hóa tam giác) | **sp** (lai hóa đường thẳng) |
|---|---|---|---|
| Orbital tham gia | 1 s + 3 p | 1 s + 2 p | 1 s + 1 p |
| Số orbital lai hóa | 4 | 3 | 2 |
| p chưa lai hóa còn lại | 0 | 1 (vuông góc mặt phẳng) | 2 (vuông góc với nhau và với trục) |
| Hình dạng, góc | Tứ diện đều, **109°28′** | Tam giác phẳng, **120°** | Đường thẳng, **180°** |
| Liên kết tạo được | 4 σ | 3 σ + 1 π | 2 σ + 2 π |
| Ví dụ | CH~4~, C~2~H~6~ | C~2~H~4~ | C~2~H~2~ |

### 1.3. Lai hóa sp³ — methan, ethan

- **Methan CH~4~**: 4 orbital sp³ của C xen phủ **trục** với 4 orbital 1s của H, tạo **4 liên kết σ hoàn toàn giống nhau**.
- **Ethan C~2~H~6~**: mỗi C dùng 3 orbital sp³ nối với 3 H, orbital sp³ còn lại nối với C kia. Tổng cộng **7 liên kết σ**: 6 liên kết kiểu **s–sp³** và 1 liên kết kiểu **sp³–sp³** (Giáo trình tr. 75).

### 1.4. Lai hóa sp² — ethylen

- Mỗi C trong **ethylen C~2~H~4~** có 3 orbital sp² nằm trên **một mặt phẳng**, góc 120°. Hai orbital nối với 2 H (σ kiểu **s–sp²**), orbital thứ ba nối với C kia (σ kiểu **sp²–sp²**). Ethylen có **5 liên kết σ** cùng nằm trên một mặt phẳng.
- Mỗi C còn **1 orbital 2p** chưa lai hóa, trục vuông góc với mặt phẳng trên. Hai orbital p này **xen phủ bên** với nhau, tạo **liên kết π**.
- Vậy **liên kết đôi C=C = 1 σ + 1 π**.

### 1.5. Lai hóa sp — acetylen

- Mỗi C trong **acetylen C~2~H~2~** có 2 orbital sp thẳng hàng (180°): một orbital nối với H (σ **s–sp**), một orbital nối với C kia (σ **sp–sp**).
- Mỗi C còn **2 orbital p** chưa lai hóa, vuông góc với nhau. Chúng xen phủ bên từng đôi một, tạo **2 liên kết π**.
- Vậy **liên kết ba C≡C = 1 σ + 2 π**. Acetylen có 3 σ và 2 π.

Liên kết π không chỉ có giữa hai C. Nó còn hình thành giữa C với các nguyên tố khác như **O, N**: C=O (aldehyd, ceton, acid), C=N, C≡N (Giáo trình tr. 76).

> [!bay] Phân biệt σ và π
> - **σ**: orbital xen phủ **dọc trục** nối hai hạt nhân; vùng xen phủ lớn nên **bền**; quay quanh trục σ **không** làm đứt liên kết.
> - **π**: hai orbital p xen phủ **bên**, ở trên và dưới trục; xen phủ ít nên **kém bền hơn σ**, dễ tham gia phản ứng cộng. Muốn quay quanh liên kết π thì phải **phá** vùng xen phủ, vì vậy **quanh C=C không quay tự do được**. Đây chính là gốc rễ của đồng phân cis–trans (mục 5).
> - Liên kết đôi hay ba **luôn chỉ có một σ**; các liên kết còn lại là π.

> [!vi-du] Cách xác định nhanh lai hóa của một C (Tự lượng giá 1.1, 1.2)
> Đếm số "hướng" C liên kết tới (mỗi nguyên tử nối với C tính một hướng, bất kể liên kết đơn, đôi hay ba):
> - 4 hướng (chỉ có liên kết đơn) → **sp³**.
> - 3 hướng (có một liên kết đôi) → **sp²**.
> - 2 hướng (có liên kết ba, hoặc hai liên kết đôi liền nhau như C trung tâm của CO~2~) → **sp**.
>
> Áp dụng:
> - **CH~3~CH~2~Cl**: cả hai C là sp³, chỉ có liên kết σ.
> - **CH~2~=CH–CH~3~** (propen): sp², sp², sp³; có **8 σ + 1 π**.
> - **Methylcyclopentan**: mọi C đều sp³, chỉ có σ.
> - **Toluen C~6~H~5~–CH~3~**: 6 C vòng benzen là sp², C của CH~3~ là sp³; có **15 σ** (7 C–C + 8 C–H) và **3 π** theo công thức Kekulé (thực ra 6 electron π giải tỏa trên cả vòng).

## 2. Cấu trúc không gian của khung carbon — cấu dạng

### 2.1. Cấu dạng là gì?

Công thức viết trên giấy là công thức phẳng. Nó **không cho thấy** hình dạng thật của phân tử trong không gian.

Hai nguyên tử C nối nhau bằng **liên kết đơn σ** thì hai nửa phân tử **quay tự do** được quanh trục C–C, vì quay không làm hỏng vùng xen phủ trục. Mỗi hình dạng sinh ra khi quay như vậy gọi là một **cấu dạng** (conformation). Về lý thuyết có vô số cấu dạng (Giáo trình tr. 76).

### 2.2. Cấu dạng của ethan

Hai cấu dạng điển hình được biểu diễn bằng **công thức chiếu Newman** (nhìn dọc trục C–C):

- **Che khuất** (eclipsed): các H của C trước nằm **thẳng hàng** với các H của C sau. Các H ở gần nhau, đẩy nhau → **kém bền**.
- **Xen kẽ** (staggered): các H của C trước nằm **giữa** các H của C sau, cách nhau 60°. Các H ở xa nhau nhất → **bền hơn**.

![Hình 2. Công thức chiếu Newman: cấu dạng của ethan và butan](newman.svg)

> [!vi-du] Chênh lệch nhỏ — quay gần như tự do
> Dạng che khuất của ethan chỉ kém bền hơn dạng xen kẽ khoảng **12 kJ/mol** (≈ 3 kcal/mol). Ở nhiệt độ thường, năng lượng nhiệt đủ để phân tử quay qua lại hàng tỉ lần mỗi giây. Vì vậy các cấu dạng **không tách riêng được** thành những chất khác nhau. Đây là điểm khác căn bản giữa cấu dạng và đồng phân.

### 2.3. Cấu dạng của butan

Thay ở mỗi C của ethan một H bằng CH~3~ (tức là xét butan, nhìn dọc liên kết C2–C3). Trong các cấu dạng xen kẽ có:

- **Dạng đối** (anti): hai nhóm CH~3~ nằm **ngược phía**, cách nhau 180° → hai nhóm lớn xa nhau nhất → **bền nhất**.
- **Hai dạng lệch** (gauche): hai nhóm CH~3~ cách nhau 60° → kém bền hơn dạng đối.
- Kém bền nhất là dạng che khuất mà hai CH~3~ trùng nhau.

### 2.4. Hình dạng thật của mạch carbon

- **Mạch no** (toàn liên kết đơn): các nhóm CH~2~ kế cận luôn ưu tiên cấu dạng xen kẽ. Do đó mạch carbon là một **đường gấp khúc (zig-zag)**, góc C–C–C xấp xỉ **109°** (Giáo trình tr. 77).
- Có **liên kết đôi** C=C: hai nửa phân tử **không quay tự do** quanh liên kết đôi. Mạch vẫn gấp khúc nhưng góc ở C mang liên kết đôi là **120°**.
- Có **liên kết ba**: phân tử có một đoạn **thẳng gồm 4 nguyên tử** (C–C≡C–C); cũng không quay tự do quanh liên kết ba.

→ Liên kết bội làm thay đổi hình dạng của mạch carbon.

### 2.5. Cấu dạng của vòng sáu cạnh: ghế và thuyền

Vòng cyclohexan **không phẳng**. Nếu phẳng thì góc là 120°, lệch xa góc tứ diện 109°28′ và mọi H đều che khuất nhau. Vòng "gập" lại thành hai dạng chính, chuyển hóa qua lại được (giáo trình nêu ở tr. 84):

![Hình 3. Cấu dạng ghế và thuyền của cyclohexan](ghe-thuyen.svg)

- **Dạng ghế**: góc gần đúng 109,5°, mọi liên kết C–H của hai C kề nhau đều **xen kẽ** → **bền hơn**. Ở nhiệt độ thường, gần như toàn bộ phân tử cyclohexan ở dạng ghế.
- **Dạng thuyền**: có các cặp liên kết che khuất; hai H ở hai "mũi thuyền" chĩa vào nhau → kém bền.
- Ở dạng ghế, mỗi C có một liên kết **trục (a)** song song trục vòng và một liên kết **biên (e)** chĩa ra ngoài. Nhóm thế lớn ưu tiên đứng ở vị trí **biên**.

> [!ung-dung] Từ cyclohexan đến glucose
> Vòng pyranose của glucose cũng mang dạng **ghế**. Ở **β-glucose**, mọi nhóm thế lớn (–OH, –CH~2~OH) đều ở vị trí biên, nên β-glucose bền hơn α-glucose (xem bài Glucid). Vòng của steroid (cholesterol, hormon sinh dục, corticoid) cũng là các vòng sáu cạnh dạng ghế ghép lại; hình dạng này quyết định chúng gắn được vào thụ thể nào.

## 3. Đồng phân — khái niệm và phân loại

### 3.1. Định nghĩa

**Đồng phân** là những chất có **cùng công thức phân tử** nhưng **khác cấu trúc**, vì vậy có **tính chất khác nhau** (Giáo trình tr. 78).

Ví dụ: C~2~H~6~O ứng với hai chất:

| | Ethanol CH~3~–CH~2~–OH | Dimethyl ether CH~3~–O–CH~3~ |
|---|---|---|
| Trạng thái (điều kiện thường) | Lỏng, t°s = +78,5 °C | Khí, t°s = −23,6 °C |
| Vì sao? | Có nhóm –OH → **liên kết hydro** giữa các phân tử | Không có H gắn vào O → không có liên kết hydro giữa các phân tử |

### 3.2. Phân loại

Dựa vào cách sắp xếp các nguyên tử trong phân tử, giáo trình chia đồng phân thành hai loại lớn:

| Loại lớn | Khác nhau ở | Các loại nhỏ |
|---|---|---|
| **Đồng phân cấu tạo** | Thứ tự liên kết giữa các nguyên tử (thấy ngay trên công thức phẳng) | Mạch carbon · Vị trí · Nhóm chức |
| **Đồng phân lập thể** (đồng phân không gian) | Cùng công thức cấu tạo, chỉ khác cách phân bố trong **không gian** | Hình học (cis–trans) · Quang học |

### 3.3. Cấu tạo — cấu dạng — cấu hình

Ba thuật ngữ này hay bị dùng lẫn. Phân biệt như sau:

| Khái niệm | Mô tả điều gì | Đổi từ dạng này sang dạng khác | Có tách riêng được không? |
|---|---|---|---|
| **Cấu tạo** | Nguyên tử nào nối với nguyên tử nào, bằng liên kết gì | Phải **phá và tạo lại** liên kết | Có — là các chất khác nhau |
| **Cấu hình** | Cách sắp xếp **cố định** của các nhóm trong không gian (cis/trans, D/L, R/S) | Phải **phá vỡ liên kết** (hoặc phá liên kết π) | Có — là các đồng phân lập thể |
| **Cấu dạng** | Hình dạng tức thời do **quay quanh liên kết đơn** | Chỉ cần **quay**, không phá liên kết nào | Thường **không** — chuyển hóa liên tục |

> [!bay]
> - Dạng ghế và dạng thuyền của cyclohexan, dạng xen kẽ và che khuất của ethan là **cấu dạng**, **không phải** đồng phân.
> - Acid maleic và acid fumaric (cis/trans) là hai **cấu hình** khác nhau. Muốn chuyển chất này thành chất kia phải phá liên kết π, nên chúng là hai chất riêng biệt.

## 4. Đồng phân cấu tạo

Chỉ cần nhìn **công thức cấu tạo phẳng** là thấy khác nhau. Ví dụ n-butan CH~3~–CH~2~–CH~2~–CH~3~ và iso-butan (CH~3~)~2~CH–CH~3~ đều là C~4~H~10~.

### 4.1. Đồng phân mạch carbon

Các chất khác nhau ở **bộ khung carbon** (mạch thẳng, mạch nhánh, mạch vòng).

| Nhóm chất | Ví dụ (giáo trình tr. 78–79) |
|---|---|
| Alkan (từ C~4~) | n-butan (t°s ≈ 0 °C) và iso-butan (giáo trình in t°s = 10 °C; giá trị thực khoảng **−12 °C**, có lẽ bản in thiếu dấu trừ) |
| Cycloalkan | C~4~H~8~: cyclobutan và methylcyclopropan |
| Alken (từ C~4~) | C~4~H~8~: but-1-en (butylen, t°s −5 °C) và isobutylen (t°s −6 °C) |
| Vòng ↔ không vòng | butylen và cyclobutan (cùng C~4~H~8~) |
| Có nhóm chức | C~4~H~9~OH: butan-1-ol (t°s 117,7 °C) và 2-methylpropan-1-ol (t°s 108,4 °C) |
| Amin | C~2~H~7~N: ethylamin CH~3~CH~2~NH~2~ (pK~b~ = 3,33) và dimethylamin CH~3~NHCH~3~ (giáo trình ghi pK~b~ = 2,97; bảng số liệu hiện nay ≈ 3,27) |

> [!bay]
> - Mạch **nhánh** thì t°s **thấp hơn** mạch thẳng cùng số C: phân tử gọn, "tròn" hơn nên diện tích tiếp xúc giữa các phân tử nhỏ, lực hút yếu hơn (so sánh butan-1-ol 117,7 °C với 2-methylpropan-1-ol 108,4 °C).
> - Ethylamin (amin bậc I) và dimethylamin (amin bậc II) được giáo trình xếp vào đồng phân mạch carbon. Nhiều tài liệu khác gọi đây là **đồng phân bậc amin**. Đi thi, trả lời theo giáo trình.

### 4.2. Đồng phân vị trí

Mạch carbon giống nhau, chỉ khác **vị trí** của liên kết bội, nhóm thế hoặc nhóm chức (Giáo trình tr. 79–81).

- **Vị trí liên kết bội**: **α-pinen** (liên kết đôi nằm trong vòng, t°s 155–156 °C) và **β-pinen** (liên kết đôi nằm ngoài vòng, t°s 164–166 °C).
- **Vị trí nhóm chức**: propan-1-ol CH~3~CH~2~CH~2~OH (alcol n-propylic) và propan-2-ol CH~3~CHOHCH~3~ (alcol iso-propylic).
- **Vị trí nhóm thế trên vòng benzen**: diphenol C~6~H~4~(OH)~2~ có 3 đồng phân: **pyrocatechin** (ortho, 1,2), **resorcin** (meta, 1,3), **hydroquinon** (para, 1,4).
- **Hợp chất nhiều nhóm chức**: **α-alanin** CH~3~–CH(NH~2~)–COOH (rất phổ biến trong tự nhiên) và **β-alanin** H~2~N–CH~2~–CH~2~–COOH (ít gặp hơn nhiều).
- **Peptid**: glycyl-alanin và alanyl-glycin có cùng thành phần nhưng **thứ tự** amino acid (acid amin) khác nhau. Với n amino acid khác nhau, mỗi loại dùng một lần, có **n!** cách sắp xếp. Ví dụ 3 amino acid (glycin, alanin, leucin) cho 3! = **6** tripeptid đồng phân.
- **Glycerid**: α-monoolein (gốc acid oleic ở C đầu mạch glycerol) và β-monoolein (gốc acid ở C giữa). Theo giáo trình, **lipase** chỉ thủy phân được α-monoolein; β-monoolein phải đồng phân hóa thành dạng α trước.

> [!ung-dung] Thứ tự quyết định chức năng
> Peptid hormon và protein khác nhau chủ yếu ở **thứ tự** amino acid. Chỉ cần đổi một vị trí cũng có thể gây bệnh: ở bệnh hồng cầu hình liềm, hemoglobin chỉ bị thay **một** amino acid (glutamat → valin ở vị trí 6 chuỗi β). Trong ba đồng phân diphenol, **hydroquinon** là chất khử, từng được dùng làm kem trị nám da (hiện bị hạn chế vì tác dụng phụ), còn **resorcin** có tác dụng sát khuẩn, tiêu sừng, dùng ngoài da.

### 4.3. Đồng phân nhóm chức

Cùng công thức phân tử nhưng thuộc **các loại nhóm chức khác nhau**. Ví dụ đơn giản: alcol và ether (ethanol – dimethyl ether). Phân tử càng phức tạp, số đồng phân nhóm chức càng nhiều. Giáo trình lấy ví dụ **C~3~H~6~O** (tr. 81):

| Công thức | Tên | Nhóm chức |
|---|---|---|
| CH~2~=CH–CH~2~–OH | Alcol allylic | Alcol (không no) |
| CH~3~–CH–CH~2~ có cầu –O– nối hai C (vòng 3 cạnh) | Propylen oxid (giáo trình: *propan oxide*) | Ether vòng (epoxid) |
| CH~3~–O–CH=CH~2~ | Ether methyl vinylic | Ether |
| CH~3~–CH~2~–CHO | Aldehyd propionic (propanal) | Aldehyd |
| CH~3~–CO–CH~3~ | Aceton (propanon) | Ceton |

## 5. Đồng phân hình học (cis–trans)

### 5.1. Vì sao cần đồng phân lập thể? Bằng chứng từ CH~2~Cl~2~

Nếu chỉ nhìn công thức phẳng vuông, CH~2~Cl~2~ có vẻ có **hai** cách sắp xếp (hai Cl cạnh nhau hoặc đối nhau). Thực tế chỉ có **một** chất CH~2~Cl~2~. Lý do: C lai hóa sp³ nằm ở tâm một **tứ diện**. Mọi đỉnh của tứ diện đều kề nhau, nên hai cách vẽ trên chồng khít được lên nhau (Giáo trình tr. 81–82).

Ngược lại có trường hợp công thức phẳng chỉ cho **một** cách viết nhưng thực tế có **hai** chất, ví dụ **cis-** và **trans-para-mentan** (t°s 168,5 °C và 161 °C). Đó là vì các nhóm thế phân bố khác nhau trong không gian.

**Đồng phân lập thể** là những chất có **cùng công thức cấu tạo** nhưng các nguyên tử hoặc nhóm nguyên tử phân bố **khác nhau trong không gian**. Gồm đồng phân **hình học** và đồng phân **quang học**.

### 5.2. Đồng phân hình học ở hợp chất có liên kết đôi

Ví dụ kinh điển: HOOC–CH=CH–COOH (acid butendioic) có hai đồng phân (Giáo trình tr. 83):

| | **Acid maleic** | **Acid fumaric** |
|---|---|---|
| Cấu hình | **cis**: hai nhóm –COOH **cùng phía** với liên kết đôi | **trans**: hai nhóm –COOH **khác phía** |
| Viết gọn | H(HOOC)C=C(COOH)H, hai –COOH cùng bên | H(HOOC)C=C(H)COOH, hai –COOH chéo nhau |

**Điều kiện để có đồng phân hình học** (Tự lượng giá 1.3):

1. Có một bộ phận **"cứng nhắc"** cản trở sự quay tự do: **liên kết đôi** (C=C, C=N) hoặc **vòng no**.
2. **Mỗi** nguyên tử ở bộ phận cứng đó phải gắn với **hai nhóm khác nhau**. Với liên kết đôi dạng **abC=Cde**, cần **a ≠ b và d ≠ e**.

**Nguyên nhân**: liên kết π được tạo bởi xen phủ bên của hai orbital p. Muốn quay quanh C=C phải bẻ gãy liên kết π. Ở nhiệt độ thường, năng lượng không đủ, nên hai cấu hình **không tự chuyển** cho nhau.

> [!bay] Có hay không có cis–trans?
> - **But-2-en** CH~3~CH=CHCH~3~: **có** (mỗi C mang H và CH~3~).
> - **But-1-en** CH~2~=CH–CH~2~CH~3~: **không** (C1 mang hai H giống nhau).
> - **2-methylbut-2-en** (CH~3~)~2~C=CH–CH~3~: **không** (C2 mang hai CH~3~).
> - **3-methylpent-2-en** CH~3~CH=C(CH~3~)–C~2~H~5~: **có** (C3 mang CH~3~ và C~2~H~5~ khác nhau).
> - **Alkyn** (CH~3~–C≡C–C~6~H~5~): **không**, vì phần C–C≡C–C thẳng hàng, không có "hai phía".

**Hợp chất có nhiều liên kết đôi.** Chất dạng **aCH=CH–CH=CHb** (a ≠ b) có thể có **4** đồng phân hình học: trans–trans, trans–cis, cis–trans, cis–cis (Giáo trình tr. 83–84).

> [!bay] Khi hai đầu giống nhau
> Nếu a = b (ví dụ **hexa-2,4-dien** CH~3~CH=CH–CH=CHCH~3~), hai dạng "cis–trans" và "trans–cis" **chính là một chất** (lật phân tử lại là trùng). Vì vậy hexa-2,4-dien chỉ có **3** đồng phân hình học: trans,trans; cis,cis; cis,trans.

### 5.3. Đồng phân hình học ở hợp chất vòng

Vòng no cũng "cứng": các nguyên tử trong vòng không quay tự do quanh liên kết vòng được.

- **cis**: hai nhóm thế ở **cùng một phía** so với mặt phẳng (trung bình) của vòng; **trans**: ở hai phía.
- **Acid cyclopropan-1,2-dicarboxylic**: dạng cis (t°nc 139 °C) và dạng trans (t°nc 175 °C).
- **Vòng sáu cạnh** (dạng ghế, mục 2.5): hai nhóm thế cùng phía mặt phẳng trung bình của vòng là cis, khác phía là trans. Ví dụ cis- và trans-para-mentan.
- **Hợp chất nhiều vòng**: **decalin** (hai vòng sáu cạnh chung một cạnh) có **cis-decalin** (hai H ở chỗ nối vòng cùng phía, t°s 194 °C) và **trans-decalin** (hai H khác phía, t°s 185 °C).

> [!bay]
> Hai nhóm thế phải ở **hai C khác nhau** của vòng. **1,1-dimethylcyclohexan** (hai CH~3~ cùng gắn vào một C) **không** có đồng phân cis–trans, vì C đó mang hai nhóm giống nhau.

> [!yhct] Tinh dầu: đồng phân quyết định mùi và tác dụng
> - **α-pinen** và **β-pinen** (đồng phân vị trí của liên kết đôi) là thành phần chính của **tinh dầu thông** (nhựa thông), cũng có trong tinh dầu nhiều vị thuốc khác. Hai chất có mùi và nhiệt độ sôi khác nhau.
> - **Menthol**, hoạt chất chính của tinh dầu **Bạc hà** (*Mentha arvensis*), chính là **para-mentan-3-ol**, tức là bộ khung para-mentan của giáo trình gắn thêm một nhóm –OH. Phân tử có **3 C\*** nên có **2^3^ = 8** đồng phân lập thể (menthol, neomenthol, isomenthol, neoisomenthol, mỗi chất một đôi đối quang). Cây chủ yếu tạo **(−)-menthol**, trong đó cả ba nhóm thế trên vòng ghế đều ở vị trí **biên**. Đây là dạng gây cảm giác mát mạnh nhất.
> - Ý nghĩa: tinh dầu tổng hợp hoặc bán tổng hợp có thể chứa tỉ lệ đồng phân khác tinh dầu tự nhiên. Vì vậy kiểm nghiệm dược liệu có chỉ tiêu riêng cho đồng phân (ví dụ **góc quay cực** của tinh dầu). Lưu ý: tinh dầu Bạc hà và menthol đậm đặc **không** bôi gần mũi trẻ nhỏ (có thể gây co thắt thanh quản).

> [!ung-dung] Cis–trans trong cơ thể
> - **Fumarat** (dạng trans) là chất trung gian của **chu trình Krebs** (fumarat → malat nhờ enzym fumarase). Dạng cis (maleat) không được enzym này sử dụng.
> - **Thị giác**: **11-cis-retinal** gắn với opsin trong tế bào que. Ánh sáng đổi nó thành **all-trans-retinal**, làm thay đổi hình dạng protein và phát tín hiệu thần kinh.
> - **Chất béo trans** (sinh ra khi hydro hóa một phần dầu thực vật) làm tăng LDL-cholesterol và nguy cơ tim mạch. Acid béo tự nhiên trong dầu thực vật chủ yếu ở dạng **cis**.

> [!cap-nhat] Danh pháp Z/E
> Giáo trình chỉ dùng **cis/trans**. Cách gọi này chỉ rõ ràng khi mỗi C mang một H. Với các anken có 3–4 nhóm thế khác nhau, hiện nay IUPAC dùng danh pháp **Z/E**:
> - Ở mỗi C của liên kết đôi, xếp hạng hai nhóm thế theo **quy tắc ưu tiên CIP** (mục 6.8).
> - Hai nhóm **ưu tiên cao** nằm **cùng phía** → **Z** (*zusammen* = cùng nhau); **khác phía** → **E** (*entgegen* = đối nhau).
> - Ví dụ: acid maleic là (Z)-butendioic, acid fumaric là (E)-butendioic. Thường cis ≈ Z, trans ≈ E, nhưng **không phải luôn luôn**. Ví dụ CH~3~–CBr=CH–CH~3~: khi hai nhóm CH~3~ cùng phía (kiểu "cis" theo mạch chính) thì chất lại là **E**, vì ở C2 nhóm Br được ưu tiên hơn CH~3~.
>
> Đi thi môn này, dùng cis/trans theo giáo trình.

## 6. Đồng phân quang học

### 6.1. Ánh sáng phân cực và chất quang hoạt

Schiessler và Liebig tìm ra **ba dạng acid lactic** CH~3~–CHOH–COOH có cùng công thức cấu tạo (Giáo trình tr. 85). Chiếu ánh sáng phân cực qua dung dịch 10% của chúng:

- Dạng thứ nhất làm mặt phẳng phân cực quay **sang phải** +3,82°.
- Dạng thứ hai làm quay **sang trái** −3,82°.
- Dạng thứ ba **không** làm quay mặt phẳng phân cực.

Chất làm quay mặt phẳng phân cực gọi là **chất quang hoạt**; tính chất đó gọi là **tính quang hoạt**. Các chất cùng công thức cấu tạo nhưng làm quay mặt phẳng phân cực những góc khác nhau là **đồng phân quang học**.

- Quay **phải**: đồng phân **(+)** (dextrogyre); quay **trái**: đồng phân **(−)** (levogyre).
- Hai đồng phân quay **cùng một góc** nhưng **ngược chiều** (+α và −α) gọi là **một đôi đối quang** (enantiomer). Hai dạng acid lactic quay ±3,82° là một đôi đối quang.

### 6.2. Hỗn hợp racemic

Dạng thứ ba của acid lactic là gì? Pasteur phát hiện: **hỗn hợp hai lượng bằng nhau của một đôi đối quang** không làm quay mặt phẳng phân cực, vì tác dụng của hai chất **triệt tiêu nhau**. Hỗn hợp đó gọi là **hỗn hợp racemic** (ký hiệu (±) hoặc *rac-*) (Giáo trình tr. 86).

### 6.3. Carbon bất đối (C\*) — gốc rễ của tính quang hoạt

Những chất quang hoạt nói trên đều có ít nhất một **carbon bất đối xứng** (C\*): nguyên tử C liên kết với **bốn nguyên tử hoặc nhóm nguyên tử hoàn toàn khác nhau**. Acid lactic có 1 C\*, gắn với H, OH, CH~3~ và COOH.

Biểu diễn bằng mô hình tứ diện, C\* cho **hai cấu hình** là **vật và ảnh của nó trong gương phẳng**. Hai cấu hình ấy **không chồng khít** được lên nhau, giống như bàn tay trái và bàn tay phải. Một cấu hình quay phải, cấu hình kia quay trái: đó là một đôi đối quang.

![Hình 4. Cặp đối quang của acid lactic: mô hình nêm và công thức chiếu Fischer](doi-quang.svg)

> [!bay] Nhận diện C\* nhanh
> - C có liên kết đôi hoặc ba → **không** phải C\* (không đủ 4 nhóm).
> - C mang **2 H**, hoặc **2 nhóm CH~3~** → **không** phải C\*.
> - Phải xét **cả nhóm**, không chỉ nguyên tử gắn trực tiếp. Ví dụ trong CH~3~–CHBr–CH~2~–CH~3~, C2 gắn CH~3~ và C~2~H~5~ là hai nhóm khác nhau → C2 là C\*.
> - Ví dụ không có C\*: CH~3~–CHBr–CH~3~, glycerol HOCH~2~–CHOH–CH~2~OH (C2 mang hai nhóm CH~2~OH giống nhau), glycin H~2~N–CH~2~–COOH.

### 6.4. Công thức chiếu Fischer

Để vẽ đồng phân quang học trên giấy cho nhanh, người ta dùng **công thức chiếu Fischer** (Giáo trình tr. 86–87):

- Đặt tứ diện sao cho **hai nhóm nằm ngang hướng về phía người xem**, **hai nhóm thẳng đứng hướng ra phía sau**.
- Chiếu xuống mặt giấy thành một **dấu thập**; C\* là giao điểm (thường không ghi chữ C).
- Quy ước: mạch carbon viết **theo cột dọc**, C có **số oxy hóa cao nhất** (–CHO, –COOH) ở **trên cùng**.

> [!bay] Các phép biến đổi công thức Fischer
> - **Quay 180°** trong mặt phẳng giấy → vẫn là **chính chất đó**.
> - **Quay 90°**, hoặc **đổi chỗ hai nhóm bất kỳ** (một lần) → được **đối quang**.
> - Đổi chỗ **hai lần** → trở lại chất ban đầu.
> - **Không** được lật công thức Fischer ra khỏi mặt giấy.

### 6.5. Phân tử có hai C\* khác nhau — đồng phân dia

Mỗi C\* đóng góp vào góc quay một lượng: C\* thứ nhất ±A, C\* thứ hai ±B. Có 4 tổ hợp: (+A +B), (−A −B), (+A −B), (−A +B). Vậy có **4 đồng phân quang học**, tạo thành **2 đôi đối quang** (Giáo trình tr. 88).

Ví dụ: **aldotetrose** CH~2~OH–CHOH–CHOH–CHO có 2 C\*, cho 4 đồng phân: hai **erythrose** (hai –OH cùng phía trên công thức Fischer) và hai **threose** (hai –OH khác phía).

- Erythrose (I) và erythrose (II) là một đôi đối quang; threose (III) và threose (IV) là đôi đối quang thứ hai.
- Các cặp I–III, II–IV, I–IV, II–III là đồng phân quang học **nhưng không đối quang**. Ngày nay gọi là **đồng phân dia** (diastereomer).

**Tổng quát**: phân tử có **n C\*** thì có tối đa **2^n^** đồng phân quang học (1 C\* → 2; 2 C\* → 4; 3 C\* → 8; aldohexose có 4 C\* → 16).

| | **Đối quang** (enantiomer) | **Đồng phân dia** (diastereomer) |
|---|---|---|
| Quan hệ | Vật – ảnh qua gương | Đồng phân lập thể nhưng **không** là vật – ảnh |
| Cấu hình | Ngược nhau ở **tất cả** các C\* | Ngược nhau ở **một số** (không phải tất cả) C\* |
| Tính chất vật lý (t°nc, t°s, độ tan) | **Giống hệt nhau** | **Khác nhau** |
| Góc quay cực | Cùng trị số, ngược dấu | Khác nhau tùy ý |
| Tách riêng | Khó (phải dùng tác nhân bất đối) | Tách được bằng kết tinh, sắc ký thường |
| Với enzym, thụ thể | **Khác nhau** | Khác nhau |

### 6.6. Hai C\* giống nhau — đồng phân meso

Nếu phân tử có dạng **abe-C\*–C\*-abe** (hai C\* mang cùng bộ nhóm thế), góp phần quay cực của hai C\* có cùng trị số. Chỉ còn 3 tổ hợp: (+A +A), (−A −A) và (+A −A) (Giáo trình tr. 89).

- (+A +A) và (−A −A) là **một đôi đối quang**.
- (+A −A): hai C\* triệt tiêu nhau **ngay trong một phân tử** → không quang hoạt. Đây là **đồng phân meso**.

Ví dụ: **acid tartric** HOOC–CHOH–CHOH–COOH có 2 C\* nhưng chỉ có **3** đồng phân: acid (+)-tartric, acid (−)-tartric và acid **meso-tartric**. Trên công thức Fischer, dạng meso có hai –OH **cùng phía** và một **mặt phẳng đối xứng** cắt ngang giữa phân tử.

> [!bay] Meso và racemic — đều không quang hoạt nhưng khác bản chất
> | | **Meso** | **Racemic** |
> |---|---|---|
> | Là gì | **Một chất** duy nhất | **Hỗn hợp** đồng lượng hai đối quang |
> | Vì sao không quay cực | Triệt tiêu **trong nội phân tử** (có mặt phẳng đối xứng) | Triệt tiêu **giữa các phân tử** |
> | Tách được thành chất quang hoạt? | **Không** | **Có** (tách racemic) |

### 6.7. Dãy D và dãy L

Ký hiệu (+)/(−) chỉ **chiều quay đo được**. Để chỉ **cấu hình** (cách sắp xếp thật trong không gian), người ta dùng **D/L**, lấy **glyceraldehyd** làm chất chuẩn (Giáo trình tr. 89–90):

- **D-glyceraldehyd**: trên công thức Fischer (–CHO ở trên), –OH ở C\* nằm **bên phải**. Chất này quay phải, nên viết **D-(+)-glyceraldehyd**.
- **L-glyceraldehyd**: –OH **bên trái**, viết **L-(−)-glyceraldehyd**.
- Với chất có nhiều C\*: viết mạch dọc, C có số oxy hóa cao nhất ở trên. Xét **C\* cuối cùng** (xa nhóm có số oxy hóa cao nhất). Nếu cấu hình của nó **giống D-glyceraldehyd** (nhóm –OH bên phải) → **dãy D**; giống L-glyceraldehyd → **dãy L**.
- **Amino acid**: so nhóm –NH~2~ ở C\*α (–COOH ở trên): bên phải là **D**, bên trái là **L**.
- Đường tự nhiên hầu hết thuộc **dãy D**; amino acid trong protein thuộc **dãy L**.

> [!cap-nhat] D/L không phải là chiều quay
> Ở tr. 85, giáo trình viết đồng phân quay phải "còn ký hiệu là D", quay trái "ký hiệu là L". Cách gọi đó là **cách dùng cũ**: chữ *d*/*l* thường từng được dùng để chỉ chiều quay (nay thay bằng (+)/(−)). Chính giáo trình ở tr. 90 lại nhấn mạnh: **chất thuộc dãy D không đồng nhất với đồng phân (+)**.
> Hiện nay thống nhất: **D/L** (chữ in hoa nhỏ) = **cấu hình**; **(+)/(−)** = **chiều quay**. Hai thứ **độc lập** nhau. Ví dụ: D-(−)-acid lactic, D-(−)-fructose, L-(+)-alanin.

### 6.8. Cấu hình R/S và quy tắc CIP (mở rộng)

Giáo trình chỉ dùng D/L. Hệ D/L tiện cho đường và amino acid nhưng khó áp dụng cho phân tử bất kỳ. Danh pháp IUPAC hiện hành và tên thuốc (Dược thư, tài liệu Hóa dược) dùng hệ **R/S** (Cahn – Ingold – Prelog, **CIP**).

**Bước 1 — Xếp hạng ưu tiên 4 nhóm quanh C\*:**

1. Nguyên tử gắn trực tiếp vào C\* có **số hiệu nguyên tử lớn hơn** thì ưu tiên hơn: I > Br > Cl > S > F > O > N > C > H.
2. Nếu hòa, xét tiếp **bộ ba nguyên tử** gắn vào nguyên tử đó, so lần lượt từ lớn đến nhỏ. Ví dụ –CH~2~OH (O, H, H) > –CH~3~ (H, H, H).
3. Liên kết đôi, ba được tính như **lặp lại** nguyên tử: –CHO coi như C gắn (O, O, H); –COOH coi như (O, O, O).

**Bước 2 — Đặt nhóm ưu tiên thấp nhất (④, thường là H) ra xa người xem.** Nhìn thứ tự ① → ② → ③:

- Theo **chiều kim đồng hồ** → **R** (*rectus*);
- **Ngược** chiều kim đồng hồ → **S** (*sinister*).

**Mẹo với công thức Fischer:** nếu nhóm ④ nằm trên **nét dọc** (hướng ra sau) thì đọc thẳng. Nếu nhóm ④ nằm trên **nét ngang** (hướng về người xem) thì đọc xong phải **đảo ngược** kết quả.

> [!vi-du] Áp dụng cho acid lactic (Hình 4)
> Thứ tự ưu tiên: –OH ① > –COOH ② > –CH~3~ ③ > –H ④.
> Ở công thức bên trái (–OH bên phải, –H bên trái): đi ① (phải) → ② (trên) → ③ (dưới) là **ngược chiều kim đồng hồ**. H nằm trên nét ngang nên đảo lại → **R**. Vậy D-(−)-acid lactic = **(R)**-acid lactic.
>
> Lưu ý: **R/S cũng độc lập với (+)/(−)**, và **không trùng hoàn toàn với D/L**. Ví dụ L-alanin là (S), nhưng L-cystein lại là (R) vì nhóm –CH~2~SH có S đứng đầu bảng ưu tiên.

### 6.9. Đồng phân quang học không có C\*

Tính quang hoạt thật ra do **cả phân tử bất đối xứng** (không có mặt phẳng và tâm đối xứng), chứ không bắt buộc phải có C\*. Ví dụ: **acid 6,6′-diclodiphenic** (biphenyl mang hai –COOH và hai –Cl ở các vị trí ortho). Các nhóm thế cồng kềnh cản trở hai vòng benzen quay quanh liên kết nối giữa chúng, nên hai vòng bị "khóa" lệch nhau và phân tử có hai dạng vật – ảnh (Giáo trình tr. 90).

> [!bay] Hai khẳng định hay bị nhầm
> - "Có C\* thì chắc chắn quang hoạt" → **Sai**: hợp chất meso có C\* nhưng không quang hoạt.
> - "Không có C\* thì không thể có đồng phân quang học" → **Sai**: ví dụ dẫn xuất biphenyl ở trên.

## 7. Đồng phân lập thể và thuốc

Enzym và thụ thể trong cơ thể được tạo từ **L-amino acid**, nên bản thân chúng **bất đối**. Hai đối quang của một thuốc giống nhau về tính chất vật lý, nhưng "khớp" với thụ thể khác nhau, giống như tay phải chỉ vừa găng tay phải. Vì vậy hai đối quang có thể khác nhau về **tác dụng, độc tính, chuyển hóa**.

> [!ung-dung] Ba ví dụ kinh điển
> - **Thalidomid**: bán dạng **racemic** làm thuốc an thần, chống nôn cho phụ nữ có thai (cuối thập niên 1950). Hơn 10.000 trẻ sinh ra bị **dị tật chi** (tật chân tay ngắn như vây hải cẩu, *phocomelia*). Đồng phân (R) chủ yếu gây an thần; đồng phân (S) liên quan đến tác dụng gây quái thai. Điều quan trọng: hai đối quang **chuyển hóa qua lại trong cơ thể** (racemic hóa), nên **dùng riêng đồng phân (R) cũng không an toàn**. Ngày nay thalidomid vẫn được dùng (điều trị đa u tủy xương, một biến chứng của bệnh phong) nhưng với chương trình **tránh thai bắt buộc**. Thảm họa này đã thay đổi cách thử nghiệm thuốc trên toàn thế giới.
> - **Levodopa (L-dopa)**: thuốc chính điều trị **bệnh Parkinson**. L-dopa qua được hàng rào máu – não rồi được enzym decarboxylase chuyển thành **dopamin**. Enzym chỉ nhận dạng **L**; D-dopa không cho tác dụng điều trị. Vì vậy thuốc dùng ở dạng **L đơn chất**, không dùng racemic.
> - **Ibuprofen**: thuốc bán ra thường là **racemic**, nhưng chỉ **(S)-ibuprofen** ức chế mạnh enzym COX (tác dụng giảm đau, chống viêm). Trong cơ thể, một phần (R) được **chuyển thành (S)** (chiều ngược lại hầu như không xảy ra). Dạng (S) đơn chất được bán với tên **dexibuprofen**.
>
> Hệ quả: nhiều thuốc mới được sản xuất ở dạng **một đối quang** (ví dụ esomeprazol là (S)-omeprazol; levocetirizin là đối quang có hoạt tính của cetirizin).

> [!ung-dung] Acid lactic trong xét nghiệm
> Cơ thể người sinh ra **L-(+)-acid lactic** khi cơ hoạt động thiếu oxy hoặc khi sốc. Xét nghiệm **lactat máu** thông thường dùng enzym đặc hiệu cho dạng L. Dạng **D-lactat** do vi khuẩn đường ruột tạo ra (ví dụ ở người có hội chứng ruột ngắn); muốn đo phải dùng xét nghiệm riêng.

> [!yhct] Ma hoàng: ephedrin và pseudoephedrin là đồng phân dia
> **Ma hoàng** (*Ephedra sinica* và các loài cùng chi) có alkaloid chính là **(−)-ephedrin** và **(+)-pseudoephedrin**. Cả hai đều là 2-(methylamino)-1-phenylpropan-1-ol, phân tử có **2 C\*** (C1 mang –OH, C2 mang –NHCH~3~).
> - Ephedrin là **(1R,2S)**; pseudoephedrin là **(1S,2S)**. Hai chất **chỉ khác cấu hình ở C1**, giống nhau ở C2. Vậy chúng **không phải đối quang** mà là **đồng phân dia**. Đối quang của (−)-ephedrin là (+)-ephedrin (1S,2R), một chất khác.
> - Vì là đồng phân dia nên hai chất có **tính chất vật lý khác nhau** và tác dụng khác nhau. **Ephedrin** kích thích thần kinh giao cảm mạnh hơn: giãn phế quản, co mạch, tăng huyết áp, kích thích thần kinh trung ương. **Pseudoephedrin** tác dụng lên tim mạch và thần kinh trung ương yếu hơn, được dùng làm thuốc **chống ngạt mũi**.
> - Liên hệ: Ma hoàng là vị thuốc **phát hãn giải biểu, tuyên phế bình suyễn** (ví dụ bài *Ma hoàng thang*). Tác dụng giãn phế quản của ephedrin được chứng minh rõ ràng; trước đây ephedrin chính là một thuốc trị hen phế quản.
> - **Thận trọng**: alkaloid Ma hoàng có thể gây **tăng huyết áp, loạn nhịp tim, mất ngủ, đánh trống ngực**. Có ca đột quỵ, nhồi máu cơ tim khi dùng chế phẩm Ma hoàng để giảm cân, tăng lực; Hoa Kỳ đã cấm Ma hoàng trong thực phẩm chức năng từ năm 2004. Thận trọng ở người tăng huyết áp, bệnh tim, cường giáp, glôcôm, người đang dùng thuốc IMAO. Theo YHCT, Ma hoàng chỉ dùng đúng chứng (biểu thực, không ra mồ hôi), đúng liều Dược điển; ra nhiều mồ hôi, hư chứng thì không dùng.

## 8. Tóm tắt

| Nội dung | Điểm cần nhớ |
|---|---|
| Lai hóa sp³ / sp² / sp | 4 / 3 / 2 orbital lai hóa; 109°28′ / 120° / 180°; còn 0 / 1 / 2 orbital p tạo π |
| Liên kết bội | Đôi = 1σ + 1π; ba = 1σ + 2π; π không cho quay tự do |
| Cấu dạng | Do quay quanh liên kết đơn; bền nhất: xen kẽ (ethan), đối (butan), ghế (cyclohexan); không tách riêng được |
| Đồng phân cấu tạo | Mạch carbon (butan / iso-butan) · Vị trí (α/β-pinen, o/m/p-diphenol, peptid n!) · Nhóm chức (alcol / ether; giáo trình nêu 5 chất C~3~H~6~O) |
| Đồng phân hình học | Cần bộ phận cứng + mỗi C mang hai nhóm khác nhau; cis (cùng phía) / trans (khác phía); maleic (cis) – fumaric (trans) |
| C\* | C gắn 4 nhóm khác nhau; n C\* → tối đa 2^n^ đồng phân |
| Đối quang | Vật – ảnh; tính chất vật lý giống nhau, góc quay ngược dấu; tác dụng sinh học khác nhau |
| Đồng phân dia | Đồng phân lập thể không đối quang; tính chất vật lý khác (ephedrin ↔ pseudoephedrin) |
| Meso / racemic | Meso: một chất có mặt phẳng đối xứng; racemic: hỗn hợp 1:1 hai đối quang |
| D/L – (+)/(−) – R/S | Cấu hình so với glyceraldehyd – chiều quay đo được – cấu hình theo CIP; ba hệ độc lập |

> [!vi-du] Đáp án Tự lượng giá (tr. 90–92) và các điểm cần lưu ý ở phần hướng dẫn cuối sách (tr. 250)
> - **1.4** (đồng phân hình học): có ở a (but-2-en), d (hexa-2,4-dien), e (pent-2-en), f (acid crotonic), g (CH~3~CH=CH–C~6~H~5~). Không có ở b (alkyn), c ((CH~3~)~2~C=). Đáp án cuối sách ghi **cả h**. Nhưng h trong đề là **1,1-dimethylcyclohexan** (hai CH~3~ cùng một C), chất này **không** có cis–trans. Có lẽ đề định viết 1,2- hay 1,4-dimethylcyclohexan.
> - **1.5** (cis–trans): có ở b, c, d, e, f, g, h; **không** có ở a (2-methylbut-2-en).
> - **1.7**: a (CH~3~CHBrCH~3~) không có C\*; c (acid lactic) và d (alanin): 2 đồng phân; e (acid tartric): 3 đồng phân (có meso); f (aldohexose, 4 C\*): 16. Đáp án cuối sách ghi b (CH~3~–CHBr–CHBr–COOH) có **3** đồng phân. Thực tế hai C\* của chất này **khác nhau** (một C gắn CH~3~, C kia gắn COOH), nên không có dạng meso và có **2^2^ = 4** đồng phân.
> - **1.8**: đề hỏi C~4~H~9~Cl, nhưng hướng dẫn giải lại giải cho **C~4~H~8~Cl~2~** (9 đồng phân cấu tạo, 7 đồng phân quang học). Với **C~4~H~9~Cl**: có 4 đồng phân cấu tạo (1-clobutan, 2-clobutan, 1-clo-2-methylpropan, 2-clo-2-methylpropan); chỉ **2-clobutan** có C\*, cho **2** đồng phân quang học.
> - **1.9**: dãy D: a, e; dãy L: b, c, d, f; meso: g.
> - **1.10**: a, d có đồng phân quang học (d có 2 C\* khác nhau → 4); b, c có đồng phân hình học.
> - **1.11**: cấu dạng bền nhất là **xen kẽ** (ethan) và **đối** (n-butan, 1,2-dicloethan: hai nhóm lớn ngược phía 180°); kém bền nhất là **che khuất**, với butan và 1,2-dicloethan là dạng hai nhóm lớn trùng nhau.
