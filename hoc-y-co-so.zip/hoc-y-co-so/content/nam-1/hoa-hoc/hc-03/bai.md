---
title: Hiệu ứng cấu trúc
thoi-gian: 35 phút
muc-tieu:
- Cho được ví dụ về liên kết phân cực trong phân tử hữu cơ và biểu diễn đúng sự phân cực của liên kết σ, liên kết π.
- Trình bày được bản chất, cách phân loại (+I/−I, +C/−C) và đặc điểm của hiệu ứng cảm ứng và hiệu ứng liên hợp.
- Dùng hai hiệu ứng trên để so sánh và giải thích tính acid, tính base và hướng phản ứng của một số chất.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Hai nguyên tử có độ âm điện khác nhau → liên kết **phân cực** (δ+, δ−). Đây là gốc của mọi "hiệu ứng" trong phân tử.
> 2. **Hiệu ứng cảm ứng (I)** truyền theo **liên kết σ**, **tắt nhanh**: qua khoảng 3 carbon gần như không còn. Hút electron mạnh hơn H là **−I**, đẩy mạnh hơn H là **+I**.
> 3. **Hiệu ứng liên hợp (C)** truyền theo **hệ π (và p) liên hợp, phẳng**, **gần như không giảm** khi hệ kéo dài. Nhóm có cặp electron tự do (–OH, –NH~2~, –Cl) là **+C**; nhóm có liên kết bội với nguyên tử âm điện (C=O, –NO~2~, –C≡N) là **−C**.
> 4. **Tính acid tăng** khi nhóm thế **hút** electron (−I, −C) vì anion sinh ra bền hơn; **giảm** khi nhóm thế **đẩy** electron (+I).
> 5. **Tính base của amin tăng** khi nhóm thế **đẩy** electron (+I của alkyl); **giảm** khi cặp electron của N bị **liên hợp** vào vòng (anilin) hoặc bị hút (–NO~2~).

## 1. Sự phân cực liên kết

Liên kết giữa **hai nguyên tử giống hệt nhau** (H–H, Cl–Cl, C–C trong ethan) **không phân cực**: cặp electron chung nằm chính giữa.

Khi hai nguyên tử có **độ âm điện khác nhau**, cặp electron bị kéo lệch về phía nguyên tử âm điện hơn. Nguyên tử đó mang một phần điện tích âm, ký hiệu **δ−**; nguyên tử kia mang một phần điện tích dương, **δ+** (Giáo trình tr. 101).

Cách biểu diễn theo giáo trình:

- Liên kết **σ** phân cực: vẽ **mũi tên thẳng** trên nét liên kết, đầu mũi tên chỉ về nguyên tử hút electron. Ví dụ: C^δ+^ → Cl^δ−^.
- Liên kết **π** phân cực: vẽ **mũi tên cong** từ giữa liên kết π về nguyên tử hút electron. Ví dụ: >C^δ+^=O^δ−^ (mũi tên cong chỉ về O).

**Vì sao quan trọng?** Liên kết phân cực tạo ra các "điểm tích điện" trong phân tử. Chính các điểm này làm các nguyên tử, nhóm nguyên tử **ảnh hưởng lẫn nhau**. Ảnh hưởng đó gọi chung là **hiệu ứng**. Bài này học hai loại chính: hiệu ứng **cảm ứng** và hiệu ứng **liên hợp**.

> [!vi-du] Độ âm điện cần nhớ (thang Pauling)
> F 4,0 > O 3,5 > Cl 3,0 ≈ N 3,0 > Br 2,8 > C 2,5 ≈ I 2,5 ≈ S 2,5 > H 2,1.
> Vì vậy trong hợp chất hữu cơ: C–O, C–N, C–halogen có C mang δ+; còn C–H gần như không phân cực (được chọn làm chuẩn ở mục 2).

## 2. Hiệu ứng cảm ứng (I)

### 2.1. Bản chất

Xét mạch C3–C2–C1–X, trong đó X âm điện hơn carbon (ví dụ Cl):

- Liên kết C1–X phân cực về phía X: X mang δ−, C1 mang δ+.
- C1 "thiếu" electron nên lại kéo cặp electron của liên kết C2–C1 về phía mình. C2 mang một điện tích dương nhỏ hơn (δδ+).
- Cứ thế, sự lệch electron **lan truyền dọc các liên kết σ** liên tiếp, **mỗi bước một yếu đi**.

Sự dịch chuyển electron theo cơ chế **cảm ứng tĩnh điện** dọc chuỗi liên kết σ như vậy gọi là **hiệu ứng cảm ứng**, ký hiệu **I** (*Inductive effect*) (Giáo trình tr. 101–102).

![Hình 1. Hiệu ứng cảm ứng âm của clo lan truyền và tắt dần trên mạch carbon](cam-ung.svg)

### 2.2. Hai loại: −I và +I

Người ta lấy **nguyên tử H trong liên kết C–H của hydrocarbon no** làm chuẩn, quy ước **I = 0** (Giáo trình tr. 102).

| | **Hiệu ứng cảm ứng âm (−I)** | **Hiệu ứng cảm ứng dương (+I)** |
|---|---|---|
| Định nghĩa | Nhóm **hút** electron mạnh hơn H | Nhóm **đẩy** electron mạnh hơn H |
| Ví dụ | –F, –Cl, –Br, –I, –OH, –OR, –NH~2~, –NO~2~, –C≡N, –COOH, –C~6~H~5~, –CH=CH~2~ | Các gốc alkyl: –CH~3~, –C~2~H~5~, –CH(CH~3~)~2~, –C(CH~3~)~3~; các nhóm mang điện âm (–O^−^, –COO^−^) |
| Hệ quả | Làm carbon bên cạnh nghèo electron hơn | Làm carbon bên cạnh giàu electron hơn |

**Thứ tự −I theo giáo trình** (tr. 102):

- Halogen: **–F > –Cl > –Br > –I** (độ âm điện giảm dần).
- Cùng chu kỳ: **–F > –OH > –NH~2~** (F > O > N về độ âm điện).
- Theo kiểu lai hóa của C: **–C≡CH > –C~6~H~5~ > –CH=CH~2~**. Carbon **sp** có nhiều tính s nhất (50%), giữ electron gần hạt nhân nhất nên hút electron mạnh nhất.

**Thứ tự +I** (tr. 102): **–C(CH~3~)~3~ > –CH(CH~3~)~2~ > –CH~2~CH~3~ > –CH~3~**. Gốc alkyl càng phân nhánh, càng nhiều nhóm CH~3~ thì đẩy electron càng mạnh.

> [!bay]
> - **–NH~2~ và –OH có hiệu ứng −I** (N, O âm điện hơn C), dù khi gắn vào hệ liên hợp chúng lại "cho" electron (+C, mục 3). Đừng nhầm hai hiệu ứng.
> - Gốc phenyl –C~6~H~5~ và vinyl –CH=CH~2~ có **−I** (carbon sp^2^ âm điện hơn carbon sp^3^), không phải +I như gốc alkyl.
> - Mốc so sánh là **H** (I = 0), không phải carbon.

### 2.3. Ảnh hưởng đến tính acid của acid carboxylic

Giáo trình đưa bảng hằng số acid K~a~ (tr. 102). Ở đây bổ sung thêm pK~a~ (= −lg K~a~; **pK~a~ càng nhỏ, acid càng mạnh**) theo các bảng số liệu hiện hành:

| Acid | K~a~ (giáo trình) | pK~a~ (tham khảo) | Nhóm gắn với –COOH |
|---|---|---|---|
| (CH~3~)~3~C–COOH | 0,94·10^−5^ | 5,03 | +I mạnh nhất (tert-butyl) |
| CH~3~–COOH | 1,76·10^−5^ | 4,76 | +I của CH~3~ |
| C~6~H~5~–CH~2~–COOH | 5,03·10^−5^ | 4,31 | −I của phenyl (qua 1 CH~2~) |
| H–COOH | 21,4·10^−5^ | 3,75 | H: I = 0 |
| Br–CH~2~–COOH | 138·10^−5^ | 2,90 | −I của Br |
| Cl–CH~2~–COOH | 155·10^−5^ | 2,87 | −I của Cl |
| F–CH~2~–COOH | 217·10^−5^ | 2,59 | −I của F (mạnh nhất) |

**Vì sao?** Acid càng mạnh khi anion RCOO^−^ sinh ra càng **bền**.

- Nhóm **hút** electron (−I) kéo bớt mật độ electron khỏi nhóm –COO^−^. Điện tích âm được **phân tán**, anion bền hơn, H^+^ dễ tách hơn → **acid mạnh hơn**. Đồng thời liên kết O–H cũng phân cực mạnh hơn.
- Nhóm **đẩy** electron (+I) dồn thêm electron vào –COO^−^, anion kém bền → **acid yếu hơn**. Vì thế HCOOH mạnh hơn CH~3~COOH, và CH~3~COOH mạnh hơn (CH~3~)~3~CCOOH.

![Hình 2. So sánh ion acetat và ion cloacetat](acetat-cloacetat.svg)

Nhiều nhóm hút cùng lúc thì hiệu ứng **cộng dồn**: CH~3~COOH (pK~a~ 4,76) < ClCH~2~COOH (2,87) < Cl~2~CHCOOH (1,35) < Cl~3~CCOOH (≈ 0,7). Đây chính là đáp án bài tập 3.7c của giáo trình.

> [!bay] Số liệu trong bảng của sách
> Các giá trị K~a~ của acid halogenoacetic và HCOOH trong giáo trình hơi khác các bảng hiện nay (ví dụ K~a~ của FCH~2~COOH hiện ghi ≈ 2,6·10^−3^, của ClCH~2~COOH ≈ 1,35·10^−3^, của HCOOH ≈ 1,8·10^−4^). **Thứ tự mạnh – yếu thì không đổi**, và đi thi chỉ cần thứ tự.

> [!ung-dung] Acid tricloacetic (TCA) trong y học
> Ba nguyên tử Cl có −I cộng dồn làm Cl~3~C–COOH mạnh gần bằng acid vô cơ. Vì vậy TCA:
> - làm **tủa protein**: dùng trong phòng xét nghiệm để loại protein khỏi mẫu trước khi định lượng;
> - làm **đông vón mô bề mặt**: dùng trong da liễu (lột da hóa học, chấm mụn cóc, sùi mào gà) — chỉ do bác sĩ thực hiện vì dễ gây bỏng, sẹo.
> Cũng từ đó: **dung dịch acid hữu cơ "mạnh" vẫn ăn da** như acid vô cơ, phải cẩn thận khi pha chế.

### 2.4. Đặc điểm quan trọng nhất: tắt rất nhanh theo khoảng cách

Hiệu ứng cảm ứng **giảm rất nhanh khi mạch carbon kéo dài**. Ví dụ với các acid clobutanoic (Giáo trình tr. 103, xem Hình 1):

| Acid | Vị trí Cl | K~a~ (giáo trình) |
|---|---|---|
| CH~3~–CH~2~–CHCl–COOH | C2 (α) | 139·10^−5^ |
| CH~3~–CHCl–CH~2~–COOH | C3 (β) | 8,9·10^−5^ |
| ClCH~2~–CH~2~–CH~2~–COOH | C4 (γ) | 3,0·10^−5^ |

Chỉ dời Cl xa thêm một carbon, K~a~ đã giảm khoảng **15 lần**. **Sau ba nguyên tử carbon**, hiệu ứng cảm ứng chỉ còn lại không đáng kể.

**Vì sao tắt nhanh?** Liên kết σ khó bị phân cực. Mỗi bước truyền, phần điện tích "cảm ứng" sang liên kết kế tiếp chỉ còn một phần nhỏ (giống tiếng vọng nhỏ dần).

> [!vi-du] Bài tập 3.9 của giáo trình
> Dãy theo tính acid tăng dần: CH~3~COOH < NC–CH~2~CH~2~–COOH < CH~3~CH(CN)–COOH < NC–CH~2~–COOH.
> - Nhóm –C≡N có −I mạnh. Ở chất thứ hai, CN gắn ở carbon β (xa –COOH thêm một bậc) nên tác dụng yếu đi nhiều.
> - Ở hai chất cuối, CN đều gắn ngay carbon α. Chất thứ ba có thêm nhóm CH~3~ (+I) nên yếu hơn một chút so với acid cyanoacetic.
> - Giáo trình tóm tắt: hiệu ứng của CN giảm khi mạch truyền dài ra.

## 3. Hiệu ứng liên hợp (C)

### 3.1. Hệ liên hợp — electron "không định chỗ"

**Hệ liên hợp** là hệ có **liên kết đôi và liên kết đơn xen kẽ nhau**. Ví dụ (Giáo trình tr. 103):

- **Buta-1,3-dien** CH~2~=CH–CH=CH~2~: hai liên kết C=C cách nhau một liên kết đơn.
- **Acrolein** CH~2~=CH–CH=O: liên kết C=C và C=O cách nhau một liên kết đơn.

Trong buta-1,3-dien, **cả bốn C đều lai hóa sp^2^**, nên 4 C và 6 H nằm **trên cùng một mặt phẳng**. Mỗi C còn một orbital p vuông góc mặt phẳng đó. Các orbital p này **không chỉ xen phủ từng cặp** (C1–C2, C3–C4) mà còn xen phủ **liên tiếp** qua C2–C3. Kết quả là một **orbital phân tử chung** trải trên cả 4 carbon: electron π **không định chỗ** (giải tỏa) trên toàn hệ. Hiện tượng này gọi là **sự liên hợp**.

Có hai kiểu liên hợp (Giáo trình tr. 104):

| Kiểu | Thành phần | Ví dụ |
|---|---|---|
| **Liên hợp π–π** | Liên kết π nối với liên kết π qua một liên kết đơn | Buta-1,3-dien, acrolein, benzen |
| **Liên hợp p–π** | Nguyên tử có **cặp electron p chưa liên kết** gắn với C mang liên kết π | Vinyl clorid CH~2~=CH–Cl̈ (cặp electron p của Cl xen phủ với orbital π) ; phenol, anilin |

**Điều kiện**: liên hợp chỉ xảy ra trên **hệ phẳng**, nơi trục các orbital p (π và p) **song song** với nhau. Nếu phân tử bị xoắn, các orbital p không còn song song, sự liên hợp bị phá.

**Bằng chứng: độ dài liên kết bị "san bằng"** (Giáo trình tr. 104):

| Liên kết | Độ dài |
|---|---|
| C–C đơn bình thường (alkan) | 1,54 Å |
| C–C đơn ở giữa buta-1,3-dien | **1,46 Å** (ngắn hơn: mang một phần tính chất liên kết đôi) |
| C–C trong benzen (6 liên kết như nhau) | **1,39 Å** |
| C=C đôi bình thường (ethylen) | 1,34 Å |

Tương tự, liên kết C–Cl trong vinyl clorid ngắn và bền hơn C–Cl trong ethyl clorid.

**Vòng benzen** là **hệ liên hợp kín**: 6 electron p của 6 carbon xen phủ đều nhau, tạo một orbital phân tử bao trùm cả vòng (hai "vành" electron ở trên và dưới mặt phẳng vòng). Vì thế cả 6 liên kết C–C dài bằng nhau (1,39 Å), nằm giữa liên kết đơn và đôi.

### 3.2. Hiệu ứng liên hợp: định nghĩa và hai loại

Khi một nguyên tử hoặc nhóm nguyên tử có khả năng **đẩy hoặc hút electron** gắn vào hệ liên hợp, mật độ electron của **cả hệ** bị phân bố lại. Hiện tượng đó gọi là **hiệu ứng liên hợp**, ký hiệu **C** (*Conjugate effect*) (Giáo trình tr. 105).

| | **Hiệu ứng +C** (đẩy electron vào hệ) | **Hiệu ứng −C** (hút electron khỏi hệ) |
|---|---|---|
| Nhóm điển hình | Nhóm có **cặp electron tự do** ở nguyên tử gắn trực tiếp vào hệ: –O^−^, –NH~2~, –OH, –OR, –F, –Cl, –Br, –I | Nhóm có **liên kết bội với nguyên tử âm điện**: –NO~2~, –C≡N, –CHO, >C=O, –COOH, –COOR |
| Ví dụ trong sách | Cl trong vinyl clorid; –OH trong phenol | O trong nhóm C=O của acrolein |
| Kết quả | Đầu xa của hệ (hoặc vị trí ortho, para của vòng) mang δ− | Đầu xa của hệ mang δ+ |

**Ví dụ +C — phenol.** Cặp electron chưa liên kết của O liên hợp với vòng benzen. Mật độ electron tăng ở **hai vị trí ortho và vị trí para** (mang δ−). Do đó phản ứng **thế electrophil** (như brom hóa) xảy ra chủ yếu ở ortho và para (Giáo trình tr. 105–106):

=> C~6~H~5~OH + 3 Br~2~ → 2,4,6-tribromophenol↓ (trắng) + 3 HBr

Phản ứng xảy ra ngay ở nhiệt độ thường, không cần xúc tác. Benzen thì phải có xúc tác Fe/FeBr~3~ mới phản ứng với brom. Đó là bằng chứng cho thấy –OH làm vòng giàu electron.

**Ví dụ −C — acrolein.** O của nhóm C=O hút electron π về phía mình qua cả hệ: O mang δ−, còn **C cuối mạch** (CH~2~=) mang δ+ (Giáo trình tr. 105).

**Ví dụ: CH~3~ gắn vào hệ liên hợp** (penta-1,3-dien CH~3~–CH=CH–CH=CH~2~). Giáo trình đánh số C1 là CH~2~ đầu mạch. Nhóm CH~3~ đẩy electron vào hệ, làm **C1 mang δ−** và **C4 mang δ+**. Khi cộng HBr, **H^+^ gắn vào C1, Br^−^ gắn vào C4** (cộng 1,4), tạo CH~3~–CHBr–CH=CH–CH~3~ (4-bromopent-2-en) (Giáo trình tr. 105).

> [!cap-nhat] Hiệu ứng siêu liên hợp
> Giáo trình gọi tác dụng đẩy electron của CH~3~ vào hệ liên hợp (penta-1,3-dien) là hiệu ứng **+C**. Nhóm CH~3~ không có cặp electron tự do hay liên kết π. Hiện nay tác dụng này được gọi riêng là **hiệu ứng siêu liên hợp** (hyperconjugation, ký hiệu **+H**): các liên kết **σ C–H** của nhóm alkyl xen phủ một phần với orbital π (hoặc orbital p trống) bên cạnh. Siêu liên hợp giải thích vì sao carbocation bậc III bền hơn bậc I và anken nhiều nhóm thế bền hơn (sẽ gặp ở bài *Phản ứng của hợp chất hữu cơ* (hc-04)). Đi thi, trả lời theo giáo trình: CH~3~ gây +C (và +I).

> [!cap-nhat] Ký hiệu quốc tế
> Hiệu ứng liên hợp **±C** của giáo trình tương ứng với **hiệu ứng mesomer ±M** (hoặc hiệu ứng cộng hưởng **±R**) trong sách nước ngoài. Ba ký hiệu là cùng một khái niệm.

### 3.3. Đặc điểm: truyền xa, gần như không giảm

**Khác với hiệu ứng cảm ứng**, hiệu ứng liên hợp **gần như không giảm** khi mạch liên hợp kéo dài: nó được truyền đi trong **toàn bộ hệ liên hợp** (Giáo trình tr. 106). Ví dụ trong CH~2~=CH–CH=CH–CH=O, nhóm C=O vẫn làm C cuối mạch (cách 4 carbon) mang δ+.

**Vì sao?** Electron π không bị "khóa" giữa hai nguyên tử mà di chuyển trong orbital phân tử chung của cả hệ. Ảnh hưởng ở một đầu được chuyển nguyên vẹn đến đầu kia, miễn hệ còn liên hợp (phẳng, xen kẽ đôi – đơn).

| So sánh | Hiệu ứng cảm ứng (I) | Hiệu ứng liên hợp (C) |
|---|---|---|
| Đường truyền | Liên kết **σ** | Hệ **π, p liên hợp** |
| Nguồn gốc | Chênh lệch **độ âm điện** | Xen phủ orbital p – π |
| Theo khoảng cách | **Giảm rất nhanh**, ~0 sau 3 C | **Gần như không giảm** trên toàn hệ |
| Điều kiện | Có ở mọi phân tử có liên kết phân cực | Cần **hệ liên hợp phẳng** |
| Biểu diễn | Mũi tên thẳng trên liên kết σ | Mũi tên cong |

### 3.4. Thứ tự độ mạnh của hiệu ứng liên hợp

**Hiệu ứng −C** (Giáo trình tr. 106):

- **>C=O > >C=NH > >C=CH~2~**, vì độ âm điện O > N > C.
- **–NO~2~ > –C≡N > –COOH > –COO^−^**. Nhóm –COO^−^ đã mang điện âm nên hút electron kém nhất.

**Hiệu ứng +C** (Giáo trình tr. 106):

- **–F > –Cl > –Br > –I**. Kích thước nguyên tử tăng từ F đến I. Orbital 2p của F cùng cỡ với orbital 2p của C nên xen phủ tốt nhất; orbital 5p của I quá lớn, xen phủ kém.
- **–NH~2~ > –OH > –F**. Độ âm điện tăng từ N đến F: nguyên tử càng âm điện thì càng "giữ chặt" cặp electron, càng khó cho đi.
- **–O^−^ > –OR**. Nguyên tử mang điện tích âm cho electron mạnh hơn chính nó khi trung hòa.

> [!bay] Thứ tự −I và +C: chỗ ngược, chỗ giống
> | Dãy | −I (hút, theo độ âm điện) | +C (cho, theo khả năng nhường cặp e) |
> |---|---|---|
> | F, OH, NH~2~ | **–F > –OH > –NH~2~** | **–NH~2~ > –OH > –F** |
> | F, Cl, Br, I | **–F > –Cl > –Br > –I** | **–F > –Cl > –Br > –I** (theo kích thước) |
>
> Đề hay hỏi "sắp xếp theo chiều **tăng dần**" (bài 3.2, 3.3, 3.5, 3.6): đọc kỹ để viết từ **yếu đến mạnh**.

### 3.5. Nhóm có hiệu ứng liên hợp đổi dấu

Một số nhóm như **vinyl CH~2~=CH–, phenyl C~6~H~5~–, ethynyl CH≡C–** có hiệu ứng liên hợp **đổi dấu tùy nhóm gắn với nó** (Giáo trình tr. 106):

- Trong **nitrobenzen** C~6~H~5~–NO~2~: –NO~2~ hút mạnh (−C), nên phenyl đóng vai **cho** electron (+C).
- Trong **anilin** C~6~H~5~–NH~2~: –NH~2~ cho electron (+C), nên phenyl đóng vai **nhận** electron (−C).

> [!vi-du] Halogen gắn vào vòng benzen: hai hiệu ứng ngược nhau
> Ở clorobenzen, Cl vừa có **−I** (hút qua σ) vừa có **+C** (cho cặp e p vào vòng). Với halogen, **−I thắng**, nên vòng nghèo electron hơn benzen và phản ứng thế chậm hơn. Nhưng +C vẫn làm vị trí ortho, para "đỡ nghèo" hơn vị trí meta, nên nhóm thế mới vẫn vào **ortho, para**. Với –OH và –NH~2~ thì ngược lại: **+C thắng −I**, vòng giàu electron, phản ứng rất dễ.

## 4. Vận dụng: so sánh tính acid và tính base

Phần này gom các dạng bài **Tự lượng giá 3.7 – 3.9** (Giáo trình tr. 107; đáp án ở tr. 251).

### 4.1. Cách làm chung

1. Viết chất về dạng R–(nhóm chức) và xác định **nhóm thế R** cùng vị trí của nó.
2. Với mỗi nhóm thế, hỏi: **hút** hay **đẩy** electron? Bằng **I**, bằng **C**, hay cả hai? Ở gần hay xa trung tâm phản ứng?
3. **Acid**: yếu tố nào làm **anion bền hơn** (hút e, phân tán điện tích âm) thì acid mạnh hơn.
4. **Base** (amin): yếu tố nào làm **cặp electron của N giàu hơn, sẵn sàng hơn** để nhận H^+^ thì base mạnh hơn.

### 4.2. Tính acid của alcol, phenol, acid carboxylic

![Hình 3. Các công thức cộng hưởng của ion phenoxid](phenoxid.svg)

| Chất | pK~a~ (tham khảo) | Giải thích |
|---|---|---|
| C~2~H~5~OH | ≈ 16 | +I của gốc ethyl; anion C~2~H~5~O^−^ có điện tích âm dồn trên O |
| CH~3~OH | ≈ 15,5 | +I của CH~3~ (yếu hơn C~2~H~5~) |
| p-CH~3~C~6~H~4~OH (p-cresol) | 10,3 | Như phenol nhưng có thêm +I của CH~3~ nên yếu hơn phenol một chút |
| C~6~H~5~OH (phenol) | 10,0 | Vòng benzen hút e (−C), anion phenoxid được giải tỏa (Hình 3) |
| p-O~2~N–C~6~H~4~OH | 7,2 | –NO~2~ hút mạnh (−I, −C) → phenoxid càng bền |
| CH~3~COOH | 4,76 | –COO^−^ có hai O chia đều điện tích âm; nhóm C=O có −C, −I; nhưng có +I của CH~3~ |
| HCOOH | 3,75 | Như trên, không có nhóm đẩy e (H: I = 0) |
| CH~3~CHClCOOH | 2,8 | Thêm −I của Cl ở carbon α |

Đáp án giáo trình (tr. 251):

- **3.7a**: CH~3~OH < C~6~H~5~OH < HCOOH.
- **3.7d**: C~2~H~5~OH < p-CH~3~C~6~H~4~OH < C~6~H~5~OH < CH~3~COOH < CH~3~CHClCOOH.

> [!bay]
> - **Phenol có tính acid nhưng rất yếu**: tác dụng được với NaOH (alcol thì không), nhưng **yếu hơn acid carbonic**, nên không đẩy được CO~2~ ra khỏi NaHCO~3~. Ngược lại, CO~2~ sục vào dung dịch natri phenolat sẽ giải phóng phenol (vẩn đục).
> - Acid carboxylic mạnh hơn phenol nhiều: anion RCOO^−^ có điện tích âm chia đều trên **hai nguyên tử O** (rất âm điện), còn phenoxid phải "gửi" điện tích lên các nguyên tử **C** của vòng.

### 4.3. Tính base của amin

Amin là base vì **N còn một cặp electron tự do** để nhận H^+^:

=> R–NH~2~ + H~2~O ⇌ R–NH~3~^+^ + OH^−^

| Chất | pK~a~ của acid liên hợp (tham khảo; càng lớn base càng mạnh) | Giải thích |
|---|---|---|
| p-O~2~N–C~6~H~4~NH~2~ (p-nitroanilin) | 1,0 | Cặp e của N vừa liên hợp vào vòng, vừa bị –NO~2~ (−I, −C) kéo mạnh |
| C~6~H~5~NH~2~ (anilin) | 4,6 | Cặp e của N liên hợp vào vòng (+C của NH~2~, −C của phenyl) → kém sẵn sàng |
| NH~3~ | 9,25 | Mốc so sánh |
| CH~3~NH~2~ | 10,6 | +I của CH~3~ làm N giàu electron |
| (CH~3~)~2~NH | 10,7 | Hai nhóm +I |

Đáp án giáo trình (tr. 251):

- **3.8a**: C~6~H~5~NH~2~ < NH~3~ < CH~3~NH~2~.
- **3.8b**: thứ tự đúng là **p-O~2~N–C~6~H~4~NH~2~ < C~6~H~5~NH~2~ < CH~3~NHCH~3~**.

> [!bay] Đáp án in trong sách bị đảo
> Phần hướng dẫn trả lời (tr. 251) in câu 3.8b là "p-O~2~N–C~6~H~4~NH~2~ < CH~3~NHCH~3~ < C~6~H~5~NH~2~". Thứ tự này **mâu thuẫn với chính lời giải thích kèm theo** (−C của C~6~H~5~ làm giảm, +I của CH~3~ làm tăng tính base) và với số liệu thực nghiệm: dimethylamin là base mạnh hơn anilin khoảng **10^6^ lần**. Hãy viết: p-nitroanilin < anilin < dimethylamin.

> [!vi-du] Ngoài phạm vi sách: amin bậc III trong nước
> Theo hiệu ứng +I đơn thuần, (CH~3~)~3~N phải là base mạnh nhất. Thực tế trong nước nó **yếu hơn** (CH~3~)~2~NH và CH~3~NH~2~ (pK~a~ 9,8), vì ion (CH~3~)~3~NH^+^ chỉ có một H để tạo liên kết hydro với nước nên kém được "ổn định" bởi dung môi. Ở pha khí thì thứ tự đúng như hiệu ứng +I dự đoán.

> [!ung-dung] Tính acid – base quyết định cách dùng thuốc
> - Nhiều thuốc là **amin** (base yếu): morphin, lidocain, atropin, ephedrin… Vì là base nên chúng tạo **muối với acid** (morphin hydroclorid, lidocain hydroclorid). Dạng muối tan tốt trong nước, nên pha được thuốc tiêm.
> - **Paracetamol** có nhóm –OH phenol (pK~a~ ≈ 9,5) và nhóm amid. N của amid **gần như không có tính base**, vì cặp electron của N đã liên hợp với nhóm C=O bên cạnh (+C của N, −C của C=O).
> - **Aspirin** là acid carboxylic (pK~a~ ≈ 3,5). Trong dạ dày (pH 1–2) nó tồn tại phần lớn ở dạng phân tử, không ion hóa, nên thấm được vào niêm mạc dạ dày — một phần lý do aspirin gây hại niêm mạc dạ dày.

> [!yhct] Alkaloid là base — cơ sở hóa học của "chế với giấm"
> Phần lớn **alkaloid** trong dược liệu là **amin dị vòng**, tức là base yếu. Ở dạng base tự do, nhiều alkaloid **khó tan trong nước**; khi gặp acid chúng tạo **muối dễ tan**.
> - Đây là cách các sách bào chế giải thích việc **chế giấm** với **Diên hồ sách** (Huyền hồ): acid acetic tạo muối acetat với alkaloid (tetrahydropalmatin…), giúp hoạt chất **tan vào nước sắc nhiều hơn**. Một số nghiên cứu ghi nhận hàm lượng alkaloid hòa tan tăng sau khi chế giấm; tác dụng lâm sàng tăng đến đâu thì chưa có nhiều bằng chứng chắc chắn.
> - Ngược lại, khi chiết alkaloid ở dạng base để định lượng, người ta **kiềm hóa** (NH~3~) rồi chiết bằng dung môi hữu cơ.

## Tóm tắt

| Nội dung | Ghi nhớ |
|---|---|
| Phân cực liên kết | Lệch về nguyên tử âm điện hơn (δ−). σ: mũi tên thẳng; π: mũi tên cong |
| Hiệu ứng cảm ứng I | Truyền qua σ, **tắt nhanh** (≈ 0 sau 3 C). Chuẩn: H (I = 0) |
| −I | –F > –Cl > –Br > –I ; –F > –OH > –NH~2~ ; –C≡CH > –C~6~H~5~ > –CH=CH~2~ |
| +I | –C(CH~3~)~3~ > –CH(CH~3~)~2~ > –C~2~H~5~ > –CH~3~ |
| Hệ liên hợp | Đôi – đơn xen kẽ, **phẳng**; π–π (butadien, acrolein, benzen), p–π (vinyl clorid, phenol). C–C butadien 1,46 Å; benzen 1,39 Å |
| Hiệu ứng liên hợp C | Truyền qua hệ liên hợp, **không giảm** theo chiều dài |
| −C | >C=O > >C=NH > >C=CH~2~ ; –NO~2~ > –C≡N > –COOH > –COO^−^ |
| +C | –F > –Cl > –Br > –I ; –NH~2~ > –OH > –F ; –O^−^ > –OR |
| Đổi dấu | Phenyl, vinyl, ethynyl: +C trong nitrobenzen, −C trong anilin |
| Tính acid | Hút e (−I, −C) → anion bền → acid **mạnh**; đẩy e (+I) → acid **yếu** |
| Tính base amin | Đẩy e (+I) → base **mạnh**; liên hợp vào vòng / hút e → base **yếu** |
