---
title: Glucid
thoi-gian: 30 phút
muc-tieu:
- Nêu được định nghĩa, công thức chung và cách phân loại glucid.
- Viết được công thức mạch hở (Fischer) và mạch vòng (Haworth) của glucose, fructose; phân biệt được D/L và α/β.
- Trình bày được các phản ứng hóa học của monosaccharid và dùng chúng để nhận biết.
- So sánh được cấu tạo, tính khử của saccharose, maltose, lactose; tinh bột, glycogen, cellulose.
- Nêu được ý nghĩa y học và liên hệ với dược liệu, bào chế YHCT.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Glucid là **polyhydroxy-aldehyd hoặc polyhydroxy-ceton** (và những chất thủy phân ra chúng).
> 2. Glucose = aldohexose, fructose = cetohexose; cùng công thức C~6~H~12~O~6~.
> 3. Trong dung dịch chủ yếu ở **dạng vòng** (hemiacetal nội phân tử) → sinh ra nhóm **–OH hemiacetal** ở C anomer, có hai dạng α và β.
> 4. Còn –OH hemiacetal tự do ⇒ **có tính khử**: glucose, fructose, maltose, lactose. **Saccharose không khử.**
> 5. Tinh bột, glycogen = chuỗi **α**-glucose (tiêu hóa được); cellulose = chuỗi **β**-glucose (người không tiêu hóa được).

## 1. Glucid là gì — phân loại

Glucid (carbohydrat, saccharid) là nhóm hợp chất tự nhiên mà phần lớn có công thức chung **C~n~(H~2~O)~m~**. Vì công thức trông như "carbon ngậm nước" nên còn gọi là **hydrat carbon**. Ví dụ: glucose C~6~H~12~O~6~ = C~6~(H~2~O)~6~; saccharose C~12~H~22~O~11~ = C~12~(H~2~O)~11~.

Thực chất glucid **không phải** là carbon ngậm nước. Định nghĩa đúng theo cấu tạo: glucid là các **aldehyd hoặc ceton có nhiều nhóm –OH** (polyhydroxy-aldehyd/ceton), cùng các chất mà khi thủy phân tạo ra chúng.

> [!bay]
> - Có chất đúng công thức C~n~(H~2~O)~m~ nhưng **không phải glucid**: formaldehyd CH~2~O, acid acetic C~2~H~4~O~2~, acid lactic C~3~H~6~O~3~.
> - Có glucid **không đúng** công thức đó: deoxyribose C~5~H~10~O~4~ (trong DNA/ADN).
> - Vì vậy nhận diện glucid phải dựa vào **cấu tạo**, không dựa vào công thức phân tử.

| Nhóm | Đặc điểm | Ví dụ |
|---|---|---|
| **Monosaccharid** (monose) | Không thủy phân được nữa — là "viên gạch" | Triose (C~3~), pentose: ribose, deoxyribose; hexose: glucose, fructose, galactose |
| **Oligosaccharid** | Thủy phân cho 2–10 monose; vẫn tan, có vị ngọt | Disaccharid: saccharose, maltose, lactose; trisaccharid: raffinose |
| **Polysaccharid** | Hàng trăm – hàng nghìn gốc monose; không ngọt, khó tan | Tinh bột, glycogen, cellulose |

> [!bay] Cách chia của giáo trình (dễ ra thi)
> Giáo trình chỉ chia glucid thành **2 nhóm**: **monosaccharid** (monose) và **polysaccharid** (polyose). Nhóm polysaccharid gồm mọi glucid thủy phân được, kể cả saccharose và raffinose C~18~H~32~O~16~. Polysaccharid lại chia thành:
> - *Polysaccharid có tính chất đường* = oligosaccharid (disaccharid, trisaccharid…): phân tử nhỏ, ngọt, tan.
> - *Polysaccharid không có tính chất đường*: tinh bột, cellulose, glycogen.

**Cách gọi tên monosaccharid** = (aldo- hoặc ceto-) + (số C) + -ose:

- Có nhóm –CHO → **aldose**; có nhóm C=O ở giữa mạch → **cetose**.
- 3C triose, 4C tetrose, 5C pentose, 6C hexose.
- Glucose = **aldohexose**; fructose = **cetohexose**; ribose = aldopentose.

## 2. Cấu tạo monosaccharid

### 2.1. Dạng mạch hở — công thức Fischer

Mạch carbon được vẽ thẳng đứng và đánh số từ đầu gần nhóm carbonyl nhất (C=O ở C1 của aldose, ở C2 của cetose). Nhóm –OH đặt sang trái hoặc phải.

![Hình 1. Công thức Fischer của D-glucose và D-fructose](fischer.svg)

> [!ghi-nho] Mẹo nhớ glucose
> Đọc vị trí –OH từ C2 đến C5: **Phải – Trái – Phải – Phải**.
> Fructose giống glucose từ C3 đến C6; chỉ khác ở C1–C2: C2 là nhóm ceton (C=O), C1 là CH~2~OH.

### 2.2. Dạng mạch vòng — vì sao đường "tự cuộn lại"?

Aldehyd phản ứng với alcol tạo **hemiacetal**. Glucose có cả –CHO lẫn –OH trong cùng một phân tử, nên nhóm **–OH ở C5 cộng vào C=O ở C1** của chính nó. Đó là phản ứng tạo **hemiacetal nội phân tử**.

- **Glucose** khép vòng **6 cạnh** (5C + 1O), gọi là dạng **pyranose**.
- **Fructose** dùng –OH ở C5 cộng vào C=O ở **C2**, khép vòng **5 cạnh** (4C + 1O), gọi là dạng **furanose**. Đây là dạng có trong saccharose và các ester phosphat (fructose-6-phosphat…). *Fructose tự do trong nước thực ra tồn tại chủ yếu ở dạng vòng 6 cạnh (pyranose, do –OH ở C6 khép vòng).*
- Carbon của nhóm C=O cũ trở thành **carbon anomer** (C1 của glucose, C2 của fructose). Nó mang một nhóm –OH mới gọi là **–OH hemiacetal** (giáo trình gọi là –OH *semiacetal* hay *bán acetal*; còn gọi –OH glycosid). Đây là nhóm –OH **hoạt động nhất** của phân tử.

![Hình 2. Công thức Haworth của α-, β-glucose và β-fructose](haworth.svg)

**α hay β?** Xét vị trí –OH ở carbon anomer so với nhóm CH~2~OH cuối mạch (C6):

- **α**: –OH anomer nằm **khác phía** CH~2~OH (ở hình Haworth là hướng **xuống**).
- **β**: –OH anomer nằm **cùng phía** CH~2~OH (hướng **lên**).

Giáo trình còn gọi α-glucose là dạng **cis** và β-glucose là dạng **trans**, xét theo –OH ở C1 so với –OH ở C2.

> [!vi-du] Hiểu sâu hơn
> Vòng 6 cạnh thật ra không phẳng mà có dạng **ghế** (như cyclohexan). Ở **β-glucose**, mọi nhóm thế lớn đều nằm ở vị trí **biên/xích đạo** (equatorial), ít va chạm nhau nhất. Vì thế β-glucose bền nhất. Khi cân bằng trong nước có khoảng **64% β : 36% α**, còn dạng mạch hở chưa tới 1%.

### 2.3. Hiện tượng quay hỗn hợp (mutarotation)

Pha α-glucose tinh khiết vào nước thì góc quay cực ban đầu là +112°. Góc này giảm dần rồi dừng ở **+52,7°**. Pha β-glucose (+18,7°) thì góc quay tăng dần đến đúng +52,7°.

Lý do: trong nước, vòng mở ra thành mạch hở rồi khép lại, nên α và β **chuyển hóa qua lại** cho đến khi đạt cân bằng. Chỉ đường nào **còn –OH hemiacetal tự do** mới có hiện tượng này.

## 3. Đồng phân của monosaccharid

Giáo trình phân 4 loại đồng phân:

| Loại | Ví dụ |
|---|---|
| Khác nhóm chức | Glucose (aldehyd) ↔ fructose (ceton) |
| Khác mạch carbon (thực chất là hỗ biến vòng – mạch hở) | Dạng mạch hở ↔ dạng vòng |
| Khác vị trí –OH hemiacetal | α-glucose ↔ β-glucose (gọi là **anomer**) |
| **Đồng phân quang học** | D-glucose ↔ L-glucose |

**Đồng phân quang học.** Carbon bất đối (C\*) là carbon gắn với 4 nhóm khác nhau. Có n C\* thì có **2^n^** đồng phân quang học:

- Aldohexose (glucose) có **4 C\*** (C2–C5), nên có 2^4^ = **16 đồng phân**: 8 dãy D và 8 dãy L; về chiều quay thì một nửa quay phải, một nửa quay trái.
- Cetohexose (fructose) có **3 C\*** (C3–C5), nên có 2^3^ = **8 đồng phân**.

**Dãy D hay L** được xác định bởi –OH ở **C\* xa nhóm C=O nhất** (ở hexose là C5): nằm bên **phải** là **D**, bên **trái** là **L**. Đường trong tự nhiên hầu hết thuộc dãy **D**.

> [!bay]
> - **D/L không cho biết chiều quay mặt phẳng ánh sáng phân cực.** Chiều quay được ký hiệu riêng bằng (+) quay phải, (−) quay trái.
> - Ví dụ: D-glucose quay phải, D-(+)-glucose (tên cũ *dextrose*). D-fructose lại quay **trái**, D-(−)-fructose (tên cũ *levulose*). Cả hai vẫn cùng thuộc dãy D.
> - Thêm hai thuật ngữ hay gặp ở môn Hóa sinh: **epimer** là hai đường chỉ khác nhau ở **một** C\*. Glucose và mannose là epimer ở C2; glucose và galactose là epimer ở C4.

## 4. Tính chất của monosaccharid

### 4.1. Tính chất vật lý

Monosaccharid là chất kết tinh, không màu, vị ngọt, **dễ tan trong nước** (nhờ nhiều nhóm –OH tạo liên kết hydro) và **có tính quang hoạt**.

Độ ngọt giảm dần theo thứ tự: fructose > saccharose > glucose > maltose > lactose.

### 4.2. Tính chất hóa học — "hai con người trong một phân tử"

Monosaccharid vừa mang tính chất của **polyalcol** (nhiều –OH), vừa mang tính chất của **aldehyd/ceton** (nhóm C=O). Ngoài ra nó còn có phản ứng riêng của nhóm **–OH hemiacetal**.

#### a) Tính chất polyalcol

- **Hòa tan Cu(OH)~2~** ở nhiệt độ thường, tạo **dung dịch xanh lam** (phức đồng). Phản ứng cần ít nhất hai –OH kề nhau. Glycerol cũng cho phản ứng này, nên đây chỉ là dấu hiệu chung của polyalcol.
- **Tạo ester.** Quan trọng nhất là ester với acid phosphoric: **glucose-6-phosphat**, glucose-1-phosphat, fructose-6-phosphat, fructose-1,6-bisphosphat (giáo trình ghi *diphosphat*). Đây là các chất trung gian **quan trọng** trong chuyển hóa glucid ở tế bào (sẽ học ở Hóa sinh, chương 7).

#### b) Tính chất của nhóm carbonyl

**Phản ứng oxy hóa (tính khử)**

- Tráng bạc với **AgNO~3~/NH~3~** (thuốc thử Tollens): glucose → acid gluconic (trong NH~3~ thực chất tạo muối amoni gluconat), đồng thời tạo lớp bạc sáng.
- Khử **Cu(OH)~2~ khi đun nóng** hoặc thuốc thử **Fehling**: tạo kết tủa **Cu~2~O đỏ gạch**.
- Nước brom oxy hóa được nhóm –CHO của **aldose** nhưng **không** oxy hóa được cetose. Đây là cách phân biệt glucose với fructose.
- Phản ứng oxy hóa này từng được dùng để **định tính, định lượng glucose trong nước tiểu** (xem mục 7).

=> R–CHO + [O] → R–COOH  (glucose → acid gluconic)

**Phản ứng khử**

- H~2~/Ni chuyển glucose thành **sorbitol** (hexol). Sorbitol được dùng làm chất tạo ngọt cho người cần hạn chế đường và làm thuốc nhuận tràng thẩm thấu.

**Phản ứng cộng HCN**

- Tạo **cyanohydrin**, chất này thủy phân thành acid glucoheptonic (mạch dài thêm 1C).
- Fructose cũng cộng HCN và phản ứng với phenylhydrazin như glucose. Quy tắc chung của giáo trình: **aldose có phản ứng của glucose, cetose có phản ứng của fructose.**

**Phản ứng với phenylhydrazin**

- Tạo **osazon**, là những tinh thể có hình dạng đặc trưng. Phản ứng dùng để nhận biết và tách riêng từng loại đường.

> [!bay]
> - **Glucose, fructose và mannose cho cùng một osazon.** Lý do: phản ứng làm "mất dấu" cấu hình ở C1 và C2, mà ba đường này chỉ khác nhau ở C1–C2.
> - **Fructose không có –CHO nhưng vẫn tráng bạc và khử Fehling.** Trong môi trường kiềm của thuốc thử, fructose chuyển hóa một phần thành glucose (xem mục d).

#### c) Phản ứng của –OH hemiacetal: tạo glycosid

Đun đường với alcol (có HCl khan làm xúc tác) thì –OH hemiacetal được thay bằng –OR, tạo **glycosid** (với glucose gọi là *glucosid*). Glycosid cũng có hai dạng α và β (giáo trình ghi: α-glucose cho α-glucosid, β-glucose cho β-glucosid). Thực tế khi tổng hợp bằng HCl khan, sản phẩm là hỗn hợp α và β, trong đó methyl α-glucosid chiếm ưu thế. Khi đã tạo thành, cấu hình α/β của glycosid được **cố định**.

=> α-glucose + CH~3~OH ⇌ methyl α-glucosid + H~2~O

- Phần **đường** gọi là **glycon**, phần không phải đường (R) gọi là **aglycon**.
- Glycosid **mất tính khử** và **không còn quay hỗn hợp**, vì C anomer đã bị "khóa".
- Glycosid **bị thủy phân** khi đun với acid vô cơ loãng hoặc nhờ **enzym** đặc hiệu, giải phóng lại đường và aglycon.

> [!yhct] Glycosid — "chìa khóa" của hóa học dược liệu
> Rất nhiều hoạt chất trong cây thuốc là **glycosid**. Phần aglycon thường quyết định tác dụng; phần đường ảnh hưởng đến độ tan và sự hấp thu.
> - **Saponin**: glycyrrhizin của **Cam thảo**; ginsenosid của **Nhân sâm**, **Tam thất**.
> - **Flavonoid glycosid**: rutin của **Hoa hòe**, giúp bền thành mạch.
> - **Anthraglycosid**: **Đại hoàng**, **Phan tả diệp**, **Muồng trâu**, có tác dụng nhuận tràng, tẩy.
> - **Glycosid tim**: lá **Trúc đào**. Cây **rất độc**, chỉ dùng dạng thuốc đã chuẩn hóa (các cây chứa glycosid tim và độc tính: xem bài *Vận chuyển vật chất qua màng tế bào*, mã sh-04).
> - **Glycosid sinh cyanid**: amygdalin trong **Khổ hạnh nhân** (Dược điển Trung Quốc xếp **có độc nhỏ**), **Đào nhân**; linamarin trong **sắn**. Khi enzym trong chính cây thủy phân, chất này giải phóng **HCN rất độc**.
>
> **Ý nghĩa với bào chế:** nhiều dược liệu phải được **sao, chưng hoặc đồ** để **diệt enzym**, giữ cho glycosid không bị thủy phân. Ví dụ: **Hoàng cầm** cần chưng hoặc đồ; nếu ngâm nước lạnh, enzym thủy phân baicalin và dược liệu chuyển màu xanh lục. Với dược liệu chứa glycosid sinh cyanid thì phải dùng **đúng liều** và chế biến đúng cách. Diệt enzym của cây chưa loại hết nguy cơ, vì vi khuẩn đường ruột cũng thủy phân được glycosid này. Sắn phải bóc vỏ, ngâm kỹ, luộc mở vung để HCN bay hơi.

> [!cap-nhat] Ngộ độc HCN và "uống nước đường"
> Giáo trình viết rằng glucose cộng được với HCN nên "thường chữa ngộ độc sắn bằng đường". Nước đường **chỉ là biện pháp dân gian hỗ trợ** khi ngộ độc nhẹ. Ngộ độc cyanid thật sự là **cấp cứu**: phải đưa ngay đến cơ sở y tế để dùng thuốc giải đặc hiệu (hydroxocobalamin, natri thiosulfat…). Khi thi, trả lời theo giáo trình; khi hành nghề, không được trì hoãn chuyển viện.

#### d) Tác dụng với kiềm

- **Kiềm loãng, nguội**: glucose, fructose và mannose **chuyển hóa qua lại** thông qua một dạng trung gian **enediol** (–C(OH)=C(OH)–). Giáo trình gọi đây là sự **tautome hóa** (chuyển hóa tương hỗ). Đây là lý do fructose cũng có tính khử.
- **Kiềm đặc, đun nóng**: mạch carbon bị gãy và oxy hóa, tạo các sản phẩm màu nâu dạng nhựa.

#### e) Lên men (bổ sung, thực tế)

Nấm men biến glucose thành **ethanol + CO~2~** (lên men rượu). Vi khuẩn lactic biến glucose thành **acid lactic** (làm sữa chua, dưa muối). Rượu thuốc trong YHCT dùng ethanol làm dung môi chiết hoạt chất.

### 4.3. Điều chế

- **Thủy phân tinh bột** bằng acid hoặc enzym: (C~6~H~10~O~5~)~n~ + n H~2~O → n C~6~H~12~O~6~. Đây là cách sản xuất glucose trong công nghiệp.
- Giáo trình nêu thêm: oxy hóa nhẹ polyalcol (sorbitol) cho monose. Thực tế phản ứng này không chọn lọc, ít dùng.

## 5. Disaccharid

Disaccharid gồm 2 phân tử monose nối với nhau, đồng thời **loại đi 1 phân tử nước**. Nước được tách ra từ **–OH hemiacetal** của gốc thứ nhất và một –OH của gốc thứ hai. –OH của gốc thứ hai có thể là –OH alcol hoặc chính –OH hemiacetal của nó. Liên kết tạo thành gọi là **liên kết glycosid**.

![Hình 3. Cấu tạo của maltose, lactose, saccharose](disaccharid.svg)

| | **Maltose** | **Lactose** | **Saccharose** (sucrose) |
|---|---|---|---|
| Thành phần | Glucose + glucose | Galactose + glucose | Glucose + fructose |
| Liên kết | α(1→4) | β(1→4) | α1 ↔ β2 (nối giữa hai C anomer) |
| –OH hemiacetal tự do | **Còn** | **Còn** | **Không còn** |
| Tính khử, quay hỗn hợp | Có | Có | **Không** |
| Nguồn | Mạch nha (thủy phân tinh bột) | Sữa | Mía, củ cải đường |

Tính chất chung của disaccharid:

- Kết tinh, tan tốt, vị ngọt, quang hoạt.
- Hòa tan Cu(OH)~2~ tạo dung dịch xanh lam, vì còn nhiều –OH.
- Disaccharid còn –OH hemiacetal tự do (maltose, lactose) thì có tính khử và cũng cộng HCN được như glucose.
- **Thủy phân** bằng acid loãng hoặc enzym cho 2 monose:

=> C~12~H~22~O~11~ (saccharose) + H~2~O → C~6~H~12~O~6~ (glucose) + C~6~H~12~O~6~ (fructose)

Hỗn hợp glucose + fructose sinh ra khi thủy phân saccharose gọi là **đường nghịch chuyển**. Tên gọi này đến từ chiều quay cực bị **đảo ngược**: saccharose quay phải, còn hỗn hợp sau thủy phân quay trái (vì fructose quay trái mạnh). Sau thủy phân, hỗn hợp đã **có tính khử**.

> [!ung-dung] Không dung nạp lactose
> Muốn hấp thu lactose, ruột non phải có enzym **lactase** cắt lactose thành galactose và glucose. Nhiều người trưởng thành, nhất là người châu Á, giảm hoạt tính lactase. Khi đó lactose xuống đại tràng, bị vi khuẩn lên men gây **đầy hơi, đau bụng, tiêu chảy** sau khi uống sữa. Đó là **không dung nạp lactose**, không phải dị ứng sữa. Lactose kém ngọt hơn saccharose. Theo giáo trình, sữa bò chứa 4–5,5% lactose, sữa người 5,5–8,4%; đây là nguồn năng lượng quan trọng cho trẻ bú mẹ.

## 6. Polysaccharid: tinh bột, glycogen, cellulose

![Hình 4. Sơ đồ cấu tạo tinh bột, glycogen và cellulose](polysaccharid.svg)

| | Đơn vị & liên kết | Cấu trúc | Ở đâu? | Ý nghĩa |
|---|---|---|---|---|
| **Amylose** (12–25% tinh bột, theo giáo trình) | α-glucose, α(1→4); 200 đến hàng nghìn gốc | Mạch **thẳng**, cuộn xoắn | Hạt, củ | Tan trong nước nóng |
| **Amylopectin** (75–85% tinh bột) | α(1→4) + nhánh **α(1→6)**; 600–6000 gốc | **Phân nhánh** | Hạt, củ | Không tan, trương nở thành hồ |
| **Glycogen** | Như amylopectin; 2400–24000 gốc | Nhánh **nhiều hơn, ngắn hơn** | **Gan, cơ** động vật | Dự trữ glucose của cơ thể |
| **Cellulose** | **β**-glucose, β(1→4); 300–15000 gốc | Mạch thẳng, các sợi song song | Thành tế bào thực vật | Người **không tiêu hóa** được → chất xơ |

- **Thủy phân tinh bột bằng acid** thu được glucose.
- **Thủy phân bằng enzym**: enzym trong mầm mạ, mầm lúa mạch (amylase; cũng có trong nước bọt, dịch tụy) chủ yếu cho **maltose**. Đó là nguyên lý làm **mạch nha**. Enzym trong mốc tương thủy phân tinh bột đến **glucose**.
- **Thủy phân cellulose** đến cùng thu được **β-glucose**.
- **Phản ứng với iod**: hồ tinh bột cho màu **xanh tím**. Cụ thể, amylose cho màu xanh lam (iod chui vào trong lòng xoắn), amylopectin cho màu tím đỏ, glycogen cho màu đỏ nâu. Dùng để nhận biết tinh bột.

> [!bay]
> Tinh bột và cellulose có cùng công thức (C~6~H~10~O~5~)~n~, nhưng **không phải đồng phân** của nhau vì n khác nhau. Điểm khác quyết định là liên kết **α** (tinh bột) hay **β** (cellulose). Người có enzym cắt liên kết α(1→4) nhưng **không có enzym cắt β(1→4)**. Trâu, bò, dê tiêu hóa được cellulose là nhờ vi sinh vật trong dạ cỏ.

> [!yhct] Mạch nha, Giao di và tinh bột trong dược liệu
> - **Mạch nha** (hạt đại mạch nảy mầm) chứa **amylase**, giúp thủy phân tinh bột. Đây được xem là **một phần** cơ sở cho công dụng **tiêu thực, hóa tích** (trị đầy bụng do ăn nhiều tinh bột). Sinh mạch nha giữ hoạt tính enzym tốt hơn; sao kỹ làm giảm hoạt tính.
> - **Giao di** (kẹo mạch nha, thành phần chủ yếu là **maltose**) là vị chính của bài **Tiểu kiến trung thang**.
> - **Hoài sơn**, **Ý dĩ** giàu tinh bột. **Hoàng kỳ** và **Linh chi** chứa polysaccharid (β-glucan…) đang được nghiên cứu về điều hòa miễn dịch; bằng chứng hiện chủ yếu là thực nghiệm.

## 7. Ý nghĩa y học

- **Nguồn năng lượng chính.** Giáo trình ghi glucid cung cấp khoảng 60–70% tổng năng lượng mỗi ngày. Khuyến nghị dinh dưỡng hiện nay cho người Việt Nam trưởng thành là khoảng **55–65%**.
- Chỉ **monosaccharid** mới được hấp thu trực tiếp qua niêm mạc ruột. Tinh bột, saccharose, lactose đều phải được thủy phân trước.
- **Ribose và deoxyribose** (pentose): D(+)-ribose là thành phần của acid ribonucleic (**RNA** (ARN)); deoxyribose (thiếu một O ở C2) là thành phần của acid deoxyribonucleic (**DNA**).
- **Glucose** có nhiều trong quả ngọt. Glucose trong máu theo giáo trình là 0,08–0,11% (tức 0,8–1,1 g/L); người đái tháo đường có glucose trong nước tiểu. Glucose bị chuyển hóa đến CO~2~ và nước, giải phóng năng lượng, nên được dùng như **thuốc trợ lực** và để pha **dịch truyền** (giáo trình gọi là "huyết thanh").

> [!cap-nhat] Đường huyết — đơn vị và ngưỡng hiện hành
> - Quy đổi: **mmol/L × 18 = mg/dL**. Ví dụ 5,5 mmol/L ≈ 99 mg/dL ≈ 0,99 g/L.
> - Đường huyết lúc đói bình thường: khoảng **3,9–5,5 mmol/L** (70–99 mg/dL).
> - Chẩn đoán đái tháo đường (theo hướng dẫn của Bộ Y tế và ADA) khi đường huyết lúc đói **≥ 7,0 mmol/L** (126 mg/dL), hoặc HbA1c ≥ 6,5%, hoặc đường huyết 2 giờ sau nghiệm pháp dung nạp glucose ≥ 11,1 mmol/L.
> - Glucose niệu ngày nay được xét nghiệm bằng **que thử chứa enzym glucose oxidase**, đặc hiệu cho glucose. Phản ứng Fehling/Benedict cũ dương tính với mọi đường khử.

> [!ung-dung] Dịch truyền glucose
> - **Glucose 5%** gần **đẳng trương** với huyết tương: dùng để bù nước và cung cấp một ít năng lượng.
> - Glucose **10%, 20%, 30%** là dung dịch **ưu trương**: dùng để chữa hạ đường huyết và nuôi dưỡng. Nồng độ cao dễ gây viêm tĩnh mạch.

> [!yhct] Mật ong trong bào chế hoàn mật
> Mật ong chủ yếu gồm **fructose và glucose**, là các đường khử tương tự đường nghịch chuyển, cùng một ít nước và enzym. Khi **luyện mật**, mật được đun cho bay bớt nước và diệt enzym, nhờ vậy tăng độ dính và giúp viên hoàn bảo quản lâu hơn. Fructose rất hút ẩm, nên viên hoàn mật dễ hút ẩm nếu luyện mật chưa đạt hoặc bảo quản hở.

## 8. Tóm tắt — so sánh nhanh

| Câu hỏi | Glucose | Fructose | Maltose | Lactose | Saccharose | Tinh bột | Cellulose |
|---|---|---|---|---|---|---|---|
| Thuộc loại | Mono (aldose) | Mono (cetose) | Di | Di | Di | Poly | Poly |
| Tráng bạc / Fehling | + | + | + | + | − | − | − |
| Cu(OH)~2~ nhiệt độ thường → xanh lam | + | + | + | + | + | − | − |
| Mất màu nước brom | + | − | + | + | − | − | − |
| Bị thủy phân | − | − | + | + | + | + | + |
| Màu với iod | − | − | − | − | − | xanh tím | − |

> [!vi-du] Câu hỏi tự lượng giá của giáo trình (8.10, 8.11)
> - Phân biệt aldehyd formic và glucose: dùng **Cu(OH)~2~ ở nhiệt độ thường**. Glucose (polyalcol) hòa tan tạo dung dịch xanh lam; HCHO không có. Cả hai đều tráng bạc nên Tollens không phân biệt được.
> - Saccharose ↔ maltose: maltose còn –OH hemiacetal nên có tính khử; saccharose thì không.
> - Tinh bột ↔ cellulose: liên kết α ↔ β, mạch xoắn/phân nhánh ↔ thẳng; tinh bột cho màu với iod và người tiêu hóa được.
