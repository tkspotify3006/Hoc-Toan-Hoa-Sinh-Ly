---
title: Các nguyên tố phi kim
thoi-gian: 50 phút
muc-tieu:
- Trình bày được tính chất hóa học của hydro, những tính chất "bất thường" của nước và tính chất đặc trưng của hydro peroxide.
- Xác định được vị trí và cấu hình electron lớp ngoài của các phi kim nhóm VIIA, VIA, VA, IVA; giải thích được số oxy hóa của chúng.
- Kể được các tính chất hóa học chính của đơn chất phi kim và viết được phương trình (đã cân bằng) của các hợp chất tiêu biểu.
- Nêu được ứng dụng và vai trò sinh học, y học của các phi kim và hợp chất của chúng; liên hệ được một số khoáng dược trong YHCT.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. **Hydro** chủ yếu có **tính khử**; hydro **mới sinh** (H) mạnh hơn H~2~. **Nước** có tính chất bất thường nhờ **liên kết hydro**; H~2~O~2~ (O số oxy hóa −1) **vừa oxy hóa vừa khử**.
> 2. **Halogen** (ns^2^np^5^) dễ nhận 1 e → số oxy hóa −1; Cl, Br, I còn có +1, +3, +5, +7, riêng **F chỉ có −1**. Tính oxy hóa giảm F~2~ > Cl~2~ > Br~2~ > I~2~; tính acid tăng HF < HCl < HBr < HI.
> 3. **Nhóm VIA** (ns^2^np^4^): O, S có số oxy hóa −2; S còn +4, +6. **O~3~** oxy hóa mạnh hơn O~2~; **SO~2~ (S^+4^) vừa khử vừa oxy hóa**; H~2~SO~4~ đặc oxy hóa mạnh.
> 4. **Nhóm VA** (ns^2^np^3^): N có số oxy hóa từ −3 đến +5. N~2~ trơ (liên kết ba); NH~3~ là base; **nitrit (N^+3^) vừa oxy hóa vừa khử**; HNO~3~ oxy hóa mạnh; H~3~PO~4~ không oxy hóa.
> 5. **Nhóm IVA** (ns^2^np^2^): C, Si hóa trị IV, liên kết cộng hóa trị. **CO** gắn Hb rất bền (ngộ độc); CO~2~/HCO~3~^−^ là hệ đệm của máu; SiO~2~ chỉ tan trong **HF**.

Các phi kim nằm ở góc trên bên phải bảng tuần hoàn (cùng với hydro ở đầu bảng). Bài này đi theo đúng thứ tự của giáo trình: hydro – nước → nhóm VIIA → VIA → VA → IVA (Giáo trình tr. 44).

| Nhóm | Nguyên tố phi kim | Cấu hình lớp ngoài | Số e độc thân tối đa |
|---|---|---|---|
| IA | H | 1s^1^ | 1 |
| IVA | C, Si | ns^2^np^2^ | 4 (sau khi kích thích) |
| VA | N, P, As | ns^2^np^3^ | 3 (N); 5 (P, As) |
| VIA | O, S, Se, Te | ns^2^np^4^ | 2 (O); 4, 6 (S, Se, Te) |
| VIIA | F, Cl, Br, I, At | ns^2^np^5^ | 1 (F); 3, 5, 7 (Cl, Br, I) |

> [!ghi-nho] Một quy luật dùng cho cả bài
> Nguyên tố ở **chu kỳ 2** (C, N, O, F) **không có phân lớp d** ở lớp ngoài. Vì vậy chúng không "mở rộng" được số electron độc thân: O chỉ hóa trị 2, F chỉ hóa trị 1, N tối đa 4 liên kết. Nguyên tố từ **chu kỳ 3** trở đi (Si, P, S, Cl…) có **phân lớp d trống**, khi được kích thích có thể chuyển e lên d, nên có thêm hóa trị và số oxy hóa cao (S +6, P +5, Cl +7). Giáo trình dùng lập luận này để trả lời nhiều câu tự lượng giá (4.4, 4.11, 4.17).

## 1. Hydro – nước

### 1.1. Vị trí và đặc điểm của hydro

Hydro có cấu hình **1s^1^**, nên được xếp vào **nhóm IA hoặc VIIA**:

- Giống kim loại kiềm: có thể **mất 1 e** thành H^+^.
- Giống halogen: chỉ **thiếu 1 e** là đạt cấu hình khí hiếm He, nên có thể **nhận 1 e** thành ion hydrid H^−^.

Hydro có **3 đồng vị**: proti ^1^H (gần như toàn bộ, khoảng 99,98%), dotri (deuteri) ^2^H = D, và triti ^3^H = T (vết, phóng xạ).

> [!bay] Tỉ lệ đồng vị
> Giáo trình in tỉ lệ P : D : T = 99,9 : **0,16** : 10^−7^ (tr. 44). Con số 0,16 có lẽ là lỗi in: tổng đã vượt 100%. Trong tự nhiên deuteri chiếm khoảng **0,015%**. Khi thi chỉ cần nhớ: proti chiếm gần như tất cả, triti chỉ là vết.

### 1.2. Tính chất hóa học của hydro

**a) Tính khử của hydro phân tử (H~2~).** Liên kết H–H rất bền; phải tới khoảng 5000 °C H~2~ mới phân ly thành nguyên tử. Vì vậy, **trừ F~2~**, H~2~ chỉ phản ứng với phi kim khi đun nóng, chiếu sáng hoặc có xúc tác.

=> H~2~ + F~2~ → 2HF (ngay ở nhiệt độ thấp, nổ mạnh)

=> H~2~ + Cl~2~ → 2HCl (t° hoặc ánh sáng)

=> 2H~2~ + O~2~ → 2H~2~O (t° hoặc xúc tác)

=> 3H~2~ + N~2~ ⇌ 2NH~3~ (xúc tác, t°, p)

=> H~2~ + CuO → Cu + H~2~O (t°)

H~2~ còn khử nhóm aldehyd thành alcol khi có xúc tác (R–CHO + H~2~ → R–CH~2~OH).

**b) Tính khử của hydro nguyên tử (hydro mới sinh).** Hydro vừa sinh ra trong phản ứng (ví dụ Zn + HCl) ở dạng **nguyên tử H**, rất hoạt động, khử được nhiều chất **ngay ở nhiệt độ thường**. *Vì sao?* H nguyên tử không cần tốn năng lượng để phá liên kết H–H.

=> 5H + MnO~4~^−^ + 3H^+^ → Mn^2+^ + 4H~2~O

=> C~6~H~5~NO~2~ + 6H → C~6~H~5~NH~2~ + 2H~2~O

(nitrobenzen bị khử thành anilin)

**c) Tính oxy hóa.** Với kim loại rất hoạt động, H~2~ nhận e tạo **hydrid** (H có số oxy hóa −1):

=> H~2~ + 2Na → 2NaH (t°)

### 1.3. Nước

**a) Cấu tạo — vì sao nước "bất thường"?**

- Phân tử có **dạng góc**, góc HOH ≈ **104,5°** (giáo trình: 104°30'); O **lai hóa sp^3^**, còn 2 cặp e tự do.
- Phân tử **phân cực** mạnh (μ = 1,84 D) → nước là **dung môi tốt** cho các chất ion và chất phân cực.
- Giữa các phân tử nước có **liên kết hydro**. Muốn nước sôi hay nóng chảy, phải phá thêm các liên kết này. Vì vậy nhiệt độ sôi, nhiệt độ nóng chảy, nhiệt dung của nước **cao bất thường** so với H~2~S, H~2~Se, H~2~Te. Nếu không có liên kết hydro, người ta dự đoán nước sẽ sôi ở khoảng −80 °C và đông đặc ở −100 °C.
- Nước có **khối lượng riêng lớn nhất ở 4 °C**. Nước đá nhẹ hơn nước lỏng vì trong tinh thể đá, mỗi phân tử liên kết hydro với 4 phân tử xung quanh (tổ hợp 5 phân tử) tạo **mạng rỗng**.

![Hình 1. Hình học một số phân tử phi kim trong bài](hinh-hoc-phan-tu.svg)

**b) Tính chất hóa học — nước "đóng nhiều vai"**

| Vai trò | Ví dụ | Giải thích |
|---|---|---|
| **Acid** (Brönsted) | H~2~O + CH~3~COO^−^ ⇌ CH~3~COOH + OH^−^ | Nước nhường H^+^ |
| **Base** (Brönsted) | H~2~O + NH~4~^+^ ⇌ H~3~O^+^ + NH~3~ | Nước nhận H^+^ |
| **Chất oxy hóa** | 2H~2~O + 2Na → 2NaOH + H~2~↑ | H^+1^ → H^0^ |
| **Chất khử** | 2H~2~O + 2F~2~ → 4HF + O~2~↑ | O^−2^ → O^0^ |
| **Xúc tác** | H~2~ + O~2~ gần như không phản ứng nếu khô hoàn toàn; Fe + Cl~2~ chỉ phản ứng rõ khi có vết nước | — |

> [!ung-dung] Nước cứng và nước dùng trong ngành dược
> - **Nước cứng** chứa nhiều Ca^2+^, Mg^2+^. Giáo trình nêu nước sinh hoạt phải có hàm lượng Ca^2+^ thấp, mỗi lít không quá 0,5 g muối khoáng (tr. 48).
>   - *Cứng tạm thời* do Ca(HCO~3~)~2~, Mg(HCO~3~)~2~: đun sôi là hết, đồng thời sinh **cặn** CaCO~3~ trong ấm.
>   - *Cứng vĩnh cửu* do CaCl~2~, CaSO~4~, MgCl~2~…: đun không hết, phải dùng hóa chất (Na~2~CO~3~) hoặc nhựa trao đổi ion (đáp án 1.9, tr. 242).
>
> => Ca(HCO~3~)~2~ → CaCO~3~↓ + CO~2~↑ + H~2~O (đun sôi)
>
> - **Nước dùng trong dược phẩm** được phân cấp rõ: *nước tinh khiết* (cất hoặc trao đổi ion, thẩm thấu ngược) để pha chế thông thường; **nước cất pha tiêm** phải **vô khuẩn và không có chất gây sốt** (pyrogen). Không bao giờ dùng nước máy hay nước tinh khiết thông thường để pha thuốc tiêm.

### 1.4. Hydro peroxide H~2~O~2~

**Cấu tạo.** H–O–O–H không phẳng mà gấp khúc dạng "trang sách mở": hai liên kết O–H nằm trên hai mặt phẳng hợp với nhau góc khoảng 111°; góc HOO ≈ 95°, liên kết O–O dài 1,49 Å. Trong H~2~O~2~, **O có số oxy hóa −1**, là mức trung gian giữa −2 (H~2~O) và 0 (O~2~). Đó là lý do H~2~O~2~ **vừa oxy hóa vừa khử**.

**Tính chất hóa học:**

- **Tự phân hủy** (tự oxy hóa – khử), xúc tác bởi MnO~2~, Pt (nhất là Pt dạng keo) hoặc enzym **catalase**:

=> 2H~2~O~2~ → 2H~2~O + O~2~↑

- **Tính khử** — gặp chất oxy hóa mạnh, O^−1^ lên O^0^ (dùng để định lượng H~2~O~2~ bằng KMnO~4~):

=> 5H~2~O~2~ + 2MnO~4~^−^ + 6H^+^ → 5O~2~↑ + 2Mn^2+^ + 8H~2~O

- **Tính oxy hóa** — gặp chất khử, O^−1^ xuống O^−2^:

=> H~2~O~2~ + 2I^−^ + 2H^+^ → 2H~2~O + I~2~

> [!bay] Phương trình H₂O₂ + MnO₄⁻ trong sách
> Giáo trình (tr. 46 và đáp án 4.14, tr. 247) in vế phải là "… + 2Mn^2+^ + **H~2~O**" — **chưa cân bằng**. Đếm H: vế trái 10 + 6 = 16 H, vậy vế phải phải là **8H~2~O**.

### 1.5. Trạng thái tự nhiên và điều chế

Hydro tự do có rất ít trong khí quyển; phần lớn nằm trong hợp chất (nước, chất hữu cơ).

| Cách điều chế H~2~ | Phương trình |
|---|---|
| Kim loại kiềm, kiềm thổ + nước | 2Na + 2H~2~O → 2NaOH + H~2~↑ ; Ca + 2H~2~O → Ca(OH)~2~ + H~2~↑ |
| Kim loại hoạt động + acid | Mg + 2H^+^ → Mg^2+^ + H~2~↑ |
| Kim loại lưỡng tính + kiềm | Zn + 2NaOH → Na~2~ZnO~2~ + H~2~↑ |
| Khử hơi nước bằng C hoặc CO | H~2~O + C → H~2~ + CO (than nóng đỏ) ; H~2~O + CO → H~2~ + CO~2~ (xúc tác Fe~2~O~3~) |
| Điện phân nước (dung dịch acid, kiềm, hoặc muối của acid mạnh – base mạnh) | 2H~2~O → 2H~2~ + O~2~ |
| **Công nghiệp** | CH~4~ + H~2~O → CO + 3H~2~ (Ni, 1100 °C) |

**Điều chế H~2~O~2~** từ peroxide kim loại kiềm thổ:

=> BaO~2~ + H~2~SO~4~ → H~2~O~2~ + BaSO~4~↓

> [!vi-du] Câu 4.1 — Vì sao thêm vài giọt CuSO₄ khi cho Zn tác dụng với H₂SO₄ loãng?
> Đáp án của giáo trình chỉ ghi: CuSO~4~ làm tốc độ phản ứng tăng lên. *Bản chất:* Zn đẩy Cu ra khỏi muối (Zn + Cu^2+^ → Zn^2+^ + Cu). Cu bám trên mặt Zn tạo thành **pin điện hóa Zn – Cu** trong dung dịch acid. Zn là cực âm, tan nhanh; H~2~ thoát ra ở cực Cu, không còn bám che mặt Zn. Đây là **ăn mòn điện hóa**, nhanh hơn nhiều so với ăn mòn hóa học thông thường.

### 1.6. Ứng dụng và vai trò sinh học

- H~2~: tổng hợp NH~3~ (phân đạm), **hydro hóa dầu thực vật** (acid béo không no → no), bơm bóng thám không. H~2~ không độc nhưng không duy trì sự sống.
- Hydro có trong mọi chất hữu cơ của cơ thể: protein, lipid, glucid.
- **H~2~O~2~**: tẩy trắng len, lụa, giấy; trong y học dùng **sát khuẩn vết thương** nhờ tính oxy hóa. H~2~O~2~ cũng là chất **độc** với tế bào. Các phản ứng oxy hóa trong cơ thể luôn sinh ra một lượng H~2~O~2~; enzym **catalase** (trong máu, gan…) phân hủy nó thành H~2~O và O~2~.
- **Clo** được dùng khử trùng nước sinh hoạt với liều lượng xác định (xem mục 2).

> [!cap-nhat] Oxy già 3% và vết thương
> Giáo trình nêu H~2~O~2~ dùng rửa vết thương. Hiện nay H~2~O~2~ 3% vẫn có mặt trong tủ thuốc, nhưng **không còn được khuyến cáo dùng thường quy** cho vết thương sạch đang lành: nó làm tổn thương cả tế bào mô hạt (nguyên bào sợi) và làm chậm lành. Nước muối sinh lý NaCl 0,9% là lựa chọn rửa vết thương thông thường. Khi thi, trả lời theo giáo trình.

> [!vi-du] Vì sao nhỏ oxy già lên vết thương lại sủi bọt?
> Máu và mô chứa nhiều **catalase**. Enzym này xúc tác 2H~2~O~2~ → 2H~2~O + O~2~ rất nhanh; bọt chính là khí O~2~. Bọt giúp đẩy dị vật, máu cục ra ngoài; sủi bọt **không** chứng tỏ vết thương "bị nhiễm trùng".

## 2. Nhóm VIIA — halogen: F, Cl, Br, I

### 2.1. Vị trí và đặc điểm

- Gồm F, Cl, Br, I, At. Ở điều kiện thường: **F~2~, Cl~2~ là khí; Br~2~ lỏng; I~2~ rắn**. At không có ở dạng tự do (phóng xạ).
- Lớp ngoài **ns^2^np^5^**, thiếu 1 e là đủ bát tử. Halogen dễ **nhận 1 e** (liên kết ion) hoặc **góp chung 1 e** (liên kết cộng hóa trị) → số oxy hóa **−1**.
- **Trừ F**, các halogen còn có số oxy hóa **+1, +3, +5, +7**. Ở trạng thái kích thích, electron lần lượt chuyển từ np, ns lên phân lớp nd trống, tạo 3, 5, 7 electron độc thân.

> [!bay] Vì sao flo chỉ có số oxy hóa −1? (câu 4.4)
> Theo giáo trình: lớp ngoài của F (n = 2) **không có orbital d trống**, nên không tạo được 3, 5, 7 e độc thân. Thêm một lý do dễ hiểu: F là nguyên tố có **độ âm điện lớn nhất**; trong mọi hợp chất F luôn kéo e về phía mình, nên không bao giờ mang số oxy hóa dương.

### 2.2. Tính chất hóa học

**a) Với hydro.** Mọi halogen đều phản ứng trực tiếp với H~2~, nhưng mức độ **giảm dần** từ F~2~ đến I~2~:

| Phản ứng | Điều kiện |
|---|---|
| F~2~ + H~2~ → 2HF | Ngay ở nhiệt độ thấp, mãnh liệt (nổ) |
| Cl~2~ + H~2~ → 2HCl | Đun nóng hoặc chiếu sáng |
| I~2~ + H~2~ ⇌ 2HI | Đun nóng, **thuận nghịch** |

**b) Với kim loại.** F~2~ phản ứng với hầu hết kim loại. Cl~2~, Br~2~ đưa kim loại lên **số oxy hóa cao nhất**; I~2~ yếu hơn nên chỉ đưa lên số oxy hóa thấp:

=> 3Cl~2~ + 2Fe → 2FeCl~3~ (t°)

=> I~2~ + Fe → FeI~2~ (t°)

**c) Với kiềm** — sản phẩm phụ thuộc điều kiện (đây là các phản ứng tự oxy hóa – khử của Cl^0^):

=> Cl~2~ + 2NaOH → NaCl + NaOCl + H~2~O (nguội)

=> 2Cl~2~ + 2Ca(OH)~2~ → CaCl~2~ + Ca(OCl)~2~ + 2H~2~O

=> 3Cl~2~ + 6KOH → 5KCl + KClO~3~ + 3H~2~O (đặc, nóng)

Ba sản phẩm lần lượt là **nước Javel** (NaOCl + NaCl), **clorua vôi** (từ sữa vôi) và **kali clorat** KClO~3~.

**d) Với hợp chất có tính khử:**

=> Cl~2~ + 2FeCl~2~ → 2FeCl~3~

=> Br~2~ + SO~2~ + 2H~2~O → 2HBr + H~2~SO~4~

=> Br~2~ + 2KI → 2KBr + I~2~

Phản ứng cuối cho thấy **halogen mạnh hơn đẩy halogen yếu hơn** ra khỏi muối: tính oxy hóa F~2~ > Cl~2~ > Br~2~ > I~2~.

### 2.3. Các hợp chất

**a) Hydro halid HX.** Là các khí tan rất nhiều trong nước, tạo dung dịch acid (HCl khí + nước → acid clohydric).

- **Tính acid tăng dần** từ HF đến HI: HF < HCl < HBr < HI. *Vì sao?* Đi từ F đến I, nguyên tử to dần, liên kết H–X dài và yếu dần nên H^+^ tách ra dễ hơn.
- **HF là acid yếu** (câu 4.8): giữa các phân tử HF có **liên kết hydro** bền, và một phần HF còn kết hợp thành ion HF~2~^−^ (giáo trình gọi là "sự proton hóa"):

=> 2HF + H~2~O ⇌ HF~2~^−^ + H~3~O^+^

- Dù yếu, **HF hòa tan được thủy tinh** (câu 4.7) vì tạo **phức tan** H~2~[SiF~6~]:

=> SiO~2~ + 6HF → H~2~[SiF~6~] + 2H~2~O

Vì vậy dung dịch HF phải đựng trong bình nhựa, và HF được dùng để khắc chữ lên thủy tinh.

**b) Oxy acid của halogen.** Với clo: HClO (hypoclorơ), HClO~2~ (clorơ), HClO~3~ (cloric), HClO~4~ (percloric). Tính acid **tăng** theo số nguyên tử O: HClO < HClO~2~ < HClO~3~ < HClO~4~. Giáo trình giải thích bằng sự **tăng độ phân cực của liên kết H–O** khi có thêm O hút e (xem thêm bài Hợp chất vô cơ).

**c) Muối halid.** Hầu hết muối halid **dễ tan**, **trừ** halid của **bạc, chì, thủy ngân(I)** (AgCl, PbCl~2~, Hg~2~Cl~2~…). Muối của oxy acid halogen (NaOCl, Ca(OCl)~2~, KClO~3~) có **tính oxy hóa mạnh** vì Cl mang số oxy hóa dương.

![Hình 2. Thang số oxy hóa của N, S, Cl: số oxy hóa trung gian thì vừa oxy hóa vừa khử](so-oxy-hoa.svg)

### 2.4. Trạng thái tự nhiên và điều chế

Halogen trong tự nhiên chỉ có ở dạng hợp chất: **criolit** 3NaF·AlF~3~, **fluorit** CaF~2~, **apatit** 3Ca~3~(PO~4~)~2~·CaF~2~; NaCl, MgCl~2~ trong nước biển (khoảng 2%); cacnalit KCl·MgCl~2~·6H~2~O; xinvinit NaCl·KCl. Iod có nhiều trong **rong biển**, brom trong nước ót (nước còn lại sau khi làm muối).

| Halogen | Cách điều chế |
|---|---|
| **F~2~** | Ion F^−^ rất khó bị oxy hóa → **chỉ có một cách**: điện phân **nóng chảy** hỗn hợp KHF~2~ + HF (khoảng 100 °C) |
| **Cl~2~** (phòng thí nghiệm) | MnO~2~ + 4HCl (đặc) → MnCl~2~ + Cl~2~↑ + 2H~2~O (hoặc dùng KMnO~4~) |
| **Cl~2~** (công nghiệp) | 2NaCl + 2H~2~O → 2NaOH + H~2~↑ + Cl~2~↑ (điện phân dung dịch, **có màng ngăn**) |
| **Br~2~, I~2~** | Cl~2~ + 2Br^−^ (hoặc 2I^−^) → 2Cl^−^ + Br~2~ (hoặc I~2~) |
| **HCl** (công nghiệp, câu 4.9) | H~2~ + Cl~2~ → 2HCl; H~2~ và Cl~2~ lấy từ chính quá trình điện phân NaCl |

### 2.5. Ứng dụng và tác dụng sinh học

- **Cl~2~** dùng sản xuất nhiều chất vô cơ, hữu cơ, chất dẻo (PVC), thuốc trừ sâu, tẩy trắng vải giấy; **khử trùng nước sinh hoạt**, tẩy độc nước thải.
- **Br** và hợp chất: KBr (an thần), thuốc nhuộm; AgCl, AgBr dùng trong phim ảnh (bị ánh sáng phân hủy).
- **I~2~** dù rất loãng cũng làm hồ tinh bột **xanh** → dùng trong phân tích (phép đo iod). **Clorua vôi** dùng tẩy uế; **iodoform** CHI~3~ dùng rửa vết thương.
- **Ở dạng tự do, halogen đều độc.** Cl~2~ gây tổn thương nặng niêm mạc đường hô hấp. Br~2~ và I~2~ tan nhiều trong dung môi hữu cơ và **lipid** nên dễ thấm qua da gây **bỏng** — phải đặc biệt thận trọng.
- **Trong cơ thể**: F có trong **men răng**, Br trong tế bào thần kinh, I trong **tuyến giáp**, Cl có ở mọi mô. **HCl là acid vô cơ duy nhất** có trong dạ dày.
- **Iod** vào cơ thể qua thức ăn, muối ăn; tập trung ở tuyến giáp trong **thyreoglobulin** (thyroglobulin), cần cho hoạt động bình thường và quá trình đồng hóa. Thiếu iod gây **bướu cổ** (nhiều ở vùng núi cao) → phòng bằng **muối trộn iod**.

> [!ung-dung] Halogen trong y học hằng ngày
> - **Khử trùng bằng clo.** Clo tan trong nước tạo **HClO** — tác nhân diệt khuẩn thật sự (phân tử trung hòa, nhỏ, dễ thấm qua màng vi khuẩn rồi oxy hóa enzym của chúng):
>
> => Cl~2~ + H~2~O ⇌ HCl + HClO
>
> - **Nước Javel / NaOCl** pha loãng (khoảng 0,05–0,5% clo hoạt tính tùy mục đích) dùng khử khuẩn bề mặt, dụng cụ, xử lý chất thải trong bệnh viện.
> - **Iod**: cồn iod; **povidon-iod** (Betadine) là phức iod với polymer povidon, nhả iod từ từ nên **ít kích ứng** hơn cồn iod, dùng sát khuẩn da trước mổ, vết thương. Dung dịch **Lugol** (I~2~ + KI) dùng trước phẫu thuật tuyến giáp. **KI** liều cao được phát khi có sự cố hạt nhân để tuyến giáp "no" iod thường, không hấp thu iod phóng xạ ^131^I.
> - **Muối iod**: iod được bổ sung vào muối dưới dạng **KIO~3~** (bền hơn KI khi gặp nhiệt và ẩm); muối iod ở Việt Nam cũng dùng KIO~3~. Iod cần để tuyến giáp tổng hợp hormon **T~3~, T~4~**; thiếu iod ở phụ nữ có thai có thể ảnh hưởng phát triển trí tuệ của trẻ.
> - **Thử nhanh muối iod** — chính là phản ứng của câu 4.10: trong môi trường acid, IO~3~^−^ oxy hóa I^−^ thành I~2~, làm hồ tinh bột hóa **xanh**.
>
> => KIO~3~ + 5KI + 3H~2~SO~4~ → 3K~2~SO~4~ + 3I~2~ + 3H~2~O
>
> - **Fluor và răng**: ion F^−^ thay nhóm OH^−^ trong hydroxyapatit của men răng, tạo **fluorapatit** bền hơn với acid do vi khuẩn sinh ra → giảm sâu răng (kem đánh răng có fluor). Thừa fluor lâu ngày lại gây **nhiễm fluor** (răng lốm đốm, xương giòn).

> [!bay] Không trộn nước Javel với chất tẩy rửa có acid
> Chất tẩy bồn cầu thường chứa HCl. Trộn với Javel sẽ giải phóng **khí clo** độc:
>
> => NaOCl + 2HCl → NaCl + Cl~2~↑ + H~2~O
>
> Đây là nguyên nhân hay gặp của ngộ độc clo trong gia đình. Cùng nguyên lý, câu 4.10 hỏi: CaOCl~2~ + 2HCl (đặc) → CaCl~2~ + Cl~2~↑ + H~2~O (giáo trình in thiếu hệ số 2 trước HCl).

> [!cap-nhat] KBr và thuốc trừ sâu "666"
> Giáo trình nêu KBr có tác dụng an thần và Cl~2~ dùng sản xuất thuốc trừ sâu 666. Hiện nay **bromid hầu như không còn dùng làm thuốc an thần cho người** (dễ tích lũy gây ngộ độc brom), chỉ còn dùng trong thú y. Thuốc **666** (hexacloran, có thành phần lindan) độc, tồn lưu lâu trong môi trường, **đã bị cấm** ở Việt Nam và theo Công ước Stockholm. Khi thi, trả lời theo giáo trình.

## 3. Nhóm VIA: O, S, Se, Te

### 3.1. Vị trí và đặc điểm

- Lớp ngoài **ns^2^np^4^**, có 2 electron độc thân → số oxy hóa đặc trưng **−2**.
- **Trừ O**, các nguyên tố còn lại có phân lớp **nd trống**. Khi kích thích, e từ s, p chuyển lên d tạo 4 hoặc 6 e độc thân, nên ngoài −2, +2 còn có **+4, +6** (câu 4.11).

| | Oxy | Lưu huỳnh (và Se, Te) |
|---|---|---|
| Phân lớp d ở lớp ngoài | Không có | Có, còn trống |
| Hóa trị | 2 | 2, 4, 6 |
| Số oxy hóa | −2 (−1 trong peroxide; +2 trong F~2~O) | −2, +2, +4, +6 |

### 3.2. Tính chất hóa học

**a) Với phi kim** — tạo hợp chất cộng hóa trị:

=> S + F~2~ → SF~2~ (S số oxy hóa +2)

=> O~2~ + 2H~2~ → 2H~2~O ; S + H~2~ → H~2~S (đốt hoặc xúc tác; O, S số oxy hóa −2)

=> S + O~2~ → SO~2~ (có thể oxy hóa tiếp lên SO~3~)

**b) Với kim loại.** O và S phản ứng với hầu hết kim loại, tạo **oxide** và **sulfid** (hợp chất ion, O và S có số oxy hóa −2):

=> 2Na + O~2~ → Na~2~O~2~ (đốt nóng, tạo peroxide)

=> 2Mg + O~2~ → 2MgO (cháy với ngọn lửa chói sáng)

=> 4Al + 3O~2~ → 2Al~2~O~3~ ; 3Fe + 2O~2~ → Fe~3~O~4~ (nhiệt độ cao)

**c) Với hợp chất vô cơ, hữu cơ:**

=> 4Fe(OH)~2~ + O~2~ + 2H~2~O → 4Fe(OH)~3~

=> C~2~H~5~OH + 3O~2~ → 2CO~2~ + 3H~2~O

**d) Ozon O~3~** — một **dạng thù hình** của oxy.

- Phân tử **dạng góc** (≈ 116,8°), phân cực (μ = 0,66 D). O trung tâm **lai hóa sp^2^**; một cặp e tự do chiếm một "góc" của tam giác nên phân tử bị gập. Electron p không lai hóa tạo **liên kết π không định cư** trải trên cả 3 nguyên tử O (Hình 1).
- **Tính oxy hóa mạnh hơn O~2~** (câu 4.12): ở điều kiện thường O~3~ oxy hóa được bạc và ion iodid; O~2~ thì không.

=> O~3~ + 2Ag → Ag~2~O + O~2~

=> O~3~ + 2I^−^ + H~2~O → O~2~ + I~2~ + 2OH^−^

- Điều chế bằng **phóng điện êm** trong oxy khô. Trên tầng cao khí quyển, O~3~ hình thành từ O~2~ dưới tia tử ngoại (λ ≈ 200–290 nm). **Tầng ozon** hấp thụ tia tử ngoại có hại (gây biến dị, ung thư da), nên có ý nghĩa sống còn.

> [!vi-du] Câu 4.13 — Vì sao O₂ thuận từ?
> Thực nghiệm cho thấy O~2~ bị nam châm hút (**thuận từ**), tức phân tử có **electron độc thân**. Theo thuyết VB, O=O có một liên kết σ và một liên kết π, mọi e đều ghép đôi → không giải thích được. Theo **thuyết MO**, 12 e hóa trị của O~2~ xếp vào các orbital phân tử; 2 e cuối cùng nằm riêng rẽ trên **hai orbital π\* phản liên kết** có cùng năng lượng (quy tắc Hund) → **2 e độc thân**. Bậc liên kết vẫn bằng 2.

### 3.3. Các hợp chất

**a) H~2~O và H~2~S.**

- H~2~O có nhiệt độ sôi, nóng chảy, nhiệt dung, khối lượng riêng bất thường so với các hợp chất cùng nhóm — do **liên kết hydro** (mục 1.3).
- **H~2~S**: phân tử góc (≈ 92°), sinh ra khi xác động vật bị vi khuẩn phân hủy (mùi trứng thối). Dung dịch H~2~S là **acid yếu** (acid sulfuhydric), có **tính khử mạnh** (S^−2^ chỉ có thể tăng số oxy hóa):

=> 2H~2~S + O~2~ → 2S↓ + 2H~2~O

Vì vậy dung dịch H~2~S để lâu trong không khí bị vẩn đục (S). H~2~S cũng bị halogen oxy hóa — phản ứng dùng định lượng H~2~S trong hỗn hợp khí:

=> H~2~S + I~2~ → S↓ + 2HI

*Vì sao H~2~S có góc gần 90° còn H~2~O tới 104,5°?* S to hơn, liên kết S–H dài hơn và ít phân cực hơn; các cặp e liên kết đẩy nhau yếu hơn, nên góc gần với góc giữa hai orbital p thuần túy (90°).

**b) SO~2~, acid sulfurơ, muối sulfit (S^+4^).**

- SO~2~ dạng góc (≈ 119,5°), S lai hóa sp^2^. Tan trong nước tạo **acid sulfurơ** H~2~SO~3~ — acid yếu, chỉ tồn tại trong dung dịch.

=> SO~2~ + H~2~O ⇌ H~2~SO~3~

- S^+4^ là số oxy hóa **trung gian** (Hình 2) nên:
  - **Tính khử là chủ yếu** (gặp chất oxy hóa, S^+4^ → S^+6^):

=> SO~2~ + Br~2~ + 2H~2~O → H~2~SO~4~ + 2HBr

=> 5SO~3~^2−^ + 2MnO~4~^−^ + 6H^+^ → 5SO~4~^2−^ + 2Mn^2+^ + 3H~2~O

  - **Tính oxy hóa** khi gặp chất khử mạnh (S^+4^ → S^0^):

=> SO~3~^2−^ + 2S^2−^ + 6H^+^ → 3S↓ + 3H~2~O

> [!bay] Phương trình sulfit + permanganat
> Giáo trình (tr. 53 và đáp án 4.15, tr. 248) in "5SO~3~^2−^ + 2MnO~4~^−^ + **16H^+^** → 5SO~4~^2−^ + 2Mn^2+^ + **8H~2~O**". Đếm điện tích: vế trái −10 − 2 + 16 = +4, vế phải −10 + 4 = −6 → **sai**. Đúng là **6H^+^ và 3H~2~O** — chính sách viết đúng như vậy ở đáp án câu 3.15 (tr. 245). Hệ số 16H^+^/8H~2~O là của phản ứng 2MnO~4~^−^ với Fe^2+^ hoặc Cl^−^, đừng nhớ nhầm.

**c) SO~3~, acid sulfuric, muối sulfat (S^+6^).**

- SO~3~: phân tử **tam giác phẳng** (120°), S lai hóa sp^2^. SO~3~ + H~2~O → H~2~SO~4~.
- **H~2~SO~4~ loãng**: acid mạnh thông thường, tác dụng với kim loại hoạt động giải phóng H~2~.
- **H~2~SO~4~ đặc**: **oxy hóa mạnh** do S^+6^. Với kim loại kém hoạt động (Cu, Ag, Hg) bị khử đến SO~2~; với kim loại hoạt động có thể bị khử sâu đến S hoặc H~2~S; với phi kim (C, S, P) oxy hóa chúng lên oxide hoặc acid cao nhất.

=> Cu + 2H~2~SO~4~ (đặc, t°) → CuSO~4~ + SO~2~↑ + 2H~2~O

=> 4Mg + 5H~2~SO~4~ (đặc) → 4MgSO~4~ + H~2~S↑ + 4H~2~O

=> C + 2H~2~SO~4~ (đặc, t°) → CO~2~↑ + 2SO~2~↑ + 2H~2~O

- H~2~SO~4~ đặc còn **sulfon hóa** hợp chất thơm (ArH → ArSO~3~H) — sẽ gặp ở phần Hóa hữu cơ.
- **Muối sulfat**: BaSO~4~, SrSO~4~, PbSO~4~ **không tan**; CaSO~4~, Ag~2~SO~4~ **ít tan**; sulfat kim loại kiềm dễ tan. **Phèn** có công thức chung M^I^M^III^(SO~4~)~2~·xH~2~O (M^I^: kim loại kiềm hoặc NH~4~^+^; M^III^: Al, Fe…).

### 3.4. Trạng thái tự nhiên và điều chế

- **Oxy** tự do chiếm khoảng 1/5 thể tích không khí. Phòng thí nghiệm: nhiệt phân muối giàu oxy hoặc điện phân nước; công nghiệp: **hóa lỏng không khí rồi chưng cất phân đoạn**.

=> 2KClO~3~ → 2KCl + 3O~2~↑ (t°, xúc tác MnO~2~)

=> 2KMnO~4~ → K~2~MnO~4~ + MnO~2~ + O~2~↑ (t°)

- **Lưu huỳnh** tự do có ở mỏ, vùng núi lửa. Dạng hợp chất: H~2~S, SO~2~ trong khí núi lửa; sulfid như **pirit** FeS~2~, chancopirit CuFeS~2~; khoáng **thạch cao** CaSO~4~·2H~2~O, barit BaSO~4~.
- **H~2~SO~4~ công nghiệp** (câu 4.16) đi từ quặng pirit:

=> FeS~2~ → SO~2~ → SO~3~ → H~2~SO~4~

Viết đầy đủ, đã cân bằng: 4FeS~2~ + 11O~2~ → 2Fe~2~O~3~ + 8SO~2~ (t°); 2SO~2~ + O~2~ ⇌ 2SO~3~ (V~2~O~5~, t°); SO~3~ + H~2~O → H~2~SO~4~ (thực tế hấp thụ SO~3~ bằng H~2~SO~4~ đặc để tránh tạo sương mù acid).

H~2~SO~4~ là acid vô cơ quan trọng nhất: sản xuất phân bón, muối, lọc dầu, tổng hợp hữu cơ, **dược phẩm**, chất màu, chất nổ, ắc quy.

### 3.5. Ý nghĩa sinh học

- **Oxy** không thể thiếu cho sự sống; động vật máu nóng chết sau vài phút nếu thiếu oxy. O~2~ gắn với hemoglobin thành **oxyhemoglobin**, được chở tới mô rồi nhả O~2~. Người lớn cần ít nhất khoảng **0,5 m^3^ oxy** mỗi 24 giờ. Thực vật tái tạo O~2~ từ CO~2~ qua quang hợp → chu trình oxy.
- **Lưu huỳnh** là nguyên tố không thể thay thế: có trong tóc, móng, xương, biểu bì; trong acid amin (amino acid) **cystein, cystin, methionin**, vitamin **B~1~** (thiamin). Ở thực vật, S nhiều trong hạt cải (mù tạt).
- **Lưu huỳnh đơn chất không độc**, nhưng **H~2~S rất độc**: giáo trình giải thích H~2~S kết hợp với hemoglobin, làm liệt trung tâm hô hấp và gây tử vong; ở nồng độ thấp cơ thể tự phân hủy được. **SO~2~** phá hủy niêm mạc đường hô hấp.

> [!cap-nhat] Cơ chế độc của H₂S
> Giáo trình viết H~2~S độc do "kết hợp với hemoglobin". Hiện nay cơ chế chính được xác định là H~2~S **ức chế enzym cytochrom c oxidase** của ty thể (giống cyanid), làm tế bào không dùng được oxy. Ở nồng độ cao, H~2~S còn **làm tê liệt khứu giác** — nạn nhân không còn ngửi thấy mùi trứng thối dù khí vẫn đang nồng nặc. Đây là kiểu tai nạn hay gặp khi xuống hầm biogas, hố ga, bể phốt. Khi thi, trả lời theo giáo trình.

> [!ung-dung] O₃, SO₂ và sulfit
> - **Ozon** dùng khử trùng nước, khử mùi nhờ tính oxy hóa mạnh, phân hủy thành O~2~ nên không để lại dư lượng clo. Ngược lại, ozon **ở mặt đất** là chất ô nhiễm, kích ứng đường thở, làm nặng thêm hen phế quản.
> - **SO~2~ và muối sulfit** (Na~2~SO~3~, NaHSO~3~, Na~2~S~2~O~5~) là chất **bảo quản, chống oxy hóa, chống nâu hóa** trong thực phẩm (rượu vang, trái cây sấy…) và trong một số thuốc tiêm (bảo vệ adrenalin khỏi bị oxy hóa). Chúng hoạt động nhờ **tính khử** của S^+4^: tự bị oxy hóa trước, bảo vệ hoạt chất. Một số người, nhất là người **hen phế quản**, **nhạy cảm sulfit**: có thể lên cơn khó thở.
> - **Lưu huỳnh** dùng ngoài (thuốc mỡ lưu huỳnh 5–10%) trị ghẻ, nấm da.

> [!yhct] Lưu hoàng và xông diêm sinh dược liệu
> - **Lưu hoàng** chính là **lưu huỳnh** (S). Trong YHCT, Lưu hoàng chủ yếu **dùng ngoài** để sát trùng, trị ghẻ lở, nấm ngứa — phù hợp với công dụng của thuốc mỡ lưu huỳnh hiện đại. Dùng trong chỉ dùng loại **đã chế**, liều nhỏ, có thầy thuốc chỉ định; Lưu hoàng sống không dùng uống.
> - **Xông diêm sinh** (xông lưu huỳnh): đốt lưu huỳnh trong buồng kín, khí SO~2~ sinh ra (S + O~2~ → SO~2~) ngấm vào dược liệu. SO~2~ là chất khử nên **tẩy trắng**, đồng thời ức chế nấm mốc, mọt, giúp dược liệu (Hoài sơn, Bạch chỉ, Cát căn, Bạch thược…) trắng đẹp, lâu hỏng.
> - **Mặt trái — dư lượng SO~2~**: xông quá mức để lại nhiều sulfit trong dược liệu, gây kích ứng đường tiêu hóa, hô hấp, nguy hiểm cho người nhạy cảm sulfit. SO~2~ còn có thể **biến đổi hoạt chất**: ví dụ paeoniflorin của **Bạch thược** chuyển một phần thành dẫn chất sulfonat. Vì vậy Dược điển Trung Quốc (từ bản 2015) đã đặt **giới hạn tồn dư SO~2~** cho dược liệu (thường ≤ 150 mg/kg; ≤ 400 mg/kg với một số vị như Hoài sơn, Bạch thược, Thiên ma…).
> - *Thực hành:* dược liệu **trắng bất thường, mùi hắc chua, nếm thấy chua the** là dấu hiệu nghi xông diêm sinh quá mức. Nên mua dược liệu có nguồn gốc, đạt tiêu chuẩn kiểm nghiệm.

## 4. Nhóm VA: N, P, As

### 4.1. Vị trí và đặc điểm

- Lớp ngoài **ns^2^np^3^**, có 3 e độc thân.
- **Trừ N**, P và As có phân lớp **nd trống**: e từ ns chuyển lên nd tạo **5 e độc thân** → hóa trị tối đa **5** (PCl~5~, H~3~PO~4~).
- **Nitơ** không có d, nên:
  - Với kim loại mạnh có thể nhận 3 e thành ion **nitrua N^3−^** (Li~3~N, Ca~3~N~2~).
  - Phần lớn hợp chất nitơ là liên kết **cộng hóa trị**: góp chung 3 e tạo 3 liên kết; cặp e tự do ở 2s có thể cho đi tạo thêm **liên kết phối trí** thứ tư (như trong NH~4~^+^). Vậy N có **hóa trị tối đa 4** (câu 4.17).
  - N có nhiều số oxy hóa nhất nhóm: **từ −3 đến +5** (Hình 2).

### 4.2. Tính chất hóa học của đơn chất

**a) Với phi kim**

- **N~2~ rất trơ** ở nhiệt độ thường vì phân tử có **liên kết ba** N≡N năng lượng lớn, độ dài nhỏ. Với oxy, N~2~ chỉ phản ứng khi có tia lửa điện, khoảng 3000 °C (xảy ra trong tia chớp):

=> N~2~ + O~2~ → 2NO

- **Phospho trắng** bị oxy hóa chậm trong không khí, **phát sáng** trong tối (hiện tượng **lân quang**), tạo P~2~O~3~ và P~2~O~5~:

=> 4P + 3O~2~ → 2P~2~O~3~ ; 4P + 5O~2~ → 2P~2~O~5~

- **Phospho đỏ** phổ biến hơn, bền hơn; dễ cháy khi cọ sát có oxy → dùng làm **diêm**.
- Với hydro (cần xúc tác, nhiệt độ) tạo hợp chất dạng XH~3~: NH~3~, PH~3~, AsH~3~. Với halogen: 2P + 3Cl~2~ → 2PCl~3~ (phospho cháy trong clo).

**b) Với kim loại.** Ở nhiệt độ thường N~2~ chỉ phản ứng với Li; ở nhiệt độ cao N, P tác dụng với kim loại tạo **nitrid, phosphid**:

=> N~2~ + 3Ca → Ca~3~N~2~ (t°) ; 2P + 3Mg → Mg~3~P~2~ (t°)

### 4.3. Các hợp chất

**a) Amoniac NH~3~** (câu 4.18)

- **Hình chóp tam giác**, N lai hóa sp^3^, góc ≈ 107°; phân tử phân cực (μ = 1,48 D), tạo được liên kết hydro (nên NH~3~ tan rất nhiều trong nước).
- **Tính base** nhờ **cặp e tự do** trên N nhận H^+^:

=> NH~3~ + H^+^ → NH~4~^+^

=> NH~3~ + H~2~O ⇌ NH~4~^+^ + OH^−^

- **Tạo phức tan** với một số muối, hydroxide khó tan (cặp e tự do cho vào ion kim loại):

=> AgCl + 2NH~3~ → [Ag(NH~3~)~2~]Cl

=> Cu(OH)~2~ + 4NH~3~ → [Cu(NH~3~)~4~](OH)~2~ (dung dịch xanh lam thẫm)

- **Bị oxy hóa** thành NO (xúc tác Pt, khoảng 800 °C) — bước đầu sản xuất HNO~3~:

=> 4NH~3~ + 5O~2~ → 4NO + 6H~2~O

- **Bị kim loại thay thế H**, tạo amidua NH~2~^−^, imidua NH^2−^, nitrua N^3−^:

=> 2NH~3~ + 2Na → 2NaNH~2~ + H~2~↑

**b) Phosphin PH~3~** — hình chóp, góc ≈ 93,7°; **khí rất độc**. Ở khoảng 150 °C tự bốc cháy trong không khí (PH~3~ + 2O~2~ → H~3~PO~4~). Sinh ra khi thủy phân phosphid kim loại:

=> Ca~3~P~2~ + 6H~2~O → 3Ca(OH)~2~ + 2PH~3~↑

PH~3~ thường lẫn một ít diphosphin P~2~H~4~ — chất này tự bốc cháy ngay ở nhiệt độ thường (giải thích hiện tượng "ma trơi").

**c) Các oxide của nitơ**

| Oxide | Số oxy hóa N | Tên | Đặc điểm |
|---|---|---|---|
| N~2~O | +1 | Dinitơ oxide (protoxide, "khí cười") | Khí không màu |
| NO | +2 | Nitơ oxide | Khí không màu |
| N~2~O~3~ | +3 | Dinitơ trioxide (anhydrid nitrơ) | Chất lỏng; N~2~O~3~ + H~2~O → 2HNO~2~ |
| NO~2~ | +4 | Nitơ dioxide | Khí **màu nâu đỏ**; 3NO~2~ + H~2~O → 2HNO~3~ + NO |
| N~2~O~5~ | +5 | Dinitơ pentoxide (anhydrid nitric) | Chất rắn; N~2~O~5~ + H~2~O → 2HNO~3~ |

**d) Acid nitrơ HNO~2~ và muối nitrit (N^+3^)** (câu 4.19)

- HNO~2~ là **acid yếu**, chỉ có trong dung dịch, dễ bị phân hủy (tự oxy hóa – khử):

=> 3HNO~2~ → HNO~3~ + 2NO↑ + H~2~O

- Muối **nitrit** tương đối bền, kết tinh được, dễ tan.
- N^+3^ là mức **trung gian** nên nitrit **vừa có tính khử, vừa có tính oxy hóa**:

Nitrit là **chất khử** (gặp MnO~4~^−^):

=> 5NO~2~^−^ + 2MnO~4~^−^ + 6H^+^ → 5NO~3~^−^ + 2Mn^2+^ + 3H~2~O

Nitrit là **chất oxy hóa** (gặp I^−^):

=> 2NO~2~^−^ + 2I^−^ + 4H^+^ → 2NO↑ + I~2~ + 2H~2~O

**e) Acid nitric HNO~3~ và muối nitrat** (câu 4.20)

- Phân tử phẳng, N lai hóa sp^2^. **Acid mạnh** nhưng **kém bền**: dưới ánh sáng, nhiệt độ bị phân hủy một phần (vì thế dung dịch HNO~3~ để lâu ngả vàng do NO~2~ hòa tan, phải đựng trong chai sẫm màu):

=> 4HNO~3~ → 4NO~2~↑ + O~2~↑ + 2H~2~O

| | HNO~3~ **đặc** | HNO~3~ **loãng** |
|---|---|---|
| Sản phẩm khử thường gặp | NO~2~ (nâu đỏ) | NO; với kim loại mạnh có thể tới N~2~O, N~2~, **NH~4~^+^** |
| Ví dụ | Cu + 4HNO~3~ → Cu(NO~3~)~2~ + 2NO~2~↑ + 2H~2~O | 4Mg + 10HNO~3~ → 4Mg(NO~3~)~2~ + NH~4~NO~3~ + 3H~2~O |
| Với phi kim | S + 6HNO~3~ → H~2~SO~4~ + 6NO~2~↑ + 2H~2~O | — |
| Đặc biệt | **Thụ động hóa Fe, Al** khi nguội | Không bao giờ giải phóng H~2~ |

- **Muối nitrat** đều **dễ tan**. Khi nhiệt phân, sản phẩm phụ thuộc kim loại (câu 4.22):

| Kim loại trong muối | Sản phẩm nhiệt phân | Ví dụ |
|---|---|---|
| Rất hoạt động (K, Na…) | **Nitrit** + O~2~ | 2KNO~3~ → 2KNO~2~ + O~2~ |
| Trung bình (Mg … Cu) | **Oxide** + NO~2~ + O~2~ | 2Cu(NO~3~)~2~ → 2CuO + 4NO~2~ + O~2~ |
| Kém hoạt động (Ag, Hg) | **Kim loại** + NO~2~ + O~2~ | 2AgNO~3~ → 2Ag + 2NO~2~ + O~2~ ; Hg(NO~3~)~2~ → Hg + 2NO~2~ + O~2~ |

> [!vi-du] Câu 4.21 và 4.22 — các phản ứng đáng nhớ
> => 2NH~3~ + CO~2~ + H~2~O → (NH~4~)~2~CO~3~ (dd)
>
> => 2NH~3~ + CO~2~ → (NH~2~)~2~CO + H~2~O (t°, p)
>
> => Ag + 2HNO~3~ (đặc) → AgNO~3~ + NO~2~↑ + H~2~O
>
> => NH~4~HCO~3~ → NH~3~↑ + CO~2~↑ + H~2~O (t°)
>
> Phản ứng thứ hai (áp suất, nhiệt độ cao) là cách **sản xuất urê**; NH~4~HCO~3~ là "bột khai" làm nở bánh.
>
> => 2NaNO~3~ → 2NaNO~2~ + O~2~↑ (t°)

**f) Acid phosphoric H~3~PO~4~ và muối phosphat**

- Acid quan trọng nhất của phospho; acid **3 nấc**, độ mạnh trung bình.
- **Khác HNO~3~, H~3~PO~4~ không có tính oxy hóa** (dưới 350 °C). *Vì sao?* Liên kết **P–O bền hơn N–O**, nên P^+5^ khó bị khử.
- Muối phosphat phổ biến trong tự nhiên ở quặng **apatit** Ca~5~F(PO~4~)~3~. Công nghiệp dùng apatit sản xuất H~3~PO~4~ và phân lân:

=> Ca~5~F(PO~4~)~3~ + 5H~2~SO~4~ + 10H~2~O → 5CaSO~4~·2H~2~O + 3H~3~PO~4~ + HF

### 4.4. Điều chế

- **N~2~**: phòng thí nghiệm nhiệt phân muối NH~4~NO~2~ → N~2~ + 2H~2~O; công nghiệp **hóa lỏng không khí rồi chưng cất phân đoạn**.
- **Phospho**: khử quặng phosphat trong lò điện (khoảng 1000–1500 °C):

=> 2Ca~3~(PO~4~)~2~ + 6SiO~2~ + 10C → 6CaSiO~3~ + 10CO + P~4~

- **NH~3~** (sản xuất phân đạm): N~2~ từ không khí, H~2~ từ khí thiên nhiên. Phản ứng **tỏa nhiệt, thuận nghịch, giảm số mol khí** → dùng **áp suất cao** (khoảng 220 atm), nhiệt độ vừa phải **380–450 °C**, xúc tác **bột sắt** hoạt hóa:

=> N~2~ + 3H~2~ ⇌ 2NH~3~ (tỏa nhiệt)

- **HNO~3~** công nghiệp (câu 4.23):

=> N~2~ → NH~3~ → NO → NO~2~ → HNO~3~

Cụ thể: 4NH~3~ + 5O~2~ → 4NO + 6H~2~O (Pt, 800 °C); 2NO + O~2~ → 2NO~2~; 4NO~2~ + O~2~ + 2H~2~O → 4HNO~3~.

### 4.5. Ý nghĩa sinh học của nitơ (và phospho, arsen)

- Nitơ có trong **mọi cơ thể sống**: protein, acid nucleic, urê, hormon (động vật); alcaloid, vitamin, chlorophyl (thực vật).
- Động vật và thực vật bậc cao **không dùng trực tiếp N~2~** của không khí. Chỉ một số vi khuẩn (như *Azotobacter*, vi khuẩn **nốt sần ở rễ cây họ Đậu**) cố định được N~2~.
- Sấm chớp tạo ra NO~2~, NH~3~… theo nước mưa vào đất thành muối nitrat, muối amoni. Cây hấp thu nitơ dưới dạng **muối amoni, nitrat**; động vật nhận nitơ qua thức ăn thực vật.

> [!ung-dung] Hợp chất nitơ trong y học
> - **NO là chất truyền tin giãn mạch.** Tế bào nội mô mạch máu sinh NO; NO khuếch tán vào cơ trơn, hoạt hóa guanylat cyclase → tăng cGMP → **giãn mạch**. **Nitroglycerin** (ngậm dưới lưỡi) và isosorbid dinitrat cắt cơn **đau thắt ngực** vì trong cơ thể chúng giải phóng NO. NO dạng **khí hít** dùng điều trị tăng áp động mạch phổi ở trẻ sơ sinh.
> - **N~2~O** ("khí cười") là thuốc mê đường hô hấp, giảm đau nhẹ. Hít N~2~O để "tiêu khiển" kéo dài gây thiếu vitamin B~12~, tổn thương thần kinh.
> - **NH~3~/NH~4~^+^**: amoniac sinh ra từ chuyển hóa protein là chất **độc với não**; gan chuyển nó thành **urê** để thải qua thận. Suy gan làm NH~3~ máu tăng → **bệnh não gan**. Thuốc **lactulose** làm acid hóa đại tràng, biến NH~3~ (dễ hấp thu) thành NH~4~^+^ (khó hấp thu) để thải theo phân — một ứng dụng trực tiếp của cân bằng NH~3~ + H^+^ ⇌ NH~4~^+^.
> - **Nitrit** (NaNO~2~, chất bảo quản giữ màu đỏ cho thịt nguội, xúc xích) có **tính oxy hóa**: ngộ độc nitrit oxy hóa Fe^2+^ của hemoglobin thành Fe^3+^ (**methemoglobin**) không chở được oxy → tím tái; thuốc giải là **xanh methylen**. Trong dạ dày (môi trường acid), nitrit còn phản ứng với **amin bậc hai** tạo **nitrosamin** — chất có khả năng **gây ung thư**. Nước giếng nhiễm nitrat/nitrit cũng nguy hiểm cho trẻ nhỏ.
> - **Phosphat**: **ATP** (adenosin triphosphat) giữ năng lượng trong các liên kết phosphoanhydrid; hệ **đệm phosphat** H~2~PO~4~^−^/HPO~4~^2−^ quan trọng trong tế bào và nước tiểu; xương, răng có thành phần chính là **hydroxyapatit** Ca~10~(PO~4~)~6~(OH)~2~.
> - **Phosphid kẽm, nhôm** (thuốc diệt chuột, viên xông kho chống mọt) gặp nước hoặc acid dạ dày giải phóng **PH~3~ rất độc** (như phản ứng Ca~3~P~2~ + H~2~O ở trên). Uống phải nhôm phosphid thường tử vong; viên xông kho chỉ do người được huấn luyện sử dụng.

**Arsen (As).** Giáo trình chỉ nêu As cùng nhóm với N, P (số oxy hóa −3, +3, +5; tạo AsH~3~). Về y học, arsen là ví dụ kinh điển cho câu "liều lượng làm nên chất độc":

> [!ung-dung] Arsen — chất độc và thuốc
> - **Ngộ độc arsen**: As^3+^ gắn vào nhóm **–SH** của enzym, làm bất hoạt nhiều enzym chuyển hóa năng lượng. Ngộ độc cấp: nôn, tiêu chảy dữ dội, sốc. Ngộ độc mạn (thường do **nước giếng khoan nhiễm arsen**, gặp ở một số vùng đồng bằng sông Hồng): dày sừng lòng bàn tay chân, rối loạn sắc tố da, tăng nguy cơ ung thư da, phổi, bàng quang. Thuốc giải là các chất có nhóm –SH như **dimercaprol (BAL)**, DMSA. Khí **arsin** AsH~3~ gây tan máu cấp.
> - **As~2~O~3~ làm thuốc**: arsen trioxide (dạng tiêm, liều kiểm soát chặt) là thuốc chuẩn điều trị **bệnh bạch cầu cấp tiền tủy bào** (APL, thể M3), phối hợp với acid all-trans retinoic (ATRA). Thuốc thúc đẩy tế bào ác tính biệt hóa và chết theo chương trình. Hướng nghiên cứu này khởi nguồn một phần từ kinh nghiệm dùng thạch tín trong y học cổ truyền Trung Quốc.

> [!yhct] Hùng hoàng (As₄S₄) — vì sao "kỵ hỏa"
> - **Hùng hoàng** là khoáng vật **realgar**, thành phần chính **As~4~S~4~** (arsen sulfid, As có số oxy hóa +2). YHCT dùng chủ yếu **ngoài da** (sát trùng, trị ghẻ lở, mụn nhọt, rắn cắn); dùng trong chỉ ở dạng **hoàn tán**, liều rất nhỏ (theo Dược điển Trung Quốc 0,05–0,1 g/ngày), **không sắc**, không dùng lâu, cấm dùng cho phụ nữ có thai.
> - **Cơ sở hóa học của "kỵ hỏa"** (cấm nung, sao): khi đun nóng trong không khí, As~4~S~4~ bị oxy hóa thành **As~2~O~3~ — thạch tín** (Tín thạch, Phê sương), dễ tan và **độc hơn rất nhiều**:
>
> => As~4~S~4~ + 7O~2~ → 2As~2~O~3~ + 4SO~2~ (t°)
>
> - Vì vậy Hùng hoàng chỉ được chế bằng **thủy phi**: nghiền mịn trong nước, gạn lấy phần bột lơ lửng, phơi khô trong râm. Cách này vừa làm bột mịn, vừa rửa bớt phần As~2~O~3~ tan lẫn trong khoáng. Tục ngâm "rượu Hùng hoàng" uống vào Tết Đoan ngọ hoặc hơ nóng thuốc có Hùng hoàng là **nguy hiểm**.
> - Thành phần As~4~S~4~ rất ít tan nên được cho là hấp thu kém, nhưng các nghiên cứu vẫn ghi nhận **tích lũy arsen** khi dùng kéo dài các chế phẩm có Hùng hoàng (như một số thành phẩm có Ngưu hoàng, Hùng hoàng). Liên hệ với ứng dụng As~2~O~3~ trị APL ở trên: cùng một nguyên tố, ranh giới giữa thuốc và độc nằm ở **dạng hóa học, liều và cách dùng**.

## 5. Nhóm IVA: C, Si

### 5.1. Vị trí và đặc điểm

- Lớp ngoài **ns^2^np^2^**. Một e ở ns dễ chuyển lên np, tạo **4 e độc thân** (ns^1^np^3^) → trong hầu hết hợp chất C, Si có **hóa trị IV** và chỉ tạo **liên kết cộng hóa trị**; **không tồn tại ion C^4+^ hay Si^4+^**. Số oxy hóa của C trải **từ −4 (CH~4~) đến +4 (CO~2~)**.
- **Si có orbital 3d trống** nên tạo được phức (ví dụ [SiF~6~]^2−^); C thì không.
- **C có khả năng tạo mạch** –C–C–C– dài, bền → nguồn gốc của sự đa dạng hợp chất hữu cơ (hàng chục triệu chất).

### 5.2. Tính chất hóa học

**a) Carbon.** Ở nhiệt độ thường rất trơ; ở nhiệt độ cao thể hiện chủ yếu **tính khử**.

- Với oxy (tỏa nhiều nhiệt): C + O~2~ → CO~2~ (ΔH° = −94,14 kcal/mol). Thiếu oxy tạo **CO**. Ở nhiệt độ cao C còn phản ứng với hydro.
- Với kim loại hoạt động (lò điện) tạo **carbid** (liên kết ion):

=> Ca + 2C → CaC~2~ ; 4Al + 3C → Al~4~C~3~

- Với hợp chất (C là **chất khử**):

=> C + CO~2~ → 2CO (t°)

=> C + H~2~O → CO + H~2~ (than nóng đỏ)

Hỗn hợp CO + H~2~ này gọi là **khí than ướt**.

- Nung C với CaO trong lò điện được CaC~2~ (**đất đèn**):

=> CaO + 3C → CaC~2~ + CO (lò điện)

> [!bay] Phản ứng CaO + C trong sách
> Giáo trình (tr. 61) in "2C + CaO → CaC~2~ + CO" và nói C thể hiện **tính oxy hóa**. Phương trình **chưa cân bằng**: vế phải có 3 C, phải là **3C** + CaO. Xét số oxy hóa: 2 nguyên tử C xuống −1 (trong CaC~2~, C nhận e → C là chất oxy hóa), 1 nguyên tử C lên +2 (trong CO, C nhường e → chất khử). Vậy C vừa là chất oxy hóa, vừa là chất khử (**tự oxy hóa – khử**). Đi thi: nhớ ý của sách "C thể hiện tính oxy hóa" là nói về phần C tạo carbid.

**b) Silic.**

- Si đơn chất có cấu trúc giống kim cương, là **chất bán dẫn**.
- Phản ứng với O~2~, Cl~2~ ở 400–600 °C; với H~2~ ở nhiệt độ hồ quang tạo **silan** Si~n~H~2n+2~.
- Ở nhiệt độ thường **không tác dụng với acid**, nhưng tan trong hỗn hợp HNO~3~ + HF (F^−^ kéo Si vào phức [SiF~6~]^2−^):

=> 3Si + 4HNO~3~ + 18HF → 3H~2~[SiF~6~] + 4NO↑ + 8H~2~O

- Tan trong kiềm, giải phóng H~2~:

=> Si + 2NaOH + H~2~O → Na~2~SiO~3~ + 2H~2~↑

### 5.3. Các hợp chất

**a) Hydrocarbon** — hợp chất của C với H, sẽ học ở phần Hóa hữu cơ.

**b) Carbon monoxide CO** (câu 4.24)

- **Thuyết VB**: C≡O là liên kết ba gồm **1 σ và 2 π** (hai liên kết góp chung, một liên kết phối trí từ O sang C). **Thuyết MO**: cấu hình (σ~s~)^2^(σ~s~\*)^2^(π~x~)^2^(π~y~)^2^(σ~z~)^2^ → bậc liên kết **3**; độ dài 1,13 Å; năng lượng liên kết rất lớn (256,1 kcal/mol). CO và N~2~ có cùng số electron (đẳng electron) nên giống nhau về độ bền.
- Rất bền nhiệt; cháy trong oxy ở khoảng 700 °C: 2CO + O~2~ → 2CO~2~.
- Với Cl~2~ (ánh sáng, xúc tác) tạo **phosgen** COCl~2~ (rất độc). Với H~2~ (xúc tác ZnO) tạo **methanol**: CO + 2H~2~ → CH~3~OH.
- Với kim loại tạo **carbonyl kim loại** như Fe(CO)~5~ (chất lỏng, dễ phân hủy) → dùng điều chế kim loại tinh khiết: Fe(CO)~5~ → Fe + 5CO (t°).
- **Chất khử** trong luyện kim: Fe~2~O~3~ + 3CO → 2Fe + 3CO~2~ (lò cao).
- Sinh ra khi than cháy **thiếu oxy**, khi hơi nước qua than nóng đỏ. Phòng thí nghiệm: HCOOH → CO + H~2~O (H~2~SO~4~ đặc hút nước).

> [!vi-du] Câu 4.26 — Cho hỗn hợp CO và CO₂ qua ống đựng CuO dư nung nóng
> Chỉ CO phản ứng: CO + CuO → Cu + CO~2~ (t°). Mỗi phân tử CO biến thành một phân tử CO~2~ nên **tổng số mol khí không đổi**, nhưng **tỉ lệ CO~2~ tăng** (CO bị chuyển hết thành CO~2~ vì CuO dư).

**c) CO~2~, acid carbonic và muối carbonat**

- CO~2~ phân tử **thẳng** (C lai hóa sp), không phân cực. Bền với nhiệt (chỉ phân hủy một phần ở nhiệt độ rất cao) và bền với nhiều tác nhân hóa học; chỉ bị khử bởi kim loại có ái lực mạnh với oxy:

=> CO~2~ + 2Mg → 2MgO + C (Mg vẫn cháy trong CO~2~)

- Bị **NaOH** rắn hoặc đặc hấp thụ dễ dàng tạo Na~2~CO~3~ hoặc NaHCO~3~ (dùng loại CO~2~ trong thí nghiệm với súc vật).
- Tan trong nước có cân bằng:

=> CO~2~ + H~2~O ⇌ H~2~CO~3~ ⇌ H^+^ + HCO~3~^−^

- **Acid carbonic** rất yếu, chỉ có trong dung dịch, 2 nấc (K~1~ = 4,16·10^−7^; K~2~ = 4,84·10^−11^). Ion CO~3~^2−^ **phẳng**, góc 120°, ba liên kết C–O dài bằng nhau (1,31 Å) do **cộng hưởng**.
- **Muối**: carbonat kim loại kiềm và **hydrocarbonat** kim loại kiềm thổ dễ tan. Na~2~CO~3~, NaHCO~3~ dùng nhiều trong chất tẩy rửa, thủy tinh, thực phẩm.

> [!vi-du] Câu 4.25 — Vì sao CaCO₃ tan trong nước bão hòa CO₂?
> => CaCO~3~ + CO~2~ + H~2~O ⇌ Ca(HCO~3~)~2~ (tan)
>
> Đây chính là cách nước mưa có CO~2~ hòa tan đá vôi, tạo **hang động**, và là nguồn gốc của **nước cứng tạm thời**. Phản ứng nghịch (khi CO~2~ thoát ra) tạo **thạch nhũ** và **cặn ấm đun nước**.

**d) Acid cyanhydric HCN và muối cyanid** — HCN là chất lỏng sôi ở 25,6 °C, phân tử thẳng, có liên kết hydro …H–C≡N…H–C≡N…; dung dịch là acid **rất yếu** (pK = 9,31). Dùng trong tổng hợp hữu cơ, diệt côn trùng; **rất độc** qua đường tiêu hóa, hô hấp và thấm qua da. HCN có ở dạng tự do trong một số cây nhiệt đới (sắn), dạng glycosid trong hạt đào, mận… (đã học ở bài Glucid).

**e) Hợp chất của silic**

- **SiO~2~** là **oxide acid**; acid tương ứng có công thức chung xSiO~2~·yH~2~O (H~4~SiO~4~ — acid orthosilicic; H~2~SiO~3~ — acid metasilicic).
- SiO~2~ **không tác dụng với acid**, **trừ HF**:

=> SiO~2~ + 4HF → SiF~4~↑ + 2H~2~O

=> SiO~2~ + 6HF (dư) → H~2~[SiF~6~] + 2H~2~O

- Tác dụng với **kiềm hoặc carbonat kim loại kiềm nóng chảy** tạo silicat:

=> SiO~2~ + 2KOH → K~2~SiO~3~ + H~2~O (nóng chảy)

=> SiO~2~ + Na~2~CO~3~ → Na~2~SiO~3~ + CO~2~↑ (nóng chảy)

### 5.4. Tác dụng và ý nghĩa sinh học

**a) CO — khí rất độc.** CO kết hợp với hemoglobin tạo **carboxyhemoglobin HbCO**, bền gấp khoảng **300 lần** so với HbO~2~ (theo giáo trình), nên Hb không còn chở được oxy tới mô. Cho nạn nhân thở không khí trong lành hoặc **thở oxy**, cân bằng dịch chuyển, CO dần được giải phóng:

=> HbCO + O~2~ ⇌ HbO~2~ + CO

**b) CO~2~.** Là sản phẩm hô hấp của động vật, đồng thời là nguyên liệu **quang hợp** của cây xanh — tạo glucid và tái tạo oxy:

=> 6CO~2~ + 6H~2~O → C~6~H~12~O~6~ + 6O~2~ (ánh sáng, chlorophyl)

CO~2~ không độc theo nghĩa thông thường nhưng gây **ngạt** vì chiếm chỗ oxy, nhất là ở nơi không khí tù đọng (hầm, giếng sâu, hang). CO~2~ cùng CH~4~, O~3~, CFC, hơi nước gây **hiệu ứng nhà kính**: cho ánh sáng mặt trời (λ 500–1000 nm) đi qua nhưng giữ lại bức xạ hồng ngoại (λ > 1400 nm) do mặt đất phát ra.

**c) HCN, cyanid.** Ion CN^−^ gắn với **ion sắt của các enzym hô hấp** (cytochrom oxidase) tạo phức không có hoạt tính, làm **ngừng quá trình oxy hóa** trong tế bào. Tế bào não điều khiển hô hấp nhạy cảm nhất.

> [!cap-nhat] Số liệu về CO và nhiệt độ Trái Đất
> - **CO**: giáo trình ghi HbCO bền gấp 300 lần HbO~2~. Hiện nay số liệu thường dùng là ái lực của Hb với CO lớn hơn với O~2~ khoảng **200–250 lần**. Điều trị ngộ độc CO: cho thở **oxy 100%** càng sớm càng tốt (rút ngắn thời gian bán thải HbCO từ khoảng 4–5 giờ khi thở khí trời xuống khoảng 1 giờ); ca nặng có thể dùng **oxy cao áp**. Lưu ý máy đo SpO~2~ thông thường **không phân biệt được HbCO** với HbO~2~, nên SpO~2~ có thể "bình thường giả".
> - **Nóng lên toàn cầu**: giáo trình ghi nhiệt độ trung bình Trái Đất đã tăng khoảng 0,5 °C. Theo báo cáo IPCC (2021), mức tăng đến thập niên 2011–2020 đã khoảng **1,1 °C** so với thời kỳ tiền công nghiệp.
>
> Khi thi, trả lời theo số liệu giáo trình.

> [!ung-dung] Carbon, silic trong y học
> - **Than hoạt** (carbon xốp, diện tích bề mặt rất lớn) **hấp phụ** nhiều chất độc, thuốc trong ống tiêu hóa; dùng trong ngộ độc qua đường uống (hiệu quả nhất khi cho sớm, trong khoảng 1 giờ đầu). Than hoạt **không** hấp phụ tốt kim loại (sắt, lithi), alcol, acid hoặc kiềm mạnh.
> - **Hệ đệm bicarbonat** CO~2~/HCO~3~^−^ là hệ đệm chính của máu. Enzym **carbonic anhydrase** xúc tác nhanh phản ứng CO~2~ + H~2~O ⇌ H~2~CO~3~. Thở chậm, ứ CO~2~ → **toan hô hấp**; thở nhanh, thải nhiều CO~2~ → **kiềm hô hấp**.
> - **Silic**: SiO~2~ dạng **silica gel** là chất hút ẩm (gói nhỏ trong lọ thuốc, túi dược liệu). Hít lâu ngày bụi SiO~2~ tinh thể gây **bệnh bụi phổi silic** (nghề mỏ, đá, gốm). **Simethicon** (polymer silicon) chống đầy hơi; **diosmectit** (Smecta — nhôm magnesi silicat) điều trị tiêu chảy; **talc** (magnesi silicat ngậm nước, tương ứng vị Hoạt thạch) dùng làm tá dược trơn trong viên nén.

## Đính chính các phương trình in nhầm trong bài

Bảng gom các lỗi cân bằng trong chương (bài viết ở trên đã dùng dạng đúng). Đi thi cần viết dạng **đã cân bằng**.

| Trang | Giáo trình in | Đúng là |
|---|---|---|
| 45, 249 | 3H~2~ + N~2~ → 3NH~3~ | 3H~2~ + N~2~ ⇌ **2**NH~3~ |
| 45 | H~2~ + Na → 2NaH | H~2~ + **2**Na → 2NaH |
| 46, 247 | 5H~2~O~2~ + 2MnO~4~^−^ + 6H^+^ → 5O~2~ + 2Mn^2+^ + H~2~O | … + **8**H~2~O |
| 49 | Cl~2~ + Fe → FeCl~3~ | **3**Cl~2~ + **2**Fe → **2**FeCl~3~ |
| 52 | 3O~2~ + 3Fe → Fe~3~O~4~ | **2**O~2~ + 3Fe → Fe~3~O~4~ |
| 53, 248 | 5SO~3~^2−^ + 2MnO~4~^−^ + 16H^+^ → … + 8H~2~O | **6**H^+^ … + **3**H~2~O |
| 54 | H~2~SO~4~ + C → CO~2~ + SO~2~ + H~2~O | **2**H~2~SO~4~ + C → CO~2~ + **2**SO~2~ + **2**H~2~O |
| 57, 248 | 4NH~3~ + 5O~2~ → 4NO + 4H~2~O | … + **6**H~2~O |
| 58 | HNO~2~ → HNO~3~ + NO~2~ | **3**HNO~2~ → HNO~3~ + **2NO** + H~2~O |
| 58 | 4HNO~3~ → 4NO~2~ + O~2~ + H~2~O | … + **2**H~2~O |
| 58, 248, 249 | 6HNO~3~ + S → 6NO~2~ + 3H~2~SO~4~ + 2H~2~O | … + **1** H~2~SO~4~ + 2H~2~O |
| 59 | Cu(NO~3~)~2~ → 2CuO + 4NO~2~ + O~2~ | **2**Cu(NO~3~)~2~ → 2CuO + 4NO~2~ + O~2~ |
| 59 | 4Ca~3~(PO~4~)~3~ + 12SiO~2~ + 48C → 12CaSiO~2~ + 48CO + 3P~4~ | 2Ca~3~(PO~4~)~2~ + 6SiO~2~ + 10C → 6CaSiO~3~ + 10CO + P~4~ (sai cả công thức Ca~3~(PO~4~)~2~ và CaSiO~3~) |
| 61 | 2C + CaO → CaC~2~ + CO | **3**C + CaO → CaC~2~ + CO |
| 61 | 3Si + 4HNO~3~ + HF → H~2~[SiF~6~] + NO + H~2~O | 3Si + 4HNO~3~ + **18**HF → **3**H~2~[SiF~6~] + **4**NO + **8**H~2~O |
| 64 | SiO~2~ + 2HF (dư) → H~2~[SiF~6~] | SiO~2~ + **6**HF → H~2~[SiF~6~] + **2H~2~O** |
| 247 | CaOCl~2~ + HCl → CaCl~2~ + H~2~O + Cl~2~ | CaOCl~2~ + **2**HCl → … |
| 247 | 2NaOCl + 2KI → 2NaCl + 2KCl + O~2~ + I~2~ | NaOCl + 2KI + H~2~O → NaCl + I~2~ + 2KOH |
| 249 | NH~3~ + CO~2~ → (NH~2~)~2~CO + H~2~O | **2**NH~3~ + CO~2~ → (NH~2~)~2~CO + H~2~O |

## Tóm tắt

| Nhóm | Lớp ngoài | Số oxy hóa | Đơn chất | Hợp chất "phải nhớ" | Y học |
|---|---|---|---|---|---|
| **H** | 1s^1^ | −1, +1 | Khử (H mới sinh mạnh hơn H~2~) | H~2~O (liên kết hydro), H~2~O~2~ (vừa oxy hóa vừa khử) | H~2~O~2~ sát khuẩn; catalase |
| **VIIA** | ns^2^np^5^ | −1; Cl, Br, I: +1, +3, +5, +7 | Oxy hóa: F~2~ > Cl~2~ > Br~2~ > I~2~ | HX (acid tăng HF→HI; HF khắc thủy tinh); Javel, clorua vôi, KClO~3~ | Khử trùng Cl, povidon-iod, muối iod – bướu cổ, F^−^ – răng |
| **VIA** | ns^2^np^4^ | −2; S: +4, +6 | O~3~ oxy hóa mạnh hơn O~2~; O~2~ thuận từ (MO) | H~2~S khử; SO~2~ vừa khử vừa oxy hóa; H~2~SO~4~ đặc oxy hóa | H~2~S độc; SO~2~/sulfit bảo quản; Lưu hoàng; dư lượng SO~2~ |
| **VA** | ns^2^np^3^ | N: −3 → +5; P, As: −3, +3, +5 | N~2~ trơ (liên kết ba); P trắng lân quang | NH~3~ base, tạo phức; nitrit vừa oxy hóa vừa khử; HNO~3~ oxy hóa mạnh; H~3~PO~4~ không oxy hóa | NO giãn mạch, nitroglycerin, N~2~O; NH~3~ – bệnh não gan; nitrit – MetHb, nitrosamin; ATP; As~2~O~3~ – APL; Hùng hoàng |
| **IVA** | ns^2^np^2^ | C: −4 → +4; hóa trị IV | C khử ở nhiệt độ cao; Si bán dẫn | CO (liên kết ba, khử), CO~2~/HCO~3~^−^; SiO~2~ chỉ tan trong HF | Ngộ độc CO, than hoạt, đệm bicarbonat, silica gel, bụi phổi silic |

- **Chu kỳ 2 không có d** → O, F, N bị giới hạn hóa trị; chu kỳ 3 trở đi có thêm số oxy hóa cao.
- **Số oxy hóa trung gian → vừa oxy hóa vừa khử**: H~2~O~2~ (O^−1^), SO~2~ (S^+4^), nitrit (N^+3^), Cl~2~.
- **Điều chế đáng nhớ**: H~2~ công nghiệp từ CH~4~ + H~2~O; F~2~ chỉ bằng điện phân nóng chảy; Cl~2~ bằng MnO~2~ + HCl hoặc điện phân NaCl có màng ngăn; H~2~SO~4~ từ pirit; NH~3~ (Fe, 220 atm, 380–450 °C); HNO~3~ từ NH~3~.
