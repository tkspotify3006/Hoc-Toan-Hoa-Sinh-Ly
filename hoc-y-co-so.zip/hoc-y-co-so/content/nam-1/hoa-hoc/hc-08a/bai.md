---
title: Aldehyd và ceton
thoi-gian: 35 phút
muc-tieu:
- Gọi được tên các aldehyd, ceton đơn giản theo danh pháp IUPAC và danh pháp thông thường.
- Mô tả được cấu tạo nhóm C=O và giải thích được cơ chế cộng nucleophil (A~N~).
- Viết được các phản ứng chính của aldehyd, ceton: cộng, thế O, oxy hóa – khử, thế H~α~, ngưng tụ aldol, phản ứng với thuốc thử Schiff.
- So sánh và giải thích được vì sao aldehyd phản ứng mạnh hơn ceton; dùng phản ứng để phân biệt chúng.
- Nêu được các phương pháp điều chế chính và ý nghĩa y học của formaldehyd, aceton, cloral hydrat và các aldehyd, ceton trong dược liệu.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Aldehyd có nhóm **–CHO** (C=O gắn ít nhất một H); ceton có **C=O nằm giữa hai gốc hydrocarbon**. Tên IUPAC: đuôi **-al** và **-on**.
> 2. C=O phân cực (C^δ+^, O^δ−^) nên phản ứng đặc trưng là **cộng nucleophil A~N~**: HCN, NaHSO~3~, alcol, H~2~, Grignard.
> 3. **Aldehyd phản ứng mạnh hơn ceton** vì C của nó dương hơn (ít gốc +I) và ít bị che chắn (ít án ngữ không gian).
> 4. **Chỉ aldehyd có tính khử**: tráng bạc (Tollens), khử Cu(OH)~2~ thành Cu~2~O đỏ gạch, làm hồng thuốc thử Schiff. Ceton thì không. Đây là cách phân biệt.
> 5. H ở **C~α~** linh động: thế halogen (cloral), **ngưng tụ aldol**. Y học: formol (sát khuẩn, cố định mẫu, độc), aceton (thể ceton trong đái tháo đường), cloral hydrat (an thần).

## 1. Định nghĩa và phân loại

Aldehyd và ceton là những hợp chất hữu cơ có nhóm **carbonyl** >C=O (Giáo trình tr. 164).

- **Aldehyd**: nhóm carbonyl gắn với **một gốc hydrocarbon và một nguyên tử H**. Nhóm chức là **–CHO**. Riêng **aldehyd formic** H–CHO có C=O gắn với **hai H**, không có gốc hydrocarbon nào; vẫn được xếp vào aldehyd.
- **Ceton**: nhóm carbonyl gắn với **hai gốc hydrocarbon** R–CO–R′. Nhóm chức ceton là >C=O nằm giữa mạch.

Theo gốc hydrocarbon, chia làm hai loại:

| Loại | Đặc điểm | Ví dụ (theo giáo trình) |
|---|---|---|
| **Aldehyd, ceton béo no** | –CHO hay >C=O gắn với gốc no | Aldehyd acetic CH~3~CHO; ethyl methyl ceton CH~3~COCH~2~CH~3~ |
| **Aldehyd, ceton béo không no** | Gốc có liên kết bội | **Acrolein** CH~2~=CH–CHO; ethenyl methyl ceton CH~2~=CH–CO–CH~3~ |
| **Aldehyd, ceton thơm** | –CHO hay >C=O gắn vào **nhân thơm** hoặc vào **mạch nhánh** của gốc thơm | Aldehyd benzoic C~6~H~5~CHO; aldehyd phenyl acetic C~6~H~5~CH~2~CHO; methyl phenyl ceton C~6~H~5~COCH~3~; diphenyl ceton C~6~H~5~COC~6~H~5~ |

> [!bay]
> - Theo cách chia của giáo trình, C~6~H~5~–CH~2~–CHO (–CHO **không** gắn trực tiếp vào vòng) **vẫn** được xếp là aldehyd **thơm**.
> - Tên thông thường "**ethyl methyl ceton**": các gốc đọc theo **thứ tự chữ cái** (e trước m), không theo độ lớn.

## 2. Danh pháp

### 2.1. Aldehyd

**Tên IUPAC** = tên hydrocarbon tương ứng (mạch dài nhất **chứa C của –CHO**) + đuôi **-al**. Đánh số **1 từ C của nhóm –CHO**, nên không cần ghi số vị trí cho –CHO.

- CH~3~–CH(CH~3~)–CH~2~–CHO → **3-methylbutanal**.
- CH~2~=CH–CHO → **propenal** (acrolein).
- OHC–CHO → **ethandial**; OHC–CH~2~–CH~2~–CHO → **butandial**.

Khi –CHO **gắn trực tiếp vào vòng**, C của –CHO không được đánh số vào vòng. Tên = tên vòng + **carbaldehyd** (giáo trình ghi thêm: *carbonal*). Ví dụ C~6~H~11~–CHO → **cyclohexancarbaldehyd**. Riêng C~6~H~5~–CHO dùng tên giữ lại là **benzaldehyd**.

**Tên thông thường** = chữ "aldehyd" + tên **acid** tương ứng (acid mà aldehyd bị oxy hóa thành):

| Công thức | Tên thông thường | Tên IUPAC |
|---|---|---|
| HCHO | Aldehyd formic (formaldehyd) | Methanal |
| CH~3~CHO | Aldehyd acetic (acetaldehyd) | Ethanal |
| CH~3~CH~2~CHO | Aldehyd propionic | Propanal |
| OHC–CHO | Aldehyd oxalic (glyoxal) | Ethandial |
| C~6~H~5~CHO | Aldehyd benzoic | Benzaldehyd |

### 2.2. Ceton

**Tên IUPAC** = số chỉ vị trí C=O + tên hydrocarbon + đuôi **-on**. Đánh số từ đầu mạch **gần nhóm C=O nhất**.

- CH~3~–CO–CH~2~–CH~3~ → **butan-2-on**.
- CH~3~–CH(CH~3~)–CH~2~–CO–CH~2~–CH~3~ → **5-methylhexan-3-on** (đánh số từ phải để C=O mang số 3, không phải 4).
- Ceton vòng 6 cạnh → **cyclohexanon**.

**Tên thông thường** = tên **các gốc** hydrocarbon + chữ "ceton":

- CH~3~–CO–CH~3~ → **dimethyl ceton**; tên riêng **aceton**; IUPAC **propanon** (propan-2-on).
- CH~3~–CO–CH(CH~3~)~2~ → **methyl isopropyl ceton** = 3-methylbutan-2-on.
- C~6~H~5~–CO–CH~3~ → methyl phenyl ceton, tên riêng **acetophenon**.

> [!bay]
> - Aldehyd: C của –CHO luôn là **C1**, không ghi số. Ceton: **phải** ghi số khi có thể nằm ở nhiều vị trí (pentan-2-on ≠ pentan-3-on). Propanon và butanon không cần số vì chỉ có một vị trí khả dĩ, nhưng ghi propan-2-on, butan-2-on vẫn đúng.
> - Chỉ số mạch tính **cả C của –CHO**: CH~3~CH~2~CHO là **propanal** (3C), không phải "ethanal".
> - Có cả –CHO và C=O ceton thì –CHO được ưu tiên làm đuôi; ceton thành tiền tố **oxo-** (xem bài Danh pháp, mục thứ tự ưu tiên).

> [!vi-du] Tự lượng giá 8.1–8.2 — gọi tên và viết công thức (đáp án tr. 255)
> - **8.1**: a) CH~2~=CH–CHO: **propenal** (aldehyd acrylic) · b) OHC–CHO: **ethandial** (aldehyd oxalic, glyoxal) · c) OHC–CH~2~–CH~2~–CHO: **butandial** (aldehyd succinic) · d) C~6~H~5~–CHO: **benzaldehyd** (aldehyd benzoic; sách: phenyl methanal) · e) OHC–C~6~H~4~–CHO (para): **benzen-1,4-dicarbaldehyd** (đáp án sách in "ando phenyl methanol" là lỗi in) · f) vòng 4 cạnh gắn –CHO: **cyclobutancarbaldehyd**.
> - **8.2**: a) pentan-2-on: CH~3~–CO–CH~2~–CH~2~–CH~3~ · b) pent-3-yn-2-on: CH~3~–CO–C≡C–CH~3~ · c) 2-methylpropanal: (CH~3~)~2~CH–CHO · d) p-bromobenzaldehyd: Br–C~6~H~4~–CHO (Br ở vị trí 4) · e) butyl methyl ceton: CH~3~–CO–CH~2~CH~2~CH~2~CH~3~ (hexan-2-on) · f) cyclopentancarbaldehyd: vòng 5 cạnh no gắn –CHO.

## 3. Đồng phân

| Loại đồng phân | Ví dụ |
|---|---|
| **Nhóm chức khác nhau** (aldehyd ↔ ceton cùng CTPT) | CH~3~CH~2~CHO (propanal) và CH~3~COCH~3~ (propanon), cùng C~3~H~6~O |
| **Mạch carbon** | n-butanal CH~3~(CH~2~)~2~CHO và i-butanal (CH~3~)~2~CH–CHO; methyl propyl ceton và methyl isopropyl ceton |
| **Vị trí nhóm chức** (chỉ ở ceton) | Pentan-2-on và pentan-3-on |

> [!vi-du] Vì sao aldehyd không có đồng phân vị trí nhóm chức?
> –CHO luôn phải nằm ở **đầu mạch** (C1), vì C của nó chỉ còn một hóa trị để nối với mạch. Muốn "dời" nhóm C=O vào giữa mạch thì nó đã thành ceton, tức là đồng phân **nhóm chức** chứ không còn là đồng phân vị trí.

## 4. Tính chất vật lý

Ở điều kiện thường, **aldehyd formic là chất khí**. Các aldehyd tiếp theo là chất lỏng; aldehyd cao như aldehyd palmitic C~15~H~31~CHO là chất rắn (nóng chảy ở +34 °C). Các ceton đầu dãy và trung bình là chất lỏng có mùi đặc trưng; ceton cao là chất rắn (Giáo trình tr. 167).

| Chất | Công thức | Nhiệt độ sôi (°C, theo giáo trình) |
|---|---|---|
| Aldehyd formic | HCHO | −21 (khí) |
| Aldehyd acetic | CH~3~CHO | +21 |
| Aldehyd propionic | CH~3~CH~2~CHO | +48 |
| Aldehyd n-butyric | CH~3~(CH~2~)~2~CHO | +75,7 |
| Aldehyd benzoic | C~6~H~5~CHO | +179,5 |
| Dimethyl ceton (aceton) | CH~3~COCH~3~ | +56,5 |
| Ethyl methyl ceton | CH~3~COC~2~H~5~ | +79,6 |
| Diethyl ceton | C~2~H~5~COC~2~H~5~ | +101,7 |
| Methyl phenyl ceton | C~6~H~5~COCH~3~ | +202,3 |

**Vì sao nhiệt độ sôi như vậy?**

- Aldehyd, ceton **không có H gắn với O**, nên các phân tử **không tạo liên kết hydro với nhau**. Vì vậy chúng sôi **thấp hơn alcol** có khối lượng tương đương (ethanol sôi ở 78 °C, aldehyd acetic chỉ 21 °C).
- Nhưng nhóm C=O **phân cực**, các phân tử hút nhau bằng lực lưỡng cực. Vì vậy chúng sôi **cao hơn hydrocarbon** tương ứng.
- O của C=O vẫn **nhận** được liên kết hydro từ nước. Vì vậy các chất đầu dãy (HCHO, CH~3~CHO, aceton) **tan tốt trong nước**; aceton tan vô hạn.

## 5. Tính chất hóa học

### 5.1. Cấu tạo nhóm carbonyl — chìa khóa của mọi phản ứng

C của nhóm C=O lai hóa **sp^2^**: ba liên kết σ nằm trong một mặt phẳng, góc khoảng 120°. Liên kết π bị kéo lệch về phía **O** (âm điện hơn), nên **C mang δ+**, **O mang δ−** (Giáo trình tr. 167).

![Hình 1. Nhóm carbonyl phân cực và cơ chế cộng nucleophil A~N~](carbonyl-an.svg)

Phản ứng cộng tác nhân H–A (HCN, NaHSO~3~, H–OR…) xảy ra **hai giai đoạn**:

1. **A^−^ (nucleophil) tấn công C^δ+^**, tạo anion alkoxid. Giai đoạn này **chậm**, quyết định tốc độ.
2. **H^+^ gắn vào O^δ−^**. Giai đoạn này nhanh.

Vì giai đoạn quyết định tốc độ do **nucleophil** khởi đầu, phản ứng được gọi là **cộng nucleophil (A~N~)**. Đây là điểm khác cơ bản với anken: C=C giàu electron, không phân cực, nên anken cộng **electrophil** (A~E~). Phần lý thuyết chung về A~N~ đã học ở bài Phản ứng của hợp chất hữu cơ (mục cộng nucleophil).

### 5.2. Phản ứng cộng nucleophil

![Hình 2. Sơ đồ các phản ứng chính của aldehyd và ceton](so-do-phan-ung.svg)

#### a) Cộng natri hydrosulfit (NaHSO~3~) — tạo hợp chất bisulfit

=> CH~3~–CHO + NaHSO~3~ → CH~3~–CH(OH)–SO~3~Na

- Sản phẩm là **chất kết tinh**, dễ tách ra khỏi hỗn hợp.
- Đun với **acid loãng** (hoặc kiềm), hợp chất bisulfit phân hủy, giải phóng lại aldehyd ban đầu:

=> CH~3~–CH(OH)–SO~3~Na + HCl → CH~3~–CHO + SO~2~↑ + H~2~O + NaCl

- Ứng dụng: **tách aldehyd ra khỏi hỗn hợp và tinh chế aldehyd** (Giáo trình tr. 168).
- Ceton cộng kém hơn. Theo giáo trình, **chỉ methyl ceton** CH~3~–CO–R cộng được NaHSO~3~; ceton có hai gốc từ C~2~H~5~ trở lên và **ceton thơm** thì không cộng được (vì án ngữ không gian).

#### b) Cộng HCN — tạo cyanohydrin

=> CH~3~–CHO + HCN → CH~3~–CH(OH)–CN

=> CH~3~–CO–CH~3~ + HCN → (CH~3~)~2~C(OH)–CN

Hai sản phẩm lần lượt là cyanohydrin của acetaldehyd và của aceton. Cần môi trường **kiềm** để tạo CN^−^, chính ion này mới là nucleophil. Cyanohydrin dễ **thủy phân** (acid hoặc kiềm) thành **acid α-hydroxy**:

=> CH~3~–CH(OH)–CN + 2 H~2~O + H^+^ → CH~3~–CH(OH)–COOH + NH~4~^+^

Sản phẩm là **acid lactic** (acid 2-hydroxypropanoic). Phản ứng cộng HCN **làm mạch carbon dài thêm 1C**.

> [!vi-du] Cyanohydrin trong dược liệu
> Glycosid sinh cyanid (amygdalin của Khổ hạnh nhân, Đào nhân) chứa phần **cyanohydrin của benzaldehyd** (mandelonitril). Khi bị thủy phân, nó giải phóng **benzaldehyd** (mùi hạnh nhân) và **HCN** độc. Chi tiết và lưu ý bào chế đã có ở bài *Phản ứng của hợp chất hữu cơ* (hc-04) (mục A~N~) và bài Glucid (mục glycosid).

#### c) Cộng alcol — hemiacetal và acetal

Một phân tử aldehyd (hoặc ceton) cộng **một phân tử alcol** (có xúc tác) tạo **hemiacetal** (giáo trình gọi là *semi acetal*; từ ceton gọi là *semi cetal*):

=> CH~3~–CHO + C~2~H~5~OH ⇌ CH~3~–CH(OH)–OC~2~H~5~

Nhóm –OH của hemiacetal **hoạt động hơn** –OH alcol thường. Với xúc tác acid, nó phản ứng tiếp với **phân tử alcol thứ hai** (tách nước) tạo **acetal**:

=> CH~3~CH(OH)OC~2~H~5~ + C~2~H~5~OH ⇌ CH~3~CH(OC~2~H~5~)~2~ + H~2~O

| | Hemiacetal | Acetal |
|---|---|---|
| C cũ của nhóm C=O mang | 1 –OH + 1 –OR | 2 –OR |
| Độ bền | **Kém bền**, dễ trở về aldehyd + alcol | **Bền** (trong môi trường trung tính, kiềm) |
| Thủy phân | Tự phân ly ngược | Bị thủy phân bởi **acid vô cơ** → aldehyd ban đầu |
| Đặc điểm khác | | Chất lỏng, ít tan trong nước, **mùi thơm dễ chịu**, sinh ra trong **rượu để lâu năm** |

- Vì acetal bền với kiềm nhưng dễ "mở" bằng acid, người ta chuyển C=O thành acetal để **bảo vệ nhóm carbonyl** trong tổng hợp hữu cơ, sau đó thủy phân bằng acid để lấy lại.
- **Hemiacetal nội** (*semiacetal nội*): khi –OH và –CHO nằm **trong cùng một phân tử** (như glucose) thì phản ứng xảy ra trong phân tử, khép thành vòng. Acetal tương ứng ở đường chính là **glycosid** (xem bài Glucid).

> [!bay] Thuật ngữ trong đề thi (Tự lượng giá 8.4)
> - **Semiacetal, semicetal** = sản phẩm cộng **1 phân tử alcol** vào aldehyd, ceton.
> - **Semiacetal nội, semicetal nội** = sản phẩm cộng giữa –OH và C=O **trong cùng một phân tử**.
> - "Semi-" = "hemi-" = "bán-": semiacetal, hemiacetal, bán acetal là một.

#### d) Cộng hydro

=> CH~3~–CHO + H~2~ →(Pt, Ni) CH~3~–CH~2~–OH

=> CH~3~–CO–CH~3~ + H~2~ →(Pt, Ni) CH~3~–CH(OH)–CH~3~

Aldehyd cho **alcol bậc I**; ceton cho **alcol bậc II** (aceton → propan-2-ol).

Có thể dùng "H mới sinh" hoặc khí H~2~ với xúc tác Pt, Ni. Xem thêm mục 5.4 (phản ứng khử bằng hydrid).

#### e) Cộng hợp chất cơ magnesi (thuốc thử Grignard)

R–MgBr cộng vào C=O (gốc R gắn vào C, –MgBr gắn vào O), sau đó **thủy phân** cho alcol. Bậc của alcol phụ thuộc vào chất carbonyl ban đầu (Giáo trình tr. 170):

| Chất carbonyl | Sản phẩm sau thủy phân | Ví dụ |
|---|---|---|
| **HCHO** | Alcol **bậc I** R–CH~2~OH | HCHO + C~3~H~7~MgBr → **butan-1-ol** |
| **Aldehyd khác** R′CHO | Alcol **bậc II** | Pentanal + C~2~H~5~MgBr → **heptan-3-ol** |
| **Ceton** | Alcol **bậc III** | Aceton + RMgBr → R–C(OH)(CH~3~)~2~ |

=> R–MgBr + HCHO → R–CH~2~–OMgBr

=> R–CH~2~–OMgBr + H~2~O → R–CH~2~–OH + Mg(OH)Br

Cách tạo thuốc thử Grignard và vì sao phải dùng ether khan: xem bài Dẫn xuất halogen.

#### f) So sánh khả năng cộng nucleophil: aldehyd > ceton

Giáo trình nêu **hai nguyên nhân** (tr. 170):

1. **Hiệu ứng cảm ứng dương (+I) của gốc alkyl.** Ceton có **hai** gốc alkyl đẩy electron về C của C=O, làm δ+ ở C **nhỏ hơn** so với aldehyd (chỉ một gốc). Nucleophil khó tấn công hơn.
2. **Án ngữ không gian.** Gốc càng lớn, càng cồng kềnh (isopropyl –CH(CH~3~)~2~, tert-butyl –C(CH~3~)~3~, nhân thơm…) càng che chắn C=O, nucleophil càng khó tiếp cận.

Ngược lại, nhóm **hút electron (−I)** như –CCl~3~ làm C=O **dương hơn**, nên cộng **dễ hơn**.

> [!vi-du] Tự lượng giá 8.5 — xếp theo khả năng cộng nucleophil tăng dần (đáp án tr. 256)
> **diisopropyl ceton < diethyl ceton < aceton < acetaldehyd < cloral (CCl~3~CHO)**
> - Ba ceton: gốc càng lớn, càng cồng kềnh → càng khó (isopropyl > ethyl > methyl).
> - Acetaldehyd chỉ có một gốc CH~3~ → dễ hơn ceton.
> - Cloral: nhóm CCl~3~ hút electron mạnh (−I của 3 Cl) → C=O dương nhất → dễ nhất.

### 5.3. Phản ứng thế O của nhóm carbonyl với hợp chất X–NH~2~

Nhóm C=O phản ứng với các chất dạng **H~2~N–X**: nguyên tử O được thay bằng =N–X, đồng thời **tách một phân tử nước** (Giáo trình tr. 170–171). Thực chất là cộng nucleophil (N có cặp e tự do tấn công C^δ+^) rồi tách nước.

=> R(R′)C=O + H~2~N–X → R(R′)C=N–X + H~2~O

X có thể là gốc alkyl/aryl, –OH (hydroxyl), –NH–C~6~H~5~ (anilino), –NH–CO–NH~2~ (ureido).

| Thuốc thử | Sản phẩm | Ví dụ |
|---|---|---|
| **Hydroxylamin** H~2~N–OH | **Oxim** (aldoxim, cetoxim) | Acetaldehyd → aldoxim; aceton → acetoxim |
| **Phenylhydrazin** H~2~N–NH–C~6~H~5~ | **Phenylhydrazon** | Benzaldehyd, acetophenon → phenylhydrazon tương ứng |

=> CH~3~CHO + H~2~N–OH → CH~3~–CH=N–OH + H~2~O

=> (CH~3~)~2~C=O + H~2~N–OH → (CH~3~)~2~C=N–OH + H~2~O

=> C~6~H~5~CHO + H~2~N–NHC~6~H~5~ → C~6~H~5~CH=N–NHC~6~H~5~ + H~2~O

- Các **oxim** là chất **kết tinh, không tan trong nước** → dùng để **tách aldehyd** ra khỏi hỗn hợp. Phenylhydrazon cũng kết tinh, có nhiệt độ nóng chảy xác định, dùng để **nhận biết**.
- Với đường, phenylhydrazin dư tạo **osazon** (xem bài Glucid).

> [!ung-dung] Base Schiff trong cơ thể
> Khi X là gốc hydrocarbon (amin bậc I), sản phẩm C=N–R gọi là **imin (base Schiff)**. Cơ thể dùng phản ứng này rất nhiều: **retinal** (aldehyd của vitamin A) gắn vào protein opsin của tế bào que qua liên kết imin để tạo **rhodopsin**, sắc tố thị giác; thiếu vitamin A gây **quáng gà**. Pyridoxal phosphat (vitamin B~6~) cũng gắn với amino acid (acid amin) theo cách này.

### 5.4. Phản ứng oxy hóa và phản ứng khử

#### a) Oxy hóa — điểm khác biệt lớn nhất giữa aldehyd và ceton

Aldehyd là **chất khử mạnh**: bị oxy hóa ngay cả bởi oxy không khí và các chất oxy hóa **yếu**, tạo acid carboxylic tương ứng (Giáo trình tr. 171–172):

=> R–CHO + [O] → R–COOH

**Phản ứng tráng gương (thuốc thử Tollens, AgNO~3~/NH~3~):**

=> RCHO + 2[Ag(NH~3~)~2~]OH →(t°) RCOONH~4~ + 2Ag↓ + 3NH~3~ + H~2~O

Viết gọn theo giáo trình:

=> R–CHO + Ag~2~O →(NH~3~) R–COOH + 2Ag↓

Đun nhẹ trong ống nghiệm sạch, bạc bám lên thành ống **sáng như gương**.

**Phản ứng với Cu(OH)~2~ khi đun nóng (thuốc thử Fehling là dạng phức của Cu^2+^ trong kiềm):**

=> R–CHO + 2Cu(OH)~2~ →(t°) R–COOH + Cu~2~O↓ + 2H~2~O

Kết tủa Cu(OH)~2~ **xanh** bị khử đến CuOH **vàng**, rồi CuOH bị nhiệt phân thành Cu~2~O **đỏ gạch**:

=> 2CuOH → Cu~2~O + H~2~O

> [!bay]
> - **Ceton không** tráng bạc, **không** khử Cu(OH)~2~. Đây là phép **phân biệt aldehyd với ceton** (Tự lượng giá 8.3, 8.7).
> - Với chất oxy hóa **mạnh** (KMnO~4~, hỗn hợp sulfocromic K~2~Cr~2~O~7~/H~2~SO~4~, HNO~3~) thì **cả hai** đều bị oxy hóa. Aldehyd cho **một acid cùng số C**; ceton bị **cắt mạch C** ở hai bên nhóm C=O, cho hỗn hợp acid **ít C hơn**.
> - **HCHO** có thể coi như có **hai nhóm –CHO** (H–CHO), nên 1 mol HCHO tạo được tới **4 mol Ag** (sản phẩm cuối là CO~2~, trong NH~3~ là (NH~4~)~2~CO~3~).
> - Lưu ý thêm (ngoài sách): aldehyd **thơm** (benzaldehyd) tráng bạc được nhưng **thường không** khử thuốc thử Fehling. Còn **fructose** là ceton nhưng **vẫn** khử được Tollens, Fehling, vì trong kiềm nó chuyển hóa một phần thành aldose.
> - Giáo trình viết phương trình với Cu(OH)~2~ theo tỉ lệ 1 : 1. Viết **cân bằng** phải là 2 Cu(OH)~2~ cho 1 Cu~2~O, như trên.

**Oxy hóa ceton bằng chất oxy hóa mạnh** — ví dụ pentan-2-on CH~3~–CO–C~3~H~7~ bị cắt ở bên này hoặc bên kia nhóm C=O, cho hỗn hợp hai cặp acid:

=> Cắt phía CH~3~: HCOOH + C~3~H~7~COOH

=> Cắt phía C~3~H~7~: CH~3~COOH + C~2~H~5~COOH

Phân tích các acid tạo thành giúp **xác định vị trí nhóm C=O** trong phân tử. Ceton vòng cho **acid dicarboxylic**:

=> cyclohexanon →[O] HOOC–(CH~2~)~4~–COOH (acid adipic)

> [!vi-du] Tự lượng giá 8.9 — chất oxy hóa yếu và mạnh (đáp án tr. 256)
> Ba chất đầu đều có vòng **cyclohexan** (no).
> - 4-hydroxycyclohexan-1-carbaldehyd + Ag~2~O → chỉ –CHO bị oxy hóa: **acid 4-hydroxycyclohexan-1-carboxylic** + 2 Ag. Nhóm –OH alcol bậc II **không** bị Ag~2~O oxy hóa.
> - Cùng chất đó + K~2~Cr~2~O~7~/H~2~SO~4~ (mạnh) → –CHO thành –COOH **và** –OH bậc II thành C=O: **acid 4-oxocyclohexan-1-carboxylic** (đáp án sách ghi "4-oxy", đúng ra là **4-oxo**).
> - 4-oxocyclohexan-1-carbaldehyd + [Ag(NH~3~)~2~]OH → chỉ –CHO bị oxy hóa, C=O ceton giữ nguyên: cũng cho **acid 4-oxocyclohexan-1-carboxylic** + 2 Ag.

#### b) Phản ứng khử bằng hydrid kim loại

Các chất khử mạnh **LiAlH~4~** (liti nhôm hydrid) và **NaBH~4~** (natri borohydrid) khử aldehyd thành **alcol bậc I**, ceton thành **alcol bậc II** (Giáo trình tr. 172–173):

=> CH~3~CH=CHCHO →(LiAlH~4~; H^+^) CH~3~CH=CHCH~2~OH

=> CH~3~COC~2~H~5~ →(NaBH~4~; H^+^) CH~3~CH(OH)C~2~H~5~

Phương trình thứ nhất: but-2-enal → but-2-en-1-ol (nối đôi C=C giữ nguyên). Phương trình thứ hai: butan-2-on → butan-2-ol.

> [!bay] Khử bằng hydrid khác khử bằng H~2~/xúc tác
> - **Hydrid kim loại** (LiAlH~4~, NaBH~4~) **chỉ khử C=O**, giữ nguyên C=C. Lý do: hydrid cung cấp H^−^ là một nucleophil, chỉ tấn công C^δ+^ của nhóm C=O phân cực, còn C=C không phân cực.
> - **H~2~ + Pt, Ni** khử **cả C=O lẫn C=C**, ví dụ acrolein thành propan-1-ol:
>
> => CH~2~=CH–CHO + 2H~2~ →(Ni) CH~3~CH~2~CH~2~OH

### 5.5. Phản ứng thế H ở C~α~

C~α~ là carbon **ngay cạnh** nhóm C=O. Nhóm C=O hút electron làm các H ở C~α~ trở nên **linh động** (dễ tách ra dưới dạng H^+^). Vì vậy một hay tất cả các H~α~ có thể bị thay bằng halogen (Giáo trình tr. 173–174).

=> CH~3~–CHO + 3Cl~2~ → CCl~3~–CHO + 3HCl

Sản phẩm là **cloral** (tricloroacetaldehyd).

Cloral cộng nước tạo **cloral hydrat** kết tinh, bền — một **thuốc an thần, gây ngủ**:

=> CCl~3~–CHO + H~2~O → CCl~3~–CH(OH)~2~

> [!bay] Vì sao cloral hydrat bền, trong khi "hai –OH trên một C" thường không bền?
> Thông thường gem-diol R–CH(OH)~2~ tự tách nước trở lại thành aldehyd. Ở cloral, nhóm CCl~3~ **hút electron rất mạnh** làm C=O cực kỳ dương, nên cân bằng cộng nước lệch hẳn về phía hydrat. Đây cũng là lý do cloral đứng **đầu** dãy khả năng cộng nucleophil (Tự lượng giá 8.5).
> *Lưu ý: giáo trình in phương trình cộng nước kèm "+ 3HCl" ở vế phải. Đó là lỗi in: phản ứng cộng nước không sinh ra HCl.*

Ceton cũng bị thế H~α~ (xúc tác acid). Ví dụ butanon + Br~2~ cho dẫn xuất mono-, rồi di-, tri-brom ở C~α~. Các **α-halogen ceton** (như bromoaceton) gây **chảy nước mắt** mạnh; từng được dùng làm vũ khí hóa học trong Chiến tranh thế giới thứ nhất.

**Phản ứng iodoform** (mở rộng — hay dùng để nhận biết): chất có nhóm **CH~3~–CO–** (aceton, methyl ceton, acetaldehyd) gặp I~2~ trong NaOH: cả 3 H của nhóm CH~3~ bị thế bởi I, rồi mạch bị cắt, tạo **kết tủa vàng CHI~3~** mùi đặc trưng:

=> CH~3~COR + 3I~2~ + 4NaOH → CHI~3~↓ + RCOONa + 3NaI + 3H~2~O

Ethanol và propan-2-ol cũng cho phản ứng này, vì I~2~/NaOH oxy hóa chúng thành CH~3~CHO và aceton trước. **Methanol, HCHO không** cho phản ứng (không có nhóm CH~3~–CO–).

### 5.6. Phản ứng ngưng tụ aldol

Trong kiềm **loãng** hoặc kiềm yếu (natri acetat, natri carbonat…), hai phân tử aldehyd hoặc ceton **có H ở C~α~** cộng hợp với nhau. **C~α~ của phân tử này gắn vào C của nhóm C=O của phân tử kia**, H~α~ chuyển sang O (Giáo trình tr. 174).

![Hình 3. Ngưng tụ aldol: tạo liên kết C–C mới giữa C~α~ và C của nhóm carbonyl](aldol.svg)

=> 2CH~3~CHO →(OH^−^ loãng) CH~3~–CH(OH)–CH~2~–CHO

Sản phẩm là **aldol** (3-hydroxybutanal). Tên "aldol" = **ald**ehyd + alc**ol**, vì sản phẩm vừa có –CHO vừa có –OH. Đun nóng, aldol dễ **tách nước** thành aldehyd không no CH~3~–CH=CH–CHO (but-2-enal); vì có tách nước nên gọi là **ngưng tụ**.

Ceton có H~α~ cũng ngưng tụ kiểu aldol. Ví dụ trong Ba(OH)~2~, hai phân tử aceton cho **cetaldol** (ceton–alcol):

=> 2CH~3~COCH~3~ →(Ba(OH)~2~) (CH~3~)~2~C(OH)–CH~2~–CO–CH~3~

Tên IUPAC của cetaldol này: 4-hydroxy-4-methylpentan-2-on.

**Vì sao cần H~α~?** Base tách H^+^ ở C~α~, tạo carbanion (ion enolat). Carbanion này là một **nucleophil** và tấn công C^δ+^ của phân tử thứ hai, tức là lại một phản ứng A~N~. HCHO và benzaldehyd **không có H~α~** nên không tự ngưng tụ được, nhưng vẫn có thể làm "phân tử nhận" cho chất khác.

> [!ung-dung] Aldol trong cơ thể
> Phản ứng aldol là một cách quan trọng để **tạo liên kết C–C**. Trong đường phân, enzym **aldolase** cắt fructose-1,6-bisphosphat (6C) thành hai triose phosphat (3C): đó chính là phản ứng **aldol nghịch**. Khi tân tạo glucose, aldolase xúc tác chiều thuận để ghép hai triose lại.

### 5.7. Phản ứng với thuốc thử Schiff

**Thuốc thử Schiff** (acid fuchsin sulfurơ) là dung dịch **fuchsin đã bị SO~2~ làm mất màu**. Aldehyd tác dụng với nó tạo hợp chất màu **đỏ tím (hồng tím)**. Phản ứng dùng để **định tính và định lượng aldehyd** (Giáo trình tr. 174).

Các ceton **không** phản ứng; **riêng aceton** có phản ứng nhưng **rất chậm**.

> [!ung-dung] Thuốc thử Schiff trong giải phẫu bệnh
> Hai kỹ thuật nhuộm kinh điển dựa trên việc "tạo ra" nhóm –CHO rồi cho phản ứng với Schiff:
> - **Nhuộm PAS** (periodic acid–Schiff): acid periodic cắt các cặp –OH kề nhau của glucid thành –CHO → **glycogen, chất nhầy, màng đáy** bắt màu đỏ tím. Dùng chẩn đoán bệnh ứ glycogen, nấm, một số u.
> - **Nhuộm Feulgen**: thủy phân nhẹ DNA (ADN) bằng HCl làm lộ nhóm –CHO của **deoxyribose** → nhân tế bào bắt màu đỏ tím, dùng định lượng DNA.

### 5.8. Một số phản ứng riêng

**Aldehyd, ceton không no** có thêm phản ứng của C=C. Ví dụ acrolein cộng HBr:

=> CH~2~=CH–CHO + HBr → Br–CH~2~–CH~2~–CHO

Sản phẩm (3-bromopropanal) **trái quy tắc Markovnikov**. Lý do: nhóm C=O hút electron làm liên kết π của C=C bị phân cực về phía nhóm carbonyl. H^+^ gắn vào **O** của nhóm C=O, Br^−^ gắn vào C đầu mạch, tạo **enol** CH~2~Br–CH=CH–OH. Enol không bền (–OH gắn vào C có liên kết đôi), nên chuyển ngay thành aldehyd (Giáo trình tr. 175). *Giáo trình in vế phải "+ 3HCl" là lỗi in.*

**Aldehyd, ceton thơm** có phản ứng thế vào nhân thơm. –CHO và –CO– là nhóm **hút electron**, làm giảm mật độ electron của vòng, nhất là ở vị trí ortho và para. Vì vậy nhóm thế mới vào **vị trí meta**, và phản ứng **khó hơn** so với benzen:

=> C~6~H~5~CHO + HNO~3~ →(H~2~SO~4~) m-O~2~NC~6~H~4~CHO + H~2~O

Tương tự, acetophenon cho m-nitroacetophenon (giáo trình in nhầm là "aceto phenol").

## 6. Điều chế

### 6.1. Oxy hóa alcol

- Alcol **bậc I** → **aldehyd**; alcol **bậc II** → **ceton**. Chất oxy hóa: hỗn hợp **sulfocromic**, hoặc **oxy không khí** với xúc tác (đồng, platin ở nhiệt độ cao) (Giáo trình tr. 176).

=> CH~3~–CH~2~–OH + [O] → CH~3~–CHO + H~2~O

=> CH~3~–CH(OH)–CH~3~ + [O] → CH~3~–CO–CH~3~ + H~2~O

=> 2CH~3~OH + O~2~ →(Cu/Ag, t°) 2HCHO + 2H~2~O

Đây là cách sản xuất formaldehyd trong công nghiệp.

Giáo trình giải thích: C mang –OH bị oxy hóa tạm thành gem-diol (hai –OH trên một C), gem-diol không bền nên tách nước ngay thành C=O.

> [!bay] Tự lượng giá 8.8 — "oxy hóa alcol nào để thu được…?" (đáp án tr. 256)
> - **2-methylpropanal** (CH~3~)~2~CH–CHO ← alcol bậc I **2-methylpropan-1-ol** (CH~3~)~2~CH–CH~2~OH.
> - **4-tert-butylcyclohexanon** ← alcol bậc II **4-tert-butylcyclohexan-1-ol**.
> - Khi oxy hóa alcol bậc I bằng chất oxy hóa mạnh, aldehyd dễ bị **oxy hóa tiếp thành acid**. Muốn dừng ở aldehyd phải dùng chất oxy hóa nhẹ, hoặc chưng cất aldehyd ra ngay khi vừa tạo thành (aldehyd sôi thấp hơn alcol). Alcol **bậc III không** bị oxy hóa thành aldehyd hay ceton.

### 6.2. Thủy phân dẫn xuất gem-dihalogen

Dẫn xuất **gem-dihalogen** có **hai nguyên tử halogen gắn trên cùng một C**. Khi thủy phân, nó tạo gem-diol; gem-diol không bền, tách nước thành aldehyd (nếu hai halogen ở C đầu mạch) hoặc ceton (nếu ở C giữa mạch):

=> CH~3~–CHCl~2~ + 2 NaOH → CH~3~–CHO + 2 NaCl + H~2~O

=> CH~3~–CCl~2~–CH~3~ + 2 NaOH → CH~3~–CO–CH~3~ + 2 NaCl + H~2~O

### 6.3. Điều chế ceton thơm bằng phản ứng Friedel–Crafts

Cho **clorid acid** hoặc **anhydrid acid** tác dụng với hydrocarbon thơm, xúc tác **AlCl~3~** khan (phản ứng acyl hóa):

=> C~6~H~6~ + CH~3~COCl →(AlCl~3~) C~6~H~5~COCH~3~ + HCl

=> C~6~H~6~ + (CH~3~CO)~2~O →(AlCl~3~) C~6~H~5~COCH~3~ + CH~3~COOH

> [!bay]
> Sản phẩm trên là **acetophenon** (methyl phenyl ceton) C~6~H~5~–CO–CH~3~. Giáo trình gọi nó là "phenyl aceton", nhưng tên đó đúng ra chỉ chất C~6~H~5~–CH~2~–CO–CH~3~ (1-phenylpropan-2-on, xem bài Danh pháp). Hai chất này **khác nhau**.

## 7. Ứng dụng và ý nghĩa y học

### 7.1. Aldehyd formic (formaldehyd, HCHO)

- Là chất khí, mùi xốc. Dung dịch nước khoảng 37–40% gọi là **formalin** hay **formol** (giáo trình ghi 40%). Đây là chất **sát trùng mạnh**, dùng tiệt trùng dụng cụ (Giáo trình tr. 176–177).
- **Cơ chế**: HCHO phản ứng với nhóm **–NH~2~ của protein**, tạo các cầu nối giữa các phân tử protein. Protein **đông cứng lại**, không tan, không bị vi khuẩn phân hủy (không thối). Vì vậy formol được dùng **ngâm xác, bảo quản phủ tạng mẫu**, **cố định bệnh phẩm** (mẫu sinh thiết ngâm formol 10% trước khi làm giải phẫu bệnh), và thuộc da.
- Cũng chính phản ứng này làm formol **độc**: nó làm bất hoạt hệ thống **enzym**. Hơi formaldehyd làm **cay mắt, mũi**, gây chảy máu mũi, xạm da.
- Trong công nghiệp, HCHO dùng tổng hợp phẩm nhuộm, nhựa, cao su và thuốc sát khuẩn đường tiết niệu **urotropin** (hexamethylentetramin, methenamin). Vào nước tiểu acid, urotropin bị thủy phân giải phóng HCHO diệt khuẩn:

=> (CH~2~)~6~N~4~ + 6 H~2~O → 6 HCHO + 4 NH~3~

> [!cap-nhat] Formaldehyd gây ung thư — cấm dùng cho thực phẩm
> Giáo trình chỉ nêu độc tính kích ứng. Hiện nay **IARC** (Cơ quan Nghiên cứu Ung thư Quốc tế) xếp formaldehyd vào **nhóm 1: chắc chắn gây ung thư ở người** (ung thư vòm họng, bệnh bạch cầu). Do đó:
> - Phòng giải phẫu, phòng xét nghiệm phải **thông khí tốt**, dùng tủ hút, găng tay, kính bảo hộ.
> - Formol **không phải phụ gia thực phẩm** và bị **cấm** dùng để bảo quản thực phẩm (bánh phở, bún, hải sản…) ở Việt Nam.
> - Methenamin (urotropin) dạng **hippurat** hiện vẫn được dùng ở một số nước để **dự phòng** nhiễm khuẩn tiết niệu tái phát; thuốc chỉ có tác dụng khi nước tiểu **acid**.

> [!ung-dung] Ngộ độc methanol: "thủ phạm" là formaldehyd và acid formic
> Methanol (có trong rượu pha chế không rõ nguồn gốc) bản thân ít độc. Trong gan, enzym **alcol dehydrogenase** oxy hóa nó thành **formaldehyd**, rồi thành **acid formic**. Acid formic gây **toan chuyển hóa nặng** và tổn thương **thần kinh thị giác** (mờ mắt, mù vĩnh viễn), có thể tử vong. Triệu chứng thường xuất hiện **chậm** sau 12–24 giờ. Điều trị đặc hiệu là **ức chế alcol dehydrogenase** bằng fomepizol hoặc ethanol (để methanol không bị chuyển hóa), kết hợp lọc máu. Đây là chuỗi phản ứng "alcol bậc I → aldehyd → acid" của bài này xảy ra ngay trong cơ thể. Với ethanol cũng vậy: ethanol → **acetaldehyd** (gây đỏ mặt, nhức đầu, buồn nôn) → acid acetic.

### 7.2. Aldehyd acetic và cloral hydrat

Aldehyd acetic là chất lỏng, dùng điều chế **cloral hydrat** CCl~3~CH(OH)~2~, một thuốc **an thần, gây ngủ** (Giáo trình tr. 177).

> [!cap-nhat] Cloral hydrat ngày nay
> Cloral hydrat là một trong những thuốc ngủ tổng hợp đầu tiên. Do **khoảng an toàn hẹp** (quá liều gây loạn nhịp tim, ức chế hô hấp), kích ứng dạ dày và dễ gây lệ thuộc, nay **ít dùng**; làm thuốc ngủ đã được thay bằng các thuốc an toàn hơn. Ở một số nơi, nó còn được dùng để **an thần ngắn cho trẻ em** khi làm thủ thuật, ghi điện não, chụp chiếu; nhiều nước đã hạn chế hoặc ngừng lưu hành. Khi thi, trả lời theo giáo trình: cloral hydrat là thuốc an thần.

### 7.3. Aldehyd thơm

Aldehyd thơm có trong thiên nhiên ở dạng tự do hoặc hợp chất trong thực vật, động vật, thu được bằng cách chiết xuất: **benzaldehyd** (dầu hạnh nhân), **cinnamaldehyd** (dầu quế), aldehyd lily (hoa loa kèn), **vanilin** (hạt vani) (Giáo trình tr. 177). Benzaldehyd còn có trong lá, hạt đào, mơ, mận dưới dạng glycosid **amygdalin**; khi đun với acid loãng hoặc dưới tác dụng của enzym, amygdalin thủy phân cho glucose, benzaldehyd và HCN.

Nhóm chức aldehyd cũng là nhóm chức cơ bản của **glucid** (aldose); nhóm ceton có trong cetose, các **cetoacid** (acid pyruvic, acid oxaloacetic) và nhiều hormon steroid (progesteron, testosteron, cortisol).

### 7.4. Aceton và thể ceton

**Aceton** CH~3~COCH~3~ là chất lỏng mùi đặc biệt, **tan vô hạn trong nước**, là dung môi tốt (tơ nhân tạo, thuốc nổ, dược phẩm, sơn móng tay). Hơi aceton gây nhiễm độc cho người **tiếp xúc thường xuyên** (Giáo trình tr. 177–178).

Aceton có trong **nước tiểu người bệnh đái tháo đường**. Khi thiếu insulin, tế bào không dùng được glucose, cơ thể tăng phân giải mỡ; gan tạo nhiều **acid acetoacetic**. Acid này là một **β-cetoacid** nên dễ tự **khử carboxyl**:

=> CH~3~–CO–CH~2~–COOH → CH~3~–CO–CH~3~ + CO~2~

*(Giáo trình viết phương trình này không ghi CO~2~; viết đầy đủ phải có CO~2~.)*

> [!ung-dung] Nhiễm toan ceton do đái tháo đường
> - **"Thể ceton"** gồm 3 chất: **acid acetoacetic**, **acid β-hydroxybutyric** và **aceton**. Hai acid làm máu bị **toan hóa**: bệnh nhân thở nhanh, sâu (kiểu Kussmaul), nôn, mất nước, có thể hôn mê.
> - **Aceton** bay hơi qua phổi, làm hơi thở có **mùi táo chín (mùi trái cây)**: một dấu hiệu lâm sàng gợi ý.
> - Xét nghiệm ceton niệu bằng **que thử nitroprussiat** phát hiện chủ yếu **acetoacetat** (aceton phản ứng yếu) và **không** phát hiện β-hydroxybutyrat.

> [!bay]
> **Acid β-hydroxybutyric** được gọi là "thể ceton" nhưng về cấu tạo **không phải ceton** (nó có –OH và –COOH, không có C=O ceton). Trong nhiễm toan ceton nặng, β-hydroxybutyrat lại chiếm **đa số**. Vì vậy que thử nước tiểu có thể cho kết quả **thấp hơn thực tế**; hiện nay ưu tiên đo **β-hydroxybutyrat trong máu**.

### 7.5. Ceton thơm trong tự nhiên

Nhiều ceton có mùi thơm trong thực vật hay tuyến động vật: **menthon** (tinh dầu bạc hà), **jasmon** (tinh dầu hoa nhài), **campho** (tinh dầu long não), **muscon** (xạ hương của hươu xạ). Giáo trình nhận xét chúng đều là những **dược liệu quý** (tr. 178).

> [!bay] Hình menthon trong giáo trình
> Giáo trình (tr. 128 và tr. 178) vẽ menthon có thêm **liên kết đôi C=C** ở nhóm isopropyl. Menthon thật là **p-menthan-3-on** C~10~H~18~O: vòng **no**, chỉ có một nhóm C=O, không có C=C. Chất vẽ như sách gần với **pulegon** (cũng là ceton của tinh dầu họ Bạc hà nhưng có C=C). Khi thi, nhớ menthon là **ceton vòng no**, khử cho **menthol**.

> [!yhct] Aldehyd, ceton trong tinh dầu — đọc tính chất bào chế từ phản ứng
> Tên IUPAC và công thức của citral, cinnamaldehyd, vanilin, long não đã có ở bài **Danh pháp hóa học hữu cơ** (hc-02, mục 6, bảng hoạt chất dược liệu). Ở đây chỉ nêu các phản ứng của bài này áp dụng cho chúng.
> - **Cinnamaldehyd** (thành phần chủ yếu của tinh dầu **Quế**) và **citral** (thành phần chủ yếu của tinh dầu **Sả chanh**, *Cymbopogon citratus*) là **aldehyd**: dễ bị **oxy không khí oxy hóa** thành acid (cinnamaldehyd → acid cinnamic). Đây là cơ sở hóa học của yêu cầu **đựng kín, tránh ánh sáng** và vì sao tinh dầu, dược liệu để lâu **giảm mùi thơm**. Cả hai đều cho phản ứng tráng bạc và hợp chất bisulfit; phản ứng bisulfit từng được dùng để **tách citral** ra khỏi tinh dầu.
> - Ngược lại, aldol có thể **tổng hợp** các chất này: benzaldehyd + acetaldehyd → cinnamaldehyd; citral + aceton → pseudoionon → ionon (hương liệu, nguyên liệu tổng hợp vitamin A) (Hình 3).
> - **Menthon** (ceton, có trong tinh dầu **Bạc hà** cùng menthol) khi bị **khử** cho **menthol** (alcol bậc II): đúng quy tắc "ceton + H~2~ → alcol bậc II". Trong cây cũng có enzym chuyển menthon thành menthol.
> - **Long não** (campho, ceton) khi bị khử cho **borneol** (alcol bậc II) lẫn isoborneol. Vị thuốc **Băng phiến** (Borneolum) chính là borneol. Băng phiến tổng hợp được điều chế từ long não hoặc từ tinh dầu thông.
> - **Vanilin** vừa có –CHO (tráng bạc) vừa có –OH phenol. Nó chủ yếu được dùng làm **chất điều hương** trong thuốc và thực phẩm, không phải vị thuốc YHCT.
>
> **Thận trọng:** trong dân gian, "băng phiến" còn chỉ **viên long não chống gián**. Thứ này thường là **naphthalen** (hydrocarbon thơm), rất độc nếu nuốt (gây tan máu, nhất là ở trẻ thiếu men G6PD), **hoàn toàn khác** vị thuốc Băng phiến. Long não và tinh dầu giàu ceton dùng ngoài là chính (xem cảnh báo co giật ở trẻ nhỏ trong bài *Danh pháp hóa học hữu cơ*, mã hc-02). Tác dụng sinh học của các tinh dầu này chủ yếu được chứng minh trên **thực nghiệm**.

## Tóm tắt

| Nội dung | Aldehyd R–CHO | Ceton R–CO–R′ |
|---|---|---|
| Tên IUPAC | …**al** (C của –CHO là C1); vòng + **carbaldehyd** | Số chỉ vị trí + …**on** |
| Tên thông thường | Aldehyd + tên acid (aldehyd acetic) | Tên các gốc + ceton (dimethyl ceton) |
| Liên kết hydro giữa các phân tử | Không → sôi thấp hơn alcol, cao hơn hydrocarbon | Như aldehyd |
| Cộng A~N~ (HCN, NaHSO~3~, ROH, H~2~, RMgX) | **Dễ** | Khó hơn (+I của 2 gốc, án ngữ không gian); NaHSO~3~: chỉ methyl ceton |
| + H~2~ / NaBH~4~ / LiAlH~4~ | Alcol **bậc I** | Alcol **bậc II** |
| + RMgX rồi H~2~O | HCHO → bậc I; RCHO → bậc II | Alcol **bậc III** |
| + H~2~N–X | Oxim, phenylhydrazon (kết tinh) | Cetoxim, phenylhydrazon |
| Tollens, Cu(OH)~2~/t° | **+** (Ag↓, Cu~2~O↓ đỏ gạch) | **−** |
| Thuốc thử Schiff | **+** (đỏ tím) | − (riêng aceton: rất chậm) |
| Chất oxy hóa mạnh | Acid cùng số C | Cắt mạch → hỗn hợp acid ít C hơn |
| Thế H~α~, aldol | Có (nếu có H~α~) | Có (nếu có H~α~) |
| Iodoform (I~2~/NaOH) | Chỉ CH~3~CHO | Methyl ceton (aceton…) |
| Điều chế | Oxy hóa alcol **bậc I**; thủy phân gem-dihalogen ở C đầu mạch | Oxy hóa alcol **bậc II**; gem-dihalogen giữa mạch; Friedel–Crafts (ceton thơm) |
| Y học | Formol (sát khuẩn, cố định mẫu, **độc, gây ung thư**); cloral hydrat (an thần); urotropin | Aceton: thể ceton trong **nhiễm toan ceton** đái tháo đường; menthon, campho trong tinh dầu |
