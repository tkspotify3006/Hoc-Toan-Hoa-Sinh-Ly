---
title: Các hợp chất dị vòng
thoi-gian: 35 phút
muc-tieu:
- Nêu được định nghĩa dị vòng, dị tố (dị tử) và cho ví dụ về các dạng dị vòng.
- Phân loại được dị vòng chứa nitơ theo dị tố, số cạnh, độ bão hòa, số vòng, số dị tố; gọi được tên theo danh pháp của giáo trình và tên thông thường.
- Trình bày được các phản ứng chính của dị vòng nitơ: thế, cộng, dehydro hóa và phản ứng thể hiện tính base.
- So sánh và giải thích được tính base của pyrrol, anilin, pyridin, NH~3~, piperidin, pyrrolidin.
- Kể được các base purin, pyrimidin của acid nucleic, một số alkaloid tiêu biểu và ý nghĩa y học của dị vòng.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Dị vòng = vòng có **nguyên tử khác carbon** (dị tử: N, O, S) nằm **ngay trong vòng**. Dị tử luôn được đánh **số 1**.
> 2. Dị vòng thơm (pyrrol, pyridin, pyrimidin…) có **phản ứng thế** giống benzen: **pyrrol thế rất dễ**, **pyridin thế rất khó** (N hút electron).
> 3. Hóa tính đặc trưng nhất của dị vòng nitơ là **tính base**, nhờ N còn **cặp electron chưa liên kết**.
> 4. Tính base tăng dần: **pyrrol < anilin < pyridin < NH~3~ < piperidin, pyrrolidin** (dị vòng no mạnh như amin béo).
> 5. Base **purin** (A, G) và **pyrimidin** (C, T, U) tạo nên acid nucleic; **alkaloid** đa số là dị vòng nitơ, có tác dụng dược lý mạnh (quinin, berberin…; ephedrin là alkaloid nhưng **không** có dị vòng).

## 1. Định nghĩa và phân loại

### 1.1. Định nghĩa

**Dị vòng** là hợp chất có mạch vòng (no hoặc không no), trong đó **ngoài carbon** còn có nguyên tử của nguyên tố khác tham gia **tạo vòng**, thường là **O, N, S**. Các nguyên tố này gọi là **dị tố**; từng nguyên tử của chúng trong vòng gọi là **dị tử** (Giáo trình tr. 234).

Ví dụ của giáo trình: pyrrol, furan, thiophen, pyridin, piperidin, purin.

> [!bay] Có N nhưng chưa chắc là dị vòng
> Điều kiện là dị tử phải **nằm trong vòng**. Anilin C~6~H~5~–NH~2~ có N nhưng N nằm **ngoài** vòng benzen, nên anilin là **amin thơm**, không phải dị vòng. Ephedrin cũng vậy (mục 7.2).

### 1.2. Phân loại

Giáo trình chia dị vòng theo năm tiêu chí (tr. 234–235):

| Tiêu chí | Các nhóm | Ví dụ |
|---|---|---|
| **Dị tố** | Chứa N / chứa O / chứa S | pyrrol, pyridin / furan / thiophen |
| **Số cạnh** | 5 cạnh / 6 cạnh / nhiều vòng | pyrrol, furan, thiophen / pyridin, piperidin / purin |
| **Độ bão hòa** | Không no (có nối đôi, đa số thơm) / no | pyridin, pyrrol / piperidin, pyrrolidin |
| **Số vòng** | Một vòng / nhiều vòng ngưng tụ | pyridin / purin, indol, quinolin, phenothiazin |
| **Số dị tố, dị tử** | 1 dị tử / 2 dị tử cùng loại / 2 dị tố khác nhau | pyridin / imidazol, pyrimidin / thiazol (S, N), oxazol (O, N), oxazin |

> [!bay] Giáo trình in nhầm ví dụ "no – không no"
> Ở tr. 235 sách viết "dị vòng no (ví dụ pyridin) và dị vòng không no (ví dụ piperidin)". Thực tế **ngược lại**: **pyridin** có 3 nối đôi liên hợp, là dị vòng **không no, thơm**; **piperidin** (C~5~H~11~N) là pyridin đã cộng đủ hydro, là dị vòng **no**. Bảng 24 của chính giáo trình cũng xếp piperidin và pyrrolidin vào cột "No".

![Hình 1. Các dị vòng một vòng cơ bản và cách đánh số nguyên tử](vong-don.svg)

**Bảng 24 của giáo trình** (dị vòng một vòng) có thể nhớ theo hai hàng:

- **5 cạnh, không no:** furan (O), thiophen (S), pyrrol (N); imidazol (2 N); oxazol (O + N); thiazol (S + N). **5 cạnh, no:** pyrrolidin.
- **6 cạnh, không no:** pyran (O), pyridin (N); pyrimidin (2 N); oxazin (O + N); thiazin (S + N). **6 cạnh, no:** piperidin.

**Dị vòng nhiều vòng ngưng tụ** (hai vòng dùng chung một cạnh):

![Hình 2. Các dị vòng ngưng tụ có đánh số: purin, indol, quinolin, isoquinolin](vong-ngung-tu.svg)

| Dị vòng | Ghép từ | Gặp ở đâu |
|---|---|---|
| **Purin** | pyrimidin + imidazol | Adenin, guanin, acid uric, cafein |
| **Indol** | benzen + pyrrol | Tryptophan, serotonin, strychnin, reserpin |
| **Quinolin** | benzen + pyridin (N ở vị trí 1) | Quinin, chloroquin |
| **Isoquinolin** *(ngoài sách)* | benzen + pyridin (N ở vị trí 2) | Berberin, morphin, papaverin |
| **Phenothiazin** | 2 vòng benzen + vòng 6 cạnh chứa S và N | Thuốc an thần kinh (chlorpromazin) |

Từ mục 2 trở đi, giáo trình chỉ xét **dị vòng chứa nitơ**.

## 2. Danh pháp

### 2.1. Danh pháp IUPAC (theo giáo trình)

Tên gồm hai phần (tr. 236):

- **Tên dị tử**: N đọc là **az**, O là **ox**, S là **thi**. Có 2 dị tử thì thêm **di-** và số chỉ vị trí.
- **Đuôi**: **-ol** nếu vòng **5 cạnh**, **-in** nếu vòng **6 cạnh**.

| Tên IUPAC (theo sách) | Tên thông thường |
|---|---|
| monoazol | pyrrol |
| 1,3-diazol | imidazol |
| monoazin | pyridin |
| 1,3-diazin | pyrimidin |
| 2-methyl monoazin | 2-methylpyridin |

**Cách đánh số:** dị tử nhận **số 1**, các số tiếp theo chọn sao cho dị tử thứ hai và nhóm thế có **chỉ số nhỏ nhất**. Khi có hai dị tử khác loại, ưu tiên **O > S > N** cho số 1. Vì vậy thiazol có **S1, N3**; oxazol có **O1, N3**.

### 2.2. Danh pháp thông thường

Dị vòng thường có cấu tạo phức tạp, nên tên thông thường vẫn được dùng phổ biến: **pyridin** thay cho monoazin, **imidazol** thay cho 1,3-diazol.

> [!cap-nhat] Tên "monoazol", "monoazin"
> Giáo trình ghi pyrrol là "monoazol", pyridin là "monoazin". Hiện nay IUPAC **giữ các tên thông thường** pyrrol, pyridin, imidazol, pyrimidin, purin, indol, quinolin làm tên chính thức. Kiểu tên ghép (hệ Hantzsch–Widman) chủ yếu dùng cho dị vòng có nhiều dị tử hoặc dị tử khác loại, như 1,3-thiazol, 1,3-oxazol, 1,4-oxazin. Tiếp đầu ngữ "mono-" thường không viết. Đi thi vẫn trả lời theo cách gọi của giáo trình.

## 3. Đồng phân

Loại đồng phân phổ biến nhất của dị vòng là đồng phân do **vị trí dị tử** và **vị trí liên kết đôi** (tr. 236). Ví dụ **oxazin** (vòng 6 cạnh có 1 O và 1 N) có ba đồng phân theo vị trí dị tử: **1,2-oxazin**, **1,3-oxazin**, **1,4-oxazin**.

> [!vi-du] Đồng phân vị trí dị tử gặp nhiều trong y học
> - **Diazin** (vòng 6 cạnh có 2 N): 1,2-diazin (pyridazin), **1,3-diazin (pyrimidin)**, 1,4-diazin (pyrazin). Chỉ pyrimidin có mặt trong acid nucleic.
> - **Diazol** (vòng 5 cạnh có 2 N): **1,2-diazol (pyrazol)**, có trong nhóm thuốc giảm đau pyramidon, analgin; **1,3-diazol (imidazol)**, có trong histidin, histamin, metronidazol.
> - **Quinolin và isoquinolin** chỉ khác nhau ở vị trí N (1 hay 2).

## 4. Tính chất lý học

Dị vòng có thể là chất lỏng hoặc chất rắn. Nhiều chất có **mùi khó chịu**: **indol** mùi thối như phân, **pyrrolidin** mùi khai như amoniac, **pyrrol** mùi giống cloroform, **pyridin** mùi đặc biệt khó chịu (tr. 236–237).

| Dị vòng | Trạng thái | t° nóng chảy (°C) | t° sôi (°C) |
|---|---|---|---|
| Pyrrol | lỏng | −18,5 | 130 |
| Pyrrolidin | lỏng | | 87 |
| Pyridin | lỏng | −41,8 | 115,6 |
| Quinolin | lỏng | −15,6 | 237,1 |
| Pyrimidin | rắn | 21 | 124 |
| Piperazin | rắn | 104 | 145 |
| Purin | rắn | 216 | |
| Acridin | rắn | 110 | 345 |
| Indol | rắn | 52 | 253 |

*Bảng 25, Giáo trình tr. 237.*

> [!vi-du] Vì sao pyridin tan trong nước còn benzen thì không?
> Cặp electron tự do của N trong pyridin **nhận liên kết hydro** từ nước, nên pyridin **trộn lẫn với nước theo mọi tỷ lệ**. Benzen không có chỗ nhận liên kết hydro nên không tan. Pyridin vì thế là một **dung môi** quan trọng trong phòng thí nghiệm và tổng hợp thuốc.

## 5. Tính chất hóa học

### 5.1. Tính chất do cấu tạo của vòng quyết định

**Vì sao pyrrol, pyridin "giống benzen"?** Các dị vòng có **hệ liên hợp kín** như pyrrol, pyridin, pyrimidin có **6 electron π** trải đều trên vòng (giống benzen). Vì vậy chúng **bền**, khó cộng, dễ thế hơn cộng, tức là có **tính thơm**.

- **Pyridin**: 5 C và N, mỗi nguyên tử góp **1 electron π**. Cặp electron riêng của N nằm **ngoài** hệ π (hướng ra ngoài vòng).
- **Pyrrol**: 4 C góp 4 electron π, N góp **cả cặp electron** của nó. Cặp electron của N **nằm trong** hệ 6 electron π thơm.
- **Piperidin** (câu 11.4): vòng **no**, 5 C và N đều lai hóa **sp³**, không có electron π; cặp electron của N hoàn toàn "tự do" như ở amin béo bậc II.

#### a) Phản ứng thế

Pyridin chỉ bị brom hóa khi đun tới khoảng **300 °C**, nhóm thế vào **vị trí 3**:

=> C~5~H~5~N + Br~2~ → (300 °C) 3-bromopyridin C~5~H~4~BrN + HBr

**Phản ứng thế của pyridin khó hơn pyrrol**, vì N có độ âm điện lớn **hút electron** của vòng, làm vòng pyridin **nghèo electron** (tr. 237). Pyridin "khó tính" giống nitrobenzen.

Pyrrol ngược lại là vòng **giàu electron** (6 electron π chia cho chỉ 5 nguyên tử). Nó phản ứng với brom rất dễ, ngay ở nhiệt độ thường, và thế hết bốn vị trí C (câu 11.5):

=> C~4~H~4~NH (pyrrol) + 4Br~2~ → C~4~Br~4~NH (2,3,4,5-tetrabromopyrrol) + 4HBr

#### b) Phản ứng cộng

Pyrrol cộng hydro (giáo trình dùng H mới sinh từ Zn + HCl) cho dị vòng no **pyrrolidin**:

=> C~4~H~5~N (pyrrol) + 2H~2~ → C~4~H~9~N (pyrrolidin)

> [!bay] Điều kiện khử pyrrol
> Giáo trình ghi khử bằng Zn + HCl thu được pyrrolidin. Thực tế, Zn/HCl chỉ khử được **một nối đôi** (thu được 2,5-dihydropyrrol, tức 3-pyrrolin). Muốn có pyrrolidin phải **hydro hóa xúc tác** (H~2~/Ni hoặc Pt, nhiệt độ, áp suất). Đi thi, viết sản phẩm là pyrrolidin như sách.

#### c) Phản ứng dehydro hóa

Dị vòng **không có** hệ liên hợp kín (piperidin, pyrrolidin) có hóa tính giống **hydrocarbon no**. Chúng có thể bị **dehydro hóa** (tách hydro) thành dị vòng thơm:

=> C~5~H~11~N (piperidin) → (Ag^+^, t°) C~5~H~5~N (pyridin) + 3H~2~

### 5.2. Tính chất do dị tố quyết định: tính base

Đây là **hóa tính đặc trưng nhất** của dị vòng nitơ (đáp án 11.2). N trong vòng vẫn còn **cặp electron chưa chia sẻ**, nên nhận được ion H^+^ giống NH~3~ và amin:

- Với nước tạo **hydroxid** (cân bằng lệch mạnh về phía trái vì pyridin là base yếu):

=> C~5~H~5~N + H~2~O ⇌ C~5~H~5~NH^+^ + OH^−^ (pyridin hydroxid)

- Với acid tạo **muối pyridini**:

=> C~5~H~5~N + HCl → C~5~H~5~NH^+^Cl^−^ (pyridin clorid)

- Với **acid picric** (2,4,6-trinitrophenol) tạo **pyridin picrat kết tủa vàng**. Phản ứng tạo picrat dùng để nhận biết và tách các base hữu cơ:

=> C~5~H~5~N + C~6~H~2~(NO~2~)~3~OH → [C~5~H~5~NH]^+^[C~6~H~2~(NO~2~)~3~O]^−^ ↓ vàng

Tương tự, **pyrrolidin** và piperidin (base mạnh) phản ứng với HCl tạo pyrrolidin clorid, piperidin clorid (câu 11.3, 11.6):

=> C~4~H~8~NH + HCl → C~4~H~8~NH~2~^+^Cl^−^

### 5.3. So sánh tính base

| Loại | Chất | K~b~ (Bảng 26) |
|---|---|---|
| Dị vòng thơm | pyrrol | 1,0·10^−16^ |
| Amin thơm | anilin | 4,6·10^−10^ |
| Dị vòng thơm | pyridin | 1,8·10^−9^ |
| *(mốc so sánh)* | *NH~3~* | *1,8·10^−5^* |
| Dị vòng không thơm (no) | piperidin | 1,7·10^−4^ (theo sách) |
| Dị vòng không thơm (no) | pyrrolidin | 1,3·10^−3^ |
| Amin béo bậc hai | diethylamin | 9,6·10^−4^ |

*Giáo trình tr. 238; K~b~ của NH~3~ thêm để so sánh.*

![Hình 3. Vị trí cặp electron của N quyết định tính base](tinh-base.svg)

Ba kết luận của giáo trình (tr. 239), kèm "vì sao":

1. **Dị vòng thơm (pyridin) có tính base yếu, tương tự amin thơm.** K~b~ của pyridin chỉ lớn hơn của anilin một chút. Cặp electron của N pyridin **không bị giải tỏa** vào vòng; còn cặp electron của N anilin **liên hợp vào vòng benzen**, nên kém sẵn sàng nhận H^+^.
2. **Dị vòng no (pyrrolidin, piperidin) có tính base mạnh như amin béo**: K~b~ của pyrrolidin xấp xỉ diethylamin. Hai nhóm CH~2~ gắn vào N có hiệu ứng **+I**, cặp electron ở trên N "tự do" hoàn toàn.
3. **Dị vòng thơm yếu hơn dị vòng no** vì N trong hệ thơm có mật độ electron thấp hơn.

> [!bay] Câu "Ví dụ: K~b~ pyridin > K~b~ piperidin" ở tr. 239 là in nhầm
> Ngay sau kết luận "dị vòng thơm **yếu hơn** dị vòng no", sách ghi ví dụ "K~b~ của pyridin > K~b~ của piperidin". Câu này mâu thuẫn với kết luận và với Bảng 26 (1,8·10^−9^ so với 1,7·10^−4^). Đúng là **K~b~ pyridin < K~b~ piperidin**, như đáp án 11.7: **pyrrol < anilin < pyridin < piperidin**.
> Thêm một chi tiết: K~b~ của piperidin trong Bảng 26 (1,7·10^−4^) có lẽ cũng in lệch; giá trị tra cứu hiện nay khoảng **1,3·10^−3^** (pK~a~ của ion piperidini ≈ 11,1). Vì vậy không nên dựa vào bảng này để so sánh piperidin với pyrrolidin: hai chất có tính base gần bằng nhau.

> [!vi-du] Hiểu sâu: lai hóa sp² và sextet thơm
> - **Pyrrol gần như không có tính base** (K~b~ ≈ 10^−16^): cặp electron của N là một phần của **6 electron π thơm**. Nếu N nhận H^+^, vòng sẽ **mất tính thơm**, rất bất lợi. Pyrrol còn bị acid mạnh làm **trùng hợp hóa nhựa**, nên không viết được muối pyrrol clorid bền.
> - **Pyridin** yếu hơn NH~3~ khoảng 10^4^ lần. Lý do chính được chấp nhận hiện nay: cặp electron của N pyridin nằm trong orbital **lai hóa sp²** (33% tính s), bị hạt nhân giữ chặt hơn orbital **sp³** (25% tính s) của NH~3~ và piperidin. Đáp án của giáo trình (11.3) giải thích bằng "hệ liên hợp"; khi trả lời, có thể nêu cả hai ý.

**Đáp án Tự lượng giá 11.3 (tr. 258)**:

- a) pyridin > anilin;
- b) pyrrolidin > pyridin;
- c) NH~3~ > pyridin;
- d) pyrrolidin > NH~3~ (do hiệu ứng +I của hai nhóm CH~2~ trong vòng **no**; đáp án sách in "vòng không no" là nhầm).

> [!vi-du] Nhận biết anilin và pyridin (câu 11.8)
> Dùng **nước brom**. Anilin có nhóm –NH~2~ hoạt hóa mạnh vòng benzen, nên cho ngay **kết tủa trắng** 2,4,6-tribromoanilin. Pyridin có vòng nghèo electron, không phản ứng với nước brom ở điều kiện thường.
>
> => C~6~H~5~NH~2~ + 3Br~2~ → C~6~H~2~Br~3~NH~2~ ↓ trắng + 3HBr

## 6. Điều chế

- **Nguồn tự nhiên:** than đá, gỗ, xương động vật… Chưng than đá thu được **nhựa than đá** chứa pyrrol, pyridin, quinolin, indol và các dị vòng khác.
- **Tổng hợp từ hợp chất không vòng**, theo hai nguyên tắc:

**a) Ngưng tụ** một hợp chất không chứa dị tố với một hợp chất có dị tố. Ví dụ cho hơi anilin và acetylen qua ống nung **600–700 °C** thu được indol:

=> C~6~H~5~NH~2~ (anilin) + C~2~H~2~ → (600–700 °C) C~8~H~7~N (indol) + H~2~

**b) Đổi dị tố** của một dị vòng này bằng dị tố khác. Ví dụ furan + NH~3~ (xúc tác Al~2~O~3~, khoảng 450 °C) cho pyrrol:

=> C~4~H~4~O (furan) + NH~3~ → C~4~H~4~NH (pyrrol) + H~2~O

Theo câu 11.9, chiều ngược lại viết tương tự (pyrrol + H~2~O → furan + NH~3~, cùng loại xúc tác, nhiệt độ cao). Đây là phản ứng minh họa nguyên tắc "đổi dị tử", ít dùng trong thực tế.

## 7. Ứng dụng và ý nghĩa y học

Dị vòng có mặt trong nhiều hợp chất tự nhiên quan trọng như **acid nucleic** và **alkaloid**. Nhiều dẫn xuất dị vòng được dùng làm thuốc: thuốc hạ nhiệt, giảm đau loại **pyramidon**; thuốc ngủ dẫn xuất **acid barbituric** (tr. 239–240).

### 7.1. Nhân purin và pyrimidin

Acid nucleic chứa các **base dị vòng**:

- **Base purin** (dẫn xuất purin): **adenin (A)** = 6-aminopurin; **guanin (G)** = 2-amino-6-oxopurin.
- **Base pyrimidin** (dẫn xuất pyrimidin): **cytosin (C)**, **thymin (T)** = 5-methyluracil, **uracil (U)**.
- **DNA** (ADN) chứa chủ yếu **G, A, C, T**; **RNA** (ARN) chứa chủ yếu **G, A, C, U**.

Acid nucleic trong nhân tế bào giữ vai trò trong **phân chia tế bào, tổng hợp protein** và **lưu giữ thông tin di truyền**.

![Hình 4. Cấu tạo năm base nucleic](base-nucleic.svg)

> [!bay] Vẽ base cho đúng
> - Uracil có **hai nhóm N–H** (N1 và N3) và **hai nhóm C=O** (C2, C4). Thymin giống hệt uracil, chỉ thêm **CH~3~ ở C5**.
> - Cytosin có C=O ở C2 và **–NH~2~ ở C4**; N3 không mang H.
> - Hình thymin và uracil trong giáo trình (tr. 240) in chưa chuẩn ở vị trí 3: thymin **thiếu nguyên tử N3**, uracil vẽ N3 **không mang H**. Hãy vẽ theo Hình 4.
> - Mẹo nhớ: purin (2 vòng) là **A, G**; pyrimidin (1 vòng) là **C, T, U**. Trong chuỗi xoắn kép DNA, A ghép với T bằng **2** liên kết hydro, G ghép với C bằng **3**.

> [!ung-dung] Purin, pyrimidin trong thuốc và bệnh
> - **Acid uric** là sản phẩm thoái hóa base purin ở người. Acid uric máu cao, kết tủa ở khớp gây **bệnh gút**. **Allopurinol** có khung gần giống purin, ức chế enzym xanthin oxidase nên giảm tạo acid uric.
> - **Thuốc chống ung thư, kháng virus** "đóng giả" base: **5-fluorouracil** (giống uracil), **mercaptopurin** (giống purin), **acyclovir** (giống guanin, trị Herpes).
> - **Cafein, theophylin** (Chè, Cà phê) là dẫn xuất methyl của **xanthin**, tức 2,6-dioxopurin (xem khung YHCT).

### 7.2. Dị vòng trong các phân tử sống và thuốc khác (mở rộng)

| Dị vòng | Chất tự nhiên / sinh học | Thuốc |
|---|---|---|
| **Pyrrol** | **Hem** (porphyrin = 4 vòng pyrrol nối bằng cầu =CH–, Fe^2+^ ở giữa); diệp lục (Mg^2+^); vitamin B12 (vòng corrin, Co); **bilirubin** (4 pyrrol mạch hở, gây vàng da) | |
| **Pyrrolidin** | Prolin | Nicotin (kèm pyridin) |
| **Imidazol** | **Histidin**, **histamin** (dị ứng) | Metronidazol, ketoconazol |
| **Thiazol** | **Vitamin B1** (thiamin = pyrimidin + thiazol) | Penicillin (vòng thiazolidin) |
| **Pyridin** | **Vitamin B6** (pyridoxin); **vitamin PP** (acid nicotinic, nicotinamid); coenzym **NAD^+^** | **Isoniazid** (thuốc lao) |
| **Pyrimidin** | C, T, U; vitamin B1 | **Barbiturat** (phenobarbital), 5-fluorouracil |
| **Indol** | **Tryptophan**, **serotonin**, melatonin | Indomethacin |
| **Quinolin** | Quinin | Chloroquin; kháng sinh **fluoroquinolon** (ciprofloxacin) |
| **Phenothiazin** | | **Chlorpromazin** (an thần kinh) |

> [!ung-dung] Thiếu vitamin chứa dị vòng
> - Thiếu **B1** (thiamin): bệnh **tê phù (beriberi)**, hội chứng Wernicke ở người nghiện rượu.
> - Thiếu **PP** (niacin): bệnh **pellagra** với "3 D": viêm da, tiêu chảy, sa sút trí tuệ. Cái tên "acid **nicotinic**" có gốc từ chỗ chất này từng được điều chế bằng cách **oxy hóa nicotin** (nhân pyridin còn lại, mạch pyrrolidin bị cắt thành –COOH).
> - Dùng **isoniazid** (một dẫn chất pyridin) kéo dài có thể gây **thiếu B6**, viêm dây thần kinh ngoại biên; vì vậy thường uống kèm vitamin B6.

> [!cap-nhat] Hai thuốc dị vòng được giáo trình nêu
> - **Pyramidon** (aminophenazon, dẫn xuất pyrazolon): giáo trình nêu là thuốc hạ nhiệt, giảm đau. Hiện nay pyramidon **đã bị loại khỏi sử dụng** ở hầu hết các nước vì nguy cơ **mất bạch cầu hạt** có thể gây tử vong.
> - **Barbiturat** (dẫn xuất acid barbituric = pyrimidin-2,4,6-trion): giáo trình nêu là thuốc ngủ. Hiện nay barbiturat **gần như không còn dùng làm thuốc ngủ** vì dễ gây lệ thuộc và quá liều gây ức chế hô hấp; nhóm benzodiazepin và các thuốc mới đã thay thế. **Phenobarbital** vẫn được dùng để **chống động kinh**.

### 7.3. Alkaloid

**Alkaloid** là hợp chất thiên nhiên có cấu tạo phức tạp, **chứa nitơ**, **đa số** có cấu tạo **dị vòng**, có **tính base**, thường gặp trong **thực vật**, và có **tác dụng dược lý mạnh** (tr. 240).

- Alkaloid cho phản ứng **kết tủa** với một số thuốc thử chung: **tannin**, **acid picric**. Với **acid sulfuric, acid nitric đặc** chúng tạo các hợp chất **có màu đặc trưng**. Trong kiểm nghiệm dược liệu còn dùng các thuốc thử tạo tủa như Mayer, Dragendorff, Bouchardat.
- **Ephedrin** có trong cây **Thảo ma hoàng** (Ma hoàng), dùng điều trị **cơn hen, sổ mũi**. *Ephedrin là alkaloid nhưng N nằm ở mạch nhánh, **không có dị vòng**.* Cấu trúc lập thể của ephedrin đã học ở bài **Cấu trúc phân tử hợp chất hữu cơ — đồng phân** (hc-01).
- **Quinin** có trong vỏ cây **Canhkina đỏ** (*Cinchona*), dùng điều trị **sốt rét** do ký sinh trùng. Phân tử quinin có nhân **quinolin** (gắn nhóm –OCH~3~ ở vị trí 6) nối với một khung bicyclic chứa N (quinuclidin).

> [!bay] "Alkaloid = dị vòng nitơ"?
> Giáo trình viết "**đa số**" alkaloid có dị vòng. Có ngoại lệ, như **ephedrin** (N ở mạch nhánh). Ngược lại, có chất là dị vòng nitơ nhưng tính base rất yếu: **cafein** có khung purin nhưng gần như không tạo muối với acid loãng như các alkaloid thông thường.

> [!cap-nhat] Quinin trong điều trị sốt rét hiện nay
> Giáo trình nêu quinin là thuốc trị sốt rét. Hiện nay, theo WHO và hướng dẫn của Bộ Y tế, thuốc đầu tay là các **phối hợp có dẫn chất artemisinin** (ACT); sốt rét nặng dùng **artesunat tiêm**. Quinin chỉ còn là thuốc **thay thế** khi không có artesunat hoặc trong một số trường hợp đặc biệt. Artemisinin (từ cây **Thanh hao hoa vàng**) không phải alkaloid, nhưng cũng là một dị vòng: nó chứa vòng **1,2,4-trioxan** có cầu peroxid –O–O–, phần quyết định tác dụng diệt ký sinh trùng.

> [!yhct] Alkaloid dị vòng trong dược liệu: đọc tên nhân, hiểu tính chất
> Bài **Hiệu ứng cấu trúc** (hc-03) đã giải thích vì sao alkaloid là base (cơ sở của chế giấm). Ở đây chỉ xếp các alkaloid quen thuộc theo **nhân dị vòng** vừa học:
>
> | Vị thuốc (bộ phận dùng) | Alkaloid chính | Nhân dị vòng | Tác dụng chính |
> |---|---|---|---|
> | **Hoàng liên** (thân rễ), Hoàng bá, **Vàng đắng** | **Berberin** | **Isoquinolin** (dạng ion amoni bậc 4, màu vàng) | Kháng khuẩn đường ruột, trị lỵ, tiêu chảy |
> | **Bình vôi** (củ) | **Rotundin** (L-tetrahydropalmatin) | Isoquinolin | An thần, gây ngủ |
> | **Canh-ki-na** (vỏ thân) | **Quinin**, quinidin | **Quinolin** | Quinin trị sốt rét; quinidin chống loạn nhịp tim |
> | **Chè** (lá), **Cà phê** (hạt) | **Cafein**; **theophylin** (lượng nhỏ trong chè) | **Purin** (xanthin) | Kích thích thần kinh trung ương, lợi tiểu; theophylin giãn phế quản, trị hen |
> | **Thuốc lá**, Thuốc lào | **Nicotin** | **Pyridin + pyrrolidin** | Không dùng làm thuốc; độc, gây nghiện |
> | **Mã tiền** (hạt) | **Strychnin**, brucin | **Indol** (khung nhiều vòng) | Rất độc; liều nhỏ kích thích thần kinh, dùng trong thuốc xoa bóp, phong thấp |
> | **Ba gạc** (rễ) | **Reserpin**, ajmalin | **Indol** | Hạ huyết áp, an thần |
>
> - **Hóa học giải thích dược động:** berberin là **ion amoni bậc 4** (mang điện dương thường trực; cũng vì thế không chiết được theo kiểu kiềm hóa – dung môi hữu cơ, xem bài *Amin, amid, amino acid*, mã hc-10, mục 5) nên **hấp thu qua ruột rất kém**; berberin còn bị bơm P-glycoprotein đẩy ngược vào lòng ruột (xem bài *Hóa sinh màng tế bào*, mã hs-13). Thuốc lưu lại nhiều trong lòng ruột, phù hợp với công dụng trị lỵ, tiêu chảy, nhưng không đạt nồng độ đủ cao trong máu để trị nhiễm khuẩn toàn thân.
> - **Mức bằng chứng:** berberin, quinin, cafein, theophylin, reserpin đều đã được tinh chế thành **thuốc** có dược lý rõ ràng. Còn hàm lượng hoạt chất trong dược liệu thô thì thay đổi theo nguồn gốc, bộ phận dùng và cách chế biến, nên không quy đổi đơn giản "vị thuốc = thuốc tinh khiết".

> [!yhct] Mã tiền: vì sao bắt buộc phải chế biến
> - Hạt **Mã tiền** (*Strychnos nux-vomica*) chứa **strychnin** và brucin, là alkaloid nhân indol **cực độc**. Strychnin chặn thụ thể **glycin** (chất ức chế dẫn truyền) ở tủy sống, nên gây **co cứng, co giật** kiểu uốn ván khi người bệnh vẫn tỉnh, có thể tử vong do co cứng cơ hô hấp (cơ chế hóa sinh thần kinh: xem bài *Hóa sinh thần kinh*, mã hs-21). Liều gây chết ở người lớn chỉ vài chục miligam strychnin.
> - **Mã tiền sống không được dùng uống.** Theo các sách bào chế, hạt được ngâm (nước hoặc nước vo gạo) cho mềm, **cạo bỏ vỏ và lông**, bỏ mầm, thái mỏng, sấy khô rồi **sao** (với cát) hoặc **tẩm dầu vừng rồi sao** đến màu vàng nâu. Các bước cụ thể thay đổi theo từng phương pháp.
> - **Cơ sở hóa học:** nhiệt độ cao làm giảm **một phần** (không loại hết) hàm lượng strychnin, brucin; dầu vừng giúp truyền nhiệt đều khi sao. Một phần các chất này chuyển thành dẫn chất **ít độc hơn** (như isostrychnin và dạng N-oxid).
> - **Quan niệm YHCT và lịch sử dùng thuốc**: Mã tiền chế được dùng trong thuốc xoa bóp, chữa phong thấp, tê bại; "liều nhỏ kích thích thần kinh" là cơ sở xưa của việc dùng strychnin làm thuốc "bổ thần kinh", nay không còn dùng.
> - **Thận trọng:** Mã tiền **đã chế vẫn là thuốc độc**. Khoảng cách giữa liều điều trị và liều độc rất hẹp, nên phải dùng **đúng liều quy định của Dược điển**, không tự ngâm rượu uống. Nếu ngộ độc (cứng hàm, co giật), phải **cấp cứu ngay**.

## Tóm tắt

| Chủ đề | Điều cần nhớ |
|---|---|
| Định nghĩa | Vòng có dị tử O, N, S **nằm trong vòng**; dị tử mang số 1 |
| Phân loại | Theo dị tố, số cạnh, độ bão hòa (**pyridin không no – piperidin no**), số vòng, số dị tố |
| Danh pháp (sách) | az/ox/thi + **-ol** (5 cạnh) / **-in** (6 cạnh): imidazol = 1,3-diazol; pyrimidin = 1,3-diazin |
| Đồng phân | Vị trí dị tử và vị trí liên kết đôi (1,2-, 1,3-, 1,4-oxazin) |
| Phản ứng thế | Pyrrol rất dễ (4 Br); pyridin rất khó (300 °C, vị trí 3) |
| Cộng / dehydro hóa | Pyrrol + H → pyrrolidin; piperidin − 6H → pyridin |
| Tính base | **pyrrol < anilin < pyridin < NH~3~ < piperidin ≈ pyrrolidin**; pyridin + HCl → pyridin clorid; + acid picric → picrat **vàng** |
| Nhận biết anilin / pyridin | Nước brom: anilin cho **tủa trắng** |
| Điều chế | Nhựa than đá; anilin + acetylen → indol; furan + NH~3~ → pyrrol |
| Acid nucleic | Purin: **A, G**; pyrimidin: **C, T, U**; DNA có T, RNA có U |
| Alkaloid | N, đa số dị vòng, tính base, tác dụng mạnh; tủa với tannin, acid picric; ephedrin (Ma hoàng, hen), quinin (Canhkina, sốt rét) |
