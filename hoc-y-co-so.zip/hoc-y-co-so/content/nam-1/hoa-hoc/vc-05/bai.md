---
title: Hợp chất vô cơ: oxide, acid, base, muối
thoi-gian: 30 phút
muc-tieu:
- Nêu được định nghĩa và cách phân loại oxide, acid, base, muối; cho được ví dụ mỗi loại.
- Viết được các phương trình (đã cân bằng) thể hiện tính chất hóa học cơ bản của từng loại hợp chất.
- Trình bày được các phương pháp chính để điều chế oxide, acid, base, muối.
- Gọi được tên các hợp chất vô cơ thường gặp và vận dụng vào y học (acid dạ dày, thuốc kháng acid, dung dịch muối).
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. **Oxide** = oxy + một nguyên tố khác. Có 4 loại: **base, acid, lưỡng tính, trơ** (không tạo muối).
> 2. **Acid** là chất **nhường H^+^**; **base** là chất **nhận H^+^** (định nghĩa proton). Vì vậy NH~4~^+^ là acid, NH~3~ và CO~3~^2−^ là base.
> 3. Acid có oxy càng nhiều O càng mạnh: HClO~4~ > HClO~3~ > HClO~2~ > HClO.
> 4. **Muối** = thay H^+^ của acid bằng cation, hoặc thay OH^−^ của base bằng anion gốc acid. Có 5 loại: trung tính, acid, base, kép, hỗn hợp.
> 5. Phản ứng trao đổi chỉ xảy ra khi tạo **kết tủa, khí, hoặc chất điện ly yếu** (như H~2~O).

![Hình 1. Quan hệ giữa các loại hợp chất vô cơ](quan-he.svg)

Hình 1 tóm tắt cả bài. Kim loại cháy cho oxide base, tan vào nước cho base. Phi kim cháy cho oxide acid, tan vào nước cho acid. Hai "nhánh" gặp nhau ở **muối**.

## 1. Oxide

### 1.1. Định nghĩa và phân loại

**Oxide** là hợp chất của **oxy với một nguyên tố khác**. Trong oxide thông thường, O có số oxy hóa **−2**.

| Loại | Thường là oxide của | Hydroxide tương ứng | Ví dụ (giáo trình) |
|---|---|---|---|
| **Oxide base** | Kim loại | Base | Na~2~O → NaOH; CuO → Cu(OH)~2~ |
| **Oxide acid** | Hầu hết phi kim; **một số kim loại** ở số oxy hóa cao | Acid | CO~2~ → H~2~CO~3~; SO~3~ → H~2~SO~4~; Mn~2~O~7~ → HMnO~4~; CrO~3~ → H~2~CrO~4~ |
| **Oxide lưỡng tính** | Một số kim loại | Hydroxide lưỡng tính | ZnO → Zn(OH)~2~; Al~2~O~3~ → Al(OH)~3~ |
| **Oxide trơ** (không tạo muối) | Một số phi kim | Không có | CO, NO, N~2~O |

*Ví dụ oxide trơ là bổ sung; giáo trình chỉ nêu tên nhóm.*

**Oxide đặc biệt**: có những hợp chất của oxy mà O **không** mang số oxy hóa −2:

- **Peroxide** Na~2~O~2~: O có số oxy hóa −1 (có cầu –O–O–).
- **Superoxide** KO~2~: O có số oxy hóa −1/2.
- **Ozonide** KO~3~ (giáo trình gọi là *ozonit*): O có số oxy hóa −1/3.
- F~2~O: O có số oxy hóa **+2**, vì F hút electron mạnh hơn O.

> [!bay] Oxide kim loại không phải lúc nào cũng là oxide base
> Tính chất phụ thuộc **số oxy hóa** của kim loại. Số oxy hóa càng cao thì oxide càng thiên về **acid**. Ví dụ với crom: CrO (+2) là oxide base, Cr~2~O~3~ (+3) lưỡng tính, **CrO~3~ (+6) là oxide acid**. Mangan cũng vậy: Mn~2~O~7~ (+7) là oxide acid của acid permanganic HMnO~4~.
>
> *Vì sao?* Kim loại mang điện tích dương lớn hút mạnh electron của O, làm liên kết O–H trong hydroxide phân cực. Khi đó H^+^ dễ tách ra, nên hydroxide thể hiện tính acid.

> [!cap-nhat] Tên gọi F₂O
> Giáo trình xếp F~2~O vào nhóm oxide ("fluorid oxide"). Hiện nay danh pháp IUPAC viết **OF~2~** và gọi là **oxygen difluorid**. Lý do: F âm điện hơn O nên đây là một **fluorid của oxy**, không phải oxide. Khi thi, chỉ cần nhớ ý của giáo trình: trong F~2~O, O có số oxy hóa +2.

### 1.2. Tính chất hóa học

**a) Oxide base**

- Oxide của **kim loại kiềm và kiềm thổ** tan trong nước, tạo dung dịch kiềm:

=> BaO + H~2~O → Ba(OH)~2~

- Tác dụng với **oxide acid** và với **acid** tạo muối:

=> CaO + CO~2~ → CaCO~3~

=> Fe~2~O~3~ + 3H~2~SO~4~ → Fe~2~(SO~4~)~3~ + 3H~2~O

**b) Oxide acid** — tác dụng với **oxide base** và với **base** tạo muối:

=> SO~3~ + BaO → BaSO~4~

=> CO~2~ + 2NaOH → Na~2~CO~3~ + H~2~O

**c) Oxide lưỡng tính** — tác dụng được với **cả acid lẫn base**:

=> ZnO + H~2~SO~4~ → ZnSO~4~ + H~2~O

=> ZnO + 2NaOH + H~2~O → Na~2~[Zn(OH)~4~]

Sản phẩm với kiềm là **muối phức** natri tetrahydroxozincat. Al~2~O~3~ cũng vậy: tan trong acid cho muối Al^3+^, tan trong kiềm cho Na[Al(OH)~4~]. Giáo trình còn viết Al(OH)~3~ dưới dạng "acid" HAlO~2~·H~2~O để nhấn mạnh tính lưỡng tính.

> [!vi-du] Vì sao gọi là "lưỡng tính"?
> Zn(OH)~2~ có thể tách theo hai kiểu. Gặp acid, nó nhả OH^−^ (đóng vai base). Gặp kiềm mạnh, nó nhận thêm OH^−^ để tạo [Zn(OH)~4~]^2−^ (đóng vai acid). Chất nào "chọn" vai trò tùy theo bạn phản ứng của nó.

### 1.3. Điều chế oxide

| Cách | Ví dụ (đã cân bằng) |
|---|---|
| Đốt nguyên tố trong oxy | S + O~2~ → SO~2~ ; 4Na + O~2~ → 2Na~2~O |
| Acid có tính oxy hóa tác dụng với phi kim hoặc kim loại | C + 2H~2~SO~4~ (đặc, t°) → CO~2~ + 2SO~2~ + 2H~2~O ; Cu + 4HNO~3~ (đặc) → Cu(NO~3~)~2~ + 2NO~2~ + 2H~2~O |
| Nhiệt phân acid, base, muối | H~2~SO~3~ → SO~2~ + H~2~O ; 2Fe(OH)~3~ → Fe~2~O~3~ + 3H~2~O ; 2Mg(NO~3~)~2~ → 2MgO + 4NO~2~ + O~2~ |

> [!bay] Giáo trình in nhầm hệ số (tr. 68)
> - Giáo trình in "2Na + O~2~ → Na~2~O", phương trình này **chưa cân bằng** O. Đúng là **4Na + O~2~ → 2Na~2~O**. (Nếu đốt Na trong oxy dư thì sản phẩm chính là peroxide: 2Na + O~2~ → Na~2~O~2~.)
> - Giáo trình in "6HNO~3~ + 2Cu → 2NO~2~ + 2Cu(NO~3~)~2~ + 3H~2~O", **chưa cân bằng** (vế trái 18 O, vế phải 19 O; Cu nhường 4 e mà N chỉ nhận 2 e). Phương trình đúng: **Cu + 4HNO~3~ (đặc) → Cu(NO~3~)~2~ + 2NO~2~ + 2H~2~O**. Chính phần đáp án cuối sách (tr. 248) cũng viết như vậy.

## 2. Acid

### 2.1. Định nghĩa và phân loại

**Acid** là chất có khả năng **nhường proton H^+^**. Định nghĩa này (của Brönsted) không đòi hỏi acid phải là phân tử trung hòa; một ion cũng có thể là acid:

=> HCl → H^+^ + Cl^−^

=> H~2~PO~4~^−^ ⇌ H^+^ + HPO~4~^2−^

=> NH~4~^+^ ⇌ H^+^ + NH~3~

| Loại | Ví dụ |
|---|---|
| **Acid không có oxy** | HF, HCl, H~2~S, NH~4~^+^ |
| **Acid có oxy** | H~2~SO~4~, HNO~2~, H~2~CO~3~, H~2~PO~4~^−^ |

### 2.2. Tính chất hóa học

**a) Độ mạnh của acid có oxy.** Với cùng một nguyên tố trung tâm, **càng nhiều nguyên tử O thì acid càng mạnh**:

- HNO~3~ > HNO~2~
- H~2~SO~4~ > H~2~SO~3~
- HClO~4~ > HClO~3~ > HClO~2~ > HClO

*Vì sao?* Giáo trình giải thích: thêm O làm liên kết **O–H phân cực hơn**. O là nguyên tố hút electron mạnh. Càng nhiều O "kéo" electron về phía mình, cặp electron của liên kết O–H càng lệch xa H, nên H^+^ càng dễ tách ra. Ngoài ra, anion sinh ra (ví dụ ClO~4~^−^) có điện tích âm được **trải đều** trên nhiều O nên rất bền; acid vì thế dễ nhường H^+^ hơn.

**b) Tác dụng với oxide base và base** (phản ứng trung hòa):

=> H~2~SO~4~ + CuO → CuSO~4~ + H~2~O

=> HCl + NaOH → NaCl + H~2~O

**c) Tác dụng với kim loại.** Cần phân biệt hai nhóm acid:

| | Acid **không** có tính oxy hóa (HCl, H~2~SO~4~ loãng) | Acid **có** tính oxy hóa (HNO~3~, H~2~SO~4~ đặc nóng) |
|---|---|---|
| Phần bị khử | Ion H^+^ | **Gốc acid** (N^+5^, S^+6^) |
| Sản phẩm khí | **H~2~** | NO~2~, NO, N~2~O, N~2~, NH~4~^+^; SO~2~, S, H~2~S |
| Kim loại phản ứng | Chỉ kim loại **hoạt động** (đứng trước H) | Cả kim loại kém hoạt động như **Cu, Ag**; cả **phi kim** (C, S, P) |

=> Zn + H~2~SO~4~ (loãng) → ZnSO~4~ + H~2~↑

=> 5Mg + 12HNO~3~ → 5Mg(NO~3~)~2~ + N~2~↑ + 6H~2~O

=> Cu + 2H~2~SO~4~ (đặc, t°) → CuSO~4~ + SO~2~↑ + 2H~2~O

=> 2P + 5H~2~SO~4~ (đặc) → 2H~3~PO~4~ + 5SO~2~↑ + 2H~2~O

**d) Phản ứng trao đổi với muối:**

=> 2HCl + Na~2~CO~3~ → 2NaCl + CO~2~↑ + H~2~O

=> H~2~SO~4~ + BaCl~2~ → BaSO~4~↓ + 2HCl

*Vì sao phản ứng xảy ra?* Phản ứng trao đổi giữa các chất trong dung dịch chỉ "chạy" khi một sản phẩm **thoát khỏi dung dịch**: kết tủa (BaSO~4~), khí (CO~2~) hoặc chất rất ít phân ly (H~2~O). Nếu không, các ion chỉ trộn lẫn mà không có phản ứng.

> [!bay]
> - Giáo trình in "HCl + Na~2~CO~3~ → CO~2~ + H~2~O + NaCl" (tr. 69) — **thiếu hệ số**. Đúng là **2**HCl và **2**NaCl. Với lượng HCl ít (thiếu), phản ứng chỉ dừng ở NaHCO~3~: HCl + Na~2~CO~3~ → NaCl + NaHCO~3~.
> - **Fe, Al** bị HNO~3~ đặc nguội và H~2~SO~4~ đặc nguội làm **thụ động** (không tan).
> - HNO~3~ không bao giờ giải phóng H~2~ khi tác dụng với kim loại, kể cả khi loãng.

### 2.3. Điều chế acid

- **Tổng hợp trực tiếp từ đơn chất:** H~2~ + Cl~2~ → 2HCl (chiếu sáng hoặc đốt), sau đó hòa khí HCl vào nước.
- **Từ oxide acid + nước:**

=> SO~3~ + H~2~O → H~2~SO~4~

=> 4NO~2~ + O~2~ + 2H~2~O → 4HNO~3~

- **Điện phân dung dịch muối** (với muối của kim loại yếu và gốc acid có oxy):

=> 2CuSO~4~ + 2H~2~O → 2Cu + 2H~2~SO~4~ + O~2~↑ (điện phân dung dịch)

## 3. Base

### 3.1. Định nghĩa và phân loại

**Base** là chất có khả năng **nhận proton H^+^**. Ví dụ: NaOH (thực chất là ion OH^−^ nhận H^+^), CO~3~^2−^, NH~3~.

| Loại | Ví dụ | Đặc điểm |
|---|---|---|
| **Base tan** (base kiềm) | KOH, NaOH, Ba(OH)~2~ | Hydroxide của kim loại kiềm, kiềm thổ (trừ Be, Mg). Làm quỳ hóa xanh, phenolphtalein hóa hồng |
| **Base không tan** | Cu(OH)~2~, Fe(OH)~2~, Fe(OH)~3~ | Bị **nhiệt phân** thành oxide + nước |

### 3.2. Tính chất hóa học

**a) Tác dụng với oxide acid, oxide lưỡng tính và acid:**

=> Ca(OH)~2~ + CO~2~ → CaCO~3~↓ + H~2~O

=> 2NaOH + Al~2~O~3~ + 3H~2~O → 2Na[Al(OH)~4~]

=> NH~3~ + HCl → NH~4~Cl

Phản ứng đầu là cách **nhận biết CO~2~**: thổi khí vào nước vôi trong thấy vẩn đục.

**b) Tác dụng với kim loại (có hydroxide lưỡng tính) và phi kim:**

=> Zn + Ba(OH)~2~ + 2H~2~O → Ba[Zn(OH)~4~] + H~2~↑

=> Cl~2~ + Ca(OH)~2~ → CaOCl~2~ + H~2~O

Phản ứng thứ hai tạo **clorua vôi**, chất khử trùng.

**c) Phản ứng trao đổi với muối:**

=> 2NaOH + Ca(HCO~3~)~2~ → Na~2~CO~3~ + CaCO~3~↓ + 2H~2~O

=> Ba(OH)~2~ + (NH~4~)~2~SO~4~ → BaSO~4~↓ + 2NH~3~↑ + 2H~2~O

=> 2NaOH + Cu(NO~3~)~2~ → Cu(OH)~2~↓ + 2NaNO~3~

Phản ứng giữa kiềm và **muối amoni** giải phóng **NH~3~** (mùi khai, làm xanh quỳ ẩm). Đây là cách nhận biết ion NH~4~^+^.

**d) Phản ứng nhiệt phân** (base không tan):

=> Mg(OH)~2~ → MgO + H~2~O (t°)

> [!bay] Giáo trình in nhầm (tr. 70)
> Trong phương trình 2NaOH + Ca(HCO~3~)~2~, giáo trình đánh dấu kết tủa (↓) cho cả **Na~2~CO~3~**. Thực tế **Na~2~CO~3~ tan tốt**; chỉ có **CaCO~3~ kết tủa**. Đây là phản ứng làm mềm nước cứng tạm thời.

### 3.3. Điều chế base

- **Kim loại kiềm, kiềm thổ hoặc oxide của chúng + nước:**

=> 2Li + 2H~2~O → 2LiOH + H~2~↑

=> BaO + H~2~O → Ba(OH)~2~

- **Trao đổi giữa muối và base** (dùng điều chế base không tan):

=> FeSO~4~ + 2NaOH → Fe(OH)~2~↓ + Na~2~SO~4~

=> Al(NO~3~)~3~ + 3NH~3~ + 3H~2~O → Al(OH)~3~↓ + 3NH~4~NO~3~

Điều chế Al(OH)~3~ nên dùng **NH~3~** thay cho NaOH. Lý do: Al(OH)~3~ là chất lưỡng tính, sẽ tan trở lại nếu dư NaOH, còn NH~3~ là base yếu nên không hòa tan được nó.

- **Điện phân dung dịch muối halid có màng ngăn** — cách sản xuất NaOH trong công nghiệp:

=> 2NaCl + 2H~2~O → 2NaOH + H~2~↑ + Cl~2~↑ (điện phân, có màng ngăn)

> [!bay] Giáo trình in nhầm (tr. 71)
> Giáo trình viết "BaO + 2H~2~O → Ba(OH)~2~ + H~2~↑". **Sai**: oxide tan vào nước **không** giải phóng H~2~ (không có chất nào thay đổi số oxy hóa). Đúng là **BaO + H~2~O → Ba(OH)~2~**. Chỉ **kim loại** (Li, Na, Ba…) tác dụng với nước mới sinh H~2~.

## 4. Muối

### 4.1. Định nghĩa và phân loại

**Muối** là sản phẩm khi **thay H^+^ của acid bằng cation** (gốc base), hoặc **thay OH^−^ của base bằng anion gốc acid**. Ví dụ: NaOCl, NaHCO~3~, NH~4~Cl.

| Loại | Đặc điểm | Ví dụ (giáo trình) |
|---|---|---|
| **Muối trung tính** | **Tất cả** H^+^ của acid đã được thay bằng cation | Na~2~CO~3~, K~2~SO~4~ |
| **Muối acid** | Còn H^+^ của acid **chưa** bị thay | NaHCO~3~, K~2~HPO~4~ |
| **Muối base** | Còn OH^−^ của base **chưa** bị thay | Fe(OH)~2~NO~3~, Ca(OH)Cl |
| **Muối kép** | Có **nhiều cation** | KAl(SO~4~)~2~·12H~2~O (phèn chua), Na~2~NH~4~PO~4~ |
| **Muối hỗn hợp** (hỗn tạp) | Có **nhiều anion** gốc acid | CaOCl~2~, tức Cl–Ca–OCl (clorua vôi) |

> [!bay] "Trung tính" là nói về cấu tạo, không phải về pH
> Muối **trung tính** chỉ có nghĩa là **không còn H^+^ thay thế được** trong gốc acid. Dung dịch của nó có thể **không** trung tính: Na~2~CO~3~ là muối trung tính nhưng dung dịch có tính **kiềm** khá mạnh. Ngược lại, NaHCO~3~ là muối **acid** nhưng dung dịch lại **kiềm nhẹ**. Nguyên nhân là hiện tượng **thủy phân** (xem mục 6.4).

> [!cap-nhat] Clorua vôi
> Giáo trình xem clorua vôi là một muối hỗn hợp có công thức CaOCl~2~ (Cl–Ca–OCl). Hiện nay clorua vôi thương mại được coi là **hỗn hợp** chủ yếu gồm Ca(OCl)~2~, CaCl~2~ và Ca(OH)~2~. Thành phần có tác dụng sát khuẩn là ion **hypoclorit OCl^−^**. Khi thi, trả lời theo giáo trình (muối hỗn hợp CaOCl~2~).

### 4.2. Tính chất hóa học

**a) Tác dụng với kim loại và phi kim** (phản ứng thế):

=> Zn + Cu(NO~3~)~2~ → Zn(NO~3~)~2~ + Cu

=> Cl~2~ + 2KBr → 2KCl + Br~2~

Kim loại **mạnh hơn** đẩy kim loại yếu hơn ra khỏi muối. Halogen **mạnh hơn** (Cl~2~) đẩy halogen yếu hơn (Br^−^) ra khỏi muối.

**b) Phản ứng trao đổi** (với muối, acid, base):

=> Na~2~SO~4~ + BaCl~2~ → BaSO~4~↓ + 2NaCl

=> AgNO~3~ + HCl → AgCl↓ + HNO~3~

=> K~2~CO~3~ + Ba(OH)~2~ → BaCO~3~↓ + 2KOH

Hai phản ứng đầu là phép thử quen thuộc: **ion Ba^2+^ nhận biết SO~4~^2−^** (kết tủa trắng, không tan trong acid); **ion Ag^+^ nhận biết Cl^−^** (kết tủa trắng AgCl, hóa đen ngoài ánh sáng).

**c) Phản ứng nhiệt phân:**

=> CaCO~3~ → CaO + CO~2~↑ (t°)

=> 2NaNO~3~ → 2NaNO~2~ + O~2~↑ (t°)

=> 2AgCl → 2Ag + Cl~2~↑ (ánh sáng)

### 4.3. Điều chế muối

Gần như mọi phản ứng đã học đều có thể tạo muối. Giáo trình nhóm thành 5 cách:

| Cách | Ví dụ |
|---|---|
| Kim loại + phi kim / acid / base / muối | 2Fe + 3Br~2~ → 2FeBr~3~ ; Zn + H~2~SO~4~ → ZnSO~4~ + H~2~↑ ; Cu + 2AgNO~3~ → Cu(NO~3~)~2~ + 2Ag↓ |
| Phi kim + base / muối | Cl~2~ + 2NaOH → NaCl + NaOCl + H~2~O ; Br~2~ + 2KI → 2KBr + I~2~ |
| Oxide + acid / base / oxide | BaO + H~2~SO~4~ → BaSO~4~ + H~2~O ; CO~2~ + 2NaOH → Na~2~CO~3~ + H~2~O ; CaO + CO~2~ → CaCO~3~ |
| Muối + acid / base / muối | 2AgNO~3~ + H~2~SO~4~ → Ag~2~SO~4~ + 2HNO~3~ ; K~2~CO~3~ + Ca(OH)~2~ → CaCO~3~↓ + 2KOH ; Pb(NO~3~)~2~ + 2KCl → PbCl~2~↓ + 2KNO~3~ |
| Nhiệt phân muối | 2KClO~3~ → 2KCl + 3O~2~↑ (t°, xúc tác MnO~2~) |

Ví dụ kim loại + base của giáo trình: 2Al + 6NaOH + 6H~2~O → 2Na~3~[Al(OH)~6~] + 3H~2~↑. Phương trình này cân bằng; sách hiện nay thường viết gọn 2Al + 2NaOH + 6H~2~O → 2Na[Al(OH)~4~] + 3H~2~↑.

> [!bay] Giáo trình in thiếu hệ số (tr. 72)
> Giáo trình in "CO~2~ + NaOH → Na~2~CO~3~ + H~2~O". Đúng là **CO~2~ + 2NaOH → Na~2~CO~3~ + H~2~O** (như chính sách viết ở tr. 68). Nếu CO~2~ dư thì tạo muối acid: CO~2~ + NaOH → NaHCO~3~.

> [!yhct] Xếp khoáng dược vào bảng phân loại của bài này
> Các khoáng dược đã gặp ở bốn bài trước có thể xếp vào đúng các loại hợp chất vừa học. Công dụng, cách chế và cảnh báo độc **không nhắc lại ở đây** — xem bài tương ứng.
>
> | Vị thuốc | Thành phần chính | Loại hợp chất | Xem bài |
> |---|---|---|---|
> | Bạch phàn (phèn chua) | KAl(SO~4~)~2~·12H~2~O | **Muối kép** (hai cation) | *Kim loại khối p (IIIA, IVA)* (vc-02), mục 2.3c |
> | Mang tiêu | Na~2~SO~4~·10H~2~O | Muối trung tính, ngậm nước | *Kim loại khối s (IA, IIA)* (vc-01), mục 3.6 |
> | Thạch cao | CaSO~4~·2H~2~O | Muối trung tính, ngậm nước | *Kim loại khối s (IA, IIA)* (vc-01), mục 3.6 |
> | Mẫu lệ, Ô tặc cốt, Ngõa lăng tử | CaCO~3~ | Muối trung tính của acid yếu | Khung YHCT ở mục 6.2 dưới đây |
> | Lô cam thạch | ZnCO~3~ (nung → ZnO) | Muối trung tính → oxide lưỡng tính | *Kim loại khối d (chuyển tiếp)* (vc-03), mục 4.6 |
> | Từ thạch | Fe~3~O~4~ | Oxide (hỗn hợp FeO·Fe~2~O~3~) | *Kim loại khối d (chuyển tiếp)* (vc-03), mục 4.6 |
> | Duyên đan, Mật đà tăng | Pb~3~O~4~, PbO | Oxide của chì (PbO là oxide lưỡng tính) | *Kim loại khối p (IIIA, IVA)* (vc-02), mục 3.6 |
> | Chu sa | HgS | Sulfid kim loại (muối của acid H~2~S) | *Kim loại khối d (chuyển tiếp)* (vc-03), mục 4.6 |
> | Hùng hoàng | As~4~S~4~ | Sulfid của arsen (hợp chất cộng hóa trị, không phải muối ion) | *Các nguyên tố phi kim* (vc-04), mục 4.5 |
>
> Bốn vị cuối chứa **chì, thủy ngân, arsen**: đều **độc**, không tự ý dùng, không đun nóng Chu sa và Hùng hoàng.

## 5. Gọi tên hợp chất vô cơ (bổ sung)

Giáo trình không có mục danh pháp riêng, nhưng các tên dưới đây được dùng xuyên suốt sách và trong đề thi.

| Loại | Quy tắc | Ví dụ |
|---|---|---|
| Oxide kim loại | Tên kim loại (hóa trị, nếu có nhiều) + **oxide** | Na~2~O natri oxide; FeO sắt(II) oxide; Fe~2~O~3~ sắt(III) oxide |
| Oxide phi kim | Tiền tố số nguyên tử (mono-, di-, tri-, penta-…) + **oxide** | CO carbon monoxide; CO~2~ carbon dioxide; SO~3~ sulfur trioxide; P~2~O~5~ diphosphor pentoxide |
| Acid không oxy | Acid + tên phi kim + **-hydric** | HCl acid clohydric; HF acid fluohydric; H~2~S acid sulfuhydric |
| Acid có oxy | Nhiều O: đuôi **-ic**; ít O hơn: đuôi **-ơ** | H~2~SO~4~ acid sulfuric / H~2~SO~3~ acid sulfurơ; HNO~3~ nitric / HNO~2~ nitrơ |
| Họ acid của clo | hypo…ơ < …ơ < …ic < per…ic | HClO acid hypoclorơ; HClO~2~ clorơ; HClO~3~ cloric; HClO~4~ percloric |
| Base | Tên kim loại (hóa trị) + **hydroxide** | NaOH natri hydroxide; Fe(OH)~3~ sắt(III) hydroxide |
| Muối | Tên kim loại (hóa trị) + tên gốc acid | Gốc từ acid **-hydric → -id** (clorid, sulfid); **-ic → -at** (sulfat, nitrat, carbonat); **-ơ → -it** (sulfit, nitrit, hypoclorit) |
| Muối acid | Thêm **hydro / dihydro** trước tên gốc | NaHCO~3~ natri hydrocarbonat; K~2~HPO~4~ kali hydrophosphat; KH~2~PO~4~ kali dihydrophosphat |

> [!vi-du] Luyện nhanh
> NaOCl natri hypoclorit (nước Javel) · KMnO~4~ kali permanganat (thuốc tím) · NH~4~Cl amoni clorid · BaSO~4~ bari sulfat · NaNO~2~ natri nitrit · CaOCl~2~ clorua vôi · Na~2~[Zn(OH)~4~] natri tetrahydroxozincat.

## 6. Ứng dụng y học

### 6.1. Acid clohydric trong dạ dày

Tế bào **viền** (tế bào thành) ở niêm mạc dạ dày tiết **HCl**. Dịch vị nhờ đó có pH khoảng **1,5–3,5**, là môi trường acid mạnh nhất cơ thể. HCl có ba vai trò chính:

- Biến **pepsinogen** thành **pepsin** hoạt động và tạo pH thích hợp để pepsin tiêu hóa protein.
- **Diệt vi khuẩn** theo thức ăn vào.
- Giúp hòa tan muối sắt, hỗ trợ **hấp thu sắt**.

![Hình 2. Thang pH: dung dịch muối bị thủy phân và một số dịch cơ thể](thang-ph.svg)

### 6.2. Thuốc kháng acid (antacid) — phản ứng trung hòa trong dạ dày

Antacid là các **base yếu hoặc muối của acid yếu**. Chúng trung hòa bớt HCl để giảm đau rát, ợ chua.

| Thuốc | Phản ứng với HCl | Tác dụng phụ đặc trưng — vì sao |
|---|---|---|
| **NaHCO~3~** (natri hydrocarbonat) | NaHCO~3~ + HCl → NaCl + CO~2~↑ + H~2~O | Sinh **CO~2~** gây đầy hơi, ợ hơi. Hấp thu vào máu gây **kiềm hóa**, nhiều Na^+^ |
| **CaCO~3~** | CaCO~3~ + 2HCl → CaCl~2~ + CO~2~↑ + H~2~O | Đầy hơi; dùng nhiều gây **táo bón** |
| **Mg(OH)~2~** (sữa magnesi) | Mg(OH)~2~ + 2HCl → MgCl~2~ + 2H~2~O | **Tiêu chảy** (Mg^2+^ kéo nước vào lòng ruột) |
| **Al(OH)~3~** | Al(OH)~3~ + 3HCl → AlCl~3~ + 3H~2~O | **Táo bón** |

Vì Mg(OH)~2~ gây tiêu chảy còn Al(OH)~3~ gây táo bón, các chế phẩm thường **phối hợp cả hai** để hai tác dụng phụ bù trừ nhau.

> [!ung-dung] BaSO₄ cản quang — và vì sao không được dùng BaCO₃
> Chụp X-quang dạ dày, ruột dùng **bari sulfat** uống. Ion Ba^2+^ tan rất độc, nhưng BaSO~4~ **không tan cả trong nước lẫn trong HCl** của dịch vị, nên đi qua ống tiêu hóa mà không bị hấp thu.
> Nếu nhầm thành **BaCO~3~** thì rất nguy hiểm: muối của acid yếu này **tan trong HCl dạ dày**:
>
> => BaCO~3~ + 2HCl → BaCl~2~ + CO~2~↑ + H~2~O
>
> BaCl~2~ tan, giải phóng Ba^2+^ gây ngộ độc (hạ kali máu, liệt cơ, rối loạn nhịp tim). Cùng nguyên tắc: phép thử SO~4~^2−^ bằng Ba^2+^ cho kết tủa **không tan trong acid**, còn BaCO~3~, BaSO~3~ thì tan.

> [!yhct] Vị thuốc chứa CaCO₃ và nước vôi trong bào chế
> - **Ô tặc cốt** (mai mực, Hải phiêu tiêu), **Mẫu lệ** (vỏ hàu), **Ngõa lăng tử** có thành phần chính là **CaCO~3~**. Trong YHCT các vị này có công dụng **"chế toan chỉ thống"** (bớt chua, giảm đau dạ dày). Cơ sở hóa học rõ ràng là phản ứng trung hòa CaCO~3~ + 2HCl, giống thuốc kháng acid hiện đại. Khi **nung** (đoạn) Mẫu lệ ở nhiệt độ cao, một phần CaCO~3~ có thể bị nhiệt phân thành CaO.
> - **Bán hạ** sống **có độc** (Dược điển Trung Quốc xếp loại có độc), gây ngứa, rát họng, tê lưỡi mạnh; không dùng sống để uống. Một cách chế (Pháp bán hạ) là ngâm với dịch **Cam thảo** và **nước vôi** (Ca(OH)~2~, từ vôi sống CaO + H~2~O). Cách chế khác (Thanh bán hạ, Khương bán hạ) dùng **phèn chua** và gừng. Các phương pháp này được ghi nhận làm giảm tính kích ứng của Bán hạ; cơ chế hóa học cụ thể vẫn đang được nghiên cứu.

### 6.3. Dung dịch NaCl 0,9% (nước muối sinh lý)

- **0,9%** nghĩa là **9 g NaCl trong 1 lít**, tức khoảng **154 mmol/L** (9 : 58,5). NaCl phân ly hoàn toàn thành Na^+^ và Cl^−^, nên nồng độ thẩm thấu lý thuyết khoảng **308 mOsm/L**, xấp xỉ huyết tương. Dung dịch này **đẳng trương**.
- Dùng để: truyền tĩnh mạch bù nước và điện giải, rửa vết thương, nhỏ mắt, mũi, pha thuốc tiêm.
- Dung dịch **ưu trương** (NaCl 3%) kéo nước ra khỏi tế bào; **nhược trương** làm tế bào (hồng cầu) trương lên và có thể vỡ (tan máu).

### 6.4. Muối bị thủy phân — vì sao dung dịch muối có pH khác 7

Ion của **acid yếu** hoặc **base yếu** phản ứng với nước (thủy phân), làm dung dịch lệch khỏi trung tính:

| Muối tạo bởi | Ion bị thủy phân | Môi trường | Ví dụ |
|---|---|---|---|
| Acid mạnh + base mạnh | Không có | **Trung tính** (pH ≈ 7) | NaCl, KNO~3~, Na~2~SO~4~ |
| Acid yếu + base mạnh | Anion (CO~3~^2−^, HCO~3~^−^, CH~3~COO^−^) | **Kiềm** | Na~2~CO~3~, NaHCO~3~, CH~3~COONa |
| Acid mạnh + base yếu | Cation (NH~4~^+^, Al^3+^, Fe^3+^) | **Acid** | NH~4~Cl, phèn chua, FeCl~3~ |

=> CO~3~^2−^ + H~2~O ⇌ HCO~3~^−^ + OH^−^

=> NH~4~^+^ + H~2~O ⇌ NH~3~ + H~3~O^+^

=> Al^3+^ + 3H~2~O ⇌ Al(OH)~3~ + 3H^+^

Phương trình cuối giống cách giáo trình giải thích tác dụng làm trong nước của phèn nhôm (đáp án câu 2.8, tr. 243).

> [!ung-dung] Thủy phân muối trong điều trị
> - **NaHCO~3~** truyền tĩnh mạch (dung dịch 1,4% hoặc 8,4%) dùng điều chỉnh **toan chuyển hóa** nặng. Dung dịch NaHCO~3~ cũng dùng súc miệng, rửa trong nấm miệng vì có tính kiềm nhẹ.
> - **NH~4~Cl** từng được dùng làm thuốc **acid hóa** nước tiểu và long đờm.
> - **Dung dịch Ringer lactat**: ion lactat được gan chuyển hóa thành HCO~3~^−^, nên dịch truyền này giúp bù kiềm nhẹ.
> - Nước **Javel** (NaOCl) và **clorua vôi** sát khuẩn, tẩy uế; **KMnO~4~** (thuốc tím) sát khuẩn ngoài da nhờ tính oxy hóa mạnh.

## Tóm tắt

| | Định nghĩa | Phân loại | Tính chất chính | Điều chế |
|---|---|---|---|---|
| **Oxide** | O + nguyên tố khác | Base, acid, lưỡng tính, trơ | Oxide base + acid; oxide acid + base; lưỡng tính + cả hai | Đốt nguyên tố; acid oxy hóa + KL/PK; nhiệt phân |
| **Acid** | Nhường H^+^ | Không oxy / có oxy | + base, oxide base; + kim loại (H~2~ hoặc sản phẩm khử gốc acid); trao đổi | H~2~ + Cl~2~; oxide acid + H~2~O; điện phân muối |
| **Base** | Nhận H^+^ | Tan (kiềm) / không tan | + acid, oxide acid, oxide lưỡng tính; + Zn, Al, Cl~2~; trao đổi; nhiệt phân | KL kiềm, kiềm thổ hoặc oxide + H~2~O; muối + kiềm; điện phân NaCl có màng ngăn |
| **Muối** | Thay H^+^ bằng cation / OH^−^ bằng anion | Trung tính, acid, base, kép, hỗn hợp | + KL, PK (thế); trao đổi; nhiệt phân | 5 nhóm phản ứng |

- Phản ứng trao đổi cần tạo **↓, ↑ hoặc H~2~O**.
- Nhận biết: **Ba^2+^ → SO~4~^2−^**; **Ag^+^ → Cl^−^**; **nước vôi trong → CO~2~**; **kiềm → NH~4~^+^** (NH~3~ bay ra).
- Y học: HCl dịch vị pH 1,5–3,5; antacid (NaHCO~3~, CaCO~3~, Mg(OH)~2~, Al(OH)~3~); **BaSO~4~ cản quang, không dùng BaCO~3~**; NaCl 0,9% đẳng trương.

> [!vi-du] Câu tự lượng giá 5.1 của giáo trình — Hydro
> Câu 5.1 (tr. 72) hỏi về hydro, đáp án ở tr. 249:
> - Tính chất hóa học điển hình của hydro là **tính khử**:
>
> => N~2~ + 3H~2~ ⇌ 2NH~3~ (xúc tác, t°, p)
>
> => H~2~ + CuO → Cu + H~2~O (t°)
>
> - **Hydro mới sinh** (hydro nguyên tử, H) hoạt động mạnh hơn **hydro phân tử** (H~2~), khử được nhiều chất ngay ở nhiệt độ thường. *Vì sao?* Muốn H~2~ phản ứng, trước hết phải tốn năng lượng phá liên kết H–H bền (khoảng 436 kJ/mol). Hydro nguyên tử vừa sinh ra (ví dụ từ Zn + HCl) không cần bước này.
>
> => MnO~4~^−^ + 5H + 3H^+^ → Mn^2+^ + 4H~2~O
>
> => C~6~H~5~NO~2~ + 6H → C~6~H~5~NH~2~ + 2H~2~O (nitrobenzen → anilin)
>
> - Lưu ý: đáp án cuối sách in "3H~2~ + N~2~ → 3NH~3~"; đúng phải là **2NH~3~**.
> - Các câu 5.2–5.5 (định nghĩa, phân loại oxide, acid, base, muối, cho ví dụ) xem các bảng ở mục 1–4.
