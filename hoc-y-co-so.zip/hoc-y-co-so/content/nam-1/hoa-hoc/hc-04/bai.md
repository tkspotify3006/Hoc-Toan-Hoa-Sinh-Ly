---
title: Phản ứng của hợp chất hữu cơ
thoi-gian: 45 phút
muc-tieu:
- Phân loại được phản ứng hữu cơ theo kiểu biến đổi (thế, cộng, tách loại, oxy hóa–khử, chuyển vị) và nêu được ba đặc điểm chung của phản ứng hữu cơ.
- Phân biệt được phân cắt đồng li và dị li; gốc tự do, carbocation, carbanion; tác nhân nucleophil, electrophil và gốc.
- Trình bày tóm tắt được cơ chế các phản ứng S~R~, S~N~1, S~N~2, S~E~, A~N~, A~E~ và E (E1, E2).
- Phát biểu và cho ví dụ được quy tắc thế vào vòng benzen, quy tắc Markovnikov, Zaicev, Hofmann.
- Giải thích được cơ chế gốc tự do của sự peroxy hóa lipid và vai trò của chất chống oxy hóa.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Bốn kiểu chính: **thế (S)**, **cộng (A)**, **tách loại (E)**, **chuyển vị**; nhiều phản ứng đồng thời là **oxy hóa–khử**. Phản ứng hữu cơ thường **chậm, thuận nghịch, nhiều sản phẩm**.
> 2. Cắt **đồng li** → **gốc tự do** (cơ chế gốc); cắt **dị li** → **carbocation R^+^ / carbanion R^−^** (cơ chế ion). Tác nhân **nucleophil** giàu electron, **electrophil** thiếu electron.
> 3. **S~R~**: alkan + Cl~2~/Br~2~, ánh sáng, chuỗi 3 giai đoạn. **S~N~1**: qua carbocation, bậc nhất, racemic (bậc III). **S~N~2**: một giai đoạn, bậc hai, **nghịch đảo cấu hình** (bậc I).
> 4. **S~E~**: vòng thơm, qua **phức σ**; nhóm loại I định hướng **o, p**, loại II định hướng **m**. **A~N~**: nhóm C=O. **A~E~**: C=C, theo **Markovnikov** (qua carbocation bền hơn).
> 5. Tách loại: **Zaicev** (alken nhiều nhóm thế) với X trung hòa; **Hofmann** (alken ít nhóm thế) với X mang điện dương, cồng kềnh. Gốc tự do + O~2~ → **peroxy hóa**; chất chống oxy hóa (phenol) **cắt mạch**.

## 1. Phân loại phản ứng hữu cơ

Giáo trình phân loại theo **cách phân tử chất phản ứng biến đổi** (Giáo trình tr. 108–109).

### 1.1. Phản ứng thế (S — Substitution)

Một nguyên tử hay nhóm nguyên tử trong phân tử bị **thay** bằng một nguyên tử hay nhóm khác.

=> CH~4~ + Cl~2~ → CH~3~Cl + HCl  (ánh sáng)

=> C~6~H~6~ + HNO~3~ → C~6~H~5~NO~2~ + H~2~O  (H~2~SO~4~ đặc, t°)

Sơ đồ chung: **RX + Y → RY + X**. Trong đó:

- **X** là nhóm **bị thế** (ở hai ví dụ trên là H);
- **R** là **trung tâm phản ứng** (CH~3~–, C~6~H~5~–);
- **Y** là **tác nhân thế** (Cl•, ^+^NO~2~).

**Trùng ngưng** thực chất là chuỗi phản ứng thế nối tiếp nhau.

### 1.2. Phản ứng cộng (A — Addition)

Hai phân tử **kết hợp** thành một phân tử mới. Phản ứng xảy ra ở liên kết bội (C=C, C≡C, C=O), vì liên kết π kém bền, dễ đứt.

=> CH~2~=CH~2~ + Cl~2~ → Cl–CH~2~–CH~2~–Cl

=> HCHO + H~2~ → CH~3~OH  (Ni, t°)

**Trùng hợp** thực chất là chuỗi phản ứng cộng nối tiếp nhau.

### 1.3. Phản ứng tách loại (E — Elimination)

Hai nguyên tử hay nhóm nguyên tử **tách ra** khỏi phân tử, **không có** nhóm nào thế vào. Thường tạo thêm một liên kết bội.

=> CH~3~–CH~3~ → CH~2~=CH~2~ + H~2~  (xúc tác, t°)

=> CH~3~–CH~2~–OH → CH~2~=CH~2~ + H~2~O  (H~2~SO~4~ đặc, 170 °C)

**Cracking** (bẻ gãy mạch dầu mỏ) thực chất cũng là phản ứng tách loại.

### 1.4. Phản ứng oxy hóa–khử

Đây **không phải** một kiểu biến đổi riêng. Nhiều phản ứng thế, cộng, tách được xếp thêm vào nhóm oxy hóa–khử, vì có **số oxy hóa của carbon thay đổi**.

=> CH~3~–CHO + H~2~ → CH~3~–CH~2~OH  (Ni, t°)

C của nhóm –CHO từ **+1** xuống **−1** → bị khử.

=> CH~2~=CH~2~ + [O] + H~2~O → HOCH~2~–CH~2~OH  (KMnO~4~ loãng)

Mỗi C từ **−2** lên **−1** → bị oxy hóa.

> [!vi-du] Tính nhanh số oxy hóa của một carbon
> Xét từng liên kết của C đó: mỗi liên kết với nguyên tố âm điện hơn (O, N, halogen) tính **+1**; mỗi liên kết với H tính **−1**; liên kết C–C tính **0**. Ví dụ nhóm –CHO: liên kết đôi với O (+2), một H (−1), một C (0) → **+1**. Nhóm –CH~2~OH: một O (+1), hai H (−2), một C (0) → **−1**.

### 1.5. Phản ứng chuyển vị

Một nguyên tử hay nhóm nguyên tử **đổi chỗ** trong cùng phân tử. Có hai nhóm:

- **Không đổi bộ khung carbon.** Ví dụ (xúc tác H^+^): nhóm –OH và liên kết đôi cùng dịch chuyển. Sản phẩm bền hơn vì C=C mới **liên hợp** với vòng benzen.

=> C~6~H~5~–CH(OH)–CH=CH~2~ → C~6~H~5~–CH=CH–CH~2~OH  (H^+^)

- **Làm thay đổi bộ khung.** Ví dụ chuyển vị **Beckmann**: oxim chuyển thành amid trong môi trường acid; một nhóm R chuyển từ C sang N.

=> R(R′)C=N–OH → R–CO–NH–R′  (H^+^)

| Kiểu | Ký hiệu | Bản chất | "Phản ứng lớn" tương ứng |
|---|---|---|---|
| Thế | S | Thay nhóm này bằng nhóm khác | Trùng ngưng |
| Cộng | A | Hai phân tử thành một, mất liên kết π | Trùng hợp |
| Tách loại | E | Bớt hai nhóm, thêm liên kết π | Cracking |
| Oxy hóa–khử | — | Số oxy hóa của C thay đổi | (chồng lên ba kiểu trên) |
| Chuyển vị | — | Nhóm đổi chỗ trong phân tử | Có / không đổi khung C |

## 2. Đặc điểm của phản ứng hữu cơ

Giáo trình nêu ba đặc điểm (Giáo trình tr. 109):

1. **Chậm**: đa số phản ứng diễn ra với tốc độ đo được, không tức thời.
2. **Không hoàn toàn**: thường dừng ở một **cân bằng thuận nghịch**, hiệu suất chỉ khoảng **60–80%**.
3. **Nhiều hướng**: phản ứng không đi theo một hướng duy nhất, nên tạo **hỗn hợp sản phẩm**.

**Vì sao?** Phản ứng vô cơ trong dung dịch thường là phản ứng giữa các **ion** có sẵn, chúng gặp nhau là phản ứng ngay (Ag^+^ + Cl^−^ → AgCl tức thì). Hợp chất hữu cơ chủ yếu có **liên kết cộng hóa trị**. Muốn phản ứng, phải **phá liên kết cũ**, tốn năng lượng hoạt hóa. Phân tử lại lớn, có nhiều vị trí có thể bị tấn công, nên dễ sinh nhiều sản phẩm.

> [!ung-dung] Vì sao thuốc tổng hợp phải tinh chế và kiểm tạp chất?
> Hiệu suất không tuyệt đối và có sản phẩm phụ, nên mọi nguyên liệu làm thuốc đều phải qua tinh chế. Dược điển quy định giới hạn **tạp chất liên quan** cho từng hoạt chất. Đó là hệ quả trực tiếp của đặc điểm 2 và 3.

## 3. Khái niệm về cơ chế phản ứng

**Cơ chế phản ứng** là "con đường chi tiết" từ chất đầu đến sản phẩm. Nó cho biết phản ứng gồm mấy giai đoạn, liên kết nào đứt và đứt theo cách nào, liên kết nào hình thành, đi qua chất trung gian hay trạng thái chuyển tiếp nào (Giáo trình tr. 110).

### 3.1. Phân cắt liên kết và các tiểu phân phản ứng

**Phân cắt đồng li** (homolytic): cặp electron liên kết được **chia đôi**, mỗi bên giữ 1 electron. Sinh ra **gốc tự do**, là tiểu phân có **electron độc thân**, ký hiệu bằng dấu chấm.

=> Cl–Cl → Cl• + Cl•  (ánh sáng hν)

=> CH~3~–H → •CH~3~ + H•

Phân cắt đồng li thường gặp ở liên kết **ít phân cực**, khi có **ánh sáng, nhiệt độ cao, peroxid**.

**Phân cắt dị li** (heterolytic): cặp electron liên kết thuộc **hẳn về một bên**. Sinh ra hai ion trái dấu.

- Ion có C mang điện **dương** là **carbocation** (R^+^):

=> (CH~3~)~3~C–Br → (CH~3~)~3~C^+^ + Br^−^

- Ion có C mang điện **âm** là **carbanion** (R^−^):

=> (p-NO~2~C~6~H~4~)~3~C–H + OH^−^ → (p-NO~2~C~6~H~4~)~3~C^−^ + H~2~O

Phân cắt dị li thường gặp ở liên kết **phân cực**, trong **dung môi phân cực**. Carbocation và carbanion đóng vai trò quan trọng trong các phản ứng thế, cộng và tách loại.

| | **Gốc tự do** R• | **Carbocation** R^+^ | **Carbanion** R^−^ |
|---|---|---|---|
| Sinh ra do | Cắt đồng li | Cắt dị li | Cắt dị li |
| Số electron lớp ngoài của C | 7 (1 electron độc thân) | 6 (thiếu electron) | 8 (có cặp electron tự do) |
| Hình dạng | Gần phẳng | **Phẳng** (sp²) | Tháp (gần sp³) |
| Được làm bền bởi | Nhóm đẩy electron, liên hợp | Nhóm **đẩy** electron (+I, +C) | Nhóm **hút** electron (−I, −C) |
| Độ bền theo bậc | III > II > I > CH~3~• | III > II > I > CH~3~^+^ | CH~3~^−^ > I > II > III |

> [!vi-du] Tự lượng giá 4.7 — sắp xếp độ bền
> - Carbocation: CH~3~^+^ < CH~3~CH~2~^+^ < CH~3~C^+^HCH~3~ < (CH~3~)~3~C^+^. Mỗi nhóm CH~3~ đẩy electron (+I), "san sẻ" bớt điện tích dương, nên càng nhiều nhóm CH~3~ càng bền.
> - Gốc tự do xếp theo **cùng thứ tự** đó: •CH~3~ < CH~3~CH~2~• < (CH~3~)~2~CH• < (CH~3~)~3~C•.
> - Carbanion: CH~3~CH~2~^−^ < CCl~3~CH~2~^−^ < CF~3~CH~2~^−^. Nhóm hút electron (−I) kéo bớt điện tích âm; F hút mạnh hơn Cl, nên CF~3~CH~2~^−^ bền nhất.
> (Giáo trình tr. 121, đáp án tr. 251.)

Hiệu ứng cảm ứng (I) và liên hợp (C) đã học ở bài Hiệu ứng cấu trúc là công cụ giải thích chính cho các thứ tự này.

### 3.2. Tác nhân phản ứng và các kiểu cơ chế

Cơ chế được gọi tên theo **loại tác nhân tấn công** vào chất phản ứng ở **giai đoạn chậm** (giai đoạn quyết định tốc độ) (Giáo trình tr. 110–111).

| Tác nhân | Đặc điểm | Ví dụ | Tấn công vào |
|---|---|---|---|
| **Nucleophil** (ái nhân) | Giàu electron: anion hoặc phân tử có **cặp electron tự do** | OH^−^, CN^−^, C~2~H~5~O^−^, Cl^−^, Br^−^, I^−^, H~2~O, NH~3~ | Nguyên tử mang **điện dương** (C^δ+^) |
| **Electrophil** (ái electron) | **Thiếu** electron: cation hoặc tiểu phân mang một phần điện dương | H^+^, ^+^NO~2~, Br^+^, R^+^, (Br^δ+^ của Br~2~ bị phân cực) | Nơi **giàu electron**: liên kết π, vòng thơm |
| **Gốc tự do** | Có electron độc thân | Cl•, Br•, •CH~3~ | Liên kết ít phân cực (C–H của alkan) |

Ví dụ của giáo trình:

- Cơ chế **nucleophil** (tác nhân là ^−^OC~2~H~5~):

=> CH~3~–I + ^−^OC~2~H~5~ → CH~3~–O–C~2~H~5~ + I^−^

- Cơ chế **electrophil** (tác nhân là ^+^NO~2~):

=> C~6~H~5~–H + ^+^NO~2~ → C~6~H~5~–NO~2~ + H^+^

- Cơ chế **gốc** (tác nhân là Cl•):

=> CH~4~ + Cl• → •CH~3~ + HCl

=> •CH~3~ + Cl~2~ → CH~3~Cl + Cl•

**Cách đọc ký hiệu cơ chế:** chữ hoa là kiểu phản ứng (S, A, E), chữ nhỏ dưới là loại tác nhân (R = gốc, N = nucleophil, E = electrophil), số cuối là **số phân tử** tham gia giai đoạn chậm (1 = đơn phân tử, 2 = lưỡng phân tử). Ví dụ S~N~2 = thế nucleophil lưỡng phân tử.

> [!bay]
> - Tên cơ chế đặt theo **tác nhân**, không theo chất phản ứng. "Thế electrophil" vào benzen nghĩa là **tác nhân** (^+^NO~2~) là electrophil; còn vòng benzen thì giàu electron.
> - H~2~O và NH~3~ trung hòa điện nhưng vẫn là **nucleophil** (có cặp electron tự do). Carbocation R^+^ là **electrophil**, còn carbanion R^−^ là **nucleophil**.
> - Trong "E" của S~E~, A~E~, chữ E nghĩa là **electrophil**; còn E đứng một mình (E1, E2) là **tách loại** (elimination).

## 4. Cơ chế phản ứng thế

### 4.1. Thế theo cơ chế gốc tự do (S~R~)

Đây là phản ứng **đặc trưng của hydrocarbon no** (alkan). Quan trọng nhất là **halogen hóa**; nitro hóa alkan cũng theo cơ chế gốc. Phản ứng thế H của alkan bằng halogen chỉ thực hiện được với **clo hoặc brom**, khi **chiếu sáng** (Giáo trình tr. 111–112).

=> R–H + X~2~ → R–X + HX  (ánh sáng hν)

Phản ứng là một **chuỗi** gồm 3 giai đoạn:

1. **Khơi mào**: ánh sáng cắt đồng li X~2~ → 2X•.
2. **Phát triển mạch** (dây chuyền):
   - X• + R–H → R• + HX  (**chậm**, quyết định tốc độ)
   - R• + X–X → R–X + X•
   
   X• mới sinh ra lại tấn công R–H tiếp. Vòng này lặp lại rất nhiều lần; với CH~4~, giáo trình ghi khoảng **10 000 lần** cho mỗi lần khơi mào.
3. **Tắt mạch**: hai gốc gặp nhau và kết hợp: X• + X• → X~2~; X• + R• → R–X; R• + R• → R–R.

**Hệ quả:**

- Sản phẩm là **hỗn hợp phức tạp** (thế 1, 2, 3… nguyên tử H; có cả R–R do tắt mạch).
- Gốc R• có cấu trúc **phẳng**, X~2~ tấn công từ hai phía với xác suất gần như nhau. Vì vậy nếu R–H quang hoạt (và phản ứng xảy ra ở C\*), sản phẩm là **hỗn hợp racemic**.
- H ở carbon bậc cao bị thế **dễ hơn**, vì gốc tự do bậc cao bền hơn.

> [!vi-du] Tự lượng giá 4.1 — propan + Cl~2~ (ánh sáng)
> - Khơi mào: Cl~2~ → 2Cl•
> - Phát triển mạch: Cl• lấy H của CH~3~ (tạo CH~3~CH~2~CH~2~•) hoặc H của CH~2~ (tạo CH~3~C•HCH~3~, bậc II, bền hơn). Gốc đó lấy Cl của Cl~2~ → **1-cloropropan** và **2-cloropropan**, sinh lại Cl•.
> - Tắt mạch: Cl• + Cl•, Cl• + R•, R• + R• (ví dụ tạo hexan hoặc 2,3-dimethylbutan).
> - Propan có 6 H bậc I nhưng chỉ 2 H bậc II, vậy mà **2-cloropropan vẫn chiếm phần hơn**: mỗi H bậc II phản ứng nhanh hơn mỗi H bậc I vài lần. Brom kém hoạt động nên **chọn lọc hơn nhiều**, gần như chỉ thế vào C bậc cao.

> [!ung-dung] Cloroform phải đựng chai tối màu
> Dưới ánh sáng và có O~2~, cloroform (CHCl~3~) bị oxy hóa theo cơ chế gốc, tạo **phosgen COCl~2~** rất độc. Vì vậy cloroform dược dụng được đựng trong **chai màu nâu, đầy, kín**, và thêm một lượng nhỏ **ethanol** để bẫy phosgen sinh ra. Đây cũng là lý do nhiều thuốc phải "tránh ánh sáng": ánh sáng là tác nhân khơi mào gốc tự do.

### 4.2. Thế nucleophil (S~N~)

Sơ đồ chung (Giáo trình tr. 112):

=> R–X + Y^−^ → R–Y + X^−^

- **Y** (nucleophil): anion hoặc phân tử trung hòa có cặp electron tự do: Cl^−^, Br^−^, I^−^, OH^−^, CN^−^, NH~3~…
- **X** (nhóm bị thế, nhóm đi ra): nhóm **hút electron** làm C gắn với nó mang điện dương một phần: –Cl, –Br, –I, –OH, –N^+^R~3~…

Dựa vào **số tiểu phân tham gia giai đoạn quyết định tốc độ**, chia thành S~N~1 và S~N~2.

![Hình 1. So sánh cơ chế SN2 (một giai đoạn, nghịch đảo cấu hình) và SN1 (qua carbocation phẳng, racemic hóa)](sn1-sn2.svg)

#### a) S~N~1 — thế nucleophil đơn phân tử

Hai giai đoạn **không đồng thời**: X tách ra trước (mang theo cặp electron của liên kết C–X), tạo **carbocation** trung gian; sau đó Y^−^ mới tấn công. Ví dụ thủy phân tert-butyl bromid (Giáo trình tr. 112–113):

=> (CH~3~)~3~C–Br → (CH~3~)~3~C^+^ + Br^−^  (chậm)

=> (CH~3~)~3~C^+^ + HO^−^ → (CH~3~)~3~C–OH  (nhanh)

- Giai đoạn chậm chỉ có **một** phân tử RX, nên tốc độ là **bậc một**: **v = k[t-C~4~H~9~Br]**. Thay đổi nồng độ OH^−^ không làm phản ứng nhanh lên.
- Carbocation **phẳng**, Y^−^ tấn công **hai mặt** với khả năng như nhau → nếu RX quang hoạt, sản phẩm là **hỗn hợp racemic**.

#### b) S~N~2 — thế nucleophil lưỡng phân tử

**Một giai đoạn**, đi qua **trạng thái chuyển tiếp**, không tạo chất trung gian. Y^−^ tấn công C^δ+^ **đồng thời** với lúc X tách ra. Ví dụ thủy phân methyl iodid bằng NaOH (Giáo trình tr. 113):

=> HO^−^ + CH~3~–I → [HO···CH~3~···I]^−^ → HO–CH~3~ + I^−^

(Chất trong ngoặc vuông là trạng thái chuyển tiếp.)

- Cả RX và Y^−^ cùng có mặt ở giai đoạn quyết định tốc độ → tốc độ **bậc hai**: **v = k[CH~3~I][HO^−^]**.
- Vì liên kết cũ đứt và liên kết mới hình thành cùng lúc, Y^−^ phải tấn công **từ phía sau**, ngược hướng với X. Ba nhóm còn lại "lật" như chiếc ô bị gió thổi ngược. Nếu RX quang hoạt, sản phẩm có **cấu hình ngược lại** (nghịch đảo Walden).

| | **S~N~1** | **S~N~2** |
|---|---|---|
| Số giai đoạn | 2 | 1 |
| Qua | **Carbocation** (chất trung gian) | **Trạng thái chuyển tiếp** |
| Phương trình tốc độ | v = k[RX] (bậc 1) | v = k[RX][Y^−^] (bậc 2) |
| Lập thể (RX quang hoạt) | **Racemic hóa** | **Nghịch đảo cấu hình** |
| Gốc R thuận lợi | **Bậc III** (và benzyl) | **Bậc I** (và CH~3~) |
| Dung môi (theo giáo trình) | Phân cực | Ít phân cực / không phân cực |
| Ví dụ của sách | (CH~3~)~3~C–Br + HO^−^ | CH~3~–I + HO^−^ |

#### c) Yếu tố quyết định S~N~1 hay S~N~2

Phụ thuộc vào cấu tạo gốc R, bản chất nhóm X, tác nhân Y, dung môi… **Quan trọng nhất là cấu tạo gốc R** (Giáo trình tr. 113–114):

- X gắn với C **bậc I** (RCH~2~–X): chủ yếu **S~N~2**.
- X gắn với C **bậc III** (R~3~C–X): chủ yếu **S~N~1**.
- X gắn với C **bậc II** (R~2~CH–X): theo S~N~1 hoặc S~N~2 tùy cấu trúc và **dung môi**. Theo giáo trình, dung môi phân cực ưu tiên S~N~1, dung môi ít phân cực ưu tiên S~N~2.

**Vì sao?** Hai lý do cùng chiều:

- Carbocation bậc III **bền** (ba nhóm alkyl đẩy electron), nên dễ hình thành → S~N~1 thuận lợi. Carbocation bậc I rất kém bền, khó hình thành.
- Ba nhóm alkyl quanh C bậc III **che chắn** mặt sau, nucleophil khó chen vào → S~N~2 bị cản. C bậc I "thoáng", nucleophil dễ tiếp cận từ phía sau.

**Ảnh hưởng của gốc thơm:**

- **Benzyl halogenid** C~6~H~5~–CH~2~–X **dễ** bị thế, vì cation benzyl C~6~H~5~–CH~2~^+^ được vòng benzen làm bền (điện tích dương giải tỏa vào vòng).
- **Aryl halogenid** C~6~H~5~–X (X gắn trực tiếp vào vòng) **rất khó** bị thế. Cặp electron tự do của X liên hợp với vòng (hiệu ứng **+C**), làm liên kết C–X ngắn và bền hơn; hiệu ứng −I của X lại ngược chiều với +C. Kết quả: liên kết C–X kém phân cực hẳn.

**Ảnh hưởng của nhóm X** (khi R không đổi): khả năng bị thế giảm dần theo **I > Br > Cl >> F**. Nguyên tử X càng lớn, liên kết C–X càng dài và yếu, X càng dễ tách ra.

**Khi X là –OH**: –OH là nhóm đi ra rất kém (OH^−^ là base mạnh). Phải làm phản ứng trong **acid mạnh** để proton hóa –OH thành –OH~2~^+^; khi đó nhóm tách ra là phân tử H~2~O trung hòa, rất dễ đi.

=> (CH~3~)~3~C–OH + HCl → (CH~3~)~3~C–Cl + H~2~O  (S~N~1, Tự lượng giá 4.10d)

> [!cap-nhat] Dung môi trong S~N~1 / S~N~2
> Giáo trình ghi: dung môi phân cực ưu tiên S~N~1, dung môi ít phân cực ưu tiên S~N~2. Hiện nay người ta phân biệt rõ hơn: dung môi **phân cực có proton** (nước, alcol) ưu tiên **S~N~1**, vì chúng solvat hóa tốt cả carbocation lẫn anion đi ra. Dung môi **phân cực không có proton** (aceton, DMSO, DMF) lại ưu tiên **S~N~2**, vì chúng không "bọc" nucleophil bằng liên kết hydro nên nucleophil hoạt động mạnh hơn. Đi thi trả lời theo giáo trình.

> [!bay] Tự lượng giá 4.2
> - CH~3~–CH~2~Cl + NaOH (nước, đun nóng) → CH~3~CH~2~OH + NaCl: bậc I → **S~N~2**.
> - (CH~3~)~3~C–Cl + NaOH (nước, đun nóng) → (CH~3~)~3~C–OH + NaCl: bậc III → **S~N~1**.
> - Đáp án sách: a) S~N~2, b) S~N~1. Lưu ý thực tế: dẫn xuất bậc III gặp **base mạnh, đặc, nóng** thì phản ứng **tách loại** (tạo isobutylen) cạnh tranh mạnh với thế (xem mục 6.3).

> [!ung-dung] Thuốc alkyl hóa và phản ứng methyl hóa trong cơ thể
> - **Thuốc chống ung thư nhóm alkyl hóa** (mù tạt nitơ: cyclophosphamid, melphalan…) mang nhóm –CH~2~CH~2~Cl. Trong cơ thể chúng tạo trung tâm carbon thiếu electron; **nguyên tử N7 của guanin** trong DNA (ADN) đóng vai trò nucleophil tấn công vào đó. DNA bị gắn chéo, tế bào ung thư không nhân lên được. Cùng cơ chế đó cũng gây độc cho tủy xương và niêm mạc.
> - **S-adenosylmethionin (SAM)** là "chất cho nhóm methyl" của tế bào. Enzym COMT methyl hóa catecholamin (adrenalin, dopamin); các enzym khác methyl hóa DNA. Các phản ứng này đều là **S~N~2** vào nhóm CH~3~ gắn với S^+^.

### 4.3. Thế electrophil vào vòng thơm (S~E~)

Đây là phản ứng **đặc trưng của hydrocarbon thơm và dị vòng thơm**. Vòng thơm có **mật độ electron π cao**, nên dễ phản ứng với tác nhân electrophil hơn là với nucleophil hay gốc tự do (Giáo trình tr. 114–115).

**Cơ chế (lưỡng phân tử, nhiều giai đoạn):**

1. Y^+^ tiến lại gần vòng, tạo **phức π** (tương tác lỏng lẻo với đám mây π).
2. Y^+^ liên kết hẳn với một C của vòng, tạo **phức σ**: một carbocation vòng, C bị tấn công chuyển thành sp³ (mang cả H và Y). **Giai đoạn chậm.** Điện tích dương phân bố chủ yếu ở các vị trí **2, 4, 6** so với C mang Y.
3. Phức σ **tách H^+^** (nhanh), khôi phục hệ thơm → sản phẩm thế.

Y^+^ có thể là ion dương thực sự (^+^NO~2~, R^+^…) hoặc tiểu phân chỉ mang một phần điện dương.

**Vì sao là "thế" chứ không phải "cộng"?** Nếu phức σ cộng tiếp Y^−^, vòng sẽ mất tính thơm. Tách H^+^ để **giữ lại hệ thơm bền vững** có lợi về năng lượng hơn nhiều.

**Ví dụ: brom hóa benzen** (Fe, đun nóng):

=> C~6~H~6~ + Br~2~ → C~6~H~5~Br + HBr  (Fe, t°)

Từng bước theo giáo trình:

=> 2Fe + 3Br~2~ → 2FeBr~3~

=> FeBr~3~ + Br~2~ → [FeBr~4~]^−^ + Br^+^  (tạo tác nhân electrophil)

=> C~6~H~6~ + Br^+^ → phức π → phức σ  (chậm)

=> phức σ + [FeBr~4~]^−^ → C~6~H~5~Br + HBr + FeBr~3~  (nhanh)

> [!vi-du] Nitro hóa benzen — ^+^NO~2~ từ đâu ra?
> Hỗn hợp HNO~3~ đặc và H~2~SO~4~ đặc tạo ra ion nitroni:
>
> => HNO~3~ + 2H~2~SO~4~ ⇌ ^+^NO~2~ + H~3~O^+^ + 2HSO~4~^−^
>
> H~2~SO~4~ mạnh hơn, proton hóa HNO~3~ rồi tách nước, để lại ^+^NO~2~ là electrophil mạnh. Vì vậy "hỗn hợp sulfonitric" nitro hóa benzen tốt hơn HNO~3~ một mình.

> [!cap-nhat] Br^+^ có thật sự tự do?
> Giáo trình viết FeBr~3~ + Br~2~ tạo ra ion Br^+^ riêng rẽ. Hiện nay người ta cho rằng ion Br^+^ tự do hầu như không tồn tại. FeBr~3~ (acid Lewis) chỉ **phân cực mạnh** phân tử Br~2~ thành phức Br^δ+^–Br–FeBr~3~^δ−^, và đầu Br^δ+^ của phức này tấn công vòng. Kết quả và sản phẩm không đổi. Đi thi trả lời theo giáo trình.

#### Quy tắc thế vào vòng benzen

Khi vòng đã có sẵn một nhóm thế, nhóm đó **định hướng** tác nhân tiếp theo vào vị trí xác định (Giáo trình tr. 115–116):

| | **Nhóm thế loại I** | **Nhóm thế loại II** |
|---|---|---|
| Định hướng | **ortho và para** | **meta** |
| Ví dụ | Alkyl (–CH~3~, –C~2~H~5~…), –OH, –NH~2~, halogen | –NO~2~, –CHO, –COOH… |
| Ảnh hưởng đến tốc độ | **Hoạt hóa** vòng (dễ thế hơn benzen), **trừ halogen** | **Phản hoạt hóa** (khó thế hơn benzen) |
| Hiệu ứng | +I hoặc +C: tăng mật độ electron, nhất là ở o, p | −C và −I mạnh: giảm mật độ electron, nhất là ở o, p |

Số liệu nitro hóa của giáo trình (lấy hằng số tốc độ của benzen k = 1):

| Chất | k (so với benzen) | % ortho | % meta | % para |
|---|---|---|---|---|
| Phenol C~6~H~5~OH | 1000 | 40 | — | 60 |
| Toluen C~6~H~5~CH~3~ | 25 | 56 | 3 | 41 |
| Benzen | 1 | — | — | — |
| Clorobenzen C~6~H~5~Cl | 3·10^−3^ | 30 | 1 | 69 |
| Nitrobenzen C~6~H~5~NO~2~ | 6·10^−8^ | 6 | **93** | 1 |

**Vì sao nhóm loại II lại cho meta?** Nhóm loại II làm **cả vòng** nghèo electron, nhưng nghèo nhất ở o và p. Vị trí meta **ít bị phản hoạt hóa nhất**, nên tác nhân "chọn" meta, dù vẫn khó hơn benzen rất nhiều.

> [!bay] Halogen — "ngoại lệ" của loại I
> Halogen có **−I > +C**, nên làm vòng **kém hoạt động** hơn benzen (clorobenzen k = 3·10^−3^). Nhưng nhờ **+C**, phức σ ở vị trí o và p được ổn định hơn phức σ ở meta. Vì thế halogen **phản hoạt hóa nhưng vẫn định hướng o, p**, và được xếp vào **loại I**.
>
> Tự lượng giá 4.6 — tăng dần khả năng thế electrophil: **C~6~H~5~NO~2~ < C~6~H~6~ < C~6~H~5~NH~2~**.

> [!vi-du] Tự lượng giá 4.3 — toluen + Cl~2~ (tỉ lệ mol 1 : 1)
> - **Chiếu sáng**: cơ chế **S~R~** ở **mạch nhánh** (gốc benzyl C~6~H~5~CH~2~• rất bền) → C~6~H~5~CH~2~Cl (benzyl clorid) + HCl.
> - **Bột sắt** (tạo FeCl~3~): cơ chế **S~E~** ở **vòng**; –CH~3~ là nhóm loại I → **o-clorotoluen** và **p-clorotoluen** + HCl.
> - Cách nhớ: "**ánh sáng → nhánh; sắt → vòng**".

> [!ung-dung] Tuyến giáp iod hóa vòng thơm của tyrosin
> Để tổng hợp hormon giáp, enzym **thyroperoxidase** oxy hóa I^−^ thành dạng iod mang tính electrophil, rồi gắn iod vào vòng phenol của **tyrosin** trong thyroglobulin. Nhóm –OH là nhóm thế loại I, nên iod vào vị trí **ortho so với –OH** (vị trí para đã có mạch nhánh), tạo monoiodotyrosin, diiodotyrosin, rồi T~3~, T~4~. Thuốc kháng giáp **propylthiouracil, methimazol** ức chế chính enzym này.

## 5. Cơ chế phản ứng cộng

### 5.1. Cộng nucleophil (A~N~)

Là phản ứng quan trọng của hợp chất có **nhóm carbonyl** C=O. Liên kết C=O **phân cực** mạnh: O hút electron, C mang δ+, nên nucleophil tấn công vào **C** (Giáo trình tr. 116–117).

Sơ đồ chung: R(R′)C=O + H–Y (hoặc X–Y) → R(R′)C(OH)–Y.

- H–Y: H–OH, H–OR, H–CN, H–NHR…
- X–Y: hợp chất cơ kim như RMgX, CH≡CNa…

**Hai giai đoạn:**

1. Nucleophil Y^−^ tấn công vào **C^δ+^** của nhóm carbonyl, tạo anion alkoxid R(R′)C(O^−^)Y. **Giai đoạn chậm**, quyết định tốc độ.
2. Anion này nhận **H^+^** (nhanh) → sản phẩm R(R′)C(OH)Y.

Vì giai đoạn chậm có cả chất phản ứng và tác nhân, A~N~ là phản ứng **lưỡng phân tử**.

=> CH~3~CHO + HCN → CH~3~CH(OH)CN  (môi trường kiềm; Tự lượng giá 4.10e)

**Vì sao HCN phải có kiềm?** HCN là acid rất yếu, phân li rất ít. Kiềm chuyển HCN thành ion CN^−^, chính CN^−^ mới là nucleophil tấn công C=O. Sản phẩm là **cyanohydrin** (2-hydroxypropannitril).

**Yếu tố ảnh hưởng đến khả năng phản ứng:**

- **Điện tích dương ở C của C=O**: gốc có hiệu ứng **−I** làm δ+ lớn hơn → phản ứng **dễ hơn**; gốc **+I** làm δ+ nhỏ đi → **khó hơn**.
- **Án ngữ không gian**: nucleophil thường cồng kềnh; gốc gắn với C=O càng lớn càng cản trở, đặc biệt khi có **hai gốc** (ceton). Vì vậy **aldehyd phản ứng dễ hơn ceton**.

> [!vi-du] Tự lượng giá 4.5 — khả năng cộng HCN tăng dần (đáp án tr. 251)
> - a) p-CH~3~–C~6~H~4~CHO < C~6~H~5~CHO < p-NO~2~–C~6~H~4~CHO. Nhóm –CH~3~ đẩy electron (giảm δ+); –NO~2~ hút electron mạnh (tăng δ+).
> - b) CH~3~COCH~3~ < CH~3~CHO < CH~2~ClCHO < CHCl~2~CHO < CCl~3~CHO. Ceton có hai gốc đẩy electron và cồng kềnh hơn nên yếu nhất; càng nhiều Cl (−I) thì C=O càng dương, càng dễ cộng.

> [!ung-dung] A~N~ quen thuộc trong cơ thể và trong dược liệu
> - Glucose **tự khép vòng** chính là phản ứng cộng nucleophil của nhóm –OH (C5) vào nhóm C=O (C1), tạo **hemiacetal** (xem bài Glucid).
> - Pyridoxal phosphat (vitamin B~6~) gắn vào acid amin (amino acid) bằng cách nhóm –NH~2~ cộng vào nhóm –CHO tạo **base Schiff (imin)**, bước đầu của phản ứng chuyển amin.
> - Glycosid sinh cyanid (amygdalin) khi bị thủy phân giải phóng **mandelonitril**, chính là cyanohydrin của benzaldehyd. Phản ứng cộng HCN là **thuận nghịch**, nên mandelonitril dễ phân hủy ngược lại thành benzaldehyd + **HCN** độc.

### 5.2. Cộng electrophil (A~E~)

Phản ứng của X–Y (H–Cl, H–OH, Cl~2~, Br~2~…) vào **liên kết đôi C=C** là ví dụ điển hình. Liên kết π giàu electron và dễ bị phân cực, nên tác nhân đầu tiên tấn công là **phần mang điện dương X^δ+^** (Giáo trình tr. 117–118).

**Nhiều giai đoạn:**

1. X^δ+^ (ví dụ H^+^) cộng vào một C của nối đôi, Y^−^ tách ra; tạo **carbocation** trung gian ở C còn lại. **Giai đoạn chậm.**
2. Carbocation nhanh chóng kết hợp với nucleophil Y^−^ → sản phẩm cộng.

**Quy tắc Markovnikov.** Khi alken **không đối xứng** cộng với H–A (H–Cl, H–OH…), phản ứng ưu tiên đi theo hướng tạo ra **carbocation trung gian bền hơn**. Hệ quả quen thuộc: H cộng vào C **có nhiều H hơn**, còn A cộng vào C **có ít H hơn** (bậc cao hơn).

![Hình 2. Cơ chế cộng electrophil HBr vào propen và quy tắc Markovnikov](ae-markovnikov.svg)

=> CH~3~–CH=CH~2~ + HBr → CH~3~–CHBr–CH~3~

Sản phẩm chính là **2-bromopropan** (khoảng 95%).

Lý do: H^+^ cộng vào CH~2~ đầu mạch tạo carbocation **bậc II** CH~3~–C^+^H–CH~3~, có hai nhóm CH~3~ đẩy electron, bền hơn carbocation **bậc I** CH~3~CH~2~CH~2~^+^.

**Yếu tố ảnh hưởng:**

- Nhóm thế **đẩy electron** gắn vào nối đôi: tăng mật độ electron của C=C và làm bền carbocation → phản ứng **dễ hơn**. Nhóm **hút electron**: ngược lại, **khó hơn**.
- **Halogen**: Br~2~ cộng **êm dịu, thuận lợi** (dùng nước brom nhận biết nối đôi). Cl~2~ có thể cộng hoặc gây **phản ứng hủy** (khi có tia lửa, chiếu sáng mạnh). I~2~ cộng **chậm, thuận nghịch**. F~2~ phản ứng **quá mãnh liệt**, thường gây hủy.
- **Hydrohalid**: acid càng mạnh và X^−^ càng nucleophil thì càng dễ cộng: **HI > HBr > HCl >> HF**.

> [!bay] Khi nối đôi gắn với nhóm hút electron hoặc halogen (Tự lượng giá 4.4, 4.8)
> - CH~2~=CH–CH~3~ + HCl → CH~3~–CHCl–CH~3~ (Markovnikov thông thường).
> - CH~2~=CH–Cl + HCl → **CH~3~–CHCl~2~** (1,1-dicloroethan). Cl có +C, làm bền carbocation ở chính C mang Cl, nên Cl thứ hai vào cùng C đó.
> - CH~2~=CH–COOH + HCl → **Cl–CH~2~–CH~2~–COOH**; CH~2~=CH–CHO + HBr → **Br–CH~2~–CH~2~–CHO**. Nhóm –COOH, –CHO hút electron (−C, −I) làm carbocation cạnh nó rất kém bền. H gắn vào C cạnh nhóm chức, halogen gắn vào C **đầu mạch**, nhìn bề ngoài **"ngược Markovnikov"**.
> - CH~3~–CH=CH–COOH + HCl → **CH~3~–CHCl–CH~2~–COOH** (Cl vào C xa nhóm –COOH).
> - Nguyên tắc chung không đổi: phản ứng đi qua **trung gian bền hơn**. "H vào C nhiều H" chỉ là hệ quả trong trường hợp alken mang nhóm alkyl.

> [!cap-nhat] Cộng Br~2~ và hiệu ứng peroxid
> - Giáo trình mô tả A~E~ của Br~2~ qua carbocation mở. Hiện nay người ta biết Br~2~ (và Cl~2~) cộng qua **ion bromoni vòng 3 cạnh**; Br^−^ phải tấn công từ **mặt đối diện**, nên hai nguyên tử Br vào hai phía của nối đôi (**cộng trans/anti**). Ví dụ cyclohexen + Br~2~ chỉ cho trans-1,2-dibromocyclohexan.
> - HBr khi có **peroxid** (hoặc ánh sáng) cộng theo **cơ chế gốc tự do**, cho sản phẩm **ngược Markovnikov** (CH~3~CH~2~CH~2~Br từ propen). Hiện tượng này (hiệu ứng Kharasch) chỉ gặp với HBr.
> Đi thi về A~E~ trả lời theo sơ đồ carbocation của giáo trình.

## 6. Cơ chế phản ứng tách loại (E)

### 6.1. Hướng tách — quy tắc Zaicev

Tách loại tạo C=C xảy ra phức tạp, theo nhiều cơ chế tùy chất phản ứng, tác nhân, nhiệt độ, dung môi. Dẫn xuất halogen **bậc I** thường cho **một** sản phẩm. Dẫn xuất **bậc II, III** có thể tách theo 2–3 hướng, tạo 2–3 alken đồng phân (Giáo trình tr. 118).

=> CH~3~–CH~2~–CHBr–CH~3~ → CH~3~–CH=CH–CH~3~ + HBr  (KOH/ethanol, t°)

Sản phẩm gồm **but-2-en 81%** và but-1-en CH~3~–CH~2~–CH=CH~2~ 19%.

**Quy tắc Zaicev:** nhóm X **không mang điện dương và không cồng kềnh** (–Cl, –Br, –OH…) tách ra chủ yếu cùng với **H ở carbon bậc cao hơn** bên cạnh. Sản phẩm chính là **alken có nhiều nhóm thế hơn** ở hai C của nối đôi.

**Vì sao?** Alken càng nhiều nhóm alkyl quanh nối đôi càng **bền** (các nhóm alkyl "nuôi" liên kết π bằng hiệu ứng siêu liên hợp). Trạng thái chuyển tiếp dẫn đến alken bền hơn cũng có năng lượng thấp hơn.

### 6.2. Quy tắc Hofmann

Nếu X **mang điện dương, kém hoạt động hoặc rất cồng kềnh** (–N^+^R~3~, –S^+^R~2~…), phản ứng tách chủ yếu tạo **alken có ít nhóm thế nhất**. Đây là **quy tắc Hofmann**, ngược với Zaicev (Giáo trình tr. 119).

=> [CH~3~CH~2~–N^+^(CH~3~)~2~–C~3~H~7~]OH^−^ → CH~2~=CH~2~ + (CH~3~)~2~N–C~3~H~7~ + H~2~O  (t°)

Ethylen chiếm **98%**. Sản phẩm phụ (2%) là propen CH~2~=CH–CH~3~ cùng (CH~3~)~2~N–C~2~H~5~.

**Vì sao?** Nhóm cồng kềnh che khuất các H ở carbon bậc cao; base dễ lấy H ở nhóm CH~3~ hoặc CH~2~ "thoáng" hơn. Nhóm –N^+^R~3~ hút electron mạnh cũng làm H ở C bậc thấp có tính acid hơn.

> [!vi-du] Tự lượng giá 4.9 (đáp án tr. 252)
> - a) CH~3~–CH(OH)–CH(CH~3~)~2~ (3-methylbutan-2-ol), tách nước → **CH~3~–CH=C(CH~3~)~2~** (2-methylbut-2-en). X = –OH trung hòa → **Zaicev**: H tách từ C bậc III.
> - b) (CH~3~)~2~CH–CH(N^+^(CH~3~)~3~)–CH~3~, đun nóng → **(CH~3~)~2~CH–CH=CH~2~** (3-methylbut-1-en). X = –N^+^(CH~3~)~3~ → **Hofmann**: H tách từ nhóm CH~3~.

### 6.3. Cơ chế E1 và E2 (bổ sung theo mục tiêu bài)

Giáo trình yêu cầu trình bày E1, E2 ở mục tiêu nhưng phần nội dung chỉ nêu các quy tắc. Tóm tắt hai cơ chế, song song với S~N~1 và S~N~2:

| | **E1** (tách loại đơn phân tử) | **E2** (tách loại lưỡng phân tử) |
|---|---|---|
| Giai đoạn | 2: X tách ra tạo **carbocation** (chậm), rồi mất H^+^ ở C bên cạnh (nhanh) | 1: base lấy H ở C bên cạnh **đồng thời** với lúc X tách ra |
| Tốc độ | v = k[RX] | v = k[RX][base] |
| Thuận lợi khi | RX **bậc III**, base yếu, dung môi phân cực | **Base mạnh, đặc**, đun nóng; mọi bậc |
| Cạnh tranh với | S~N~1 (cùng carbocation) | S~N~2 (cùng điều kiện, khác vị trí tấn công) |

Base tấn công vào **H** thì xảy ra **tách loại**; nucleophil tấn công vào **C** thì xảy ra **thế**. Cùng một tiểu phân như OH^−^ có thể làm cả hai việc, nên thế và tách luôn **cạnh tranh** nhau.

> [!bay] Thế hay tách? Nhìn điều kiện phản ứng
> - Dẫn xuất halogen + **NaOH/KOH trong nước**, nhiệt độ vừa phải → ưu tiên **thế** → alcol.
> - Dẫn xuất halogen + **KOH trong ethanol**, đun nóng → ưu tiên **tách** → alken.
> - Ethanol + H~2~SO~4~ đặc: ở **170 °C** tách nội phân tử → ethylen; ở **140 °C** tách giữa hai phân tử → diethyl ether.
> - Nhiệt độ cao, base mạnh và cồng kềnh, gốc R bậc cao → nghiêng về **tách**.

## 7. Phản ứng oxy hóa–khử

Phản ứng oxy hóa–khử của hợp chất hữu cơ có mấy đặc điểm sau (Giáo trình tr. 119–120).

**a) Liên kết C–H bị oxy hóa có chọn lọc**, phụ thuộc rõ vào nhóm bên cạnh:

- Ethan + dung dịch KMnO~4~ (H^+^): **không phản ứng**.
- Toluen + dung dịch KMnO~4~ (H^+^, đun nóng): C–H **cạnh vòng benzen** (vị trí benzyl) bị oxy hóa → **acid benzoic**.

=> 5C~6~H~5~CH~3~ + 6KMnO~4~ + 9H~2~SO~4~ → 5C~6~H~5~COOH + 3K~2~SO~4~ + 6MnSO~4~ + 14H~2~O

(C của –CH~3~ từ −3 lên +3, nhường 6e; Mn từ +7 xuống +2, nhận 5e.)

**b) Liên kết C=C, C≡C dễ bị oxy hóa; vòng thơm khó bị oxy hóa hơn nhiều.** Dung dịch KMnO~4~ trong môi trường kiềm không oxy hóa được vòng benzen, chỉ oxy hóa nối bội ở mạch nhánh:

=> C~6~H~5~–C≡CH → C~6~H~5~–COOH  ([O], KMnO~4~)

**c) Hướng phản ứng phụ thuộc vào tác nhân oxy hóa hay khử.** Với propen:

- KMnO~4~ loãng, lạnh → **propan-1,2-diol**:

=> 3CH~3~–CH=CH~2~ + 2KMnO~4~ + 4H~2~O → 3CH~3~–CH(OH)–CH~2~OH + 2MnO~2~ + 2KOH

- KMnO~4~/H^+^, đun nóng → **cắt mạch** tại nối đôi:

=> CH~3~–CH=CH~2~ → CH~3~–COOH + HCOOH  ([O], KMnO~4~/H^+^)

Với acid benzoic, tác nhân khử khác nhau khử vào chỗ khác nhau:

- H~2~/Pt khử **vòng**, tạo acid cyclohexancarboxylic:

=> C~6~H~5~–COOH + 3H~2~ → C~6~H~11~–COOH  (Pt, t°)

- LiAlH~4~ khử **nhóm –COOH**, tạo alcol benzylic:

=> C~6~H~5~–COOH → C~6~H~5~–CH~2~OH  (LiAlH~4~)

> [!cap-nhat] Sản phẩm cắt mạch propen
> Giáo trình ghi sản phẩm là CH~3~COOH + HCOOH. Thực tế với KMnO~4~/H^+^ đun nóng, **HCOOH bị oxy hóa tiếp thành CO~2~ + H~2~O**, vì nhóm =CH~2~ đầu mạch luôn chuyển hết thành CO~2~. Phương trình cân bằng:
>
> => 5CH~3~–CH=CH~2~ + 10KMnO~4~ + 15H~2~SO~4~ → 5CH~3~COOH + 5CO~2~ + 5K~2~SO~4~ + 10MnSO~4~ + 20H~2~O
>
> Đi thi trả lời theo giáo trình nếu câu hỏi bám sát sách.

**d) Oxy hóa theo cơ chế gốc tự do — tạo peroxid.** Hợp chất hữu cơ cũng có thể bị oxy hóa qua gốc tự do, thường sinh ra **hydroperoxid** ROOH:

=> R–H → R• + H•  (ánh sáng hν; khơi mào)

=> R• + O~2~ → R–O–O•  (gốc peroxyl)

=> R–O–O• + R–H → R–OOH + R•

R• mới lại kết hợp với O~2~, chuỗi cứ thế tiếp diễn.

Đây chính là sơ đồ dây chuyền của S~R~ (mục 4.1), chỉ khác là "X~2~" được thay bằng **O~2~**. Quá trình này gọi là **tự oxy hóa** (autoxidation).

## 8. Ứng dụng: gốc tự do, stress oxy hóa và chất chống oxy hóa

### 8.1. Gốc tự do trong cơ thể

Cơ thể liên tục sinh ra các **dạng oxy hoạt động** (ROS): gốc **superoxid** O~2~•^−^, gốc **hydroxyl** •OH (rất mạnh), cùng H~2~O~2~ (không phải gốc nhưng dễ sinh ra •OH). Nguồn chính là **ty thể** (chuỗi hô hấp rò rỉ electron), **bạch cầu** khi diệt khuẩn, tia xạ, khói thuốc lá, một số thuốc và chất độc.

Ở mức thấp, ROS có vai trò sinh lý (diệt khuẩn, truyền tín hiệu). Khi ROS **vượt quá** khả năng chống đỡ của cơ thể thì gọi là **stress oxy hóa**.

### 8.2. Peroxy hóa lipid — một phản ứng S~R~ trong màng tế bào

Acid béo **không no nhiều nối đôi** (LH) trong màng tế bào có các H ở nhóm CH~2~ nằm giữa hai nối đôi. Liên kết C–H ở đây **yếu**, vì gốc tạo thành được làm bền nhờ liên hợp. Chuỗi phản ứng đi đúng ba giai đoạn của mục 4.1 và 7d:

![Hình 3. Chuỗi peroxy hóa lipid theo cơ chế gốc tự do và vị trí cắt mạch của chất chống oxy hóa phenol](peroxy-hoa-lipid.svg)

- **Khơi mào**: •OH + LH → L• + H~2~O.
- **Phát triển mạch**: L• + O~2~ → LOO•;  LOO• + LH → LOOH + L• (một gốc khơi mào có thể phá hủy hàng loạt phân tử lipid).
- **Tắt mạch**: hai gốc kết hợp, hoặc **gặp chất chống oxy hóa**.

Hậu quả: màng tế bào mất tính toàn vẹn; LOOH phân hủy thành aldehyd độc như **malondialdehyd (MDA)**. MDA được dùng làm **chỉ dấu** đánh giá mức peroxy hóa lipid trong nghiên cứu. LDL bị oxy hóa là một mắt xích trong hình thành **vữa xơ động mạch**.

### 8.3. Chất chống oxy hóa hoạt động thế nào?

- **Enzym**: superoxid dismutase (SOD) chuyển O~2~•^−^ thành H~2~O~2~; catalase và glutathion peroxidase (cần selen) phân hủy H~2~O~2~ và LOOH.
- **Chất cắt mạch (chain-breaking)**, điển hình là **vitamin E** (α-tocopherol, một **phenol** tan trong lipid, nằm trong màng):

=> LOO• + ArOH → LOOH + ArO•

Gốc phenoxyl ArO• **bền**, vì electron độc thân được giải tỏa vào vòng benzen. Nó quá "lười" để lấy H của lipid khác, nên **chuỗi bị cắt**. **Vitamin C** (tan trong nước) khử ArO• trở lại vitamin E. **Glutathion** (GSH) tham gia khử peroxid.

**Vì sao phenol là cấu trúc chống oxy hóa kinh điển?** Liên kết O–H của phenol tương đối yếu, dễ nhường H•. Gốc sinh ra được vòng thơm làm bền. Phenol càng có nhiều –OH kề nhau (nhóm **catechol**, pyrogallol) thì khả năng bắt gốc tự do càng mạnh.

> [!ung-dung] Từ phòng thí nghiệm đến lâm sàng
> - **Ngộ độc paracetamol**: liều cao tạo nhiều chất chuyển hóa NAPQI, làm cạn **glutathion** ở gan, gây hoại tử tế bào gan. Thuốc giải là **N-acetylcystein**, bổ sung nguyên liệu để gan tái tạo glutathion.
> - **Lưu ý về viên bổ sung chống oxy hóa**: các thử nghiệm lâm sàng lớn với vitamin E, β-caroten liều cao **không giảm** bệnh tim mạch hay ung thư. β-caroten liều cao còn **làm tăng** ung thư phổi ở người hút thuốc. Cơ chế "bắt gốc tự do" đúng về hóa học không có nghĩa là uống càng nhiều càng tốt.

> [!yhct] Polyphenol, flavonoid của dược liệu — mạnh trong ống nghiệm, thận trọng khi suy rộng
> - Nhiều dược liệu giàu hợp chất **phenol nhiều nhóm –OH**: catechin, EGCG của **Chè xanh**; rutin, quercetin của **Hoa hòe**; baicalin của **Hoàng cầm**; acid salvianolic của **Đan sâm**; curcumin của **Nghệ**. Nhờ cấu trúc catechol/pyrogallol, chúng **bắt gốc tự do rất mạnh trong ống nghiệm** (thử nghiệm DPPH, ABTS…), theo đúng cơ chế cắt mạch ở trên.
> - **Mức bằng chứng:** phần lớn là **in vitro** và trên động vật. Trong cơ thể người, các chất này **hấp thu kém** và bị chuyển hóa nhanh (liên hợp glucuronid, sulfat). Nồng độ trong máu thấp hơn nhiều so với nồng độ thử trong ống nghiệm. Tác dụng thực tế (nếu có) có lẽ chủ yếu qua điều hòa enzym chống oxy hóa nội sinh, hơn là bắt gốc trực tiếp. **Chưa đủ bằng chứng lâm sàng** để xem "chống oxy hóa" là căn cứ chữa bệnh.
> - **An toàn:** chiết xuất chè xanh dạng viên liều cao (EGCG) đã có báo cáo **tổn thương gan**. Không nên quy đổi "uống nước chè" sang "uống viên cô đặc".

> [!yhct] Dầu, tinh dầu bị "ôi" cũng là phản ứng gốc tự do — hệ quả cho bảo quản
> Dầu béo không no và tinh dầu (terpen như limonen) bị **tự oxy hóa** theo đúng chuỗi R• + O~2~ → ROO• → ROOH ở mục 7d. Kết quả là mùi ôi khét, hoạt chất giảm, và sinh hydroperoxid có thể **gây dị ứng da** (hydroperoxid của limonen là chất gây dị ứng tiếp xúc đã được ghi nhận). Vì vậy các vị **nhiều dầu** như Bá tử nhân, Đào nhân, Hạnh nhân dễ "ra dầu", "hắc dầu"; dược liệu chứa tinh dầu cần đựng **kín, tránh ánh sáng, để nơi mát**. Ba điều kiện đó chính là loại bỏ O~2~ và các tác nhân khơi mào gốc tự do (ánh sáng, nhiệt).

## 9. Tóm tắt

| Cơ chế | Chất phản ứng điển hình | Tác nhân | Trung gian / đặc điểm | Ghi nhớ |
|---|---|---|---|---|
| **S~R~** | Alkan, mạch nhánh của aren | Cl•, Br• (ánh sáng) | Gốc tự do phẳng; khơi mào – phát triển – tắt mạch | Hỗn hợp sản phẩm; racemic |
| **S~N~1** | R–X bậc III, benzyl | Nucleophil | **Carbocation** phẳng; v = k[RX] | Racemic hóa |
| **S~N~2** | R–X bậc I, CH~3~X | Nucleophil | Trạng thái chuyển tiếp; v = k[RX][Y^−^] | **Nghịch đảo cấu hình**, tấn công phía sau |
| **S~E~** | Benzen, aren, dị vòng thơm | Electrophil (^+^NO~2~, Br^+^…) | Phức π → **phức σ** → mất H^+^ | Loại I: o, p; loại II: m |
| **A~N~** | Aldehyd, ceton (C=O) | Nucleophil (CN^−^, ROH, RMgX…) | Anion alkoxid | Aldehyd > ceton; −I tăng, +I giảm |
| **A~E~** | Alken, alkyn (C=C) | Electrophil (H^+^, Br^δ+^) | **Carbocation** | **Markovnikov**; HI > HBr > HCl >> HF |
| **E** | R–X, alcol bậc II–III | Base | E1: carbocation; E2: một giai đoạn | **Zaicev** (X trung hòa), **Hofmann** (X^+^ cồng kềnh) |

**Tự lượng giá 4.10 — nhận diện cơ chế (đáp án tr. 252):**

| Phản ứng | Cơ chế |
|---|---|
| a) C~2~H~4~ + HCl → C~2~H~5~Cl | A~E~ |
| b) C~2~H~6~ + Cl~2~ → C~2~H~5~Cl + HCl (ánh sáng) | S~R~ |
| c) C~2~H~5~Br + KOH (dung dịch nước) → C~2~H~5~OH + KBr | S~N~2 |
| d) (CH~3~)~3~COH + HCl → (CH~3~)~3~CCl + H~2~O | S~N~1 |
| e) CH~3~CHO + HCN → CH~3~CH(OH)CN | A~N~ |
| f) C~6~H~5~CH~3~ + Cl~2~ → ClC~6~H~4~CH~3~ + HCl (thế vào vòng) | S~E~ |
| g) C~6~H~5~CH~3~ + Cl~2~ → C~6~H~5~CH~2~Cl + HCl (thế vào nhánh) | S~R~ |

> [!bay] Ý f) và g) trong sách
> Đề sách ghi điều kiện "t°, hν" ở ý f) (thế vào vòng) và không ghi điều kiện ở ý g) (thế vào nhánh). Đáp án sách: f) S~E~, g) S~R~. Hãy nhận diện theo **vị trí thế**: thế vào **vòng** cần **xúc tác Fe/FeCl~3~** (S~E~); thế vào **nhánh** cần **ánh sáng** (S~R~).
