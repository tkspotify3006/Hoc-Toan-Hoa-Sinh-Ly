---
title: Các nguyên tố kim loại khối s (IA, IIA)
thoi-gian: 35 phút
muc-tieu:
- Xác định được vị trí trong bảng tuần hoàn và đặc điểm cấu hình electron hóa trị (ns^1^, ns^2^) của kim loại nhóm IA, IIA.
- Nêu được các tính chất hóa học chính của đơn chất kim loại kiềm, kiềm thổ (với phi kim, nước, acid, kiềm).
- Viết được phương trình phản ứng của các hợp chất điển hình: oxide, peroxide, superoxide, hydroxide, muối; phương pháp điều chế.
- Kể được ứng dụng và vai trò sinh học của Na^+^, K^+^, Mg^2+^, Ca^2+^ và các hợp chất dùng trong y học.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Khối s = nhóm **IA** (Li, Na, K, Rb, Cs, Fr — kim loại kiềm, **ns^1^**, số oxy hóa **+1**) và nhóm **IIA** (Be, Mg, Ca, Sr, Ba, Ra — kim loại kiềm thổ, **ns^2^**, số oxy hóa **+2**).
> 2. Tính chất hóa học cơ bản nhất là **tính khử mạnh**: M → M^n+^ + ne. Kim loại kiềm là chất khử mạnh nhất trong mỗi chu kỳ; kiềm thổ đứng ngay sau.
> 3. Đốt trong oxy: Li → Li~2~O, Na → **Na~2~O~2~** (peroxide), K, Rb, Cs → **KO~2~** (superoxide). Peroxide, superoxide + CO~2~ → **tái tạo O~2~**.
> 4. Đi xuống nhóm: bán kính tăng, tính khử tăng, **tính base của hydroxide tăng** (Be(OH)~2~ lưỡng tính → Ba(OH)~2~ base mạnh nhất).
> 5. Y học: Na^+^/K^+^ (áp suất thẩm thấu, điện giải), Ca^2+^ (xương, tim, **đông máu**), Mg^2+^ (enzym; **MgSO~4~ nhuận tràng**), **BaSO~4~ cản quang** còn BaCO~3~, BaS **độc**; thạch cao nung bó bột.

## 1. Vị trí các kim loại khối s

Khối s gồm hai cột đầu tiên của bảng tuần hoàn. Electron cuối cùng của chúng điền vào phân lớp **s** của lớp ngoài cùng.

![Hình 1. Vị trí, cấu hình electron hóa trị và xu hướng biến đổi trong nhóm IA, IIA](xu-huong.svg)

| | **Nhóm IA — kim loại kiềm** | **Nhóm IIA — kim loại kiềm thổ** |
|---|---|---|
| Nguyên tố | Li, Na, K, Rb, Cs, **Fr** (phóng xạ) | Be, Mg, Ca, Sr, Ba, **Ra** (phóng xạ) |
| Electron hóa trị | ns^1^ | ns^2^ |
| Năng lượng ion hóa I~1~ (giáo trình) | Nhỏ, khoảng 4–5 eV | Tương đối nhỏ, khoảng 5–10 eV |
| Số oxy hóa | **+1** | **+2** |
| Tính khử | Mạnh nhất trong chu kỳ | Mạnh, chỉ sau kim loại kiềm |

*Nguồn: Giáo trình tr. 9, 13.*

## 2. Kim loại nhóm IA — kim loại kiềm

### 2.1. Vị trí và đặc điểm

- Lớp ngoài cùng chỉ có **1 electron** (ns^1^), nằm xa hạt nhân và bị các lớp trong che chắn. Vì vậy I~1~ rất nhỏ, nguyên tử **rất dễ mất 1 electron** để đạt cấu hình bền của khí hiếm đứng trước:

=> M → M^+^ + 1e

- Muốn lấy electron thứ hai thì phải phá lớp vỏ khí hiếm bền vững, tốn rất nhiều năng lượng. Do đó kim loại kiềm **chỉ có số oxy hóa +1**.
- So với các nguyên tố cùng chu kỳ, kim loại kiềm có **tính khử mạnh nhất**.
- Trong nhóm, **tính kim loại tăng từ Li đến Fr**, vì bán kính nguyên tử tăng nên electron ngoài cùng càng dễ tách.
- Kim loại kiềm và hợp chất của chúng khi đốt cho **ngọn lửa màu đặc trưng**: **Li – đỏ, Na – vàng, K – tím**.

> [!vi-du] Vì sao ngọn lửa có màu?
> Nhiệt của ngọn lửa đẩy electron ngoài cùng lên mức năng lượng cao hơn. Khi electron rơi trở về, nó phát ra ánh sáng có bước sóng xác định, riêng cho từng nguyên tố. Phép thử màu ngọn lửa dùng để **nhận biết** ion kim loại kiềm. Ánh vàng của Na rất mạnh, có thể che màu tím của K; muốn thấy K phải nhìn qua kính coban (màu xanh lam).

### 2.2. Tính chất hóa học

Mọi phản ứng của kim loại kiềm đều xuất phát từ một điều: **M nhường electron rất dễ**.

**a) Với oxy.** Ở nhiệt độ thường, kim loại kiềm bị oxy hóa nhanh tạo oxide M~2~O:

=> 4M + O~2~ → 2M~2~O

Vì vậy phải bảo quản kim loại kiềm **trong dầu hỏa** hoặc trong khí trơ.

Khi **đốt cháy** (t° cao), sản phẩm khác nhau theo từng kim loại:

=> 2Na + O~2~ → Na~2~O~2~ (natri peroxide)

=> K + O~2~ → KO~2~ (kali superoxide; Rb, Cs tương tự)

> [!bay] Giáo trình in thiếu hệ số (tr. 10)
> Giáo trình viết "2M + O~2~ → M~2~O", phương trình này **chưa cân bằng** oxy. Đúng là **4M + O~2~ → 2M~2~O**.

> [!vi-du] Vì sao Li cho oxide, Na cho peroxide, K cho superoxide?
> Ion O~2~^2−^ và O~2~^−^ là những anion **to**. Một mạng tinh thể bền cần cation và anion có kích thước "vừa nhau". Li^+^ rất nhỏ chỉ "ghép" bền với O^2−^ nhỏ; Na^+^ lớn hơn ghép được với O~2~^2−^; K^+^, Rb^+^, Cs^+^ lớn nhất ghép bền với O~2~^−^. *Đây là cách giải thích bổ sung, giáo trình chỉ nêu sản phẩm.*

**b) Với các phi kim khác**

- Với **clo**: phản ứng mãnh liệt ngay ở nhiệt độ thường.

=> 2M + Cl~2~ → 2MCl

- Với **lưu huỳnh, hydro**: cần đun nóng.

=> 2Na + S → Na~2~S

=> 2Na + H~2~ → 2NaH (natri hydrid)

Trong NaH, hydro có số oxy hóa **−1** (ion hydrid H^−^), vì Na nhường electron cho H.

**c) Với nước.** Kim loại kiềm đẩy hydro ra khỏi nước rất mạnh, tỏa nhiều nhiệt:

=> 2M + 2H~2~O → 2MOH + H~2~↑

*Vì sao?* Thế điện cực chuẩn của cặp M^+^/M rất âm (giáo trình ghi khoảng −2,9 đến −3,0 V; số liệu chuẩn: từ **−2,71 V (Na)** đến **−3,04 V (Li)**), thấp hơn rất nhiều so với cặp H^+^/H~2~ (0,0 V). Nghĩa là M nhường electron dễ hơn rất nhiều so với H~2~, nên M khử được cả H^+^ rất ít ỏi trong nước.

**d) Với amoniac** — tạo **amidua** (amid kim loại):

=> 2Na + 2NH~3~ → 2NaNH~2~ + H~2~↑ (natri amidua)

**e) Với acid và với hợp chất có nhóm –OH**

=> 2M + H~2~SO~4~ (loãng) → M~2~SO~4~ + H~2~↑

Kim loại kiềm còn thay thế được H của nhóm –OH trong **alcol** và **acid hữu cơ**:

=> 2Na + 2C~2~H~5~OH → 2C~2~H~5~ONa + H~2~↑ (natri ethylat)

Phản ứng này dùng ở phần Hóa hữu cơ để **nhận biết nhóm –OH** (sủi bọt khí H~2~).

### 2.3. Các hợp chất

#### a) Oxide M~2~O

Là oxide base điển hình. **Trừ Li~2~O** (phản ứng êm hơn), các oxide kim loại kiềm phản ứng mạnh với nước, tỏa nhiều nhiệt:

=> M~2~O + H~2~O → 2MOH

#### b) Peroxide M~2~O~2~ và superoxide MO~2~

| | **Peroxide** (Na~2~O~2~) | **Superoxide** (KO~2~) |
|---|---|---|
| Ion | O~2~^2−^ (cầu –O–O–) | O~2~^−^, cấu tạo [O–O]^−^ |
| Số oxy hóa của O | **−1** | **−1/2** |
| Với nước | Na~2~O~2~ + 2H~2~O → 2NaOH + H~2~O~2~ | 2KO~2~ + 2H~2~O → 2KOH + H~2~O~2~ + O~2~↑ |
| Với CO~2~ | 2Na~2~O~2~ + 2CO~2~ → 2Na~2~CO~3~ + O~2~↑ | 4KO~2~ + 2CO~2~ → 2K~2~CO~3~ + 3O~2~↑ |
| Đặc điểm | Oxy hóa mạnh | Oxy hóa **rất mạnh** |

**Peroxide.** H~2~O~2~ sinh ra **không bền trong môi trường kiềm**, nên tiếp tục phân hủy thành O~2~:

=> 2H~2~O~2~ → 2H~2~O + O~2~↑

Phản ứng với CO~2~ vừa **hấp thụ CO~2~** vừa **giải phóng O~2~**. Vì vậy peroxide (và superoxide) được dùng để **tái tạo không khí** trong tàu ngầm, tàu vũ trụ, bình thở của thợ lặn và lính cứu hỏa.

**Superoxide.** Ion O~2~^−^ có **13 electron hóa trị**, cấu hình theo thuyết orbital phân tử (MO):

=> σ~s~^2^ σ~s~\*^2^ σ~z~^2^ π~x~^2^ = π~y~^2^ π~x~\*^2^ = π~y~\*^1^

Còn **một electron độc thân** ở orbital phản liên kết π\*. Vì vậy O~2~^−^ là gốc tự do, thuận từ và rất hoạt động. Superoxide oxy hóa được cả C, CO, NO:

=> 4KO~2~ + 2C → 2K~2~CO~3~ + O~2~↑

=> 2KO~2~ + CO → K~2~CO~3~ + O~2~↑

=> 2KO~2~ + 3NO → KNO~3~ + KNO~2~ + NO~2~↑

Với acid, superoxide cho H~2~O~2~ và O~2~:

=> 2KO~2~ + H~2~SO~4~ → K~2~SO~4~ + H~2~O~2~ + O~2~↑

> [!ung-dung] Gốc superoxide trong cơ thể
> Ion O~2~^−^ (anion superoxide) cũng được tạo ra trong tế bào, chủ yếu từ chuỗi hô hấp ty thể và từ bạch cầu khi diệt khuẩn. Đây là một **gốc tự do** thuộc nhóm "các dạng oxy hoạt động" (ROS). Cơ thể dọn nó bằng enzym **superoxide dismutase (SOD)**, chuyển thành H~2~O~2~ rồi tiếp tục bị catalase phân hủy. Cấu hình có 1 electron độc thân ở trên giải thích vì sao O~2~^−^ hoạt động mạnh. (Sẽ gặp lại ở Hóa sinh.)

#### c) Hydroxide MOH

- **Dễ tan** trong nước, là những **base mạnh** (kiềm).
- **Hút ẩm mạnh** và hấp thụ CO~2~ của không khí, nên NaOH để lâu ngoài không khí bị lẫn Na~2~CO~3~:

=> 2NaOH + CO~2~ → Na~2~CO~3~ + H~2~O

- **Bền nhiệt**, không bị nhiệt phân, **trừ LiOH**:

=> 2LiOH → Li~2~O + H~2~O (t°)

#### d) Muối

- Là **hợp chất ion**, cấu trúc tinh thể, nhiệt độ nóng chảy cao.
- **Dễ tan trong nước**, trừ một số muối của **liti** như LiF, Li~2~CO~3~.
- **Hydrocarbonat** MHCO~3~ tách ra được ở dạng rắn, bền ở nhiệt độ thường nhưng **bị nhiệt phân** khi đun:

=> 2NaHCO~3~ → Na~2~CO~3~ + CO~2~↑ + H~2~O (t°)

- **Carbonat** M~2~CO~3~ rất **bền nhiệt**, không phân hủy ngay cả khi nóng chảy.

> [!vi-du] Vì sao muối kim loại kiềm bền nhiệt? (Câu tự lượng giá 1.2)
> Đáp án của giáo trình: do **cấu trúc tinh thể** của muối (tr. 242). Hiểu sâu hơn: cation kim loại kiềm có điện tích nhỏ (+1) và bán kính lớn, nên **ít làm biến dạng** (phân cực) anion CO~3~^2−^. Anion giữ nguyên vẹn, không bị "kéo" mất một O để tạo CO~2~. Cation có điện tích lớn và kích thước nhỏ (Mg^2+^, Ca^2+^, Cu^2+^…) kéo lệch mây electron của anion mạnh hơn, nên MgCO~3~, CaCO~3~ bị nhiệt phân dễ hơn.
>
> **Li là ngoại lệ** vì Li^+^ rất nhỏ: LiOH bị nhiệt phân, Li~2~CO~3~ và LiF ít tan, Li cháy chỉ cho Li~2~O. Những tính chất này giống **Mg** hơn là giống Na. Đây là **quan hệ đường chéo** Li – Mg (tương tự Be – Al).

> [!ung-dung] Lithi carbonat — thuốc điều trị rối loạn lưỡng cực
> **Li~2~CO~3~** là thuốc kinh điển để **ổn định khí sắc** trong rối loạn cảm xúc lưỡng cực. Thuốc có **khoảng điều trị rất hẹp**: nồng độ Li^+^ huyết thanh duy trì thường khoảng 0,6–1,0 mmol/L; trên khoảng 1,5 mmol/L đã có nguy cơ ngộ độc (run, nôn, lú lẫn, co giật). Bắt buộc phải **theo dõi nồng độ thuốc trong máu**.
> *Liên hệ hóa học:* Li^+^ và Na^+^ cùng nhóm IA nên thận xử lý chúng gần giống nhau. Khi người bệnh **ăn nhạt, mất nước** hoặc dùng thuốc lợi tiểu thiazid, NSAID, thận giữ Na^+^ lại và **giữ luôn cả Li^+^**, làm nồng độ lithi tăng vọt.

### 2.4. Trạng thái thiên nhiên

Kim loại kiềm hoạt động mạnh nên trong tự nhiên **chỉ tồn tại ở dạng hợp chất**:

| Khoáng / nguồn | Thành phần |
|---|---|
| Nước biển, mỏ muối | NaCl |
| Xinvinit (sylvinit) | NaCl·KCl |
| Cacnalit (carnalit) | KCl·MgCl~2~·6H~2~O |
| Mỏ diêm tiêu | KNO~3~, NaNO~3~ |

### 2.5. Điều chế

**a) Kim loại: điện phân nóng chảy** muối clorid hoặc hydroxide:

=> 2NaCl → 2Na + Cl~2~↑ (điện phân nóng chảy)

=> 4KOH → 4K + O~2~↑ + 2H~2~O (điện phân nóng chảy)

*Vì sao phải điện phân **nóng chảy**, không điện phân dung dịch?* Trong dung dịch, nước bị khử ở catod **dễ hơn** ion M^+^ rất nhiều, nên catod chỉ thu được H~2~. Kể cả nếu có tạo ra Na thì Na cũng lập tức phản ứng với nước.

**b) Hydroxide**

- Phương pháp cổ: cho dung dịch Na~2~CO~3~ sôi tác dụng với vôi tôi.

=> Na~2~CO~3~ + Ca(OH)~2~ → 2NaOH + CaCO~3~↓

- Ngày nay: **điện phân dung dịch NaCl có màng ngăn**. Màng ngăn giữ cho Cl~2~ ở anod không gặp NaOH ở catod.

=> 2NaCl + 2H~2~O → 2NaOH + Cl~2~↑ + H~2~↑ (điện phân, có màng ngăn)

**c) Muối** — cho hydroxide tác dụng với acid tương ứng. Riêng **soda Na~2~CO~3~** sản xuất theo **phương pháp Solvay**:

=> CO~2~ + NH~3~ + H~2~O → NH~4~HCO~3~

=> NH~4~HCO~3~ + NaCl (bão hòa) → NaHCO~3~↓ + NH~4~Cl

=> 2NaHCO~3~ → Na~2~CO~3~ + CO~2~↑ + H~2~O (khoảng 200 °C)

=> 2NH~4~Cl + Ca(OH)~2~ → CaCl~2~ + 2NH~3~↑ + 2H~2~O

Mấu chốt: NaHCO~3~ **ít tan** trong dung dịch NaCl bão hòa lạnh nên kết tinh tách ra. CO~2~ và NH~3~ được **thu hồi, quay vòng** lại đầu quy trình.

### 2.6. Ứng dụng và vai trò sinh học

- **NaOH**: sản xuất xà phòng, giấy, đường…
- **NaHCO~3~**: chế biến thực phẩm (bột nở), nước giải khát… Trong y học là thuốc kháng acid và thuốc chữa toan chuyển hóa (xem bài *Hợp chất vô cơ*).
- **Na~2~CO~3~**: sản xuất thủy tinh, đồ gốm, sứ.
- Khoảng **90% muối kali** (KNO~3~, KCl…) dùng làm **phân bón**.

**Vai trò sinh học của Na^+^ và K^+^.** Cơ thể có nhiều Na^+^ (giáo trình: 0,32% trong máu, 0,6% trong xương, 0,6–1,5% trong cơ) và K^+^, ở dạng muối clorid, carbonat, hydrocarbonat, hydrophosphat và dihydrophosphat. Các ion này:

- duy trì **áp suất thẩm thấu** trong và ngoài tế bào;
- tham gia các **hệ đệm**, giữ **pH** các dịch cơ thể ổn định.

> [!vi-du] Đổi "0,32% Na^+^ trong máu" ra đơn vị xét nghiệm
> 0,32% ≈ 3,2 g Na^+^ trong 1 lít. Chia cho khối lượng mol của Na (23 g/mol): 3,2 : 23 ≈ 0,139 mol/L = **139 mmol/L**. Con số này nằm đúng trong khoảng natri máu bình thường mà phiếu xét nghiệm ghi hiện nay (**135–145 mmol/L**).

> [!cap-nhat] Na^+^ ngoài tế bào, K^+^ trong tế bào — "cân bằng Donnan" và bơm Na^+^/K^+^
> Giáo trình viết "cân bằng **Donnal**"; tên đúng là cân bằng **Donnan** (theo nhà hóa học F. G. Donnan). Hiện nay sinh lý học nhấn mạnh rằng sự chênh lệch **Na^+^ cao ở ngoài, K^+^ cao ở trong tế bào** được duy trì chủ yếu nhờ **bơm Na^+^/K^+^-ATPase**: mỗi chu kỳ dùng 1 ATP để đẩy 3 Na^+^ ra và đưa 2 K^+^ vào. Chênh lệch này tạo **điện thế màng**, là cơ sở dẫn truyền thần kinh và co cơ (tim). Khi thi, trả lời theo giáo trình.

> [!ung-dung] Rối loạn natri, kali
> - **Kali máu** bình thường khoảng **3,5–5,0 mmol/L**. Cả hạ kali và tăng kali máu đều có thể gây **rối loạn nhịp tim** nguy hiểm.
> - Vì vậy **KCl không bao giờ được tiêm tĩnh mạch trực tiếp (bolus)**; phải pha loãng, truyền chậm, có theo dõi.
> - Mất nước, nôn, tiêu chảy làm mất cả Na^+^ lẫn K^+^; dung dịch bù nước uống (ORS) chứa NaCl, KCl, glucose và citrat (hoặc NaHCO~3~).

## 3. Kim loại nhóm IIA — kim loại kiềm thổ

### 3.1. Vị trí và đặc điểm

- Gồm Be, Mg, Ca, Sr, Ba, Ra; **Ra có tính phóng xạ**.
- Electron hóa trị **ns^2^**, I~1~ tương đối nhỏ (5–10 eV), nên dễ mất 2 electron, thể hiện số oxy hóa **+2**:

=> M → M^2+^ + 2e

- **Tính khử mạnh**, chỉ đứng sau kim loại kiềm.

> [!bay] Năng lượng ion hóa thứ hai không nhỏ — vậy sao vẫn là M^2+^?
> I~2~ của kiềm thổ khá lớn. Nhưng ion M^2+^ điện tích +2, kích thước nhỏ, hút các phân tử nước rất mạnh, tỏa ra **nhiệt hydrat hóa lớn**. Năng lượng này bù lại phần tốn cho I~2~. Vì vậy trong dung dịch (và trong tinh thể), kiềm thổ luôn ở dạng M^2+^, không ở dạng M^+^.

### 3.2. Tính chất hóa học

**a) Với oxy**

- Ở nhiệt độ thường, **Be và Mg** tạo một **lớp oxide mỏng, bền, bảo vệ** kim loại bên trong.
- Ở nhiệt độ cao chúng bốc cháy (Mg cháy cho ánh sáng trắng chói):

=> 2Mg + O~2~ → 2MgO

- **Ba** khi cháy có thể cho **BaO~2~** (peroxide).

**b) Với các phi kim khác**

- Cl~2~, Br~2~: phản ứng ngay ở nhiệt độ thường: M + Cl~2~ → MCl~2~.
- S, N~2~, C: phản ứng khi đun nóng, tạo **sulfid, nitrid, carbid**:

=> Ba + S → BaS (bari sulfid)

=> 3Mg + N~2~ → Mg~3~N~2~ (magnesi nitrid)

=> Ca + 2C → CaC~2~ (calci carbid — "đất đèn")

**c) Với nước**

- **Ca, Sr, Ba** phản ứng dễ dàng ngay ở nhiệt độ thường:

=> M + 2H~2~O → M(OH)~2~ + H~2~↑

- **Mg** chỉ phản ứng với **nước nóng**, và nhanh chóng bị một **lớp Mg(OH)~2~ nhầy** phủ lên bảo vệ:

=> Mg + 2H~2~O → Mg(OH)~2~ + H~2~↑ (t°)

- Thêm một ít **NH~4~Cl đặc** thì lớp bảo vệ bị hòa tan và phản ứng lại tiếp tục:

=> Mg(OH)~2~ + 2NH~4~Cl → MgCl~2~ + 2NH~3~↑ + 2H~2~O

*Vì sao NH~4~Cl hòa tan được Mg(OH)~2~?* Theo định nghĩa proton, NH~4~^+^ là một **acid** (nhường H^+^). Nó "lấy" OH^−^ của Mg(OH)~2~ để tạo NH~3~ và H~2~O, nên Mg(OH)~2~ tan dần.

> [!vi-du] Câu tự lượng giá 1.5
> *Cho Mg vào nước nóng có phenolphtalein thấy màu hồng; thêm NH~4~Cl thấy có khí bay lên. Giải thích.*
> - Mg + 2H~2~O → Mg(OH)~2~ + H~2~↑. Dung dịch bão hòa Mg(OH)~2~ ở 25 °C có pH ≈ 10, đủ làm phenolphtalein chuyển **hồng**.
> - Thêm NH~4~Cl: Mg(OH)~2~ + 2NH~4~Cl → MgCl~2~ + 2NH~3~↑ + 2H~2~O. Khí bay lên là **NH~3~** (mùi khai). Lớp Mg(OH)~2~ mất đi nên Mg tiếp tục phản ứng với nước, giải phóng thêm **H~2~**.
> - Lưu ý: đáp án cuối sách (tr. 242) in "Mg(OH)~2~ + NH~4~Cl", **thiếu hệ số 2** trước NH~4~Cl.

**d) Với acid** — phản ứng dễ dàng, giải phóng H~2~ (với acid thường).

**e) Với kiềm** — **riêng Be** phản ứng được với kiềm, giống nhôm, tạo **berilat**:

=> Be + 2NaOH + 2H~2~O → Na~2~[Be(OH)~4~] + H~2~↑

### 3.3. Các hợp chất

#### a) Oxide MO

- Nhiệt độ nóng chảy **rất cao**, nên dùng làm **vật liệu chịu lửa** (MgO, CaO).
- **MgO** bền, không phản ứng với nước (ở điều kiện thường). **CaO, SrO, BaO** phản ứng dễ dàng với nước, tỏa nhiều nhiệt:

=> MO + H~2~O → M(OH)~2~

- **BeO** không phản ứng với nước nhưng **tan trong kiềm** tạo berilat.

#### b) Peroxide MO~2~ (BaO~2~)

- Tan dễ trong acid, giải phóng H~2~O~2~ (từng là cách điều chế H~2~O~2~):

=> BaO~2~ + H~2~SO~4~ → BaSO~4~↓ + H~2~O~2~

- Có **tính oxy hóa mạnh**:

=> 2BaO~2~ + S → 2BaO + SO~2~

- Nhưng gặp chất oxy hóa mạnh hơn, BaO~2~ lại đóng vai **chất khử** (O^−1^ → O~2~^0^). Xem câu 1.7 ở cuối bài.

#### c) Hydroxide M(OH)~2~

| Hydroxide | Độ tan | Tính chất |
|---|---|---|
| **Be(OH)~2~** | Hầu như không tan | **Lưỡng tính**: tan cả trong acid và kiềm đặc |
| **Mg(OH)~2~** | Hầu như không tan | Base yếu |
| **Ca(OH)~2~** | Ít tan | Base mạnh (dung dịch: nước vôi trong) |
| **Sr(OH)~2~, Ba(OH)~2~** | Tan | Base mạnh; **Ba(OH)~2~ mạnh nhất** |

=> Be(OH)~2~ + 2NaOH → Na~2~[Be(OH)~4~]

**Tính base tăng dần từ Be(OH)~2~ đến Ba(OH)~2~.** *Vì sao?* Đi xuống nhóm, độ âm điện của kim loại **giảm** (Ba dương điện nhất). Liên kết M–OH càng **phân cực, càng mang tính ion**, nên càng dễ tách ra OH^−^. Ngược lại, Be nhỏ và âm điện hơn, liên kết Be–O mang nhiều tính cộng hóa trị, nên Be(OH)~2~ có thể tách cả H^+^ (thể hiện tính acid yếu) → lưỡng tính.

**Nhiệt phân** (trừ Sr(OH)~2~, Ba(OH)~2~ theo giáo trình) tạo oxide:

=> Ca(OH)~2~ → CaO + H~2~O (t°)

#### d) Muối

| Loại muối | Độ tan |
|---|---|
| Halid (trừ florid), nitrat, acetat | **Dễ tan** |
| Sulfat | BeSO~4~, **MgSO~4~ dễ tan**; **CaSO~4~ ít tan**; SrSO~4~, **BaSO~4~ không tan** |
| Carbonat MCO~3~ (Ca, Sr, Ba) | **Khó tan**; bị nhiệt phân: MCO~3~ → MO + CO~2~↑ |
| Hydrocarbonat M(HCO~3~)~2~ | **Tan**, chỉ tồn tại trong dung dịch; đun nóng bị phân hủy |

=> Ca(HCO~3~)~2~ → CaCO~3~↓ + CO~2~↑ + H~2~O (t°)

> [!bay]
> - Độ tan **sulfat giảm** dần từ Be đến Ba (MgSO~4~ tan → BaSO~4~ không tan). Ngược lại, độ tan **hydroxide tăng** dần (Mg(OH)~2~ không tan → Ba(OH)~2~ tan). Hai xu hướng ngược chiều nhau, dễ nhầm.
> - **Carbonat** kiềm thổ không tan, nhưng **hydrocarbonat** của chúng lại **tan**. Đây là gốc của hiện tượng nước cứng tạm thời và thạch nhũ trong hang đá vôi.

![Hình 2. Vòng biến đổi của các hợp chất calci: đá vôi – vôi sống – vôi tôi – nước cứng](vong-calci.svg)

### 3.4. Trạng thái tự nhiên

| Khoáng | Thành phần |
|---|---|
| Đá vôi (cũng là thành phần của vỏ sò, đá phấn, đá hoa) | CaCO~3~ |
| Thạch cao | CaSO~4~·2H~2~O |
| Apatit | Ca~5~(PO~4~)~3~F |
| Magnesit | MgCO~3~ |
| Cacnalit; nước biển, mỏ muối kali | KCl·MgCl~2~; MgCl~2~ |
| Dolomit | CaCO~3~·MgCO~3~ |
| Baritin (barit) | BaSO~4~ |
| Viterit | BaCO~3~ |

### 3.5. Điều chế

**a) Đơn chất**

- **Điện phân nóng chảy** muối clorid tương ứng — đây là nguyên tắc chung:

=> MCl~2~ → M + Cl~2~↑ (điện phân nóng chảy)

- Riêng **Mg** còn có thể điều chế bằng cách khử MgO:
  - bằng carbon ở khoảng 2000 °C: MgO + C → Mg + CO↑
  - hoặc bằng hợp kim ferosilic (Fe–Si) khử MgO từ **dolomit** đã nung, ở khoảng 1500 °C (Si bị oxy hóa thành silicat calci).

**b) Hợp chất**

- **Oxide** điều chế bằng cách **nhiệt phân muối carbonat** tương ứng. Từ xa xưa người ta đã nung đá vôi lấy **vôi sống**:

=> CaCO~3~ → CaO + CO~2~↑ (t°)

- Vôi sống tác dụng với nước cho **vôi tôi** Ca(OH)~2~, vật liệu xây dựng quan trọng. Vữa vôi đóng rắn dần vì Ca(OH)~2~ hấp thụ CO~2~ không khí, trở lại thành CaCO~3~ (Hình 2).
- Peroxide kiềm thổ (trừ BeO~2~) điều chế được bằng **phương pháp ướt** (trong dung dịch).

> [!vi-du] Câu tự lượng giá 1.4 và 1.9
> - **1.4.** Nguyên tắc chung: **kim loại** kiềm thổ điều chế bằng **điện phân nóng chảy muối clorid** (MgCl~2~ → Mg + Cl~2~); **oxide** điều chế bằng **nhiệt phân carbonat** (MgCO~3~ → MgO + CO~2~).
> - **1.9.** Điều chế CaC~2~ từ đá vôi và than đá (đáp án cuối sách không có câu này):
>
> => CaCO~3~ → CaO + CO~2~↑ (nung)
>
> => CaO + 3C → CaC~2~ + CO↑ (lò điện, khoảng 2000 °C)
>
> Than đá được luyện thành than cốc (C) trước khi dùng. CaC~2~ gặp nước cho khí **acetylen**: CaC~2~ + 2H~2~O → Ca(OH)~2~ + C~2~H~2~↑ (dùng để hàn cắt kim loại; dân gian dùng "đất đèn" để giấm trái cây).

### 3.6. Ứng dụng và vai trò sinh học

**Ứng dụng của đơn chất và hợp chất (theo giáo trình)**

- **Mg** là kim loại nhóm IIA được dùng nhiều nhất, nhất là trong **luyện kim**: thành phần của hợp kim nhẹ, bền như dura và magnali. *(Bổ sung: đura (duralumin) là hợp kim nhôm chủ yếu chứa đồng, có thêm Mg, Mn; magnali là hợp kim Al–Mg.)*
- **BaCl~2~** dễ tan: thuốc thử định tính, định lượng ion **SO~4~^2−^, CO~3~^2−^**; điều chế các muối bari khác. Rất **độc** nên từng được dùng làm thuốc trừ sâu.
- **CaCl~2~ khan** hút ẩm mạnh: dùng **làm khô** khí và chất lỏng hữu cơ (ether, benzen…). **Không** dùng để làm khô **alcol** hay **NH~3~**, vì CaCl~2~ tan trong alcol và kết hợp với NH~3~.
- **BaSO~4~** khó tan, không độc, **hấp thụ mạnh tia X** → dùng làm **thuốc cản quang** khi chụp X-quang ống tiêu hóa.
- **BaCO~3~, BaS** tuy không tan trong nước nhưng **rất độc**, vì bị **HCl dạ dày** hòa tan, giải phóng Ba^2+^.
- **MgSO~4~** (giáo trình gọi là *muối chát*) dễ tan, dùng làm **thuốc nhuận tràng**.
- **Thạch cao**: nung ở khoảng **125 °C** mất bớt nước, thành **thạch cao nung**:

=> 2CaSO~4~·2H~2~O → 2CaSO~4~·H~2~O + 3H~2~O (khoảng 125 °C)

Thạch cao nung trộn với nước thì **đông cứng** trở lại, nên dùng làm khuôn đúc, nặn tượng và **bó bột chỉnh hình** trong y học.

> [!bay] Thạch cao nung "mất một phân tử nước"?
> Giáo trình viết thạch cao "mất **một** phân tử H~2~O", nhưng phương trình đi kèm (đúng) lại cho thấy: **2** đơn vị CaSO~4~·2H~2~O mất **3** H~2~O. Tính theo một đơn vị, mỗi CaSO~4~·2H~2~O mất **1,5** H~2~O và còn lại CaSO~4~·½H~2~O (viết gọn 2CaSO~4~·H~2~O, gọi là **hemihydrat**). Khi đông cứng, hemihydrat **nhận lại nước** thành CaSO~4~·2H~2~O, các tinh thể hình kim đan cài vào nhau nên khối bột rắn chắc.
> Nếu nung quá cao, thạch cao mất hết nước thành CaSO~4~ khan, gần như **không đông cứng** được nữa ("thạch cao chết").

> [!ung-dung] Bari: BaSO~4~ an toàn, Ba^2+^ tan thì độc
> Toàn bộ khác biệt nằm ở **độ tan trong acid**. BaSO~4~ là muối của acid mạnh, không tan trong HCl dịch vị, nên đi qua ống tiêu hóa mà không bị hấp thu. BaCO~3~ (muối của acid yếu) và BaS gặp HCl thì tan, giải phóng Ba^2+^. Ba^2+^ gây **hạ kali máu** nặng, liệt cơ, rối loạn nhịp tim. Phương trình cụ thể xem bài *Hợp chất vô cơ: oxide, acid, base, muối*.

**Vai trò sinh học của Ca^2+^ và Mg^2+^ (theo giáo trình)**

- **Ca^2+^** có vai trò **tạo xương**. Giáo trình ghi xương động vật chứa khoảng **80% Ca~3~(PO~4~)~2~** và **13% CaCO~3~**.
- Calci trong huyết thanh ở dạng muối phosphat và citrat. Ion Ca^2+^ **kích thích hoạt động của tim** và cần cho quá trình **đông máu**. Calci được đưa vào cơ thể qua thức ăn thực vật và **sữa**.
- Cơ thể người chứa khoảng 71 g **magnesi** (giáo trình), phần lớn Mg^2+^ tập trung trong **xương** dưới dạng muối phức với calci và phospho; phần còn lại ở các hệ đệm và dịch cơ thể.
- **Mg^2+^** tham gia cấu tạo **nhiều enzym** và là nguyên tử trung tâm của **chlorophyl** (diệp lục) ở cây xanh.

> [!cap-nhat] Calci và magnesi trong cơ thể — số liệu hiện nay
> - **Khoáng của xương**: giáo trình ghi Ca~3~(PO~4~)~2~ và CaCO~3~. Hiện nay biết phần khoáng chính của xương và răng là **hydroxyapatit Ca~10~(PO~4~)~6~(OH)~2~** (có lẫn một ít carbonat). Khoảng **99% calci** cơ thể nằm ở xương và răng.
> - **Calci huyết thanh**: giáo trình ghi ở dạng muối phosphat và citrat. Hiện nay chia làm 3 phần: khoảng **một nửa là Ca^2+^ tự do (ion hóa)** — phần có hoạt tính sinh lý; khoảng 40% gắn **protein** (chủ yếu albumin); phần nhỏ còn lại tạo phức với citrat, phosphat… Calci toàn phần bình thường ≈ 2,15–2,55 mmol/L (tham khảo; xem hs-15).
> - **Magnesi toàn cơ thể**: giáo trình ghi khoảng 71 g. Các tài liệu sinh lý hiện nay thường ghi khoảng **20–30 g** ở người trưởng thành, trong đó hơn một nửa nằm trong xương.
> - **MgSO~4~ nhuận tràng**: giáo trình giải thích do "kích thích nhu động ruột". Hiện nay xếp MgSO~4~ vào nhóm **nhuận tràng thẩm thấu**: Mg^2+^ và SO~4~^2−^ khó hấp thu, giữ nước trong lòng ruột; khối phân nhiều nước mới gây tăng nhu động.
>
> Khi thi, trả lời theo giáo trình.

> [!ung-dung] Ca^2+^ và Mg^2+^ trong lâm sàng
> - **Đông máu cần Ca^2+^** (yếu tố IV). Vì vậy ống lấy máu xét nghiệm và túi máu dùng chất **chống đông lấy mất Ca^2+^**: **citrat** (tạo phức với Ca^2+^) hoặc **EDTA** (tạo phức chelat). Ống dùng oxalat thì kết tủa Ca^2+^ thành calci oxalat.
> - **Hạ calci máu** làm thần kinh – cơ dễ kích thích: tê đầu chi, **co quắp** (tetani). Điều trị cấp bằng **calci gluconat** tiêm tĩnh mạch chậm. Calci gluconat cũng là thuốc **bảo vệ tim** khi tăng kali máu nặng.
> - **CaCO~3~** là thuốc kháng acid và thuốc bổ sung calci (cùng với vitamin D).
> - **MgSO~4~ tiêm** là thuốc chọn lựa để **dự phòng và điều trị co giật trong tiền sản giật – sản giật**. Quá liều Mg^2+^ gây **mất phản xạ gân xương** (dấu hiệu theo dõi tại giường), rồi ức chế hô hấp. Thuốc giải: **calci gluconat** — Ca^2+^ đối kháng tác dụng của Mg^2+^.
> - MgSO~4~ đường uống là thuốc tẩy, nhuận tràng (muối Epsom); Mg(OH)~2~ là thuốc kháng acid.

> [!yhct] Thạch cao sống và Thạch cao nung — cùng một chất, hai cách dùng
> Vị thuốc **Thạch cao** chính là khoáng thạch cao CaSO~4~·2H~2~O. Sự khác nhau giữa hai dạng dùng trong YHCT trùng khớp với phần hóa học ở trên:
> - **Sinh thạch cao** (sống, giữ nguyên nước kết tinh): dùng **uống**, tính hàn, công dụng **thanh nhiệt tả hỏa, trừ phiền chỉ khát**; là quân dược của bài **Bạch hổ thang** (Thạch cao, Tri mẫu, Cam thảo, Ngạnh mễ). CaSO~4~ **ít tan** (khoảng 2 g/L), nên thường được giã nhỏ và **sắc trước** để chiết được nhiều hơn. Vì lượng Ca^2+^ đi vào nước sắc ít, cơ chế hạ sốt của Thạch cao **chưa được giải thích rõ**; các nghiên cứu thực nghiệm cho kết quả chưa thống nhất.
> - **Đoạn thạch cao** (nung): nung làm mất phần lớn hoặc toàn bộ nước kết tinh, bột trở nên xốp, hút nước. Dạng này chủ yếu **dùng ngoài** để **thu thấp, liễm sang, sinh cơ** (rắc lên vết loét, chàm chảy nước, bỏng). Tác dụng làm khô có thể hiểu được: bột thạch cao đã mất nước sẽ **hút lại nước** — đúng tính chất làm thạch cao nung đông cứng khi bó bột.
>
> Nói gọn: sống dùng uống, nung dùng ngoài. Không lấy thạch cao xây dựng, thạch cao bó bột làm thuốc, vì có thể lẫn tạp chất, phụ gia.

> [!yhct] Mang tiêu và Hoạt thạch — hai khoáng dược chứa Na, Mg
> - **Mang tiêu** Na~2~SO~4~·10H~2~O (tây y gọi là **muối Glauber**) cùng cơ chế **tả hạ** với MgSO~4~ (muối Epsom): cả hai là muối sulfat khó hấp thu, giữ nước trong ruột. Tinh thể Mang tiêu để ngoài không khí khô sẽ **mất dần nước kết tinh**, bị phủ lớp bột trắng (hiện tượng **phong hóa**). Bột Na~2~SO~4~ khan thu được là vị **Huyền minh phấn**. Mang tiêu thường được **hòa vào nước thuốc đã sắc** (không sắc lâu), như trong **Đại thừa khí thang** (Đại hoàng, Mang tiêu, Chỉ thực, Hậu phác). Khi có thai: Dược điển Trung Quốc ghi **thận trọng**, nhiều sách YHCT ghi **kiêng dùng**; thận trọng ở người cần hạn chế muối natri (phù, suy tim, tăng huyết áp).
> - **Hoạt thạch** là khoáng **talc**, một **magnesi silicat ngậm nước** Mg~3~Si~4~O~10~(OH)~2~. Đây là hợp chất của Mg nhưng **không giải phóng Mg^2+^** như MgSO~4~: talc hầu như **không tan** trong nước và acid loãng. Công dụng YHCT: **lợi thủy thông lâm, thanh nhiệt giải thử** (bài **Lục nhất tán**: Hoạt thạch 6 phần, Cam thảo 1 phần), dùng ngoài **thu thấp** (rôm sảy, chàm). Bột mịn nên khi sắc phải **bọc vải**. Tác dụng dùng ngoài chủ yếu mang tính **vật lý** (trơn, hút ẩm, che phủ da); bằng chứng cho tác dụng lợi niệu khi uống còn hạn chế.
> - **Cảnh báo Hoạt thạch:** talc tự nhiên có thể **lẫn amiăng** (asbestos, chất gây ung thư). Chỉ dùng loại đạt **tiêu chuẩn dược dụng**, tránh hít bột. Ở một số nơi, loại gọi là "nhuyễn hoạt thạch" lại là khoáng sét (nhôm silicat), không phải talc.

## 4. Nước cứng

**Nước cứng** là nước tự nhiên (nước ngầm, sông, suối…) chứa nhiều ion **Ca^2+^ và Mg^2+^**. Nước cứng gây hại cho kỹ thuật (đóng cặn nồi hơi, đường ống) và đời sống (tốn xà phòng, nấu ăn lâu chín).

| | **Nước cứng tạm thời** | **Nước cứng vĩnh cửu** |
|---|---|---|
| Anion quyết định | **HCO~3~^−^** (Ca(HCO~3~)~2~, Mg(HCO~3~)~2~) | **Cl^−^, SO~4~^2−^** (CaCl~2~, CaSO~4~, MgCl~2~, MgSO~4~) |
| Đun sôi có hết cứng? | **Có** — hydrocarbonat chuyển thành carbonat kết tủa | **Không** |
| Cách làm mềm | Đun nóng; Na~2~CO~3~; nước vôi trong (lượng vừa đủ); trao đổi ion | Hóa chất (**Na~2~CO~3~**…); **chất trao đổi ion** (ionit) |

=> Ca(HCO~3~)~2~ → CaCO~3~↓ + CO~2~↑ + H~2~O (đun sôi)

=> Ca(HCO~3~)~2~ + Ca(OH)~2~ → 2CaCO~3~↓ + 2H~2~O

=> CaSO~4~ + Na~2~CO~3~ → CaCO~3~↓ + Na~2~SO~4~

=> MgCl~2~ + Na~2~CO~3~ → MgCO~3~↓ + 2NaCl

**Chất trao đổi ion**: nhựa (hoặc zeolit) chứa ion Na^+^ (hay H^+^) có thể thay thế. Khi nước đi qua, Ca^2+^, Mg^2+^ bị giữ lại trên nhựa, đổi ra Na^+^ (hay H^+^).

> [!bay]
> - **Na~2~CO~3~** làm mềm được **cả hai loại** nước cứng, vì CO~3~^2−^ kết tủa trực tiếp Ca^2+^, Mg^2+^ bất kể anion đi kèm.
> - **Nước vôi trong** chỉ hợp với nước cứng **tạm thời** và phải dùng **vừa đủ**. Với CaSO~4~, CaCl~2~, thêm Ca(OH)~2~ chỉ đưa thêm Ca^2+^ vào nước. Dùng dư thì chính Ca(OH)~2~ lại làm nước cứng.
> - **Cặn trắng** trong ấm đun nước là **CaCO~3~** (và MgCO~3~/Mg(OH)~2~) tạo ra khi đun nước cứng tạm thời. Tẩy bằng giấm hoặc acid citric (chanh): CaCO~3~ + 2CH~3~COOH → (CH~3~COO)~2~Ca + CO~2~↑ + H~2~O.

> [!ung-dung] Nước cứng và nước dùng trong y tế, bào chế
> Nước cứng không dùng được cho nồi hấp tiệt trùng, máy chạy thận nhân tạo hay pha thuốc tiêm: các ion Ca^2+^, Mg^2+^ đóng cặn thiết bị và có thể **tạo tủa** với thuốc (ví dụ Ca^2+^ với phosphat, carbonat). Vì vậy phải dùng **nước tinh khiết** (khử khoáng bằng trao đổi ion, thẩm thấu ngược) hoặc **nước cất**.

## 5. Đáp án tự lượng giá (giáo trình tr. 17–18, đáp án tr. 242)

> [!vi-du] Các câu còn lại
> - **1.1.** Tính chất hóa học cơ bản nhất của kim loại kiềm và kiềm thổ là **tính khử**: M − ne → M^n+^ (n = 1 hoặc 2). Các phản ứng với phi kim, nước, acid đều là biểu hiện của tính khử.
> - **1.3.** Peroxide, superoxide:
>
> => Na~2~O~2~ + 2H~2~O → 2NaOH + H~2~O~2~ (H~2~O~2~ phân hủy tiếp trong kiềm: 2H~2~O~2~ → 2H~2~O + O~2~)
>
> => 2Na~2~O~2~ + 2CO~2~ → 2Na~2~CO~3~ + O~2~↑
>
> => 2KO~2~ + CO~2~ + H~2~O → K~2~CO~3~ + H~2~O~2~ + O~2~↑
>
> => 4KO~2~ + 2CO~2~ → 2K~2~CO~3~ + 3O~2~↑
>
> - **1.6.** Tính base tăng từ Be(OH)~2~ đến Ba(OH)~2~, vì độ âm điện của kim loại giảm, liên kết M–OH càng phân cực (mục 3.3c).
> - **1.7.** Peroxide bari:
>
> => BaO~2~ + 2FeSO~4~ + 2H~2~SO~4~ → Fe~2~(SO~4~)~3~ + BaSO~4~↓ + 2H~2~O
>
> => 3BaO~2~ + Cr~2~(SO~4~)~3~ + 4NaOH → 3BaSO~4~↓ + 2Na~2~CrO~4~ + 2H~2~O
>
> => BaO~2~ + HgCl~2~ → BaCl~2~ + Hg + O~2~↑
>
> Ở (a) và (b), BaO~2~ là **chất oxy hóa** (O^−1^ → O^−2^; Fe^2+^ → Fe^3+^, Cr^3+^ → Cr^+6^). Ở (c), BaO~2~ là **chất khử** (O^−1^ → O~2~^0^), còn Hg^2+^ bị khử thành Hg. *(Đáp án cuối sách không ghi vai trò; đây là phần tự suy từ số oxy hóa.)*
> - **1.8.** Be(OH)~2~ khác các hydroxide còn lại ở chỗ **lưỡng tính**, tan được trong kiềm: Be(OH)~2~ + 2NaOH → Na~2~[Be(OH)~4~].
> - **1.10.** Độ cứng tạm thời do **HCO~3~^−^**; độ cứng vĩnh cửu do **Cl^−^, SO~4~^2−^** của Mg^2+^ và Ca^2+^. Làm mềm bằng nhiệt, hóa chất (Na~2~CO~3~), chất trao đổi ion. *(Trong phần đáp án, câu này bị đánh số nhầm thành "1.9".)*
> - **1.11.** Xem mục 3.6: BaSO~4~ cản quang; MgSO~4~ nhuận tràng; thạch cao nung bó bột; CaCl~2~, BaCl~2~ làm thuốc thử; vai trò Ca^2+^ (xương, tim, đông máu), Mg^2+^ (enzym, xương).

## Tóm tắt

| | **Nhóm IA (kiềm)** | **Nhóm IIA (kiềm thổ)** |
|---|---|---|
| Cấu hình, số oxy hóa | ns^1^, +1 | ns^2^, +2 |
| Với O~2~ khi đốt | Li~2~O; **Na~2~O~2~**; **KO~2~** (K, Rb, Cs) | MO; Ba có thể cho BaO~2~ |
| Với nước | Mọi kim loại, mãnh liệt | Ca, Sr, Ba ở t° thường; Mg cần nước nóng; Be không |
| Hydroxide | Tan, base mạnh; chỉ LiOH bị nhiệt phân | Be(OH)~2~ **lưỡng tính** → Ba(OH)~2~ base mạnh nhất |
| Muối | Hầu hết tan (trừ LiF, Li~2~CO~3~); carbonat bền nhiệt | Sulfat: Mg tan, Ca ít tan, Ba không tan; carbonat không tan, bị nhiệt phân |
| Điều chế kim loại | Điện phân nóng chảy MCl, MOH | Điện phân nóng chảy MCl~2~; Mg: khử MgO bằng C hoặc Fe–Si |
| Sinh học, y học | Na^+^, K^+^: thẩm thấu, đệm pH; Li~2~CO~3~; NaHCO~3~ | Ca^2+^: xương, tim, đông máu; Mg^2+^: enzym, chlorophyl; MgSO~4~; BaSO~4~ cản quang; thạch cao bó bột |

- **Peroxide/superoxide + CO~2~ → O~2~**: tái tạo không khí trong tàu ngầm, bình thở.
- Thạch cao **2CaSO~4~·2H~2~O → 2CaSO~4~·H~2~O + 3H~2~O** (≈ 125 °C) — mỗi đơn vị mất 1,5 H~2~O.
- Nước cứng: **tạm thời = HCO~3~^−^** (đun sôi hết), **vĩnh cửu = Cl^−^, SO~4~^2−^**; Na~2~CO~3~ và ionit làm mềm được cả hai.
- **BaSO~4~ không tan trong acid → an toàn**; BaCO~3~, BaS tan trong HCl dạ dày → độc.
