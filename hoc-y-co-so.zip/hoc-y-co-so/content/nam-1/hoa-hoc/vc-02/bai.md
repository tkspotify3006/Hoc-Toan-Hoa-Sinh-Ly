---
title: Các nguyên tố kim loại khối p (IIIA, IVA)
thoi-gian: 30 phút
muc-tieu:
- Xác định được vị trí trong bảng tuần hoàn và cấu hình electron hóa trị của các kim loại nhóm IIIA (Al, Ga, In, Tl) và IVA (Sn, Pb); suy ra số oxy hóa đặc trưng.
- Nêu được các tính chất hóa học chính của nhôm, thiếc, chì (với phi kim, nước, acid, kiềm, oxide kim loại).
- Viết được phương trình (đã cân bằng) của các hợp chất điển hình: oxide, hydroxide lưỡng tính, muối nhôm, muối thiếc, muối chì.
- Kể được ứng dụng và vai trò sinh học (độc tính) của Al, Sn, Pb và hợp chất; liên hệ thuốc, xét nghiệm và khoáng dược YHCT.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Kim loại khối p có electron cuối cùng điền vào phân lớp **p**: nhóm IIIA **ns^2^np^1^** → số oxy hóa **+3** (Tl còn **+1**); nhóm IVA **ns^2^np^2^** → **+2 và +4**.
> 2. Nhôm hoạt động mạnh nhưng được **màng Al~2~O~3~** bảo vệ; tan trong acid thường **và cả trong kiềm**; khử được oxide kim loại khác (**nhiệt nhôm**).
> 3. Al~2~O~3~ và **Al(OH)~3~ lưỡng tính**: tan trong acid và kiềm mạnh, nhưng **không tan trong NH~3~**. Muối nhôm thủy phân tạo Al(OH)~3~ keo → **làm trong nước**.
> 4. Sn và Pb: oxide, hydroxide M(OH)~2~ đều **lưỡng tính**; **Sn^2+^ là chất khử mạnh**, Pb^2+^ thì không; PbSO~4~ khó tan.
> 5. **Chì độc**: tích lũy, tác động lên **thần kinh** và **ức chế tạo máu** (chặn tổng hợp hem) → thiếu máu mạn; nguy cơ ở người tiếp xúc nghề nghiệp.

## 1. Vị trí của kim loại khối p

Ở khối p, phần lớn là phi kim. Kim loại chỉ chiếm góc **dưới – trái** của khối, vì đi xuống trong một nhóm thì bán kính nguyên tử tăng, electron hóa trị bị giữ lỏng hơn, nguyên tố dễ nhường electron hơn (tính kim loại tăng).

Bảng của giáo trình (tr. 19) xếp các nguyên tố sau vào vùng kim loại p: **Al** (chu kỳ 3); Ga, Ge (chu kỳ 4); In, **Sn**, Sb (chu kỳ 5); Tl, **Pb**, Bi, Po (chu kỳ 6). Bài này chỉ học nhóm **IIIA** (trọng tâm là **nhôm**) và nhóm **IVA** (**thiếc, chì**).

![Hình 1. Vị trí và cấu hình electron hóa trị của kim loại khối p](vi-tri.svg)

| | Nhóm IIIA | Nhóm IVA |
|---|---|---|
| Kim loại | Al, Ga, In, Tl (B là phi kim) | Sn, Pb (Ge được giáo trình xếp vào vùng kim loại p, nhưng thường coi là á kim) |
| Lớp hóa trị | ns^2^np^1^ | ns^2^np^2^ |
| Số oxy hóa đặc trưng | **+3**; riêng Tl có thêm **+1** | **+2** và **+4** |
| Ví dụ cấu hình | Al: [Ne]3s^2^3p^1^ | Sn: [Kr]4d^10^5s^2^5p^2^; Pb: [Xe]4f^14^5d^10^6s^2^6p^2^ |

> [!vi-du] Vì sao Tl thích +1, Pb thích +2? — "cặp electron trơ"
> Ở các nguyên tố nặng (chu kỳ 6), cặp electron **6s^2^** bị hạt nhân giữ rất chặt, khó tham gia liên kết. Vì vậy chúng thường chỉ "cho đi" electron p:
> - **Tl**: bỏ 1 electron 6p → Tl^+^ bền. Tl^3+^ dễ bị khử về Tl^+^ (Tl~2~O~3~ phân hủy ở 500 °C thành Tl~2~O).
> - **Pb**: bỏ 2 electron 6p → **Pb^2+^ bền**; Pb(IV) (như PbO~2~) là chất **oxy hóa**.
> - **Sn** nhẹ hơn, hiệu ứng yếu → **Sn(IV) bền hơn Sn(II)**; do đó Sn^2+^ dễ nhường thêm 2 electron, là **chất khử mạnh**.
>
> Quy luật này giải thích nhiều chi tiết "lẻ" của giáo trình: Sn + halogen cho SnX~4~ nhưng Pb chỉ cho PbX~2~; Tl tạo muối TlCl, Tl~2~SO~4~ (số oxy hóa +1).

## 2. Kim loại nhóm IIIA — trọng tâm là nhôm

### 2.1. Vị trí và đặc điểm

- Nhóm IIIA gồm **B, Al, Ga, In, Tl**. **Bo là phi kim**; bốn nguyên tố còn lại là kim loại.
- Lớp electron hóa trị **ns^2^np^1^** (3 electron).
- Trừ Bo, các nguyên tố này còn **phân lớp d trống** (với Al là 3d). Nhờ đó chúng nhận thêm cặp electron để tạo **ion phức**, lai hóa sp^3^ (như [Al(OH)~4~]^−^, tứ diện) hoặc sp^3^d^2^ (như [Al(H~2~O)~6~]^3+^, [AlF~6~]^3−^, bát diện).
- Số oxy hóa đặc trưng **+3**: M → M^3+^ + 3e. **Riêng Tl có thêm +1.**

**Vì sao lại là +3 mà không phải +1?** Bứt 3 electron tốn năng lượng nhiều. Nhưng ion M^3+^ nhỏ, điện tích lớn nên hút các phân tử nước rất mạnh. **Năng lượng hydrat hóa** tỏa ra lớn, đủ bù lại năng lượng ion hóa. Vì vậy trong dung dịch, nhôm tồn tại bền ở dạng Al^3+^ (thực chất là [Al(H~2~O)~6~]^3+^).

### 2.2. Tính chất hóa học

Nhôm là **chất khử mạnh**. Tuy nhiên, trong thực tế nhôm có vẻ "trơ" vì luôn được phủ một **màng oxide mỏng, bền, kín**. Hầu hết tính chất dưới đây là cuộc "giằng co" giữa tính khử mạnh của Al và màng Al~2~O~3~ đó.

**a) Với phi kim**

=> 4M + 3O~2~ → 2M~2~O~3~

Với Al, Ga, In, màng oxide hình thành ngay ở nhiệt độ thường.

- Tl phản ứng **chậm** với oxy.
- Với **Cl~2~, Br~2~**: phản ứng ngay ở nhiệt độ thường; với **I~2~** cần đun nóng.
- Với **S, N, C**: cần nhiệt độ cao (700–800 °C).
- **Không** phản ứng với hydro.

**b) Với nước**

Nhôm **không** phản ứng với nước ở điều kiện thường vì màng oxide. Nếu phá màng này (ví dụ bằng dung dịch kiềm, hoặc hỗn hống với Hg), Al phản ứng ngay:

=> 2Al + 6H~2~O → 2Al(OH)~3~↓ + 3H~2~↑

Lớp Al(OH)~3~ sinh ra không tan, lại bám trên bề mặt nên phản ứng nhanh chóng dừng.

**c) Với acid**

- Acid thường (HCl, H~2~SO~4~ loãng): phản ứng dễ, giải phóng H~2~.

=> 2Al + 6H^+^ + 12H~2~O → 2[Al(H~2~O)~6~]^3+^ + 3H~2~↑

- **Acid hữu cơ** (acetic, citric…): ở lạnh không phản ứng, **đun nóng thì có**. Vì vậy cần lưu ý khi dùng nồi nhôm nấu thức ăn chua (canh chua, dấm, nước chanh), nhất là nấu lâu.
- **Tl** tạo TlCl, Tl~2~SO~4~ (số oxy hóa +1) **khó tan**, phủ lên bề mặt nên phản ứng tự dừng.
- **HNO~3~ đặc nguội, H~2~SO~4~ đặc nguội**: nhôm bị **thụ động hóa** (màng oxide dày lên), không tan. Do đó có thể chở HNO~3~ đặc bằng thùng nhôm.
- **Đun nóng**, acid đặc oxy hóa được nhôm (đáp án giáo trình, tr. 243):

=> 2Al + 6H~2~SO~4~ (đặc, nóng) → Al~2~(SO~4~)~3~ + 3SO~2~↑ + 6H~2~O

=> Al + 6HNO~3~ (đặc, nóng) → Al(NO~3~)~3~ + 3NO~2~↑ + 3H~2~O

=> Al + 4HNO~3~ (loãng) → Al(NO~3~)~3~ + NO↑ + 2H~2~O

> [!bay] Nhôm và HNO₃ loãng
> Phần lý thuyết giáo trình (tr. 20) viết gộp "không phản ứng với HNO~3~ loãng, đặc, H~2~SO~4~ đặc khi nguội". Thực tế chỉ **acid đặc, nguội** mới làm nhôm thụ động. **HNO~3~ loãng vẫn hòa tan nhôm** (tạo NO; rất loãng có thể tạo N~2~O, N~2~ hoặc NH~4~NO~3~). Chính phần đáp án của giáo trình (tr. 243) cũng viết phản ứng Al + HNO~3~ loãng → NO. Khi thi, nhớ câu an toàn: "Al **thụ động** trong HNO~3~ **đặc nguội** và H~2~SO~4~ **đặc nguội**".

**d) Với dung dịch kiềm — điểm đặc biệt của Al, Ga, In**

Đây là câu trả lời cho câu hỏi "tính chất hóa học đặc biệt của Al, Ga, In" (tự lượng giá 2.1). Kiềm hòa tan màng oxide lưỡng tính, sau đó kim loại khử nước, rồi Al(OH)~3~ vừa sinh ra lại tan tiếp trong kiềm:

=> 2M + 2OH^−^ + 6H~2~O → 2[M(OH)~4~]^−^ + 3H~2~↑

=> 2Al + 2NaOH + 6H~2~O → 2Na[Al(OH)~4~] + 3H~2~↑

Sản phẩm Na[Al(OH)~4~] gọi là **natri hydroxo aluminat**.

> [!bay] Cân bằng phương trình
> Đáp án câu 2.1 ở cuối giáo trình (tr. 243) in "**M** + 2OH^−^ + 6H~2~O → 2[M(OH)~4~]^−^ + 3H~2~": thiếu hệ số 2 trước M. Phải là **2M**. Tương tự, sách cũ hay viết sản phẩm là NaAlO~2~ (natri aluminat); cách viết dạng phức Na[Al(OH)~4~] đúng với cấu tạo thực trong dung dịch. Cả hai đều được chấp nhận.

**e) Với oxide kim loại — phản ứng nhiệt nhôm**

Al có **ái lực rất lớn với oxy** (nhiệt tạo thành Al~2~O~3~ rất lớn), nên ở nhiệt độ cao nó "giành" oxy của nhiều oxide kim loại khác:

=> 2Al + Fe~2~O~3~ → Al~2~O~3~ + 2Fe

Phản ứng tỏa nhiệt rất mạnh (giáo trình ghi 195 kcal/mol).

Nhiệt sinh ra đủ làm sắt nóng chảy, nên phản ứng này được dùng để **hàn đường ray**. Nó cũng dùng để điều chế các kim loại khó nóng chảy như **Mn, Cr, Ti**.

### 2.3. Hợp chất

#### a) Oxide M~2~O~3~

- Oxide hóa trị III của Al, Ga, In **bền nhiệt** và **lưỡng tính**.
- Tl có cả oxide hóa trị I và III; **Tl~2~O~3~ phân hủy ở 500 °C**: Tl~2~O~3~ → Tl~2~O + O~2~.
- Al~2~O~3~ (và Ga~2~O~3~) có **hai dạng thù hình α và γ**:

| | **α-Al~2~O~3~** | **γ-Al~2~O~3~** |
|---|---|---|
| Cấu trúc | Tinh thể rất chặt (corundum) | Xốp hơn |
| Độ cứng | Chỉ kém kim cương | Thấp hơn |
| Hoạt động hóa học | **Trơ**, không tan trong acid, kiềm | **Tan** trong acid và kiềm |

=> Al~2~O~3~ + 6H^+^ + 9H~2~O → 2[Al(H~2~O)~6~]^3+^

=> Al~2~O~3~ + 2OH^−^ + 3H~2~O → 2[Al(OH)~4~]^−^

#### b) Hydroxide M(OH)~3~

Đều là **kết tủa keo (nhầy), không tan trong nước** và **lưỡng tính** (trừ Tl(OH)~3~ chỉ tan trong acid):

=> M(OH)~3~ + OH^−^ → [M(OH)~4~]^−^

=> M(OH)~3~ + 3H^+^ + 3H~2~O → [M(H~2~O)~6~]^3+^

![Hình 2. Tính lưỡng tính của nhôm hydroxide: ba dạng tồn tại theo pH](luong-tinh-al.svg)

- **Al(OH)~3~ là base yếu**: nước tiếp xúc với Al(OH)~3~ gần như không có ion Al^3+^, nhưng chỉ cần acid loãng là kết tủa tan ngay thành [Al(H~2~O)~6~]^3+^.
- Al(OH)~3~ tan trong **kiềm mạnh** nhưng **không tan trong base yếu như NH~3~**. Lý do: NH~3~ cho nồng độ OH^−^ quá thấp để chuyển Al(OH)~3~ thành [Al(OH)~4~]^−^.
- **TlOH** thì ngược hẳn: **dễ tan**, là **base mạnh gần bằng KOH** (lại là hệ quả của Tl^+^ giống ion kim loại kiềm).

> [!bay] KOH dư và NH₃ dư cho kết quả khác nhau (tự lượng giá 2.4)
> Nhỏ từ từ đến dư vào dung dịch Al~2~(SO~4~)~3~:
> - **KOH dư**: lúc đầu có kết tủa keo trắng, sau đó **tan hết** → cuối cùng **không còn kết tủa**.
>
> => Al~2~(SO~4~)~3~ + 8KOH (dư) → 2K[Al(OH)~4~] + 3K~2~SO~4~
>
> - **NH~3~ dư** (NH~4~OH): **kết tủa còn nguyên**.
>
> => Al~2~(SO~4~)~3~ + 6NH~3~ + 6H~2~O → 2Al(OH)~3~↓ + 3(NH~4~)~2~SO~4~
>
> Vì vậy muốn **điều chế** Al(OH)~3~ người ta dùng NH~3~, không dùng NaOH.

#### c) Muối

Giáo trình kể các muối điển hình:

| Muối | Tên |
|---|---|
| NH~4~Al(SO~4~)~2~·12H~2~O | Phèn nhôm amoni |
| **KAl(SO~4~)~2~·12H~2~O** | **Phèn nhôm kali (phèn chua)** |
| AlCl~3~ khan | Nhôm clorid (xúc tác) |
| Na~3~AlF~6~ | **Criolit** (natri floroaluminat) |

> [!bay] Công thức phèn chua
> Ở tr. 21 giáo trình in phèn chua là "K.Al(SO~4~)~2~.**6**H~2~O". Đây là **lỗi in**. Phèn chua ngậm **12 phân tử nước**: **KAl(SO~4~)~2~·12H~2~O** (giống phèn nhôm amoni ngay dòng trên, và đúng với bài Hợp chất vô cơ). Hãy viết ·12H~2~O.

- Nhôm florid kết hợp với florid kim loại kiềm tạo **criolit Na~3~AlF~6~**, có nhiệt độ nóng chảy không cao → dùng trong **sản xuất nhôm** (mục 2.5).
- **Muối nhôm thủy phân rất mạnh**, tạo Al(OH)~3~ dạng keo. Vì thế dung dịch muối nhôm có **môi trường acid**.

=> Al^3+^ + 3H~2~O ⇌ Al(OH)~3~ + 3H^+^

**Vì sao phèn làm trong nước? (tự lượng giá 2.7)** Hạt Al(OH)~3~ keo có diện tích bề mặt rất lớn và tích điện. Chúng hút các hạt bùn, đất lơ lửng (vốn mang điện tích ngược dấu), kết lại thành bông lớn, nặng rồi **lắng xuống, kéo theo chất bẩn**. Nước phía trên trở nên trong. Đây là nguyên lý **keo tụ** dùng trong nhà máy nước (phèn nhôm Al~2~(SO~4~)~3~, PAC – poly nhôm clorid).

**Thủy phân "cộng hưởng" (tự lượng giá 2.5).** Đun sôi dung dịch chứa Al~2~(SO~4~)~3~ và natri acetat thì có kết tủa. Al^3+^ thủy phân tạo H^+^; ion acetat (gốc acid yếu) lại "bắt" H^+^ đó tạo CH~3~COOH. H^+^ bị lấy đi liên tục nên cân bằng thủy phân bị kéo hết về phía Al(OH)~3~; đun sôi càng thúc đẩy quá trình.

=> Al~2~(SO~4~)~3~ + 6CH~3~COONa + 6H~2~O → 2Al(OH)~3~↓ + 3Na~2~SO~4~ + 6CH~3~COOH

> [!yhct] Bạch phàn và Khô phàn — hóa học của vị "thu liễm"
> **Bạch phàn** chính là phèn chua KAl(SO~4~)~2~·12H~2~O tinh chế. **Khô phàn** (phèn phi, Khô bạch phàn) là Bạch phàn được **nung (phi)** cho mất nước kết tinh:
>
> => KAl(SO~4~)~2~·12H~2~O → KAl(SO~4~)~2~ + 12H~2~O
>
> - **Khi nung**, tinh thể chảy lỏng trong chính nước kết tinh của nó, sủi bọt rồi khô thành **khối trắng, xốp, nhẹ**. Khô phàn **hút nước mạnh** nên làm khô bề mặt ẩm ướt (vết loét chảy dịch, chàm chảy nước). Đây là một cơ sở hóa học cho tính "táo thấp" của Khô phàn khi dùng ngoài.
> - **Không nung quá lửa.** Ở nhiệt độ rất cao, muối bắt đầu phân hủy, giải phóng SO~3~ và để lại Al~2~O~3~ dạng α trơ (mục 2.3a). Al^3+^ hòa tan được — phần tạo ra tác dụng — sẽ giảm. Vì vậy phép phi phèn chỉ đun đến khi **vừa khô xốp** là dừng.
> - **Tác dụng làm se.** Al^3+^ thủy phân tạo môi trường acid nhẹ và liên kết với các nhóm –COO^−^ của protein trên bề mặt mô. Protein bị **đông vón**, tạo một lớp màng mỏng, làm mô co lại, **giảm tiết dịch và rỉ máu mao mạch**. Cùng nguyên lý này: **bút cầm máu** khi cạo râu là phèn; **chất chống mồ hôi** chứa muối nhôm clorohydrat làm tắc tạm thời ống tuyến mồ hôi.
> - Liên hệ: **Xích thạch chi** (đất sét đỏ, chủ yếu là **nhôm silicat ngậm nước** lẫn oxide sắt) là vị "sáp trường chỉ tả" (cầm tiêu chảy). Nguyên lý hấp phụ, bao phủ niêm mạc của nó gần với thuốc tây chứa đất sét nhôm silicat (như diosmectit).
> - **Thận trọng:** phèn chủ yếu **dùng ngoài**. Uống thì liều nhỏ, ngắn ngày (Dược điển Trung Quốc ghi 0,6–1,5 g/ngày) vì phèn kích ứng dạ dày và nhôm tích lũy ở người suy thận (xem mục 2.6).

### 2.4. Trạng thái tự nhiên

- Hợp chất phổ biến nhất của nhôm trong tự nhiên là quặng **bauxit** (bôxit), chứa tới khoảng **60% Al~2~O~3~** (dạng ngậm nước).
- **α-Al~2~O~3~** có trong tự nhiên dưới dạng **corundum**: nóng chảy ở khoảng **2050 °C**, rất cứng.
  - **Saphia** (sapphire) màu xanh lam do lẫn vết **titan và sắt**.
  - **Rubi** (hồng ngọc) màu đỏ do lẫn **crom**.
  - Cả hai là đá quý, dùng làm trang sức và trong kỹ thuật (ổ trục đồng hồ, laser rubi).

### 2.5. Điều chế và ứng dụng

**Lịch sử điều chế.** Lúc đầu nhôm được điều chế bằng cách dùng natri khử nhôm clorid:

=> AlCl~3~ + 3Na → Al + 3NaCl

Sau đó người ta điện phân muối kép **NaCl·AlCl~3~ nóng chảy**. Giáo trình ghi mốc **"1954"**; trong lịch sử hóa học, phương pháp này của Sainte-Claire Deville thuộc khoảng **năm 1854**, nên nhiều khả năng đây là lỗi in.

**Ngày nay** (từ năm 1886, phương pháp Hall–Héroult): **điện phân nóng chảy Al~2~O~3~ có mặt criolit**.

=> 2Al~2~O~3~ → 4Al + 3O~2~

Điều kiện: điện phân nóng chảy, có criolit, khoảng 950 °C.

- Catod (cực âm): Al^3+^ + 3e → Al
- Anod (cực dương, bằng than chì): 2O^2−^ → O~2~ + 4e; oxy sinh ra đốt cháy dần anod thành CO, CO~2~ nên anod phải thay định kỳ.

**Vì sao cần criolit? (tự lượng giá 2.2)** Al~2~O~3~ nóng chảy ở khoảng 2050 °C, quá tốn năng lượng. Hòa Al~2~O~3~ vào criolit nóng chảy thì hỗn hợp chỉ cần khoảng 950 °C. Criolit còn làm hỗn hợp **dẫn điện tốt hơn** và tạo lớp bảo vệ nhôm nóng chảy khỏi bị oxy hóa.

Sơ đồ sản xuất: **quặng bauxit → tinh chế thành Al~2~O~3~ → hòa vào criolit nóng chảy → điện phân → nhôm**.

**Ứng dụng của nhôm và hợp chất** (giáo trình nêu):

- Nhôm: vai trò lớn trong kỹ thuật, xây dựng, đời sống (nhẹ, bền, dẫn điện, dẫn nhiệt tốt).
- **AlCl~3~** là **xúc tác** (acid Lewis) cho phản ứng **Friedel–Crafts** trong hóa hữu cơ (gắn nhóm alkyl, acyl vào vòng benzen).
- **Li[AlH~4~]** (lithi nhôm hydrid) là chất **khử mạnh** trong tổng hợp hữu cơ: khử liên kết C=O của **aldehyd, ceton, ester, acid** thành **alcol**.

### 2.6. Nhôm và các nguyên tố nhóm IIIA trong y học

> [!ung-dung] Thuốc chứa nhôm
> - **Al(OH)~3~ kháng acid dạ dày**: là base yếu, không tan, nên trung hòa HCl **từ từ** và tại chỗ, không làm pH dạ dày tăng vọt hay sinh CO~2~ (khác NaHCO~3~). Al(OH)~3~ + 3HCl → AlCl~3~ + 3H~2~O. Tác dụng phụ **táo bón**, nên thường phối hợp với Mg(OH)~2~ (xem bài Hợp chất vô cơ).
> - **Tương tác thuốc**: ion Al^3+^ tạo phức (chelat) với **tetracyclin, fluoroquinolon (ciprofloxacin…), muối sắt, levothyroxin**, làm giảm hấp thu các thuốc này. Cần uống cách nhau ít nhất **2 giờ** (theo hướng dẫn của từng thuốc).
> - Al(OH)~3~ gắn **phosphat** trong ruột. Dùng lâu dài có thể gây **giảm phosphat máu**, ảnh hưởng xương.
> - **Sucralfat** (muối nhôm của sucrose octasulfat) bám vào ổ loét dạ dày tạo lớp màng bảo vệ.
> - **Tá chất vaccin** (adjuvant): muối nhôm (hydroxide, phosphat) giúp kháng nguyên lưu lại lâu tại chỗ tiêm, tăng đáp ứng miễn dịch.
> - Nhóm IIIA còn có mặt trong **y học hạt nhân**: Ga-67, **Ga-68** (chụp PET), In-111, **Tl-201** (chụp xạ hình tưới máu cơ tim, vì Tl^+^ có kích thước gần K^+^ nên được tế bào cơ tim hấp thu như K^+^).

> [!cap-nhat] Nhôm và thần kinh — thận trọng nhưng không hoảng sợ
> - **Người suy thận** thải nhôm kém. Trước đây bệnh nhân lọc máu dùng Al(OH)~3~ kéo dài (để gắn phosphat) hoặc lọc máu bằng nước chứa nhôm đã bị **bệnh não do nhôm** ("sa sút trí tuệ khi lọc máu"), **nhuyễn xương** và **thiếu máu hồng cầu nhỏ**. Vì vậy hiện nay **tránh dùng thuốc chứa nhôm kéo dài ở người suy thận**; nước lọc máu được kiểm soát nhôm chặt chẽ.
> - Giả thuyết "nhôm gây **bệnh Alzheimer**" (từ nồi nhôm, thuốc kháng acid, chất chống mồ hôi) từng được nhắc nhiều. Các bằng chứng hiện nay **chưa chứng minh được** mối quan hệ nhân quả ở người có thận bình thường.
> - Thực hành hợp lý: không nấu, ủ lâu thức ăn chua mặn trong nồi nhôm (đúng như giáo trình lưu ý); người có chức năng thận bình thường dùng thuốc kháng acid chứa nhôm ngắn ngày là an toàn.

> [!ung-dung] Thali — chất độc "giả làm kali"
> Muối thali (Tl^+^) từng được dùng làm **thuốc diệt chuột**. Vì Tl^+^ giống K^+^, nó lọt vào tế bào qua kênh và bơm của kali rồi phá rối chuyển hóa. Ngộ độc gây **rụng tóc** đặc trưng, viêm đa dây thần kinh rất đau, rối loạn tiêu hóa. Thuốc giải là **xanh Phổ** (Prussian blue), chất này "bẫy" Tl^+^ trong ruột và tăng thải qua phân.

## 3. Kim loại nhóm IVA — thiếc và chì

### 3.1. Vị trí và đặc điểm

- Thiếc (Sn) và chì (Pb) là kim loại khối p, nhóm **IVA**.
- Lớp electron hóa trị **ns^2^np^2^**.
- Số oxy hóa đặc trưng **+2** (chỉ dùng 2 electron p) và **+4** (dùng cả 4 electron). Với Sn, **+4 bền hơn**; với Pb, **+2 bền hơn** (hiệu ứng cặp electron trơ, mục 1).

### 3.2. Tính chất hóa học

**a) Với phi kim**

- **Oxy**: trong không khí ở nhiệt độ thường **thiếc không bị biến đổi**. **Chì** bị oxy hóa thành một lớp oxide, lớp này dần chuyển thành **chì carbonat base**, ngăn cản sự oxy hóa tiếp (vì vậy chì để lâu có màu xám xỉn).
- **Halogen**: thiếc cho sản phẩm **+4**, chì cho chì(II) halid:

=> Sn + 2X~2~ → SnX~4~

=> Pb + X~2~ → PbX~2~

**b) Với nước**

Trong hai kim loại, **chỉ chì** khi tiếp xúc với nước **có hòa tan không khí** thì lớp PbO bên ngoài bị bong dần, và chì tiếp tục bị ăn mòn:

=> 2Pb + O~2~ + 2H~2~O → 2Pb(OH)~2~

> [!bay] Hệ số của phương trình chì + nước
> Giáo trình (tr. 23) in "2Pb + O~2~ + **H~2~O** → 2Pb(OH)~2~" — vế phải có 4 H nhưng vế trái chỉ có 2 H. Phương trình đúng cần **2H~2~O**. Đây cũng là lý do **ống nước bằng chì** bị cấm: nước (nhất là nước mềm, hơi acid) hòa tan dần chì vào nước uống.

**c) Với acid**

- Sn và Pb có **thế điện cực âm** (đứng trước H) nên phản ứng được với acid thường:

=> Sn + 2HCl → SnCl~2~ + H~2~↑

- Phản ứng của **chì chỉ xảy ra trên bề mặt**: tạo lớp **PbCl~2~ hoặc PbSO~4~ khó tan** bao lấy kim loại, nên chì gần như không tan tiếp trong HCl, H~2~SO~4~ loãng. (Vì vậy chì làm được bản cực của **acquy chì – acid sulfuric**.)
- **HNO~3~ loãng**: tạo NO và muối nitrat M(II):

=> 3M + 8HNO~3~ → 3M(NO~3~)~2~ + 2NO↑ + 4H~2~O

- **H~2~SO~4~ đặc nóng** oxy hóa thiếc lên **Sn^4+^**:

=> Sn + 4H~2~SO~4~ (đặc, nóng) → Sn(SO~4~)~2~ + 2SO~2~↑ + 4H~2~O

- **Acid hữu cơ**: chì chỉ phản ứng khi **có mặt oxy**:

=> 2Pb + 4CH~3~COOH + O~2~ → 2Pb(CH~3~COO)~2~ + 2H~2~O

> [!vi-du] "Đường chì" và bình rượu bằng chì
> Chì(II) acetat có **vị ngọt** nên xưa gọi là "đường chì" (sugar of lead). Người La Mã nấu cô nước nho trong nồi chì để làm chất tạo ngọt cho rượu: acid hữu cơ của nho + oxy không khí + chì cho đúng phản ứng trên. Đây là một nguồn **ngộ độc chì mạn tính** kinh điển. Bài học hiện đại: **không đựng giấm, rượu, nước quả chua trong đồ gốm tráng men chì, đồ pha lê chì hoặc vật dụng hàn chì**.

**d) Với dung dịch kiềm**

Khi **đun nóng**, Sn và Pb tan trong kiềm, giải phóng hydro (giống nhôm, do oxide/hydroxide của chúng lưỡng tính):

=> M + 2NaOH + 2H~2~O → Na~2~[M(OH)~4~] + H~2~↑

### 3.3. Hợp chất

#### a) Oxide MO và MO~2~

- Các oxide MO đều **khó tan trong nước**.
- Hai oxide phổ biến của chì là **PbO** và **PbO~2~**.
- **Mọi oxide của thiếc và chì đều tan trong cả acid và kiềm** (lưỡng tính). Ví dụ với PbO (tự lượng giá 2.8):

=> PbO + 2HNO~3~ → Pb(NO~3~)~2~ + H~2~O

=> PbO + 2NaOH + H~2~O → Na~2~[Pb(OH)~4~]

Sản phẩm là natri hydroxo plumbit.

#### b) Hydroxide M(OH)~2~

**Lưỡng tính**: tan trong acid, và tan trong kiềm tạo **hydroxo stanit** (của thiếc) hoặc **hydroxo plumbit** (của chì):

=> Pb(OH)~2~ + 2KOH → K~2~[Pb(OH)~4~]

=> Sn(OH)~2~ + 2KOH → K~2~[Sn(OH)~4~]

Hai sản phẩm trên lần lượt là **kali hydroxo plumbit** và **kali hydroxo stanit**.

=> Sn(OH)~2~ + 2HCl → SnCl~2~ + 2H~2~O

> [!bay] Đuôi tên của anion phức
> Số oxy hóa **+2**: stan**it**, plumb**it** (K~2~[Sn(OH)~4~], K~2~[Pb(OH)~4~]). Số oxy hóa **+4** mới là stan**at**, plumb**at** (ví dụ Na~2~[Sn(OH)~6~]). Với nhôm: [Al(OH)~4~]^−^ là hydroxo **aluminat**.

#### c) Muối

- **PbSO~4~ khó tan** (kết tủa trắng). Trong hóa phân tích, sự tạo kết tủa PbSO~4~ dùng để **định tính ion Pb^2+^** hoặc ngược lại **ion SO~4~^2−^**.

=> Pb^2+^ + SO~4~^2−^ → PbSO~4~↓ (trắng)

- **Sn^2+^ là chất khử mạnh**, dễ bị oxy hóa lên Sn^4+^. **Pb^2+^ không có tính chất này** (vì Pb(II) mới là trạng thái bền).

=> SnCl~2~ + 2FeCl~3~ → SnCl~4~ + 2FeCl~2~

=> SnCl~2~ + 2HgCl~2~ → SnCl~4~ + Hg~2~Cl~2~↓ (trắng)

> [!vi-du] Nhận biết Pb²⁺ (bổ sung từ hóa phân tích)
> Ngoài PbSO~4~ trắng, ion Pb^2+^ còn cho **PbI~2~ vàng tươi** (với I^−^), **PbCrO~4~ vàng** (với CrO~4~^2−^) và **PbS đen** (với H~2~S hoặc S^2−^). Giấy tẩm chì acetat hóa đen khi gặp H~2~S, nên còn dùng để phát hiện khí H~2~S.

### 3.4. Trạng thái tự nhiên và điều chế

- **Thiếc**: khoáng vật chính là quặng **caxiterit (SnO~2~)**. Việt Nam có mỏ thiếc ở **Tĩnh Túc (Cao Bằng)**.
- **Chì**: quặng **galen (PbS)**, thường đi kèm khoáng vật của kẽm; ngoài ra có **chì carbonat** trong khoáng **xeruxit** (PbCO~3~).
- Điều chế thiếc: dùng **carbon khử SnO~2~**:

=> SnO~2~ + 2C → Sn + 2CO  (1300 °C)

### 3.5. Ứng dụng

| Chất | Ứng dụng (giáo trình) | Vì sao |
|---|---|---|
| **Sn** | Tráng lên tấm sắt làm vỏ đồ hộp ("**sắt tây**") | Thiếc bền với nước và không khí, ít độc |
| Hợp kim **đồng – thiếc** | Đúc tiền, đúc tượng | Cứng, bền, dễ đúc |
| **SnCl~2~** | Chất **cắn màu** trong công nghệ nhuộm | Sn^2+^/Sn^4+^ tạo phức giữ màu trên sợi |
| **Pb** | **Tấm chắn phóng xạ** (tia X, tia γ) | Chì nặng, mật độ electron lớn, hấp thụ tia tốt |
| PbO, Pb~2~O~3~ | Sản xuất thủy tinh (thủy tinh chì, pha lê) | Tăng chiết suất, độ lấp lánh |

> [!bay] "Đồng thau" hay "đồng thiếc"?
> Giáo trình (tr. 24) gọi hợp kim thiếc và đồng là "đồng thau". Theo cách gọi chuẩn: **đồng thiếc** (đồng thanh, bronze) = **Cu + Sn**; còn **đồng thau** (brass) = **Cu + Zn**. Hợp kim dùng đúc tiền cổ, đúc tượng, trống đồng là **đồng thiếc**.

> [!ung-dung] Thiếc và chì trong y tế
> - **Áo chì, tấm chì, kính chì** trong phòng chụp X-quang, CT, xạ trị bảo vệ nhân viên và bệnh nhân.
> - **SnCl~2~** (tính khử của Sn^2+^) có trong các **bộ kit đánh dấu Tc-99m** ở khoa y học hạt nhân: Sn^2+^ khử ion pertechnetat để technetium gắn được vào thuốc phóng xạ.
> - **Thiếc(II) florid (SnF~2~)** có trong một số kem đánh răng, giúp chống sâu răng và viêm lợi.
> - Thiếc kim loại ít độc. Ngược lại, các **hợp chất thiếc hữu cơ** (như tributyltin, từng dùng trong sơn chống hà) **rất độc**.

### 3.6. Tác dụng sinh học — độc tính của chì

Theo giáo trình:

- Chì và **mọi hợp chất của chì đều độc**. Chì tác động lên **hệ thần kinh** và **ngăn cản quá trình tạo máu**. Phải cẩn thận khi tiếp xúc.
- **Chì tetraethyl Pb(C~2~H~5~)~4~** từng được pha vào xăng làm **chất chống kích nổ**. Chất này dễ thấm qua niêm mạc miệng và qua da vào máu, nên ngày nay **bị cấm**.
- **Nhiễm độc chì** hay gặp ở **công nhân** tiếp xúc thường xuyên: nhà máy **acquy**, nhà máy hóa chất, xưởng in hay đúc chữ in…
- Nguy hiểm ở chỗ bệnh **diễn ra từ từ**, gây **thiếu máu mạn tính**, trong khi cơ thể **đào thải chì rất chậm** (chì tích lũy lâu dài trong **xương**).

**Vì sao chì độc? — cơ chế "bắt nhóm –SH".** Pb^2+^ là ion kim loại nặng có ái lực rất mạnh với **lưu huỳnh**. Nó gắn vào các **nhóm thiol (–SH)** của cystein trong enzym, làm enzym biến dạng và mất hoạt tính. Pb^2+^ còn "đóng vai" Ca^2+^ và Zn^2+^: chiếm chỗ của chúng trong protein và kênh ion, nên rối loạn dẫn truyền thần kinh và lắng đọng vào xương như canxi.

![Hình 3. Chì ức chế hai enzym chứa nhóm –SH trên con đường tổng hợp hem](chi-hem.svg)

Hai enzym trên con đường tổng hợp hem rất nhạy với chì:

1. **ALA dehydratase** (ALAD, ghép 2 phân tử acid δ-aminolevulinic thành porphobilinogen): bị ức chế → **ALA tăng trong máu và nước tiểu**.
2. **Ferrochelatase** (gắn Fe^2+^ vào protoporphyrin IX tạo hem): bị ức chế → protoporphyrin không gắn được sắt, gắn **kẽm** thay thế → **kẽm protoporphyrin (ZPP) hồng cầu tăng**.

Kết quả: thiếu hem → thiếu hemoglobin → **thiếu máu** (thường hồng cầu nhỏ, nhược sắc). Hồng cầu có thể có **hạt ưa base (chấm bazơ)**. Đây chính là cơ sở hóa sinh của câu "chì ngăn cản quá trình tạo máu" trong giáo trình.

> [!ung-dung] Ngộ độc chì trên lâm sàng
> - **Biểu hiện mạn tính**: thiếu máu, **đau bụng chì** (cơn đau quặn bụng), táo bón, **đường viền xanh xám ở lợi** (đường Burton), liệt duỗi cổ tay ("bàn tay rủ") do tổn thương thần kinh ngoại biên, tăng huyết áp, tổn thương thận.
> - **Trẻ em nhạy cảm hơn nhiều**: hấp thu chì qua ruột cao hơn người lớn, não đang phát triển → **giảm trí tuệ (IQ)**, chậm phát triển, rối loạn hành vi; nặng có thể **bệnh não cấp** (co giật, hôn mê).
> - **Xét nghiệm**: **nồng độ chì máu** là chính; hỗ trợ bằng ZPP hồng cầu, ALA niệu, công thức máu.
> - **Điều trị**: trước hết **cắt nguồn tiếp xúc**. Ca nặng dùng **thuốc tạo phức (chelat)** cũng dựa trên ái lực với kim loại: CaNa~2~EDTA, **DMSA (succimer)**, dimercaprol (BAL — chính là chất mang nhóm **–SH** để "giành" chì khỏi enzym).

> [!cap-nhat] Không có ngưỡng chì "an toàn"
> - Giáo trình viết "ngày nay người ta không cho phép dùng chì tetraethyl". Cụ thể: Việt Nam ngừng dùng xăng pha chì từ năm 2001; đến **năm 2021**, xăng pha chì đã bị loại bỏ trên **toàn thế giới** (theo Chương trình Môi trường Liên Hợp Quốc).
> - Ngày nay các tổ chức y tế (WHO, CDC Hoa Kỳ) khẳng định **không có mức chì máu nào được coi là an toàn**, nhất là với trẻ em. CDC dùng mức tham chiếu **3,5 µg/dL** ở trẻ em để xác định trẻ cần can thiệp (cập nhật năm 2021).
> - Nguồn chì hiện nay: sơn cũ, pin/acquy tái chế thủ công, gốm tráng men chì, đồ chơi kém chất lượng, mỹ phẩm và **thuốc dân gian không rõ nguồn gốc** (xem khung YHCT dưới đây).

> [!yhct] Duyên đan, Mật đà tăng — vị thuốc chứa chì
> Một số khoáng dược cổ là **oxide chì**:
>
> | Vị thuốc | Thành phần chính | Ghi chú |
> |---|---|---|
> | **Duyên đan** (Hoàng đan, Chì đỏ) | **Pb~3~O~4~** (minium, màu đỏ cam) | Oxide hỗn hợp, chứa cả Pb(II) và Pb(IV): Pb~3~O~4~ = 2PbO·PbO~2~ |
> | **Mật đà tăng** (Đà tăng) | **PbO** (litharge, màu vàng) | Oxide chì(II) |
>
> - **Công dụng cổ truyền** chủ yếu là **dùng ngoài**: sát trùng, thu liễm, làm lành vết loét, sinh cơ. Ứng dụng nổi tiếng là nấu **cao dán đen** (hắc cao dược): đun dầu thực vật thật nóng rồi cho Duyên đan vào. **Cơ sở hóa học:** oxide chì (lưỡng tính nhưng thiên về base) ở nhiệt độ cao phản ứng với các acid béo trong dầu (xà phòng hóa) tạo **xà phòng chì** (chì oleat, chì stearat…) dẻo dính. Đó là "khung" của miếng cao dán. Chì acetat cũng hình thành tương tự khi oxide chì gặp giấm.
> - **Cảnh báo độc**: đây là **chì vô cơ**, độc như mọi hợp chất chì (mục 3.6). Chì hấp thu được qua **niêm mạc và vết thương hở rộng**, tích lũy lâu dài. **Không dùng uống**, không bôi diện rộng, kéo dài, không dùng cho trẻ em, phụ nữ có thai và cho con bú. Người bào chế phải tránh hít bụi chì và khói khi nấu cao.
> - Ở Việt Nam đã có nhiều báo cáo **trẻ em ngộ độc chì do dùng "thuốc cam" và các bài thuốc dân gian không rõ nguồn gốc** có chứa chì. Khi hành nghề, không dùng các chế phẩm khoáng chứa chì, thủy ngân, arsen chưa được kiểm nghiệm. Hỏi tiền sử dùng thuốc dân gian ở trẻ thiếu máu hoặc chậm phát triển không rõ nguyên nhân.

## 4. Giải nhanh câu hỏi tự lượng giá (tr. 24–25)

> [!vi-du] Đối chiếu với đáp án cuối sách (tr. 243)
> Đáp án cuối sách đánh số **lệch một số** so với câu hỏi (đáp án ghi "2.4" thực ra trả lời câu 2.3; "2.9" trả lời câu 2.8…) và có vài lỗi cân bằng. Dưới đây là bản đã sửa:
> - **2.1** Tính chất đặc biệt của Al, Ga, In: **tan trong dung dịch kiềm** giải phóng H~2~: 2M + 2OH^−^ + 6H~2~O → 2[M(OH)~4~]^−^ + 3H~2~↑.
> - **2.2** Nguyên liệu: **bauxit** → Al~2~O~3~; **điện phân nóng chảy Al~2~O~3~ trong criolit** (mục 2.5).
> - **2.3** Al + HCl, H~2~SO~4~ loãng → H~2~; Al **thụ động** với HNO~3~, H~2~SO~4~ **đặc nguội**; đặc nóng → SO~2~, NO~2~; HNO~3~ loãng → NO (mục 2.2c). *Đáp án sách in "2Al + 6H~2~SO~4~ → Al~2~(SO~4~)~3~ + 3H~2~O + 3SO~2~": phải là **6H~2~O**.*
> - **2.4** KOH dư: kết tủa tan hết; NH~3~ dư: **có kết tủa** Al(OH)~3~.
> - **2.5** Thủy phân thúc đẩy lẫn nhau, tạo Al(OH)~3~↓. *Đáp án sách thiếu hệ số: sản phẩm phải là **6CH~3~COOH**.*
> - **2.6** Al(OH)~3~ + 3HCl → AlCl~3~ + 3**H~2~O**; Al(OH)~3~ + KOH → K[Al(OH)~4~] (hay KAlO~2~ + 2H~2~O). *Đáp án sách in nhầm sản phẩm "3H~2~↑".*
> - **2.7** Al^3+^ thủy phân tạo Al(OH)~3~ keo, kéo chất bẩn lắng xuống.
> - **2.8** PbO tan trong acid và kiềm (mục 3.3a); Sn(OH)~2~ + 2HCl → SnCl~2~ + 2H~2~O; Sn(OH)~2~ + 2KOH → K~2~[Sn(OH)~4~] (kali hydroxo stanit).
> - **2.9** Ứng dụng và tác dụng sinh học: bảng ở mục 2.5, 3.5 và mục 3.6.

## Tóm tắt

| | **Nhôm (IIIA)** | **Thiếc (IVA)** | **Chì (IVA)** |
|---|---|---|---|
| Lớp hóa trị | 3s^2^3p^1^ | 5s^2^5p^2^ | 6s^2^6p^2^ |
| Số oxy hóa | +3 | +2, **+4 bền hơn** | **+2 bền hơn**, +4 |
| Với không khí | Màng Al~2~O~3~ bảo vệ | Không đổi | Màng oxide → chì carbonat base |
| Với acid thường | Tan, cho H~2~ | Tan, cho H~2~ (SnCl~2~) | Chỉ bề mặt (PbCl~2~, PbSO~4~ khó tan) |
| Với acid oxy hóa | **Thụ động** khi đặc nguội; đặc nóng → SO~2~, NO~2~; HNO~3~ loãng → NO | HNO~3~ loãng → Sn(NO~3~)~2~ + NO; H~2~SO~4~ đặc nóng → Sn(SO~4~)~2~ (Sn^4+^) | HNO~3~ loãng → Pb(NO~3~)~2~ + NO |
| Với kiềm | Tan ngay (H~2~↑) | Tan khi đun nóng | Tan khi đun nóng |
| Oxide, hydroxide | Lưỡng tính (α-Al~2~O~3~ trơ) | Lưỡng tính | Lưỡng tính |
| Điểm nhấn | Nhiệt nhôm; muối thủy phân làm trong nước | **Sn^2+^ chất khử mạnh** | PbSO~4~ khó tan; **độc** |
| Quặng | Bauxit; corundum | Caxiterit SnO~2~ | Galen PbS; xeruxit PbCO~3~ |
| Điều chế | Điện phân Al~2~O~3~ + criolit | SnO~2~ + C (1300 °C) | — |
| Y học | Al(OH)~3~ kháng acid; tránh dùng lâu ở suy thận | Kit Tc-99m (SnCl~2~), SnF~2~ | Áo chì; **ngộ độc**: ức chế ALAD, ferrochelatase → thiếu máu, tổn thương thần kinh |
| YHCT | Bạch phàn, Khô phàn (thu liễm, dùng ngoài) | — | Duyên đan Pb~3~O~4~, Mật đà tăng PbO — **độc**, chỉ dùng ngoài, hạn chế |
