---
title: Hydrocarbon
thoi-gian: 35 phút
muc-tieu:
- Phân biệt được cấu tạo của hydrocarbon no (alkan, cycloalkan), hydrocarbon không no (alken, alkyn, alkadien) và hydrocarbon thơm (benzen và đồng đẳng).
- Trình bày được cơ chế thế gốc tự do S~R~ của alkan, cơ chế cộng electrophil A~E~ của alken và cơ chế thế electrophil S~E~ của hydrocarbon thơm; vận dụng quy tắc Markovnikov và quy tắc thế vào vòng benzen.
- Nêu được ví dụ và ứng dụng của một số hydrocarbon: methan, vaselin, parafin, ethylen, acetylen, isopren, terpen, caroten, benzen, naphthalen.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Hydrocarbon chỉ gồm **C và H**. Chia 3 loại: **no** (chỉ liên kết σ), **không no** (có C=C hoặc C≡C), **thơm** (vòng benzen).
> 2. **Alkan** C~n~H~2n+2~: rất trơ, phản ứng đặc trưng là **thế gốc tự do S~R~** (cần ánh sáng); H ở C **bậc cao** dễ bị thế hơn.
> 3. **Alken** C~n~H~2n~, **alkyn** C~n~H~2n−2~: liên kết π kém bền → phản ứng đặc trưng là **cộng electrophil A~E~**, theo **quy tắc Markovnikov**; làm **mất màu nước brom và KMnO~4~**. Alkyn **đầu mạch** cho kết tủa với AgNO~3~/NH~3~.
> 4. **Benzen**: vòng phẳng, 6 e π giải tỏa đều, mọi C–C dài 1,39 Å → **dễ thế (S~E~), khó cộng, khó oxy hóa**.
> 5. **Quy tắc thế**: nhóm **loại I** (alkyl, –OH, –NH~2~, halogen) → **ortho, para**; nhóm **loại II** (–NO~2~, –CHO, –COOH) → **meta**. Terpen = (C~5~H~8~)~n~, ghép từ các đơn vị **isopren**.

Hydrocarbon là hợp chất hữu cơ mà phân tử chỉ chứa hai nguyên tố **carbon và hydro**. Đây là "bộ khung" để từ đó tạo ra mọi nhóm hợp chất ở các bài sau: thay H bằng halogen được dẫn xuất halogen (bài 6), thay bằng –OH được alcol, phenol (bài 7)… Giáo trình chia hydrocarbon thành ba loại: **no**, **không no** và **thơm** (Giáo trình tr. 122).

| | Hydrocarbon no | Hydrocarbon không no | Hydrocarbon thơm |
|---|---|---|---|
| Liên kết C–C | Chỉ σ (đơn) | Có C=C hoặc C≡C | Vòng benzen, π giải tỏa |
| Lai hóa C | sp^3^ | sp^2^ (C=C), sp (C≡C) | sp^2^ |
| Phản ứng đặc trưng | **Thế gốc S~R~** | **Cộng electrophil A~E~** | **Thế electrophil S~E~** |
| Ví dụ | Methan, cyclohexan, vaselin | Ethylen, acetylen, isopren, terpen | Benzen, toluen, naphthalen |

## 1. Hydrocarbon no

### 1.1. Định nghĩa, phân loại và đặc điểm cấu trúc

Hydrocarbon no chỉ có **liên kết σ** trong phân tử. Có hai nhóm:

- **Alkan** (parafin), mạch hở: công thức chung **C~n~H~2n+2~ (n ≥ 1)**. Ví dụ: methan CH~4~, propan C~3~H~8~.
- **Cycloalkan** (cycloparafin), mạch vòng: **C~n~H~2n~ (n ≥ 3)**. Ví dụ: cyclopropan C~3~H~6~, cyclohexan C~6~H~12~.

Mọi C trong alkan đều **lai hóa sp^3^**, góc liên kết xấp xỉ **109°28′** (tứ diện). Liên kết C–C và C–H gần như **không phân cực** và rất bền. Đó là lý do alkan "trơ".

**Sức căng Bayer.** C trong cycloalkan cũng lai hóa sp^3^. Nhưng ở vòng 3 cạnh và 4 cạnh, góc giữa các C bị ép nhỏ hơn nhiều so với 109°28′ (vòng 3 cạnh chỉ 60°). Liên kết bị "uốn cong", luôn có xu hướng bật ra để trở về góc tứ diện. Hiện tượng này do Bayer phát hiện, gọi là **sức căng Bayer**. Vòng càng nhỏ thì sức căng càng lớn, vòng càng dễ vỡ.

- **Cyclopropan, cyclobutan**: vòng kém bền.
- **Cyclopentan, cyclohexan**: vòng bền.
- **Cyclohexan** có hai cấu dạng **ghế** và **thuyền**, cả hai đều giữ được góc tứ diện. Dạng **ghế** bền vì các H ở vị trí **xen kẽ**; dạng thuyền có một số H ở vị trí **che khuất** nên kém bền (xem bài 1, mục 2.5).

> [!vi-du] Vì sao cyclohexan không có sức căng?
> Bayer giả định vòng **phẳng**. Nếu phẳng, góc của lục giác đều là 120°, lệch khỏi 109°28′. Nhưng vòng cyclohexan **không phẳng**: nó gập lại thành dạng ghế, nhờ đó mọi góc đều đúng 109°28′. Vì vậy cyclohexan bền gần như alkan mạch hở, và vòng 6 cạnh rất phổ biến trong tự nhiên (đường, steroid, terpen…).

### 1.2. Tính chất vật lý

- Ở điều kiện thường: **C~1~–C~4~** (methan → butan) là **khí**; **C~5~–C~19~** là **lỏng**; từ **C~20~** trở lên là **rắn** (theo giáo trình tr. 123).
- Nhiệt độ sôi, nhiệt độ nóng chảy **tăng theo số C** và **giảm khi mạch có nhánh** (phân tử gọn hơn, diện tiếp xúc nhỏ hơn).
- Alkan **nhẹ hơn nước**, **ít tan trong nước**, tan tốt trong dung môi hữu cơ. Lý do: alkan không phân cực, không tạo liên kết hydro với nước.

### 1.3. Tính chất hóa học

Alkan kém hoạt động hơn mọi loại hợp chất hữu cơ khác. Ở điều kiện thường, alkan **không** tác dụng với acid, base, chất oxy hóa, kim loại hoạt động. Phản ứng chỉ xảy ra khi **đun nóng, chiếu sáng** hoặc có chất khơi mào, xúc tác, và hầu hết theo kiểu **phân cắt đồng ly** (tạo gốc tự do).

#### a) Phản ứng thế H bằng halogen — cơ chế S~R~

=> R–H + X~2~ →(ánh sáng, hν) R–X + HX

Phản ứng xảy ra theo **cơ chế thế gốc tự do (S~R~)**, gồm 3 giai đoạn (Giáo trình tr. 111–112):

**(1) Khơi mào**: ánh sáng cắt đồng ly X~2~ thành hai gốc tự do.

=> X~2~ →(hν) 2 X•

**(2) Phát triển mạch** (dây chuyền): gốc X• lấy H của alkan tạo gốc alkyl R•; R• lại lấy X của X~2~, sinh ra X• mới. Một gốc X• có thể lặp lại chu trình hàng nghìn lần (với CH~4~ khoảng 10 000 lần).

=> X• + R–H → R• + HX  (chậm)

=> R• + X–X → R–X + X•

**(3) Tắt mạch**: hai gốc gặp nhau và kết hợp.

=> X• + X• → X~2~ ; X• + R• → R–X ; R• + R• → R–R

Vì có nhiều kiểu tắt mạch, sản phẩm luôn là **hỗn hợp**. Gốc R• có cấu trúc **phẳng**, nên nếu R–H quang hoạt thì sản phẩm là **hỗn hợp racemic**.

**Alkan từ 3C trở lên cho hỗn hợp đồng phân.** Ví dụ clo hóa propan (Giáo trình tr. 123):

=> CH~3~–CH~2~–CH~3~ + Cl~2~ →(hν) CH~3~CH~2~CH~2~Cl (41%) + CH~3~CHClCH~3~ (59%) + HCl

Hai sản phẩm là 1-cloropropan (41%) và 2-cloropropan (59%).

Propan có 6 H ở C bậc I và chỉ 2 H ở C bậc II. Nếu mọi H dễ thế như nhau thì sản phẩm 1-cloro phải chiếm 75%. Thực tế 2-cloro lại nhiều hơn. Vậy: **C càng bậc cao, H gắn với nó càng dễ bị thế**. Lý do: gốc tự do bậc cao bền hơn (bậc III > bậc II > bậc I > •CH~3~).

**Brom chọn lọc hơn clo.** Brom hóa propan thu gần như một sản phẩm là **2-bromopropan CH~3~–CHBr–CH~3~ (96%)**. Brom kém hoạt động hơn clo nên "kén chọn" H dễ thế nhất.

**Cycloalkan:**

Cyclopentan, cyclohexan (vòng bền) phản ứng **thế** giống alkan:

=> C~6~H~12~ + Br~2~ →(hν) C~6~H~11~Br (bromocyclohexan) + HBr

**Cyclopropan** (vòng căng) lại tham gia **cộng mở vòng**, giống một alken:

=> C~3~H~6~ (cyclopropan) + Br~2~ →(CCl~4~) Br–CH~2~–CH~2~–CH~2~–Br

Sản phẩm là 1,3-dibromopropan. Cyclopropan còn dễ cộng H~2~, HBr, HCl… Động lực của phản ứng là **giải phóng sức căng vòng**.

> [!bay]
> - "Cycloalkan" **không** phải lúc nào cũng phản ứng như alkan: **vòng 3 cạnh cộng mở vòng**, vòng 5–6 cạnh thì thế.
> - Cùng công thức C~n~H~2n~ nhưng **cycloalkan là hydrocarbon no** (không có liên kết π), khác với alken. Phân biệt: alken làm mất màu dung dịch KMnO~4~, cyclohexan thì không. (Cyclopropan làm mất màu nước brom nhưng **không** làm mất màu KMnO~4~.)

#### b) Phản ứng tách (dehydro hóa, cracking)

Đun nóng alkan mạch ngắn với xúc tác (Cr~2~O~3~, Cu, Pt…) thì alkan **tách H~2~** tạo hydrocarbon không no:

=> CH~3~–CH~3~ →(xt, t°) CH~2~=CH~2~ + H~2~

=> CH~3~–CH~2~–CH~2~–CH~3~ →(xt, t°) CH~3~–CH=CH–CH~3~ + H~2~

**Cracking** cũng là phản ứng tách, nhưng **cắt mạch carbon** thành các phân tử nhỏ hơn (ví dụ C~4~H~10~ → CH~4~ + C~3~H~6~). Cracking nhiệt dùng nhiệt đơn thuần; cracking xúc tác dùng xúc tác nên làm được ở nhiệt độ thấp hơn. Đây là cách sản xuất xăng và ethylen, propylen từ dầu mỏ.

#### c) Phản ứng oxy hóa

**Cháy hoàn toàn** khi đủ oxy, tỏa nhiều nhiệt. Vì thế alkan là nhiên liệu chính (gas, xăng, dầu):

=> CH~4~ + 2O~2~ → CO~2~ + 2H~2~O   ΔH ≈ −880 kJ/mol (giáo trình)

=> Tổng quát: C~n~H~2n+2~ + (3n+1)/2 O~2~ → n CO~2~ + (n+1) H~2~O

> [!bay] Sách in thiếu hệ số
> Giáo trình (tr. 124) in "CH~4~ + 2O~2~ → CO~2~ + H~2~O", **thiếu hệ số 2 trước H~2~O**. Khi viết bài thi, phải cân bằng: CH~4~ + 2O~2~ → CO~2~ + **2**H~2~O.

**Oxy hóa không hoàn toàn**: tùy điều kiện mà thu được các sản phẩm khác nhau (Giáo trình tr. 124–125):

| Chất | Điều kiện | Sản phẩm |
|---|---|---|
| CH~4~ + O~2~ | t°, Cu, áp suất | HCHO + H~2~O (formaldehyd) |
| CH~4~ + O~2~ | t°, Ni | CO~2~ + 2H~2~ |
| CH~4~ + O~2~ | t°, thiếu không khí | C + 2H~2~O (muội than) |
| Butan + O~2~ kk | xúc tác Mn^2+^ | Acid acetic: 2C~4~H~10~ + 5O~2~ → 4CH~3~COOH + 2H~2~O |
| Alkan cao R–CH~2~–CH~2~–R | O~2~ kk, Mn^2+^ | Cắt mạch → 2 R–COOH |
| Cyclohexan | O~2~, t°, p (hoặc O~2~, NO) | Cyclohexanol → (ZnO, t°) cyclohexanon |

### 1.4. Một số hydrocarbon no

**Methan CH~4~.** Sinh ra khi xác thực vật bị **vi khuẩn yếm khí** phân hủy dưới bùn ao, sông (vì thế còn gọi là "khí bùn ao"):

=> (C~6~H~10~O~5~)~n~ + n H~2~O → 3n CH~4~ + 3n CO~2~

Methan còn sinh ra trong ruột người và động vật, góp phần gây **chướng bụng**. Methan có nhiều trong khí thiên nhiên, dầu mỏ; là nhiên liệu và nguyên liệu tổng hợp methanol, formaldehyd… Methan và các đồng đẳng thấp trong mỏ than (khí mỏ) là nguyên nhân các vụ **nổ hầm mỏ**.

**Vaselin** (petrolatum) là **hỗn hợp alkan** (theo giáo trình từ khoảng 12 đến 25 C), dạng **chất nhão**. Dùng làm **tá dược thuốc mỡ**.

**Parafin** là hỗn hợp alkan (theo giáo trình khoảng 19 đến 35 C), chất **mềm/rắn**, không tan trong nước, tan trong nhiều dung môi hữu cơ. Dùng làm **tá dược**, làm chất **bao gói**, chống ẩm.

> [!ung-dung] Alkan trong y học
> - **Vì sao vaselin là tá dược tốt?** Alkan **trơ hóa học**: không phản ứng với dược chất, **không bị ôi khét** (khác mỡ động vật, dầu thực vật có nối đôi dễ bị oxy hóa), không kích ứng da. Vaselin **kỵ nước**, tạo lớp màng che phủ giúp da giữ ẩm, bảo vệ vết nứt nẻ. Nhược điểm: khó rửa bằng nước, dược chất khó thấm sâu, không nên bôi lên vết thương chảy dịch nhiều.
> - **Dầu parafin** (parafin lỏng) được dùng làm **thuốc nhuận tràng** kiểu làm trơn phân. Không dùng kéo dài vì làm giảm hấp thu **vitamin tan trong dầu** (A, D, E, K); không dùng cho trẻ nhỏ, người già dễ sặc vì nếu hít vào phổi gây **viêm phổi hít do lipid**.
> - **Methan không độc** nhưng gây **ngạt** khi chiếm chỗ oxy trong không gian kín (hầm biogas, giếng sâu, hầm cầu) và dễ **cháy nổ**.

> [!yhct] Vaselin trong cao xoa và thuốc mỡ
> - **Cao xoa** (dạng sáp bôi ngoài) thường gồm **hoạt chất** là menthol, camphor và các tinh dầu (bạc hà, tràm, quế, hương nhu…) phân tán trong **tá dược** là **vaselin + parafin rắn** (có thể thêm sáp ong, lanolin). Parafin rắn làm cao **cứng hơn**, không chảy ở nhiệt độ phòng; vaselin làm cao **mềm, dễ xoa**. Thay đổi tỉ lệ hai chất này để điều chỉnh độ cứng.
> - Vaselin hòa tan tốt tinh dầu (cùng là chất kém phân cực — "chất giống nhau hòa tan nhau") và giúp tinh dầu **bay hơi chậm**, giữ mùi lâu.
> - **Thuốc mỡ** dược liệu (ví dụ thuốc mỡ chữa bỏng, nứt nẻ) cũng dùng vaselin làm tá dược thay cho mỡ lợn, dầu vừng của cách làm cổ truyền, vì vaselin **không ôi**, bảo quản lâu.
> - Lưu ý thuật ngữ: chữ "**cao**" trong *cao xoa, cao dán* chỉ **dạng thuốc bôi/dán**; còn "**cao**" trong *cô cao, cao lỏng, cao đặc* là **dịch chiết dược liệu được cô đặc**. Hai khái niệm khác nhau.

## 2. Hydrocarbon không no

### 2.1. Định nghĩa, phân loại và đặc điểm cấu trúc

Hydrocarbon không no có **liên kết đôi C=C**, **liên kết ba C≡C**, hoặc cả hai trong phân tử (Giáo trình tr. 125).

| Loại | Đặc điểm | Công thức chung | Ví dụ |
|---|---|---|---|
| **Alken** (olefin) | 1 nối đôi | C~n~H~2n~ (n ≥ 2) | Ethylen CH~2~=CH~2~ |
| **Polyen** (alkadien khi có 2 nối đôi) | Nhiều nối đôi | C~n~H~2n−2~ (alkadien) | Buta-1,3-dien, isopren |
| **Alkyn** | 1 nối ba | C~n~H~2n−2~ (n ≥ 2) | Acetylen CH≡CH |
| **Alkenyn** | Cả nối đôi và nối ba | | CH~2~=CH–C≡CH (vinylacetylen) |
| Mạch vòng | Cycloalken, cycloalkyn… | | Cyclohexen |

**Alken.** Liên kết đôi = **1 liên kết σ + 1 liên kết π**. Trong ethylen, **6 nguyên tử** (2C và 4H) nằm trên **một mặt phẳng**, các góc liên kết đều **120°**, độ dài C=C là **1,34 Å**. C lai hóa sp^2^ có **độ âm điện lớn hơn** C sp^3^.

Vì liên kết π không cho hai C **quay tự do**, alken có thể có **đồng phân hình học (cis–trans)** khi **mỗi C** của nối đôi gắn với **hai nhóm khác nhau** (xem bài 1, mục 5).

**Alkadien** — ba kiểu vị trí của hai nối đôi:

- **Liền nhau** (tích lũy): anlen CH~2~=C=CH~2~.
- **Xa nhau** (cô lập): penta-1,4-dien CH~2~=CH–CH~2~–CH=CH~2~.
- **Luân phiên** (liên hợp): buta-1,3-dien CH~2~=CH–CH=CH~2~. Đây là kiểu quan trọng nhất: các electron π liên hợp với nhau, vì thế có **phản ứng cộng 1,4** đặc trưng (mục 2.3.2).

**Alkyn.** Liên kết ba = **1 σ + 2 π**. C lai hóa **sp**, phân tử thẳng (180°), C≡C chỉ dài **1,20 Å**. C sp có độ âm điện **lớn hơn** C sp^2^, nên liên kết **≡C–H phân cực mạnh** hơn =C–H. Nguyên tử H này có **tính acid yếu**, có thể bị **kim loại thay thế** (mục 2.3.4).

> [!ghi-nho] Độ âm điện của C tăng theo tỉ lệ orbital s
> sp^3^ (25% s) < sp^2^ (33% s) < **sp (50% s)**. Orbital s gần hạt nhân hơn, nên C sp giữ electron chặt hơn. Kết quả: H của alkyn đầu mạch "dễ bứt" ra hơn H của alken và alkan.

### 2.2. Tính chất vật lý

- Alken, alkyn có nối kép ở **đầu mạch** có nhiệt độ sôi **thấp hơn** alkan tương ứng.
- Nối đôi, nối ba **chuyển từ đầu mạch vào trong** thì nhiệt độ sôi và nóng chảy **tăng**.
- Đồng phân **trans** có nhiệt độ **nóng chảy cao hơn** (phân tử đối xứng, xếp chặt trong tinh thể) nhưng nhiệt độ **sôi thấp hơn** đồng phân cis (trans ít phân cực hơn).

> [!cap-nhat] Nhiệt độ sôi của alkyn đầu mạch
> Giáo trình (tr. 126) ghi chung "alken **và alkyn** có liên kết kép đầu mạch sôi thấp hơn alkan tương ứng". Số liệu thực đúng với **alken** (propen −48 °C < propan −42 °C; but-1-en −6 °C < butan −0,5 °C), nhưng **alkyn đầu mạch lại sôi cao hơn** alkan cùng số C (propyn −23 °C; but-1-yn +8 °C), vì phân tử alkyn thẳng, xếp sát và phân cực hơn. Đi thi trả lời theo câu chữ giáo trình nếu đề hỏi đúng ý đó.

### 2.3. Tính chất hóa học

Liên kết π **kém bền** hơn liên kết σ, electron π lại nằm "lộ" phía trên và dưới mặt phẳng phân tử. Vì vậy hydrocarbon không no **hoạt động hơn** hydrocarbon no và dễ bị các tác nhân **thiếu electron (electrophil)** tấn công.

#### 2.3.1. Cộng H~2~

Phản ứng tỏa nhiệt, chỉ xảy ra khi có xúc tác Ni, Pt, Pd…

=> CH~2~=CH~2~ + H~2~ →(Ni, t°) CH~3~–CH~3~

=> CH≡CH →(+H~2~, Pd) CH~2~=CH~2~ →(+H~2~, Ni) CH~3~–CH~3~

Alkyn cộng H~2~ theo hai nấc. Muốn dừng lại ở alken thì dùng xúc tác Pd đã được làm giảm hoạt tính.

#### 2.3.2. Cộng electrophil — cơ chế A~E~

Các tác nhân X–Y như **H–Cl, H–Br, H–OH, Cl~2~, Br~2~** cộng vào nối đôi theo **cơ chế cộng electrophil (A~E~)**, gồm 2 giai đoạn (Giáo trình tr. 117):

1. **Giai đoạn chậm**: phần mang điện dương X^δ+^ (ví dụ H^+^ của HBr) tấn công vào cặp electron π, tạo **carbocation** trung gian; Y^−^ tách ra. Giai đoạn này **quyết định tốc độ**.
2. **Giai đoạn nhanh**: anion Y^−^ (nucleophil) kết hợp với carbocation tạo sản phẩm.

**Quy tắc Markovnikov.** Khi alken **không đối xứng** cộng H–A (HCl, HBr, H~2~O…), phản ứng ưu tiên đi qua **carbocation bền hơn**. Hệ quả dễ nhớ: **H cộng vào C mang nhiều H hơn**, **A cộng vào C mang ít H hơn** (C bậc cao hơn).

=> CH~3~–CH=CH~2~ + H^+^ → CH~3~–C^+^H–CH~3~ (carbocation bậc II)

=> CH~3~–C^+^H–CH~3~ + Br^−^ → CH~3~–CHBr–CH~3~ (95%)

Sản phẩm chính là 2-bromopropan.

Vì sao? Carbocation bậc II (CH~3~–C^+^H–CH~3~) bền hơn bậc I (CH~3~CH~2~C^+^H~2~) do các nhóm alkyl **đẩy electron (+I)**, "san sẻ" bớt điện tích dương. Độ bền carbocation: **bậc III > bậc II > bậc I > CH~3~^+^**.

> [!vi-du] Tự lượng giá 5.2: methylpropen + HCl
> => (CH~3~)~2~C=CH~2~ + HCl → (CH~3~)~3~C–Cl
>
> Sản phẩm chính: 2-cloro-2-methylpropan.
>
> - Giai đoạn 1: H^+^ cộng vào C đầu mạch (=CH~2~), tạo carbocation **bậc III** (CH~3~)~3~C^+^, rất bền.
> - Giai đoạn 2: Cl^−^ gắn vào C^+^.
> - Nếu H^+^ cộng vào C giữa thì tạo carbocation bậc I (CH~3~)~2~CH–C^+^H~2~, kém bền. Hướng này cho sản phẩm phụ (CH~3~)~2~CH–CH~2~Cl (1-cloro-2-methylpropan).

**Yếu tố ảnh hưởng tốc độ A~E~:**

- Nhóm thế **đẩy electron** làm tăng mật độ electron ở nối đôi và làm bền carbocation → phản ứng **dễ** hơn. Nhóm **hút electron** thì ngược lại.
- Halogen: Br~2~ cộng êm dịu, dễ kiểm soát; Cl~2~ có thể cộng hoặc gây phản ứng hủy (khi có tia lửa, ánh sáng mạnh); I~2~ cộng chậm và thuận nghịch; F~2~ phản ứng quá mãnh liệt.
- Hydrohalid: khả năng phản ứng **HI > HBr > HCl ≫ HF**.

**Alkyn** cộng halogen và HX theo cơ chế tương tự alken nhưng **chậm hơn một chút** (Giáo trình tr. 126). Ví dụ: CH≡CH + Br~2~ (1:1) → CHBr=CHBr; CH≡CH + HBr (1:1) → CH~2~=CHBr.

**Alkadien liên hợp — cộng 1,2 và cộng 1,4.** Buta-1,3-dien cộng 1 phân tử Br~2~ cho **hỗn hợp hai sản phẩm**; tỉ lệ phụ thuộc tác nhân và nhiệt độ (Giáo trình tr. 127):

=> Cộng 1,2: CH~2~=CH–CH=CH~2~ + Br~2~ → CH~2~Br–CHBr–CH=CH~2~ (20%)

=> Cộng 1,4: CH~2~=CH–CH=CH~2~ + Br~2~ → CH~2~Br–CH=CH–CH~2~Br (80%)

Ở cộng 1,4, hai nguyên tử Br gắn vào **hai đầu mạch** (C1 và C4), nối đôi **dịch vào giữa** (C2=C3). Nguyên nhân: carbocation trung gian là carbocation **allyl**, điện tích dương giải tỏa trên cả C2 và C4, nên Br^−^ có thể gắn vào một trong hai vị trí.

> [!bay]
> - Markovnikov áp dụng cho tác nhân **không đối xứng** (HX, H~2~O) cộng vào alken **không đối xứng**. Cộng Br~2~, Cl~2~, H~2~ thì không cần xét quy tắc này.
> - Nhớ theo bản chất: phản ứng đi qua **carbocation bền nhất**. Câu "H vào C nhiều H hơn" chỉ là mẹo; khi có nhóm hút electron mạnh cạnh nối đôi (ví dụ –COOH ở CH~2~=CH–COOH), sản phẩm có thể ngược mẹo này.
> - Cộng HCl vào buta-1,3-dien (1:1): 1,2 → CH~3~–CHCl–CH=CH~2~; 1,4 → CH~3~–CH=CH–CH~2~Cl.

#### 2.3.3. Phản ứng trùng hợp

Nhiều phân tử nhỏ (monome) có nối đôi cộng nối tiếp nhau thành phân tử rất lớn (polyme):

=> n CH~2~=CH~2~ →(xt, p, t°) (–CH~2~–CH~2~–)~n~ (polyethylen, PE)

=> n CH~2~=CH–CH=CH~2~ →(xt, p, t°) (–CH~2~–CH=CH–CH~2~–)~n~ (cao su buna)

=> 3 CH≡CH →(than hoạt tính, t°) C~6~H~6~ (benzen)

> [!bay] Sách ghi nhầm tên polyme
> Giáo trình (tr. 127) ghi sản phẩm trùng hợp ethylen là "**PVC**". Đúng phải là **polyethylen (PE)**. PVC (polyvinyl clorid) được trùng hợp từ **vinyl clorid CH~2~=CHCl**, chính là sản phẩm ở mục 2.3.4 dưới đây.

#### 2.3.4. Phản ứng thế

Một số alken đầu dãy bị clo **thế H** ở nhiệt độ cao (500–600 °C), tạo vinyl clorid:

=> CH~2~=CH~2~ + Cl~2~ →(500–600 °C) CH~2~=CHCl + HCl

**Alkyn có nối ba đầu mạch** (–C≡C**H**) bị **kim loại thay thế H**. Với dung dịch AgNO~3~/NH~3~ tạo **kết tủa** bạc acetylua màu vàng nhạt:

=> CH≡CH + 2[Ag(NH~3~)~2~]OH → AgC≡CAg↓ + 4NH~3~ + 2H~2~O

Phản ứng này dùng để **nhận biết alkyn đầu mạch** và phân biệt với alken, với alkyn có nối ba ở giữa mạch (ví dụ but-2-yn CH~3~–C≡C–CH~3~ không có H ở C nối ba nên không phản ứng).

### 2.4. Phản ứng oxy hóa

Ngoài cháy hoàn toàn (tạo CO~2~ + H~2~O), hydrocarbon không no bị oxy hóa không hoàn toàn bởi KMnO~4~ (Giáo trình tr. 127):

**KMnO~4~ loãng, trung tính, lạnh**: nối đôi bị cắt liên kết π, mỗi C gắn thêm một –OH, tạo **diol** (glycol). Màu tím mất, có kết tủa nâu MnO~2~.

=> R–CH=CH~2~ →(KMnO~4~/H~2~O) R–CH(OH)–CH~2~OH

=> 3CH~2~=CH~2~ + 2KMnO~4~ + 4H~2~O → 3HOCH~2~–CH~2~OH + 2MnO~2~↓ + 2KOH

**KMnO~4~ trong acid, đun nóng**: **cắt đứt** cả mạch carbon ở chỗ nối đôi, tạo acid (hoặc ceton). HCOOH sinh ra còn bị oxy hóa tiếp thành CO~2~ + H~2~O.

=> R–CH=CH~2~ →(KMnO~4~/H^+^) R–COOH + HCOOH

Dựa vào các mảnh sản phẩm sau khi cắt mạch, người ta **suy ra vị trí nối đôi** trong alken ban đầu.

> [!vi-du] Nhận biết nhanh các loại hydrocarbon
> | Thuốc thử | Alkan, cyclohexan | Alken, alkadien | Alkyn đầu mạch | Benzen | Toluen |
> |---|---|---|---|---|---|
> | Nước brom | Không | **Mất màu** | **Mất màu** | Không (chỉ chiết brom lên lớp trên) | Không |
> | KMnO~4~, nhiệt độ thường | Không | **Mất màu** | **Mất màu** | Không | Không |
> | KMnO~4~, đun nóng | Không | Mất màu | Mất màu | Không | **Mất màu** (→ acid benzoic) |
> | AgNO~3~/NH~3~ | Không | Không | **Kết tủa vàng nhạt** | Không | Không |

### 2.5. Một số hydrocarbon không no

**Ethylen** CH~2~=CH~2~ và đồng đẳng (propylen…) là nguyên liệu chính của công nghiệp polyme (PE, PP, PVC…) và để tổng hợp alcol, acid…

**Acetylen** CH≡CH là khí không màu, không mùi (khi tinh khiết). Cháy trong oxy cho ngọn lửa rất nóng, dùng làm **đèn xì** hàn cắt kim loại; trước đây dùng thắp sáng. Là nguyên liệu tổng hợp nhiều hóa chất. Acetylen được điều chế từ đất đèn: CaC~2~ + 2H~2~O → C~2~H~2~↑ + Ca(OH)~2~.

> [!ung-dung] Ethylen, acetylen và trái cây chín
> - **Ethylen** là một **hormon thực vật** làm quả chín. Quả chín sinh ra ethylen nên "lây" chín sang quả bên cạnh.
> - Một số nơi dùng **đất đèn** để giấm trái cây. Đất đèn công nghiệp thường lẫn **arsen và phospho** (sinh ra AsH~3~, PH~3~ rất độc). Vì vậy việc này bị cấm ở nhiều nước và không an toàn cho người tiêu dùng.

**Isopren và buta-1,3-dien** dùng để tổng hợp **cao su**. Cao su thiên nhiên chính là **polyisopren** (dạng cis).

> [!ung-dung] Dị ứng latex
> Găng tay, ống thông bằng **cao su thiên nhiên (latex)** có thể gây **dị ứng**, từ mẩn ngứa đến **sốc phản vệ**. Nguyên nhân là các **protein** của mủ cao su còn sót lại, không phải bản thân polyisopren. Nhân viên y tế và người bệnh có tiền sử dị ứng latex nên dùng găng **nitril** hoặc vinyl.

### 2.6. Terpen

**Terpen** (theo nghĩa hẹp) là nhóm hydrocarbon, đa số **không no**, rất phổ biến trong thực vật, nhất là **tinh dầu**. Công thức chung **(C~5~H~8~)~n~ (n ≥ 2)**: phân tử được ghép từ các đơn vị **isopren** C~5~H~8~ (2-methylbuta-1,3-dien). Các dẫn xuất có chứa oxy (alcol, aldehyd, ceton…) gọi là **terpenoid**, cũng rất phổ biến (Giáo trình tr. 128).

![Hình 1. Isopren và limonen: limonen ghép từ hai đơn vị isopren](limonen.svg)

Phân loại theo số đơn vị isopren (bổ sung, thường gặp ở môn Dược liệu):

| n | Tên nhóm | Số C | Ví dụ |
|---|---|---|---|
| 2 | Monoterpen | C~10~ | Ocimen, limonen, pinen, camphen; menthol, citral, camphor (terpenoid) |
| 3 | Sesquiterpen | C~15~ | Nhiều thành phần tinh dầu nặng |
| 4 | Diterpen | C~20~ | Vitamin A (retinol) |
| 6 | Triterpen | C~30~ | Squalen; khung của nhiều saponin |
| 8 | Tetraterpen | C~40~ | **Caroten**, lycopen |

**Một số terpen quan trọng (theo giáo trình):**

- **Ocimen** (mạch hở) và các dẫn xuất **citral** (aldehyd), **citronelal** (aldehyd), **citronelol** (alcol): có trong tinh dầu **vỏ chanh, sả, màng tang**. Dùng làm thuốc xông, sát trùng đường hô hấp, nguyên liệu nước hoa.
- **Limonen** (một vòng) và các dẫn xuất như **menthol, menthon, terpinen, terpin**: theo giáo trình có trong tinh dầu **bạc hà**. Các tinh dầu này sát trùng đường hô hấp, dùng làm thuốc ho, dầu xoa.
- **Camphen** (hai vòng) có trong tinh dầu nhục đậu khấu. **Camphor** (long não) là dẫn xuất ceton, có trong tinh dầu **long não**. **α-Pinen** có trong tinh dầu **thông**, dùng để tổng hợp **terpin, camphor**…
- **Caroten** (mục dưới) và **vitamin A**.

> [!ung-dung] Terpin — thuốc long đờm
> **Terpin hydrat** (được bán tổng hợp từ α-pinen của tinh dầu thông) là thuốc **long đờm** quen thuộc, thường phối hợp với codein trong các viên "terpin–codein" trị ho. Codein là dẫn chất thuốc phiện: không dùng cho trẻ em dưới 12 tuổi, không dùng kéo dài.

> [!cap-nhat] Camphor không còn là thuốc cấp cứu
> Giáo trình ghi camphor "kích thích thần kinh trung ương, hô hấp, tuần hoàn… dùng làm thuốc cấp cứu trong các trường hợp ngạt, khó thở, suy tim". Hiện nay **camphor tiêm** (dầu long não tiêm) **đã bị loại bỏ** khỏi điều trị cấp cứu; đã có các thuốc hồi sức hiệu quả và an toàn hơn. Camphor ngày nay chủ yếu dùng **bôi ngoài** (cao xoa, dầu xoa: gây cảm giác nóng, giảm đau nhẹ). Camphor **rất độc khi uống**, nhất là ở trẻ nhỏ: chỉ khoảng **1 g** (lượng có trong một thìa nhỏ dầu long não) có thể gây **co giật**, thậm chí tử vong. Khi thi, trả lời theo giáo trình.

**Caroten** có nhiều trong rau, hoa quả, đặc biệt các quả màu đỏ cam như **gấc, đu đủ, ớt**, cà rốt. Có ba loại quan trọng **α-, β-, γ-caroten**: chung một mạch dài nhiều nối đôi **liên hợp** (vì thế có màu), chỉ khác nhau ở đầu mạch R (Giáo trình tr. 129). Vào cơ thể, caroten bị **cắt đôi ở liên kết C15=C15′** (giữa phân tử) và chuyển thành **vitamin A**. Vì vậy caroten được gọi là **provitamin A**. β-caroten có hai đầu giống nhau nên về lý thuyết cho 2 phân tử vitamin A.

**Vitamin A** (retinol) là chất kết tinh màu vàng, **không tan trong nước, tan trong dầu mỡ**. Có nhiều trong **gan cá, lòng đỏ trứng**. Vitamin A chống **bệnh khô mắt**, tham gia sự sinh sản tế bào niêm mạc và **chống nhiễm trùng**. Thức ăn giàu vitamin A hoặc caroten đặc biệt tốt cho **trẻ suy dinh dưỡng**.

> [!ung-dung] Vitamin A: thiếu và thừa đều hại
> - Thiếu vitamin A gây **quáng gà**, khô mắt, có thể loét giác mạc gây mù ở trẻ. Việt Nam có chương trình bổ sung vitamin A liều cao định kỳ cho trẻ nhỏ.
> - Vì tan trong dầu, vitamin A **tích lũy** trong gan: dùng quá liều kéo dài gây ngộ độc; liều cao ở **phụ nữ có thai** có thể gây **dị tật thai nhi**. β-caroten từ thực vật an toàn hơn vì cơ thể chỉ chuyển thành vitamin A khi cần.
> - Caroten và vitamin A tan trong dầu nên **ăn kèm chất béo** thì hấp thu tốt hơn (ví dụ xôi gấc nấu có mỡ/dầu).

> [!yhct] Terpen trong tinh dầu dược liệu: Trần bì và Gấc
> - **Trần bì** (vỏ quả quýt chín phơi khô, để lâu năm) chứa tinh dầu mà thành phần chính là **limonen** (thường chiếm đa số tinh dầu vỏ quả họ Cam chanh), cùng các flavonoid (hesperidin…). Trần bì có công năng **lý khí kiện tỳ, táo thấp hóa đàm**. Tinh dầu vỏ cam quýt có tác dụng kích thích tiêu hóa, giúp trung tiện, long đờm nhẹ; các bằng chứng hiện chủ yếu từ nghiên cứu thực nghiệm.
> - Vì sao "**trần**" (để lâu)? Limonen là terpen **dễ bay hơi** và có nối đôi **dễ bị oxy hóa**. Để lâu, lượng tinh dầu giảm bớt. YHCT cho rằng vỏ quýt để lâu **bớt tính táo, cay nóng**; sự giảm tinh dầu là một cách giải thích hóa học hợp lý nhưng chưa được chứng minh đầy đủ. Cũng vì tinh dầu dễ bay hơi, dược liệu giàu tinh dầu nói chung không nên sắc quá lâu, và Trần bì cần bảo quản trong lọ kín, nơi khô mát.
> - **Gấc** (màng hạt gấc) rất giàu **β-caroten** và **lycopen** (đều là tetraterpen C~40~). Dầu gấc được dùng bổ sung vitamin A. Do caroten có nhiều nối đôi liên hợp, dầu gấc dễ bị **oxy hóa, mất màu** khi gặp ánh sáng và không khí: cần đựng lọ tối màu, kín.

## 3. Hydrocarbon thơm

### 3.1. Định nghĩa, phân loại

**Hydrocarbon thơm** (aren) là các hydrocarbon **mạch vòng chưa no** nhưng có tính chất rất đặc trưng, **khác hẳn** hydrocarbon không no thông thường. Tính chất đó gọi là **tính thơm**: dễ thế, khó cộng, khó oxy hóa. Chữ "thơm" là tên lịch sử (nhiều chất đầu tiên tìm thấy có mùi thơm), **không** có nghĩa là chất nào cũng có mùi thơm.

Giáo trình chia ba nhóm (tr. 129–130):

- **Benzen và đồng đẳng**: benzen C~6~H~6~, toluen C~6~H~5~CH~3~ (methylbenzen), o-xylen (1,2-dimethylbenzen).
- **Nhiều vòng rời rạc**: diphenyl C~6~H~5~–C~6~H~5~, diphenylmethan C~6~H~5~–CH~2~–C~6~H~5~.
- **Nhiều vòng ngưng tụ** (hai vòng dùng chung cạnh): naphthalen (2 vòng), anthracen (3 vòng).

> [!ghi-nho] Gọi tên dẫn xuất hai lần thế của benzen
> - Hai nhóm thế ở C1 và C2 (kề nhau): **ortho (o-)**.
> - Ở C1 và C3 (cách một C): **meta (m-)**.
> - Ở C1 và C4 (đối diện): **para (p-)**.
>
> Ví dụ: o-xylen = 1,2-dimethylbenzen; p-dichlorobenzen = 1,4-dichlorobenzen.

### 3.2. Benzen

#### 3.2.1. Cấu trúc phân tử

- Vòng **6 cạnh đều và phẳng**, mọi góc liên kết **120°**.
- **Mọi** liên kết C–C **dài bằng nhau, 1,39 Å**: nằm giữa liên kết đơn (1,54 Å) và liên kết đôi (1,34 Å).
- 6 C đều **lai hóa sp^2^**. Các orbital lai hóa tạo khung liên kết σ trên cùng một mặt phẳng.
- Mỗi C còn **một orbital 2p** chưa lai hóa, trục **song song** với nhau và **vuông góc** với mặt phẳng vòng. Sáu orbital p này **xen phủ bên với cả hai bên cạnh**, tạo một orbital phân tử π **bao trùm toàn vòng** (một "đám mây" π phía trên và phía dưới mặt phẳng vòng).

![Hình 2. Cấu trúc benzen: hai công thức Kekulé và cách biểu diễn thực tế](benzen.svg)

**Vì sao không vẽ benzen bằng 3 nối đôi cố định?** Công thức Kekulé (3 nối đôi xen kẽ 3 nối đơn) dự đoán có hai loại độ dài liên kết, nhưng thực nghiệm thấy cả 6 liên kết bằng nhau. Benzen thật là **"trung gian"** của hai công thức Kekulé (gọi là **lai hóa cộng hưởng**), không phải dao động qua lại giữa chúng. Vì thế thường vẽ **lục giác có vòng tròn bên trong**.

> [!vi-du] Đo được độ "bền thơm"
> - Hydro hóa cyclohexen (1 nối đôi) tỏa khoảng **120 kJ/mol**. Nếu benzen có 3 nối đôi bình thường, hydro hóa sẽ tỏa khoảng 3 × 120 = 360 kJ/mol.
> - Thực đo benzen chỉ tỏa khoảng **208 kJ/mol**. Phần chênh khoảng **150 kJ/mol** là năng lượng mà benzen được "ổn định thêm" nhờ electron π giải tỏa (**năng lượng cộng hưởng**).
> - Đây chính là lý do benzen **"tiếc"** không muốn mất vòng thơm: phản ứng **cộng** phá vỡ hệ π nên khó; phản ứng **thế** giữ nguyên vòng thơm nên dễ.
> - Mở rộng: hệ vòng phẳng, liên hợp kín, có **4n + 2** electron π (n = 0, 1, 2…) thì có tính thơm (quy tắc Hückel). Benzen có 6 e π (n = 1).

#### 3.2.2. Tính chất vật lý

Benzen và đồng đẳng là chất **lỏng hoặc rắn**, **không tan trong nước**, nhẹ hơn nước, tan trong các hydrocarbon khác và nhiều dung môi hữu cơ; bản thân benzen là dung môi tốt cho chất béo, nhựa, iod…

#### 3.2.3. Tính chất hóa học

Phản ứng **đặc trưng** của benzen là **thế electrophil (S~E~)**. Phản ứng **cộng** và **oxy hóa** rất khó, chỉ xảy ra ở điều kiện khắc nghiệt.

**a) Thế electrophil ở nhân thơm — cơ chế S~E~**

=> Ar–H + Z–E →(xt) Ar–E + HZ

Ar là gốc thơm; Z–E có thể là HO–NO~2~, Br–Br (có xúc tác)… Ví dụ:

=> C~6~H~6~ + HO–NO~2~ →(H~2~SO~4~ đặc, t°) C~6~H~5~NO~2~ (nitrobenzen) + H~2~O

=> C~6~H~6~ + Br~2~ →(Fe, t°) C~6~H~5~Br (bromobenzen) + HBr

Cơ chế S~E~ (Giáo trình tr. 114–115), lấy ví dụ brom hóa:

1. **Tạo tác nhân electrophil**: Fe tác dụng với Br~2~ tạo FeBr~3~; FeBr~3~ (acid Lewis) kéo Br~2~ phân cực mạnh, tạo Br^+^: 2Fe + 3Br~2~ → 2FeBr~3~; FeBr~3~ + Br~2~ → [FeBr~4~]^−^ + Br^+^. Với nitro hóa, H~2~SO~4~ đặc giúp tạo ion **nitroni NO~2~^+^**: HNO~3~ + 2H~2~SO~4~ ⇌ NO~2~^+^ + H~3~O^+^ + 2HSO~4~^−^.
2. E^+^ tiến đến đám mây π, tạo **phức π**, rồi chuyển thành **phức σ** (carbocation vòng): E gắn vào một C, C này chuyển thành sp^3^, vòng **tạm mất tính thơm**. Điện tích dương phân bố chủ yếu ở các vị trí **2, 4, 6** so với C vừa gắn E. Đây là giai đoạn **chậm**.
3. Phức σ **tách H^+^** (nhanh); vòng **phục hồi tính thơm**. H^+^ kết hợp với [FeBr~4~]^−^ thành HBr và tái tạo FeBr~3~.

> [!bay]
> - Benzen **không** làm mất màu **nước brom**. Muốn brom hóa phải dùng **Br~2~ khan + bột Fe (hoặc FeBr~3~)**, đun nóng, và đó là phản ứng **thế**, không phải cộng.
> - Phản ứng S~E~ là **lưỡng phân tử, nhiều giai đoạn**; sản phẩm trung gian là **phức σ** (một carbocation).

**b) Quy tắc thế vào vòng benzen (sự định hướng)**

Khi vòng benzen **đã có sẵn một nhóm thế**, nhóm này quyết định nhóm thứ hai vào vị trí nào và phản ứng nhanh hay chậm (Giáo trình tr. 115–116, 131).

![Hình 3. Quy tắc định hướng: nhóm thế loại I (o, p) và loại II (m)](dinh-huong.svg)

| | **Nhóm thế loại I** | **Nhóm thế loại II** |
|---|---|---|
| Ví dụ | Alkyl (–CH~3~, –C~2~H~5~), –OH, –NH~2~, halogen (–Cl, –Br) | –NO~2~, –CHO, –COOH (và –SO~3~H, –CN) |
| Định hướng | **ortho và para** | **meta** |
| Tốc độ so với benzen | **Nhanh hơn** (hoạt hóa vòng), **trừ halogen** | **Chậm hơn** (phản hoạt hóa vòng) |
| Hiệu ứng | +I hoặc +C: **đẩy electron** vào vòng | −I, −C: **hút electron** khỏi vòng |

Số liệu nitro hóa trong giáo trình (tr. 116), lấy benzen k = 1:

| Chất | k (so với benzen) | % ortho | % meta | % para |
|---|---|---|---|---|
| Phenol C~6~H~5~OH | 1000 | 40 | ~0 | 60 |
| Toluen C~6~H~5~CH~3~ | 25 | 56 | 3 | 41 |
| Benzen | 1 | — | — | — |
| Clorobenzen C~6~H~5~Cl | 3·10^−3^ | 30 | 1 | 69 |
| Nitrobenzen C~6~H~5~NO~2~ | 6·10^−8^ | 6 | **93** | 1 |

Đọc bảng: ba chất đầu có nhóm loại I cho o + p ≈ 97–100%; nitrobenzen (loại II) cho meta 93%. Clorobenzen chậm hơn benzen nhưng vẫn cho o + p (99%). Thứ tự tốc độ: **phenol > toluen > benzen > clorobenzen > nitrobenzen**. (Nhiều tài liệu hiện nay ghi k của clorobenzen khoảng 3·10^−2^; thứ tự không đổi. Đi thi dùng số của giáo trình.)

**Vì sao?**

- Nhóm loại I đẩy electron làm mật độ electron trong vòng **tăng**, tăng **nhiều nhất ở o và p**. E^+^ dễ tấn công các vị trí này.
- Nhóm loại II hút electron làm vòng **nghèo electron**, nghèo **nhất ở o và p**. Vị trí **meta** "ít bị thiệt" nhất nên E^+^ vào meta, nhưng phản ứng vẫn chậm hơn benzen nhiều.
- **Halogen** là trường hợp đặc biệt: hiệu ứng hút −I **mạnh hơn** hiệu ứng đẩy +C nên làm vòng **phản ứng chậm hơn** benzen. Nhưng nhờ +C, phức σ ở vị trí o, p **bền hơn** ở meta, nên halogen vẫn định hướng **o, p** và vẫn được xếp vào **loại I**.

> [!bay] Cùng là toluen + Cl~2~, điều kiện khác thì sản phẩm khác
> - **Có bột Fe (xúc tác), không chiếu sáng** → thế **vào vòng** (S~E~), cho **o-clorotoluen và p-clorotoluen**.
> - **Chiếu sáng, đun nóng, không Fe** → thế H ở **nhánh CH~3~** (S~R~, giống alkan), cho **benzyl clorid** C~6~H~5~CH~2~Cl.
>
> Mẹo: "**Nhân – sắt, Nhánh – nắng**".

> [!vi-du] Thứ tự đưa nhóm thế quyết định sản phẩm (Tự lượng giá 5.10)
> Điều chế các nitroclorobenzen từ benzen:
> - **o- và p-nitroclorobenzen**: **clo hóa trước** (C~6~H~6~ → C~6~H~5~Cl), rồi nitro hóa. –Cl (loại I) đưa –NO~2~ vào o, p.
> - **m-nitroclorobenzen**: **nitro hóa trước** (C~6~H~6~ → C~6~H~5~NO~2~), rồi clo hóa (Cl~2~/Fe). –NO~2~ (loại II) đưa –Cl vào meta.

**c) Phản ứng cộng** — chỉ xảy ra ở điều kiện khắc nghiệt:

=> C~6~H~6~ + 3H~2~ →(Ni, t°) C~6~H~12~ (cyclohexan)

=> C~6~H~6~ + 3Cl~2~ →(ánh sáng) C~6~H~6~Cl~6~ (hexacloran, "**666**")

Cộng clo theo **cơ chế gốc tự do**, tạo **666**, chất **độc** từng dùng làm **thuốc trừ sâu**.

> [!cap-nhat] Thuốc trừ sâu 666 đã bị cấm
> Giáo trình ghi 666 "được dùng làm thuốc trừ sâu". Hiện nay 666 (hexaclorocyclohexan, HCH) và đồng phân có hoạt tính của nó là **lindan** thuộc nhóm **chất ô nhiễm hữu cơ khó phân hủy** của **Công ước Stockholm**. Chúng tích lũy lâu trong môi trường, mô mỡ, sữa mẹ và độc thần kinh. Việt Nam và hầu hết các nước **đã cấm** sử dụng. Khi thi, trả lời theo giáo trình.

**d) Phản ứng oxy hóa**

- Benzen **không** làm mất màu dung dịch KMnO~4~ ở nhiệt độ thường.
- Ở nhiệt độ cao, có xúc tác V~2~O~5~, benzen bị oxy hóa thành **anhydrid maleic** C~4~H~2~O~3~:

=> C~6~H~6~ + 9/2 O~2~ →(V~2~O~5~, t°) C~4~H~2~O~3~ + 2CO~2~ + 2H~2~O

- **Đồng đẳng của benzen dễ bị oxy hóa hơn**: KMnO~4~ đun nóng oxy hóa **nhánh alkyl** (vòng giữ nguyên), luôn tạo **acid benzoic**:

=> C~6~H~5~CH~3~ →(KMnO~4~, t°) C~6~H~5~COOH

Lý do: C của nhánh gắn trực tiếp với vòng (vị trí "benzyl") có H rất linh động. Nhánh dài bao nhiêu cũng bị cắt về –COOH gắn vòng.

### 3.3. Một số hydrocarbon thơm

**Benzen** là chất lỏng không màu, dùng làm **dung môi** và nguyên liệu tổng hợp hữu cơ: từ benzen tổng hợp **phenol** (rồi nhựa bakelit), tổng hợp **anilin** (rồi phẩm nhuộm, một số **sulfamid** chữa bệnh). Benzen và đồng đẳng gây **bệnh nghề nghiệp** cho người tiếp xúc: nồng độ cao trong không khí gây chóng mặt, nhức đầu, có thể tử vong; nồng độ thấp kéo dài gây **nhiễm độc mạn tính** (Giáo trình tr. 131).

**Naphthalen** dễ **thăng hoa**, có mùi đặc biệt, dùng làm **băng phiến** đuổi gián, nhậy. Một số hydrocarbon thơm nhiều vòng khác như **crizen, piren…** có khả năng **gây ung thư**.

> [!ung-dung] Độc tính của hydrocarbon thơm
> - **Benzen gây bệnh bạch cầu.** Benzen được **Cơ quan Nghiên cứu Ung thư Quốc tế (IARC) xếp nhóm 1**: chắc chắn gây ung thư ở người. Benzen bị gan chuyển hóa thành các chất (benzen oxid, hydroquinon, benzoquinon…) **độc với tủy xương**, gây **giảm ba dòng tế bào máu, suy tủy** và **bệnh bạch cầu cấp dòng tủy**. Nguồn tiếp xúc: xăng, khói thuốc lá, dung môi sơn keo. Vì thế phòng thí nghiệm hiện nay **hạn chế tối đa benzen**, thay bằng toluen (ít độc với tủy hơn nhưng vẫn độc thần kinh, gây nghiện khi hít keo).
> - **Benzo[a]pyren** (hydrocarbon thơm đa vòng, **PAH**, 5 vòng ngưng tụ) có trong **khói thuốc lá**, khói bếp, **thịt cá nướng cháy, hun khói**. Bản thân nó chưa độc; vào cơ thể bị enzym chuyển thành **epoxid** gắn vào DNA (ADN) (base G), gây đột biến (xem Sinh học, bài Đột biến). IARC xếp nhóm 1. Hạn chế ăn đồ nướng cháy đen, không hút thuốc.
> - **Băng phiến naphthalen** gây **tan máu** ở người **thiếu men G6PD**, đặc biệt ở **trẻ sơ sinh** mặc quần áo cất trong tủ có băng phiến. Không để trẻ ngậm, nuốt viên băng phiến.

> [!bay] Phân biệt dễ nhầm
> - Toluen + KMnO~4~ đun nóng → **acid benzoic** (oxy hóa nhánh). Benzen thì không phản ứng.
> - Benzen + Cl~2~/**Fe** → **thế** (clorobenzen C~6~H~5~Cl). Benzen + Cl~2~/**ánh sáng** → **cộng** (C~6~H~6~Cl~6~, 666). Ngược với toluen, ở benzen ánh sáng dẫn đến **cộng** vì vòng không có nhánh để thế.

## 4. Tóm tắt

| Nội dung | Điểm cần nhớ |
|---|---|
| Alkan C~n~H~2n+2~ | sp^3^, 109°28′, trơ; **S~R~** (khơi mào – phát triển mạch – tắt mạch); H ở C bậc cao dễ thế; Br~2~ chọn lọc hơn Cl~2~ |
| Cycloalkan C~n~H~2n~ | Sức căng Bayer: vòng 3–4 cạnh kém bền, **cyclopropan cộng mở vòng**; vòng 5–6 cạnh bền, phản ứng thế |
| Alkan dùng trong y học | Vaselin (C~12~–C~25~, tá dược thuốc mỡ), parafin (C~19~–C~35~, tá dược, bao gói); trơ, không ôi |
| Alken C~n~H~2n~ | 1σ + 1π, phẳng, 120°, C=C 1,34 Å; cis–trans; **A~E~ qua carbocation**, **Markovnikov** |
| Alkadien liên hợp | Cộng **1,2 và 1,4**; trùng hợp → cao su |
| Alkyn C~n~H~2n−2~ | 1σ + 2π, thẳng, C≡C 1,20 Å; A~E~ chậm hơn alken; ≡C–H **thế bằng Ag** (kết tủa) |
| Oxy hóa bằng KMnO~4~ | Loãng, lạnh → **diol**; acid, nóng → **cắt mạch** (xác định vị trí nối đôi) |
| Terpen (C~5~H~8~)~n~ | Ghép từ isopren; ocimen, citral (sả, chanh), limonen, menthol (bạc hà), camphor (long não), α-pinen (thông); caroten = **provitamin A** (cắt ở C15=C15′) |
| Benzen | Phẳng, 120°, mọi C–C 1,39 Å, 6 e π giải tỏa; **dễ thế (S~E~), khó cộng, khó oxy hóa** |
| Quy tắc thế | **Loại I** (alkyl, OH, NH~2~, halogen) → **o, p**, hoạt hóa (trừ halogen); **loại II** (NO~2~, CHO, COOH) → **m**, phản hoạt hóa |
| Độc chất | Benzen → suy tủy, **bệnh bạch cầu**; **benzo[a]pyren** (PAH) gây ung thư; naphthalen → tan máu khi thiếu G6PD |

> [!vi-du] Gợi ý trả lời Tự lượng giá (Giáo trình tr. 132, đáp án tr. 252–253)
> - **5.1** n-Butan + Cl~2~ (1:1, ánh sáng), cơ chế S~R~: sản phẩm CH~3~CH~2~CHClCH~3~ (2-clorobutan, chính) + CH~3~CH~2~CH~2~CH~2~Cl (1-clorobutan); khí A là **HCl**.
> - **5.3** Buta-1,3-dien + Cl~2~ → CH~2~Cl–CHCl–CH=CH~2~ (1,2) + CH~2~Cl–CH=CH–CH~2~Cl (1,4). 2-Methylbut-2-en + Cl~2~ → CH~3~–CHCl–CCl(CH~3~)–CH~3~; + HCl → CH~3~–CH~2~–CCl(CH~3~)~2~ (Markovnikov).
> - **5.4** KMnO~4~ loãng, lạnh: ethylen → ethylen glycol HOCH~2~–CH~2~OH; penta-1,3-dien → diol ở một trong hai nối đôi: CH~3~–CH=CH–CHOH–CH~2~OH hoặc CH~3~–CHOH–CHOH–CH=CH~2~.
> - **5.6** Cyclopropan + Br~2~ → BrCH~2~CH~2~CH~2~Br (cộng mở vòng); cyclohexan + Br~2~ (ánh sáng) → bromocyclohexan + HBr (thế).
> - **5.7** Chỉ **C~2~H~2~** tạo kết tủa với AgNO~3~/NH~3~; cả ba chất (C~2~H~4~, buta-1,3-dien, C~2~H~2~) đều cộng nước brom và HBr.
> - **5.8** Khả năng nitro hóa tăng dần: **nitrobenzen < clorobenzen < benzen < ethylbenzen < phenol**. Sản phẩm: clorobenzen, ethylbenzen, phenol → o + p; nitrobenzen → m-dinitrobenzen; benzen → nitrobenzen.
> - **5.9** Toluen → o-, p-clorotoluen (Fe) hoặc benzyl clorid (ánh sáng). Xylen (Cl~2~/Fe): Cl vào vị trí được cả hai –CH~3~ hoạt hóa (o-xylen → chủ yếu 4-cloro-1,2-dimethylbenzen; m-xylen → 1-cloro-2,4-dimethylbenzen; p-xylen → 2-cloro-1,4-dimethylbenzen); chiếu sáng thì thế ở nhánh → CH~3~C~6~H~4~CH~2~Cl. Nitrobenzen → **m**-cloronitrobenzen; o-nitrotoluen → Cl vào vị trí 4 hoặc 6 (cả –CH~3~ và –NO~2~ cùng "chỉ" về đây).
> - **5.10** Xem khung "Thứ tự đưa nhóm thế" ở mục 3.2.3.
