---
title: Acid carboxylic, ester và hợp chất tạp chức có nhóm carboxylic
thoi-gian: 50 phút
muc-tieu:
- Gọi được tên các acid carboxylic đơn giản theo danh pháp IUPAC và tên thông thường.
- Giải thích được vì sao acid carboxylic có tính acid và cấu trúc gốc R làm tính acid mạnh lên hay yếu đi như thế nào.
- Viết được các phản ứng chính của acid carboxylic và ester (tạo muối, ester hóa, thủy phân, xà phòng hóa, khử…); so sánh và giải thích khả năng phản ứng của chúng.
- Nêu được tính chất hóa học chính của hydroxy acid (alcol acid, phenol acid) và oxo acid.
- Nêu được một số cách điều chế acid carboxylic và ý nghĩa y học của acid, ester, hợp chất tạp chức (aspirin, acid lactic, citric, oxalic, chất béo, thể ceton…).
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Acid carboxylic R–COOH là **acid yếu** (K~a~ ≈ 10^−4^–10^−5^) nhưng vẫn mạnh hơn phenol và H~2~CO~3~. Nhóm **hút electron** gần –COOH làm acid **mạnh hơn**; gốc alkyl **đẩy electron** làm acid **yếu đi**.
> 2. **Ester hóa** (acid + alcol, H~2~SO~4~ đặc, t°) là phản ứng **thuận nghịch**; acid mất **–OH**, alcol mất **H** (chứng minh bằng ^18^O).
> 3. Ester bị **thủy phân**: trong acid thì thuận nghịch; trong **kiềm** thì một chiều — gọi là **xà phòng hóa**. Chất béo (glycerid) là ester của glycerol với acid béo cao.
> 4. **Hydroxy acid** có cả –OH và –COOH: **alcol acid** (lactic, malic, citric, tartric) và **phenol acid** (salicylic). –OH phenol chỉ ester hóa được bằng **anhydrid acid** → aspirin. Với Fe^3+^: alcol acid cho màu **vàng**, phenol acid cho màu **tím**.
> 5. **Oxo acid** có –COOH và C=O (aldehyd acid, ceto acid): acid pyruvic, acid acetoacetic. Chúng mạnh hơn acid thường và có phản ứng cộng của nhóm carbonyl. Acid acetoacetic là một **thể ceton**.

## 1. Acid carboxylic

### 1.1. Định nghĩa và phân loại

Acid carboxylic là hợp chất hữu cơ có nhóm **carboxyl –COOH** gắn với một gốc hydrocarbon hoặc với nguyên tử H (Giáo trình tr. 190). Công thức chung: **R–COOH**.

Nhóm –COOH thực chất là nhóm **carbonyl** C=O và nhóm **hydroxyl** –OH gắn trên cùng một carbon. Hai nhóm này ảnh hưởng lẫn nhau, nên –COOH có tính chất riêng, không giống aldehyd/ceton cũng không giống alcol.

| Tiêu chí | Loại | Ví dụ |
|---|---|---|
| Gốc R | No (C~n~H~2n+1~–, n ≥ 0) | HCOOH, CH~3~COOH |
| | Không no | CH~2~=CH–COOH (acid acrylic) |
| | Thơm | C~6~H~5~COOH (acid benzoic), C~6~H~5~CH~2~COOH (acid phenylacetic) |
| Số nhóm –COOH | Monocarboxylic | CH~3~COOH |
| | Polycarboxylic (di-, tri-…) | HOOC–COOH (acid oxalic), acid o-phtalic C~6~H~4~(COOH)~2~ |

> [!bay]
> Acid phenylacetic C~6~H~5~–CH~2~–COOH **có vòng thơm** nhưng –COOH gắn vào C no (CH~2~). Về tính chất của nhóm –COOH, nó gần với acid béo hơn là acid benzoic. Acid benzoic thì –COOH gắn **trực tiếp** vào vòng.

### 1.2. Danh pháp

#### a) Danh pháp IUPAC

**acid + tên hydrocarbon tương ứng (tính cả C của –COOH) + đuôi "-oic"** (Giáo trình tr. 191).

- C của nhóm –COOH luôn được đánh **số 1**.
- Hai nhóm –COOH ở hai đầu mạch: đuôi **"-dioic"**: HOOC–COOH là **acid ethandioic**.
- –COOH gắn vào **vòng**: **acid + tên vòng + "carboxylic"** (C của –COOH **không** tính vào tên vòng). Ví dụ C~6~H~11~–COOH: **acid cyclohexancarboxylic**.

Ví dụ:

- CH~3~–CH(CH~3~)–CH~2~–COOH: **acid 3-methylbutanoic**.
- CH~2~=CH–CH~2~–COOH: **acid but-3-enoic**.

> [!bay] Đánh số khi có –COOH
> Vì C của –COOH là C1, nên **không bao giờ có "acid 1-cloro…oic"**. Bài tập 9.2a của sách ("acid 1-clorobutanoic") là một tên sai; đáp án cuối sách vẽ Cl–CH~2~–CH~2~–CH~2~–COOH, tức **acid 4-clorobutanoic**.

#### b) Danh pháp thông thường

Tên thông thường lấy từ **nguồn gốc** của acid, thường theo tiếng Latinh (Bảng 15, Giáo trình tr. 192):

| Công thức | Tên IUPAC | Tên thường | Gốc tên |
|---|---|---|---|
| HCOOH | a. methanoic | a. **formic** | *formica*: con kiến |
| CH~3~COOH | a. ethanoic | a. **acetic** | *acetum*: giấm |
| CH~3~CH~2~COOH | a. propanoic | a. **propionic** | |
| CH~3~(CH~2~)~2~COOH | a. butanoic | a. **butyric** | *butyrum*: bơ |
| CH~3~(CH~2~)~3~COOH | a. pentanoic | a. **valeric** | cây nữ lang (*Valeriana*) |
| CH~3~(CH~2~)~4~COOH | a. hexanoic | a. caproic | *caper*: con dê |
| HOOC–COOH | a. ethandioic | a. **oxalic** | cây chua me (*Oxalis*) |
| HOOC–CH~2~–COOH | a. propandioic | a. **malonic** | *malum*: quả táo |
| HOOC–(CH~2~)~2~–COOH | a. butandioic | a. **succinic** | *succinum*: hổ phách |
| HOOC–(CH~2~)~3~–COOH | a. pentandioic | a. glutaric | |
| HOOC–(CH~2~)~4~–COOH | a. hexandioic | a. **adipic** | *adeps*: mỡ |

Trong tên thông thường, vị trí nhóm thế được chỉ bằng chữ Hy Lạp **α, β, γ, δ…**, **bắt đầu từ C sát nhóm –COOH**. Ví dụ CH~3~–CH(CH~3~)–CH~2~–COOH là acid **β-methylbutyric** (= acid 3-methylbutanoic).

> [!bay] α ≠ 1
> C**α** trong tên thường là C**2** trong tên IUPAC (C1 là C của –COOH). Vậy α-cloropropionic = 2-cloropropanoic; β-hydroxybutyric = 3-hydroxybutanoic.

### 1.3. Đồng phân

- **Đồng phân mạch carbon** (từ 4C): CH~3~CH~2~CH~2~COOH (acid n-butyric) và (CH~3~)~2~CH–COOH (acid isobutyric).
- **Đồng phân nhóm chức**: acid và ester cùng công thức phân tử. Ví dụ C~4~H~8~O~2~: CH~3~CH~2~CH~2~COOH (acid butyric) và CH~3~CH~2~COOCH~3~ (methyl propionat).
- **Đồng phân hình học (cis–trans)**: HOOC–CH=CH–COOH có dạng *cis* (acid maleic) và *trans* (acid fumaric).
- **Đồng phân quang học**: phân tử có C\*. Ví dụ acid lactic CH~3~–C\*H(OH)–COOH có D-(−)-lactic và L-(+)-lactic. (Xem lại bài *Cấu trúc phân tử hợp chất hữu cơ — đồng phân*.)

### 1.4. Tính chất vật lý

- **Acid thấp (1–4C)**: lỏng linh động, **tan vô hạn** trong nước. **Acid trung bình (5–9C)**: lỏng sánh như dầu, ít tan. **Acid cao (≥ 10C)**: rắn, không mùi, không tan trong nước, tan trong ethanol, ether.
- **Acid dicarboxylic**: tinh thể, dễ tan trong nước. **Acid thơm**: rắn kết tinh, dễ thăng hoa, chỉ tan trong nước nóng.

**Vì sao nhiệt độ sôi cao?** Hai phân tử acid liên kết với nhau bằng **hai liên kết hydro** thành một **dimer vòng** (R–C(=O)–O–H ··· O=C(–OH)–R). Muốn sôi phải phá các liên kết này. Vì vậy acid sôi cao hơn alcol có khối lượng phân tử tương đương. Ví dụ acid acetic (M = 60) sôi ở **118,5 °C**, còn propan-1-ol (M = 60) sôi ở 97 °C. Nhóm –COOH cũng tạo liên kết hydro với nước, nên các acid thấp tan rất tốt.

**Quy luật "chẵn – lẻ" của nhiệt độ nóng chảy** (Giáo trình tr. 193–194):

- Acid monocarboxylic có **số C lẻ** nóng chảy **thấp hơn** acid đứng trước nó (kém 1C). Ví dụ acid capric C10 (31,5 °C) > acid undecanoic C11 (30,5 °C).
- Acid dicarboxylic có **số C chẵn** nóng chảy **cao hơn** hai acid lẻ đứng cạnh. Ví dụ succinic C4 (182,8 °C) > malonic C3 (130,3 °C) và glutaric C5 (97,5 °C).

Lý do: mạch có số C chẵn xếp khít vào mạng tinh thể hơn.

### 1.5. Tính chất hóa học

#### 1.5.1. Tính acid

So với acid vô cơ mạnh, acid carboxylic là **acid yếu**: K~a~ chỉ khoảng 10^−4^–10^−5^. Tuy vậy chúng vẫn làm **quỳ tím hóa đỏ**.

**Vì sao –COOH cho được H^+^?** O của C=O có độ âm điện lớn, kéo electron về phía nó. C của nhóm carbonyl mang một phần điện tích dương, nên lại kéo electron của O trong nhóm –OH. Kết quả là liên kết **O–H phân cực mạnh hơn** liên kết O–H của alcol, H dễ tách ra dạng proton. Thêm vào đó, anion **carboxylat R–COO^−^ rất bền** vì điện tích âm được **trải đều trên hai nguyên tử O** (liên hợp). Phenoxid chỉ trải điện tích lên vòng, còn alkoxid thì không trải được — nên thứ tự tính acid là: **alcol < phenol < acid carboxylic**.

**Ảnh hưởng của gốc R** (đã học ở bài *Hiệu ứng cấu trúc*, mục 2.3 và 4.2):

- R **đẩy electron** (+I, gốc alkyl), R càng lớn thì liên kết O–H càng kém phân cực → acid **yếu đi**: **HCOOH > CH~3~COOH > C~2~H~5~COOH**.
- R hay nhóm **hút electron** (–C~6~H~5~, –Cl, –NO~2~, –OH, –COOH, C=O…) → acid **mạnh lên**: ClCH~2~COOH > CH~3~COOH; C~6~H~5~COOH > CH~3~COOH.

![Hình 1. Thang pKa của các acid trong bài: nhóm hút electron gần –COOH làm acid mạnh lên](thang-pka.svg)

Bảng 18 của giáo trình (tr. 195) — một số giá trị nên nhớ:

| Acid | Công thức | pK~a~ | Ghi chú |
|---|---|---|---|
| Oxalic | HOOC–COOH | **1,27** (pK~a2~ 4,27) | Mạnh nhất bảng: –COOH thứ hai hút electron, ở ngay cạnh |
| Malonic | HOOC–CH~2~–COOH | 2,83 (5,70) | –COOH thứ hai cách một CH~2~ → yếu hơn oxalic |
| Salicylic | o-HO–C~6~H~4~–COOH | 3,00 | Mạnh hơn benzoic |
| Fumaric | HOOC–CH=CH–COOH (trans) | 3,05 | Acid không no: C=C và –COOH thứ hai hút electron |
| Citric | (xem mục 3.2) | 3,10 · 4,70 · 6,39 | Ba nấc phân li |
| Malic | HOOC–CH(OH)–CH~2~–COOH | ≈ 3,4 (sách in 4,39 — xem bẫy) | Alcol acid hai chức |
| Formic | HCOOH | 3,74 | Mạnh nhất dãy no đơn chức |
| Lactic | CH~3~CHOHCOOH | 3,86 | –OH ở Cα (−I) → mạnh hơn propionic |
| Benzoic | C~6~H~5~COOH | 4,19 | |
| Succinic | HOOC(CH~2~)~2~COOH | 4,20 (5,63) | Hai –COOH xa nhau → ảnh hưởng nhỏ |
| Acetic | CH~3~COOH | **4,76** | Mốc so sánh (K~a~ = 1,8·10^−5^) |
| Propionic | CH~3~CH~2~COOH | 4,85 | |
| Phenol | C~6~H~5~OH | 10,00 | Để so sánh |

> [!bay]
> - **pK~a~ càng nhỏ, acid càng mạnh** (pK~a~ = −lg K~a~). Chênh 1 đơn vị pK~a~ = chênh **10 lần** K~a~.
> - Acid **dicarboxylic** có **hai nấc** phân li. Nấc 1 mạnh hơn acid đơn chức tương ứng (vì –COOH còn lại hút electron); nấc 2 yếu hơn nhiều (vì phải tách H^+^ khỏi một ion đã mang điện âm).
> - Bảng 18 ghi acid malic K~a1~ = 4,0·10^−4^ nhưng pK~a1~ = 4,39 — **không khớp**: −lg(4,0·10^−4^) = **3,40** (đúng với số liệu hiện hành). Tương tự, nấc 2 của acid fumaric ghi K~a2~ 3,0·10^−5^ thì pK~a2~ phải là 4,52, không phải 5,52 (số liệu hiện hành ≈ 4,4). Khi đề cho K~a~, hãy tự tính pK~a~.
> - Ảnh hưởng của nhóm hút electron **giảm nhanh theo khoảng cách** (hiệu ứng −I tắt sau khoảng 3 C): oxalic (1,27) ≫ malonic (2,83) > succinic (4,20).

#### 1.5.2. Phản ứng tạo muối

Acid carboxylic tác dụng với **kim loại kiềm, base, oxide base, muối carbonat** tạo muối:

=> R–COOH + NaOH → R–COONa + H~2~O

=> 2CH~3~COOH + Na~2~CO~3~ → 2CH~3~COONa + H~2~O + CO~2~↑

Acid dicarboxylic tạo **hai loại muối**, tùy lượng kiềm: HOOC–COOH + NaOH → HOOC–COONa (muối acid); thêm NaOH nữa → NaOOC–COONa.

> [!ung-dung] Phân biệt acid carboxylic với phenol bằng NaHCO~3~
> Acid carboxylic mạnh hơn H~2~CO~3~ (pK~a~ 6,35) nên **đẩy được CO~2~** ra khỏi muối hydrocarbonat: sủi bọt. Phenol (pK~a~ 10) yếu hơn H~2~CO~3~ nên **không** sủi bọt. Đây là phép thử nhanh để phân biệt hai nhóm chất.
> Trong dược phẩm, nhiều thuốc là acid carboxylic được bào chế ở dạng **muối natri, kali** cho dễ tan: natri benzoat, natri salicylat, kali citrat…

#### 1.5.3. Phản ứng tạo ester (ester hóa)

Đun acid với alcol, có **H~2~SO~4~ đặc** làm xúc tác, thu được **ester** và nước:

=> R–COOH + H–OR′ ⇌ R–COOR′ + H~2~O  (H~2~SO~4~ đặc, t°)

=> CH~3~COOH + C~2~H~5~OH ⇌ CH~3~COOC~2~H~5~ + H~2~O

**Ai mất –OH?** Thí nghiệm đánh dấu đồng vị: ester hóa acid benzoic bằng ethanol chứa ^18^O (C~2~H~5~–^18^OH). Ethyl benzoat thu được **chứa ^18^O**; nước sinh ra không có ^18^O. Vậy liên kết **C–OH của acid** bị cắt: acid góp –OH, alcol góp H (Giáo trình tr. 196).

![Hình 2. Ester hóa: thí nghiệm ¹⁸O, cơ chế có xúc tác H⁺ và hai kiểu thủy phân ester](ester-hoa.svg)

**Cơ chế** (xúc tác H^+^), viết gọn:

1. H^+^ gắn vào O của nhóm C=O → C mang điện dương, dễ bị tấn công hơn.
2. Phân tử alcol R′–OH (có cặp electron tự do trên O, là nucleophil) **cộng vào C** đó → trung gian có C mang 2 nhóm –OH và 1 nhóm –O^+^HR′.
3. H^+^ chuyển sang một nhóm –OH, biến nó thành –OH~2~^+^, rồi **tách ra dạng H~2~O**.
4. Tách H^+^ khỏi O còn lại → ester; H^+^ được trả lại (đúng vai trò xúc tác).

Mọi bước đều **thuận nghịch**, nên ester hóa là phản ứng **thuận nghịch**, không đi đến cùng.

> [!bay]
> - **Ngoại lệ**: với **alcol bậc III**, chính nhóm –OH **của alcol** bị tách ra (vì alcol bậc III dễ tạo carbocation bền).
> - **H~2~SO~4~ đặc** có hai vai trò: **xúc tác** (cung cấp H^+^) và **hút nước**, giúp cân bằng chuyển sang phải.
> - Hình vẽ cơ chế ở bước cuối trong sách (tr. 196) in chưa chuẩn (C mang dấu + cạnh nhóm C=O). Sản phẩm cuối của cơ chế chỉ đơn giản là ester **R–CO–OR′** trung hòa điện.

#### 1.5.4. Phản ứng khử nhóm –COOH

Nhóm –COOH rất **khó bị khử**. Chỉ chất khử mạnh như **LiAlH~4~** (lithi nhôm hydrid) mới khử được, sản phẩm cuối là **alcol bậc I**:

=> CH~3~–CH~2~–COOH → CH~3~–CH~2~–CH~2~OH  (LiAlH~4~)

#### 1.5.5. Tạo halogenid acid

Thay nhóm –OH của acid bằng halogen nhờ **PCl~5~** (hoặc PCl~3~, SOCl~2~):

=> CH~3~COOH + PCl~5~ → CH~3~COCl + POCl~3~ + HCl

CH~3~COCl là **acetyl clorid**, thuộc loại **clorid acid** (acyl clorid).

> [!bay] Tên gọi
> Giáo trình đặt tên mục này là "tạo thành acid hydrohalid". Gọi đúng là **halogenid acid** (acyl halogenid, R–CO–X), **không phải acid**: chúng không còn nhóm –COOH. Đừng nhầm với "acid hydrohalogenic" (HCl, HBr…).

#### 1.5.6. Tạo anhydrid acid

Tách một phân tử nước từ **hai phân tử acid** (chất hút nước mạnh P~2~O~5~, đun nóng):

=> 2CH~3~COOH → (CH~3~CO)~2~O + H~2~O  (P~2~O~5~, t°)

**Anhydrid acetic** dễ bị thủy phân trở lại thành acid. Nó được dùng nhiều trong tổng hợp để **gắn nhóm acyl** R–CO– vào phân tử khác (ví dụ điều chế **aspirin**, mục 3.4.2).

> [!vi-du] Khả năng phản ứng của các dẫn xuất acid
> Các dẫn xuất R–CO–Y tham gia phản ứng **thế nucleophil** ở C của nhóm C=O (gắn nhóm acyl cho chất khác). Độ hoạt động giảm dần theo khả năng "rời đi" của Y:
> **clorid acid (Y = Cl) > anhydrid (Y = OCOR) > ester (Y = OR′) > amid (Y = NH~2~)**.
> Vì thế muốn ester hóa nhóm –OH **phenol** (kém hoạt động) phải dùng anhydrid hay clorid acid; acid thường không đủ mạnh (mục 3.4.2). Amid thì bền nhất — liên kết **peptid** trong protein là liên kết amid.

#### 1.5.7. Thế nguyên tử H ở carbon α

Nhóm C=O hút electron làm H ở **Cα** trở nên linh động. Cho acid tác dụng với **halogen** (Cl~2~, Br~2~), có **phospho đỏ** làm xúc tác, H ở Cα bị thế:

=> CH~3~–CH~2~–COOH + Cl~2~ → CH~3~–CHCl–COOH + HCl  (P đỏ)

Sản phẩm là **acid α-cloropropionic** (acid 2-cloropropanoic). Phản ứng tiếp tục cho đến khi **thế hết H ở Cα**.

#### 1.5.8. Một số phản ứng riêng

**a) Acid không no** — có thêm phản ứng của nối đôi:

- Cộng H~2~ (Ni): CH~2~=CH–COOH + H~2~ → CH~3~–CH~2~–COOH.
- Cộng HBr: Br gắn vào **C xa –COOH** (Cβ), **ngược với quy tắc Markovnikov**: CH~2~=CH–COOH + HBr → BrCH~2~–CH~2~–COOH (acid β-bromopropionic). Lý do: C=C liên hợp với C=O nên phản ứng đi theo kiểu **cộng 1,4** vào cả hệ liên hợp: H^+^ gắn vào O của C=O, còn Br^−^ tấn công đầu kia của hệ là Cβ.
- Bị oxy hóa (KMnO~4~ loãng) ở nối đôi → **alcol acid**: CH~2~=CH–COOH → HOCH~2~–CH(OH)–COOH (acid 2,3-dihydroxypropanoic, acid glyceric).

**b) Acid dicarboxylic:**

- **Acid malonic** (và acid oxalic) khi đun nóng **mất CO~2~** (khử carboxyl), tạo acid ít hơn 1C:

=> HOOC–CH~2~–COOH → CH~3~–COOH + CO~2~↑  (t°)

- Acid có **4–5C** (succinic, glutaric) khi đun nóng **mất 1 H~2~O** tạo **anhydrid vòng** 5–6 cạnh. Succinic (4C) tạo vòng dễ nhất vì hai –COOH ở gần nhau; từ 6C trở lên khó tạo vòng.

=> HOOC–CH~2~–CH~2~–COOH → anhydrid succinic (vòng 5 cạnh) + H~2~O  (t°)

**c) Acid thơm**: có phản ứng **thế vào nhân**. –COOH là nhóm hút electron (−C, −I) nên **làm nhân kém hoạt động** hơn benzen và **định hướng meta**. Brom hóa acid benzoic phải đun nóng, có xúc tác; sản phẩm là **acid m-bromobenzoic**. (Xem bài *Hydrocarbon*.)

### 1.6. Nguồn thiên nhiên và điều chế

Trong tự nhiên có acid tự do (formic trong kiến, acetic trong giấm, oxalic trong chua me) và phổ biến hơn là **muối, ester** (calci oxalat trong sỏi thận; dầu thực vật, mỡ, sáp động vật).

| Phương pháp | Phương trình (ví dụ) | Ghi nhớ |
|---|---|---|
| **Oxy hóa alcol bậc I, aldehyd** (acid cromic, KMnO~4~) | C~2~H~5~OH → CH~3~CHO → CH~3~COOH ; ethylen glycol → glyoxal (aldehyd oxalic) → **acid oxalic** | Giữ nguyên số C |
| **Oxy hóa mạch nhánh trên vòng thơm** (KMnO~4~, t°) | C~6~H~5~–CH~3~ → C~6~H~5~–COOH ; C~6~H~5~–CH~2~CH~2~CH~3~ → C~6~H~5~–COOH | Nhánh dài bao nhiêu cũng chỉ còn **1C** (C sát vòng bị tấn công) |
| **Grignard + CO~2~** | R–MgCl + CO~2~ → R–COOMgCl ; + HCl → R–COOH + MgCl~2~ | Acid **thêm 1C** so với gốc R |
| **Thủy phân nitril** (acid hoặc kiềm, t°) | CH~3~–C≡N + 2H~2~O → CH~3~COOH + NH~3~ ; C~6~H~5~CN → C~6~H~5~COOH | Acid **thêm 1C** so với halogenid ban đầu (R–X + CN^−^ → R–CN) |

> [!bay]
> - Giáo trình gọi CH~3~–C≡N là "methyl nitril". Tên IUPAC là **ethannitril** (tên thường: **acetonitril**) — C của nhóm –C≡N được tính vào mạch.
> - Muốn **tăng mạch thêm 1C** khi đi từ dẫn xuất halogen thì dùng **Grignard + CO~2~** hoặc **qua nitril**; oxy hóa thì **không** đổi (hoặc làm giảm) số C.

### 1.7. Ứng dụng và ý nghĩa y học

- **Công nghiệp**: acid acetic, formic làm chất cầm màu trong nhuộm; acid adipic để sản xuất tơ nylon-6,6.
- **Thực phẩm**: acid acetic là **giấm ăn**, dùng đóng hộp; acid formic từng dùng bảo quản nước quả nhờ tác dụng khử trùng; **natri benzoat** (E211) là chất bảo quản phổ biến.
- **Dược phẩm**: nhiều acid là thuốc hoặc nguyên liệu tổng hợp thuốc: **acid acetylsalicylic (aspirin)** giảm đau, hạ sốt; natri benzoat dùng trong một số siro ho.
- **Chuyển hóa**: acid **succinic, fumaric, malic, citric** là các chất trung gian của **chu trình acid citric (chu trình Krebs)** trong ty thể.

> [!bay] Hình aspirin ở trang 200
> Hình "aspirin" ở Giáo trình tr. 200 vẽ nhóm –CO–CH~3~ gắn **thẳng vào vòng** — đó là một ceton, không phải aspirin. Aspirin đúng là **acid 2-(acetyloxy)benzoic**: nhóm **–O–CO–CH~3~** (ester) gắn vào vòng ở vị trí ortho so với –COOH. Sách vẽ đúng ở tr. 207. Đi thi phải vẽ có nguyên tử **O cầu nối**.

> [!bay] "Oxalic" hay "oxaloacetic"?
> Giáo trình viết acid oxalic, succinic… có vai trò quan trọng trong trao đổi chất. Thực ra chất trung gian của chu trình Krebs là **acid oxaloacetic** (một **oxo acid**, mục 4), không phải acid oxalic. Acid oxalic trong cơ thể chủ yếu là **chất thải**, liên quan đến sỏi thận (xem dưới).

> [!ung-dung] Acid oxalic — sỏi calci oxalat và ngộ độc ethylen glycol
> - Ion oxalat kết hợp Ca^2+^ tạo **calci oxalat CaC~2~O~4~ rất ít tan**: Ca^2+^ + C~2~O~4~^2−^ → CaC~2~O~4~↓. Đây là thành phần của loại **sỏi thận phổ biến nhất**. Người có sỏi oxalat được khuyên uống đủ nước và không ăn quá nhiều thực phẩm giàu oxalat (rau chua me, rau dền, cải bó xôi, khế chua…).
> - **Ngộ độc ethylen glycol** (chất chống đông, có trong một số rượu pha chế bất hợp pháp): trong cơ thể, ethylen glycol bị enzym (alcol dehydrogenase…) oxy hóa dần — cùng nguyên tắc với dãy oxy hóa ở mục 1.6 nhưng qua các chất trung gian glycolaldehyd → **acid glycolic** → acid glyoxylic → **acid oxalic**. Hậu quả: **toan chuyển hóa** (chủ yếu do acid glycolic), **tinh thể calci oxalat trong nước tiểu**, hạ calci máu, **suy thận cấp**. Đây là cấp cứu.
> - Acid oxalic còn có **tính khử** (khác acid acetic): làm mất màu KMnO~4~ trong acid. Phản ứng này dùng trong định lượng:
>
> => 5H~2~C~2~O~4~ + 2KMnO~4~ + 3H~2~SO~4~ → 10CO~2~↑ + 2MnSO~4~ + K~2~SO~4~ + 8H~2~O

## 2. Ester

### 2.1. Định nghĩa và phân loại

Ester là dẫn xuất của acid carboxylic, trong đó nhóm **–OH của acid được thay bằng nhóm alkoxy –OR′** của alcol: R–COOH → **R–COOR′** (Giáo trình tr. 200).

Dựa vào cấu tạo của acid và alcol, giáo trình chia ester thành **4 loại**:

| Loại | Thành phần | Ví dụ |
|---|---|---|
| **Ester hoa quả** | Acid thấp/trung bình + alcol thấp/trung bình | HCOOC~2~H~5~ ethyl formiat (mùi rượu rum); HCOOC~5~H~11~ amyl formiat (mùi mận); CH~3~COOC~5~H~11~ **isoamyl acetat (mùi chuối)**; C~3~H~7~COOC~2~H~5~ ethyl butyrat (mùi dứa) |
| **Glycerid** (lipid, chất béo) | **Glycerol** + acid béo cao, **số C chẵn, mạch không phân nhánh** | Tristearin; R~1~, R~2~, R~3~ là gốc của acid stearic C~17~H~35~COOH, palmitic C~15~H~31~COOH, oleic C~17~H~33~COOH… |
| **Serid** (sáp) | Acid béo cao + **alcol béo cao** (mạch dài) | **Sáp ong** = miricyl palmitat C~15~H~31~COOC~30~H~61~ |
| **Sterid** | Acid béo cao + **alcol vòng (sterol)** | **Cholesterid** = ester của cholesterol với acid palmitic, stearic… |

- Glycerid có R~1~ = R~2~ = R~3~ gọi là **glycerid đơn giản**; khác nhau gọi là **glycerid phức tạp** (hỗn tạp).
- **Sáp thực vật** phủ trên lá, hoa, quả: chống mất nước và ngăn vi khuẩn xâm nhập.

> [!vi-du] Acid béo hay gặp
> | Acid | Công thức | Số C : nối đôi | Gặp trong |
> |---|---|---|---|
> | Palmitic | C~15~H~31~COOH | 16 : 0 (no) | Mỡ, dầu cọ |
> | Stearic | C~17~H~35~COOH | 18 : 0 (no) | Mỡ động vật |
> | Oleic | C~17~H~33~COOH | 18 : 1 (cis) | Dầu oliu, dầu lạc, dầu vừng |
> | Linoleic | C~17~H~31~COOH | 18 : 2 | Dầu đậu nành, dầu hướng dương |
>
> Mẹo kiểm tra: acid no C~n~H~2n+1~COOH; mỗi nối đôi bớt 2H. C~17~H~35~ (no) → C~17~H~33~ (1 nối đôi) → C~17~H~31~ (2 nối đôi). Chất béo nhiều gốc **no** thì **rắn** (mỡ); nhiều gốc **không no** thì **lỏng** (dầu).

### 2.2. Danh pháp

Tên ester = **tên gốc alkyl R′ (của alcol) + tên gốc acid** (đổi đuôi -ic thành **-at**).

- CH~3~COOC~2~H~5~: **ethyl acetat** (IUPAC: ethyl ethanoat).
- HCOOCH~3~: methyl formiat. C~6~H~5~COOCH~3~: methyl benzoat. CH~3~COOC~6~H~5~: **phenyl acetat**.

> [!bay] Đọc ngược với cách viết
> Công thức viết **gốc acid trước** (R–COO–), nhưng tên đọc **gốc alcol trước**. CH~3~COOC~2~H~5~ là ethyl **acetat**, còn C~2~H~5~COOCH~3~ là methyl **propionat** — hai chất khác nhau dù cùng công thức C~4~H~8~O~2~.

### 2.3. Tính chất vật lý

Ester thấp và trung bình là chất **lỏng nhẹ hơn nước, dễ bay hơi**, nhiều chất có **mùi thơm quả chín**. Ester **rất ít tan trong nước**, tan nhiều trong dung môi hữu cơ (ethanol, ether, benzen…).

| Ester | Nhiệt độ sôi (°C) |
|---|---|
| HCOOCH~3~ methyl formiat | 31,5 |
| CH~3~COOCH~3~ methyl acetat | 57,0 |
| CH~3~COOC~2~H~5~ ethyl acetat | 77,0 |
| CH~3~CH~2~CH~2~COOCH~3~ methyl butyrat | 102,3 |
| CH~3~COOC~6~H~5~ phenyl acetat | 195,7 |
| C~6~H~5~COOCH~3~ methyl benzoat | 199,6 |

**Vì sao ester sôi thấp hơn acid đồng phân?** Ester **không còn H gắn với O**, nên các phân tử ester **không tạo liên kết hydro** với nhau. Ví dụ C~2~H~4~O~2~: methyl formiat sôi ở **31,5 °C**, còn acid acetic sôi ở **118,5 °C**. Cũng vì thế ester ít tan trong nước hơn acid.

### 2.4. Tính chất hóa học

#### 2.4.1. Phản ứng thủy phân

Ester bị thủy phân trong **dung dịch acid** và trong **dung dịch kiềm** (NaOH, KOH):

=> R–COOR′ + H~2~O ⇌ R–COOH + R′OH  (H^+^, t° — thuận nghịch)

=> R–COOR′ + NaOH → R–COONa + R′OH  (t° — một chiều)

Thủy phân trong kiềm gọi là **phản ứng xà phòng hóa**, vì dùng để sản xuất **xà phòng** từ chất béo. Ví dụ xà phòng hóa tristearin:

=> (C~17~H~35~COO)~3~C~3~H~5~ + 3NaOH → C~3~H~5~(OH)~3~ + 3C~17~H~35~COONa

Sản phẩm là **glycerol** và **natri stearat** (xà phòng). Xà phòng hóa cholesterid thu được cholesterol và muối của acid béo cao.

> [!bay]
> - Giáo trình viết như thể mọi phản ứng thủy phân ester đều gọi là xà phòng hóa. Chính xác: chỉ **thủy phân trong kiềm** mới là **xà phòng hóa**. Thủy phân trong acid là phản ứng **thuận nghịch** (chiều ngược của ester hóa).
> - **Vì sao trong kiềm lại một chiều?** Acid vừa sinh ra bị kiềm chuyển ngay thành **anion carboxylat R–COO^−^**. Anion này không còn phản ứng với alcol, nên phản ứng không quay ngược được.
> - Xà phòng hóa 1 mol triglycerid cần **3 mol NaOH**.

> [!ung-dung] Xà phòng, nước cứng và lipid trong cơ thể
> - **Xà phòng** là muối natri (hoặc kali — xà phòng mềm) của acid béo. Phân tử có **đầu ưa nước** (–COO^−^) và **đuôi kỵ nước** (mạch C dài) nên bao lấy vết dầu mỡ thành hạt nhỏ phân tán trong nước. Trong **nước cứng**, Ca^2+^, Mg^2+^ tạo **xà phòng calci, magnesi không tan** (váng), xà phòng mất tác dụng (xem bài *Kim loại khối s*).
> - Trong ruột, **lipase** của tụy thủy phân triglycerid thành acid béo và monoglycerid, **muối mật** nhũ tương hóa chúng — về hình thức cũng là "thủy phân ester". Thuốc giảm cân **orlistat** ức chế lipase, nên mỡ không được hấp thu và theo phân ra ngoài.
> - Trong máu, cholesterol phần lớn ở dạng **ester (cholesterid)** nằm trong lõi các lipoprotein (LDL, HDL).

#### 2.4.2. Tạo amid

Ester tác dụng với **amoniac** cho **amid** và alcol (nhóm –OR′ được thay bằng –NH~2~):

=> C~6~H~5~–COOCH~3~ + NH~3~ → C~6~H~5~–CONH~2~ + CH~3~OH

Sản phẩm là **benzamid** và methanol.

#### 2.4.3. Với thuốc thử Grignard → alcol bậc III

Thuốc thử Grignard (nucleophil) tấn công vào C của nhóm C=O. Phân tử thứ nhất đẩy nhóm –OR′ ra, tạo ceton; ceton lại cộng tiếp **phân tử Grignard thứ hai**. Thủy phân sản phẩm cho **alcol bậc III** có **hai gốc R″ giống nhau**:

=> R–COOR′ + 2R″MgBr → R–C(OMgBr)R″~2~ (+ R′OMgBr) ; thủy phân → **R–C(OH)R″~2~**

> [!bay]
> Sơ đồ ở Giáo trình tr. 203 vẽ sản phẩm R–C(OH)(R′)–R″, tức là gốc R′ của phần alcol vẫn ở lại. Thực tế nhóm **–OR′ bị tách ra** (thành R′OMgBr), và C nhận **hai gốc R″** từ hai phân tử Grignard. Đây là cách điều chế alcol bậc III có hai nhóm thế giống nhau.

#### 2.4.4. Khử ester bằng LiAlH~4~

Ester bị LiAlH~4~ khử thành **hai alcol**: alcol bậc I từ phần acid và alcol R′OH:

=> R–COOR′ → R–CH~2~OH + R′OH  (LiAlH~4~, ether)

LiAlH~4~ chỉ khử C=O mà **không khử nối đôi C=C** trong phân tử:

=> CH~3~CH=CH–COOCH~2~CH~3~ → CH~3~CH=CH–CH~2~OH + CH~3~CH~2~OH

Ethyl but-2-enoat (giáo trình: ethyl 2-butenoat) cho **but-2-en-1-ol** (giáo trình: 2-butenol) và ethanol.

### 2.5. Điều chế ester

Đun acid với alcol, có xúc tác acid (mục 1.5.3). Vì phản ứng **thuận nghịch**, muốn tăng hiệu suất phải đẩy cân bằng sang phải (nguyên lý Le Chatelier):

- dùng **dư alcol** (hoặc dư acid);
- **chưng cất tách ester** ngay khi nó vừa tạo thành (ester sôi thấp hơn acid và alcol tương ứng);
- dùng H~2~SO~4~ đặc để **hút nước**.

Với phenol thì không ester hóa trực tiếp bằng acid được; phải dùng **anhydrid** hoặc **clorid acid** (mục 3.4.2).

### 2.6. Ứng dụng và ý nghĩa y học

- **Ester hoa quả** làm hương liệu trong thực phẩm, nước giải khát. **Ethyl acetat** là dung môi cho sơn, keo, mỹ phẩm (và dung môi chiết trong phòng thí nghiệm dược liệu).
- **Chất béo (lipid)** là nguồn năng lượng dự trữ lớn nhất. Giáo trình ghi: 1 g chất béo cho **9,4 kcal**, còn protid và glucid lần lượt **4,0 và 4,2 kcal/g**. (Trong dinh dưỡng học hiện nay thường làm tròn theo hệ số Atwater: **9 – 4 – 4 kcal/g**.)
- **Thuốc bôi ngoài da**: **DEP** (diethyl phtalat, ester của acid phtalic) chữa **ghẻ**; **methyl salicylat** là thuốc xoa bóp giảm đau cơ.

> [!ung-dung] Methyl salicylat — "mùi dầu gió"
> **Methyl salicylat** là thành phần chính của tinh dầu **lộc đề xanh** (*Gaultheria*, wintergreen). Đây là hoạt chất có mùi đặc trưng trong nhiều loại **dầu gió, cao xoa, miếng dán giảm đau**. Bôi lên da nó gây cảm giác nóng (kích thích tại chỗ), được hấp thu một phần và giải phóng salicylat giảm đau.
> **Cảnh báo:** methyl salicylat **rất độc nếu uống**. Chỉ khoảng **5 ml** dầu methyl salicylat nguyên chất tương đương **khoảng 7 g aspirin**; trẻ nhỏ uống nhầm có thể tử vong. Phải để dầu gió, cao xoa xa tầm tay trẻ em. Không bôi diện rộng, không băng kín, không dùng cùng thuốc chống đông khi chưa hỏi ý kiến bác sĩ.

> [!yhct] Dầu thực vật, sáp ong làm tá dược — vì sao bền, vì sao hỏng
> - **Dầu vừng (dầu mè), dầu lạc** là **glycerid**. Trong bào chế YHCT chúng làm **tá dược** cho cao xoa, thuốc mỡ, dầu bôi và làm dung môi chiết hoạt chất tan trong dầu (rán, ngâm dược liệu trong dầu). Khi nấu **cao dán đen** với Duyên đan, dầu bị **xà phòng hóa** bởi oxide chì tạo **xà phòng chì** dẻo dính — đã phân tích ở bài *Kim loại khối p (IIIA, IVA)* (vc-02), ở đây không nhắc lại.
> - **Sáp ong** (Hoàng lạp; tẩy trắng gọi là Bạch lạp) là **serid** (chủ yếu miricyl palmitat). Ester của acid và alcol đều mạch rất dài nên sáp **rắn, không tan trong nước, rất khó thủy phân**. Nhờ vậy sáp ong dùng làm **tá dược viên hoàn sáp** (lạp hoàn — viên tan chậm), làm **vỏ bọc** chống ẩm cho viên hoàn mật quý, và làm tá dược thuốc mỡ.
> - **Vì sao dầu, thuốc mỡ để lâu bị "khét", chua?** Một phần do **thủy phân** liên kết ester (có nước, enzym, vi sinh vật) giải phóng **acid béo tự do** — chỉ số acid tăng; phần quan trọng hơn là **oxy hóa** gốc acid béo không no (bài *Phản ứng của hợp chất hữu cơ*, hc-04). Vì vậy dầu dùng làm tá dược nên được đun "luyện" để loại nước, đựng kín, tránh ánh sáng.

## 3. Hydroxy acid (alcol acid và phenol acid)

### 3.1. Định nghĩa và phân loại

**Hydroxy acid** là hợp chất **tạp chức** có cả nhóm **hydroxy –OH** và nhóm **carboxyl –COOH** trong phân tử (Giáo trình tr. 204).

| Loại | –OH gắn vào | Ví dụ |
|---|---|---|
| **Alcol acid** | C no của mạch hydrocarbon | Acid **lactic** CH~3~–CH(OH)–COOH; acid **malic** HOOC–CH(OH)–CH~2~–COOH; acid citric; acid tartric |
| **Phenol acid** | C của **vòng thơm** | Acid **salicylic** o-HO–C~6~H~4~–COOH; acid gallic |

### 3.2. Danh pháp

Theo IUPAC, **–COOH là nhóm chức chính** (đọc ở đuôi), **–OH là nhóm chức phụ**, đọc là tiền tố **hydroxy-**:

**acid + hydroxy + tên acid tương ứng**

| Công thức | Tên IUPAC | Tên thường |
|---|---|---|
| CH~3~–CH(OH)–COOH | acid **2-hydroxypropanoic** | acid **lactic** |
| HOOC–CH(OH)–CH~2~–COOH | acid **2-hydroxybutandioic** | acid **malic** |
| HOOC–CH(OH)–CH(OH)–COOH | acid **2,3-dihydroxybutandioic** | acid **tartric** |
| HOCH~2~–COOH | acid hydroxyethanoic | acid **glycolic** |
| HO–C~6~H~10~–COOH (vòng no) | acid 4-hydroxycyclohexancarboxylic | |
| (C~6~H~5~)~2~C(OH)–COOH | acid 2-hydroxy-2,2-diphenylethanoic | (acid benzilic) |
| o-HO–C~6~H~4~–COOH | acid **2-hydroxybenzoic** | acid **salicylic** |
| HOOC–CH~2~–C(OH)(COOH)–CH~2~–COOH | acid 2-hydroxypropan-1,2,3-tricarboxylic | acid **citric** |

Nhiều alcol acid phức tạp thường được gọi bằng **tên thường** (citric, malic, tartric…).

> [!bay] Đánh số acid malic
> HOOC–CH(OH)–CH~2~–COOH: đánh số từ đầu nào cũng có C1 là –COOH, nên chọn hướng cho –OH **số nhỏ nhất** → **2-hydroxy**butandioic. Đáp án cuối sách (bài 9.1l) ghi "3-hydroxy butandioic" là **chưa đúng quy tắc**.

### 3.3. Tính chất vật lý

- Alcol acid đơn chức: lỏng hoặc rắn, **dễ tan** trong nước (nhiều nhóm tạo liên kết hydro). Alcol acid đa chức: rắn kết tinh, cũng dễ tan.
- Nhiều alcol acid **có C\*** nên **quang hoạt** và có đồng phân quang học (lactic, malic, tartric).
- Phenol acid: tinh thể **hình kim**, dễ **thăng hoa**, **ít tan** trong nước, tan trong ethanol, ether.

### 3.4. Tính chất hóa học

Tính chất của hydroxy acid gồm tính chất của **–COOH**, của **–OH**, và một số phản ứng **riêng** do hai nhóm ở gần nhau.

#### 3.4.1. Phản ứng của nhóm –COOH

**Tính acid mạnh hơn acid tương ứng**, do hiệu ứng **−I của nhóm –OH** ở gần –COOH. Ví dụ acid glycolic HOCH~2~COOH (pK~a~ 3,83) mạnh hơn acid acetic (4,76); acid lactic (3,86) mạnh hơn propionic (4,85).

> [!bay] Số liệu "mạnh hơn hàng nghìn lần" ở tr. 206
> Giáo trình ghi K~a~ của acid glycolic là "152·10^−4^" so với 0,176·10^−4^ của acid acetic và kết luận "lớn hàng nghìn lần". Đây là **lỗi in**: K~a~ đúng của acid glycolic khoảng **1,5·10^−4^**, tức chỉ mạnh hơn acid acetic khoảng **8–9 lần** (chênh khoảng 0,9 đơn vị pK~a~). Kết luận về **thứ tự** (glycolic > acetic, do −I của –OH) vẫn đúng.

**Tạo muối:**

- Alcol acid với NaOH: chỉ –COOH phản ứng (–OH alcol không có tính acid đáng kể):

=> HOCH~2~–COOH + NaOH → HOCH~2~–COONa + H~2~O  (natri glycolat)

- Phenol acid với **NaOH**: cả **–COOH và –OH phenol** đều phản ứng:

=> HO–C~6~H~4~–COOH + 2NaOH → NaO–C~6~H~4~–COONa + 2H~2~O

- Phenol acid với **Na~2~CO~3~** (theo giáo trình) hoặc **NaHCO~3~**: chỉ nhóm **–COOH** phản ứng:

=> 2HO–C~6~H~4~–COOH + Na~2~CO~3~ → 2HO–C~6~H~4~–COONa + H~2~O + CO~2~↑

Muối thu được là **natri salicylat**.

**Tạo ester ở nhóm –COOH** (với alcol, xúc tác acid):

=> HOCH~2~–COOH + C~2~H~5~OH ⇌ HOCH~2~–COOC~2~H~5~ + H~2~O  (ethyl glycolat)

=> HO–C~6~H~4~–COOH + CH~3~OH → HO–C~6~H~4~–COOCH~3~ + H~2~O  (H~2~SO~4~ đặc; **methyl salicylat**)

#### 3.4.2. Phản ứng của nhóm –OH

- –OH của **alcol acid** phản ứng như **alcol bậc I** (giáo trình): tạo ester với acid, tạo ether…

=> HOOC–CH~2~OH + HOOC–CH~3~ ⇌ HOOC–CH~2~–O–CO–CH~3~ + H~2~O

- –OH của **phenol acid** **không ester hóa được bằng acid**; chỉ phản ứng với **anhydrid acid** (hoặc clorid acid). Đây chính là phản ứng **điều chế aspirin**:

=> HO–C~6~H~4~–COOH + (CH~3~CO)~2~O → CH~3~COO–C~6~H~4~–COOH + CH~3~COOH

![Hình 3. Từ acid salicylic: ester hóa nhóm –OH phenol cho aspirin, ester hóa nhóm –COOH cho methyl salicylat](salicylic.svg)

> [!bay] Hai ester của cùng một acid salicylic
> - **Aspirin**: ester hóa ở **–OH phenol** (acid salicylic đóng vai "alcol", acid acetic đóng vai acid) → **còn nhóm –COOH** tự do, nên aspirin vẫn là một **acid**.
> - **Methyl salicylat**: ester hóa ở **–COOH** (acid salicylic đóng vai acid, methanol đóng vai alcol) → **còn –OH phenol** tự do, nên vẫn cho màu tím với FeCl~3~.
> - Vì sao phenol không ester hóa được bằng acid? Cặp electron của O phenol liên hợp vào vòng benzen, nên O kém **nucleophil** hơn O của alcol. Phải dùng tác nhân acyl hóa mạnh hơn (anhydrid).

#### 3.4.3. Phản ứng đặc biệt (do –OH và –COOH ở gần nhau)

**a) Phản ứng bẻ gãy mạch** — của **α-hydroxy acid** (–OH ở Cα). Đun với acid vô cơ loãng, phân tử bị cắt thành **acid formic** và một **aldehyd** (nếu Cα bậc II) hoặc **ceton** (nếu Cα bậc III):

=> CH~3~–CH(OH)–COOH → CH~3~–CHO + HCOOH

=> (CH~3~)~2~C(OH)–COOH → CH~3~–CO–CH~3~ + HCOOH

**b) Loại nước tạo vòng lacton** — –OH ở vị trí **γ hoặc δ**. Nhóm –OH và –COOH trong **cùng một phân tử** ester hóa với nhau (ester **nội phân tử**), tạo vòng **5 hoặc 6 cạnh** gọi là **lacton**:

=> HO–CH~2~–CH~2~–CH~2~–COOH → γ-butyrolacton (vòng 5 cạnh) + H~2~O

**c) Loại nước tạo vòng lactid** — của **α-hydroxy acid**. **Hai phân tử** ester hóa chéo với nhau (–OH của phân tử này với –COOH của phân tử kia), mất **2 H~2~O**, tạo vòng 6 cạnh gọi là **lactid**:

=> 2CH~3~–CH(OH)–COOH → lactid (vòng 6 cạnh chứa 2 nhóm ester) + 2H~2~O

**d) Tạo phức màu với Fe^3+^** — dùng để **nhận biết**:

- Alcol acid (acid lactic) + Fe^3+^ → phức màu **vàng**.
- Phenol acid (acid salicylic) + Fe^3+^ → phức màu **tím** (xanh tím).

> [!ghi-nho] Vị trí –OH quyết định kiểu "tự phản ứng"
> | –OH ở | Đun nóng cho | Lý do |
> |---|---|---|
> | **α** | **Lactid** (2 phân tử, vòng 6) hoặc bị bẻ gãy (acid loãng) | Một phân tử không tự khép vòng được (vòng 3 cạnh quá căng) |
> | **γ, δ** | **Lacton** (1 phân tử, vòng 5–6) | Vòng 5–6 cạnh bền, ít căng |

> [!vi-du] Lacton, lactid quanh ta
> - **Vitamin C** (acid ascorbic) là một **γ-lacton** (vòng 5 cạnh). "Acid" trong tên của nó là do nhóm enol, không phải –COOH.
> - **Chỉ khâu phẫu thuật tự tiêu** (ví dụ polyglactin) là **polyester** trùng hợp từ lactid và glycolid. Trong mô, các liên kết **ester bị thủy phân** dần thành acid lactic và acid glycolic, cơ thể chuyển hóa tiếp được — nên chỉ "tự tiêu", không cần cắt chỉ. Nhựa **PLA** (poly-lactic) phân hủy sinh học cũng dựa trên nguyên lý đó.

### 3.5. Ứng dụng và ý nghĩa y học

Giáo trình (tr. 208) nêu:

- **Acid lactic**: dùng chữa tiêu chảy ở trẻ em; trong lao động nặng, acid lactic tăng và tích tụ ở cơ gây **mỏi và đau cơ**.
- **Acid citric**: chữa ngộ độc bởi chất kiềm; dùng trong công nghiệp nước giải khát.
- **Ester của phenol acid**: **methyl salicylat** xoa bóp chữa tê thấp; **aspirin** hạ nhiệt, giảm đau.
- **Acid salicylic** có tính sát trùng, dùng ngoài da.

> [!ung-dung] Aspirin — một ester "làm việc" bằng phản ứng chuyển nhóm acyl
> - Aspirin **ức chế enzym cyclooxygenase (COX)** bằng cách **chuyển nhóm acetyl** của nó lên enzym (gắn vào một gốc serin) — tức là chính liên kết ester "trao" nhóm acyl, giống phản ứng thế nucleophil ở mục 1.5.6. Sự ức chế này **không hồi phục**: tiểu cầu không có nhân, không tổng hợp lại enzym, nên tác dụng chống kết tập tiểu cầu kéo dài suốt đời sống tiểu cầu (khoảng 7–10 ngày). Đó là lý do dùng **aspirin liều thấp** để phòng huyết khối và phải **ngưng trước phẫu thuật** theo chỉ định.
> - **Bảo quản**: aspirin gặp ẩm bị **thủy phân** thành acid salicylic + acid acetic (viên thuốc có **mùi giấm**). Kiểm nghiệm dùng FeCl~3~ để phát hiện acid salicylic tự do (Hình 3). Vì thế aspirin phải đóng gói kín, tránh ẩm.
> - **Tác dụng phụ**: kích ứng, loét dạ dày (xem bài *Hiệu ứng cấu trúc*); **không dùng cho trẻ em và thanh thiếu niên bị sốt do virus** (cúm, thủy đậu) vì nguy cơ **hội chứng Reye** (tổn thương gan, não).
> - **Acid salicylic** bôi ngoài có tác dụng **làm bong lớp sừng** (tiêu sừng): dùng trị mụn trứng cá, vảy da, mụn cóc, chai chân. Không uống được vì quá kích ứng — chính vì thế người ta mới "che" nhóm –OH bằng ester hóa để có aspirin.

> [!ung-dung] Acid lactic và acid citric trong lâm sàng
> - **Lactat máu**: thiếu oxy mô (sốc, nhiễm khuẩn nặng, suy tuần hoàn), tế bào chuyển sang đường phân kỵ khí: acid pyruvic bị khử thành **acid lactic**. Lactat máu **> 2 mmol/L** là bất thường; tăng cao kèm pH giảm là **nhiễm toan lactic** — dấu hiệu nặng. **Metformin** (thuốc đái tháo đường) có thể gây nhiễm toan lactic — hiếm gặp, nhưng nguy cơ tăng rõ ở người **suy thận** (thuốc bị tích lũy).
> - **Dung dịch Ringer lactat**: dịch truyền chứa **natri lactat**; lactat được gan chuyển hóa tạo bicarbonat, giúp bù kiềm nhẹ.
> - **Citrat**: chống đông máu khi lấy máu, trữ máu (tạo phức với Ca^2+^ — xem bài *Kim loại khối s*). **Kali citrat** uống dùng phòng **sỏi thận** calci oxalat và sỏi urat: citrat tạo phức tan với Ca^2+^ và kiềm hóa nước tiểu.
> - **Acid lactic, acid glycolic** (gọi chung là **AHA**, alpha-hydroxy acid) dùng trong mỹ phẩm, da liễu để làm bong lớp sừng; acid lactic còn có trong dung dịch vệ sinh phụ nữ (giữ pH acid nhẹ).

> [!cap-nhat] Acid lactic, đau cơ và ngộ độc kiềm
> - **Đau cơ.** Giáo trình ghi acid lactic tích tụ trong cơ gây mỏi và đau cơ. **Hiện nay:** lactat được đào thải khỏi cơ và máu trong khoảng **một giờ** sau vận động (gan, tim, cơ còn dùng nó làm nhiên liệu). Cảm giác **đau cơ muộn 1–3 ngày** sau tập là do **tổn thương vi thể sợi cơ và phản ứng viêm**, không phải do acid lactic "đọng lại". Vai trò của lactat trong mỏi cơ cấp vẫn đang được bàn luận.
> - **Tiêu chảy trẻ em.** Giáo trình nêu acid lactic chữa tiêu chảy ở trẻ em. **Hiện nay** điều trị nền tảng là **bù nước bằng ORS độ thẩm thấu thấp** và **bổ sung kẽm** theo hướng dẫn của WHO và Bộ Y tế; acid lactic không còn là thuốc điều trị tiêu chảy.
> - **Ngộ độc kiềm.** Giáo trình nêu acid citric chữa ngộ độc chất kiềm. **Hiện nay** khi uống nhầm **chất kiềm ăn da** (xút, nước tẩy rửa), **không được** cho uống acid để trung hòa: phản ứng trung hòa **tỏa nhiệt** làm bỏng nặng thêm. Không gây nôn; đưa ngay đến cơ sở cấp cứu.
>
> Đi thi: trả lời theo giáo trình.

> [!yhct] Acid hữu cơ và tannin trong dược liệu: Ô mai, Sơn tra, Ngũ bội tử
> - **Ô mai** (quả mơ *Prunus mume* hun khói) chứa nhiều **acid hữu cơ** — chủ yếu **acid citric, acid malic**, cùng acid succinic. Đây là cơ sở hóa học của **vị chua** (toan), gắn với công năng **liễm phế chỉ khái, sáp trường chỉ tả, sinh tân chỉ khát** của Ô mai trong YHCT. Các alcol acid này **tan tốt trong nước**, nên có mặt đầy đủ trong nước sắc.
> - **Sơn tra** (ở Việt Nam là quả cây **táo mèo** *Docynia indica* hoặc cây **chua chát** *Malus doumeri*; ở Trung Quốc là *Crataegus pinnatifida*) chứa **acid hữu cơ** (citric, malic…), **acid triterpenic** (acid ursolic — có nhóm –COOH gắn trên khung triterpen) và flavonoid. Công năng truyền thống **tiêu thực tích**, nhất là thức ăn nhiều thịt mỡ. Việc acid hữu cơ kích thích tiết dịch vị mới là **giả thuyết hợp lý**, bằng chứng lâm sàng còn hạn chế.
> - **Ngũ bội tử** (tổ sâu trên cây muối *Rhus chinensis*) chứa rất nhiều **tannin thủy phân được** (gallotannin, khoảng 50–70%). Gallotannin là **ester của acid gallic** (acid 3,4,5-trihydroxybenzoic — một **phenol acid**) với glucose. Đun với acid hoặc nhờ enzym, liên kết ester bị **thủy phân** giải phóng **acid gallic**. Tannin làm **tủa protein** → cơ sở của tác dụng **thu liễm, cầm máu, cầm tiêu chảy** dùng ngoài và dùng trong.
> - **Hệ quả bào chế:** tannin và acid gallic là **phenol**, tạo phức **xanh đen** với Fe^3+^ (cùng loại phản ứng với acid salicylic ở mục 3.4.3) — vì vậy sắc thuốc chứa tannin **không dùng nồi sắt** ("kỵ sắt"). Tannin còn tạo tủa với **alkaloid** và protein, nên có thể làm giảm hấp thu một số thuốc khi uống cùng lúc.

## 4. Oxo acid

### 4.1. Định nghĩa

**Oxo acid** là hợp chất tạp chức có nhóm **carbonyl** (>C=O) và nhóm **carboxyl** (–COOH) trong phân tử (Giáo trình tr. 208):

- Carbonyl là nhóm **aldehyd** → **aldehyd acid**. Ví dụ **acid glyoxalic** OHC–COOH (acid oxoethanoic).
- Carbonyl là nhóm **ceton** → **ceto acid** (ceton acid). Ví dụ **acid pyruvic** CH~3~–CO–COOH (acid 2-oxopropanoic; giáo trình: acid 2-cetopropanoic).

### 4.2. Danh pháp

–COOH là **nhóm chức chính**. Nhóm >C=O trong mạch gọi là **oxo-**; nhóm –CHO làm nhánh gọi là **formyl-**; CH~3~–CO– là **acetyl-**; C~6~H~5~–CO– là **benzoyl-**.

| Công thức | Tên IUPAC |
|---|---|
| OHC–CH~2~–COOH | acid **3-oxopropanoic** |
| CH~3~–CO–COOH | acid **2-oxopropanoic** (acid pyruvic) |
| CH~3~–CH~2~–CO–CH~2~–COOH | acid **3-oxopentanoic** (giáo trình: 3-cetopentanoic) |
| CH~3~–CO–CH~2~–COOH | acid **3-oxobutanoic** (acid **acetoacetic**) |
| HOOC–CH~2~–CH(CHO)–COOH | acid **2-formylbutandioic** (giáo trình: formylbutandioic) |
| HOOC–CH~2~–CH(COCH~3~)–COOH | acid **2-acetylbutandioic** |
| HOOC–CO–CH~2~–COOH | acid 2-oxobutandioic (acid **oxaloacetic**) |

> [!bay]
> Tiền tố đúng theo IUPAC là **oxo-**. "Ceto-" là cách gọi cũ trong giáo trình. Khi nhóm –CHO **không nằm trong mạch chính** (là nhánh) thì gọi **formyl-**, còn nếu là C cuối mạch chính thì C đó được đánh số và gọi **oxo-** (OHC–CH~2~–COOH = 3-oxopropanoic).

### 4.3. Tính chất vật lý

Acid glyoxalic là chất lỏng sánh, dễ tan trong nước. Các ceto acid như acid pyruvic, acid acetoacetic cũng là chất lỏng tan trong nước.

### 4.4. Tính chất hóa học

#### 4.4.1. Phản ứng của nhóm carboxyl

Oxo acid tác dụng với base, muối carbonat, kim loại hoạt động tạo muối:

=> 2CH~3~–CO–COOH + Na~2~CO~3~ → 2CH~3~–CO–COONa + H~2~O + CO~2~↑

Oxo acid là **acid mạnh hơn** acid carboxylic no tương ứng, do **hiệu ứng −I của nhóm C=O**. Acid pyruvic (pK~a~ ≈ 2,5) mạnh hơn acid propanoic (pK~a~ ≈ 4,9) khoảng **vài trăm lần**.

> [!bay] Bảng 20 (tr. 209)
> Các giá trị K~a~ trong Bảng 20 in không thống nhất với Bảng 18 (ví dụ propanoic ghi "0,134·10^−2^", trong khi Bảng 18 ghi 1,4·10^−5^). Chỉ cần nhớ **thứ tự**: **2-oxopropanoic > propanoic**. Nhóm C=O càng gần –COOH thì ảnh hưởng càng mạnh (α-ceto acid mạnh hơn β-ceto acid).

#### 4.4.2. Phản ứng của nhóm carbonyl

Oxo acid có **phản ứng cộng** của aldehyd/ceton (A~N~ — xem bài *Aldehyd và ceton*).

- **Cộng H~2~** (Ni) → **alcol acid**:

=> HOOC–CH~2~–CO–CH~3~ + H~2~ → HOOC–CH~2~–CH(OH)–CH~3~  (Ni)

Đây là acid acetoacetic chuyển thành **acid β-hydroxybutyric** (acid 3-hydroxybutanoic).

- **Cộng HCN** → **cyanohydrin**:

=> CH~3~–CO–COOH + HCN → CH~3~–C(OH)(CN)–COOH

> [!ung-dung] Acid pyruvic, acetoacetic và thể ceton
> - **Acid pyruvic** là sản phẩm cuối của **đường phân** (glucose → 2 pyruvat). Có đủ oxy: pyruvat vào ty thể, thành **acetyl-CoA**, đi vào chu trình Krebs. Thiếu oxy: pyruvat bị **khử** thành **lactat** — về mặt hóa học chính là **cộng hydro vào nhóm C=O** của ceto acid, tạo alcol acid (như phản ứng ở mục 4.4.2).
> - **Thể ceton** (cetonic) gồm 3 chất: **acid acetoacetic** (ceto acid), **acid β-hydroxybutyric** (alcol acid — sản phẩm khử của acid acetoacetic) và **aceton**. Gan tạo ra chúng khi phải đốt nhiều acid béo: nhịn đói lâu, chế độ ăn rất ít glucid, và đặc biệt là **đái tháo đường thiếu insulin**.
> - **Aceton** sinh ra do acid acetoacetic tự **mất CO~2~** — giống acid malonic ở mục 1.5.8 (cả hai đều có C=O ở vị trí β so với –COOH): CH~3~–CO–CH~2~–COOH → CH~3~–CO–CH~3~ + CO~2~. Aceton bay hơi qua phổi gây **hơi thở mùi táo chín/mùi aceton**.
> - **Nhiễm toan ceton đái tháo đường (DKA)**: hai ceto/hydroxy acid tích tụ làm **pH máu giảm** — cấp cứu nội khoa.
> - **Xét nghiệm**: que thử nước tiểu (phản ứng nitroprusiat) phát hiện **acetoacetat** (và aceton) nhưng **không phát hiện β-hydroxybutyrat** — chất chiếm ưu thế trong DKA. Vì vậy hiện nay ưu tiên **định lượng β-hydroxybutyrat máu**.

## 5. Hướng dẫn bài tập tự lượng giá

> [!vi-du] 9.1 — Gọi tên (IUPAC; tên thường)
> a) CH~2~=CH–COOH: acid **propenoic**; acid acrylic · b) HOOC–CH~2~–COOH: acid **propandioic**; acid malonic · c) HOOC–CH=CH–COOH: acid **but-2-endioic**; acid **maleic** (cis) / **fumaric** (trans) · d) CH~3~–CHOH–COOH: acid **2-hydroxypropanoic**; acid lactic · e) HOOC–(CH~2~)~3~–COOH: acid **pentandioic**; acid glutaric · f) CH~2~=CH–CH~2~–COOCH~3~: **methyl but-3-enoat** · g) o-HO–C~6~H~4~–COOH: acid **2-hydroxybenzoic**; acid salicylic · h) p-HOOC–C~6~H~4~–COOH: acid **benzen-1,4-dicarboxylic**; acid terephtalic · i) C~6~H~5~–CH~2~–CH~2~–COOH: acid **3-phenylpropanoic** · k) như d: acid lactic · l) HOOC–CH(OH)–CH~2~–COOH: acid **2-hydroxybutandioic**; acid malic · m) HOOC–CH(OH)–CH(OH)–COOH: acid **2,3-dihydroxybutandioic**; acid tartric.

> [!bay] Đáp án cuối sách (tr. 256) có mấy chỗ cần sửa
> - **9.1c** ghi "but-2-endioic, acid malonic" — sai tên thường: acid malonic là HOOC–CH~2~–COOH (propandioic). HOOC–CH=CH–COOH là **maleic/fumaric**.
> - **9.1f** ghi "methyl butenoat" — thiếu vị trí nối đôi: đúng là **methyl but-3-enoat**.
> - **9.1l** ghi "3-hydroxy butandioic" — đúng quy tắc phải là **2-hydroxy**butandioic.
> - **9.4c** ghi "malic và fumaric là 2 đồng phân cis–trans của acid 2-butendioic" — **sai**: cặp cis–trans là **maleic và fumaric**. Acid malic là alcol acid (xem 9.4 bên dưới).
> - **9.8**: xem bên dưới.

> [!vi-du] 9.2 — Viết công thức
> a) "acid 1-clorobutanoic" là tên sai (xem mục 1.2); đáp án vẽ ClCH~2~CH~2~CH~2~COOH = **acid 4-clorobutanoic** · b) acid 2-hydroxy-2-methylpropanoic: **(CH~3~)~2~C(OH)–COOH** · c) acid 5-methyl-6-oxohexanoic: **OHC–CH(CH~3~)–CH~2~–CH~2~–CH~2~–COOH** · d) acid 4-acetylbenzoic: **p-CH~3~CO–C~6~H~4~–COOH** · e) acid 4-methylcyclohexancarboxylic: **CH~3~–C~6~H~10~–COOH** (vòng no; đáp án sách in nhầm "C~6~H~6~").

> [!vi-du] 9.3 — Thí nghiệm ^18^O và cơ chế
> Ester hóa acid benzoic bằng C~2~H~5~–^18^OH: ^18^O nằm trong ethyl benzoat, không nằm trong nước → acid mất –OH, alcol mất H. Cơ chế 4 bước: proton hóa O carbonyl → alcol cộng vào C → chuyển H^+^, tách H~2~O → tách H^+^ (mục 1.5.3, Hình 2).

> [!vi-du] 9.4 — So sánh từng cặp
> - **a) Acetic – oxalic**: mono- và di-carboxylic. Oxalic **mạnh hơn nhiều** (pK~a1~ 1,27 so với 4,76), tạo **2 loại muối**, đun nóng **mất CO~2~**, và có **tính khử** (làm mất màu KMnO~4~); acetic không có các tính chất này.
> - **b) Acetic – lactic**: lactic là **alcol acid** (thêm –OH ở Cα) → mạnh hơn acetic, có **C\*** (quang hoạt), có thêm phản ứng của –OH alcol, tạo **lactid**, bị **bẻ gãy mạch** khi đun với acid loãng, cho màu **vàng** với Fe^3+^.
> - **c) Malic – fumaric**: malic HOOC–CH(OH)–CH~2~–COOH là **alcol acid** có C\*; fumaric HOOC–CH=CH–COOH (trans) là **acid không no** có đồng phân **cis–trans** (với maleic), có phản ứng **cộng** vào nối đôi. Liên hệ: cộng nước vào acid fumaric thì được acid malic — chính là một bước của **chu trình Krebs** (enzym fumarase).
> - **d) Lactic – salicylic**: **alcol acid** và **phenol acid**. Salicylic: –OH phenol phản ứng được với NaOH (tốn 2 NaOH), chỉ ester hóa bằng **anhydrid**, cho màu **tím** với Fe^3+^; lactic: –OH alcol không phản ứng với NaOH, ester hóa được bằng acid, cho màu **vàng** với Fe^3+^.

> [!vi-du] 9.5 — Acid benzoic và các acid clorobenzoic
> Cl hút electron (−I) mạnh hơn đẩy electron qua liên hợp (+C) → cả ba acid clorobenzoic đều **mạnh hơn** acid benzoic. −I giảm theo khoảng cách nên: **ortho > meta > para > benzoic** (pK~a~ tham khảo: 2,9 · 3,8 · 4,0 · 4,2). Ở vị trí para, +C của Cl bù trừ một phần nên ảnh hưởng nhỏ nhất.

> [!vi-du] 9.6 — Acid dicarboxylic (C ≤ 5) có gì đặc biệt?
> Tính acid nấc 1 mạnh hơn; tạo 2 loại muối; **đun nóng**: oxalic, malonic **mất CO~2~**; succinic, glutaric **mất H~2~O tạo anhydrid vòng** (đáp án sách nhấn mạnh ý này); oxalic còn có tính khử.

> [!vi-du] 9.7 — Điều chế
> a) **Propyl butanoat**: CH~3~CH~2~CH~2~COOH + CH~3~CH~2~CH~2~OH ⇌ CH~3~CH~2~CH~2~COOCH~2~CH~2~CH~3~ + H~2~O (H~2~SO~4~ đặc, t°)
> b) **Methyl salicylat**: HO–C~6~H~4~–COOH + CH~3~OH ⇌ HO–C~6~H~4~–COOCH~3~ + H~2~O (H~2~SO~4~ đặc, t°)
> c) **Aspirin**: HO–C~6~H~4~–COOH + (CH~3~CO)~2~O → CH~3~COO–C~6~H~4~–COOH + CH~3~COOH

> [!vi-du] 9.8 — Ethyl acetoacetat + LiAlH~4~
> CH~3~–CO–CH~2~–COOC~2~H~5~ có hai nhóm C=O: ceton và ester. **LiAlH~4~ khử cả hai**: ceton → alcol bậc II, ester → alcol bậc I + ethanol. Sản phẩm: **CH~3~–CH(OH)–CH~2~–CH~2~OH (butan-1,3-diol) + C~2~H~5~OH**.
> Đáp án cuối sách ghi sản phẩm là CH~3~–CHOH–CH~2~–COOC~2~H~5~ (chỉ khử ceton). Điều đó chỉ đúng khi dùng chất khử **yếu hơn** như **NaBH~4~** (khử ceton, không khử ester). Với LiAlH~4~ thì không dừng lại ở đó — chính giáo trình (mục 2.4.4) cũng viết LiAlH~4~ khử ester thành alcol.

> [!vi-du] 9.9 — Điều chế acid tăng 1C
> a) Acid cyclohexancarboxylic từ cyclohexyl clorid (dùng **Grignard + CO~2~**, mục 1.6):
> C~6~H~11~Cl + Mg → C~6~H~11~MgCl (ether khan); C~6~H~11~MgCl + CO~2~ → C~6~H~11~COOMgCl; + HCl → **C~6~H~11~COOH** + MgCl~2~.
> b) Acid phenylacetic từ benzyl bromid (qua **nitril**):
> C~6~H~5~CH~2~Br + NaCN → C~6~H~5~CH~2~CN + NaBr; C~6~H~5~CH~2~CN + 2H~2~O → **C~6~H~5~CH~2~COOH** + NH~3~ (H^+^ hoặc OH^−^, t°). Cũng có thể đi qua Grignard + CO~2~ như câu a.
> Đáp án cuối sách đi đường vòng (Wurtz → clo hóa → thủy phân → oxy hóa); về nguyên tắc dài và nhiều sản phẩm phụ. Hai cách trên đúng các phương pháp giáo trình trình bày.

> [!vi-du] 9.10 — Dẫn xuất của acid và sản phẩm thủy phân
> Anhydrid (CH~3~CO)~2~O + H~2~O → 2CH~3~COOH · Clorid acid CH~3~COCl + H~2~O → CH~3~COOH + HCl · Amid CH~3~CONH~2~ + H~2~O → CH~3~COOH + NH~3~ (H^+^ hay OH^−^, t°) · Ester CH~3~COOC~2~H~5~ + H~2~O ⇌ CH~3~COOH + C~2~H~5~OH. Tất cả đều trả lại **acid carboxylic** (hoặc muối của nó nếu thủy phân trong kiềm).

> [!vi-du] 9.11 — Acid béo của lipid và cách lấy acid béo từ dầu, mỡ
> Acid palmitic C~15~H~31~COOH, stearic C~17~H~35~COOH, oleic C~17~H~33~COOH, linoleic C~17~H~31~COOH. Xà phòng hóa dầu/mỡ rồi acid hóa muối thu được:
> (C~17~H~35~COO)~3~C~3~H~5~ + 3NaOH → C~3~H~5~(OH)~3~ + 3C~17~H~35~COONa; C~17~H~35~COONa + HCl → C~17~H~35~COOH↓ + NaCl.

## Tóm tắt

| Chủ đề | Ghi nhớ |
|---|---|
| Tên IUPAC | acid + hydrocarbon + **-oic**; C của –COOH là **C1**; vòng: **-carboxylic**; tên thường dùng α (= C2), β, γ |
| Tính acid | alcol < phenol < H~2~CO~3~ < RCOOH (mạnh nhất); hút e (−I) → mạnh; +I → yếu. Oxalic (1,27) > … > formic (3,74) > acetic (4,76) > propionic (4,85) |
| Phản ứng của RCOOH | muối; **ester hóa** (thuận nghịch, acid mất OH); khử LiAlH~4~ → alcol I; PCl~5~ → clorid acid; P~2~O~5~ → anhydrid; X~2~/P đỏ → thế H~α~ |
| Riêng | Không no: cộng (HBr vào Cβ); malonic, oxalic **mất CO~2~**; succinic → **anhydrid vòng**; acid thơm thế **meta** |
| Điều chế | Oxy hóa alcol I/aldehyd; oxy hóa nhánh trên vòng; **Grignard + CO~2~** và **thủy phân nitril** (thêm 1C) |
| Ester | 4 loại: hoa quả, **glycerid**, **serid** (sáp), **sterid**; sôi **thấp** hơn acid đồng phân (không có liên kết H) |
| Phản ứng ester | Thủy phân acid ⇌; kiềm → **xà phòng hóa** (một chiều); + NH~3~ → amid; + 2 RMgX → alcol III; LiAlH~4~ → 2 alcol |
| Hydroxy acid | Alcol acid / phenol acid; mạnh hơn acid tương ứng. –OH phenol chỉ ester hóa bằng **anhydrid** (→ aspirin). α → **lactid**, bẻ gãy mạch; γ, δ → **lacton**. Fe^3+^: alcol acid **vàng**, phenol acid **tím** |
| Oxo acid | Aldehyd acid (glyoxalic), ceto acid (pyruvic, acetoacetic); tiền tố **oxo-/formyl-/acetyl-**; mạnh hơn acid thường; cộng H~2~ → alcol acid, cộng HCN → cyanohydrin |
| Y học | Aspirin (ester, acetyl hóa COX, thủy phân khi ẩm); methyl salicylat (dầu gió, độc khi uống); lactat máu; citrat chống đông, phòng sỏi; oxalat → sỏi, ngộ độc ethylen glycol; thể ceton (acetoacetic, β-hydroxybutyric, aceton) |
