---
title: Một số vấn đề về sinh quyển
thoi-gian: 30 phút
muc-tieu:
- Nêu được khái niệm sinh thái học, sinh quyển và các thành phần của một hệ sinh thái (sinh vật sản xuất, tiêu thụ, phân hủy; chuỗi và lưới thức ăn).
- Mô tả được các vòng tuần hoàn vật chất trong hệ sinh thái: carbon, oxy, nitơ, lưu huỳnh, phospho.
- Trình bày được dòng năng lượng trong hệ sinh thái: hiệu suất quang hợp, sức sản xuất sơ cấp thô và nguyên, sức sản xuất thứ cấp, sự mất năng lượng qua từng bậc dinh dưỡng.
- Nêu được hiện tượng El Nino, La Nina, cách nhận biết (SOI, SST) và hậu quả của chúng.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. **Sinh quyển** là toàn bộ khoảng không gian có sự sống trên Trái Đất (một phần khí quyển, lục địa, đại dương) cùng các sinh vật và hệ sinh thái trong đó.
> 2. **Vật chất tuần hoàn** (vô cơ → hữu cơ → vô cơ) theo các **chu trình sinh địa hóa**; **năng lượng chỉ đi một chiều** (mặt trời → sinh vật → nhiệt), không quay vòng.
> 3. Bốn vòng cơ bản được nghiên cứu kỹ: **C, O~2~, N~2~, P** (sách trình bày thêm vòng **S**). Sinh vật **phân hủy** là mắt xích khép kín mọi vòng.
> 4. Cây xanh chỉ giữ lại khoảng **0,1–0,5%** năng lượng mặt trời (mía tốt: **1,43%**). Qua mỗi bậc dinh dưỡng năng lượng lại mất phần lớn (hô hấp, nhiệt, chất thải).
> 5. **El Nino**: nước biển xích đạo Đông Thái Bình Dương **nóng lên** (SOI **âm**, SST **dương**) → Đông bán cầu (có Đông Nam Á) **hạn hán**; **La Nina** thì ngược lại.

## 1. Một số khái niệm chung

### 1.1. Sinh thái học và sinh quyển

**Sinh thái học** (ecology), theo nghĩa rộng, nghiên cứu **mối quan hệ tương tác giữa sinh vật và môi trường**. Môi trường gồm cả phần **vô sinh** (ánh sáng, nước, nhiệt độ, chất khoáng…) và phần **hữu sinh** (các sinh vật khác). Các quan hệ này ảnh hưởng tới sự phát triển, sinh sản và sự sống ở mọi mức tổ chức: cá thể, quần thể, quần xã, hệ sinh thái, sinh quyển (Giáo trình tr. 150).

**Các phân ngành** của sinh thái học được chia theo đối tượng nghiên cứu:

| Chia theo mức tổ chức | Chia theo nhóm sinh vật |
|---|---|
| Sinh thái học **cá thể**, **quần thể**, **quần xã**, **hệ sinh thái** | Sinh thái học **côn trùng**, sinh thái học **cá**, sinh thái học **loài người**… |

**Sinh quyển** (biosphere) là khoảng không gian trên Trái Đất có sự sống. Nó gồm lớp khí quyển, lục địa và đại dương nơi có cơ thể sống và các hệ sinh thái đang hoạt động. Theo giáo trình, sinh quyển chứa **nhiều hiểm họa**, đe dọa sự sống từ cá thể tới quần thể, quần xã và cả hệ sinh thái. Vì vậy chương này không đi sâu vào từng phân ngành, mà tập trung vào các vấn đề **chung của sinh quyển** và một số nội dung của **sinh thái học loài người**.

> [!cap-nhat] Những "hiểm họa của sinh quyển" được đo đạc ra sao hiện nay (bổ sung – kiến thức hiện nay)
> - **Suy giảm đa dạng sinh học**: báo cáo đánh giá toàn cầu của **IPBES (2019)** ước tính khoảng **1 triệu loài** động, thực vật đang bị đe dọa tuyệt chủng; khoảng **75% bề mặt đất liền** và **66% diện tích đại dương** đã bị con người làm biến đổi đáng kể. Năm nguyên nhân trực tiếp lớn nhất, theo thứ tự: thay đổi sử dụng đất – biển, khai thác trực tiếp sinh vật, biến đổi khí hậu, ô nhiễm, loài ngoại lai xâm hại.
> - **Biến đổi khí hậu** do khí nhà kính (xem khung về CO~2~ ở mục 2.2.1).
> - **Tầng ozon** từng bị chất CFC phá hủy (lỗ thủng ozon ở Nam Cực); nhờ **Nghị định thư Montreal (1987)** cấm dần các chất này, tầng ozon đang phục hồi và dự kiến trở lại mức năm 1980 vào khoảng giữa thế kỷ XXI (WMO/UNEP, 2023). Đây là ví dụ hiếm hoi một hiểm họa toàn cầu được kiểm soát nhờ hợp tác quốc tế.
>
> Với ngành y, mất đa dạng sinh học còn có nghĩa là mất **nguồn dược liệu** và tăng nguy cơ **bệnh lây từ động vật** khi rừng bị chia cắt (xem khái niệm "Một sức khỏe" ở bài Loài người và môi trường ngoại cảnh).

### 1.2. Hệ sinh thái, chuỗi và lưới thức ăn (kiến thức nền)

Giáo trình dùng các thuật ngữ dưới đây mà không định nghĩa riêng. Bạn cần nắm chúng để hiểu phần chu trình vật chất và dòng năng lượng.

**Hệ sinh thái** = **quần xã sinh vật** + **môi trường vô sinh** nơi chúng sống, tác động qua lại thành một thể thống nhất. Ví dụ: một ao, một khu rừng, một cánh đồng lúa. Sinh quyển là hệ sinh thái lớn nhất.

Theo **cách lấy chất hữu cơ và năng lượng**, sinh vật trong hệ sinh thái chia thành ba nhóm:

| Nhóm | Cách sống | Ví dụ |
|---|---|---|
| **Sinh vật sản xuất** (tự dưỡng) | Tự tổng hợp chất hữu cơ từ chất vô cơ, nhờ ánh sáng (quang hợp) hoặc nhờ năng lượng phản ứng hóa học (hóa tổng hợp) | Cây xanh, tảo, vi khuẩn lam; vi khuẩn hóa tự dưỡng |
| **Sinh vật tiêu thụ** (dị dưỡng) | Ăn sinh vật khác. **Bậc 1** ăn sinh vật sản xuất; **bậc 2** ăn bậc 1; **bậc 3** ăn bậc 2… | Châu chấu, trâu bò (bậc 1); ếch, chim sâu (bậc 2); rắn, diều hâu (bậc 3) |
| **Sinh vật phân hủy** | Phân giải xác và chất thải thành chất vô cơ trả lại môi trường | Vi khuẩn, nấm |

**Chuỗi thức ăn** là một dãy sinh vật, trong đó loài đứng trước là thức ăn của loài đứng sau. Ví dụ: cỏ → châu chấu → ếch → rắn. Mỗi vị trí trong chuỗi là một **bậc dinh dưỡng**. Mũi tên chỉ **chiều đi của vật chất và năng lượng**.

**Lưới thức ăn** gồm nhiều chuỗi thức ăn **có chung mắt xích**. Trong tự nhiên, một loài thường ăn nhiều loài và bị nhiều loài ăn, nên quan hệ thật là một lưới chứ không phải một chuỗi đơn. Lưới càng phức tạp thì hệ sinh thái càng **ổn định**: mất một loài, dòng năng lượng vẫn đi được qua đường khác.

> [!bay]
> - Mũi tên trong chuỗi thức ăn chỉ "**bị ăn bởi**" (chiều năng lượng), không phải "ăn". Cỏ → châu chấu nghĩa là năng lượng từ cỏ chuyển sang châu chấu.
> - Sinh vật **phân hủy** không phải "sinh vật tiêu thụ bậc cuối" của một chuỗi; chúng nhận xác và chất thải **từ mọi bậc**.
> - **Vi khuẩn hóa tự dưỡng** (như vi khuẩn nitrit hóa) cũng là sinh vật **sản xuất**, dù không dùng ánh sáng.

> [!ung-dung] Tích lũy sinh học qua chuỗi thức ăn
> Một số chất **không bị phân hủy và không bị đào thải** (thủy ngân hữu cơ, chì, cadmi, thuốc trừ sâu nhóm clo hữu cơ như DDT) đi theo chuỗi thức ăn và **tăng nồng độ ở bậc càng cao** (khuếch đại sinh học). Vì sao? Mỗi con vật ăn rất nhiều con mồi, năng lượng thì mất dần nhưng chất độc thì giữ lại trong cơ thể.
> - Ví dụ kinh điển: **bệnh Minamata** (Nhật Bản) do người ăn cá, sò nhiễm methyl thủy ngân từ nước thải nhà máy, gây tổn thương thần kinh nặng.
> - Lời khuyên dinh dưỡng thường gặp: phụ nữ có thai hạn chế cá **săn mồi cỡ lớn** (cá kiếm, cá mập, cá ngừ lớn), vì chúng ở bậc dinh dưỡng cao.
> - Cây trồng trên đất, nước ô nhiễm cũng hấp thu kim loại nặng. Đây là lý do dược liệu và thực phẩm phải được kiểm tra **giới hạn kim loại nặng** trước khi lưu hành.

## 2. Các chu trình sinh địa hóa và năng lượng học sinh thái

### 2.1. Khái niệm

**Vật chất tuần hoàn.** Cơ thể sống được xây từ các nguyên tố **C, H, O, N, S, P, Ca, Mg…** Ngoài môi trường, chúng ở dạng hợp chất vô cơ (CO~2~, H~2~O…) hoặc đơn chất (O~2~). Nhờ năng lượng và qua con đường sinh học, chúng kết hợp thành **chất hữu cơ** (glucid, lipid, protein, acid nucleic…) có tích trữ **hóa năng** (Giáo trình tr. 150).

*Vì sao vật chất phải tuần hoàn?* Lượng các nguyên tố sinh học trên Trái Đất là **có hạn** và **không được bổ sung từ bên ngoài**. Muốn sự sống tiếp nối, các nguyên tố trong xác chết và chất thải phải được **sinh vật phân hủy** tách ra, đưa về dạng vô cơ, rồi dùng lại để xây dựng cơ thể mới.

Sự luân chuyển này gọi là **chu trình sinh địa hóa** (giáo trình cũng viết "chu trình địa sinh hóa"). Mỗi chu trình có hai pha:

| Pha | Diễn ra ở đâu | Dạng tồn tại của nguyên tố |
|---|---|---|
| **Pha sinh học** | Trong cơ thể sinh vật | Hợp chất **hữu cơ** |
| **Pha vô sinh** | Ngoài môi trường (khí quyển, nước, đất, đá) | Thành phần **vô sinh** của môi trường |

Mức độ tái tuần hoàn khác nhau tùy nguyên tố: tùy nó phổ biến nhiều hay ít trong sinh quyển và tùy cách sinh vật sử dụng nó.

**Năng lượng đi một chiều.** Nguồn năng lượng đầu vào duy nhất cho sự sống là **quang năng** của mặt trời, được bổ sung liên tục (Giáo trình tr. 151):

=> Quang năng → hóa năng → các bậc dinh dưỡng → nhiệt

Cụ thể: quang hợp chuyển quang năng thành hóa năng trong chất hữu cơ của sinh vật sản xuất; hóa năng này chuyển tiếp cho sinh vật tiêu thụ bậc 1, 2, 3, vật ký sinh, vật phân hủy; cuối cùng tỏa vào khí quyển dưới dạng **nhiệt**.

Qua mỗi bậc dinh dưỡng, năng lượng **mất mát lớn** (hô hấp, tỏa nhiệt, hoạt động sống, theo chất thải). Năng lượng **không được dùng lại**. Vì vậy độ ổn định của một hệ sinh thái phụ thuộc vào **nguồn năng lượng đầu vào** nhiều hay ít. Môn nghiên cứu động học của dòng năng lượng này gọi là **năng lượng học sinh thái**.

| | Dòng vật chất | Dòng năng lượng |
|---|---|---|
| Hướng đi | **Tuần hoàn** (khép kín thành vòng) | **Một chiều**, không quay lại |
| Số phận cuối | Trở về dạng vô cơ, được dùng lại | Phân tán dần, mất đi dưới dạng **nhiệt** |
| Nguồn | Có hạn trên Trái Đất | Mặt trời, bổ sung liên tục |

> [!bay]
> Câu hỏi "cái gì tuần hoàn, cái gì không" rất hay gặp: **vật chất tuần hoàn, năng lượng thì không**. Hai dòng này diễn ra **đồng thời**: năng lượng đi "cõng" trên các phân tử hữu cơ đang luân chuyển trong chu trình.

### 2.2. Một số chu trình vật chất trong hệ sinh thái

Vật chất đi từ dạng **vô cơ → hữu cơ → vô cơ**, tạo thành các **vòng tuần hoàn vật chất**. Các vòng có **liên hệ với nhau**, ví dụ vòng C và vòng O~2~ gắn chặt qua quang hợp và hô hấp. Có nhiều vòng, nhưng **4 vòng cơ bản được nghiên cứu kỹ là C, O~2~, P và N~2~** (Giáo trình tr. 151).

> [!bay]
> Đề có thể hỏi "4 vòng cơ bản" theo sách: **C, O~2~, N~2~, P**. Vòng **lưu huỳnh** tuy được trình bày trong sách nhưng **không nằm trong** danh sách 4 vòng cơ bản đó.

#### 2.2.1. Vòng tuần hoàn carbon

- Carbon chiếm khoảng **18% khối lượng** chất sống.
- **Nguồn carbon** cho sinh vật là **CO~2~** trong không khí hoặc hòa tan trong nước.
- **Cố định carbon:** qua **quang hợp** ở thực vật có diệp lục (cây xanh, tảo) và **vi khuẩn lưu huỳnh**, CO~2~ thành chất hữu cơ (glucid, lipid, protein, acid nucleic). Ở dạng hữu cơ, carbon mới được sinh vật tiêu thụ các bậc **hấp thụ** được.
- **Pha sinh học** của vòng C cũng chính là đường đi của năng lượng: sinh vật sản xuất → sinh vật tiêu thụ → kết thúc ở sinh vật phân hủy.
- **Trả CO~2~:** **mọi sinh vật hô hấp** đều trả CO~2~ về khí quyển và nước. Sinh vật **phân hủy** đóng vai trò lớn: chúng tách carbon khỏi xác và chất thải, đưa về lại vòng.
- **Nhánh tích tụ:** ở nơi **thiếu oxy** (đất chặt, đáy hồ sâu…), chất hữu cơ không phân hủy hết mà **trầm lắng**, qua thời gian rất dài tạo thành **than, dầu mỏ, khí đốt**. Khi con người **khai thác và đốt** để lấy năng lượng, lượng CO~2~ khí quyển **tăng đáng kể**, góp phần gây **hiệu ứng nhà kính**, Trái Đất ấm lên, băng ở hai cực tan (Giáo trình tr. 151–152).

![Hình 1. Chu trình carbon (sơ đồ)](chu-trinh-carbon.svg)

> [!cap-nhat] Nồng độ CO~2~ khí quyển và nhiệt độ Trái Đất
> Giáo trình nói việc đốt nhiên liệu "**góp một phần**" gây hiệu ứng nhà kính. Hiện nay:
> - CO~2~ trung bình toàn cầu năm 2024 là **≈ 424 ppm** (WMO, Bản tin khí nhà kính 2025), so với khoảng **278–280 ppm** trước Cách mạng công nghiệp, tức đã tăng **hơn 50%**. Năm 2024 cũng là năm CO~2~ **tăng nhanh nhất** kể từ khi đo (≈ 3,5 ppm/năm). Số liệu đo tại trạm Mauna Loa (NOAA) và trung bình toàn cầu được cập nhật **hằng tháng, hằng năm** tại gml.noaa.gov và trong Bản tin khí nhà kính hằng năm của WMO; con số mỗi năm tăng thêm ≈ 2–3,5 ppm. Phần tăng chủ yếu do đốt nhiên liệu hóa thạch, một phần do phá rừng.
> - **Nhiệt độ**: năm 2024 là năm nóng nhất từng ghi nhận, trung bình toàn cầu cao hơn thời tiền công nghiệp (1850–1900) khoảng **1,55 ± 0,13 °C** (WMO, 2025), là năm dương lịch đầu tiên vượt mốc 1,5 °C. Lưu ý: mục tiêu 1,5 °C của **Thỏa thuận Paris** tính theo **trung bình nhiều thập kỷ**, nên một năm vượt chưa có nghĩa là mục tiêu đã thất bại.
> - Đồng thuận khoa học (IPCC, Báo cáo đánh giá lần 6, 2021–2023): hoạt động của con người là **nguyên nhân chính, rõ ràng** của sự ấm lên toàn cầu.
> - Một phần CO~2~ thải ra tan vào đại dương, làm nước biển **acid hóa** (axit hóa) (pH bề mặt đã giảm ≈ 0,1 đơn vị), gây hại cho san hô và sinh vật có vỏ calci.
>
> Đi thi trả lời theo ý của sách.

#### 2.2.2. Chu trình oxy

Chu trình oxy **nghịch đảo** với chu trình carbon:

- **Quang hợp** giải phóng O~2~; **hô hấp** (và đốt cháy) tiêu thụ O~2~ để oxy hóa chất hữu cơ.
- Lượng O~2~ sinh ra khi quang hợp **tỷ lệ thuận** với lượng carbon được cố định thành chất hữu cơ.

*Vì sao O~2~ khí quyển đã tăng dần qua lịch sử Trái Đất?* Mỗi phân tử carbon bị "chôn" lại (trong sinh khối và trong nhiên liệu lòng đất), không bị oxy hóa trở lại, thì phần O~2~ tương ứng được **giữ lại** trong khí quyển. Qua hàng triệu năm, quá trình này làm O~2~ **không ngừng tăng**. Sự tăng O~2~ có vai trò lớn trong **tiến hóa** của các dạng sống sơ khai và trong việc sinh vật **chuyển lên sống trên cạn** (Giáo trình tr. 152).

**Gần đây**, nồng độ O~2~ bắt đầu **giảm dần**, trước hết do **đốt nhiên liệu lòng đất** (đốt là quá trình ngược của sự "chôn" carbon). Sách lấy ví dụ một máy bay phản lực liên lục địa dùng tới **4 tấn oxy** mỗi chuyến bay. Tuy vậy, mức giảm này **chưa ảnh hưởng đáng kể** tới cơ thể sống.

#### 2.2.3. Vòng tuần hoàn nitơ

**Nghịch lý của nitơ:** N~2~ chiếm **78%** khí quyển, nhưng sinh vật vẫn thường **thiếu nitơ**. *Vì sao?* Phân tử N~2~ có **liên kết ba rất bền**. Chỉ một số ít **sinh vật cố định đạm** có enzym bẻ được liên kết này; mọi sinh vật khác phải nhận nitơ ở **dạng hợp chất đã được cố định**:

| Sinh vật | Dạng nitơ sử dụng được |
|---|---|
| Thực vật | **NO~3~^-^** (nitrat) là tốt nhất; có thể thay bằng **NH~4~^+^** (amoni) hoặc **urea** CO(NH~2~)~2~ |
| Động vật, sinh vật bậc cao | Nitơ ở dạng **hữu cơ**, ví dụ **acid amin** (amino acid) |

Sách xét chu trình nitơ qua **3 phần chính**: **cố định nitơ – nitrat hóa – phân hủy nitrit** (Giáo trình tr. 152).

![Hình 2. Chu trình nitơ (sơ đồ)](chu-trinh-nito.svg)

**a) Cố định nitơ**: chuyển N~2~ khí quyển thành hợp chất nitơ (amoniac, nitrit, nitrat). Có ba con đường:

1. **Sét (chớp):** năng lượng tia sét làm N~2~ kết hợp O~2~:

=> (1) N~2~ + O~2~ → 2NO

=> (2) 2NO + O~2~ → 2NO~2~

=> (3) 3NO~2~ + H~2~O → 2H^+^ + 2NO~3~^-^ + NO

Nitrat theo nước mưa xuống đất. Con đường này cố định khoảng **6%** lượng nitơ tách khỏi khí quyển mỗi năm.

2. **Cố định sinh học:** năng suất cao nhất, chiếm **hơn 60%** sản lượng cố định hằng năm. Do vi sinh vật có enzym **nitrogenase**, tiêu tốn **nhiều ATP**, sản phẩm là **amoniac** (NH~3~). Enzym này làm việc trong điều kiện **yếm khí**. Ví dụ:
   - vi khuẩn **cộng sinh** trong **nốt sần rễ cây họ Đậu**;
   - vi khuẩn **sống tự do**: *Azotobacter*, *Clostridium*;
   - **vi khuẩn lam**: nguồn đạm quan trọng cho hệ sinh thái nước và đất (ví dụ trong ruộng lúa).

   NH~3~ tạo ra được nhanh chóng dùng để tổng hợp protein, acid nucleic, vitamin…

3. **Cố định công nghiệp (Haber–Bosch):** N~2~ + H~2~ ở **nhiệt độ cao, áp suất cao, có xúc tác** tạo NH~3~, dùng sản xuất phân đạm (như amoni nitrat). Theo sách chiếm khoảng **30%** sản lượng cố định nitơ.

=> N~2~ + 3H~2~ ⇌ 2NH~3~

> [!cap-nhat] Tỷ lệ cố định công nghiệp
> Các con số 6% (sét), > 60% (sinh học), 30% (công nghiệp) là của giáo trình. Lượng phân đạm công nghiệp tăng rất nhanh trong nửa sau thế kỷ XX. Hiện nay nhiều ước tính cho thấy cố định nitơ do con người (phân bón Haber–Bosch, trồng cây họ Đậu) đã **ngang hoặc vượt** cố định sinh học tự nhiên trên đất liền (ví dụ tổng quan của Fowler và cộng sự, 2013). Hậu quả là dư nitrat trong nước, phú dưỡng sông hồ. Đi thi dùng số của sách.

**b) Nitrat hóa** (theo nghĩa rộng của sách gồm cả vòng sinh vật và sự oxy hóa amoniac):

- Thực vật hấp thu **nitrat**, chuyển thành acid amin, rồi nitơ hữu cơ đi qua các bậc dinh dưỡng.
- Nitơ trở lại đất qua **phân, nước tiểu, xác chết**. Sinh vật phân hủy tiến hành **khử amin** (deamination), giải phóng **amoniac**. Phần lớn sự hoàn trả đi thẳng qua bài tiết **urea** và **acid uric**.
- Amoniac trong đất được **oxy hóa** thành nitrit rồi nitrat bởi các **vi khuẩn nitrit hóa**. Chúng là **vi khuẩn hóa tự dưỡng**: lấy năng lượng từ phản ứng hóa học để tổng hợp chất hữu cơ, **không cần ánh sáng** (Giáo trình tr. 154).

| Giai đoạn | Vi khuẩn | Phản ứng (viết đầy đủ ion) |
|---|---|---|
| NH~3~ → nitrit | ***Nitrosomonas*** | 2NH~3~ + 3O~2~ → 2NO~2~^-^ + 2H^+^ + 2H~2~O + năng lượng |
| Nitrit → nitrat | ***Nitrobacter*** | 2NO~2~^-^ + O~2~ → 2NO~3~^-^ + năng lượng |

- Không phải mọi amoniac và nitrat đều được sinh vật dùng lại; một phần chuyển vào **trầm tích**. **Amoniac** (NH~4~^+^) có xu hướng **ở lại trong đất** (bám vào hạt keo đất mang điện âm); **nitrat** thì dễ **trôi theo nước**, có khi gây **ô nhiễm sông hồ**.

> [!bay]
> - Sách viết phương trình *Nitrosomonas* là "→ 2NO~2~". Ở đây NO~2~ là **ion nitrit NO~2~^-^**, không phải khí NO~2~ của phản ứng sét.
> - Thứ tự đúng: **NH~3~ →(Nitrosomonas)→ NO~2~^-^ →(Nitrobacter)→ NO~3~^-^**. Dễ nhớ: "**so**" (Nitro**so**monas) đi trước, "**bac**" (Nitro**bac**ter) theo sau.
> - Sản phẩm của **cố định đạm sinh học** là **NH~3~** chứ không phải NO~3~ (phần tóm tắt của sách viết gọn "tạo nên NO~3~", tức là tính cả bước nitrat hóa sau đó).

**c) Phân hủy nitrit (phản nitrat hóa, denitrification):** một nhóm vi khuẩn khác sống ở **vùng thiếu oxy** dùng **NO~3~^-^ thay cho O~2~** để hô hấp yếm khí. Chúng tốn một phần năng lượng để phá ion nitrat, nhưng năng lượng thu được lớn hơn nhiều. Sản phẩm thải ra là **khí N~2~**, trả nitơ về khí quyển (Giáo trình tr. 154).

=> NO~3~^-^ → NO~2~^-^ → … → N~2~ ↑

**Tóm lại**, theo giáo trình:

- **Nguồn N~2~ trong thiên nhiên:** khí quyển (78% thể tích); phản nitrat hóa (NO~3~ → NO~2~) và phản nitrit hóa (NO~2~ → N~2~); **hoạt động núi lửa**.
- **Trên cạn:** vi khuẩn cố định đạm (trong đất, ở rễ cây) đưa N~2~ vào đất → nitrat → cây đồng hóa.
- **Dưới nước:** **tảo xanh (vi khuẩn lam)** cố định N~2~ → nitrat → thực vật thủy sinh đồng hóa → động vật thủy sinh ăn.
- **Xác và chất bài tiết** (trên cạn và dưới nước) → vi khuẩn tạo **NH~3~** → nitrit → … → trả về N~2~.

> [!ung-dung] Nitrat, nitrit và sức khỏe
> - Nước giếng ở vùng bón nhiều phân đạm có thể chứa **nitrat cao**. Ở **trẻ nhũ nhi** (nhất là khi pha sữa bằng nước này), nitrat bị vi khuẩn đường ruột khử thành **nitrit**; nitrit oxy hóa Fe^2+^ của hemoglobin thành Fe^3+^, tạo **methemoglobin** không chở được oxy → trẻ **tím tái** ("hội chứng em bé xanh"). Vì vậy nước ăn uống có quy chuẩn giới hạn nitrat, nitrit.
> - Nitrat, phosphat trôi vào ao hồ gây **phú dưỡng**: tảo, vi khuẩn lam bùng phát; một số vi khuẩn lam sinh **độc tố hại gan**; khi tảo chết, vi khuẩn phân hủy dùng hết oxy → cá chết hàng loạt.

#### 2.2.4. Chu trình lưu huỳnh

**Đặc điểm khác biệt:** pha vô cơ của vòng lưu huỳnh diễn ra **chủ yếu ở trầm tích (đất, đá)**, chứ không phải trong khí quyển như vòng C và vòng N (Giáo trình tr. 154).

Các bước chính:

1. **Trong không khí:** một lượng nhỏ S ở dạng **SO~2~, SO~3~**, sinh ra khi đốt các chất chứa lưu huỳnh (có nhiều trong đá chứa lưu huỳnh và **pyrit sắt**). Chúng kết hợp hơi nước thành **H~2~SO~3~, H~2~SO~4~**, theo **mưa** xuống đất và nước (đây là cơ sở của **mưa axit**).
2. **Thực vật hấp thu** lưu huỳnh ở dạng **SO~4~^2-^** (sulfat), tạo ra từ sự oxy hóa bề mặt đá. Sự oxy hóa này **chủ yếu là sinh học**, do vi khuẩn đặc biệt thực hiện để lấy năng lượng.
3. **Trong thực vật**, SO~4~^2-^ được đưa vào nhóm **thiol (–SH)** của acid amin và protein. Ở dạng này, S đi qua các bậc dinh dưỡng.
4. **Trả lại:** S ra khỏi cơ thể sống qua phân và xác chết. Vi khuẩn phân hủy nhóm –SH thành **H~2~S**, khí gây **mùi hôi thối** đặc trưng ở bãi rác.
5. **H~2~S** có thể được một vi khuẩn đặc biệt oxy hóa trở lại thành SO~4~^2-^. Một số **vi khuẩn quang hợp lưu huỳnh** dùng **H~2~S thay cho H~2~O** để tổng hợp glucid, nhờ **ánh sáng hồng ngoại**, và thải ra **lưu huỳnh** (S) thay vì O~2~:

=> 6CO~2~ + 12H~2~S → C~6~H~12~O~6~ + 6H~2~O + 12S

(phản ứng cần **ánh sáng hồng ngoại**)

> [!vi-du] So sánh với quang hợp của cây xanh
> Cây xanh: 6CO~2~ + 12H~2~O → C~6~H~12~O~6~ + 6H~2~O + **6O~2~**. Hai phương trình có cùng "khung": một chất cho hydro (H~2~O hoặc H~2~S) bị tách hydro để khử CO~2~. Cây xanh tách hydro từ nước nên thải **O~2~**; vi khuẩn lưu huỳnh tách hydro từ H~2~S nên thải **S**. Đây cũng là lý do sách xếp **vi khuẩn lưu huỳnh** vào nhóm cố định carbon ở vòng C.

> [!ung-dung] Ngộ độc khí H~2~S
> H~2~S tích tụ trong **hầm cầu, cống ngầm, hầm biogas, bể chứa chất thải** (nơi thiếu oxy, nhiều chất hữu cơ phân hủy). Khí này ức chế chuỗi hô hấp tế bào (ức chế cytochrom c oxidase, giống cyanid). Ở nồng độ cao, nó **làm tê liệt khứu giác** nên nạn nhân không còn ngửi thấy mùi "trứng thối" nữa, rồi ngất nhanh. Nhiều vụ tử vong xảy ra khi người xuống cứu cũng ngã theo. Nguyên tắc: **không xuống hầm kín khi chưa thông khí**, cứu nạn phải có thiết bị thở.

#### 2.2.5. Chu trình phospho

- **Đi vào cơ thể** ở dạng vô cơ: **PO~4~^3-^, HPO~4~^2-^, H~2~PO~4~^-^**. Sau đó được xây thành chất hữu cơ: **acid nucleic, phospholipid, ATP**.
- **Trả lại:** khi động, thực vật chết hoặc bài tiết, **vi khuẩn phosphat hóa** trả phosphat vô cơ về đất, khép lại vòng.
- **Ở nước:** phosphat hòa tan → **tảo** → **cá** → **chim** ăn cá. Phân chim chứa nhiều PO~4~. Ở một số đảo nhỏ ven biển (ví dụ **Peru**), phân chim biển tích tụ thành lớp dày gọi là **guano**, được khai thác làm phân bón (Giáo trình tr. 155).
- **Chậm nhất:** vòng P hoàn tất **rất chậm**. *Vì sao?* Phospho **không có dạng khí** đáng kể; kho dự trữ vô sinh của nó là **đá** và **trầm tích đáy biển**. Đá chỉ giải phóng phosphat khi được đưa lên mặt đất nhờ **chuyển động địa chất** rồi bị **bào mòn**. Phosphat theo nước trôi ra biển thì lắng xuống đáy, rất lâu mới quay lại.
- **Hệ quả:** khi nhiều phosphat đổ vào đồng ruộng và ao hồ, thực vật phát triển quá mạnh, có khi **bùng phát tảo xanh**, ảnh hưởng phần còn lại của hệ sinh thái.

| Vòng | Kho dự trữ vô sinh chính | Điểm cần nhớ |
|---|---|---|
| **Carbon** | **Khí quyển** (CO~2~), nước; nhiên liệu hóa thạch | Quang hợp cố định; hô hấp, đốt cháy trả lại |
| **Oxy** | **Khí quyển** | Nghịch đảo với vòng C |
| **Nitơ** | **Khí quyển** (N~2~ 78%) | Cố định đạm → nitrit hóa → nitrat hóa → phản nitrat hóa |
| **Lưu huỳnh** | **Trầm tích**, đá (pyrit) | SO~4~^2-^ vào nhóm –SH; phân hủy ra H~2~S |
| **Phospho** | **Đá, trầm tích** | Chậm nhất; guano; phú dưỡng |

> [!vi-du] Vòng tuần hoàn nước (bổ sung, sách không trình bày)
> Nước bốc hơi từ biển, ao hồ và qua **thoát hơi nước** ở lá cây → ngưng tụ thành mây → mưa → chảy trên mặt đất, thấm xuống đất, ra biển. Năng lượng vận hành vòng này cũng là **mặt trời**. Rừng giữ nước và trả hơi nước lại khí quyển, nên mất rừng làm thay đổi lượng mưa vùng đó và tăng lũ, xói mòn. Nước còn là "dòng xe" chở nitrat, phosphat, sulfat giữa đất, sông và biển trong các vòng ở trên.

### 2.3. Dòng năng lượng trong hệ sinh thái

**Năng lượng đi vào** một hệ sinh thái phụ thuộc vào **vĩ độ, khí hậu, thời gian chiếu sáng** trong năm. **Hiệu suất chuyển đổi** quang năng thành hóa năng lại tùy **cấu trúc hệ sinh thái** và loại sinh vật sản xuất chính.

**Số liệu cần nhớ** (Giáo trình tr. 155):

- Phần lớn năng lượng mặt trời chiếu xuống **bị mất, không được sử dụng**.
- Trung bình cây xanh chỉ chuyển được khoảng **0,1% – 0,5%** thành hóa năng.
- Cá biệt, ở hệ nhân tạo như **cánh đồng mía** (giống tốt, kỹ thuật canh tác tốt), hiệu suất đạt tới **1,43%**.

**Các khái niệm sức sản xuất:**

| Thuật ngữ (theo sách) | Tương ứng | Ý nghĩa |
|---|---|---|
| **Sức sản xuất sơ cấp thô** | Gross primary production (GPP) | Phần năng lượng cây xanh tích lũy vào chất hữu cơ khi quang hợp |
| **Sức sản xuất sơ cấp nguyên** | Net primary production (NPP) | = sơ cấp thô **trừ phần cây tự dùng cho hô hấp**. Đây là **năng suất riêng** của hệ sinh thái, phần **sinh vật tiêu thụ có thể dùng** |
| **Sức sản xuất thứ cấp** | Secondary production | Phần năng lượng vật tiêu thụ **giữ lại để xây dựng cơ thể** (tăng sinh khối) |

**Đường đi ở bậc tiêu thụ 1:**

- Chỉ **một phần nhỏ** sức sản xuất sơ cấp nguyên được vật tiêu thụ bậc 1 **ăn**; phần lớn **không được ăn**, đi vào vật phân hủy.
- Trong thức ăn, chỉ **một phần nhỏ được hấp thụ**; phần lớn **bị bài tiết** (phân), cũng đi vào vật phân hủy.
- Phần hấp thụ được: một phần thành **sức sản xuất thứ cấp**, phần còn lại **mất qua hô hấp**.

**Sáu phương trình năng lượng** (Giáo trình tr. 156), đọc từ trên xuống như dòng chảy:

| # | Phương trình |
|---|---|
| 1 | Năng lượng mặt trời = Năng lượng **hấp thụ** + Năng lượng **mất đi** |
| 2 | Năng lượng hấp thụ = Sức sản xuất **sơ cấp thô** + **Nhiệt phát tán** |
| 3 | Sức sản xuất sơ cấp thô = Sức sản xuất **sơ cấp nguyên** + Năng lượng **hô hấp** (của cây) |
| 4 | Sức sản xuất sơ cấp nguyên = Năng lượng **thức ăn** + Năng lượng **mất đi** (không được ăn) |
| 5 | Năng lượng thức ăn = Năng lượng **hấp thụ được** + Năng lượng trong **bài tiết** |
| 6 | Năng lượng hấp thụ được = Sức sản xuất **thứ cấp** + Năng lượng **hô hấp** (của động vật) |

> [!bay]
> - Mỗi phương trình có dạng "**phần giữ lại + phần mất**". Hãy nhớ phần mất đặc trưng từng bước: **nhiệt phát tán** (bước 2), **hô hấp của cây** (bước 3), **không được ăn** (bước 4), **bài tiết** (bước 5), **hô hấp của động vật** (bước 6).
> - Đề hay tráo: "Sức sản xuất sơ cấp **thô** = năng lượng thức ăn + năng lượng mất đi" là **sai** (phải là sơ cấp **nguyên**). "Sơ cấp thô = sơ cấp nguyên + hô hấp" là **đúng**.
> - Sơ cấp **thô** lớn hơn sơ cấp **nguyên** (vì nguyên = thô − hô hấp).
> - Hình minh họa của sách ghi hiệu suất hấp thụ "0,1; 0,2–1%", còn lời văn ghi **0,1–0,5%**. Học theo lời văn.

**Kết luận của sách:** mọi phần năng lượng tích trữ trong chất hữu cơ (của vật sản xuất, vật tiêu thụ bậc 1, 2…) khi sinh vật chết hoặc thải ra đều được **sinh vật phân hủy** sử dụng. Năng lượng mặt trời qua các bậc dinh dưỡng **lần lượt bị giáng cấp** và **không quay vòng** như vật chất.

**Tháp sinh thái và quy tắc khoảng 10%** (kiến thức nền). Nếu xếp các bậc dinh dưỡng chồng lên nhau, mỗi bậc là một tầng có độ rộng tỷ lệ với lượng của bậc đó, ta được **tháp sinh thái**. Có ba loại:

| Loại tháp | Đo cái gì | Có thể bị "lộn ngược" không? |
|---|---|---|
| Tháp **số lượng** | Số cá thể mỗi bậc | **Có**: một cây to nuôi hàng nghìn sâu |
| Tháp **sinh khối** | Khối lượng chất sống mỗi bậc | **Có**: ở biển, khối tảo nhỏ ít hơn khối động vật phù du ăn chúng, vì tảo sinh sản rất nhanh |
| Tháp **năng lượng** | Năng lượng qua mỗi bậc trong một đơn vị thời gian | **Không bao giờ**, luôn đáy rộng đỉnh hẹp |

*Vì sao tháp năng lượng luôn đứng thẳng?* Vì bậc sau chỉ nhận được năng lượng từ bậc trước, mà mỗi lần chuyển lại mất phần lớn qua hô hấp, nhiệt và chất thải. Trung bình chỉ khoảng **10%** năng lượng của một bậc chuyển lên bậc kế tiếp (thực tế dao động khoảng 5–20%). Đây là **quy tắc 10%** (Lindeman).

![Hình 3. Chuỗi thức ăn và tháp năng lượng theo quy tắc khoảng 10% (số liệu quy ước)](thap-nang-luong.svg)

> [!vi-du] Vì sao chuỗi thức ăn thường chỉ có 4–5 mắt xích?
> Với quy tắc 10%: từ 10 000 kcal ở cỏ, đến **vật tiêu thụ bậc 3** chỉ còn khoảng 10 kcal, đến vật tiêu thụ bậc 5 còn 0,1 kcal. Không đủ năng lượng nuôi thêm một quần thể ở bậc cao hơn. Cũng vì vậy, cùng một diện tích đất, **ăn thực vật trực tiếp** nuôi được nhiều người hơn so với dùng thực vật nuôi gia súc rồi ăn thịt; và các loài **săn mồi đầu bảng** (hổ, đại bàng) luôn ít, cần lãnh thổ rộng, nên rất dễ tuyệt chủng khi rừng bị chia cắt.

> [!yhct] Cây thuốc trong lưới thức ăn: bảo tồn nguồn dược liệu tự nhiên
> Cây thuốc mọc hoang là **sinh vật sản xuất** của hệ sinh thái rừng. Khi khai thác cả rễ, củ một cách tận diệt, ta không chỉ mất một loài thuốc mà còn làm nghèo lưới thức ăn quanh nó. Nhiều dược liệu của Việt Nam đã có tên trong **Sách Đỏ Việt Nam** vì bị khai thác quá mức và mất nơi sống, ví dụ **Sâm Ngọc Linh**, **Hoàng liên chân gà**, **Bảy lá một hoa**. Hướng bền vững là **trồng** dược liệu theo thực hành tốt (GACP), chỉ thu hái tự nhiên có kiểm soát, để lại cây mẹ và giữ rừng là nơi sống của chúng.
> Liên hệ với vòng nitơ: nhiều vị thuốc thuộc **họ Đậu** (Cam thảo, Hoàng kỳ, Cát căn) có **nốt sần cố định đạm**, nên trồng xen hoặc luân canh có thể giúp cải tạo đất. Mức độ lợi ích cụ thể tùy loài và điều kiện canh tác.

## 3. El Nino, La Nina và hậu quả của chúng

### 3.1. Khái niệm

- **El Nino:** từ lâu ngư dân **Peru** và **Ecuador** đã thấy nước biển ven bờ Nam Mỹ có những đợt **nóng lên bất thường**, kèm mưa to, gió lớn, lũ lụt gây thiệt hại lớn. Hiện tượng hay xảy ra vào dịp **lễ Giáng sinh**, nên được gọi là **El Nino**, tiếng Tây Ban Nha nghĩa là "**cậu bé**", ám chỉ **Chúa Hài đồng** (Giáo trình tr. 156).
- **Nguyên nhân bước đầu** được làm rõ từ **những năm 1960**: một **dòng hải lưu nóng** lan từ vùng xích đạo, từ bờ biển Nam Mỹ tới quần đảo giữa Thái Bình Dương, làm vùng biển này **nóng lên bất thường**.
- **La Nina** ("**bé gái**"), còn gọi là **anti El Nino**: hiện tượng ngược lại, nước biển vùng này **lạnh đi**.
- Cả hai là **hiện tượng khí hậu tự nhiên**, lặp lại trung bình **3–4 năm** một lần, dài nhất **8–11 năm**. Đến nay vẫn còn **nhiều điều chưa giải thích hết** (Giáo trình tr. 157).

### 3.2. Cơ chế gây biến động thời tiết

Khi El Nino xuất hiện:

1. Một **lượng nhiệt khổng lồ** tập trung trên vùng biển rộng hàng triệu km^2^ ở **Đông Thái Bình Dương**. Theo sách, nhiệt độ nước biển vành đai xích đạo tăng hơn trung bình năm **3–5°C**, có khi **6–7°C** hoặc hơn.
2. Nước nóng → không khí phía trên nóng, bốc lên → vùng này thành **vùng áp thấp**.
3. Không khí ẩm từ các vùng **áp cao** xung quanh **hội tụ** về đây, bốc lên cao, gặp lạnh → **mưa nhiều** ở vùng này (**Tây bán cầu**).
4. Các vùng khác bị "hút" mất không khí ẩm → **không mưa** → khô hạn.
5. Một "trung tâm hút khí" lớn như vậy làm **đảo lộn hoàn lưu khí quyển toàn cầu**, phá vỡ hình thế thời tiết bình thường ở nhiều nơi.

Khi **La Nina**, nước biển lạnh đi nên biến động thời tiết **ngược lại** El Nino.

### 3.3. Hậu quả

| | **Đông bán cầu** (phần lớn châu Á, có **Đông Nam Á**; châu Phi; châu Úc) | **Tây bán cầu** (phía Bắc và ven Thái Bình Dương của Nam Mỹ; theo sách gồm cả Trung và Đông Âu; các đảo giữa và Đông Thái Bình Dương) |
|---|---|---|
| **Năm El Nino** | **Ít bão, mưa ít**, **khô hạn gay gắt** | **Nhiều bão, mưa nhiều**, **lũ lụt** nghiêm trọng |
| **Năm La Nina** | **Mưa bão, lũ lụt** | **Khô hạn** gay gắt |

**Ví dụ El Nino 1997–1998** (Giáo trình tr. 158): bắt đầu khoảng tháng 3–4/1997, khi nước biển xích đạo phía Đông và giữa Thái Bình Dương nóng lên. Đợt này phát triển **rất nhanh**: chỉ trong **7–8 tháng** đã đạt cường độ mà đợt **1982–1983** mất **một năm** mới đạt tới. Đông Nam Á là một trong các vùng thiệt hại nặng nhất: **hạn hán, cháy rừng** ở Indonesia, Úc, Philippin, Malaysia, Thái Lan…, kèm **ô nhiễm môi trường** nặng (khói mù).

> [!bay]
> - Với Việt Nam (Đông bán cầu): **El Nino → hạn hán**, **La Nina → mưa bão, lũ lụt**. Đừng nhầm "El Nino = nóng nước biển" thành "El Nino = mưa nhiều ở nước ta": mưa nhiều xảy ra ở **bên kia** Thái Bình Dương.
> - Nhớ tên: El Nino = **bé trai** (nóng), La Nina = **bé gái** (lạnh).

### 3.4. Cách xác định: chỉ số SOI và SST

| Chỉ số | Là gì | El Nino | La Nina |
|---|---|---|---|
| **SOI** (chỉ số dao động Nam, Southern Oscillation Index) | Chênh lệch **khí áp** giữa **Tahiti** (giữa Thái Bình Dương) và **Darwin** (Bắc Úc) | **Âm** (−) | **Dương** (+) |
| **Chuẩn sai SST** (sea surface temperature) | Độ lệch **nhiệt độ mặt nước biển** so với trung bình, vùng xích đạo Đông Thái Bình Dương | **Dương** (+) | **Âm** (−) |

**Giá trị tuyệt đối** của SOI và SST càng lớn thì hiện tượng càng **mạnh** (Giáo trình tr. 158).

> [!bay]
> El Nino = **SOI âm, SST dương**. Mẹo: El Nino làm nước **nóng** nên SST phải **dương**; SOI luôn **ngược dấu** với SST. Một đáp án nhiễu hay gặp là "El Nino liên quan SOI (+) và SST (−)": đó là **La Nina**.

### 3.5. Giả thuyết về nguyên nhân (theo giáo trình)

Sách cho rằng đây là vấn đề **khó, chưa có lời giải thích thỏa đáng**, và nêu hai tác động **ngược chiều** của ô nhiễm không khí lên khí hậu:

| Hiệu ứng | Cơ chế | Kết quả |
|---|---|---|
| **"Làm lạnh khí hậu"** | Hạt bụi nhỏ trong không khí tăng → **giảm bức xạ mặt trời** tới mặt đất | Hạ nhiệt độ |
| **"Nhà kính"** | CO~2~ (từ công nghiệp, giao thông) tăng → **giữ lại tia hồng ngoại** từ mặt đất | Tăng nhiệt độ |

Theo sách, chưa thống nhất hiệu ứng nào thắng thế, nhưng chắc chắn sự tác động qua lại giữa hai hiệu ứng làm khí hậu vùng và toàn cầu **khó dự báo hơn**.

> [!cap-nhat] El Nino là dao động tự nhiên của hệ đại dương – khí quyển
> Giáo trình gắn nguyên nhân El Nino với ô nhiễm không khí. Hiện nay:
> - El Nino – La Nina được xem là hai pha của một **dao động tự nhiên** giữa đại dương và khí quyển gọi là **ENSO** (El Nino – Southern Oscillation). Dấu vết ENSO có từ hàng nghìn năm trước khi có công nghiệp. Cốt lõi là **gió mậu dịch** (thổi từ đông sang tây dọc xích đạo) **yếu đi**, nước ấm vốn bị dồn về phía tây Thái Bình Dương tràn ngược về phía đông; nước ấm lại làm gió yếu thêm (vòng tự khuếch đại).
> - Cơ quan khí tượng (như NOAA) công nhận El Nino khi **chuẩn sai SST vùng Niño-3.4 (xích đạo trung tâm – đông Thái Bình Dương) ≥ +0,5°C** trong 5 thời đoạn 3 tháng trượt liên tiếp; La Nina khi ≤ −0,5°C. Từ đầu năm 2026, NOAA chuyển sang **chỉ số ONI tương đối (RONI)**: lấy chuẩn sai Niño-3.4 **trừ đi chuẩn sai trung bình của cả vành đai nhiệt đới**, để tách El Nino khỏi sự ấm lên chung của đại dương; ngưỡng ±0,5°C giữ nguyên (NOAA CPC, 2026). Các đợt rất mạnh có chuẩn sai Niño-3.4 khoảng +2 đến +3°C (mức tăng 3–7°C mà sách nêu chỉ gần với vùng nước sát bờ Nam Mỹ trong các đợt rất mạnh, không phải trung bình cả vành đai xích đạo).
> - Các đợt gần đây: El Nino **2023–2024** góp phần làm 2023 và 2024 thành hai năm nóng kỷ lục; La Nina yếu 2024–2025. Tình trạng ENSO thay đổi theo tháng: xem bản tin *ENSO Diagnostic Discussion* do NOAA CPC cập nhật **hằng tháng** (khoảng ngày 10). Với Việt Nam, mỗi đợt El Nino là tín hiệu cần chuẩn bị cho nắng nóng, hạn hán, xâm nhập mặn ở mùa khô kế tiếp.
> - **Biến đổi khí hậu** do con người không "sinh ra" El Nino, nhưng ảnh hưởng của nó lên tần suất và cường độ ENSO vẫn đang được nghiên cứu. Một năm El Nino cộng với nền ấm lên toàn cầu thường cho **năm nóng kỷ lục**.
>
> Đi thi trả lời theo ý của sách.

> [!ung-dung] El Nino và sức khỏe cộng đồng ở Việt Nam
> - Các đợt El Nino mạnh (1997–1998, 2015–2016) gây **hạn hán và xâm nhập mặn** nặng ở đồng bằng sông Cửu Long: thiếu nước sạch, ảnh hưởng vệ sinh, an ninh lương thực.
> - Nắng nóng kéo dài làm tăng **say nắng, mất nước**, đợt cấp bệnh tim mạch, bệnh thận ở người già và người lao động ngoài trời.
> - Nhiệt độ cao và trữ nước tạm trong chum vại thuận lợi cho muỗi *Aedes*; nhiều nghiên cứu ghi nhận **sốt xuất huyết** tăng ở Đông Nam Á sau các năm El Nino. Ngành y tế dự phòng dùng dự báo ENSO để chuẩn bị trước.
> - Khói mù từ cháy rừng (như ở Indonesia năm 1997) làm tăng **bệnh hô hấp** trên diện rộng.

## Tóm tắt

| Chủ đề | Ý chính |
|---|---|
| Sinh thái học | Nghiên cứu tương tác sinh vật – môi trường (vô sinh, hữu sinh); phân ngành theo mức tổ chức (cá thể → hệ sinh thái) hoặc theo nhóm sinh vật (côn trùng, cá, loài người) |
| Sinh quyển | Khoảng không gian có sự sống: khí quyển, lục địa, đại dương + sinh vật + hệ sinh thái; đang chứa nhiều hiểm họa |
| Hệ sinh thái | Quần xã + môi trường vô sinh; sinh vật sản xuất, tiêu thụ (bậc 1, 2, 3), phân hủy; chuỗi thức ăn, lưới thức ăn |
| Chu trình sinh địa hóa | Vật chất vô cơ → hữu cơ → vô cơ; pha sinh học và pha vô sinh; 4 vòng cơ bản: C, O~2~, N~2~, P |
| Vòng C | C = 18% khối lượng chất sống; CO~2~ → quang hợp (cây xanh, tảo, vi khuẩn lưu huỳnh) → các bậc dinh dưỡng → hô hấp trả CO~2~; thiếu O~2~ → than, dầu, khí; đốt → tăng CO~2~, hiệu ứng nhà kính |
| Vòng O | Nghịch đảo vòng C; O~2~ tăng dần qua lịch sử, gần đây giảm nhẹ do đốt nhiên liệu |
| Vòng N | N~2~ 78% nhưng bền; cố định: sét (khoảng 6%), sinh học (> 60%, nốt sần họ Đậu, *Azotobacter*, *Clostridium*, vi khuẩn lam), Haber–Bosch (30%); khử amin → NH~3~ →(*Nitrosomonas*)→ NO~2~^-^ →(*Nitrobacter*)→ NO~3~^-^; phản nitrat hóa (thiếu O~2~) → N~2~; núi lửa cũng tạo N~2~ |
| Vòng S | Pha vô cơ chủ yếu ở trầm tích; SO~2~, SO~3~ → H~2~SO~3~, H~2~SO~4~ theo mưa; cây hút SO~4~^2-^ → nhóm –SH; phân hủy → H~2~S (mùi hôi); vi khuẩn quang hợp dùng H~2~S, thải S |
| Vòng P | PO~4~^3-^, HPO~4~^2-^, H~2~PO~4~^-^ → acid nucleic, phospholipid, ATP; vi khuẩn phosphat hóa; tảo → cá → chim → guano (Peru); vòng chậm nhất; dư P → bùng phát tảo |
| Dòng năng lượng | Một chiều, giáng cấp, mất dưới dạng nhiệt; cây giữ 0,1–0,5% (mía 1,43%); sơ cấp thô − hô hấp = sơ cấp nguyên (năng suất riêng); 6 phương trình; khoảng 10% chuyển lên mỗi bậc; tháp năng lượng không lộn ngược |
| El Nino / La Nina | Nước biển xích đạo Đông Thái Bình Dương nóng (El Nino, bé trai) / lạnh (La Nina, bé gái); chu kỳ 3–4 năm, dài nhất 8–11 năm; El Nino: Đông bán cầu hạn, Tây bán cầu lũ; La Nina ngược lại; El Nino: SOI âm, SST dương; ví dụ 1997–1998 |
