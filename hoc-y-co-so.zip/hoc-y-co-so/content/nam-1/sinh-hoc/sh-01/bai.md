---
title: Học thuyết tế bào. Các phương pháp nghiên cứu tế bào
thoi-gian: 25 phút
muc-tieu:
- Nêu được các mốc lịch sử và nội dung cơ bản của học thuyết tế bào (quan niệm cổ điển và hiện đại).
- Trình bày được nguyên lý, khả năng phân tách và phạm vi sử dụng của hiển vi quang học, các kính hiển vi cải biến và hiển vi điện tử.
- Trình bày được nguyên tắc của các phương pháp: làm tiêu bản (định hình, nhuộm), tự chụp hình phóng xạ, nuôi cấy tế bào, ly tâm và siêu ly tâm phân tách, vi phẫu tích, hóa học tế bào.
- Nêu được ứng dụng y học của các phương pháp nghiên cứu tế bào.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. **Hooke (1665)** đặt tên "tế bào" khi soi mô bần; **Schleiden – Schwann (1838–1839)** lập học thuyết tế bào: *mọi sinh vật đều cấu tạo từ tế bào*.
> 2. Thuyết hiện đại: mọi sinh vật gồm ≥ 1 tế bào; tế bào là **đơn vị sống nhỏ nhất**; **mọi tế bào sinh ra từ tế bào có trước**. Tế bào nào cũng có **màng sinh chất, tế bào chất, nhân (hoặc vùng chứa vật chất di truyền)**.
> 3. Kính hiển vi quang học: khả năng phân tách ε = 0,61λ / (n·sinα) ≈ **0,2 µm**, phóng đại dùng được ~**1000 lần**; soi được cả tế bào **sống** và tế bào **đã định hình**.
> 4. Kính hiển vi điện tử dùng **chùm điện tử** (bước sóng rất ngắn) → phóng đại 5–10 vạn lần, phân tách tới **2 Å**; mẫu phải rất mỏng (0,02–0,1 µm).
> 5. Các phương pháp khác: **tự chụp hình phóng xạ** (^14^C, ^35^S, ^3^H, ^32^P), **nuôi cấy tế bào** (nhiễm sắc thể, virus, vacxin, chẩn đoán trước sinh), **ly tâm/siêu ly tâm**, **vi phẫu tích**, **hóa học tế bào**.

## 1. Lược sử hình thành tế bào học — học thuyết tế bào

### 1.1. Các mốc lịch sử

Tế bào quá nhỏ để mắt thường nhìn thấy, nên lịch sử tế bào học gắn liền với lịch sử **kính hiển vi**.

| Năm | Nhà khoa học | Đóng góp |
|---|---|---|
| 1665 | **Robert Hooke** | Dùng kính tự chế phóng đại **30 lần** soi lát **mô bần** (vỏ cây sồi bần). Thấy nhiều xoang nhỏ có vách bao quanh, ông gọi là **tế bào** (cell = "phòng nhỏ"). |
| 1674 | **Antonie van Leeuwenhoek** | Kính phóng đại **270 lần**; là người đầu tiên mô tả **tế bào động vật**. |
| 1838–1839 | **Matthias Schleiden** (thực vật) và **Theodor Schwann** (động vật) | Xây dựng **học thuyết tế bào**: **mọi cơ thể sinh vật đều có cấu tạo tế bào**. |
| 1870 (theo giáo trình) | **F. Engels** | Đánh giá học thuyết tế bào là **1 trong 3 phát kiến vĩ đại** của khoa học tự nhiên thế kỷ XIX, cùng với **học thuyết tiến hóa** và **học thuyết chuyển hóa (bảo toàn) năng lượng**. |

Từ thế kỷ XIX, nhờ kính hiển vi hoàn thiện hơn, tế bào học trở thành một **khoa học thực sự**, nghiên cứu cả cấu trúc lẫn chức năng của tế bào.

> [!bay]
> - Hooke thấy **vách** của những tế bào **đã chết** (mô bần chỉ còn vách cellulose – suberin). Người mô tả tế bào **động vật** là **Leeuwenhoek**, không phải Hooke.
> - Nhớ cặp số: **Hooke – 1665 – ×30 – thực vật (bần)**; **Leeuwenhoek – 1674 – ×270 – động vật**.
> - Schleiden nghiên cứu **thực vật**, Schwann nghiên cứu **động vật**; học thuyết của hai ông mới có ý *mọi sinh vật cấu tạo từ tế bào*.

> [!cap-nhat] Ai "phát minh" kính hiển vi?
> Giáo trình gọi Robert Hooke là người sáng lập kính hiển vi quang học. Hiện nay, kính hiển vi phức (nhiều thấu kính) được xem là ra đời khoảng **cuối thế kỷ XVI** ở Hà Lan; Hooke là người **cải tiến và phổ biến** nó, đồng thời đặt ra từ "tế bào" trong sách *Micrographia* (1665). Ý *"mọi tế bào sinh ra từ tế bào có trước"* (*omnis cellula e cellula*) thường gắn với **Rudolf Virchow (1855)**, dựa nhiều vào quan sát trước đó của **Robert Remak**. Đi thi vẫn trả lời theo giáo trình.

### 1.2. Nội dung học thuyết tế bào theo quan niệm hiện đại

Ba luận điểm cơ bản:

1. **Mọi sinh vật đều gồm một hoặc nhiều tế bào.** Trong tế bào diễn ra **chuyển hóa vật chất** và tồn tại **tính di truyền**.
2. **Tế bào là sinh vật sống nhỏ nhất**, là **đơn vị tổ chức cơ bản** của mọi cơ thể.
3. **Tất cả tế bào đều được sinh ra từ tế bào có trước** — không có tế bào nào tự phát sinh từ chất vô sinh.

**Vì sao tế bào là "đơn vị sống nhỏ nhất"?** Đơn vị nhỏ hơn tế bào (bào quan, phân tử ADN/DNA, protein…) khi đứng riêng **không tự chuyển hóa, không tự sinh sản** được. Virus cũng không phải tế bào: nó chỉ nhân lên được **bên trong** tế bào sống (xem mục 2.4).

### 1.3. Cấu trúc chung của mọi tế bào

Mọi tế bào đều có **3 phần cơ bản**:

| Thành phần | Vai trò chính |
|---|---|
| **Màng sinh chất** | Bao quanh, ngăn cách tế bào với môi trường, kiểm soát trao đổi chất |
| **Tế bào chất** | Nơi diễn ra phần lớn các phản ứng chuyển hóa, chứa các bào quan |
| **Nhân** hoặc **vùng nhân/nguyên liệu chứa thông tin di truyền** | Lưu giữ và truyền đạt thông tin di truyền |

Tế bào có **cấu trúc chung**, nhưng các nhóm tế bào **tiến hóa theo những hướng khác nhau**, nên cấu tạo biến đổi theo nhiều cách. Ví dụ: vi khuẩn (Prokaryota/nhân sơ) không có nhân thật, chỉ có vùng nhân chứa ADN; tế bào hồng cầu trưởng thành của người mất nhân để chứa nhiều hemoglobin hơn.

> [!bay]
> Câu "mọi tế bào đều có **nhân**" là **sai** nếu hiểu là nhân có màng bao. Giáo trình viết cẩn thận: có **nhân hoặc nguyên liệu chứa thông tin di truyền** — để bao gồm cả vi khuẩn.

## 2. Các phương pháp nghiên cứu tế bào

Hình dưới cho thấy vì sao cần nhiều loại kính: mỗi loại "nhìn" được một khoảng kích thước nhất định.

![Hình 1. Kích thước các cấu trúc sinh học (thang logarit) và giới hạn phân tách của mắt, kính hiển vi quang học, kính hiển vi điện tử](kich-thuoc.svg)

> [!ghi-nho] Đổi đơn vị
> 1 mm = 1000 µm (micromet); 1 µm = 1000 nm; 1 nm = 10 Å (angstrom). Vậy **1 Å = 0,1 nm = 10^−10^ m**.
> Đơn vị của hiển vi quang học là **micromet** (kích thước hiển vi); của hiển vi điện tử là **nanomet / angstrom** (kích thước siêu hiển vi).

### 2.1. Hiển vi quang học

#### 2.1.1. Nguyên lý

Kính hiển vi quang học phóng đại vật nhờ **hệ thấu kính thủy tinh** (vật kính, thị kính) và dùng **ánh sáng thấy được**. Độ phóng đại từ **vài trăm đến vài nghìn lần**; khả năng phân tách cũng ở mức **micromet**.

**Phóng đại khác phân tách.** Điều quan trọng không phải ảnh to bao nhiêu, mà là hai điểm gần nhau có còn được thấy **tách rời** hay không. Khoảng cách nhỏ nhất đó gọi là **khả năng phân tách** (giới hạn phân giải), ký hiệu **ε**:

=> ε = 0,61 λ / (n · sin α)

- **λ**: bước sóng ánh sáng phát ra từ mẫu vật.
- **n**: chỉ số chiết quang của môi trường giữa mẫu vật và vật kính.
- **α**: góc mở của vật kính.

**ε càng nhỏ thì kính càng tốt.** Muốn giảm ε:

- λ đã cố định bởi ánh sáng thấy được → không giảm thêm được.
- α bị giới hạn vì góc lớn gây nhiều sai lệch quang học khó sửa.
- Chỉ còn cách **tăng n**: nhỏ **dầu bách hương** (dầu soi, *immersion oil*) vào giữa mẫu và vật kính. Dầu có chiết suất **bằng chiết suất thấu kính**, nên ánh sáng đi thẳng vào vật kính, không bị khúc xạ lệch ra ngoài. n không thể cao hơn chiết suất của thấu kính.

**Số liệu cần nhớ:**

| | Giá trị |
|---|---|
| Phóng đại **lý thuyết** tối đa | **3000 lần** (thị kính 20× × thấu kính trung gian 1,5× × vật kính 100×) — thực tế không dùng vì ảnh **quá tối** |
| Phóng đại **thường dùng** | **1000 lần**, phân tách được **0,2 µm** |
| Kính nghiên cứu thật tốt | **1500 lần** |
| Đối tượng | Cả **tế bào sống** và **tế bào đã định hình** |

> [!vi-du] Tính thử ε
> Với ánh sáng xanh λ ≈ 0,5 µm, vật kính dầu có n·sinα ≈ 1,4:
> ε ≈ 0,61 × 0,5 / 1,4 ≈ **0,22 µm**. Đó là lý do con số **0,2 µm** xuất hiện ở khắp nơi — đây là giới hạn vật lý của ánh sáng thấy được, không phải do kính chưa đủ tốt.
> Tăng phóng đại quá mức mà ε không đổi thì ảnh chỉ to ra và mờ đi (gọi là "phóng đại rỗng").

> [!bay]
> - **Độ phóng đại ≠ khả năng phân tách.** Ảnh to hơn chưa chắc rõ hơn.
> - ε **tỉ lệ thuận** với λ và **tỉ lệ nghịch** với n·sinα. Tăng n (dầu soi) → ε **giảm** → kính **tốt hơn**.
> - Dầu bách hương dùng với vật kính **100×** (vật kính dầu), không nhỏ dầu cho vật kính khô 10×, 40×.

#### 2.1.2. Làm tiêu bản tế bào đã định hình và nhuộm

**Các kiểu làm tiêu bản** hay dùng: **giọt ép**, **vết bôi**, **dấu quét** (áp mô lên phiến kính), **lát cắt**. Có mẫu trên phiến kính rồi thì **định hình** và **nhuộm**.

**Định hình (cố định)** — giết **thật nhanh** tế bào để mọi cấu trúc được **giữ nguyên hình dạng như lúc sống**, không bị enzym của chính tế bào phân hủy.

- Tác nhân vật lý: **sức nóng**, **đông lạnh**.
- Hóa chất: **alcol**; muối kim loại nặng (**platin clorua, thủy ngân biclorua**); acid (**acetic, picric, cromic, formic**).
- Chọn chất và thời gian định hình tùy đối tượng và mục đích.
- Mẫu dày thì cắt thành lát mỏng **vài micromet**, rồi nhuộm.

**Vì sao phải nhuộm?** Phần lớn cấu trúc tế bào gần như **trong suốt**. Thuốc nhuộm gắn chọn lọc vào từng thành phần, tạo **độ tương phản màu** để phân biệt chúng.

| Cách phân loại thuốc nhuộm | Các nhóm |
|---|---|
| Theo **nguồn gốc** | Thực vật, động vật, tổng hợp |
| Theo **bản chất hóa học** | Acid, base, trung tính |
| Theo **số loại dùng** | Nhuộm **đơn** (1 loại); nhuộm **kép, nhuộm phức** (≥ 2 loại) |
| Theo **dung môi** | Pha trong **cồn** hoặc **nước cất** |

> [!ung-dung] Tiêu bản trong xét nghiệm hằng ngày
> - **Vết bôi/phết**: phết máu nhuộm **Giemsa** để đếm công thức bạch cầu, tìm **ký sinh trùng sốt rét**; phết dịch nhuộm **Gram** để phân loại vi khuẩn (nhuộm kép); phết **tế bào cổ tử cung (Pap smear)** tầm soát ung thư cổ tử cung.
> - **Lát cắt**: giải phẫu bệnh — mô sinh thiết được cố định (thường bằng **formol**), cắt mỏng vài µm, nhuộm **Hematoxylin – Eosin (HE)**. Hematoxylin (tính base) bắt màu **nhân** tím xanh vì nhân giàu acid nucleic; eosin (tính acid) nhuộm **bào tương** hồng.
> - **Dấu áp**: áp mặt cắt tươi của mẫu sinh thiết lên phiến kính (*touch imprint*) để soi nhanh trong lúc mổ.

#### 2.1.3. Quan sát tế bào sống

Tế bào sống phải được giữ trong **môi trường lỏng giống hoặc gần giống môi trường tự nhiên** của nó.

**Khó khăn:** nhiều bộ phận của tế bào sống có **chỉ số chiết quang gần bằng nhau**, nên dưới kính thường chúng "hòa" vào nhau, không phân biệt được. Có hai hướng giải quyết:

1. **Cải biến kính** bằng các phụ kiện → kính nền đen, đối pha, giao thoa, phân cực, huỳnh quang.
2. **Nhuộm sống**: dùng chất màu **loãng, không độc hoặc ít độc** — **đỏ trung tính, xanh janus, lục trypan, lục methyl, đỏ trypan**.

| Loại kính | Nguyên tắc | Dùng để |
|---|---|---|
| **Đối pha** | Cấu trúc có chiết suất/độ dày khác nhau làm **lệch pha** ánh sáng (chỗ chiết suất cao làm ánh sáng chậm lại). **Bản pha** đặt ở mặt phẳng tiêu cự sau vật kính, khớp với **màn chắn hình vòng của tụ quang**, biến sai lệch pha thành sai khác **biên độ (độ sáng tối)** mà mắt thấy được. | Quan sát tế bào, mô **sống** — được dùng **rộng rãi** |
| **Giao thoa** | Tương tự đối pha | Như đối pha |
| **Phân cực** | Có **kính phân cực** và **kính phân tích** | Thấy cấu trúc có tính **phân cực, sắp xếp định hướng** (giống tinh thể) |
| **Nền đen** | Tụ quang đặt khác thường: chỉ **tia tán xạ** từ vật đi vào vật kính | Vật **sáng trên nền tối** |
| **Huỳnh quang** | Đèn **thủy ngân** phát tia tím/tử ngoại; kính lọc chọn tia **bước sóng ngắn** chiếu vào mẫu; mẫu phát lại ánh sáng huỳnh quang **bước sóng dài hơn** | Định vị chất (tự phát huỳnh quang hoặc sau nhuộm huỳnh quang) |

**Hiển vi huỳnh quang** — ví dụ của giáo trình:

- **Quinacrin** và dẫn xuất: phát hiện **băng huỳnh quang trên nhiễm sắc thể** (băng Q) và **vật thể Y** trong nhân tế bào ở **gian kỳ** (dấu hiệu có nhiễm sắc thể Y).
- Đưa hợp chất huỳnh quang vào cơ thể sống để nghiên cứu cấu trúc phân tử, **vận chuyển qua màng**, vị trí **trung thể**, hoạt động của **ADN, ARN** (RNA).

> [!bay]
> - Ánh sáng huỳnh quang phát ra **luôn có bước sóng dài hơn** ánh sáng kích thích (một phần năng lượng bị mất). Kích thích bằng tím/tử ngoại → phát ra xanh lục, vàng, đỏ.
> - Kính **đối pha** không "nhuộm" mẫu; nó chỉ chuyển **lệch pha** thành **độ tương phản sáng tối**.
> - Nhuộm sống phải **loãng và ít độc**; thuốc nhuộm dùng cho tiêu bản cố định thường giết tế bào.

> [!cap-nhat] Hiển vi đối pha và đồng tiêu (bổ sung – kiến thức hiện nay)
> - Kính **đối pha** do **Frits Zernike** phát minh (giải Nobel Vật lý 1953) — lần đầu cho phép nhìn rõ tế bào sống không cần nhuộm.
> - Kính **đồng tiêu (confocal)** dùng tia laser quét từng điểm và một lỗ kim chặn ánh sáng ngoài tiêu điểm, cho **lát cắt quang học** sắc nét, dựng được ảnh **3 chiều**. Đèn thủy ngân của kính huỳnh quang nay phần lớn được thay bằng **LED hoặc laser**.

> [!ung-dung] Các kính cải biến trong lâm sàng
> - **Nền đen**: soi tìm xoắn khuẩn **giang mai** (*Treponema pallidum*) — xoắn khuẩn rất mảnh, khó nhuộm, nhưng sáng rõ trên nền đen.
> - **Đối pha**: soi **cặn nước tiểu**, đánh giá **tinh trùng** sống, theo dõi tế bào nuôi cấy.
> - **Phân cực**: phân biệt tinh thể **urat** (bệnh **gút**) với tinh thể calci pyrophosphat trong dịch khớp.
> - **Huỳnh quang**: miễn dịch huỳnh quang (xét nghiệm **kháng thể kháng nhân – ANA** trong lupus), kỹ thuật **FISH** phát hiện bất thường nhiễm sắc thể.

> [!yhct] Kính hiển vi trong kiểm nghiệm dược liệu
> Dược điển Việt Nam dùng **soi bột** và **vi phẫu** dưới kính hiển vi quang học để **xác định đúng dược liệu**, phát hiện giả mạo (dựa vào hạt tinh bột, tinh thể calci oxalat, lông che chở, mạch gỗ, sợi…). Chi tiết phương pháp, kể cả kính hiển vi phân cực và huỳnh quang tử ngoại (xem bài *Ứng dụng vật lý kỹ thuật trong y học (hiển vi, quang phổ, X-quang, MRI, phóng xạ)*, mã vl-10).

### 2.2. Hiển vi điện tử

**Nguyên lý:** tương tự kính quang học, nhưng thay ánh sáng bằng **chùm tia điện tử**, thay thấu kính thủy tinh bằng **thấu kính điện hoặc từ**. Ảnh hiện lên **màn huỳnh quang** hoặc **phim ảnh** (mắt không nhìn trực tiếp được điện tử).

**Vì sao nhìn được nhỏ hơn nhiều?** Theo công thức ε, phân tách tỉ lệ với **bước sóng**. Chùm điện tử có bước sóng **vô cùng ngắn** (ngắn hơn ánh sáng thấy hàng chục vạn lần), nên ε giảm xuống tới **angstrom**.

![Hình 2. Sơ đồ so sánh nguyên lý kính hiển vi quang học và kính hiển vi điện tử truyền qua](kinh-hien-vi.svg)

| | Hiển vi quang học | Hiển vi điện tử |
|---|---|---|
| "Nguồn sáng" | Ánh sáng thấy được | Chùm điện tử |
| Thấu kính | Thủy tinh | Điện hoặc từ |
| Phóng đại | Thường 1000, tối đa ~1500 (lý thuyết 3000) | **5 – 10 vạn lần** (theo giáo trình) |
| Phân tách | **0,2 µm** | **2 Å** (kính tốt nhất); hiệu ứng đường hầm ~**1 Å** |
| Bề dày mẫu | Vài µm | **0,02 – 0,1 µm** (càng mỏng càng tốt) |
| Tế bào sống | Xem được | Mẫu phải xử lý, đặt trong chân không → **không** xem tế bào sống |
| Ảnh hiện trên | Mắt, máy ảnh | Màn huỳnh quang, phim |

**Hiển vi điện tử quét** (SEM): bước tiến mới không chỉ ở độ phóng đại mà ở **ảnh nổi**, thấy được **chiều sâu và độ lồi lõm** của bề mặt. Loại cũ chiếu xuyên qua mẫu mỏng được gọi là **hiển vi điện tử truyền qua** (TEM).

> [!bay]
> - Mẫu cho kính điện tử phải **mỏng hơn nhiều** (0,02–0,1 µm) so với lát cắt cho kính quang học (vài µm), vì điện tử bị vật chất cản rất mạnh.
> - Muốn **thấy bề mặt 3 chiều** → kính điện tử **quét**; muốn **thấy cấu trúc bên trong** (màng, ribosom, mào ty thể) → kính điện tử **truyền qua**.

> [!cap-nhat] Hiển vi điện tử và hiển vi quang học ngày nay
> - Giáo trình ghi phóng đại 5–10 vạn lần, phân tách 1–2 Å. **Hiện nay** kính TEM hiện đại phóng đại tới **hàng triệu lần**, loại có hiệu chỉnh quang sai phân tách dưới **1 Å**. **Hiển vi điện tử đông lạnh (cryo-EM)** cho phép xác định cấu trúc 3D của protein gần mức nguyên tử (giải Nobel Hóa học 2017).
> - Kính "hiệu ứng đường hầm" mà giáo trình nhắc tới thực chất là **kính hiển vi quét xuyên hầm (STM)** — một loại kính **đầu dò quét**, không dùng chùm điện tử chiếu qua mẫu như TEM.
> - Giáo trình viết SEM kết hợp videocamera cho "hình ảnh sống". Thực tế mẫu SEM thông thường phải khử nước, phủ kim loại và đặt trong **chân không**, nên **không phải tế bào sống**. Hình ảnh tế bào sống hiện nay chủ yếu thu bằng **hiển vi quang học** (đối pha, huỳnh quang, **đồng tiêu – confocal**) kèm quay phim theo thời gian.
> - **Hiển vi huỳnh quang siêu phân giải** (Nobel Hóa học 2014: Betzig, Hell, Moerner) đã vượt "giới hạn 0,2 µm" của ánh sáng, thường đạt **vài chục nm**; các kỹ thuật mới nhất (như MINFLUX) tiến tới **vài nm**.
> - Nền tảng của hiển vi huỳnh quang tế bào sống là **protein huỳnh quang xanh GFP** (Nobel Hóa học 2008): gắn GFP vào một protein thì "thấy" protein đó di chuyển trong tế bào đang sống.
> - **Cryo-EM** không cần kết tinh protein, nay đạt độ phân giải tới **≈ 1,2 Å** với mẫu chuẩn; **cryo-ET** (chụp cắt lớp điện tử đông lạnh) chụp được bào quan, phân tử **ngay trong tế bào** (tế bào đã đông lạnh, không còn sống).
> - Đi thi: trả lời theo số liệu giáo trình.

> [!ung-dung]
> Hiển vi điện tử dùng trong chẩn đoán **bệnh cầu thận** (sinh thiết thận: thấy lắng đọng phức hợp miễn dịch, màng đáy), nhận dạng **virus** trong các vụ dịch mới, và bệnh **lông chuyển bất động** (thiếu cánh tay dynein trong sợi trục lông chuyển).

### 2.3. Tự chụp hình phóng xạ (phóng xạ tự ghi)

**Nguyên tắc:** đánh dấu một hợp chất bằng **đồng vị phóng xạ**, đưa vào tế bào; chất đó đi đến đâu theo con đường chuyển hóa của nó thì **phim ảnh** sẽ "chụp" lại vị trí đó.

**Các đồng vị thường dùng và mục đích:**

| Đồng vị | Gắn vào | Theo dõi |
|---|---|---|
| ^14^C, ^35^S | **Acid amin** | Tổng hợp **protein** |
| ^3^H (**tritium**) | **Thymin** | Tổng hợp **ADN** |
| ^3^H | **Uracyl** | Tổng hợp **ARN** |
| ^32^P | Hợp chất chứa phosphat | Giáo trình không nêu cụ thể (hay dùng đánh dấu acid nucleic) |

**Các bước:**

1. Tiêm chất phóng xạ vào cơ thể sống hoặc cho vào môi trường nuôi cấy → chất vào tế bào và nằm đúng chỗ nó được chuyển hóa.
2. Lấy mô/tế bào ra, **định hình**, cắt mảnh, đặt lên phiến kính, có thể nhuộm.
3. **Trong tối**, phủ lên tiêu bản một lớp **nhũ tương ảnh**, giữ trong tối như giữ phim.
4. Chất phóng xạ phát ra **điện tử** tác động lên **bromua bạc (AgBr)** của nhũ tương.
5. Rửa phiến kính như rửa phim. Soi kính hiển vi: thấy **hình tiêu bản** và chồng lên đó là **các vệt đen** ở chỗ có chất phóng xạ.

**Vì sao chọn thymin cho ADN, uracyl cho ARN?** Thymin chỉ có trong ADN, uracyl chỉ có trong ARN. Đánh dấu đúng base "riêng" thì vệt đen phản ánh **riêng** quá trình tổng hợp ADN hoặc ARN.

> [!bay]
> - Muốn theo dõi **tổng hợp ADN** → ^3^H-**thymin** (không phải uracyl). Tổng hợp **protein** → acid amin (amino acid) gắn ^14^C hoặc ^35^S (lưu huỳnh có trong methionin, cystein).
> - Thao tác phủ nhũ tương phải làm **trong tối**.
> - Thực tế người ta gắn ^3^H vào **nucleosid** (thymidin, uridin) để tế bào dễ hấp thu; giáo trình viết gọn là thymin, uracyl.

> [!cap-nhat] Đánh dấu không phóng xạ (bổ sung – kiến thức hiện nay)
> Ngày nay phần lớn phòng thí nghiệm thay ^3^H-thymidin bằng chất **tương tự thymidin không phóng xạ** (**BrdU, EdU**): tế bào đang tổng hợp ADN gắn chúng vào, rồi phát hiện bằng kháng thể hoặc phản ứng tạo màu huỳnh quang — an toàn hơn, nhanh hơn. Nguyên lý "đánh dấu rồi theo dấu" vẫn giữ nguyên.

> [!ung-dung]
> Cùng nguyên lý "đánh dấu bằng đồng vị rồi ghi hình" là cơ sở của **y học hạt nhân**: xạ hình tuyến giáp bằng iod phóng xạ, **PET/CT** dùng ^18^F-FDG (glucose đánh dấu) để tìm khối u — tế bào ung thư hấp thu glucose mạnh nên "sáng" lên trên ảnh.

### 2.4. Nuôi cấy tế bào

**Đối tượng nuôi được:** tế bào rời (**bạch cầu lympho**, tế bào thai bong vào **dịch ối**) và mô tách khỏi cơ thể (mô bào thai, mô da…).

**Điều kiện môi trường nhân tạo:**

- Dung dịch dinh dưỡng lỏng, đủ chất hòa tan cần cho tế bào sống và sinh sản.
- **Nhiệt độ** và **pH** thích hợp.
- Quan trọng nhất: **vô khuẩn tuyệt đối** (vi khuẩn sinh sản nhanh hơn tế bào người rất nhiều, sẽ lấn át ngay).

Tế bào nuôi cấy **vẫn sống, sinh sản** và về cơ bản **giữ được bản chất sinh học** của cá thể gốc.

**Ứng dụng (theo giáo trình):**

| Lĩnh vực | Ứng dụng |
|---|---|
| Virus học | Làm **vật chủ sống cho virus** — virus là sinh vật **ký sinh bắt buộc** trong tế bào sống |
| Công nghiệp | Sản xuất **vacxin**; **thử thuốc** trên tế bào người nuôi cấy |
| Di truyền | Phương pháp **cơ bản nhất** để xem **bộ nhiễm sắc thể** của một cá thể |
| Chẩn đoán trước sinh | Nuôi cấy **tế bào thai trong dịch ối** → xem bộ nhiễm sắc thể của thai, xét nghiệm **sản phẩm chuyển hóa, enzym** liên quan bệnh di truyền |
| Kết hợp kỹ thuật gen | Tìm ra **chính gen bệnh**, ví dụ gen bệnh **thiếu máu hồng cầu liềm** |

> [!ung-dung] Lập karyotype từ máu
> Lấy máu tĩnh mạch → nuôi cấy **lympho bào** khoảng 3 ngày với chất kích thích phân bào (**PHA**) → thêm **colchicin** để dừng tế bào ở **kỳ giữa** (lúc nhiễm sắc thể co ngắn nhất) → xử lý nhược trương, cố định, nhuộm → chụp và xếp bộ nhiễm sắc thể. Dùng chẩn đoán hội chứng **Down** (3 NST 21), **Turner** (45,X), **Klinefelter** (47,XXY)…
> Chọc **dịch ối** thường làm ở khoảng **tuần 15–20** của thai kỳ.

> [!cap-nhat] Chẩn đoán trước sinh và nuôi cấy tế bào ngày nay (bổ sung – kiến thức hiện nay)
> - **Sàng lọc** trước sinh không xâm lấn (**NIPT**): phân tích **ADN tự do của thai** (thực chất từ nhau thai) trong máu mẹ, làm được từ khoảng **tuần 10**. NIPT chỉ là **sàng lọc**; kết quả nguy cơ cao phải được **khẳng định** bằng sinh thiết gai nhau (tuần 10–13) hoặc chọc ối.
> - Bên cạnh karyotype nuôi cấy, nhiều nơi dùng **QF-PCR, FISH** (nhanh, không cần nuôi cấy) và **microarray NST (CMA)** (thấy mất/lặp đoạn nhỏ hơn giới hạn của karyotype).
> - Nuôi cấy tế bào hiện đại còn có **tế bào gốc vạn năng cảm ứng (iPSC)** — biến tế bào da trưởng thành trở lại trạng thái gốc (Yamanaka, Nobel Y học 2012) — và **organoid** ("cơ quan thu nhỏ" 3 chiều) dùng nghiên cứu bệnh, thử thuốc.

> [!yhct] Colchicin — alkaloid từ cây thuốc dùng trong nuôi cấy tế bào
> **Colchicin** (từ cây Ngót nghẻo *Gloriosa superba* và cây *Colchicum autumnale*) gắn tubulin, ngăn tạo thoi vô sắc, nên giữ tế bào nuôi cấy ở kỳ giữa. Ngót nghẻo **rất độc**, không tự dùng; nguồn gốc, cơ chế, công dụng trị gút và độc tính (xem bài *Phân chia tế bào và sự hình thành giao tử ở người*, mã sh-05).

### 2.5. Ly tâm phân tách

**Mục đích:** tách riêng **từng loại bào quan** cho thật **thuần khiết** để nghiên cứu. Gồm **2 bước**.

**Bước 1 — Nghiền tế bào (đồng nhất hóa).** Phá vỡ **màng tế bào** nhưng **không làm hại bào quan**. Muốn vậy:

- Nghiền và để lắng ở **nhiệt độ thấp** (gần **0 °C**) → enzym của tế bào (nhất là enzym tiêu hóa của lysosom) gần như ngừng hoạt động.
- Dùng môi trường lỏng **đẳng trương** → bào quan không trương lên vỡ ra hay co lại.
- Có **dung dịch đệm** → giữ pH chung và pH từng phần không đổi.
- Thêm hóa chất **bảo vệ** các chất của tế bào.
- Dụng cụ: cối nghiền hoặc máy nghiền **thủy tinh mài** quay tốc độ cao.

**Bước 2 — Làm lắng bằng máy ly tâm.** Các thành phần khác nhau chịu **lực ly tâm khác nhau** nên lắng với tốc độ khác nhau:

=> V = v × (2πN)^2^ × R / g

| Ký hiệu | Ý nghĩa |
|---|---|
| V | Tốc độ lắng khi có lực ly tâm |
| v | Tốc độ lắng tự nhiên (không ly tâm) |
| N | Số vòng/giây của máy |
| R | Bán kính máy ly tâm |
| g | Gia tốc trọng trường |

- V tăng theo **bình phương** số vòng quay: quay nhanh gấp đôi → lắng nhanh gấp 4.
- Tốc độ lắng có thể nhanh hơn tự nhiên **hàng nghìn lần**.
- Một lần ly tâm, phần lắng **chưa thuần khiết** → hòa tan phần lắng, ly tâm lại với **tốc độ lớn hơn**, lặp đến khi thuần khiết.
- Theo giáo trình, tỷ trọng các thành phần trong tế bào từ **lớn đến nhỏ**: **glycogen → sắc tố hoặc tinh thể → nhẹ nhất là dịch tế bào và chất béo**.

![Hình 3. Ly tâm phân đoạn: mỗi lần tăng tốc độ, các thành phần nhỏ, nhẹ hơn mới lắng xuống](ly-tam.svg)

> [!vi-du] Ly tâm phân đoạn trong thực tế phòng thí nghiệm
> Dịch nghiền được ly tâm **nhiều lần, mỗi lần nhanh hơn**, lấy phần nổi đem quay tiếp. Thứ tự lắng thường gặp (thành phần to, nặng lắng trước): **nhân → ty thể, lysosom, peroxysom → mảnh lưới nội sinh chất ("microsom") → ribosom**; phần nổi cuối cùng là **bào tương hòa tan**. Đây là bổ sung để hiểu nguyên lý; khi thi, câu hỏi về thứ tự tỷ trọng trả lời theo giáo trình (glycogen nặng nhất, chất béo nhẹ nhất).

> [!ung-dung]
> Ly tâm có mặt trong mọi phòng xét nghiệm: tách **huyết thanh/huyết tương** khỏi tế bào máu, đo **hematocrit**, lấy **cặn nước tiểu** để soi, tách **huyết tương giàu tiểu cầu**.

### 2.6. Siêu ly tâm phân tách

- Máy quay **cực nhanh**, tốc độ được **kiểm soát chính xác**.
- Đối tượng: các **phân tử đã đồng nhất** (không phải bào quan).
- Dùng nghiên cứu **protein, ADN, ARN**: xác định **trọng lượng phân tử**, **hình dáng** và **tách giữ** các phân tử này.

> [!vi-du]
> Tốc độ lắng của một phân tử trong siêu ly tâm được biểu thị bằng **hệ số lắng S (Svedberg)**. Vì vậy ribosom được gọi là **70S** (vi khuẩn) và **80S** (tế bào nhân thực) — con số này sẽ gặp lại ở bài tế bào chất.

> [!bay]
> **Ly tâm phân tách** → tách **bào quan**. **Siêu ly tâm** → tách **phân tử** (protein, ADN, ARN), xác định trọng lượng phân tử và hình dáng.

### 2.7. Vi phẫu tích tế bào

Làm "phẫu thuật" **ngay dưới kính hiển vi** bằng dụng cụ rất nhỏ: **tách nhân** ra khỏi tế bào hoặc **cắt tế bào** thành mảnh nhỏ để nghiên cứu.

> [!ung-dung]
> Kỹ thuật vi thao tác là nền tảng của **tiêm tinh trùng vào bào tương noãn (ICSI)** trong hỗ trợ sinh sản và **chuyển nhân** trong nhân bản vô tính.

### 2.8. Các phương pháp hóa học tế bào

- Xác định **vị trí tập trung** của các chất trong tế bào.
- Nhiều trường hợp **định lượng** được nhờ **máy quang phổ** đặc biệt.
- Dựa trên **phản ứng định tính hóa học**: mỗi loại chất dùng một thuốc thử riêng → thấy **màu đặc trưng** và **vị trí** của chất cần tìm.

> [!vi-du]
> - Phản ứng **Feulgen** nhuộm đặc hiệu **ADN** màu đỏ tím → định vị ADN trong nhân, đo lượng ADN mỗi tế bào.
> - Phản ứng **PAS** (acid periodic – Schiff) nhuộm **glycogen** và glycoprotein màu hồng đỏ.
> - Nhuộm **Sudan** cho **lipid**; phản ứng **Perls** (xanh Phổ) cho **sắt** dự trữ trong tủy xương.

### 2.9. Các phương pháp khác

- Phương pháp thông thường khác: **ủ lạnh**, nghiên cứu **sự chuyển hóa nội bào**…
- Ở mức phân tử cần các **kỹ thuật gen**: tách chiết ADN, **điện di** ADN, **lai** ADN, **tái tổ hợp** ADN, **nhân** ADN (PCR), **giải trình tự** ADN. Các kỹ thuật này học ở phần sinh học phân tử.

> [!cap-nhat] Một số phương pháp nghiên cứu tế bào hiện đại (bổ sung – kiến thức hiện nay)
> - **Đếm tế bào dòng chảy (flow cytometry)**: tế bào nhuộm kháng thể huỳnh quang chạy qua tia laser từng chiếc một → đếm và phân loại hàng nghìn tế bào/giây. Ví dụ quen thuộc: đếm **tế bào lympho T CD4** ở người nhiễm HIV, phân loại bệnh bạch cầu.
> - **Giải trình tự gen thế hệ mới** và **giải trình tự ARN đơn tế bào** (single-cell RNA-seq): biết từng tế bào riêng lẻ đang "bật" những gen nào.
> - **Chỉnh sửa gen CRISPR-Cas9** (Nobel Hóa học 2020): tắt hoặc sửa một gen trong tế bào nuôi cấy để tìm chức năng gen.

## Tóm tắt

| Phương pháp | Nguyên tắc cốt lõi | Điểm cần nhớ |
|---|---|---|
| **Hiển vi quang học** | Thấu kính thủy tinh + ánh sáng thấy | ε = 0,61λ/(n sinα); ×1000, **0,2 µm**; dầu bách hương tăng n; xem tế bào **sống và chết** |
| Tiêu bản định hình – nhuộm | Giết nhanh giữ nguyên cấu trúc → tạo màu | Giọt ép, vết bôi, dấu quét, lát cắt; thuốc nhuộm acid/base/trung tính |
| Đối pha, giao thoa | Lệch pha → sai khác sáng tối | Xem tế bào **sống** (đối pha dùng rộng rãi) |
| Phân cực | Kính phân cực + kính phân tích | Cấu trúc định hướng như tinh thể |
| Nền đen | Chỉ tia tán xạ vào vật kính | Vật sáng trên nền tối |
| Huỳnh quang | Kích thích bước sóng ngắn → phát bước sóng **dài hơn** | Quinacrin: băng NST, vật thể Y |
| **Hiển vi điện tử** | Chùm điện tử + thấu kính điện/từ | ×5–10 vạn; **2 Å**; mẫu 0,02–0,1 µm; **quét** cho ảnh nổi |
| Tự chụp hình phóng xạ | Đồng vị + nhũ tương ảnh AgBr | ^14^C, ^35^S → protein; ^3^H-thymin → ADN; ^3^H-uracyl → ARN |
| Nuôi cấy tế bào | Môi trường dinh dưỡng, nhiệt độ, pH, **vô khuẩn tuyệt đối** | Virus, vacxin, thử thuốc, **karyotype**, chẩn đoán trước sinh (dịch ối) |
| Ly tâm phân tách | Nghiền (lạnh, đẳng trương, đệm) → ly tâm | V = v(2πN)^2^R/g; tách **bào quan** |
| Siêu ly tâm | Quay cực nhanh, kiểm soát chính xác | Tách **phân tử**: protein, ADN, ARN; trọng lượng phân tử |
| Vi phẫu tích | Dụng cụ siêu nhỏ dưới kính | Tách nhân, cắt tế bào |
| Hóa học tế bào | Phản ứng màu đặc trưng (+ quang phổ) | Định vị và định lượng chất |
