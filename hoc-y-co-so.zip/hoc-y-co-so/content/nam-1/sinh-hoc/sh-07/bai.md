---
title: Di truyền học: nội dung, phương pháp nghiên cứu
thoi-gian: 35 phút
muc-tieu:
- Nêu được các mốc chính hình thành di truyền học Mendel và sau Mendel (từ 1865 đến Morgan).
- Trình bày được các mốc hình thành di truyền học phân tử (từ Miescher đến PCR và bản đồ gen người).
- Kể được các lĩnh vực (nội dung) của di truyền học và đối tượng của từng lĩnh vực.
- Trình bày được ba nhóm phương pháp nghiên cứu: tạp giao thực nghiệm, di truyền học tế bào, kỹ thuật di truyền phân tử (tách chiết ADN, giải trình tự, enzym giới hạn, tạo dòng, ADN dò, Southern blot, lai tại chỗ, PCR).
- Kể được các phương pháp dùng trong di truyền y học (phả hệ, trẻ sinh đôi, vân da, dịch tễ, lâm sàng) và đọc được ký hiệu phả hệ.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. **Mendel** công bố năm **1865**, bị lãng quên **34 năm**; năm **1900** De Vries, Correns, Tschermak tìm lại → **1900 là năm ra đời của di truyền học**.
> 2. Sau Mendel: **Boveri – Sutton (1902–1903)** gắn di truyền với NST (nhiễm sắc thể); **Johannsen (1909)** đặt từ "gen"; **Morgan (1910)**: gen xếp thẳng hàng trên NST, liên kết, trao đổi chéo, di truyền liên kết giới tính.
> 3. Di truyền phân tử: **Miescher 1869** (acid nucleic) → **Beadle – Tatum 1941** (một gen – một enzym) → **Watson – Crick** (mô hình ADN/DNA) → **Jacob – Monod 1961** (điều hòa gen) → mã di truyền (1964–1966) → **Temin 1970** (phiên mã ngược) → **Mullis 1985** (PCR) → **2001** bản đồ gen người.
> 4. Di truyền học nghiên cứu **tính di truyền và tính biến dị**, chia nhiều lĩnh vực: tế bào, phân tử, miễn dịch, **dược lý**, quần thể, đột biến, bệnh di truyền, công nghệ.
> 5. Ba nhóm phương pháp: **tạp giao thực nghiệm** (động – thực vật), **di truyền tế bào** (quan sát NST, lai tế bào soma, nhuộm băng), **di truyền phân tử** (tách ADN, giải trình tự, enzym giới hạn, tạo dòng, ADN dò, Southern blot, lai tại chỗ, PCR). Ở người không lai được → dùng **phả hệ, trẻ sinh đôi**…

## 1. Lược sử của di truyền học

Lược sử di truyền học là quá trình loài người dần hiểu ra **sự sống, tính di truyền và tính biến dị**. Trước khi thành khoa học, đã có nhiều quan niệm chưa có cơ sở.

Câu hỏi đầu tiên là: **sinh vật có biến đổi không?**

| Quan niệm | Nội dung | Ghi chú |
|---|---|---|
| **Sinh vật bất biến** | Loài được tạo ra sao thì giữ nguyên như vậy | Kéo dài từ thời thượng cổ, gắn với tôn giáo và chế độ phong kiến, tới khoảng **thế kỷ 16** |
| **Lamarck** | Sinh vật có biến đổi; lần đầu nêu có hệ thống về **tiến hóa** | Cơ sở là "**di truyền tập nhiễm**" (đặc điểm cơ thể thu được trong đời sống được truyền cho con) |
| **Darwin** — "Nguồn gốc các loài" | Sinh vật có hai đặc tính: **di truyền** và **biến dị**; có hai quá trình chọn lọc: **tự nhiên** và **nhân tạo** | Đặt nền cho tiến hóa luận hiện đại |

> [!bay]
> "Di truyền tập nhiễm" là của **Lamarck**, không phải Darwin. Ngày nay biết rằng đặc điểm cơ thể tự luyện được (ví dụ cơ bắp to vì tập) **không** truyền qua gen cho con.

### 1.1. Di truyền học Mendel và sau Mendel

Từ xa xưa con người đã biết **chọn giống, thuần hóa, lai giống** cây trồng và vật nuôi. Nhưng chưa ai giải thích được vì sao con giống bố mẹ, thậm chí có những cách giải thích sai. Những hiểu biết về tế bào học và phôi thai học (sách ghi từ thế kỷ 17, khi kính hiển vi ra đời) dần tạo nền móng. Tuy vậy, di truyền học chỉ thực sự bắt đầu từ công trình của **Mendel**.

**Mendel (1865).** Ông làm thí nghiệm lai rất công phu (trên đậu Hà Lan) và báo cáo năm **1865**. Ông thấy mỗi tính trạng do một **"nhân tố di truyền"** chi phối, chính là cái mà ngày nay gọi là **gen**. Cả kết quả lẫn phương pháp của ông đến nay vẫn còn nguyên giá trị. Nhưng lúc đó giới khoa học không chú ý.

**Năm 1900: "tìm lại" Mendel.** Sau **34 năm** bị bỏ quên, năm 1900 ba nhà khoa học ở **ba nước khác nhau**, làm trên **các đối tượng khác nhau**, cùng công bố kết quả giống Mendel: **De Vries, Correns, Tschermak**.

- *Vì sao lúc này người ta mới hiểu Mendel?* Vì cùng thời gian đó đã có những phát hiện về **phân chia tế bào, tạo giao tử, thụ tinh, phát triển phôi**. Khi đã thấy NST chia đều cho giao tử, "nhân tố" của Mendel mới có chỗ đứng vật chất để hình dung.
- Vì vậy **năm 1900** được coi là năm **chính thức hình thành di truyền học**. Các định luật cơ bản mang tên Mendel, được áp dụng cho thực vật, động vật và người.

**Các mốc sau Mendel:**

| Năm | Tác giả | Đóng góp |
|---|---|---|
| 1902 | **Boveri** | Số lượng NST được duy trì ổn định trong loài; NST có vai trò trong di truyền |
| 1903 | **Boveri và Sutton** | Xác định vai trò của NST trong việc truyền đặc tính qua các thế hệ (thuyết di truyền NST) |
| 1909 | **Johannsen** | Đề nghị dùng từ **"gen"** để gọi nhân tố di truyền |
| 1910 | **Morgan** và cộng sự (trên **ruồi giấm**) | Gen **xếp thành hàng dọc** trên NST, tạo **nhóm liên kết**; phát hiện **di truyền liên kết giới tính** và **trao đổi chéo** khi tạo giao tử |

Kết luận của giai đoạn này: "nhân tố di truyền" của Mendel chính là **gen nằm trên NST**, chi phối các tính trạng. Câu hỏi tiếp theo là gen **có cấu trúc thế nào** và **hoạt động ra sao**. Đó là việc của di truyền học phân tử.

> [!bay]
> - Mendel **công bố 1865**, nhưng di truyền học **ra đời năm 1900** (năm tìm lại định luật). Đề hay hỏi "năm hình thành di truyền học" → **1900**.
> - Người đặt **từ "gen"** là **Johannsen (1909)**, không phải Mendel (Mendel gọi là "nhân tố") và không phải Morgan.
> - Ba người tìm lại Mendel: **De Vries – Correns – Tschermak**. Boveri, Sutton, Morgan là người **sau** năm 1900.

### 1.2. Hình thành di truyền học phân tử

#### 1.2.1. Phát hiện acid nucleic

- **Miescher (1869)** phát hiện acid nucleic trong nhân tế bào. Về sau xác định thành phần ADN gồm: **đường 5 carbon, base và acid phosphoric**.
- Acid nucleic có trong nhân tế bào của **mọi loài sinh vật**.
- Từ đầu thế kỷ XX, các thí nghiệm cho thấy vật chất di truyền ở mức phân tử của **đa số loài là ADN**, còn **một số virus là ARN** (RNA). (Các thí nghiệm chứng minh vai trò của acid nucleic — Griffith, Avery, Hershey – Chase — được học ở bài *Cơ sở phân tử của hiện tượng di truyền*.)

#### 1.2.2. ADN truyền thông tin như thế nào?

| Năm | Tác giả | Đóng góp |
|---|---|---|
| 1941 | **Beadle và Tatum** (nấm mốc *Neurospora*) | Sơ đồ **"một gen → một enzym"**: gen chi phối tổng hợp protein (enzym) |
| 1953 | **Watson và Crick** | **Mô hình cấu trúc không gian** (chuỗi xoắn kép) của ADN, giải thích hai chức năng: **tự nhân đôi** và **phiên mã** |
| 1961 | **Jacob và Monod** | Cơ chế **điều hòa hoạt động gen** ở vi khuẩn |
| 1962 | **Arber** | Nhận ra sự có mặt của **enzym giới hạn** (enzym cắt), công cụ để "mổ xẻ" ADN |
| 1964 | **Nirenberg và Leder** | Đề ra phương pháp **xác định mã** của các acid amin (amino acid) |
| 1966 | **Nirenberg, Ochoa, Khorana** | Xác định được **mã bộ ba của tất cả acid amin** |
| 1968, 1972 | **Khorana** | **Tổng hợp gen nhân tạo** |
| 1969 | **Beckwith** | **Chiết tách được gen** từ vi khuẩn *E. coli* |
| 1970 | **Temin** và cộng sự | Chứng minh có **thông tin ngược ARN → ADN** ở virus chứa ARN (**phiên mã ngược**) |
| 1985 | **Mullis** | Công bố **PCR** (phản ứng chuỗi polymerase), nhân một đoạn ADN *in vitro* |
| 12/2/2001 | (Tạp chí *Nature*) | Công bố **bản đồ gen người**, hầu hết trình tự đã được giải mã |

Năm 1953 sách không ghi; đây là năm Watson và Crick công bố mô hình. Mô hình này dựa nhiều vào ảnh nhiễu xạ tia X của **Rosalind Franklin** (và Wilkins); Watson, Crick, Wilkins nhận giải Nobel năm 1962, khi Franklin đã mất. Về phiên mã ngược, năm 1970 **Temin** và **Baltimore** phát hiện độc lập (Nobel 1975).

**Vì sao phiên mã ngược quan trọng?** Trước đó, người ta tin dòng thông tin chỉ đi một chiều ADN → ARN → protein. Temin cho thấy ở virus ARN có cả chiều **ARN → ADN**. Vậy bên cạnh **phiên mã xuôi** (ADN → ARN) còn có **phiên mã ngược** (ARN → ADN).

> [!ung-dung] Phiên mã ngược trong y học
> - **HIV** là virus ARN dùng enzym **phiên mã ngược** (reverse transcriptase) để chép bộ gen của nó thành ADN rồi cài vào ADN người. Nhiều thuốc điều trị HIV (zidovudin, tenofovir, efavirenz…) là **thuốc ức chế enzym phiên mã ngược**.
> - Trong phòng xét nghiệm, enzym này dùng để chép ARN thành ADN rồi mới làm PCR: đó là **RT-PCR**, kỹ thuật xét nghiệm virus ARN (như SARS-CoV-2, HCV).

> [!bay]
> - "Một gen – một enzym" là của **Beadle và Tatum** trên **nấm Neurospora**, không phải trên vi khuẩn. Năm 1941 người ta chưa chứng minh được gen là ADN; hai ông làm việc với **gen đột biến** của nấm. Giáo trình viết "vai trò của ADN ở Neurospora", hiểu là vai trò của gen.
> - Điều hòa gen (operon) là **Jacob – Monod**, trên **vi khuẩn**.
> - PCR: **Mullis, 1985**. Southern blot: **Southern, 1975**. Enzym giới hạn: **Arber, 1962**.

> [!cap-nhat] Bản đồ gen người: 2001, 2003, 2022 và pangenome 2023 (bổ sung – kiến thức hiện nay)
> Giáo trình ghi: ngày 12/2/2001 *Nature* công bố bản đồ gen người với hầu hết trình tự đã giải mã.
> Hiện nay:
> - Tháng 2/2001 là **bản nháp** (draft): ngày 12/2 là ngày công bố với báo chí; bài đăng trên *Nature* (Dự án hệ gen người, nhà nước) và *Science* (công ty Celera) ra vài ngày sau. Bản nháp còn nhiều khoảng trống.
> - **Năm 2003**, **Dự án hệ gen người** (Human Genome Project) tuyên bố **hoàn thành**, phủ khoảng 99% vùng chất nhiễm sắc thực (euchromatin, nơi chứa hầu hết gen) nhưng vẫn còn những đoạn lặp lại (tâm động, đầu mút…) chưa đọc được.
> - **Năm 2022**, nhóm **T2T** (Telomere-to-Telomere, "từ đầu mút đến đầu mút") công bố trình tự **liền mạch, không còn khoảng trống** của 22 NST thường và NST X, khoảng **3,05 tỷ cặp base**; NST **Y** được hoàn tất năm **2023**.
> - NST Y hoàn chỉnh (khoảng **62,5 triệu cặp base**) được công bố trên *Nature* tháng 8/2023, bổ sung hơn 30 triệu cặp base chưa từng đọc được.
> - **Bộ gen tham chiếu đa dạng (pangenome)**: một bộ gen tham chiếu chỉ là "một người", không đại diện được mọi dân tộc. Tháng 5/2023, Liên minh Pangenome người công bố **bản nháp pangenome** gồm bộ gen của **47 người** nhiều tổ tiên khác nhau, thêm hơn **100 triệu base** mới so với bản tham chiếu cũ. Điều này giúp tìm biến thể gây bệnh chính xác hơn ở các dân tộc ít được nghiên cứu (như người châu Á).
> - Người chỉ có khoảng **19.000–20.000 gen mã hóa protein** (ít hơn nhiều so với dự đoán cũ, có lúc tới 100.000). Phần mã hóa protein chỉ chiếm khoảng **1–2%** bộ gen.
> (Nguồn: Nurk et al., *Science* 2022; Rhie et al., *Nature* 2023; Liao et al., *Nature* 2023; NHGRI.) Đi thi, nếu hỏi theo sách, trả lời mốc **2001**.

## 2. Nội dung của di truyền học

Sinh vật có hai thuộc tính riêng: **tính di truyền** (con giống bố mẹ) và **tính biến dị** (con khác bố mẹ, khác nhau). Di truyền học nghiên cứu hai thuộc tính này ở nhiều đối tượng và ứng dụng vào đời sống:

- cải tạo giống cũ, tạo **giống mới** năng suất cao cho chăn nuôi, trồng trọt;
- tạo **chế phẩm sinh học** bằng công nghệ sinh học;
- **bảo vệ sức khỏe** con người, thực hiện **ưu sinh** (cải thiện chất lượng nòi giống).

**Theo đối tượng**, có: di truyền học người, di truyền học y học, di truyền học vi khuẩn, động vật, thực vật…

Để nghiên cứu, di truyền học kết hợp với các môn khoa học khác, hình thành các **lĩnh vực** sau (sách liệt kê 8 lĩnh vực):

| Lĩnh vực | Nghiên cứu cái gì | Điểm cần nhớ |
|---|---|---|
| **Di truyền học tế bào** | Vật chất di truyền ở mức **tế bào**, nhất là **NST** | Flemming (1882) nghiên cứu chất nhiễm sắc và NST; đột biến NST; kỹ thuật **nhuộm băng** từ những năm 1970; chất nhiễm sắc giới tính ở nhân gian kỳ |
| **Di truyền học phân tử** | Cấu tạo, hoạt động của vật chất di truyền ở mức **phân tử, phản ứng hóa học** | Trọng tâm là **gen**; giải thích rối loạn chuyển hóa bẩm sinh; nền cho kỹ thuật di truyền; genomics và proteomics |
| **Di truyền học miễn dịch** | Quy luật di truyền **nhóm máu, kháng nguyên, kháng thể** | **Cơ sở của ghép mô, ghép cơ quan**; cơ chế sinh kháng thể, tính kháng nhiễm, thể tạng |
| **Di truyền học dược lý** | Sự tổng hợp, hoạt động của **enzym chuyển hóa thuốc** | Chuyển hóa thuốc bình thường và bất thường; tác động của **dược liệu, thuốc, chế phẩm sinh học** lên vật liệu di truyền |
| **Di truyền học quần thể** | Quy luật di truyền các đặc điểm của **quần thể** | Xác định **tần số gen, tần số kiểu gen, tần số kiểu hình**; tìm nguyên nhân làm tần số gen thay đổi |
| **Nghiên cứu đột biến** | Tác nhân gây đột biến (**mutagen**) và hậu quả | Đột biến mức NST hay mức gen, ở tế bào **sinh dưỡng** hay **sinh dục**; chia theo tác nhân: **phóng xạ, hóa chất, sinh học** (virus, vi khuẩn…) |
| **Bệnh di truyền** | Nguyên nhân, chẩn đoán, phòng và chữa bệnh tật di truyền | Mọi bệnh di truyền đều là **hậu quả của đột biến**; mọi mô, cơ quan đều có thể mắc; **tế bào ung thư** được coi là tế bào đột biến |
| **Di truyền học công nghệ** | Ứng dụng di truyền và kỹ thuật để **sản xuất chế phẩm sinh học** | Vacxin thế hệ mới, hormon, chất kích thích sinh trưởng; **vi khuẩn sản xuất insulin**, ovalbumin, vacxin ở quy mô công nghiệp |

### 2.1. Di truyền học tế bào và di truyền học phân tử

- **Tế bào:** "nhìn thấy" vật chất di truyền dưới kính hiển vi, chủ yếu là **NST**. Số lượng và hình thái NST của rất nhiều loài đã được xác định. Kỹ thuật **nhuộm băng** (từ những năm 1970) làm trước tiên trên NST người, rồi ở gia súc, gia cầm, chuột, ruồi giấm.
- **Phân tử:** đi vào cấu tạo hóa học và hoạt động của **gen**. Từ mô hình Watson – Crick, lĩnh vực này tiến rất nhanh. Thành công khi giải mã bộ gen người thúc đẩy nghiên cứu **hệ protein** (proteome). Hai hướng **genomics** (nghiên cứu bộ gen) và **proteomics** (nghiên cứu hệ protein) hỗ trợ nhau.

*Vì sao cần cả proteomics?* Gen chỉ là "bản thiết kế"; chức năng thật trong tế bào do protein đảm nhận. Biết đủ gen chưa đủ để biết tế bào đang làm gì, phải xem protein nào đang được tạo ra.

### 2.2. Di truyền học miễn dịch và di truyền học dược lý

**Miễn dịch:** nhóm máu, kháng nguyên, kháng thể được di truyền theo quy luật. Đây là **cơ sở của ghép**: người cho và người nhận càng giống nhau về kháng nguyên thì cơ thể càng ít thải ghép.

**Dược lý:** cùng một liều thuốc, người này chuyển hóa nhanh, người kia chậm, vì **gen quy định enzym chuyển hóa thuốc** khác nhau.

> [!ung-dung] Di truyền dược lý trong lâm sàng (có bổ sung – kiến thức hiện nay)
> - **Thiếu enzym G6PD** (di truyền liên kết X): dùng **primaquin**, sulfonamid, hoặc ăn **đậu tằm** có thể gây **tan máu** cấp.
> - **Kiểu "acetyl hóa chậm"** (gen *NAT2*): người acetyl hóa chậm dùng **isoniazid** (thuốc lao) dễ bị độc thần kinh ngoại biên và độc gan hơn.
> - **Alen HLA-B\*15:02** (gặp nhiều ở người Đông Nam Á và Nam Trung Quốc): người mang alen này dùng **carbamazepin** có nguy cơ cao bị hội chứng **Stevens – Johnson / hoại tử thượng bì nhiễm độc** (SJS/TEN), phản ứng da – niêm mạc nặng, có thể tử vong. Từ năm 2007, FDA Hoa Kỳ đóng **khung cảnh báo** trên nhãn thuốc: người có **tổ tiên châu Á** nên **xét nghiệm HLA-B\*15:02 trước khi dùng** carbamazepin; dương tính thì tránh dùng trừ khi lợi ích vượt trội. Ở người Việt, các nghiên cứu cho tần số alen khoảng **12–15%** (cao hơn ở một số nhóm bệnh nhân), và người mang alen có nguy cơ SJS cao hơn khoảng **12–13 lần** (Frontiers in Pharmacology, 2023). Vì vậy xét nghiệm này **rất đáng làm ở người Việt**.
> - **CYP2C9 và VKORC1 với warfarin** (thuốc chống đông): *CYP2C9* quy định enzym thải warfarin, *VKORC1* quy định đích tác dụng của thuốc. Hai gen này giải thích khoảng **30–35%** sự khác nhau về liều giữa các người; người châu Á thường mang biến thể *VKORC1* làm giảm đích tác dụng nên **cần liều thấp hơn** người châu Âu. FDA đưa thông tin hai gen này vào nhãn warfarin năm 2007 và bảng liều theo kiểu gen năm 2010 (ADLM, 2011).
> - Đây đúng là "tình trạng **không bình thường** của quá trình chuyển hóa thuốc" mà giáo trình nhắc tới. Ngày nay lĩnh vực này gọi là **dược lý di truyền (pharmacogenomics)**, mục tiêu là "đúng thuốc, đúng liều theo kiểu gen".

> [!yhct] Dược liệu cũng có thể tác động lên vật liệu di truyền
> Ví dụ rõ nhất cho ý "tác động của dược liệu lên vật liệu di truyền" của giáo trình là **acid aristolochic** trong một số cây chi *Aristolochia* (như Quảng phòng kỷ, Quan mộc thông): chất gây đột biến ADN, độc thận và gây ung thư đường tiết niệu đã được xác định trên người (xem bài *Đột biến*, mã sh-10).

### 2.3. Di truyền học quần thể, đột biến và bệnh di truyền

- **Quần thể:** không nhìn một cá thể mà nhìn cả cộng đồng. Ví dụ: trong một vùng, bao nhiêu phần trăm người mang gen bệnh tan máu bẩm sinh. Các con số này là **tần số gen, tần số kiểu gen, tần số kiểu hình**.
- **Đột biến:** tìm các **tác nhân gây đột biến (mutagen)** và hậu quả. Phân loại theo tác nhân: **phóng xạ, hóa chất, sinh học** (virus, vi khuẩn…). Đột biến ở tế bào **sinh dục** có thể truyền cho đời sau; ở tế bào **sinh dưỡng** thì chỉ ảnh hưởng chính cơ thể đó.
- **Bệnh di truyền:** đều bắt nguồn từ **đột biến** (mức NST hoặc mức gen). Tế bào **ung thư** được coi là tế bào đột biến: bộ máy di truyền rối loạn nên nó chuyển từ sinh sản bình thường sang **sinh sản hỗn loạn**.

### 2.4. Di truyền học công nghệ

Dùng hiểu biết di truyền và kỹ thuật để sản xuất **chế phẩm sinh học** nhanh hơn, quy mô lớn hơn: vacxin thế hệ mới, hormon, chất kích thích sinh trưởng. Bằng cách **chiết tách và ghép gen**, người ta tạo ra **vi khuẩn sản xuất insulin**, ovalbumin, vacxin ở quy mô công nghiệp.

> [!vi-du] Vì sao vi khuẩn làm ra được insulin người?
> Mã di truyền gần như **chung cho mọi sinh vật**. Gắn gen insulin người vào ADN vi khuẩn (mục 3.3), vi khuẩn sẽ "đọc" gen đó như gen của chính nó và làm ra insulin người. Insulin người tái tổ hợp được dùng làm thuốc từ đầu những năm 1980, thay cho insulin chiết từ tụy bò, tụy lợn (dễ gây dị ứng hơn).

> [!cap-nhat] Chỉnh sửa gen CRISPR và Casgevy (bổ sung – kiến thức hiện nay)
> Giáo trình (2008) chưa nói tới **CRISPR-Cas9** (công bố năm 2012), công cụ cắt ADN chính xác tại vị trí mong muốn: một **ARN dẫn đường** tìm đúng trình tự bổ sung, enzym **Cas9** cắt đứt hai mạch ADN tại đó. Charpentier và Doudna nhận **giải Nobel Hóa học 2020** cho phát minh này.
> - Liệu pháp đầu tiên dùng CRISPR là **exa-cel (Casgevy)**: được Anh (MHRA) cấp phép tháng 11/2023; FDA Hoa Kỳ cấp phép ngày **8/12/2023** cho **bệnh hồng cầu hình liềm** và ngày **16/1/2024** cho **β-thalassemia phụ thuộc truyền máu**.
> - Cách làm: lấy **tế bào gốc tạo máu** của chính người bệnh, dùng CRISPR cắt hỏng một đoạn điều hòa của gen *BCL11A* (gen vốn "tắt" huyết sắc tố bào thai HbF), rồi truyền trả lại. Hồng cầu mới lại tạo nhiều **HbF**, bù cho β-globin hỏng. Đây là chỉnh sửa **tế bào soma**, không truyền cho con.
> - Liên hệ: thalassemia rất phổ biến ở Việt Nam, nên đây là hướng điều trị đáng theo dõi, dù hiện giá rất cao (nguồn: Nobel Prize 2020; FDA 2023–2024).

## 3. Phương pháp nghiên cứu

### 3.1. Phương pháp tạp giao thực nghiệm

Đây là phương pháp **kinh điển** (của Mendel) và đến nay vẫn là phương pháp **chủ yếu ở động vật, thực vật**.

**Cách làm:** cho hai loài hoặc hai chủng giao phối với nhau, rồi theo dõi tính trạng qua các thế hệ con. Hai mẫu đem lai phải có **một hoặc vài tính trạng đối lập** để dễ theo dõi. Ví dụ: đậu thân cao × đậu thân thấp; chuột lông xám × chuột lông trắng.

**Bốn điều kiện của sinh vật mẫu:**
1. **Chu kỳ sống ngắn**;
2. **Sinh được nhiều** thế hệ con (đông con);
3. **Nhiều biến dị**;
4. **Dễ nuôi, dễ duy trì**.

*Vì sao?* Muốn thấy quy luật, phải đếm được nhiều con (thống kê) qua nhiều thế hệ trong thời gian ngắn.

| Sinh vật mẫu | Đặc điểm theo sách |
|---|---|
| **Ruồi giấm** (*Drosophila*) | **10–15 ngày** một thế hệ |
| **Chuột nhắt trắng** (*Mus musculus*) | **2,5 tháng** một thế hệ |
| **Nấm *Neurospora crassa*** | Đời sống rất ngắn; dùng nghiên cứu **hoạt động của gen** |
| **Vi khuẩn, virus** | Gần đây dùng nhiều |
| **Lúa mạch, ngô** | Thực vật bậc cao được nghiên cứu rộng rãi |

> [!bay]
> Tạp giao thực nghiệm **không dùng được ở người** (không thể cho người "lai" theo ý muốn, và một thế hệ người mất 20–30 năm, đông con thì ít). Vì vậy di truyền người phải dùng phương pháp riêng (mục 4).

### 3.2. Phương pháp di truyền học tế bào

**Quan sát NST** là kỹ thuật phổ biến nhất.

- **NST tế bào sinh dưỡng:** chọn mô có **nhiều tế bào đang phân chia mạnh**: **tủy xương, mô bào thai, chóp rễ, đỉnh sinh trưởng** của cây. Mô ít hoặc không phân chia thì phải **kích thích** cho tế bào phân chia.
- **NST trong tạo giao tử:** dùng tế bào của **tuyến sinh dục** đực hoặc cái.

*Vì sao phải có tế bào đang phân chia?* NST chỉ đóng xoắn, hiện rõ hình dạng khi tế bào phân chia (rõ nhất ở **kỳ giữa**). Ở gian kỳ, chất nhiễm sắc duỗi ra, không đếm được NST (xem bài *Phân chia tế bào*).

**Lai tế bào soma** (từ những năm 1970): nuôi cấy tế bào và dùng một số tác nhân làm **hai tế bào** (cùng loài hoặc khác loài) **hòa nhập thành một tế bào lai** mang **cả hai bộ gen**. Dùng để khảo sát tính chất sinh học, hoạt động gen của tế bào soma và **góp phần lập bản đồ gen**.

**Kỹ thuật nhuộm băng NST** (từ những năm 1970): giúp nhận rõ từng NST và từng đoạn trên NST, ở trạng thái bình thường cũng như đột biến.

**Gây đột biến NST nhân tạo** được dùng nhiều trong **chọn giống**.

**Xét nghiệm NST** đã thành xét nghiệm thường quy với các bệnh do đột biến NST. Dù di truyền phân tử ngày càng quan trọng, di truyền tế bào vẫn cần thiết.

> [!ung-dung] Lập karyotype trong lâm sàng
> - Để xét nghiệm NST ở người, thường nuôi cấy **tế bào lympho máu ngoại vi** (vốn không phân chia) và **kích thích bằng phytohemagglutinin (PHA)** cho chúng phân chia; sau đó dùng **colchicin** dừng tế bào ở kỳ giữa. Đây chính là ví dụ "tế bào ít phân chia phải kích thích" của sách.
> - Chẩn đoán trước sinh lấy **tế bào ối** hoặc **gai nhau** (mô bào thai, phân chia mạnh).
> - Kết quả ví dụ: **47,XX,+21** là hội chứng Down ở bé gái.

### 3.3. Kỹ thuật di truyền phân tử

#### 3.3.1. Tách chiết ADN

ADN chủ yếu nằm trong **nhân**, trên NST. NST của sinh vật nhân thật gồm **ADN + protein**. Vì vậy, tách ADN theo ba bước:

1. **Phá màng tế bào và màng nhân** để ADN thoát ra;
2. **Loại bỏ protein**;
3. **Tủa (kết tủa) ADN**.

ADN tinh sạch được **định tính, định lượng** bằng **điện di** trên gel **agarose** hoặc **polyacrylamid**, hoặc **định lượng bằng mật độ quang**.

> [!vi-du] Đo mật độ quang ADN
> Base của ADN hấp thụ mạnh ánh sáng tử ngoại bước sóng **260 nm**. Đo độ hấp thụ ở 260 nm suy ra lượng ADN. Protein hấp thụ mạnh ở 280 nm, nên tỷ số A260/A280 cho biết mẫu còn lẫn protein nhiều hay ít.

#### 3.3.2. Xác định trình tự nucleotid

Về nguyên lý có thể đọc trình tự **cả bộ gen**, nhưng với điều kiện trước đây chỉ đọc được **những đoạn ADN xác định**. Có hai phương pháp: **phương pháp hóa học** và **phương pháp enzym học**.

> [!cap-nhat] Giải trình tự: từ Sanger đến thế hệ mới, NIPT, sàng lọc sơ sinh (bổ sung – kiến thức hiện nay)
> - Hai phương pháp sách nêu ra đời năm 1977: **hóa học** là của **Maxam – Gilbert** (cắt ADN bằng hóa chất đặc hiệu từng base); **enzym** là của **Sanger** (dùng ADN polymerase và nucleotid "kết thúc chuỗi" dideoxy). Phương pháp Sanger thắng thế và là phương pháp dùng cho Dự án hệ gen người.
> - Từ khoảng giữa những năm 2000 có **giải trình tự thế hệ mới** (NGS): đọc **hàng triệu đoạn ADN song song** cùng lúc. Giá đọc một bộ gen người giảm từ khoảng 3 tỷ USD (Dự án hệ gen người) xuống còn **≈ 500 USD vào năm 2022** (NHGRI; chi phí cập nhật định kỳ tại genome.gov). Các máy đọc **đoạn dài** (PacBio, Oxford Nanopore) đọc được những vùng lặp mà NGS đoạn ngắn bỏ sót; nhờ chúng mới có trình tự T2T.
> - **Giải trình tự exome** (WES: chỉ đọc các exon, khoảng 1–2% bộ gen nhưng chứa phần lớn đột biến gây bệnh đã biết) và **giải trình tự toàn bộ gen** (WGS): Hội Di truyền Y học Hoa Kỳ (ACMG, 2021) khuyến cáo dùng **sớm, như xét nghiệm hàng đầu hoặc hàng thứ hai** cho trẻ có dị tật bẩm sinh, chậm phát triển, khuyết tật trí tuệ; tìm ra nguyên nhân ở khoảng **1/4 – 1/3** số ca.
> - **NIPT** (sàng lọc trước sinh không xâm lấn): đọc **ADN tự do của thai** (thực chất phần lớn từ bánh nhau) trong máu mẹ, từ khoảng tuần 10 thai kỳ. Phát hiện **trên 99%** thai Down, tỷ lệ dương tính giả rất thấp, nhưng vẫn là **sàng lọc**: kết quả nguy cơ cao phải khẳng định bằng **chọc ối hoặc sinh thiết gai nhau**.
> - **Ở Việt Nam**: theo Luật Dân số 2025, Bộ Y tế ban hành **Thông tư 12/2026/TT-BYT** (hiệu lực 1/7/2026) về danh mục bệnh bẩm sinh khuyến khích sàng lọc: **70 bệnh/nhóm bệnh trước sinh** (gồm thalassemia, lệch bội NST, dị tật hình thái…) và **hơn 30 bệnh sơ sinh** (gồm suy giáp bẩm sinh, tăng sản thượng thận bẩm sinh, **thiếu G6PD**, phenylketon niệu và các rối loạn chuyển hóa, thalassemia, teo cơ tủy, suy giảm miễn dịch kết hợp nặng, giảm thính lực, tim bẩm sinh). Sàng lọc sơ sinh mở rộng dùng **giọt máu gót chân thấm khô**, phân tích bằng **khối phổ song song** (MS/MS) và ngày càng nhiều bằng giải trình tự gen.

#### 3.3.3. Lai acid nucleic

Lai acid nucleic dùng để **tạo ADN tái tổ hợp** (từ đó tạo dòng tế bào, chủng sinh vật mới) hoặc để **tìm một trình tự ADN** cần tìm.

**a) Enzym giới hạn (enzym cắt)**

- Chiết từ **vi khuẩn**; tên enzym đặt theo loài vi khuẩn: **EcoRI** (từ *E. coli*), **BamHI**, **SmaI**…
- Mỗi enzym **nhận ra và cắt ở một trình tự xác định**, cắt **cả hai mạch** của ADN sợi kép.
- Nhiều enzym để lại **"đầu dính"** (đoạn sợi đơn ngắn) khớp với đầu của đoạn ADN sẽ ghép vào.

> [!vi-du] EcoRI cắt thế nào?
> EcoRI nhận trình tự 6 cặp base **GAATTC** (đọc xuôi trên mạch này cũng giống đọc xuôi trên mạch kia). Nó cắt giữa G và A trên cả hai mạch, nên mỗi đầu cắt thò ra 4 base **AATT** sợi đơn. Hai đoạn ADN bất kỳ cắt bằng EcoRI có đầu dính bắt cặp bổ sung với nhau → **nối được**.
> Lưu ý: không phải enzym nào cũng tạo đầu dính. **SmaI** (cắt CCC|GGG) cắt ngay giữa nên tạo **đầu bằng**.

**b) Tạo dòng (clôn hóa đoạn ADN)**

1. Dùng **cùng một enzym giới hạn** cắt **ADN cho** (chứa gen cần) và **ADN nhận** (thể chuyển, **vector**). *Vì sao cùng một enzym?* Để hai bên có đầu dính khớp nhau.
2. Dùng **enzym nối (ligase)** nối đoạn ADN cho vào vector → **ADN lai** (tái tổ hợp).
3. Đưa ADN lai vào tế bào (*in vivo*) hoặc nhân trong ống nghiệm (*in vitro*). Ví dụ: đưa vào **vi khuẩn**; vi khuẩn sinh sản thì ADN lai cũng nhân lên → **dòng vi khuẩn mang tính chất mới**.

**c) ADN dò (probe)**

- Là đoạn **ADN hoặc ARN sợi đơn**, **đã biết trình tự, tính chất**, có khả năng **bắt cặp bổ sung** với đoạn ADN đích (sợi đơn).
- Dùng để **chọn đúng clôn** chứa đoạn ADN cần tìm.
- Nguồn tạo ADN dò: tổng hợp từ **nucleotid đơn**; **chiết từ ADN của NST**; hoặc tổng hợp **cDNA** (ADN bổ sung) từ khuôn **mARN** (nhờ enzym phiên mã ngược).
- **Đánh dấu** bằng đồng vị phóng xạ ^32^P hoặc bằng **biotin** để "nhìn thấy" chỗ dò bắt cặp.

**d) Southern blot** (Southern đề xuất năm **1975**)

Các bước:

1. **Cắt** ADN mẫu thành nhiều đoạn bằng **enzym giới hạn**;
2. **Điện di trên gel agarose** để xếp các đoạn theo kích thước;
3. **Biến tính** bằng **NaOH** hoặc **nhiệt**: cắt liên kết hydro → ADN sợi đơn;
4. **Chuyển (thấm)** ADN sợi đơn từ gel sang **màng nitrocellulose** (sách mô tả qua giấy lọc);
5. **Lai** màng với dung dịch chứa **ADN dò** đã đánh dấu; dò bắt cặp với ADN đích;
6. **Rửa** màng bằng dung dịch đệm, rồi **phát hiện** vạch lai nhờ ^32^P hoặc biotin.

*Vì sao phải biến tính?* ADN dò chỉ bắt cặp được với ADN **sợi đơn**. Nếu ADN đích còn sợi kép, không có chỗ cho dò bám vào.

> [!vi-du] "Họ" Southern
> Vì kỹ thuật mang tên người (Southern), các kỹ thuật tương tự được đặt tên đùa theo hướng la bàn: **Northern blot** phát hiện **ARN**, **Western blot** phát hiện **protein** (dùng kháng thể thay cho ADN dò). Western blot từng là xét nghiệm khẳng định nhiễm HIV.

**e) Lai tại chỗ trên NST** (in situ)

Đây là chỗ gặp nhau của **di truyền tế bào** và **lai phân tử**: NST **kỳ giữa** trên lam kính được loại **ARN** (bằng **ARNase**) và **protein** (bằng **proteinase K**), rồi **lai với ADN dò đã đánh dấu**, nhuộm và soi kính hiển vi. Kết quả: thấy được gen nằm **ở đâu trên NST nào**, và **phát hiện nhanh** đột biến NST cũng như một số dạng đột biến ADN trên NST. Giáo trình nêu đây chính là **cơ sở của kỹ thuật lai tại chỗ huỳnh quang (FISH)**.

> [!ung-dung] FISH trong lâm sàng
> Trong FISH, ADN dò gắn **chất phát huỳnh quang** thay cho đồng vị phóng xạ, nên an toàn và đọc nhanh hơn. FISH dùng nhiều trong chẩn đoán vi mất đoạn NST, ung thư máu (ví dụ phát hiện gen tổ hợp *BCR-ABL* trong bạch cầu mạn dòng tủy) và đếm nhanh NST 13, 18, 21, X, Y trước sinh. Southern blot nay ít dùng trong chẩn đoán vì PCR và giải trình tự nhanh hơn.

#### 3.3.4. PCR (phản ứng chuỗi polymerase)

PCR (Mullis, 1985) **nhân một đoạn ADN** xác định lên rất nhiều lần **trong ống nghiệm**. Đây là một trong những kỹ thuật dùng nhiều nhất của sinh học phân tử.

**Thành phần** (theo giáo trình): đoạn ADN khuôn; hai **mồi** (primer) là các **oligonucleotid** ngắn bổ sung với **hai đầu** đoạn cần nhân; **ADN polymerase chịu nhiệt** (**Taq polymerase**); **4 loại nucleotid**. Giáo trình ghi mỗi chu kỳ mất **khoảng 10 phút**; số chu kỳ chọn **tùy lượng ADN cần**.

Mỗi chu kỳ gồm **3 bước** (nhiệt độ theo hình của sách):

| Bước | Nhiệt độ | Điều xảy ra |
|---|---|---|
| 1. **Biến tính** | ~**94 °C** | Hai mạch ADN tách rời |
| 2. **Gắn mồi** (lai ghép) | ~**45–60 °C** | Hai **đoạn mồi** (primer) ngắn bám vào hai đầu đoạn đích, mỗi mồi trên một mạch, chiều ngược nhau |
| 3. **Kéo dài** (tổng hợp) | ~**72 °C** | **ADN polymerase chịu nhiệt** gắn dATP, dTTP, dCTP, dGTP nối dài từ mồi |

![Hình 1. Ba bước của một chu kỳ PCR (sơ đồ)](pcr.svg)

**Vì sao số bản sao tăng theo cấp số nhân?** Hết mỗi chu kỳ, số đoạn ADN đích **tăng gấp đôi**: 1 → 2 → 4 → 8… Sau *n* chu kỳ có khoảng **2^n^** bản. Sau 30 chu kỳ, từ một phân tử thành khoảng một tỷ bản.

**Vì sao polymerase phải chịu nhiệt?** Mỗi chu kỳ đều nóng lên 94 °C; enzym thường sẽ biến tính và hỏng. Enzym lấy từ vi khuẩn sống ở suối nước nóng (*Taq polymerase*) chịu được nhiệt này, nên chỉ cần cho vào một lần.

> [!ung-dung] PCR quanh ta
> Chẩn đoán vi khuẩn, virus (lao, viêm gan B, HPV, SARS-CoV-2), xác định huyết thống, pháp y, phát hiện đột biến gen bệnh (ví dụ gen globin trong thalassemia), và cả **kiểm nghiệm dược liệu**: dùng PCR và đọc trình tự một đoạn ADN "mã vạch" để phân biệt vị thuốc thật với vị thuốc giả hoặc nhầm loài.

## 4. Phương pháp dùng trong di truyền y học

Giáo trình nêu ngắn gọn: ở người **không áp dụng tạp giao thực nghiệm**. Ngoài phương pháp **di truyền tế bào** và **di truyền phân tử**, di truyền y học còn dùng: **xây dựng và phân tích gia hệ (phả hệ)**, **khảo sát trẻ sinh đôi**, **in và phân tích nếp vân da**, **điều tra di truyền dịch tễ học** và **di truyền lâm sàng**. *Vì sao cần phương pháp riêng?* Người không lai theo ý muốn được, mỗi thế hệ dài, ít con.

Bảng dưới giải thích thêm từng phương pháp (phần giải thích, hai dòng *hóa sinh* và *quần thể*, cùng các mục 4.1–4.2 là **bổ sung, không có trong giáo trình**):

| Phương pháp | Cách làm | Cho biết gì |
|---|---|---|
| **Phả hệ** | Lập "cây gia đình" qua nhiều thế hệ, đánh dấu người bệnh | Tính trạng/bệnh do **gen trội hay lặn**, trên **NST thường hay NST giới tính** |
| **Trẻ sinh đôi** | So sánh **sinh đôi cùng trứng** (giống nhau hoàn toàn về gen) với **sinh đôi khác trứng** (giống như anh chị em ruột) | Tính trạng phụ thuộc **gen** nhiều hay **môi trường** nhiều |
| **Di truyền tế bào** | Lập **karyotype**, nhuộm băng, FISH | Bệnh do **đột biến số lượng, cấu trúc NST** (Down, Turner…) |
| **Nếp vân da** | In vân tay, vân lòng bàn tay, bàn chân rồi phân tích | Gợi ý một số hội chứng NST (ví dụ Down hay có **một nếp gấp ngang** lòng bàn tay) |
| **Dịch tễ di truyền** | Điều tra tần suất bệnh trong cộng đồng, trong họ hàng | Bệnh có tính gia đình hay không, nguy cơ cho người thân |
| **Di truyền lâm sàng** | Khám, mô tả triệu chứng, dị hình của người bệnh và gia đình | Nhận diện hội chứng di truyền, định hướng xét nghiệm |
| **Hóa sinh** | Định lượng enzym, protein, chất chuyển hóa | Rối loạn chuyển hóa bẩm sinh (ví dụ phenylketon niệu) |
| **Di truyền phân tử** | PCR, giải trình tự, lai ADN | Vị trí và loại **đột biến gen** cụ thể |
| **Di truyền quần thể** | Điều tra tần số bệnh, tần số alen trong cộng đồng | Tỷ lệ người mang gen, nguy cơ bệnh theo vùng, dân tộc |

### 4.1. Phả hệ và ký hiệu chuẩn

Khi lập phả hệ, mọi người dùng chung một bộ ký hiệu để ai đọc cũng hiểu:

![Hình 2. Các ký hiệu chuẩn dùng khi lập phả hệ](ky-hieu-pha-he.svg)

**Cách đọc:** mỗi **thế hệ** một hàng, đánh số **La Mã** (I, II, III…) từ trên xuống; người trong hàng đánh số **Ả Rập** từ trái sang phải. Vợ chồng nối bằng **đường ngang**; con cái treo dưới một đường ngang chung, xếp **theo thứ tự sinh**. **Người khởi đầu** (proband) là người bệnh đầu tiên khiến gia đình được khám, đánh dấu bằng **mũi tên**.

![Hình 3. Phả hệ mẫu: bệnh do gen lặn trên NST thường, có kết hôn cận huyết](pha-he-mau.svg)

**Phân tích phả hệ mẫu:**

- **IV-2 và IV-3** bị bệnh, nhưng bố mẹ (**III-2, III-3**) đều bình thường → gen bệnh là **lặn**: bố mẹ là **dị hợp** Aa, con nhận a từ cả hai người → aa.
- Có cả **con gái** (IV-2) và **con trai** (IV-3) bị bệnh; con gái bệnh mà bố bình thường → gen **không nằm trên X** (nếu lặn trên X, con gái bệnh thì bố phải bệnh) → gen trên **NST thường**.
- III-2 và III-3 là anh em họ (cùng ông bà I-1, I-2): **kết hôn cận huyết** (nét đôi).

| Bố III-2 \ Mẹ III-3 | A | a |
|---|---|---|
| **A** | AA (bình thường) | Aa (mang gen) |
| **a** | Aa (mang gen) | **aa (bệnh)** |

=> Aa × Aa → 1 AA : 2 Aa : 1 aa

Vậy mỗi lần sinh, con có **1/4** nguy cơ bị bệnh và **2/4** khả năng mang gen như bố mẹ.

> [!bay]
> - Mỗi lần sinh là **độc lập**: đã có một con bệnh thì lần sau **vẫn là 1/4**, không phải "đã đủ phần 1/4 rồi".
> - Ô **tô nửa** = dị hợp, mang gen bệnh nhưng **không bệnh**. Đừng nhầm với tô đậm (người bệnh).
> - Sinh đôi **cùng trứng** luôn **cùng giới**; sinh đôi khác trứng có thể khác giới.

> [!ung-dung] Vì sao tư vấn tránh kết hôn cận huyết?
> Anh em họ có chung ông bà nên dễ **cùng mang một gen lặn hiếm** từ tổ tiên chung. Kết hôn với nhau làm tăng khả năng con nhận **hai bản** gen lặn đó → bệnh di truyền lặn xuất hiện nhiều hơn. Đây là cơ sở khoa học của quy định cấm kết hôn giữa những người có họ trong phạm vi ba đời ở Việt Nam. Ở nước ta, **thalassemia** (bệnh tan máu bẩm sinh, di truyền lặn trên NST thường) có tỷ lệ người mang gen khá cao, vì vậy lập phả hệ và xét nghiệm người mang gen trước khi sinh con rất có ích.

### 4.2. Nghiên cứu trẻ sinh đôi

- **Sinh đôi cùng trứng:** một trứng thụ tinh rồi tách đôi → **bộ gen giống nhau**. Khác biệt giữa hai trẻ chủ yếu do **môi trường**.
- **Sinh đôi khác trứng:** hai trứng thụ tinh với hai tinh trùng → giống nhau trung bình **một nửa** số alen, như anh chị em ruột.

*Logic:* nếu một tính trạng (hay một bệnh) **trùng nhau** ở cặp cùng trứng **nhiều hơn hẳn** so với cặp khác trứng, thì gen đóng vai trò lớn. Nếu tỷ lệ trùng gần như nhau, môi trường đóng vai trò lớn.

## Tóm tắt

| Chủ đề | Ý chính |
|---|---|
| Tiến hóa luận | Bất biến (đến TK 16) → Lamarck (di truyền tập nhiễm) → Darwin (di truyền, biến dị; chọn lọc tự nhiên, nhân tạo) |
| Mendel và sau Mendel | Mendel 1865 → bỏ quên 34 năm → 1900 De Vries, Correns, Tschermak (**năm ra đời di truyền học**) → Boveri 1902, Boveri – Sutton 1903 (NST) → Johannsen 1909 ("gen") → Morgan 1910 (ruồi giấm: liên kết, trao đổi chéo, liên kết giới tính) |
| Di truyền phân tử | Miescher 1869 → Beadle – Tatum 1941 (một gen – một enzym, *Neurospora*) → Watson – Crick (mô hình ADN) → Jacob – Monod 1961 (điều hòa gen) → Arber 1962 (enzym giới hạn) → Nirenberg, Leder 1964; Nirenberg, Ochoa, Khorana 1966 (mã bộ ba) → Khorana (gen nhân tạo) → Beckwith 1969 (tách gen) → Temin 1970 (phiên mã ngược) → Mullis 1985 (PCR) → 2001 bản đồ gen người |
| Nội dung | Tính di truyền + tính biến dị; 8 lĩnh vực: tế bào, phân tử, miễn dịch (cơ sở ghép), dược lý (enzym chuyển hóa thuốc), quần thể (tần số gen), đột biến (phóng xạ, hóa chất, sinh học), bệnh di truyền (ung thư = tế bào đột biến), công nghệ (vi khuẩn sản xuất insulin) |
| Tạp giao thực nghiệm | Kinh điển, chủ yếu ở động – thực vật; mẫu: chu kỳ ngắn, đông con, nhiều biến dị, dễ nuôi; ruồi giấm 10–15 ngày, chuột nhắt 2,5 tháng, *Neurospora*, vi khuẩn, virus, lúa mạch, ngô |
| Di truyền tế bào | Quan sát NST ở mô phân chia mạnh (tủy xương, bào thai, chóp rễ, đỉnh sinh trưởng) hoặc kích thích phân chia; tuyến sinh dục cho giao tử; lai tế bào soma; nhuộm băng (1970); xét nghiệm NST thường quy |
| Di truyền phân tử | Tách ADN (phá màng → bỏ protein → tủa); giải trình tự (hóa học, enzym); enzym giới hạn (EcoRI, BamHI, SmaI); tạo dòng (cùng enzym cắt + ligase + vector); ADN dò sợi đơn (^32^P, biotin; cDNA từ mARN); Southern blot 1975 (cắt → điện di → NaOH/nhiệt → nitrocellulose → lai dò); lai tại chỗ trên NST kỳ giữa (ARNase, proteinase K) |
| PCR | Mồi oligonucleotid, Taq polymerase, 4 nucleotid; mỗi chu kỳ ~10 phút (theo sách); 94 °C biến tính → 45–60 °C gắn mồi → 72 °C kéo dài; mỗi chu kỳ gấp đôi, n chu kỳ ≈ 2^n^ |
| Di truyền y học | Không dùng tạp giao; dùng di truyền tế bào, phân tử, phả hệ, trẻ sinh đôi, nếp vân da, dịch tễ, lâm sàng; ký hiệu: □ nam, ○ nữ, tô đậm = bệnh, tô nửa = dị hợp, nét đôi = cận huyết, mũi tên = người khởi đầu |
