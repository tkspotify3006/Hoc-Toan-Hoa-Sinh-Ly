---
title: Tiến hóa của chất sống
thoi-gian: 40 phút
muc-tieu:
- Trình bày được quá trình hình thành các đơn phân sống, các polyme sống và giọt coacerva (Protobionta) trong giai đoạn tiến hóa hóa học – tiền sinh học.
- Trình bày được những thành tựu mới về tiến hóa tiền tế bào: ARN có trước ADN và protein, ARN xúc tác (ribozym), hiệu chỉnh ARN, chuyển từ ARN sang ADN nhờ phiên mã ngược.
- Nêu được các mốc tiến hóa sinh học sau khi tế bào xuất hiện và ý nghĩa của ADN ty thể.
- Kể được các thuyết tiến hóa chính và trình bày được các nhân tố tiến hóa cơ bản.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. **Haldane và Oparin** (thập niên 1920–1930): sự sống bắt đầu bằng **tổng hợp tiền sinh học** trong khí quyển nguyên thủy **không có O~2~, không có tầng ozon**.
> 2. Chuỗi sự kiện: khí đơn giản → **đơn phân sống** (acid amin/amino acid, đường, base, nucleotid; thí nghiệm **Miller 1953**) → **polyme sống** (protein không sống của **Fox**, polynucleotid; xúc tác bởi **đất sét, đá núi lửa**) → **giọt coacerva / hạt cầu vi thể Fox = Protobionta** có màng ngăn cách với môi trường.
> 3. **ARN (RNA) có trước ADN (DNA) và protein**: ARN vừa mang thông tin vừa **xúc tác** được (**ribozym**, ví dụ ARNase P); sau đó thông tin được chuyển sang **ADN bền hơn** nhờ **phiên mã ngược**.
> 4. ADN bền hơn ARN vì **không có nhóm 2'-OH** (không bị thủy phân kiềm) và dùng **thymin thay uracil** (sửa được lỗi khử amin C → U).
> 5. Nhân tố tiến hóa (theo giáo trình) gồm 4 nhóm: **đột biến + giao phối** (nguyên liệu), **du nhập gen**, **chọn lọc tự nhiên** (định hướng), **cách ly** (phân hóa, kết thúc bằng cách ly sinh sản → loài mới).

## 1. Các phương pháp giải thích sự tiến hóa của sự sống

Qua lịch sử, con người đã dùng nhiều cách để tìm hiểu nguồn gốc sự sống:

| Phương pháp | Nội dung |
|---|---|
| Giả thuyết suy luận (trước Công nguyên) | Ví dụ **Aristote**: sinh vật phát sinh **ngẫu nhiên từ chất vô sinh** |
| Thực nghiệm | Làm thí nghiệm để kiểm chứng giả thuyết (ví dụ thí nghiệm Miller) |
| Cổ sinh vật học | Dựa vào **hóa thạch** |
| Dẫn liệu ngoài Trái Đất | Thiên thạch, sao chổi, các hành tinh được coi là tương ứng với một thời kỳ của Trái Đất |
| So sánh sinh vật hiện nay | Sắp xếp từ **đơn giản → phức tạp**; phức tạp hơn được coi là tiến hóa cao hơn |
| Sinh học phân tử, di truyền học phân tử | Phương pháp hiện đại: so sánh trình tự ADN, ARN, protein |

> [!cap-nhat] Thuyết "tự sinh" đã bị bác bỏ
> Ý tưởng sinh vật **tự sinh ra hằng ngày** từ chất vô sinh (như dòi tự sinh từ thịt thối) đã bị **Pasteur** bác bỏ bằng thí nghiệm bình cổ cong (khoảng năm 1860). Vì vậy, các nhà khoa học hiện đại chỉ bàn đến sự phát sinh sự sống **một lần, trong điều kiện Trái Đất nguyên thủy**, qua một quá trình hóa học kéo dài hàng trăm triệu năm. Đây chính là nội dung phần 2.

## 2. Những tiếp cận về nguồn gốc sự sống của thế kỷ XX

![Hình 1. Ba giai đoạn tiến hóa của chất sống](cac-giai-doan.svg)

Quá trình được chia làm ba giai đoạn nối tiếp: **tiến hóa hóa học** (tạo chất hữu cơ từ chất vô cơ) → **tiến hóa tiền sinh học** (tạo hệ thống tự sao chép có màng bọc) → **tiến hóa sinh học** (từ tế bào đầu tiên đến sinh giới ngày nay).

### 2.1. Tiến hóa phân tử tiền sinh học

Hóa thạch và giải phẫu so sánh cho thấy khá rõ sự tiến hóa của động vật và thực vật trong khoảng **700 triệu năm** gần đây. Luận điểm chính: **cơ thể đa bào phức tạp tiến hóa từ cơ thể đơn bào đơn giản**.

Câu hỏi còn lại là: tế bào đầu tiên từ đâu ra? Khoảng **thập niên 1920–1930**, khi biết mọi sinh vật đều được xây dựng từ **cùng những nguyên tố**, **Haldane** và **Oparin** đề xuất: trong điều kiện khí quyển và địa chất đặc biệt của Trái Đất sơ khai, các phân tử hữu cơ quan trọng đã được **tổng hợp một cách ngẫu nhiên (tổng hợp tiền sinh học)**, đủ để mở đường cho tiến hóa tiền tế bào. Về sau nhiều thực nghiệm đã tổng hợp được acid amin, một số base của acid nucleic và cả polyme sơ khai.

#### 2.1.1. Khí quyển nguyên thủy

- Khi mới hình thành, Trái Đất được bao bởi một lớp **tinh vân**, cộng thêm **khí phun từ núi lửa**.
- Thành phần chủ yếu là các hợp chất đơn giản: **CH~4~, NH~3~, H~2~O, CO, CO~2~**.
- Theo giáo trình, hỗn hợp này **trung tính**: không có tính oxy hóa như khí quyển ngày nay, cũng **không có tính khử** như Oparin giả định.
- **Không có O~2~ tự do** và **không có tầng ozon (O~3~)** → tia cực tím từ Mặt Trời chiếu thẳng xuống bề mặt.
- Trái Đất nguội dần → hơi nước ngưng tụ → hình thành **đại dương nguyên thủy**.

*Vì sao việc thiếu O~2~ lại quan trọng?* O~2~ là chất oxy hóa mạnh, sẽ phá hủy các phân tử hữu cơ vừa tạo ra. Không có O~2~ (và chưa có sinh vật nào "ăn" chúng), chất hữu cơ có thể **tích lũy** dần trong nước. Còn tia cực tím, tia chớp chính là **nguồn năng lượng** cho các phản ứng tổng hợp.

#### 2.1.2. Các đơn phân sống (biomonomer)

Các nhà khoa học dựng lại "khí quyển nguyên thủy" trong bình thí nghiệm và cung cấp năng lượng giả lập nguồn năng lượng tự nhiên:

| Năng lượng tự nhiên | Thay bằng trong thí nghiệm |
|---|---|
| Tia phóng xạ Mặt Trời (tử ngoại) | Đèn cực tím |
| Tia chớp | **Tia lửa điện** |
| Tia phóng xạ ion hóa | Cyclotron |
| Nhiệt Mặt Trời, núi lửa | Lò nung điện |
| Đại dương nguyên thủy | Bình cầu chứa nước biển hoặc tương tự |

Các tác giả gắn với những thí nghiệm này: **Miller (1953)**, Ponnamperuma, Calvin, Fox, Oró.

**Kết quả:**
- Phân tử đơn giản: **acid cyanhydric (HCN), formaldehyd (HCHO), acid acetic**.
- Từ đó phản ứng tiếp thành: **acid amin, monose (đường đơn), base nitơ**, trong một số trường hợp có cả **nucleotid và ATP**.

Như vậy, các "viên gạch" của đại phân tử sinh học có thể tự hình thành trong khí quyển nguyên thủy và trong các vùng nước giàu muối khoáng.

![Hình 2. Sơ đồ thí nghiệm Miller (1953)](thi-nghiem-miller.svg)

> [!vi-du] Thí nghiệm Miller – Urey (1953)
> - **Stanley Miller** (học trò của **Harold Urey**) cho hỗn hợp **CH~4~, NH~3~, H~2~ và hơi nước** tuần hoàn trong hệ bình kín.
> - Bình nước đun sôi đóng vai "đại dương" tạo hơi nước; bình khí có **hai điện cực phóng tia lửa điện** đóng vai "tia chớp"; bộ phận làm lạnh ngưng tụ hơi nước thành "mưa" đưa sản phẩm trở về bình nước.
> - Sau khoảng **1 tuần**, nước trong bình chuyển màu nâu đỏ; phân tích thấy có nhiều **acid amin** (glycin, alanin…).
> - Ý nghĩa: lần đầu chứng minh bằng thực nghiệm rằng chất hữu cơ của sự sống có thể tạo ra **từ chất vô cơ, không cần sinh vật**, đúng như dự đoán của Oparin – Haldane.

> [!cap-nhat] Về thí nghiệm Miller và khí quyển nguyên thủy
> - Giáo trình viết Miller dùng **đèn cực tím** thay tia phóng xạ Mặt Trời. Thực ra thí nghiệm kinh điển năm 1953 của Miller dùng **tia lửa điện** (giả lập tia chớp) với hỗn hợp CH~4~, NH~3~, H~2~, H~2~O. Đi thi, nếu câu hỏi bám đúng câu chữ giáo trình thì theo giáo trình.
> - Năm 2008, phân tích lại các mẫu Miller còn lưu giữ bằng máy móc hiện đại tìm thấy **hơn 20 loại acid amin**, nhiều hơn số Miller công bố.
> - Hiện nay đa số cho rằng khí quyển sơ khai **giàu CO~2~, N~2~, hơi nước**, ít CH~4~ và NH~3~ hơn giả định của Miller; nghĩa là khí quyển chỉ khử yếu hoặc trung tính (gần với điều giáo trình viết). Trong điều kiện này hiệu suất tạo acid amin thấp hơn, nên các vùng đặc biệt (miệng núi lửa, **miệng phun thủy nhiệt dưới đáy biển**) và chất hữu cơ từ vũ trụ được coi là nguồn bổ sung quan trọng.

**Nguồn từ vũ trụ.** Từ khoảng năm **1970**, nhờ thiên văn vô tuyến (giáo trình gọi là thiên văn phóng xạ), người ta phát hiện trong khoảng không giữa các vì sao có nhiều **amoniac, cyanoacetylen, formaldehyd** (trước đó chỉ biết có H~2~ và các gốc nhỏ OH, CN). Theo **M. Calvin (1974)**, các phân tử này được Trái Đất thu nhận khi hình thành, rồi được đưa lên bề mặt cùng nước và chất khoáng.

#### 2.1.3. Các polyme sống (biopolymer)

**Lượng chất hữu cơ có thể tích lũy:** nếu chỉ **1/10 triệu** năng lượng Mặt Trời được dùng để tổng hợp chất hữu cơ, thì trong **5 triệu năm** mỗi **1 m^2^** có thể tạo khoảng **10 kg chất hữu cơ** (A. Ducrocq, 1966). Điều kiện là chưa có sinh vật tiêu thụ chúng. Kết quả là một **"canh thang hữu cơ"** (cháo hữu cơ, *primordial soup*) đậm đặc dần trong đại dương.

Cách đơn phân nối thành polyme đầu tiên vẫn chưa rõ. Tuy nhiên thí nghiệm cho thấy **nhiệt và phóng xạ** có thể nối đơn phân thành polyme, và **bề mặt khoáng nóng có cấu trúc tinh thể** (đá núi lửa, đất sét) có thể đóng vai **chất xúc tác**:

| Tác giả | Thí nghiệm | Sản phẩm |
|---|---|---|
| **S. W. Fox** | Hỗn hợp **khô 18 acid amin** đặt trên mảnh đá núi lửa (phún thạch) nung **170 °C** nhiều giờ | Polyme hàng trăm acid amin: **"tiền thân protein"** = **protein không sống** (proteinoid) |
| **G. Schramm** | Nung nucleotid **60 °C** với dẫn xuất acid metaphosphoric | Polynucleotid **20–200** đơn phân (dạng khô) |
| **J. Oró và P. Kimball (1971)** | Trong **môi trường nước**, có **cyanamid** làm tác nhân ngưng tụ, **đất sét** làm bề mặt xúc tác | Polyme hóa **5–10 nucleotid** |

*Vì sao đất sét quan trọng?* Đất sét có bề mặt tinh thể tích điện, **hấp phụ và xếp các đơn phân sát nhau theo trật tự**, làm tăng nồng độ cục bộ và giúp phản ứng nối (loại nước) dễ xảy ra hơn. Có giả thuyết cho rằng khuôn đất sét đã giúp tạo ra những "gen" hữu cơ hình sợi, **tổ tiên của ARN**.

**Bằng chứng ngoài Trái Đất:**
- **Thiên thạch Murchison** (rơi ở Úc năm **1969**; giáo trình viết "Murchinson"): chứa cả **acid amin tự nhiên** (có trong protein) và **acid amin phi sinh học**. Mẫu lấy rất sâu bên trong nên loại trừ được nhiễm bẩn từ mặt đất.
- Trong tinh vân giữa các vì sao: **H~2~, HCN, cyanoacetylen, CO, H~2~S, NH~3~**, cả phân tử lớn hơn như **acetonitril, acetaldehyd**.
- **Sao chổi Halley (1986)**: nhân sao chổi chứa nhiều phân tử hữu cơ phức tạp hơn dự đoán.

> [!cap-nhat] Mẫu tiểu hành tinh mang về Trái Đất (bổ sung – kiến thức hiện nay)
> Thiên thạch rơi xuống có thể bị nhiễm bẩn; nay đã có mẫu lấy **trực tiếp từ tiểu hành tinh** trong vỏ kín. Mẫu tiểu hành tinh **Ryugu** (tàu Hayabusa2, Nhật Bản) có **uracil**; mẫu tiểu hành tinh **Bennu** (tàu OSIRIS-REx, NASA; công bố trên *Nature Astronomy* và *Nature*, 1/2025) chứa **14/20 acid amin** dùng trong protein và **đủ cả 5 base nitơ** của ADN, ARN, cùng amoniac và các muối hình thành từ nước mặn bốc hơi. Điều này củng cố ý của giáo trình: "viên gạch" của sự sống hình thành được ngoài Trái Đất và có thể đã được đưa tới Trái Đất sơ khai. Nó **không** có nghĩa là đã tìm thấy sự sống ngoài Trái Đất.

→ Kết luận: các đại phân tử có ý nghĩa sinh học **có thể hình thành dễ dàng trong tự nhiên**, và có thể đã có trên Trái Đất khoảng **4 tỷ năm trước**. Khi chưa có O~2~ tự do và chưa có tế bào chuyển hóa chúng, các chất hữu cơ khá **bền**, tích tụ trong đại dương → giả thuyết "cháo hữu cơ" của Haldane – Oparin có nhiều khả năng hiện thực.

#### 2.1.4. Giọt coacerva hay Protobionta

**Ý tưởng của Oparin:** mọi sinh vật đều là một **đơn vị riêng biệt**, các phản ứng diễn ra có trật tự trong không gian – thời gian, và luôn được **ngăn cách với môi trường bằng màng**. Vì vậy sự sống phải bắt đầu trong những **giọt vi thể** có màng bảo vệ:
- Màng cho một số chất đi qua (nước, glucose, acid amin) nhưng giữ lại chất khác → **trong và ngoài giọt khác nhau** → hình ảnh sơ khai của **trao đổi chất (dị dưỡng)**.
- Các giọt khác nhau tùy vi môi trường; chỉ giọt nào có phản ứng **có lợi cho chính nó** mới **lớn lên, phân chia, sinh sôi** → một dạng **chọn lọc tự nhiên tiền sinh học**.
- Oparin gọi chúng là **giọt coacerva**: phức hợp **đại phân tử ngậm nước**, tự hình thành trong điều kiện lý hóa xác định.

**Hạt cầu vi thể của Fox (microsphere):** khi hòa tan protein không sống vào **nước nóng và mặn**, Fox thu được nhiều hạt cầu **2–3 µm** (cỡ vi khuẩn), có **màng bọc** thấy được dưới kính hiển vi điện tử. Chúng giống đáng ngạc nhiên với cấu trúc vi thể trong thiên thạch giàu chất hữu cơ **Orgueil**.

**Liposom:** hạt tự hình thành trong nước từ hỗn dịch lipid và protein, có **màng lipid kép** giống màng tế bào.

*Vì sao lipid tự tạo màng?* Phospholipid và cholesterol có **đầu ưa nước** và **đuôi kỵ nước**. Trong nước, chúng tự xếp thành **lớp kép hình cầu** để giấu đuôi kỵ nước vào giữa. Không cần enzym, chỉ cần tính chất lý hóa (xem lại bài Màng tế bào và tế bào chất).

**Protobionta** = dạng tiền tế bào giả định (kiểu hạt cầu vi thể Fox), được coi là mô hình chất sống đầu tiên.

**Câu hỏi còn bỏ ngỏ:** từ giọt vi thể chuyển thành tế bào thật như thế nào? Ngay tế bào đơn giản nhất (vi khuẩn) đã có khoảng **10 000 loại protein** được mã hóa chặt chẽ (theo giáo trình).

> [!cap-nhat] Một tế bào tối thiểu cần bao nhiêu gen?
> Con số "10 000 protein" của giáo trình là cao: bộ gen *E. coli* chỉ mã hóa khoảng **4.300 protein**. Năm 2016, nhóm Craig Venter tạo được tế bào vi khuẩn tổng hợp **JCVI-syn3.0** chỉ với **473 gen** mà vẫn sống và phân chia được (*Science*, 2016). Dù vậy, ý chính của sách vẫn đúng: ngay tế bào tối giản cũng phức tạp hơn rất nhiều so với giọt coacerva.

> [!bay]
> - **Coacerva** là khái niệm của **Oparin**; **hạt cầu vi thể (microsphere)** và **protein không sống (proteinoid)** là của **Fox**. Protobionta là tên chung cho dạng tiền tế bào giả định này.
> - Protobionta **chưa phải tế bào**: chưa có hệ thống di truyền (mã, nhân đôi, dịch mã).
> - Thiên thạch **Murchison** (1969, Úc) → acid amin; thiên thạch **Orgueil** → cấu trúc vi thể giống hạt Fox. Đừng đảo.

### 2.2. Những thành tựu mới về tiến hóa sinh học tiền tế bào

#### 2.2.1. Tế bào đã hình thành như thế nào?

Vì **học thuyết tế bào** khẳng định mọi sinh vật đều cấu tạo từ tế bào, nên tìm nguồn gốc sự sống = **tìm nguồn gốc tế bào**. Học thuyết Haldane – Oparin cũng dựa trên nền tảng này.

Acid amin, protein không sống, acid nucleic, giọt Fox… vẫn chưa giải đáp được vấn đề then chốt: **bộ máy di truyền**. Trước khi có tế bào thật sự, phải có sẵn:
1. Một **mã** di truyền;
2. Cơ chế **nhân đôi acid nucleic**;
3. Cơ chế **dịch mã** ra protein.

Đây là "khoảng trống" giữa tiền sinh học và sinh học. Hiểu biết về **vai trò đa năng và khả năng xúc tác của ARN** đã gợi ý cách lấp khoảng trống này. Không có tế bào ngày nay nào giống tế bào tổ tiên, nhưng tế bào hiện đại vẫn còn **dấu vết** của tiến hóa phân tử nguyên thủy.

#### 2.2.2. ARN có nhiều khả năng có trước ADN và protein

Polyme hóa acid amin tự do cho chuỗi polypeptid bấp bênh, hiệu suất rất thấp (tốt hơn khi nung khô acid amin hoạt hóa có mặt đất sét).

**Cuối thập niên 1960**, sau khi khám phá mã di truyền, phiên mã và dịch mã, **Leslie Orgel, Francis Crick và Carl Woese** cho rằng **ARN có trước ADN**, vì:
- ARN **tự nhân đôi** được bằng cách sao chép sợi bổ sung → có thể là polyme đầu tiên;
- ARN có **khả năng xúc tác**: tự cắt, tự ghép exon, tự kéo dài, tự nối → có vai trò trung tâm, có thể nguyên thủy nhất.

**Các chức năng sinh hóa của ARN đã được chứng minh** (bằng chứng ủng hộ):

| Bằng chứng | Ý nghĩa |
|---|---|
| ARN làm khuôn tổng hợp ADN (**phiên mã ngược**) | Thông tin có thể đi từ ARN sang ADN |
| ARN cần cho **telomerase** hoạt động ở đầu mút NST (nhiễm sắc thể) | ARN làm khuôn kéo dài telomere |
| **ARN 7S** tham gia bộ máy **tiết protein** | ARN có vai trò cấu trúc – vận chuyển |
| Hàng chục loại ARN khác chưa rõ chức năng | ARN đa dạng |
| ARN có **nhiều chức năng hơn ADN** | Vừa mang tin vừa làm việc |
| **Deoxyribonucleotid là dẫn xuất của ribonucleotid** | Tế bào tạo nguyên liệu ADN từ nguyên liệu ARN → ARN "đi trước" |
| **Enzym phiên mã ngược** có ở cả vi khuẩn và hầu hết Eukaryota (sinh vật nhân thực), không chỉ ở virus ARN gây ung thư | Cơ chế chuyển ARN → ADN phổ biến |

→ Hầu hết tác giả thừa nhận **ARN có trước ADN** trong tiến hóa tiền tế bào. Câu hỏi tiếp theo: ARN xuất hiện thế nào, và quan hệ ARN – protein hình thành ra sao?

> [!cap-nhat] Giả thuyết "thế giới ARN" (RNA world)
> Giáo trình trình bày ý tưởng này nhưng chưa dùng tên gọi. Hiện nay nó được gọi là **giả thuyết thế giới ARN** (thuật ngữ của **Walter Gilbert, 1986**): đã có một giai đoạn sự sống dùng **ARN vừa làm vật liệu di truyền vừa làm enzym**, trước khi có ADN và protein.
> - Năm 1982–1983, **Thomas Cech** (intron tự cắt nối ở *Tetrahymena*) và **Sidney Altman** (ARNase P) phát hiện ARN xúc tác; hai ông nhận **giải Nobel Hóa học 1989**.
> - Năm 2000, cấu trúc tinh thể ribosom cho thấy trung tâm **tạo liên kết peptid** chỉ gồm **rARN**, không có protein: **ribosom về bản chất là một ribozym**. Đây được coi là "hóa thạch phân tử" mạnh nhất của thế giới ARN (công trình cấu trúc ribosom được **giải Nobel Hóa học 2009**: Ramakrishnan, Steitz, Yonath).
> - Nhiều coenzym (ATP, NAD^+^, FAD, coenzym A) chứa **nucleotid** → có thể là dấu vết của thời ARN làm mọi việc.
> - Năm 2026, một nhóm nghiên cứu công bố trên *Science* ribozym **QT45** chỉ dài **45 nucleotid**, tìm được từ các chuỗi ARN ngẫu nhiên, có thể **tổng hợp được bản sao của chính nó và mạch bổ sung** (dùng nguyên liệu là bộ ba nucleotid, trong nước đá kiềm nhẹ). Hiệu suất còn rất thấp (≈ 0,2% sau 72 ngày) và chép còn sai, nên đây là bước tiến quan trọng chứ **chưa phải** một hệ ARN tự sao chép hoàn chỉnh, tự duy trì.
> - Giả thuyết vẫn còn điểm khó (ribose kém bền, nguồn nucleotid tiền sinh học, ARN tự sao chép hiệu quả chưa tạo được), nhưng là mô hình được chấp nhận rộng rãi nhất hiện nay.

#### 2.2.3. Sự tổng hợp ARN tiền sinh học

Nguyên liệu: **ribose** rồi đến **ribonucleotid**. Người ta thừa nhận cả hai có thể tạo được trong điều kiện tiền sinh học, nhưng **con đường cụ thể chưa khẳng định**.

- **Phản ứng formose**: formaldehyd (HCHO) ngưng tụ → **glycolaldehyd (2C)** → ngưng tụ hàng loạt → hỗn hợp đường nhiều kích cỡ (có triose, pentose như ribose). Nhược điểm: tạo hỗn hợp đường rất phức tạp → nucleotid rất đa dạng, không chọn lọc.
=> HCHO + HCHO → glycolaldehyd (C~2~) → triose (C~3~) → … → ribose (C~5~) và nhiều đường khác
- **Thí nghiệm nung nóng** hỗn hợp **urê, NH~4~Cl, phosphat và hydroxyapatit** ở **100 °C trong 24 giờ** → thu được **ribonucleotid**, rồi **polyphosphat**.

#### 2.2.4. Nguồn gốc mã di truyền

ARN nguyên thủy phải tương tác với acid amin và peptid. Câu hỏi: ARN (hay tiền thân của nó) đã "dịch" ra peptid như thế nào? Nghiên cứu bảng mã hiện nay cho thấy những dấu vết của mã nguyên thủy:

| Nhận xét trên bảng mã | Ví dụ |
|---|---|
| Acid amin **kỵ nước nhất** có **U ở vị trí giữa** codon | Phenylalanin, leucin, isoleucin, valin, methionin |
| Acid amin **ưa nước** có **A ở vị trí giữa** | Glutamat, aspartat, lysin, asparagin, glutamin, histidin, tyrosin |
| Codon có **C ở giữa** mã hóa acid amin kỵ nước **nhiều hơn** codon có **G ở giữa** | — |
| Acid amin có nhiều codon (vd 4 codon) thường **giống nhau 2 chữ đầu, khác chữ thứ ba** | — |

→ Suy luận: mã nguyên thủy phải **phân biệt được kỵ nước / ưa nước**; có thể là **mã bộ ba nhưng chỉ dùng 2 chữ đầu**.

Các tương tác ARN – ARN và ARN – acid amin trong dịch mã hiện nay:
1. **tARN – acid amin**: nhờ enzym đặc hiệu **aminoacyl-tARN synthetase**.
2. **tARN – rARN**: qua bộ bốn nucleotid (giáo trình ghi "TCG") của tARN với đoạn tương đồng trên rARN.
3. **tARN – mARN**: bắt cặp **codon – anticodon** (mã – đối mã).

Vì các tương tác này đều xảy ra **tại ribosom**, người ta nghĩ đến một **ribosom nguyên thủy cấu tạo chủ yếu bằng ARN**.

> [!ung-dung] Vì sao đột biến ở vị trí thứ ba thường "vô hại"?
> Do mã có tính **thoái hóa** chủ yếu ở chữ thứ ba, đột biến thay base ở vị trí này thường là **đột biến đồng nghĩa** (không đổi acid amin). Còn mã có quy luật "U giữa = kỵ nước" nên nhiều đột biến sai nghĩa thay acid amin bằng một acid amin **có tính chất gần giống** → giảm hậu quả. Mã di truyền đã tiến hóa theo hướng **chống chịu sai sót**.

#### 2.2.5. ARN xúc tác — tác nhân ra đời hệ thống di truyền tiền tế bào

**ARN xúc tác** = ARN hoạt động như enzym. Hoạt động sơ khai nhất là hoạt động **nuclease** (cắt acid nucleic).

**Ví dụ kinh điển: ARNase P của *E. coli***
- Chức năng: **cắt, tỉa ARN tiền thân** (phiên mã từ ADN) để tạo **tARN^Tyr^ thuần thục**.
- Gồm 2 phần: **ARN dài 375 nucleotid** + **protein**.
- Phần **protein một mình không có hoạt tính**. Phần **ARN một mình** (khi có **nồng độ muối cao**) vẫn cắt tỉa được → **chính ARN là chất xúc tác**.
- Vai trò của protein trong tế bào: **che các điện tích âm** của ARN để ARN xúc tác áp sát đúng vị trí trên ARN cơ chất. (*Vì sao cần muối cao khi không có protein?* Ion dương của muối làm thay việc trung hòa điện tích này.)

Enzym cùng loại đã được tinh chế từ vi khuẩn khác, **nấm men và cả tế bào người**, đều có chuỗi ARN khoảng **350 nucleotid**, gọi chung là **ribozym**. Cấu trúc bậc 2 của chúng **rất giống nhau** → **chung nguồn gốc**.

#### 2.2.6. Hiệu chỉnh ARN sau phiên mã — dấu vết của phản ứng tiền tế bào

**Hiệu chỉnh ARN** (*RNA editing*) = thay đổi một số nucleotid của ARN **sau khi phiên mã**. Được làm sáng tỏ ở **ty thể** của 3 loài **động vật nguyên sinh có roi**: ***Leishmania, Trypanosoma, Crithidia***.

**Cách phát hiện:** lấy mARN của một số enzym → **phiên mã ngược** thành cADN → so với ADN ty thể gốc → có đoạn khớp, có đoạn **không khớp với ADN mà chỉ khớp với ARN**.

**Bản chất:** phiên mã từ ADN ty thể bình thường, sau đó mARN được sửa: **thêm hoặc bớt các uridylat (U)**. Nhờ vậy mARN đang **không dịch mã được** trở thành **dịch mã được**. Ví dụ: mARN thiếu codon khởi đầu, được chèn **U vào giữa A và G** → tạo **AUG** → dịch mã bắt đầu.

=> …A–G… (không có codon mở đầu) + chèn U → …**AUG**… (dịch mã được)

**Ý nghĩa tiến hóa:** một cơ chế tương tự có thể đã biến một ARN sơ khai **"không sống"** thành ARN **"sống"**, biết dịch mã ra protein.

> [!ung-dung] Hiệu chỉnh ARN ở người
> Người cũng có hiệu chỉnh ARN (kiểu đổi base, không phải chèn U): gen **apolipoprotein B** ở **ruột non** được đổi C → U tạo codon kết thúc sớm, cho **ApoB-48** (trong chylomicron); ở **gan** không hiệu chỉnh nên tạo **ApoB-100** (trong VLDL, LDL). Một gen cho hai protein khác nhau tùy mô.
> Các ký sinh trùng *Trypanosoma* (bệnh ngủ châu Phi, bệnh Chagas) và *Leishmania* phụ thuộc vào cơ chế chèn U đặc biệt này, nên bộ máy hiệu chỉnh của chúng được nghiên cứu làm **đích thuốc** mới.

#### 2.2.7. Từ ARN ra ADN

Tế bào có khả năng phân bào như ngày nay phải có một **bộ gen ổn định**. ADN **bền hơn ARN nhiều** → là nơi lưu trữ thông tin tốt nhất.

Công cụ lý tưởng để chép thông tin ARN sang ADN là **enzym phiên mã ngược**:
- Phát hiện đầu tiên trong **virus gây ung thư** (retrovirus); từng tưởng chỉ có ở virus động vật có xương sống.
- Nay biết enzym này **phổ biến trong tự nhiên**: có ở ***Mycobacteria***, một số chủng ***E. coli***, và hầu hết Eukaryota.

→ Rất có thể sự chuyển từ **thế giới ARN sang thế giới ADN** đã nhờ một enzym kiểu phiên mã ngược.

> [!ung-dung] Phiên mã ngược trong y học
> - **HIV** là retrovirus: dùng enzym phiên mã ngược để chép bộ gen ARN thành ADN rồi cài vào ADN tế bào lympho T. Nhiều thuốc kháng HIV là **thuốc ức chế enzym phiên mã ngược** (zidovudin, tenofovir, efavirenz…). Virus **viêm gan B** cũng nhân lên qua bước phiên mã ngược nên cũng dùng tenofovir, entecavir.
> - Trong xét nghiệm, kỹ thuật **RT-PCR** dùng enzym phiên mã ngược chuyển ARN virus thành cADN rồi khuếch đại (ví dụ xét nghiệm SARS-CoV-2, đo tải lượng HIV, HCV).

#### 2.2.8. Khác biệt hóa học giữa ADN và ARN quyết định chức năng riêng

ADN và ARN polymerase nối nucleotid theo cùng một cách, vậy tại sao lại tách làm hai loại? Vì **ADN bền hơn về hóa học**:

| Đặc điểm | ARN | ADN | Hệ quả |
|---|---|---|---|
| Đường | **Ribose** (có **2'-OH**) | **Deoxyribose** (không có 2'-OH) | 2'-OH là điểm tấn công của enzym phân giải ARN; ở **pH cao** (kiềm), ARN bị cắt qua **2',3'-phosphat vòng**. ADN **không bị thủy phân kiềm** |
| Base | **Uracil** | **Thymin** | Cytosin dễ bị **khử amin → uracil**. Nếu ADN dùng U thì không phân biệt được U "thật" với U do lỗi. ADN dùng T nên mọi U trong ADN đều là lỗi → enzym sửa chữa nhận ra cặp **U–G**, thay U bằng C → **C–G** |
| Vai trò | Linh hoạt, nhiều chức năng (mang tin, xúc tác, cấu trúc) | **Bảo thủ**, lưu trữ thông tin ổn định | Sinh vật cần thông tin di truyền gần như hằng định để bảo tồn loài |

→ Đó là lý do sinh vật **chuyển thông tin vào ADN** bằng phiên mã ngược: ARN quá linh hoạt và dễ biến đổi, không thích hợp làm "kho lưu trữ" lâu dài.

> [!bay]
> - ADN bền nhờ **hai** điểm: **deoxyribose** (mất 2'-OH) và **thymin** (thay uracil). Đề hay hỏi "chi tiết nào giúp ADN không bị thủy phân trong kiềm" → **thiếu 2'-OH**, không phải thymin.
> - Khử amin **cytosin → uracil** (không phải thymin → uracil). Enzym sửa nhận ra cặp **U–G** và đổi thành **C–G**.

### 2.3. Tiến hóa sinh học sau tế bào

**Trình tự giả định** (theo giáo trình): tế bào đầu tiên → **Prokaryota** (sinh vật nhân sơ) đầu tiên (vi khuẩn) → vi khuẩn **sản xuất O~2~**, oxy hóa dần khí quyển → **Eukaryota** đầu tiên → **sinh vật đa bào** → **kỷ Cambri**: động, thực vật biển bùng nổ đa dạng. Sinh vật **dị dưỡng xuất hiện trước, tự dưỡng sau**.

**Bằng chứng hóa thạch:**

| Tuổi | Địa điểm | Hóa thạch |
|---|---|---|
| ~**3,5 tỷ năm** | **Fig Tree** (Nam Phi) | Sinh vật rất giống vi khuẩn hiện nay |
| ~**2 tỷ năm** | **Gunflint** (Canada) | Prokaryota: vi khuẩn và **vi khuẩn lam** |
| ~**1,4 tỷ năm** | Úc và một số nơi khác | **Eukaryota đơn bào** (tảo lục) lẫn trong quần thể vi khuẩn, vi khuẩn lam |

**Hai ngưỡng nồng độ O~2~ khí quyển:**

| Ngưỡng O~2~ | Ý nghĩa | Thời điểm (theo giáo trình) |
|---|---|---|
| **1%** | Tầng ozon đủ bảo vệ sự sống **trong nước** (ở độ sâu **30 cm**); **hô hấp** có thể xuất hiện. Sinh vật ở lớp nước mặt chịu tia tử ngoại → **tần số đột biến rất cao** | ~**700 triệu năm**: động vật hóa thạch đầu tiên; hơn 100 triệu năm sau: động vật dây sống đầu tiên (**cá giáp Ostracoderma**, đã tuyệt diệt); ≈500 triệu năm: hóa thạch biển rất đa dạng |
| **10%** | Màn chắn tử ngoại đủ cho sự sống **trên cạn** | ~**400 triệu năm**: rừng dương xỉ |

**Các mốc của động vật có xương sống:**
- ~**350 triệu năm**: lưỡng cư lớn (*Labyrinthodontia*).
- ≈50 triệu năm sau (≈300 triệu năm): **bò sát** — động vật có xương sống đầu tiên **sống hoàn toàn trên cạn**. Từ bò sát → **chim**.
- ~**225 triệu năm**: **thú (động vật có vú)** đầu tiên.
- Khủng long thống trị "hơn 200 triệu năm" (con số của giáo trình; theo niên đại hiện nay khoảng **165 triệu năm**, từ ~230 đến ~66 triệu năm trước).
- ~**65 triệu năm** (ranh giới kỷ Đệ nhị/Đệ tam, tức Phấn trắng/Đệ tam): **khủng long tuyệt diệt**, đồng thời **thú và chim (động vật hằng nhiệt)** phân hóa mạnh. Vỏ Trái Đất ở thời điểm này giàu bất thường các nguyên tố hiếm **iridi, osmi, paladi, platin** (**L. W. Alvarez, 1980**).

> [!cap-nhat] Nguyên nhân tuyệt chủng khủng long
> Giáo trình viết sự xuất hiện các nguyên tố hiếm kéo dài khoảng 250 nghìn năm "đã loại bỏ giả thuyết về những thảm họa", và nguồn gốc ngoài Trái Đất vẫn còn là giả thuyết. Hiện nay ngược lại: lớp **iridi bất thường** do nhóm Alvarez phát hiện chính là bằng chứng chủ chốt cho **giả thuyết thiên thạch va chạm**; năm 1991 đã xác định được **hố va chạm Chicxulub** (bán đảo Yucatán, Mexico), cùng tuổi với ranh giới, khoảng **66 triệu năm**. Đa số nhà khoa học cho rằng va chạm thiên thạch là nguyên nhân chính, có thể cộng thêm phun trào núi lửa quy mô lớn (Deccan, Ấn Độ). Trả lời thi theo giáo trình nếu câu hỏi trích nguyên văn.

> [!cap-nhat] Các mốc thời gian hiện nay
> - Hóa thạch/dấu vết vi sinh vật cổ nhất: khoảng **3,5 tỷ năm** (thống nhất với giáo trình), có thể sớm hơn.
> - O~2~ tăng mạnh lần đầu (**Sự kiện Oxy hóa Lớn**) khoảng **2,4 tỷ năm** trước, do **vi khuẩn lam** quang hợp.
> - Hóa thạch Eukaryota chắc chắn cổ nhất khoảng **1,6–1,8 tỷ năm** (ước tính từ đồng hồ phân tử có thể sớm hơn), tức sớm hơn mốc 1,4 tỷ năm của giáo trình.
> - "Bùng nổ kỷ Cambri" khoảng **540 triệu năm** trước (ranh giới kỷ Cambri theo Ủy ban Địa tầng Quốc tế: ≈ 538,8 triệu năm); trước đó đã có quần động vật Ediacara (≈575 triệu năm).
> - **Tổ tiên chung phổ quát cuối cùng (LUCA)** của mọi sinh vật hiện nay: một nghiên cứu lớn (Moody và cộng sự, *Nature Ecology & Evolution*, 2024) ước tính LUCA sống khoảng **4,2 tỷ năm** trước, tức chỉ vài trăm triệu năm sau khi Trái Đất hình thành (≈ 4,54 tỷ năm). LUCA được suy đoán là một tế bào **nhân sơ yếm khí**, đã có bộ gen ADN, ribosom, mã di truyền như hiện nay và cả một dạng **hệ CRISPR** chống virus, sống trong một quần xã vi sinh vật. Nghĩa là LUCA **đã là tế bào khá hoàn chỉnh**, không phải Protobionta; giai đoạn thế giới ARN phải xảy ra trước đó. Con số 4,2 tỷ năm còn nhiều bất định.

#### ADN ty thể và cái nôi của loài người

**Đặc điểm ADN ty thể (theo giáo trình):**
- Di truyền **hoàn toàn theo dòng mẹ**: noãn chứa **400–20 000 ty thể**; tinh trùng chỉ có vài ty thể, khi thụ tinh chỉ có nhân tinh trùng đi vào, phần bào tương ít ỏi ở lại bên ngoài.
- Tần số đột biến **cao gấp 10 lần** ADN nhân.
- **Không tái tổ hợp**.
→ Dòng tiến hóa của ADN ty thể **độc lập** với ADN nhân; lần theo nó sẽ tìm được **"người mẹ" chung** đầu tiên.

**Kết quả:** phân tích ADN ty thể người ở **5 vùng** (châu Phi, châu Á, châu Âu, châu Úc, Tân Ghinê): ADN ty thể châu Phi **đa dạng nhất**; một nhánh trong đó sinh ra các dân tộc ở mọi châu lục; mọi nhánh của cây phát sinh **hội tụ về một gốc duy nhất ở châu Phi** → củng cố giả thuyết **châu Phi là cái nôi của loài người** (vốn đã có bằng chứng cổ sinh vật học).

*Vì sao vùng đa dạng nhất lại là gốc?* Quần thể sống lâu nhất ở một nơi thì có **nhiều thời gian tích lũy đột biến nhất**. Các nhóm di cư đi sau chỉ mang theo một phần nhỏ sự đa dạng đó.

> [!cap-nhat] "Eva ty thể" và ty thể của tinh trùng
> - Nghiên cứu này (Cann, Stoneking và Wilson, 1987) ước tính tổ tiên chung theo dòng mẹ của mọi người hiện nay (**"Eva ty thể"**) sống ở châu Phi khoảng **150–200 nghìn năm** trước. Đây là tổ tiên chung gần nhất theo dòng mẹ, **không** phải người phụ nữ duy nhất thời đó.
> - Giáo trình viết chỉ có nhân tinh trùng vào noãn. Hiện nay biết ở người **toàn bộ tinh trùng** (kể cả khoảng vài chục ty thể ở đoạn giữa) đi vào noãn, nhưng ty thể tinh trùng **bị đánh dấu và phân hủy chủ động** sau thụ tinh. Kết luận "ADN ty thể di truyền theo dòng mẹ" vẫn đúng.

> [!ung-dung] ADN ty thể trong y học và pháp y
> - **Bệnh do đột biến ADN ty thể** di truyền theo dòng mẹ: mẹ bệnh → mọi con có thể bị; bố bệnh → không truyền cho con. Ví dụ: **bệnh thần kinh thị giác di truyền Leber (LHON)**, **MELAS** (bệnh não – cơ, nhiễm toan lactic, cơn giống đột quỵ). Mô tiêu tốn nhiều năng lượng (cơ, thần kinh, mắt) bị nặng nhất.
> - **Pháp y**: ADN ty thể có hàng trăm đến hàng nghìn bản sao mỗi tế bào và bền, nên dùng được với mẫu cũ, mẫu xương, tóc; giúp **xác định danh tính hài cốt** bằng cách so với họ hàng bên ngoại.

### 2.4. Mở rộng: nguồn gốc tế bào nhân thực — thuyết nội cộng sinh

Giáo trình nói Eukaryota xuất hiện sau Prokaryota nhưng chưa giải thích bằng cách nào. Phần này bổ sung kiến thức hiện đại (xem thêm bài Màng tế bào và tế bào chất, mục Ty thể).

![Hình 3. Thuyết nội cộng sinh: nguồn gốc ty thể và lục lạp](noi-cong-sinh.svg)

> [!cap-nhat] Thuyết nội cộng sinh (endosymbiotic theory)
> Được **Lynn Margulis** phát triển và phổ biến từ năm **1967** (ban đầu bị nhiều người phản đối), nay là quan điểm được đồng thuận:
> 1. Một tế bào chủ thuộc **vi khuẩn cổ – Archaea**, cụ thể là nhóm **Asgard archaea** (phát hiện từ năm 2015 qua giải trình tự ADN môi trường; năm 2020 lần đầu nuôi cấy được; phân tích năm 2023 trên *Nature* xếp tổ tiên nhân thực **nằm hẳn bên trong** nhóm Asgard, gần nhánh Heimdallarchaeia), nhận vào một **vi khuẩn hiếu khí** (họ hàng của **α-proteobacteria**) nhưng không tiêu hóa nó. Asgard archaea đã có sẵn nhiều gen "kiểu nhân thực" (như actin, protein vận chuyển màng), giúp giải thích bước chuyển này.
> 2. Hai bên cùng có lợi: vi khuẩn được che chở và nhận chất dinh dưỡng; tế bào chủ nhận nhiều **ATP** nhờ hô hấp hiếu khí — rất quan trọng khi O~2~ khí quyển tăng. Vi khuẩn này dần trở thành **ty thể**.
> 3. Về sau, một dòng tế bào đã có ty thể nuốt tiếp **vi khuẩn lam** quang hợp → **lục lạp** → tổ tiên của tảo và thực vật.
> 4. Phần lớn gen của vi khuẩn cộng sinh **chuyển dần vào nhân** tế bào chủ, nên ty thể và lục lạp chỉ còn **bán tự trị**.

**Bằng chứng** ty thể và lục lạp vốn là vi khuẩn:

| Đặc điểm | Ty thể / lục lạp | Vi khuẩn |
|---|---|---|
| Màng | **Màng kép**; màng trong giống màng vi khuẩn (ty thể có cardiolipin) | Màng sinh chất giống màng trong |
| ADN | **Vòng, trần** (không có histon) | Vòng, trần |
| Ribosom | **70S** | 70S |
| Sinh sản | **Phân đôi**, không tạo mới từ đầu | Phân đôi |
| Khởi đầu dịch mã | **N-formylmethionin** | N-formylmethionin |
| Nhạy cảm kháng sinh | Bị ức chế bởi một số kháng sinh diệt khuẩn | Có |
| Trình tự gen | Gần **α-proteobacteria** (ty thể) và **vi khuẩn lam** (lục lạp) | — |

*Vì sao màng kép?* Màng trong là màng gốc của vi khuẩn; màng ngoài có nguồn gốc từ màng tế bào chủ khi nuốt (hoặc từ màng ngoài của vi khuẩn Gram âm).

> [!ung-dung] Kháng sinh và ty thể
> Vì ribosom ty thể giống ribosom vi khuẩn, một số kháng sinh nhắm vào ribosom vi khuẩn cũng ảnh hưởng ty thể người:
> - **Cloramphenicol** ức chế tổng hợp protein ty thể → góp phần gây **ức chế tủy xương**.
> - **Aminoglycosid** (gentamicin, amikacin) gây **điếc**; người mang đột biến **m.1555A>G** trên gen rARN 12S ty thể (di truyền theo dòng mẹ) rất dễ bị điếc dù chỉ dùng liều thường. Vì vậy hỏi tiền sử gia đình bên mẹ bị điếc do thuốc trước khi dùng aminoglycosid là rất quan trọng.
> - **Linezolid** dùng kéo dài có thể gây **nhiễm toan lactic**, bệnh thần kinh thị giác.

## 3. Các thuyết tiến hóa chính

**Tiến hóa sinh học** nghiên cứu sự phát sinh, phát triển của sinh giới **ở mọi cấp tổ chức**: đại phân tử → tế bào → cơ quan → hệ cơ quan → cơ thể → quần thể → quần xã → hệ sinh thái. Trọng tâm: sự hình thành sự sống, **hình thành loài mới**, dẫn đến đa dạng sinh giới, tổ chức ngày càng hoàn thiện và thích nghi ngày càng hợp lý.

| | **Tiến hóa nhỏ** (microevolution) | **Tiến hóa lớn** (macroevolution) |
|---|---|---|
| Nghiên cứu | Nguyên nhân, cơ chế **hình thành loài mới** | Nguyên nhân, cơ chế hình thành **đơn vị trên loài**: chi, họ, bộ, lớp, ngành |
| Quy mô | Trong quần thể, thời gian tương đối ngắn | Phạm vi rộng, **thời gian địa chất dài** |
| Cách nghiên cứu | Quan sát, thực nghiệm được | **Gián tiếp**: cổ sinh vật học, giải phẫu so sánh, địa lý sinh vật |

### 3.1. Tiến hóa lớn — các học thuyết

| Học thuyết | Nội dung chính | Hạn chế |
|---|---|---|
| **Mục đích luận** (đến cuối thế kỷ XVII) | Mọi loài do **thượng đế tạo ra cùng một lần**, hợp lý ngay từ đầu, theo mục đích định sẵn, **không biến đổi** | Bị bác bỏ bởi phân loại học, hình thái học và giải phẫu so sánh thế kỷ XVII–XVIII |
| **Biến đổi luận** | Từ **một mẫu cấu tạo chung**, các loài trong một ngành biến đổi chi tiết cho phù hợp đất đai, khí hậu, thức ăn | Chưa giải thích được cơ chế |
| **Lamarck** | Tiến hóa là **phát triển có kế thừa lịch sử**, theo hướng **ngày càng hoàn thiện** | Sai: cho rằng **không loài nào bị đào thải** và mọi cá thể trong loài **phản ứng giống nhau** trước điều kiện mới |
| **Darwin** | Tiến hóa do **chọn lọc tự nhiên**: chỉ cá thể **thích nghi** mới sống sót, sinh trưởng, sinh sản | Chưa giải thích được nguồn gốc biến dị và cơ chế di truyền |
| **Thuyết đột biến** | **Đột biến là động cơ duy nhất**; tiến hóa bằng **bước nhảy vọt**, loài mới xuất hiện trực tiếp từ loài trước | Không giải thích được **tính thích nghi**; đột biến ngẫu nhiên, hiếm khi có lợi |
| **Thuyết tiến hóa tổng hợp** (1930–1950) | **Đột biến** tạo biến dị + **chọn lọc tự nhiên** sàng lọc kiểu gen thích nghi ở từng thế hệ. Kết hợp **di truyền học, phân loại học, cổ sinh vật học**. Xem sinh vật là **thành viên của quần thể**, không phải cá thể biệt lập | — |

> [!bay]
> - Sai lầm của **Lamarck** theo giáo trình: "không loài nào bị đào thải" và "mọi cá thể phản ứng giống nhau". Không nhầm với Darwin.
> - **Thuyết đột biến** (thường gắn với Hugo de Vries) cho đột biến là động lực **duy nhất**; thuyết **tổng hợp** coi đột biến chỉ là **nguồn nguyên liệu**, còn **chọn lọc** mới định hướng.
> - Đơn vị tiến hóa của thuyết tổng hợp là **quần thể**, không phải cá thể hay loài.

### 3.2. Tiến hóa nhỏ

**Quần thể là đơn vị tiến hóa cơ sở.** Định nghĩa (Yablokov, 1986): quần thể là **nhóm cá thể cùng loài**, chung sống **lâu dài** trong **khu vực xác định**, là **đơn vị sinh sản tự nhiên nhỏ nhất** của loài, có **hệ thống di truyền độc lập**. Quần thể là đơn vị tồn tại và đơn vị sinh sản của loài.

- Có **quần thể tự phối** và **quần thể giao phối**.
- Giao phối làm quần thể **đa dạng kiểu gen → đa dạng kiểu hình**. Cá thể chỉ giống nhau ở nét cơ bản, khác nhau nhiều chi tiết.

**Định luật Hardy – Weinberg:** trong những điều kiện nhất định, **tần số tương đối các alen** của mỗi gen trong **quần thể giao phối** có khuynh hướng **duy trì không đổi** qua các thế hệ.

- Phản ánh **trạng thái cân bằng (tĩnh)** của quần thể.
- Giải thích vì sao nhiều quần thể giữ ổn định lâu dài. Trong tiến hóa, **duy trì những đặc điểm đã đạt được** cũng quan trọng như phát sinh đặc điểm mới.

> [!vi-du] Công thức Hardy – Weinberg
> Gen có 2 alen A (tần số p) và a (tần số q), p + q = 1. Ở trạng thái cân bằng, tần số kiểu gen là:
> => p^2^ AA + 2pq Aa + q^2^ aa = 1
> Điều kiện cân bằng: quần thể **rất lớn**, **giao phối ngẫu nhiên**, **không đột biến**, **không chọn lọc**, **không di nhập gen**. Mọi nhân tố tiến hóa ở mục 3.3 chính là những gì **phá vỡ** các điều kiện này.
>
> **Ví dụ y học:** một bệnh lặn trên NST thường có tần số người bệnh (aa) là 1/10 000 → q^2^ = 1/10 000 → q = 1/100 → p ≈ 0,99 → tần số người lành mang gen (Aa) = 2pq ≈ **1/50**. Người mang gen bệnh nhiều gấp khoảng 200 lần người bệnh — đây là cơ sở để tư vấn di truyền và sàng lọc người mang gen (ví dụ bệnh thalassemia ở Việt Nam).

### 3.3. Các nhân tố tiến hóa cơ bản

Giáo trình chia thành **4 nhóm**:

| Nhóm | Nhân tố | Vai trò |
|---|---|---|
| 1. Tạo **nguồn nguyên liệu** | **Quá trình đột biến** | Nguyên liệu **sơ cấp**; tạo áp lực làm biến đổi cấu trúc di truyền quần thể |
| | **Quá trình giao phối** | Phát tán đột biến, tạo **biến dị tổ hợp** = nguyên liệu **thứ cấp** |
| 2. Ảnh hưởng **vốn gen** | **Du nhập gen** (di cư) | Gen lan từ quần thể này sang quần thể khác qua giao phối → đổi vốn gen của quần thể nhận |
| 3. **Định hướng** tiến hóa | **Chọn lọc tự nhiên** | Giữ lại cá thể thích nghi nhất |
| 4. Tăng **phân hóa**, làm quần thể phân ly | **Cơ chế cách ly** | Hạn chế hoặc chặn trao đổi gen giữa các nhóm |

#### 3.3.1. Đột biến và giao phối

- **Đột biến**: ở loài giao phối, chỉ **đột biến giao tử** và **đột biến tiền phôi** mới di truyền cho đời sau; **đột biến soma** chỉ tồn tại trong đời cá thể đó.
- **Giao phối**: làm đột biến **lan rộng** trong quần thể và tạo **biến dị tổ hợp**.
- Cả hai tạo nguồn nguyên liệu phong phú cho chọn lọc tự nhiên.

> [!ung-dung] Đột biến soma và ung thư
> Ung thư phần lớn do **đột biến soma** tích lũy trong một dòng tế bào (ví dụ do thuốc lá, tia cực tím). Các đột biến này **không truyền cho con**. Ngược lại, đột biến **dòng mầm** như *BRCA1/2* có trong mọi tế bào và di truyền được → ung thư vú – buồng trứng có tính gia đình. Đây đúng là phân biệt "đột biến soma / đột biến giao tử" của giáo trình.

#### 3.3.2. Du nhập gen (di cư)

Một số cá thể từ quần thể cho giao phối với cá thể của quần thể nhận → **gen mới lan vào** quần thể nhận → thay đổi vốn gen. Chọn lọc sau đó tiếp tục thay đổi tần số gen.

#### 3.3.3. Chọn lọc tự nhiên — nhân tố định hướng

- **Darwin và Wallace** là những người đầu tiên coi chọn lọc tự nhiên là nhân tố tiến hóa cơ bản.
- **Quan niệm của Darwin**: nguyên liệu của chọn lọc là **biến dị cá thể** qua sinh sản và cả **biến đổi do điều kiện sống hay tập quán hoạt động**. Kết quả: **sống sót** của cá thể thích nghi nhất.
- **Thuyết tiến hóa hiện đại** làm sáng tỏ 2 điểm Darwin chưa giải quyết: (1) **nguyên nhân và bản chất của biến dị**; (2) **cơ chế di truyền biến dị**. Theo đó, chỉ **biến dị di truyền được** (đột biến, biến dị tổ hợp) mới là nguyên liệu của chọn lọc. Kết quả của chọn lọc là sự **tồn tại, sinh trưởng và ưu thế sinh sản** của cá thể thích nghi nhất.

> [!bay]
> Darwin: kết quả chọn lọc là **sống sót** của cá thể thích nghi nhất. Thuyết hiện đại nhấn mạnh **ưu thế sinh sản** (để lại nhiều con cháu hơn). Darwin còn coi biến đổi do tập quán/điều kiện sống là nguyên liệu; thuyết hiện đại chỉ chấp nhận **biến dị di truyền được**.

> [!ung-dung] Chọn lọc tự nhiên ngay trong bệnh viện
> - **Vi khuẩn kháng kháng sinh**: trong quần thể vi khuẩn có sẵn vài tế bào mang đột biến (hoặc plasmid) kháng thuốc. Dùng kháng sinh không đủ liều, không đủ thời gian sẽ **diệt con nhạy cảm và giữ lại con kháng** → chủng kháng chiếm ưu thế (MRSA, vi khuẩn sinh ESBL…). Đây là lý do phải dùng kháng sinh đúng chỉ định, đủ liều, đủ ngày.
> - **Hồng cầu hình liềm và sốt rét**: người dị hợp HbA/HbS ít bị sốt rét nặng, nên ở vùng sốt rét lưu hành alen HbS được chọn lọc giữ lại với tần số cao dù người đồng hợp bị bệnh nặng.

#### 3.3.4. Cơ chế cách ly — tăng phân hóa trong quần thể

Cách ly làm **trao đổi gen** giữa các quần thể (hoặc giữa các nhóm tách ra từ một quần thể gốc) **bị hạn chế hoặc cắt đứt hoàn toàn**.

| Loại cách ly | Nội dung |
|---|---|
| **Cách ly không gian (địa lý)** | Quần thể bị ngăn cách bởi **chướng ngại địa lý** (núi, sông, biển) |
| **Cách ly sinh thái** | Cùng khu vực địa lý nhưng mỗi nhóm thích ứng với **điều kiện sinh thái khác nhau** |
| **Cách ly sinh sản** | (a) **Không giao phối được**; (b) giao phối được nhưng: không thụ tinh, hoặc thụ tinh nhưng **hợp tử chết**, hoặc con **chết sớm/muộn**, hoặc con **không có khả năng sinh sản** |

**Cách ly sinh sản** là nhân tố quan trọng **kết thúc quá trình tiến hóa nhỏ**, đánh dấu **loài mới** đã hình thành. *Vì sao?* Khi hai nhóm không còn trao đổi gen được nữa, mỗi nhóm tiến hóa theo đường riêng và không thể "hòa" trở lại.

> [!cap-nhat] Các nhân tố tiến hóa theo cách trình bày hiện nay
> Giáo trình liệt kê 4 nhóm như trên. Sách sinh học hiện nay thường kể các nhân tố làm thay đổi tần số alen/thành phần kiểu gen của quần thể gồm: **đột biến, di – nhập gen, chọn lọc tự nhiên, các yếu tố ngẫu nhiên (phiêu bạt di truyền) và giao phối không ngẫu nhiên**. Nhân tố **phiêu bạt di truyền** (thay đổi tần số alen do ngẫu nhiên, mạnh ở quần thể nhỏ, như **hiệu ứng kẻ sáng lập** và **hiệu ứng thắt cổ chai**) chưa có trong giáo trình. Cách ly được coi là điều kiện để hình thành loài hơn là một nhân tố làm thay đổi tần số alen.

> [!cap-nhat] Sau thuyết tiến hóa tổng hợp (bổ sung – kiến thức hiện nay)
> - **Thuyết trung tính** (Motoo Kimura, 1968): ở mức phân tử, phần lớn đột biến được giữ lại trong quần thể là **trung tính** (không lợi, không hại) và lan rộng hay mất đi chủ yếu nhờ **phiêu bạt ngẫu nhiên**, không phải nhờ chọn lọc. Đây là cơ sở của **"đồng hồ phân tử"** dùng để ước tính thời điểm các loài tách nhau (như ước tính tuổi "Eva ty thể", tuổi LUCA ở trên). Thuyết này **bổ sung** chứ không bác bỏ chọn lọc tự nhiên: các tính trạng thích nghi vẫn do chọn lọc định hướng.
> - **Truyền gen ngang** (giữa các loài, nhất là ở vi khuẩn qua plasmid, virus) làm "cây" tiến hóa của vi sinh vật giống một **mạng lưới** hơn.
> - **Tổng hợp tiến hóa mở rộng** (Extended Evolutionary Synthesis, Laland và cộng sự, 2015): một số nhà khoa học đề nghị đưa thêm vào lý thuyết vai trò của **phát triển cá thể** (evo-devo), **tính mềm dẻo kiểu hình**, **di truyền ngoài gen** (biểu sinh, văn hóa) và **xây dựng ổ sinh thái** (sinh vật tự cải tạo môi trường của mình). Đây là **đề xuất còn tranh luận**; đa số vẫn xem chúng là phần mở rộng của thuyết tổng hợp chứ không phải một thuyết thay thế. Lưu ý: biểu sinh **không** có nghĩa là Lamarck đúng — phần lớn dấu ấn biểu sinh bị xóa qua các thế hệ ở động vật có vú.

## Tóm tắt

| Nội dung | Điểm cốt lõi |
|---|---|
| Giả thuyết nền | **Haldane – Oparin** (1920–1930): tổng hợp tiền sinh học; khí quyển nguyên thủy **không O~2~, không ozon**; giáo trình: trung tính (CH~4~, NH~3~, H~2~O, CO, CO~2~) |
| Đơn phân sống | Miller 1953 và cộng sự: năng lượng (tử ngoại, tia lửa điện, phóng xạ, nhiệt) → HCN, HCHO, acid acetic → acid amin, đường, base, nucleotid, ATP; thêm nguồn vũ trụ (Calvin 1974) |
| Polyme sống | 1/10 triệu năng lượng Mặt Trời → 10 kg/m^2^/5 triệu năm; **Fox**: 18 acid amin, 170 °C → protein không sống; **Schramm**: 60 °C → polynucleotid 20–200; **Oró – Kimball 1971**: đất sét + cyanamid → 5–10 nucleotid; thiên thạch **Murchison 1969**; sao chổi **Halley 1986** |
| Coacerva – Protobionta | Oparin: giọt coacerva có màng; Fox: hạt cầu vi thể 2–3 µm; liposom màng lipid kép; vẫn cần ≈10 000 protein để thành vi khuẩn |
| ARN có trước | Orgel, Crick, Woese (cuối 1960s): ARN tự nhân đôi + xúc tác; deoxyribonucleotid từ ribonucleotid; phiên mã ngược phổ biến → **thế giới ARN** |
| Tổng hợp ARN | Ribose từ **phản ứng formose**; urê + NH~4~Cl + phosphat + hydroxyapatit, 100 °C, 24 giờ → ribonucleotid |
| Mã nguyên thủy | U giữa → kỵ nước; A giữa → ưa nước; khác nhau ở chữ thứ 3 → mã 3 chữ dùng 2 chữ đầu; ribosom nguyên thủy bằng ARN |
| Ribozym | **ARNase P** (*E. coli*): ARN 375 nu tự xúc tác cắt tỉa tiền tARN^Tyr^; protein che điện tích; ribozym ≈350 nu ở nhiều loài |
| Hiệu chỉnh ARN | Ty thể *Leishmania, Trypanosoma, Crithidia*: thêm/bớt U; A-G → AUG |
| ARN → ADN | ADN bền (không 2'-OH, có T thay U); chuyển thông tin nhờ **phiên mã ngược** |
| Sau tế bào | Prokaryota (3,5 tỷ năm, Fig Tree) → O~2~ tăng → Eukaryota (1,4 tỷ năm theo giáo trình) → đa bào; ngưỡng O~2~ 1% (sống trong nước) và 10% (lên cạn); tuyệt chủng 65 triệu năm, iridi (Alvarez 1980). *Hiện nay: LUCA ≈ 4,2 tỷ năm; Eukaryota ≈ 1,6–1,8 tỷ năm; va chạm Chicxulub 66 triệu năm* |
| ADN ty thể | Dòng mẹ, đột biến gấp 10, không tái tổ hợp → nguồn gốc châu Phi |
| Nội cộng sinh (bổ sung) | Tế bào chủ: Asgard archaea; ty thể ← α-proteobacteria; lục lạp ← vi khuẩn lam; bằng chứng: màng kép, ADN vòng, ribosom 70S, phân đôi |
| Thuyết tiến hóa | Mục đích luận → biến đổi luận → Lamarck → Darwin → thuyết đột biến → **thuyết tổng hợp** (1930–1950, đơn vị là quần thể). *Bổ sung: thuyết trung tính (Kimura 1968), tổng hợp mở rộng (còn tranh luận)* |
| Tiến hóa nhỏ / lớn | Nhỏ → loài mới; lớn → chi, họ, bộ, lớp, ngành; Hardy – Weinberg: tần số alen không đổi trong điều kiện nhất định |
| Nhân tố tiến hóa | Đột biến (sơ cấp) + giao phối (thứ cấp); du nhập gen; **chọn lọc tự nhiên** (định hướng); **cách ly** (địa lý, sinh thái, sinh sản → kết thúc tiến hóa nhỏ) |
