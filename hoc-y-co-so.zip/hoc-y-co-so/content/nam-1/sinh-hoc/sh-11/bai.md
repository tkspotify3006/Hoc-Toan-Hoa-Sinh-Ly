---
title: Quá trình phát triển cá thể
thoi-gian: 45 phút
muc-tieu:
- Mô tả được cấu tạo tinh trùng (đầu, cổ, đuôi) và phân biệt được các loại trứng theo lượng và sự phân bố noãn hoàng.
- Nêu được định nghĩa và đặc điểm của các giai đoạn phôi thai, sinh trưởng, trưởng thành, già lão và tử vong.
- Nêu được đặc điểm phân cắt và phát triển phôi của trứng đẳng hoàng, đoạn hoàng và vô hoàng; kể được các cơ quan hình thành từ mỗi lá phôi.
- Phân biệt được sinh sản vô tính, hữu tính và các hình thức sinh sản đặc biệt (đơn tính sinh, mẫu sinh, phụ sinh…).
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Phát triển cá thể ở động vật có xương sống gồm **7 giai đoạn**: tạo giao tử → tạo hợp tử (thụ tinh) → **phôi thai** → sinh trưởng → trưởng thành → già lão → tử vong.
> 2. Phôi thai qua 3 bước: **phân cắt** (phôi dâu → phôi nang) → **phôi vị hóa** (phôi 2 lá → 3 lá, phát sinh mầm cơ quan) → **tạo hình cơ quan**.
> 3. Kiểu phân cắt do **noãn hoàng** quyết định: đẳng hoàng → hoàn toàn, **đều**; đoạn hoàng trung bình (ếch) → hoàn toàn, **không đều**; đoạn hoàng nhiều (chim) → **không hoàn toàn**; vô hoàng (thú) → hoàn toàn, không đều, một phần thành **lá nuôi → rau thai**.
> 4. **Ngoài** → da, thần kinh, giác quan; **Giữa** → cơ, xương, máu, tim mạch, niệu – sinh dục; **Trong** → lớp lót ống tiêu hóa, hô hấp và các tuyến của chúng.
> 5. Sinh trưởng: **đồng hóa > dị hóa**; trưởng thành: đồng hóa ≈ dị hóa, sinh dục hiệu quả; già lão: **dị hóa > đồng hóa**, các cơ quan già **không đồng đều**.

## 1. Khái quát

### 1.1. Sinh học phát triển là gì

**Sinh học phát triển** nghiên cứu các **quy luật** phát triển cá thể của sinh vật, cùng các **nhân tố** và **cơ chế** điều khiển sự phát triển ở mọi giai đoạn.

Nhánh **ứng dụng** của nó khai thác thực tiễn của trinh sản, mẫu sinh, phụ sinh, nhân bản vô tính, điều khiển giới tính, cấy truyền hợp tử và **tế bào gốc** để phục vụ y học, nông nghiệp, đời sống.

**Quá trình phát triển cá thể** là toàn bộ chặng đường của một cá thể: từ lúc hình thành **mầm sống** (giao tử, bào tử hoặc một nhóm tế bào sinh dưỡng), qua các giai đoạn phát triển, cho tới khi **già và chết**.

Cá thể mới chỉ ra đời nhờ **sinh sản**. Vì thế, học về phát triển cá thể là học cả chuỗi: tạo giao tử → hợp tử → phôi thai → (sau khi sinh) sinh trưởng → trưởng thành → già lão → tử vong, cùng các cơ chế điều chỉnh.

### 1.2. Sinh sản dựa trên ba yếu tố

| Yếu tố | Vì sao cần? |
|---|---|
| **Tăng trưởng** | Nếu cơ thể không lớn lên về khối lượng, kích thước thì mỗi lần sinh sản, đời con lại nhỏ hơn → nòi giống tự tiêu vong. |
| **Di truyền** | Để đời con lặp lại các đặc điểm của bố mẹ, tổ tiên, của loài. |
| **Phát triển** | Chuỗi biến đổi liên tiếp, đưa một (hoặc một nhóm) tế bào **đơn giản, đa tiềm năng** thành cơ thể đa bào **phân hóa** hoàn chỉnh. |

*Lưu ý:* ở sinh vật **đơn bào**, sinh sản **không kèm** phát triển (tế bào con giống tế bào mẹ, không có biệt hóa).

## 2. Các phương thức sinh sản

Sinh sản giúp loài tồn tại, tạo cá thể mới thay thế cá thể chết đi. Dựa vào **bản chất di truyền**, chia hai phương thức chính: **vô tính** và **hữu tính**.

### 2.1. Sinh sản vô tính

- **Định nghĩa:** chỉ từ **một nguồn mẹ**, đời con mang bộ gen **sao chép nguyên bản** của mẹ, thường không có tái tổ hợp di truyền. Cơ sở tế bào học: **nguyên phân**.
- **Đặc điểm:** từ một hoặc một nhóm tế bào của mẹ → một hay nhiều cơ thể **giống hệt mẹ và giống hệt nhau**; không có sự phối hợp vật chất di truyền của giao tử đực và cái.
- **Hình thức:** phân đôi, nảy chồi, cắt đốt, bào tử.

### 2.2. Sinh sản hữu tính

- **Định nghĩa:** luôn có **tái tổ hợp di truyền** do kết hợp **hai bộ gen** của hai giao tử (cùng nguồn hoặc khác nguồn). Cơ sở tế bào học: **giảm phân + thụ tinh**.
- **Đặc điểm:** giao tử đực + giao tử cái → **hợp tử** → cơ thể mới. Bộ gen được tổ hợp từ hai nguồn, thường từ hai cơ thể khác nhau → nhiều **biến dị tổ hợp**, **sức sống mạnh**.

**Các khuynh hướng tiến hóa trong sinh sản hữu tính**

1. **Phân hóa cấu trúc – chức năng:**
   - *Tế bào trong cơ thể:* từ chỗ tế bào nào cũng sinh sản được → tách thành hai dòng: **dòng sinh dục** và **dòng sinh dưỡng**.
   - *Giao tử:* **đẳng giao** (hai giao tử giống nhau, ở sinh vật bậc thấp) → **dị giao** (giao tử đực nhỏ, di động hơn) → **noãn giao** (cao nhất): tinh trùng rất nhỏ, bơi nhanh; trứng rất lớn, **không di động**, chứa **noãn hoàng**, chất dự trữ và các **tổ chức tố (cảm ứng tố) cơ sở** cho phôi biệt hóa sau này.
   - *Giới tính:* **lưỡng tính** (hai loại cơ quan sinh dục trên một cơ thể; có thể tự thụ nhưng thường tiến tới thụ chéo) → **đơn tính** (mỗi cơ thể chỉ đực hoặc cái; **bắt buộc** thụ tinh chéo).
2. **Phương thức thụ tinh:** **thụ tinh ngoài** trong nước, hiệu quả thấp (ruột túi, cá; ếch đực tưới tinh lên trứng) → **thụ tinh trong** nhờ cơ quan giao cấu, hiệu quả cao (đa số động vật bậc cao ở cạn).
3. **Bảo vệ phôi:** cá, lưỡng cư đẻ trứng trong nước, ít bảo vệ → bò sát đẻ trứng có **vỏ** → chim làm tổ, ấp, chăm con → thú: phôi phát triển trong **tử cung**, sau sinh còn **cho bú**.

### 2.3. Các hình thức sinh sản đặc biệt

| Hình thức | Bản chất | Ví dụ trong sách |
|---|---|---|
| **Tiếp hợp** | Hai cá thể đơn bào áp vào nhau, **trao đổi** vật chất di truyền của hai nhân → hai tế bào được "**thanh xuân hóa**" | Trùng lông, vi khuẩn |
| **Nội hợp** | "Thanh xuân hóa" **ngay trên một cá thể**: nhân chia ra rồi các nhân con của chính nó tổ hợp lại | Một số đơn bào già cỗi |
| **Lưỡng tính sinh** | Một cơ thể có cả cơ quan sinh dục đực và cái | Sán dây (**tự thụ tinh**: đốt gần đầu thụ tinh cho đốt cuối); sán lá, giun đất (lưỡng tính nhưng **thụ tinh chéo**); đậu Hà Lan (tự thụ phấn) |
| **Đơn tính sinh** (trinh sản) | Trứng (tạo ra **qua giảm phân**) **không thụ tinh** vẫn phát triển thành cơ thể | Ong, rệp, luân trùng… |
| **Mẫu sinh** | Trứng **có thụ tinh**, nhưng **nhân tinh trùng thoái hóa**; chỉ nhân trứng phát triển. Tinh trùng chỉ để **hoạt hóa** trứng | Cá diếc bạc (thụ tinh với cá chép đực… vẫn chỉ ra cá diếc bạc cái) |
| **Phụ sinh** | Trứng có thụ tinh, nhưng **nhân trứng thoái hóa**; chỉ nhân tinh trùng phát triển | Tạo giống **tằm** cao sản |

> [!bay]
> - **Đơn tính sinh ≠ sinh sản vô tính.** Trứng đơn tính sinh vẫn sinh ra từ **giảm phân** của tế bào sinh dục; sinh sản vô tính dựa trên **nguyên phân**.
> - **Mẫu sinh** = chỉ giữ nhân **mẹ** (trứng). **Phụ sinh** = chỉ giữ nhân **bố** (tinh trùng). Nhớ "mẫu = mẹ, phụ = cha".
> - Tiếp hợp cần **hai** cá thể; nội hợp chỉ **một**.

#### Đơn tính sinh — các kiểu cần nhớ

**Theo bộ NST (nhiễm sắc thể) của cơ thể con:**
- *Đơn bội:* cơ thể trưởng thành giữ nguyên bộ **n** của trứng.
- *Lưỡng bội:* bộ NST được phục hồi thành **2n**, nhưng **đồng hợp tử** hoàn toàn vì cả hai bộ đều nhân đôi từ một bộ n của mẹ.

**Theo giới tính của con:**

1. **Đơn tính sinh đực (kiểu ong).** Tổ ong có một **ong chúa** (cái, đẻ trứng), nhiều **ong thợ** (cái, cơ quan sinh dục thoái hóa) và **ong đực**. Ong chúa trữ tinh trùng trong **túi chứa tinh**, có cơ thắt điều khiển. Trứng **không thụ tinh → ong đực**; trứng **được thụ tinh → ong cái**. Ấu trùng cái chỉ ăn mật, phấn hoa → ong thợ; được ăn thêm chất tiết của ong thợ → **ong chúa**.
2. **Đơn tính sinh cái.** Một số loài ốc, tôm, cua chỉ có con cái. Tế bào 2n được tạo lại bằng một trong ba cách:
   - lần nguyên phân đầu tiên của trứng, **tế bào chất không chia** → tế bào 2n;
   - ở **giảm phân I, NST không phân ly** → trứng 2n (sách nêu ví dụ tôm, thỏ);
   - giảm phân bình thường, nhưng **cực cầu II hòa nhập lại** với trứng → 2n.
3. **Đơn tính sinh chu kỳ.** Xen kẽ mùa sinh đơn tính với mùa sinh hữu tính. Ví dụ **luân trùng**: mùa xuân, trứng qua đông nở ra con cái; con cái đẻ trứng không thụ tinh → con cái. Đến thời kỳ hữu tính, một thế hệ đẻ trứng nhỏ hơn → **con đực**; con đực giao phối với con cái → trứng thụ tinh **2n**, chịu được mùa đông.

**Đơn tính sinh nhân tạo:** kích thích trứng không cần tinh trùng. Trứng ếch: **châm kim**. Trứng cầu gai: **lắc** hoặc **hóa chất** (đổi nồng độ muối). Con sinh ra thường **yếu, nhỏ**, phát triển không đầy đủ.

**Ở người:** từng gặp trứng không thụ tinh phân chia tới khoảng **50 phôi bào**. **U quái buồng trứng** chứa các bộ phận phát triển lộn xộn như tóc, răng, mắt, chi…; người ta cho rằng nó sinh ra từ trứng không thụ tinh phát triển bất thường.

> [!ung-dung] U quái và chửa trứng — "trinh sản" và "phụ sinh" ở người
> - **U quái trưởng thành buồng trứng** (u nang bì) khá thường gặp ở phụ nữ trẻ. Phân tích di truyền cho thấy đa số có nguồn gốc từ **một tế bào mầm đã qua giảm phân I** (lỗi ở giảm phân II hoặc nhân đôi bộ n), tức là chỉ mang gen mẹ — đúng tinh thần "trứng tự phát triển". Siêu âm thấy khối có mỡ, vôi hóa (răng).
> - **Chửa trứng toàn phần** (thai trứng) là phiên bản bệnh lý giống "phụ sinh": trứng **mất nhân**, toàn bộ bộ gen (thường 46,XX) đến từ **tinh trùng**. Không có phôi, chỉ có lá nuôi tăng sinh → hCG rất cao, nguy cơ ung thư nguyên bào nuôi.
> - Vì sao người và động vật có vú **không** sinh sản đơn tính tự nhiên? Do **in dấu gen** (genomic imprinting): một số gen chỉ hoạt động khi đến từ bố, số khác chỉ khi đến từ mẹ. Phôi chỉ có gen mẹ thì lá nuôi kém; chỉ có gen bố thì không có phôi. Cần **cả hai** bộ gen.

> [!cap-nhat] Ong chúa giao phối với nhiều ong đực
> Giáo trình ghi ong chúa "cả đời chỉ giao hợp một lần" với một con ong đực. **Hiện nay** đã biết ong chúa thực hiện một (đôi khi vài) **chuyến bay giao phối** ngay sau khi trưởng thành, trong đó giao phối với **khoảng 10–20 ong đực** (có khi nhiều hơn), rồi trữ tinh trùng dùng suốt đời. Cơ chế xác định giới tính (trứng không thụ tinh → đực đơn bội) vẫn đúng như sách. Đi thi vẫn trả lời theo giáo trình.

## 3. Bảy giai đoạn phát triển cá thể của động vật

Phát triển cá thể là một quá trình **động, liên tục, có quy luật**. Giai đoạn trước kết thúc làm **nền** cho giai đoạn sau, theo một chương trình khá chặt chẽ đã **mã hóa trong kiểu gen**.

Ở động vật có xương sống sinh sản hữu tính có **7 giai đoạn**:

| # | Giai đoạn | Mốc chính |
|---|---|---|
| 1 | Tạo giao tử | Giảm phân tạo tinh trùng, trứng |
| 2 | Tạo hợp tử | Thụ tinh, khôi phục 2n |
| 3 | **Phôi thai** | Phân cắt → phôi vị hóa → tạo hình cơ quan |
| 4 | Sinh trưởng (hậu phôi) | Con non tự sống, lớn nhanh |
| 5 | Trưởng thành | Sinh dục có hiệu quả |
| 6 | Già lão | Giảm sút chức năng, dị hóa > đồng hóa |
| 7 | Tử vong | Chấm dứt sự sống |

## 4. Giai đoạn tạo giao tử

Tinh trùng do tế bào sinh tinh ở **tinh hoàn** giảm phân tạo ra; trứng do tế bào sinh trứng ở **buồng trứng** giảm phân tạo ra (diễn biến giảm phân: xem bài *Phân chia tế bào và sự hình thành giao tử*). Ở đây chỉ xét **cấu tạo** giao tử.

### 4.1. Tinh trùng

Tinh trùng người và động vật bậc cao là tế bào **nhỏ, di động**, gồm 3 phần: **đầu – cổ – đuôi**.

![Hình 1. Cấu tạo tinh trùng động vật có vú (sơ đồ)](tinh-trung.svg)

| Phần | Cấu tạo | Chức năng |
|---|---|---|
| **Đầu** | **Nhân lớn** chiếm gần hết; tế bào chất rất mỏng, **không bào quan**. Phía trước có **thể đầu** (acrosom) do **bộ Golgi** tạo thành, hình chóp | Mang bộ gen n. Thể đầu chứa **lysin, hyaluronidase** để làm tan màng bao quanh trứng, cùng các chất giúp tiếp xúc màng trứng và hoạt hóa trứng |
| **Cổ** | Dải sinh chất mỏng, chứa **trung thể gần** (sát đầu) và **trung thể xa** (sát đuôi) | Trung thể đóng vai trò quan trọng trong **phân chia hợp tử** |
| **Đuôi — đoạn trung gian** | Sợi trục ở giữa, bao quanh là **bao lò xo do ty thể** biến dạng dính lại | Cung cấp **năng lượng** cho vận động |
| **Đuôi — đoạn chính** | Dài nhất; sợi trục + lớp sinh chất mỏng; quanh trục có **9 sợi ống kép** (vi ống) | Vận động nhờ **tubulin** và **dynein** (protein vận động) |
| **Đuôi — đoạn cuối** | Ngắn, chỉ có **sợi trục trần** bọc màng tế bào | |

> [!vi-du] Vì sao tinh trùng "tinh giản" như vậy?
> Tinh trùng chỉ có một việc: **mang bộ gen đến trứng thật nhanh**. Nó bỏ gần hết tế bào chất (cho nhẹ), giữ lại nhân (thông tin), acrosom (chìa khóa mở màng trứng), ty thể (động cơ) và roi (chân vịt). Ty thể của tinh trùng bị **phá hủy trong trứng** sau thụ tinh → **ADN (DNA) ty thể di truyền theo dòng mẹ**.

> [!ung-dung] Tinh dịch đồ và bất động lông roi
> - **Tinh dịch đồ** đánh giá số lượng, độ di động, hình dạng tinh trùng (dị dạng đầu, cổ, đuôi). Theo WHO 2021, giới hạn dưới tham chiếu: mật độ khoảng 16 triệu/mL, di động tiến tới khoảng 30%, hình dạng bình thường khoảng 4%.
> - **Rối loạn vận động lông nguyên phát** (hội chứng Kartagener) do hỏng **dynein**: tinh trùng **không di động** → vô sinh nam, kèm viêm xoang, giãn phế quản (lông chuyển đường thở cũng hỏng), có thể đảo ngược phủ tạng.

### 4.2. Trứng

Trứng thường tròn hoặc bầu dục, **không di động**, **lớn hơn tinh trùng rất nhiều**. Chất dinh dưỡng dự trữ cho phôi gọi là **noãn hoàng**. Theo **lượng** và **sự phân bố** noãn hoàng, có **4 loại trứng**:

![Hình 2. Các loại trứng theo lượng và sự phân bố noãn hoàng](loai-trung.svg)

| Loại trứng | Noãn hoàng | Nhân | Ví dụ |
|---|---|---|---|
| **Đẳng hoàng** | Ít, **phân bố đều** | Ở trung tâm | Cầu gai, cá lưỡng tiêm |
| **Đoạn hoàng** | Tập trung ở **cực dưới** (cực dinh dưỡng) | Cùng phần lớn tế bào chất ở **cực trên** (cực sinh vật) | — lượng **trung bình**: lưỡng cư (ếch nhái); — lượng **rất nhiều**: bò sát, chim |
| **Trung hoàng** | Tương đối ít, **ở giữa** quanh nhân | Ở trung tâm | Côn trùng |
| **Vô hoàng** | **Không có** noãn hoàng | — | Động vật có vú |

Dù noãn hoàng nhiều hay ít, tập trung hay phân tán, trứng vẫn có **phân cực**: **cực sinh vật** và **cực dinh dưỡng**; đường nối hai cực là **trục của trứng**.

> [!bay]
> - Trứng gà = trứng **đoạn hoàng nhiều noãn hoàng** (không phải "đẳng hoàng" dù lòng đỏ tròn đều). Phần sống, phân chia chỉ là **đĩa phôi** nhỏ trên mặt lòng đỏ.
> - Trứng ếch = đoạn hoàng **trung bình**; trứng côn trùng = **trung hoàng**; trứng cầu gai = **đẳng hoàng**.
> - Cực **sinh vật** có nhân (sẽ tạo phôi nhiều hơn); cực **dinh dưỡng** chứa noãn hoàng.

> [!cap-nhat] Trứng người không hẳn "vô hoàng"
> Giáo trình xếp trứng thú vào loại **vô hoàng**. Nhiều sách hiện nay mô tả trứng thú có nhau là trứng có **rất ít noãn hoàng, phân bố đều** (gần với đẳng hoàng), vì phôi được nuôi bằng mẹ qua rau thai. Riêng thú đơn huyệt (thú mỏ vịt) đẻ trứng nhiều noãn hoàng. Đi thi dùng thuật ngữ **vô hoàng** như sách.

## 5. Giai đoạn tạo hợp tử — sự thụ tinh

**Bản chất:** kết hợp **hai bộ nhân đơn bội** (n) của giao tử đực và cái thành **một bộ nhân lưỡng bội** (2n) của hợp tử, khởi đầu cơ thể mới.

Về nguyên tắc, một cơ thể mới **không nhất thiết** phải qua thụ tinh (xem đơn tính sinh). Nhưng thụ tinh phổ biến ở sinh vật bậc cao vì nó tạo **tổ hợp di truyền đa dạng** — nguyên liệu cho tiến hóa.

**Diễn biến:**

1. Tinh trùng tự bơi đến trứng (cả khi thụ tinh ngoài lẫn trong).
2. Trên mặt trứng nhô lên một **nón hút** để thu nhận tinh trùng.
3. Nhiều tinh trùng cùng đến, các tinh trùng "phụ" giải phóng **enzym** lên các màng bao trứng, mở đường; nhưng **chỉ một tinh trùng** vào thụ tinh.
4. Trứng nhanh chóng **hoàn thành lần phân bào thứ hai**, tống **cực cầu** ra ngoài.
5. **Nhân đực** và **nhân cái** di chuyển về phía đối diện chỗ tống cực cầu. **Thể sao** xuất hiện, **thoi vô sắc** hình thành.
6. NST co ngắn, tập trung ở mặt phẳng xích đạo → bộ **2n được khôi phục**, hợp tử bước vào lần phân bào đầu tiên.

**Kết quả:** từ hai tế bào **biệt hóa cao** của hai nguồn bố mẹ → **một tế bào đa tiềm năng chưa biệt hóa**. Hợp tử mang bộ gen nhân 2n đã tổ hợp lại, cộng với các yếu tố di truyền **ngoài nhân** trong tế bào chất **của trứng**. Đó là toàn bộ "chương trình" phát triển cá thể mới.

> [!ung-dung] Khi "chỉ một tinh trùng" bị phá vỡ
> - Ngay khi tinh trùng đầu tiên vào, trứng giải phóng các **hạt vỏ** làm biến đổi màng trong suốt (phản ứng vỏ), chặn các tinh trùng khác — giáo trình không mô tả cơ chế này, nhưng nó giải thích vì sao "chỉ một tinh trùng vào".
> - Nếu **hai tinh trùng** cùng vào (đa thụ tinh) → hợp tử **tam bội** (69 NST), thường gây **chửa trứng bán phần** hoặc sẩy thai.
> - Trong **thụ tinh ống nghiệm**, kỹ thuật **ICSI** tiêm trực tiếp một tinh trùng vào bào tương trứng, dùng khi tinh trùng quá ít hoặc kém di động.

## 6. Giai đoạn phôi thai

### 6.1. Định nghĩa

Giai đoạn phôi thai bắt đầu từ **hợp tử phân cắt**, kéo dài đến khi tạo thành **ấu thể** có cấu trúc cơ thể non tương đối hoàn chỉnh, **tách khỏi** noãn hoàng, vỏ trứng hoặc cơ thể mẹ.

Mọi loại trứng đều qua **3 bước** kế tiếp: **phân cắt** → **phôi vị hóa** (phát sinh mầm cơ quan) → **tạo hình các cơ quan**.

### 6.2. Đặc điểm (4 ý)

1. **Lặp lại lịch sử chủng loại:** phôi đi qua các giai đoạn giống tiến hóa của giới động vật — tạo tính đa bào, phôi hai lá, phôi ba lá…
2. **Tốc độ sinh sản, tăng trưởng tế bào cực kỳ mạnh.**
3. **Biệt hóa tế bào:** từ tế bào đồng nhất, **đa tiềm năng** → tế bào **tiềm năng bị hạn chế**, chuyên hóa về hình thái và chức năng → mô, cơ quan, hệ cơ quan.
4. **Phát triển chưa vững chắc:** nhất là thời kỳ sớm, phôi **rất mẫn cảm** với tác nhân độc hại → dễ thành **quái thai**, sẩy, teo, chết.

> [!cap-nhat] "Lặp lại lịch sử chủng loại" — hiểu cho đúng
> Ý 1 xuất phát từ "định luật phát sinh sinh vật" của **Haeckel** (thế kỷ 19): phôi lặp lại các dạng **trưởng thành** của tổ tiên. **Hiện nay** định luật này theo nghĩa đen **không còn được chấp nhận**. Cách hiểu đúng (theo **von Baer** và sinh học phát triển – tiến hóa ngày nay): phôi các loài có họ hàng **giống phôi** của nhau ở giai đoạn sớm (vì dùng chung các gen điều khiển phát triển cổ xưa, như gen *Hox*), rồi càng về sau càng khác. Ví dụ phôi người có các **cung hầu** giống phôi cá, nhưng đó không phải "mang cá": ở người chúng thành xương hàm, xương con, tuyến giáp, cận giáp… Đi thi vẫn ghi đủ 4 đặc điểm như giáo trình.

> [!ung-dung] Giai đoạn phôi — "cửa sổ" nhạy cảm với thuốc
> - Ở người, **2 tuần đầu** sau thụ tinh thường theo quy luật "**tất cả hoặc không**": tác nhân độc hoặc giết phôi, hoặc phôi hồi phục hoàn toàn.
> - **Tuần 3–8** là thời kỳ tạo cơ quan: **nhạy cảm nhất** với tác nhân gây quái thai. Ví dụ kinh điển: **thalidomid** gây chi ngắn như vây hải cẩu; **rubella** gây đục thủy tinh thể, tim bẩm sinh, điếc; **rượu** gây hội chứng rượu bào thai; **isotretinoin** (trị mụn) gây dị tật nặng.
> - Thiếu **acid folic** làm tăng nguy cơ **dị tật ống thần kinh** (nứt đốt sống, vô sọ) → khuyến cáo bổ sung acid folic **400 µg/ngày** từ **ít nhất 1 tháng trước khi có thai** và trong 3 tháng đầu; người **đã từng có con bị dị tật ống thần kinh** dùng liều cao hơn (**4 mg/ngày**) theo chỉ định bác sĩ (theo khuyến cáo của CDC Hoa Kỳ).

> [!yhct] Liên hệ: thuốc "kỵ thai" trong Dược học cổ truyền
> Ý "phôi thai phát triển chưa vững chắc" cũng là lý do Dược học cổ truyền xếp riêng nhóm vị **cấm dùng** và **thận trọng** khi có thai (vd Xạ hương, Ba đậu, Thủy điệt, Tam lăng, Nga truật… cấm dùng; Đào nhân, Hồng hoa, Ngưu tất, Đại hoàng, Phụ tử… thận trọng). Danh mục đầy đủ, cách phân nhóm và mức bằng chứng: xem bài *Cơ chế điều khiển phát triển phôi và các nhân tố ảnh hưởng*, mã sh-12, mục 2.3.

### 6.3. Phân loại

| Tiêu chí | Nhóm | Đặc điểm – ví dụ |
|---|---|---|
| **Số lá phôi** | Động vật **hai lá phôi** | Chỉ có lá ngoài + lá trong. Thân lỗ, ruột túi |
| | Động vật **ba lá phôi** | Thêm **lá phôi giữa**. Giun đốt, thân mềm, tiết túc, động vật có xương sống |
| **Nguồn dinh dưỡng của phôi** | **Noãn thai sinh** | Phôi sống nhờ chất dự trữ trong trứng. Chim |
| | **Thai sinh** | Phôi nhận chất dinh dưỡng trực tiếp từ mẹ. Thú |
| **Màng ối** (ở động vật có xương sống) | **Không có màng ối** | Trứng phát triển trong nước, **toàn bộ** trứng thành phôi. Cá, lưỡng cư |
| | **Có màng ối** | Chỉ **một phần** tế bào thành phôi, phần còn lại thành **dưỡng mô** (màng phôi). Bò sát, chim, thú. Ở **thú** còn có thêm **rau thai** để nhận chất bổ và thải chất bài tiết qua mẹ |

> [!vi-du] Vì sao màng ối là "phát minh" lớn?
> Màng ối bao phôi trong một "bể nước riêng". Nhờ đó trứng bò sát, chim không cần đẻ xuống nước mà vẫn không bị khô — điều kiện để động vật có xương sống chinh phục hoàn toàn đất liền. Ở người, **nước ối** còn là đối tượng xét nghiệm (chọc ối) để chẩn đoán bất thường NST của thai.

### 6.4. Phân cắt và phát triển phôi ở trứng đẳng hoàng (mẫu: cá lưỡng tiêm)

**Đặc điểm:** phân cắt **hoàn toàn và đều** — mọi phần của hợp tử đều chia, các phôi bào sau mỗi lần chia **bằng nhau**. **Toàn bộ** tế bào đều thành phôi.

![Hình 3. Phân cắt và phôi vị hóa ở trứng đẳng hoàng (sơ đồ)](phan-cat.svg)

#### a) Giai đoạn phân cắt → phôi dâu → phôi nang

Hợp tử phân chia liên tiếp, nhưng khối phôi bào **hầu như không lớn hơn trứng ban đầu** — tế bào chỉ nhỏ dần đi.

| Lần phân cắt | Mặt phẳng | Kết quả |
|---|---|---|
| 1 | **Kinh tuyến** (qua trục trứng, từ cực sinh vật đến cực dinh dưỡng) | 2 phôi bào bằng nhau |
| 2 | **Kinh tuyến**, **vuông góc** với lần 1 | 4 phôi bào |
| 3 | **Xích đạo** (đổi hướng) | 8 phôi bào đều nhau |
| 4 | Kinh tuyến | 16 |
| 5 | Song song mặt phẳng xích đạo | 32 |
| Tiếp theo | Xen kẽ dọc – ngang | Khối tế bào đều nhau như quả dâu: **phôi dâu** |

Phôi bào tiếp tục chia. Ở giữa phôi dâu xuất hiện một **xoang chứa dịch**, lớn dần, đẩy tế bào ra ngoại vi xếp thành **một lớp**. Đó là **phôi nang**: thành gồm **một lớp tế bào**, bên trong là **xoang phôi nang** (xoang phân cắt).

Trong giai đoạn phân cắt, protein được tổng hợp chủ yếu theo **mARN (mRNA) của mẹ** đã tích sẵn trong trứng từ trước khi thụ tinh. *Vì sao?* Phân cắt quá nhanh, gen của hợp tử chưa kịp "lên tiếng" — trứng phải dùng "vốn" của mẹ để lại.

#### b) Giai đoạn phôi vị hóa — phôi hai lá rồi ba lá

Thường đến phôi vị hóa, **bộ gen hợp tử mới bắt đầu phiên mã** → tạo **mARN của phôi** → protein làm **chất cảm ứng sơ cấp** khởi động **biệt hóa** tế bào.

1. Lớp tế bào phía **cực dinh dưỡng lõm vào** trong xoang, tiến về phía cực sinh vật, cuối cùng áp sát mặt trong lớp tế bào cực sinh vật.
2. Xoang phôi nang thu hẹp, chỉ còn **một khe** giữa hai lớp.
3. Phôi lúc này là **phôi vị** — túi rỗng có xoang mới gọi là **xoang vị**, thông ra ngoài qua **phôi khẩu** (miệng phôi).
4. Thành phôi vị có **hai lớp**: ngoài là **lá phôi ngoài**, trong là **lá phôi trong** (phôi hai lá).
5. Cùng lúc, phôi **xoay 90^o^** để phôi khẩu chuyển từ đáy sang **bên**. Bờ phôi khẩu gọi là **môi**: **môi lưng** ở trên, **môi bụng** ở dưới.
6. Trên môi lưng: đám tế bào lá ngoài là **mầm hệ thần kinh**; dưới nó, đám tế bào lá trong là **mầm dây sống**.
7. Một số tế bào xen vào giữa lá ngoài và lá trong → **lá phôi giữa** (**phôi ba lá**). Phôi vị dài ra theo trục trước – sau.

#### c) Phát sinh mầm cơ quan

- **Ống thần kinh:** vùng mầm thần kinh (lá ngoài) dẹt xuống thành **tấm thần kinh** → lõm thành **máng thần kinh** → tế bào hai bờ máng lan lên che kín → **ống thần kinh**.
- **Dây sống:** đám mầm dây sống (lá trong) dưới ống thần kinh uốn lại thành **dây hình trụ đặc**.
- **Lá phôi giữa và xoang cơ thể:** tế bào lá trong ở hai bên dây sống **gấp nếp** dọc phôi, uốn lên rồi khép kín → **lá phôi giữa**, bên trong là **xoang cơ thể nguyên thủy**. Lá giữa và xoang chia thành từng đốt dọc phôi: **khúc nguyên thủy**, xếp đối xứng hai bên.
- **Ống ruột:** phần lá trong ở mặt bụng tách khỏi mầm dây sống, khép thành ống kín. Đầu trước thủng ra → **miệng**; đầu sau thủng ra → **hậu môn**.

> [!ung-dung] Dị tật ống thần kinh
> Nếu máng thần kinh **không khép kín** thành ống, trẻ sinh ra bị **vô sọ** (hở phía đầu) hoặc **nứt đốt sống – thoát vị tủy màng tủy** (hở phía đuôi). Ở người, ống thần kinh khép xong vào khoảng **ngày 28** sau thụ tinh — thường trước khi người mẹ biết mình có thai. Đó là lý do phải uống acid folic **từ trước** khi mang thai. Xét nghiệm **AFP** trong huyết thanh mẹ tăng gợi ý dị tật này.

### 6.5. Trứng đoạn hoàng

**a) Noãn hoàng trung bình (trứng ếch)**

- **Phân cắt hoàn toàn nhưng không đều, không đồng thời.** Toàn bộ tế bào vẫn thành phôi.
- *Vì sao không đều?* Noãn hoàng dồn ở cực dinh dưỡng **cản trở** phân chia → cực dinh dưỡng chia **chậm**, tế bào **to, ít**; cực sinh vật chia **nhanh**, tế bào **nhỏ, nhiều**.
- **Phôi nang:** xoang lệch về **gần cực sinh vật**. Thành phía cực sinh vật **mỏng hơn**, nhiều lớp tế bào nhỏ; thành phía cực dinh dưỡng **dày hơn**, tế bào ít nhưng to.
- **Phôi vị hóa:** vì đáy quá dày nên chỗ lõm **không ở đáy** mà **lệch sang một bên**. Phôi vị có **môi lưng mỏng** (tế bào nhỏ) và **môi bụng dày** (tế bào to, nhiều noãn hoàng). **Lá phôi giữa** do tế bào từ **môi lưng** vùng phôi khẩu tách ra, lan vào giữa hai lá.
- Phát sinh mầm cơ quan và tạo hình cơ quan: **tương tự** trứng đẳng hoàng.

**b) Noãn hoàng rất nhiều (trứng bò sát, chim)**

- **Phân cắt không hoàn toàn**: chỉ có nhân và tế bào chất ở **cực trên** (một đĩa nhỏ) phân chia, tạo **đĩa phôi**; khối noãn hoàng bên dưới **không chia**.
- Tế bào phân cắt **một phần** thành phôi, **một phần** thành **màng ối** và **màng niệu**.
- Khi có hai rồi ba lá phôi, một phần **lá phôi trong lan xuống bao lấy khối noãn hoàng** để hút chất dinh dưỡng nuôi phôi.
- Ba lá phôi phát triển tiếp **tương tự** trứng đẳng hoàng.

### 6.6. Trứng vô hoàng (động vật có vú)

**Đặc điểm:** phân cắt **hoàn toàn nhưng không đều**. Tế bào **sớm biệt hóa**: một phần thành **phôi**, một phần thành **lá nuôi** (sau thành **rau thai** cung cấp dinh dưỡng).

Diễn biến theo giáo trình:

1. Lần 1 và 2: theo **kinh tuyến**. Lần 3: song song mặt phẳng xích đạo nhưng **gần cực sinh vật** → **4 tiểu phôi bào** ở trên, **4 đại phôi bào** ở dưới.
2. **Tiểu phôi bào** chia nhanh hơn, lan ra **bao lấy** khối đại phôi bào → sau thành **lá nuôi**. **Đại phôi bào** → **mầm thai**.
3. Ở cực sinh vật, giữa đại phôi bào và lá nuôi xuất hiện một xoang lớn dần (tương đương **xoang phôi nang**).
4. Một số đại phôi bào ở mặt dưới tách ra, lót mặt dưới khối đại phôi bào và mặt trong lá nuôi → **lá phôi trong** (nội bì), bên trong là **túi noãn hoàng**. Phía trên, đại phôi bào bè ra → **lá phôi ngoài**.
5. Xuất hiện **xoang ối** giữa lá phôi ngoài và lá nuôi. **Lá phôi giữa** hình thành do tế bào **di chuyển vào** giữa lá ngoài và lá trong.
6. Lá nuôi tạo **rau thai** → trao đổi chất mẹ – con qua rau thai.

> [!cap-nhat] Phôi người giai đoạn đầu theo phôi học hiện nay
> Giáo trình mô tả lá nuôi sinh ra từ "4 tiểu phôi bào". **Hiện nay** phôi học người mô tả như sau:
> - Phân cắt ở thú **chậm và không đồng thời**. Từ giai đoạn 8 tế bào, phôi **nén chặt** lại (compaction).
> - Ở phôi dâu (khoảng ngày 3–4), tế bào **ở ngoài** thành **lá nuôi** (trophoblast), tế bào **ở trong** thành **khối tế bào trong** → phôi. Như vậy là do **vị trí trong/ngoài**, không phải do "tiểu/đại phôi bào".
> - **Phôi nang** (ngày 4–5) **làm tổ** vào niêm mạc tử cung khoảng **ngày 6–7**. Tuần 2: **đĩa phôi hai lá** (thượng bì phôi và hạ bì phôi), xuất hiện **khoang ối**. Tuần 3: **phôi vị hóa** qua **đường nguyên thủy**, tạo ba lá phôi; ở người cả lá giữa lẫn lá trong chính thức đều từ thượng bì phôi đi vào.
> - Bộ gen phôi người bắt đầu phiên mã mạnh từ khoảng giai đoạn **4–8 tế bào** (ở ếch: giữa giai đoạn phôi nang), **sớm hơn** "đến phôi vị hóa" như sách viết. Hiện tượng này gọi là **hoạt hóa bộ gen hợp tử** (*zygotic genome activation*): trước đó phôi sống nhờ mARN và protein của mẹ, sau đó phần lớn mARN mẹ bị phân hủy.
>
> Đi thi vẫn trả lời theo giáo trình.

**Các mốc phát triển phôi người theo tuần** (bổ sung – kiến thức hiện nay; tính **sau thụ tinh**, tuổi thai sản khoa tính theo kỳ kinh cuối thì **cộng ≈ 2 tuần**):

| Thời điểm | Sự kiện chính |
|---|---|
| Ngày 1 | Thụ tinh ở 1/3 ngoài vòi tử cung, tạo hợp tử |
| Ngày 2–3 | Phân cắt 2 → 4 → 8 tế bào; hoạt hóa bộ gen phôi (4–8 tế bào) |
| Ngày 3–4 | Phôi dâu (≈ 16 tế bào), nén chặt, vào buồng tử cung |
| Ngày 4–5 | Phôi nang: lá nuôi + khối tế bào trong |
| Ngày 6–7 | Bắt đầu **làm tổ** ở niêm mạc tử cung |
| Tuần 2 | Đĩa phôi **hai lá**, khoang ối, túi noãn hoàng ("tuần của số 2") |
| Tuần 3 | **Phôi vị hóa** (đường nguyên thủy) → **ba lá phôi**; dây sống; tấm thần kinh |
| ≈ Ngày 22 | **Tim bắt đầu đập** |
| Tuần 4 | Ống thần kinh khép (lỗ thần kinh trước ≈ ngày 25, sau ≈ ngày 28); phôi gấp mình; mầm chi; cung hầu |
| Tuần 3–8 | **Thời kỳ phôi**: hình thành mầm mọi cơ quan → nhạy cảm nhất với tác nhân gây quái thai |
| Tuần 9 → sinh | **Thời kỳ thai**: cơ quan lớn lên, hoàn thiện chức năng; sinh ≈ 38 tuần sau thụ tinh (= 40 tuần theo kỳ kinh cuối) |

(Nguồn: Langman's Medical Embryology 15th ed., 2023.)

> [!ung-dung] Phôi nang trong y học
> - **Thụ tinh ống nghiệm (IVF):** phôi thường được nuôi đến ngày 3 hoặc **ngày 5 (phôi nang)** rồi chuyển vào tử cung. Có thể sinh thiết vài tế bào **lá nuôi** để chẩn đoán di truyền tiền làm tổ mà không chạm đến khối tế bào trong.
> - **Tế bào gốc phôi** lấy từ **khối tế bào trong** của phôi nang — loại tế bào **vạn năng**, biệt hóa được thành mọi tế bào của ba lá phôi.
> - **Tế bào gốc vạn năng cảm ứng (iPS)** (bổ sung – kiến thức hiện nay): năm 2006–2007, **Yamanaka** đưa 4 yếu tố phiên mã vào tế bào da (nguyên bào sợi) của chuột rồi của người, "quay ngược" chúng thành tế bào giống tế bào gốc phôi mà **không cần dùng phôi**; ông cùng **Gurdon** (chuyển nhân ở ếch, 1962) nhận **Nobel Y học 2012**. iPS dùng để nghiên cứu bệnh, thử thuốc và đang được thử nghiệm điều trị (vd tế bào biểu mô sắc tố võng mạc, tế bào thần kinh dopamin cho bệnh Parkinson). Xem thêm bài *Cơ chế điều khiển phát triển phôi*.
> - **Sinh đôi cùng trứng:** phôi bào giai đoạn sớm còn **toàn năng**, nếu tách ra thì mỗi phần vẫn phát triển thành một cơ thể hoàn chỉnh.

### 6.7. So sánh phân cắt theo loại trứng

| Loại trứng | Phân cắt | Phôi nang | Số phận tế bào |
|---|---|---|---|
| **Đẳng hoàng** (lưỡng tiêm) | **Hoàn toàn, đều** | Xoang ở giữa, thành 1 lớp đều | **Toàn bộ** → phôi |
| **Đoạn hoàng TB** (ếch) | **Hoàn toàn, không đều, không đồng thời** | Xoang lệch về cực sinh vật; thành cực dinh dưỡng dày | **Toàn bộ** → phôi |
| **Đoạn hoàng nhiều** (bò sát, chim) | **Không hoàn toàn** (chỉ đĩa phôi chia) | Đĩa phôi trên khối noãn hoàng | Một phần → phôi; một phần → **màng ối, màng niệu** |
| **Vô hoàng** (thú, người) | **Hoàn toàn, không đều** | Tiểu phôi bào bao đại phôi bào | Một phần → phôi; một phần → **lá nuôi → rau thai** |

> [!bay]
> - **Chỉ** trứng đoạn hoàng **nhiều** noãn hoàng mới phân cắt **không hoàn toàn**. Ếch (đoạn hoàng trung bình) và thú (vô hoàng) đều phân cắt **hoàn toàn**, chỉ là **không đều**.
> - "Toàn bộ tế bào thành phôi" chỉ đúng với **đẳng hoàng** và **đoạn hoàng trung bình** (nhóm không có màng ối).
> - Lần phân cắt 1 và 2 theo **kinh tuyến**, lần 3 theo **xích đạo** — rất hay bị hỏi.
> - Lá phôi giữa ở ếch đến từ **môi lưng**, không phải môi bụng.

## 7. Tạo hình cơ quan — tương lai của ba lá phôi

Sau khi có mầm cơ quan, ba lá phôi tiếp tục phân hóa thành các bộ phận của cơ thể.

![Hình 4. Ba lá phôi và các cơ quan hình thành từ mỗi lá (sơ đồ)](la-phoi.svg)

| Lá phôi | Cơ quan, mô hình thành (theo giáo trình) | Cách nhớ |
|---|---|---|
| **Ngoài** | **Thượng bì**, tóc, lông, móng, **tuyến mồ hôi**; **hệ thần kinh**; tế bào thu nhận kích thích của **giác quan**; **nhân mắt**; niêm mạc **miệng, mũi, hậu môn**; **men răng**; **tuyến tiền yên** | "Vỏ ngoài + bộ máy liên lạc" |
| **Giữa** | **Cơ** (trơn, vân, tim); **mô liên kết, xương, sụn**; **răng**; **máu**; màng treo ruột, **màng bụng, màng phổi**; **cơ quan niệu – sinh dục** (trừ tế bào sinh dục); **tim, mạch máu** | "Khung, động cơ, ống dẫn, lọc" |
| **Trong** | Niêm mạc **thực quản, ruột**, manh tràng; **gan, tụy, tuyến nước bọt**; niêm mạc **khí quản, phổi**; **tuyến giáp, cận giáp, tuyến ức**; niêm mạc **bàng quang**; **dây sống** | "Lớp lót bên trong ống tiêu hóa – hô hấp + các tuyến mọc ra từ ống đó" |

> [!bay] Những chỗ hay gài
> - **Men răng** ← lá **ngoài**; phần còn lại của **răng** ← lá **giữa** (theo sách).
> - **Tuyến tiền yên** ← lá **ngoài** (từ túi ở nóc miệng nguyên thủy), dù nó là tuyến nội tiết.
> - **Tuyến giáp, tuyến ức** ← lá **trong**; **thận, tinh hoàn, buồng trứng** ← lá **giữa**, nhưng **tế bào sinh dục** thì **không** từ lá giữa.
> - **Niêm mạc bàng quang** ← lá **trong**, còn **thận, niệu quản** ← lá **giữa**.
> - **Màng phổi, màng bụng** ← lá **giữa**; **niêm mạc phổi** ← lá **trong**.
> - **Máu, tim** ← lá **giữa**.

> [!cap-nhat] Dây sống và mào thần kinh
> - Giáo trình xếp **dây sống** vào lá phôi **trong** (đúng với cá lưỡng tiêm, nơi dây sống tách từ nóc ruột nguyên thủy). Ở động vật có xương sống và người, **hiện nay** dây sống được xếp vào **lá phôi giữa trục**.
> - Sách không nhắc **mào thần kinh** (từ lá ngoài) — nguồn gốc của hạch thần kinh ngoại biên, tủy thượng thận, tế bào sắc tố, nhiều xương sụn vùng mặt và **ngà răng**.
>
> Đi thi: dây sống ← lá trong, theo sách.

## 8. Giai đoạn sinh trưởng (giai đoạn hậu phôi)

### 8.1. Định nghĩa

Còn gọi là giai đoạn **kế phôi, sau phôi, hậu phôi**. Ấu trùng hoặc con non đã **tách khỏi** noãn hoàng, vỏ trứng hoặc cơ thể mẹ, **tự hoạt động** để lớn lên liên tục về khối lượng, kích thước, chuẩn bị vật chất cho giai đoạn trưởng thành.

### 8.2. Đặc điểm

- Tăng khối lượng, kích thước **rất nhanh**. **Đồng hóa rất mạnh, mạnh hơn dị hóa nhiều.**
- Cơ thể phát triển **chưa cân đối**; một số cơ quan chưa hoàn chỉnh, có cơ quan sẽ **mất đi** và được thay bằng cơ quan mới.
- Cơ quan sinh dục **chưa phát triển** hoặc hoạt động chưa hiệu quả.
- Khả năng **thích nghi, chống đỡ** với ngoại cảnh **còn yếu**.

### 8.3. Phân loại

| Tiêu chí | Nhóm | Đặc điểm – ví dụ |
|---|---|---|
| **Giới hạn sinh trưởng** | **Có giới hạn** | Chỉ lớn trong một số giai đoạn, đạt kích thước đặc trưng loài rồi dừng. Chim, thú, **người** |
| | **Không giới hạn** | Lớn suốt đời. Một số cá, bò sát |
| **Biến thái** | **Phát triển trực tiếp** (không biến thái) | Cơ quan có từ phôi hoàn thiện dần, **hình dạng chung không đổi**, không mất cơ quan cũ. Chim, thú |
| | **Phát triển gián tiếp** (có biến thái) | Qua một hay nhiều lần **biến đổi sâu sắc** về hình thái và cấu trúc; cơ quan phôi bị **thay** bằng cơ quan mới. Lưỡng cư (**nòng nọc** → ếch), tiết túc (**bọ gậy** → muỗi), một số giun tròn, giun dẹp |
| **Khả năng hoạt động của con non** | **Con non khỏe** | Tự hoạt động ngay khi ra đời. Bê, nghé, gà con |
| | **Con non yếu** | Chưa tự lập, cần bố mẹ chăm. Bồ câu non, chuột nhắt non, **trẻ sơ sinh** |

> [!ung-dung] Ý nghĩa với nhi khoa và ký sinh trùng
> - Trẻ em thuộc nhóm **sinh trưởng có giới hạn** và **con non yếu**: đánh giá phát triển bằng biểu đồ cân nặng, chiều cao theo tuổi. Tốc độ lớn mạnh nhất là năm đầu và tuổi dậy thì. Đầu xương còn **sụn tăng trưởng**; khi sụn này cốt hóa hết thì chiều cao dừng — đó chính là "giới hạn".
> - Hiểu **biến thái** để diệt côn trùng truyền bệnh đúng lúc: diệt **bọ gậy** (ấu trùng muỗi) ở nước đọng là biện pháp chủ lực phòng sốt xuất huyết.

## 9. Giai đoạn trưởng thành

### 9.1. Định nghĩa

Sinh vật **bắt đầu có khả năng sinh dục hiệu quả** và hoạt động sinh dục tích cực để duy trì nòi giống.

### 9.2. Đặc điểm

- Phát triển **nhảy vọt về chất**: mọi cơ quan **hoàn chỉnh**, chức năng sinh lý – sinh hóa **thuần thục**, phối hợp **hài hòa, cân đối**.
- **Đồng hóa và dị hóa đều mạnh và cân bằng tương đối.**
- Khả năng thích nghi, chống đỡ **cao**; hoạt động sống tích cực.
- Thời gian hoạt động sinh dục **tùy loài**: có loài kéo dài vài chục, thậm chí vài trăm năm; có loài sinh sản **một lần rồi chết**; có loài chỉ vài giờ. Sau đó giảm dần hoặc ngừng khi chuyển sang giai đoạn sau.

### 9.3. Phân loại

**Theo cách thụ tinh:**
- *Tự thụ tinh:* động vật lưỡng tính tự thụ được (một số giun dẹp, giun đốt — theo sách).
- *Thụ tinh chéo:* một số động vật lưỡng tính bậc thấp (sán lá) và hầu hết động vật bậc cao đơn tính. Đây là hình thức tiến hóa cao.
- *Thụ tinh ngoài:* trong nước, ngoài cơ thể mẹ (cá, lưỡng cư).
- *Thụ tinh trong:* trong cơ thể con cái nhờ cơ quan giao cấu, hiệu quả cao (côn trùng, chim, thú).

**Theo cách đẻ và bảo vệ con:**
- *Đẻ trứng:* trứng phát triển ngoài môi trường (nhiều động vật không xương sống ở nước, đa số côn trùng, cá, lưỡng cư, một số bò sát, chim).
- *Đẻ con:* phôi **làm tổ trong tử cung**, được mẹ nuôi đến khi thành con non (thú, người).
- *Vừa đẻ trứng vừa đẻ con*: cá mập, một số thằn lằn, rắn, côn trùng. Trứng nhiều noãn hoàng **ở lại lâu trong ống sinh dục mẹ**, có khi đến lúc nở; nhưng phôi **không gắn chặt** với thành ống dẫn trứng và **không dùng chất dinh dưỡng từ máu mẹ**.

> [!bay]
> - Chữ "**noãn thai sinh**" trong giáo trình (mục phân loại phôi, 6.3) chỉ kiểu phôi sống nhờ **chất dự trữ của trứng**, ví dụ **chim**. Một số sách khác lại dùng "noãn thai sinh" (*ovoviviparity*) cho kiểu cá mập "vừa đẻ trứng vừa đẻ con". Đi thi theo cách dùng của giáo trình.
> - "Vừa đẻ trứng vừa đẻ con" **không phải** thai sinh thật: phôi vẫn sống nhờ **noãn hoàng của trứng**, mẹ chỉ là "nơi ấp". Chỉ ở **thai sinh** (thú) phôi mới nhận chất dinh dưỡng từ **máu mẹ qua rau thai**.

## 10. Giai đoạn già lão

### 10.1. Định nghĩa

Gồm những **biến đổi sâu xa** làm **giảm hẳn khả năng hoạt động mọi mặt** của cơ thể trưởng thành — gọi chung là **sự già** hay **lão hóa**.

### 10.2. Đặc điểm

- **Giảm hoặc mất hẳn** khả năng sinh dục (đặc trưng nhất).
- Các cơ quan **thoái biến** về cấu trúc và chức năng; trao đổi chất giảm; **dị hóa mạnh hơn đồng hóa**.
- Các cơ quan **bắt đầu già vào thời điểm khác nhau** và **với tốc độ khác nhau**. Ví dụ ở người 75 tuổi so với người trẻ:

| Chỉ số | Giảm |
|---|---|
| Tốc độ dẫn truyền xung thần kinh | **10%** |
| Lượng máu cung cấp cho não | **20%** |
| Tốc độ lọc của cầu thận | **44%** |

*Vì sao điều này quan trọng?* Vì già **không đồng đều** nên sự **phối hợp hài hòa** giữa các cơ quan bị tổn thương: cơ quan này không đáp ứng đủ nhu cầu của cơ quan kia → sinh ra các **bệnh tuổi già**, cơ thể kém thích nghi. Sự mất cân đối ấy gọi là **khủng hoảng lão hóa**.

Sau khủng hoảng (ngắn hay dài tùy loài, tùy thể trạng), có **hai khả năng**:

1. **Già từ từ:** cơ quan già trước vẫn đáp ứng **tối thiểu** cho cơ quan khác; các cơ quan khác cũng giảm dần cho đến khi **mọi cơ quan già ở mức gần như nhau** → cơ thể vào **trạng thái cân bằng đại lão**: hài hòa nhưng ở **mức thấp**. Cá thể sống tiếp nhưng kém hoạt động.
2. **Một cơ quan già quá nhanh, quá ác liệt** → không đáp ứng nhu cầu tối thiểu của cơ quan khác hoặc ngừng hoạt động → chuyển sang **tử vong**.

> [!ung-dung] Dùng thuốc ở người cao tuổi
> Mức lọc cầu thận giảm gần một nửa ở tuổi 75, trong khi creatinin máu có thể vẫn "bình thường" vì khối cơ cũng giảm. Do đó phải **ước tính mức lọc cầu thận** và **giảm liều** các thuốc thải qua thận (digoxin, aminoglycosid, metformin, nhiều kháng sinh…). Lưu lượng máu não giảm, dẫn truyền thần kinh chậm giải thích vì sao người già dễ **lú lẫn, té ngã** khi dùng thuốc an thần. Thuốc sắc, cao, hoàn ở người cao tuổi cũng nên dùng liều thấp hơn và theo dõi chức năng thận, gan.

> [!yhct] "Thận khí" và các mốc đời người trong Nội kinh
> Thiên *Thượng cổ thiên chân luận* (Hoàng đế Nội kinh – Tố vấn) chia đời người theo chu kỳ **7 năm ở nữ** và **8 năm ở nam**, gắn với sự thịnh suy của **thận khí** và **thiên quý**: nữ 7 tuổi thận khí thịnh (thay răng, tóc dài), 14 tuổi (2×7) "thiên quý đến" (có kinh, có thể có con), 49 tuổi (7×7) "thiên quý cạn" (mãn kinh); nam 8 tuổi thận khí thực, 16 tuổi (2×8) thiên quý đến, 40 tuổi (5×8) thận khí bắt đầu suy, 56 tuổi (7×8) thiên quý cạn, tinh ít, thận tạng suy, 64 tuổi (8×8) răng tóc rụng. Các mốc này tương ứng khá sát với **dậy thì – trưởng thành – già lão** trong sinh học (tuổi mãn kinh trung bình hiện nay khoảng 50).
> Cần hiểu đây là **mô hình mô tả từ quan sát** của y học cổ, **không** đồng nghĩa "thận" giải phẫu hay một cơ chế sinh học đã được chứng minh. Các nghiên cứu về thuốc "bổ thận" chống lão hóa phần lớn còn ở mức thực nghiệm.

## 11. Giai đoạn tử vong

Tử vong ở đây là **cái chết tự nhiên** nối tiếp giai đoạn già lão — một giai đoạn **ngắn**, chấm dứt sự sống cá thể.

**Cơ chế:** một hoặc vài cơ quan **quan trọng** không còn thực hiện được chức năng, không đáp ứng nhu cầu cơ bản của các cơ quan khác → tính **"tổng thể hài hòa, phối hợp chặt chẽ"** của cơ thể bị phá vỡ → cơ quan ấy ngừng kéo theo **tất cả** các cơ quan ngừng → chết.

**Kết luận của chương:** phát triển cá thể diễn ra dưới **sự kiểm soát chặt chẽ của bộ gen** — các giai đoạn đã được "lập trình" từ lịch sử tiến hóa và thực hiện dần trong đời cá thể. Nhưng không chỉ có gen: các **nhân tố ngoại cảnh** (vô sinh và hữu sinh) cũng chi phối. **Kiểu hình = tương tác giữa hệ gen và môi trường.**

> [!vi-du] Gen "lập trình" nhưng môi trường "điều chỉnh"
> - Ấu trùng ong cái có **cùng bộ gen**, nhưng được ăn chất tiết đặc biệt của ong thợ thì thành **ong chúa**, chỉ ăn mật – phấn thì thành **ong thợ** (ví dụ ngay trong bài).
> - Ở người, thai nhi tiếp xúc rượu, thuốc lá, thiếu dinh dưỡng trong tử cung có nguy cơ cao hơn về bệnh tim mạch, đái tháo đường khi trưởng thành — tức là môi trường thời kỳ **phôi thai** để lại dấu ấn đến tận **già lão**.

## Tóm tắt

| Nội dung | Điểm phải nhớ |
|---|---|
| Sinh sản vô tính / hữu tính | Một nguồn mẹ, nguyên phân, giống hệt mẹ / hai bộ gen, giảm phân + thụ tinh, biến dị tổ hợp |
| Hình thức đặc biệt | Tiếp hợp (2 cá thể), nội hợp (1 cá thể), lưỡng tính sinh, đơn tính sinh (đực – ong; cái – ốc, tôm, cua; chu kỳ – luân trùng; nhân tạo – châm kim trứng ếch), **mẫu sinh** (giữ nhân trứng – cá diếc bạc), **phụ sinh** (giữ nhân tinh trùng – tằm) |
| 7 giai đoạn | Giao tử → hợp tử → phôi thai → sinh trưởng → trưởng thành → già lão → tử vong |
| Tinh trùng | Đầu (nhân + **thể đầu** từ Golgi, hyaluronidase) – cổ (**trung thể** gần, xa) – đuôi (trung gian: **ty thể**; chính: 9 sợi ống kép, tubulin – dynein; cuối: sợi trục trần) |
| 4 loại trứng | **Đẳng hoàng** (cầu gai, lưỡng tiêm) – **đoạn hoàng** TB (ếch) / nhiều (bò sát, chim) – **trung hoàng** (côn trùng) – **vô hoàng** (thú) |
| Thụ tinh | Nón hút → 1 tinh trùng vào → trứng tống cực cầu II → 2 nhân tiến lại → khôi phục **2n** |
| Phôi thai: 4 đặc điểm | Lặp lại chủng loại (hiện nay hiểu: phôi giống **phôi** loài họ hàng, không phải giống con trưởng thành của tổ tiên); tăng trưởng cực mạnh; biệt hóa; **chưa vững chắc** (dễ quái thai) |
| Mốc phôi người (bổ sung) | Thụ tinh ngày 1 → phôi nang ngày 4–5 → làm tổ ngày 6–7 → tuần 2 hai lá → tuần 3 ba lá → tim đập ≈ ngày 22 → ống thần kinh khép ≈ ngày 28 → tuần 3–8 thời kỳ phôi → từ tuần 9 thời kỳ thai |
| Phân cắt | Đẳng hoàng: hoàn toàn, **đều**; đoạn hoàng TB: hoàn toàn, **không đều**; đoạn hoàng nhiều: **không hoàn toàn**; vô hoàng: hoàn toàn, không đều, có **lá nuôi** |
| Trình tự phôi | Phôi dâu → **phôi nang** (1 lớp + xoang) → **phôi vị** (2 lá, xoang vị, phôi khẩu) → 3 lá → ống thần kinh, dây sống, khúc nguyên thủy, ống ruột |
| 3 lá phôi | **Ngoài**: da, thần kinh, giác quan, men răng, tiền yên; **Giữa**: cơ, xương, máu, tim mạch, niệu – sinh dục, màng bụng – phổi; **Trong**: niêm mạc tiêu hóa – hô hấp, gan, tụy, giáp, ức, bàng quang, dây sống |
| Sinh trưởng | Đồng hóa ≫ dị hóa; chưa cân đối; có/không giới hạn; có/không biến thái; con non khỏe/yếu |
| Trưởng thành | Sinh dục hiệu quả; đồng hóa ≈ dị hóa; hài hòa, thích nghi cao |
| Già lão | Dị hóa > đồng hóa; già **không đồng đều** (người 75 tuổi: thần kinh −10%, máu não −20%, lọc cầu thận −44%) → khủng hoảng lão hóa → **cân bằng đại lão** hoặc **tử vong** |
| Tử vong | Cơ quan quan trọng ngừng → phá vỡ tính tổng thể → chết tự nhiên. Kiểu hình = gen × môi trường |
