---
title: Các nguyên lý và quy luật cơ bản của sự di truyền
thoi-gian: 60 phút
muc-tieu:
- Giải thích được các thuật ngữ cơ bản (tính trạng, kiểu hình, kiểu gen, alen) và các ký hiệu P, F, cách đặt tên alen.
- Trình bày được ba định luật Mendel và cơ sở tế bào học của chúng; tính được tỷ lệ giao tử, kiểu gen, kiểu hình.
- Trình bày được di truyền đơn gen (hai alen, nhiều alen) và tương tác của hai gen không alen phân ly độc lập cùng quy định một tính trạng.
- Nêu được khái niệm, đặc điểm của di truyền đa gen và di truyền đa nhân tố.
- Trình bày được hiện tượng liên kết gen, hoán vị (tái tổ hợp) gen và nguyên tắc lập bản đồ di truyền.
- Trình bày được các cơ chế xác định giới tính và quy luật di truyền liên kết giới tính; phân biệt với tính trạng hạn chế bởi giới tính.
- Trình bày được đặc điểm của di truyền ngoài nhiễm sắc thể (lạp thể, ty thể, tế bào chất).
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. **Mendel**: F1 đồng tính (định luật I); F2 phân tính **3 trội : 1 lặn** (định luật II, do cặp alen phân ly vào giao tử); hai cặp gen trên hai cặp NST (nhiễm sắc thể) khác nhau **phân ly độc lập** → F2 **9 : 3 : 3 : 1** (định luật III).
> 2. **Đơn gen**: trội hoàn toàn, trội không hoàn toàn (trung gian), **đồng trội** (MN, I^A^I^B^); **nhiều alen** ở một locus (nhóm máu ABO), n alen → n(n+1)/2 kiểu gen.
> 3. **Hai gen không alen** cùng quy định một tính trạng → biến dạng của 9:3:3:1: **9:7, 9:6:1, 9:3:4, 12:3:1, 13:3, 15:1**. **Đa gen – đa nhân tố**: tính trạng số lượng, biến thiên liên tục, chịu ảnh hưởng môi trường.
> 4. **Liên kết gen** (gen cùng một NST di truyền cùng nhau); **trao đổi chéo** → hoán vị gen; **1% tái tổ hợp = 1 cM** là đơn vị bản đồ di truyền.
> 5. **Giới tính**: XX–XY, XX–XO, ZZ–ZW, ZZ–ZO, đơn bội, một gen, môi trường. Gen trên X không có alen trên Y: ở giới XY **một alen cũng biểu hiện** (mù màu, hemophilia). **Ngoài nhân** (ty thể, lạp thể): di truyền **theo dòng mẹ**, không theo tỷ lệ Mendel.

## 1. Một số thuật ngữ và ký hiệu

### 1.1. Tính trạng

**Tính trạng** là một đặc điểm **quan sát được** của cơ thể, trong lúc đang phát triển hoặc khi đã trưởng thành: hình thái, cấu trúc, sinh lý, thậm chí tâm thần.

Tính trạng di truyền do **gen** tạo ra: có thể do các alen của **một gen**, hoặc do **nhiều gen không alen** (ở nhiều locus khác nhau) cùng chi phối. Luôn luôn trong mối tương tác với **môi trường**.

### 1.2. Kiểu hình (phenotyp)

**Kiểu hình** là tập hợp các tính trạng quan sát, nhận biết được của một cơ thể. Nó hình thành từ **tương tác giữa kiểu gen và môi trường**.

- Có thể dùng cho **toàn bộ** cơ thể, hoặc chỉ cho **một vài tính trạng** đang xét (ví dụ "kiểu hình nhóm máu A").
- Kiểu hình **không bao giờ phản ánh đầy đủ** kiểu gen. *Vì sao?* Kiểu hình chỉ cho thấy phần kiểu gen **được thực hiện** trong những điều kiện cụ thể. Ví dụ, alen lặn ở người dị hợp bị che lấp; một gen có thể không biểu hiện nếu thiếu điều kiện môi trường thích hợp.

### 1.3. Kiểu gen (genotyp)

**Kiểu gen** là toàn bộ thông tin di truyền (các gen) chứa trong các nhiễm sắc thể của sinh vật (cả Prokaryota/nhân sơ lẫn Eukaryota/nhân thực).

- Kiểu gen xác định **phạm vi phản ứng** (mức phản ứng) của cơ thể khi môi trường thay đổi. Kiểu gen + môi trường → kiểu hình.
- Nghĩa hẹp: chỉ các alen ở **một hoặc vài locus** đang xét. Ví dụ người nhóm máu A có kiểu gen **I^A^I^A^** hoặc **I^A^i**.
- **Idiotyp** ("kiểu gen cá thể"): **toàn bộ** yếu tố di truyền trong tế bào, gồm cả gen trên NST (*chromotype*) và gen ngoài nhân (*plasmotype*). Có tác giả dùng chữ genotyp theo nghĩa rộng này, khi đó idiotyp đồng nghĩa với genotyp.

### 1.4. Alen

**Alen** là một trong **hai hay nhiều dạng cấu trúc khác nhau của cùng một gen**, nằm ở **cùng một locus** trên cặp NST tương đồng, và quy định các trạng thái khác nhau của **cùng một tính trạng**.

> [!bay]
> - **Alen** = các dạng của **cùng một gen**, cùng locus (A và a). **Gen không alen** = gen ở **các locus khác nhau** (A và B).
> - Tính trạng là "loại đặc điểm" (màu hạt); **trạng thái tính trạng** là từng biểu hiện cụ thể (vàng, lục). Đề hay dùng "cặp tính trạng tương phản" để chỉ hai trạng thái của một tính trạng.

### 1.5. Các ký hiệu thường dùng

| Ký hiệu | Ý nghĩa |
|---|---|
| **P** (*parental*) | Thế hệ bố mẹ. Tính từ một cá thể: bố mẹ là P1, ông bà là P2, cụ là P3… |
| **F** (*filial*) | Thế hệ con: F1 (con của P), F2 (con của F1), F3 (con của F2)… |
| **Chữ in hoa / in thường** | In hoa: alen **trội** hoàn toàn; in thường: alen **lặn** |

**Cách chọn chữ:** lấy **chữ đầu của tên tính trạng biến dị, đột biến** (tức là tính trạng hiếm), phân biệt với **kiểu dại** (tính trạng phổ biến nhất trong quần thể).

- Ví dụ của sách: hạt đậu **vàng** phổ biến, hạt **lục** hiếm hơn → alen lục ký hiệu **g** (*green*, chữ thường vì lặn); alen vàng (trội) là **G**.
- Một số tài liệu ký hiệu kiểu dại bằng dấu **+**, còn alen đột biến bằng chữ hoa (nếu trội) hoặc chữ thường (nếu lặn).
- **Đồng trội**: mọi alen đều biểu hiện nên đều viết **chữ in hoa** kèm chỉ số. Ví dụ hệ nhóm máu MN: **L^M^** và **L^N^** (chữ L kỷ niệm **Landsteiner** và **Levine**, người phát hiện hệ MN).
- **Dãy nhiều alen**: alen trội nhất viết **in hoa**, alen lặn nhất viết **in thường**, các alen ở giữa viết chữ thường kèm **ký hiệu phụ trên cao**. Ví dụ màu mắt ruồi giấm: đỏ kiểu dại là **W**, trắng lặn với mọi alen là **w**; ở giữa có w^co^, w^bl^, w^e^, w^ch^, w^a^… (theo thứ tự trội giảm dần).

## 2. Các nguyên lý di truyền của Mendel

### 2.1. Lai một tính – Định luật I và II

#### 2.1.1. Thực nghiệm

Mendel dùng các **dòng đậu Hà Lan thuần chủng**. Ông theo dõi **riêng từng cặp tính trạng tương phản** qua nhiều thế hệ, và **đếm số lượng** con lai. Lai hai cây bố mẹ chỉ khác nhau về **một** tính trạng gọi là **lai một tính**.

Mendel làm với **7 tính trạng** (Giáo trình tr. 72–73):

| Tính trạng | P (trội × lặn) | F1 | F2: trội : lặn | % trội |
|---|---|---|---|---|
| Chiều cao thân | cao × thấp | cao | 787 : 277 | 74,0 |
| Màu hạt | vàng × lục | vàng | 6022 : 2001 | 75,1 |
| Dạng hạt | trơn × nhăn | trơn | 5474 : 1850 | 74,7 |
| Màu quả (vỏ quả) | lục × vàng | lục | 428 : 152 | 73,8 |
| Dạng quả | phồng × có ngấn (sách ghi "phẳng") | phồng | 882 : 299 | 74,7 |
| Màu hoa | tím lam × trắng | tím lam | 705 : 224 | 75,9 |
| Vị trí hoa | mọc nách × mọc đỉnh | mọc nách | 651 : 207 | 75,9 |

*Vì sao Mendel thành công?* Dòng thuần, theo dõi từng tính trạng riêng, số lượng lớn và **xử lý thống kê** (tỷ lệ chỉ hiện ra khi đếm nhiều). Cả 7 tính trạng đều cho F2 xấp xỉ **75% : 25%**.

> [!bay]
> Ở **màu hạt**, vàng trội; nhưng ở **màu quả** (vỏ quả), **lục** lại trội so với vàng. Hai gen khác nhau, đừng suy từ tính trạng này sang tính trạng kia.

#### 2.1.2. Định luật I (định luật đồng tính, định luật tính trội)

Lai hai cơ thể **thuần chủng**, khác nhau một cặp tính trạng tương phản → **F1 đồng loạt giống nhau**, mang tính trạng của một bên bố hoặc mẹ. Tính trạng hiện ra ở F1 gọi là **trội**; tính trạng không hiện ra ở F1 gọi là **lặn**.

#### 2.1.3. Định luật II (định luật phân tính)

Cho F1 tự thụ phấn → F2 **phân tính** xấp xỉ **3 trội : 1 lặn**. Mendel làm tiếp F3 (cho từng cây F2 tự thụ):

| Nhóm cây F2 | Tỷ lệ trong F2 | F3 khi tự thụ | Kết luận |
|---|---|---|---|
| Cây lặn | 1/4 | toàn lặn | thuần chủng |
| Cây trội | 1/3 số cây trội (= 1/4 tổng) | toàn trội | thuần chủng |
| Cây trội | 2/3 số cây trội (= 2/4 tổng) | lại 3 trội : 1 lặn | không thuần chủng |

Như vậy, bên dưới tỷ lệ kiểu hình **3 : 1** là tỷ lệ kiểu gen **1 : 2 : 1**.

Sơ đồ lai (T: thân cao, t: thân thấp):

=> P: TT (cao) × tt (thấp) → G: T ; t → F1: Tt (100% cao)

Bảng Punnett F1 × F1 (Tt × Tt):

| ♂ \ ♀ | **T** (1/2) | **t** (1/2) |
|---|---|---|
| **T** (1/2) | TT | Tt |
| **t** (1/2) | Tt | tt |

=> F2: 1 TT : 2 Tt : 1 tt → 3 cao : 1 thấp

> [!bay] Hai câu hỏi "1/3" và "1/4" hay bị đánh tráo
> - Trong **toàn bộ F2**, cây trội thuần chủng (TT) chiếm **1/4**.
> - Trong số **cây trội F2**, cây thuần chủng chiếm **1/3**, cây dị hợp chiếm **2/3**.
> Đọc kỹ đề hỏi "trong tổng số" hay "trong số cây trội".

#### 2.1.4. Cơ sở tế bào học của lai một tính

- Trong tế bào **2n**, NST tồn tại thành **cặp tương đồng** (giống nhau về hình dạng, kích thước, trình tự gen). Vì thế gen cũng tồn tại thành **cặp alen** ở cùng locus.
- Khi **giảm phân**, hai NST của cặp tương đồng **phân ly** về hai giao tử khác nhau, nên **hai alen cũng tách ra**, mỗi giao tử chỉ nhận **một alen**.
- Khi **thụ tinh**, giao tử đực + giao tử cái → hợp tử có lại cặp NST tương đồng, tức có lại **cặp alen**: một alen từ bố, một alen từ mẹ.

**Nguyên lý phân ly gen** (phát biểu hoàn chỉnh sau này): Trong cơ thể, gen tồn tại **theo từng đôi**, nhưng **riêng rẽ, không hòa lẫn**. Khi tạo giao tử, mỗi cặp gen **phân ly**, mỗi gen đi vào một giao tử. Khi thụ tinh, các alen lại **kết hợp thành đôi** trong hợp tử.

*Vì sao nói "không hòa lẫn"?* Alen lặn t bị che ở F1 nhưng **vẫn nguyên vẹn**: sang F2 nó lại xuất hiện ở dạng tt với đúng tính trạng thấp ban đầu. Nếu di truyền kiểu "pha trộn" (như pha mực) thì không thể có chuyện đó.

> [!vi-du] Phép lai phân tích
> Muốn biết một cây thân cao là TT hay Tt, đem lai với cây **đồng hợp lặn** (tt). Cây lặn chỉ cho giao tử t, nên kiểu hình đời con "đọc" thẳng ra giao tử của cây cần kiểm tra:
> - Đời con **100% cao** → cây đem thử là **TT**;
> - Đời con **1 cao : 1 thấp** → cây đem thử là **Tt**.
> Phép lai phân tích còn dùng để nhận ra gen liên kết (mục 7.2).

> [!ung-dung] Ở người không lai thực nghiệm được
> Người không thể "đem lai thử" như đậu. Di truyền y học thay bằng **phân tích phả hệ**, nghiên cứu **trẻ sinh đôi**, phân tích **dấu vân da**, **điều tra dịch tễ di truyền**, cùng kỹ thuật **di truyền tế bào** và **phân tử** (xem bài Di truyền học: nội dung, phương pháp nghiên cứu). Các quy luật Mendel vẫn là công cụ để tính **nguy cơ** cho con trong tư vấn di truyền.

### 2.2. Lai hai tính – Định luật III

#### 2.2.1. Thí nghiệm

Mendel lai cây thuần chủng hạt **trơn, vàng** với cây thuần chủng hạt **nhăn, lục** (lai hai tính). Hai cặp gen mà ông chọn tình cờ nằm trên **hai cặp NST khác nhau**.

- F1: **100% trơn, vàng**.
- F2 (F1 tự thụ): **556 hạt** gồm **315** trơn vàng : **108** trơn lục : **101** nhăn vàng : **32** nhăn lục ≈ **9 : 3 : 3 : 1**.

Xét **riêng từng cặp** ở F2: trơn : nhăn ≈ 3 : 1, vàng : lục ≈ 3 : 1. Tỷ lệ chung đúng bằng **tích** hai tỷ lệ riêng:

=> (3 : 1) × (3 : 1) = 9 : 3 : 3 : 1

Tức là hai phép lai một tính diễn ra **đồng thời** trong cùng một cây, **không ảnh hưởng** lẫn nhau.

#### 2.2.2. Định luật III (định luật phân ly độc lập, nguyên lý tổ hợp độc lập)

Phát biểu (đã bổ sung theo cơ sở tế bào học): Nếu **mỗi cặp gen** quy định một tính trạng và các cặp gen nằm trên **các cặp NST khác nhau**, thì khi giảm phân chúng **phân ly độc lập**, cặp này không phụ thuộc cặp kia; các gen tổ hợp vào giao tử một cách **ngẫu nhiên**.

**Ứng dụng:** trong chọn giống động vật, thực vật, người ta lai để **gom các tính trạng mong muốn** vào cùng một cá thể rồi giữ chúng lại.

#### 2.2.3. Cơ sở tế bào học của lai hai tính

Ký hiệu của sách: **N** (trơn) > **n** (nhăn); **L** (vàng) > **l** (lục). Hai cặp gen nằm trên hai cặp NST tương đồng khác nhau.

=> P: NNLL (trơn, vàng) × nnll (nhăn, lục) → G: NL ; nl → F1: NnLl (100% trơn, vàng)

Khi F1 giảm phân, cặp NST mang N/n và cặp NST mang L/l **xếp ở kỳ giữa I theo hai cách** với xác suất bằng nhau. Do đó tạo **4 loại giao tử** với tỷ lệ **bằng nhau**: NL, Nl, nL, nl (mỗi loại 1/4), cả ở bên đực lẫn bên cái.

![Hình 1. Cơ sở tế bào học của phân ly độc lập: hai cặp NST xếp ngẫu nhiên ở kỳ giữa I nên F1 NnLl tạo 4 loại giao tử bằng nhau](phan-ly-doc-lap.svg)

Bảng Punnett F1 × F1 (NnLl × NnLl): 4 × 4 = **16 tổ hợp**.

| ♂ \ ♀ | **NL** | **Nl** | **nL** | **nl** |
|---|---|---|---|---|
| **NL** | NNLL | NNLl | NnLL | NnLl |
| **Nl** | NNLl | NNll | NnLl | Nnll |
| **nL** | NnLL | NnLl | nnLL | nnLl |
| **nl** | NnLl | Nnll | nnLl | nnll |

Kết quả F2:

- **9 kiểu gen**: 1 NNLL : 2 NNLl : 2 NnLL : **4 NnLl** : 1 NNll : 2 Nnll : 1 nnLL : 2 nnLl : 1 nnll, tức là (1 : 2 : 1) × (1 : 2 : 1).
- **4 kiểu hình**: **9 N-L-** (trơn vàng) : **3 N-ll** (trơn lục) : **3 nnL-** (nhăn vàng) : **1 nnll** (nhăn lục).

> [!vi-du] Mẹo tính nhanh bằng xác suất (không cần vẽ bảng 16 ô)
> Vì các cặp gen độc lập, **xác suất chung = tích các xác suất riêng**.
> - Tỷ lệ cây trơn, lục ở F2 = P(trơn) × P(lục) = 3/4 × 1/4 = **3/16**.
> - Tỷ lệ kiểu gen NnLl ở F2 = P(Nn) × P(Ll) = 1/2 × 1/2 = **1/4** (= 4/16).
> - Trong số cây trơn vàng F2, cây thuần chủng NNLL chiếm (1/3) × (1/3) = **1/9**.
> - Phép lai AaBb × aabb (lai phân tích) → (1 : 1) × (1 : 1) = **1 : 1 : 1 : 1**.

### 2.3. Lai đa tính – công thức tổng quát

Mendel còn lai **ba tính** (hình dạng hạt, màu lá mầm, màu vỏ hạt) và khái quát cho **n cặp gen** dị hợp, phân ly độc lập (định luật tổ hợp):

| Đại lượng (F1 dị hợp n cặp, F1 × F1) | 1 cặp | 2 cặp | n cặp |
|---|---|---|---|
| Số loại giao tử của F1 | 2 | 4 | **2^n^** |
| Số tổ hợp giao tử ở F2 | 4 | 16 | **4^n^** |
| Số loại kiểu gen F2 | 3 | 9 | **3^n^** |
| Tỷ lệ kiểu gen F2 | 1:2:1 | (1:2:1)^2^ | **(1 : 2 : 1)^n^** |
| Số loại kiểu hình F2 (trội hoàn toàn) | 2 | 4 | **2^n^** |
| Tỷ lệ kiểu hình F2 | 3:1 | 9:3:3:1 | **(3 : 1)^n^** |

> [!bay]
> - Công thức chỉ đúng khi các cặp gen **phân ly độc lập** (khác cặp NST) và **trội hoàn toàn**. Trội không hoàn toàn thì số kiểu hình = số kiểu gen = 3^n^.
> - 4^n^ là số **tổ hợp** (ô trong bảng Punnett), không phải số kiểu gen. Với n = 3: 64 tổ hợp, 27 kiểu gen, 8 kiểu hình.

### 2.4. Sự phát hiện lại và các bổ sung sau Mendel

- **1866**: công trình của Mendel được in trong kỷ yếu Hội các nhà tự nhiên học ở **Brno** (sách ghi "Bruno"). Người đương thời **không hiểu** hết giá trị của nó.
- **1900**: các định luật Mendel được **phát hiện lại**. Từ đây di truyền học thực sự phát triển.

Ba nhà thực vật học phát hiện lại Mendel một cách độc lập năm 1900 là **De Vries**, **Correns** và **Tschermak** (xem bài Di truyền học: nội dung, phương pháp nghiên cứu).

Sau Mendel, người ta thấy với gen trong nhân có **nhiều kiểu di truyền** khác nhau, bổ sung cho Mendel:

1. **Di truyền đơn gen** (mục 3);
2. **Gen đa hiệu**: một gen chi phối nhiều mặt của kiểu hình (mục 5);
3. **Hai hay nhiều gen không alen** cùng tác động lên một tính trạng (mục 4);
4. Gen thuộc nhóm **liên kết NST thường** hoặc **liên kết NST giới tính** (mục 7, 9);
5. **Di truyền đa gen, đa nhân tố** (mục 6);
6. Ngoài ra còn **di truyền tế bào chất** (mục 11).

## 3. Di truyền đơn gen

### 3.1. Khái niệm

**Di truyền đơn gen**: một tính trạng (ở từng cơ thể và trong cả quần thể) chỉ do **các alen của một gen**, ở **một locus**, quy định. Trong cơ thể lưỡng bội, hai alen của gen ấy tương tác với nhau để tạo kiểu hình.

Vì dựa trên sự **phân ly và tổ hợp** của cặp alen trong giảm phân và thụ tinh, có thể **tính toán** được tần số kiểu gen, kiểu hình bằng công thức. Do đó còn gọi là **"di truyền kiểu Mendel"** hay **"di truyền đơn giản theo hệ thức"**.

Gồm hai dạng: **di truyền hai alen** và **di truyền nhiều alen**.

### 3.2. Di truyền hai alen

Cả quần thể chỉ có **hai alen** của gen chi phối tính trạng. Tùy quan hệ giữa hai alen mà có ba kiểu tương quan:

| Tương quan | Kiểu hình của dị hợp Aa | Tỷ lệ F2 (Aa × Aa) | Ví dụ của sách |
|---|---|---|---|
| **Trội hoàn toàn** | Giống AA | 3 : 1 | Đậu thân cao TT, Tt |
| **Trội không hoàn toàn** | **Trung gian** giữa AA và aa | **1 : 2 : 1** | Hoa mõm chó: AA đỏ, **Aa hồng**, aa trắng |
| **Đồng trội** | Biểu hiện **đầy đủ cả hai** | **1 : 2 : 1** | Nhóm máu MN: L^M^L^N^ có cả kháng nguyên M và N |

#### 3.2.1. Trội lặn hoàn toàn

Ở thể dị hợp Aa, chỉ trạng thái do **A** quy định hiện ra; trạng thái của **a** bị lấn át hẳn. Do đó **AA và Aa có cùng kiểu hình**.

Hai lưu ý của sách:

- "Gen lặn" thực ra **không hẳn im lặng**. Nói đúng hơn: alen lặn gây biểu hiện **khó thấy hoặc không thấy** ở kiểu hình bề ngoài. Nhưng có thể **phát hiện** được bằng phương pháp **hóa sinh**, ở mức **phân tử**.
- Cùng một gen, ở **môi trường này** có thể hoạt động như gen **trội**, ở **môi trường khác** lại như gen **lặn**.

> [!ung-dung] Phát hiện người lành mang gen lặn
> Người dị hợp (mang gen bệnh lặn) trông hoàn toàn khỏe mạnh, nhưng xét nghiệm có thể "thấy" alen lặn. Ví dụ ở Việt Nam, **thalassemia** (bệnh tan máu bẩm sinh) rất phổ biến: người mang gen thường không triệu chứng, nhưng **xét nghiệm công thức máu** thấy hồng cầu nhỏ (MCV, MCH giảm), **điện di huyết sắc tố** hoặc **xét nghiệm ADN** (DNA) xác định được. Nếu **cả hai vợ chồng** cùng mang gen, mỗi lần sinh con có nguy cơ **1/4** bị bệnh (Aa × Aa → 1/4 aa). Đó là lý do tầm soát trước hôn nhân và trước sinh.

#### 3.2.2. Trội không hoàn toàn – biểu hiện trung gian

Ở dị hợp, **mỗi alen chỉ biểu hiện một phần**, kết quả là kiểu hình **trung gian**.

Ví dụ hoa mõm chó (*Antirrhinum*): AA đỏ, aa trắng, **Aa hồng**. Sách giải thích: A tạo sắc tố đỏ, a tạo "sắc tố trắng"; ở Aa cả hai cùng hoạt động nên hoa hồng.

| ♂ \ ♀ | **A** | **a** |
|---|---|---|
| **A** | AA (đỏ) | Aa (hồng) |
| **a** | Aa (hồng) | aa (trắng) |

=> F2: 1 đỏ : 2 hồng : 1 trắng (tỷ lệ kiểu hình **trùng** tỷ lệ kiểu gen)

> [!cap-nhat] Màu hồng ở hoa mõm chó
> Giáo trình nói alen a tạo "sắc tố trắng". Hiện nay giải thích chính xác hơn: hoa trắng là do **không tạo được** sắc tố (alen a mất chức năng); cây Aa chỉ có **một** alen hoạt động nên tạo **nửa lượng** sắc tố đỏ, cánh hoa trông hồng (hiệu ứng liều gen). Đi thi vẫn trả lời "kiểu hình trung gian do trội không hoàn toàn".

#### 3.2.3. Đồng trội

Hai alen **trội ngang nhau**. Dị hợp biểu hiện **cả hai** trạng thái **đầy đủ, ngang nhau**, **không** phải trung gian.

Ví dụ hệ nhóm máu **MN**:

| Kiểu gen | Kháng nguyên trên hồng cầu | Ngưng kết với |
|---|---|---|
| L^M^L^M^ | M | kháng thể kháng M |
| L^N^L^N^ | N | kháng thể kháng N |
| **L^M^L^N^** | **M và N** | **cả** kháng M lẫn kháng N |

> [!bay] Trội không hoàn toàn khác đồng trội ở chỗ nào?
> - **Trội không hoàn toàn**: dị hợp có kiểu hình **mới, nằm giữa** (hồng = "nửa đỏ").
> - **Đồng trội**: dị hợp mang **cả hai** sản phẩm, mỗi cái **trọn vẹn** (vừa có M, vừa có N; không có "kháng nguyên nửa M nửa N").
> - Cả hai đều cho F2 **1 : 2 : 1** về kiểu hình.

### 3.3. Di truyền nhiều alen

#### 3.3.1. Khái niệm và locus phức hợp

Do **đột biến**, một gen có thể có **nhiều dạng** khác nhau ở các cá thể trong quần thể → tạo **dãy nhiều alen** (> 2 alen). Locus có nhiều alen gọi là **locus phức hợp**.

Điểm then chốt: cả **quần thể** có nhiều alen, nhưng **mỗi cơ thể lưỡng bội chỉ mang tối đa hai** trong số đó (một trên mỗi NST tương đồng).

#### 3.3.2. Số kiểu gen trong dãy n alen

| Đại lượng | Công thức | n = 3 (ABO) | n = 4 |
|---|---|---|---|
| Tổng số kiểu gen | **n(n + 1)/2** | 6 | 10 |
| Kiểu gen đồng hợp | **n** | 3 | 4 |
| Kiểu gen dị hợp | **n(n − 1)/2** | 3 | 6 |

*Vì sao?* Đồng hợp: mỗi alen ghép với chính nó, có n cách. Dị hợp: chọn 2 alen khác nhau trong n, có n(n − 1)/2 cách (tổ hợp chập 2).

#### 3.3.3. Ví dụ: nhóm máu ABO

Hệ ABO (sách gọi ABH) do một gen có **3 alen chính**: **I^A^**, **I^B^** (đồng trội với nhau) và **i** (lặn so với cả hai).

| Nhóm máu | Kiểu gen | Kháng nguyên trên hồng cầu | Kháng thể trong huyết thanh |
|---|---|---|---|
| A | I^A^I^A^, I^A^i | A | kháng B |
| B | I^B^I^B^, I^B^i | B | kháng A |
| AB | I^A^I^B^ | A và B | không có |
| O | ii | không có (chỉ có H) | kháng A và kháng B |

Trong một locus ABO có **cả hai** kiểu quan hệ: I^A^ và I^B^ **đồng trội**; I^A^, I^B^ **trội hoàn toàn** so với i.

> [!vi-du] Bài tập nhóm máu
> Bố nhóm A, mẹ nhóm B, con đầu nhóm O. Con O là **ii** nên nhận i từ bố và i từ mẹ → bố **I^A^i**, mẹ **I^B^i**.
>
> | ♂ \ ♀ | **I^B^** | **i** |
> |---|---|---|
> | **I^A^** | I^A^I^B^ (AB) | I^A^i (A) |
> | **i** | I^B^i (B) | ii (O) |
>
> Mỗi lần sinh, xác suất con nhóm A, B, AB, O **bằng nhau, mỗi loại 1/4**.

> [!ung-dung] Nhóm máu trong truyền máu và loại trừ quan hệ cha con
> - Truyền máu phải hợp nhóm vì kháng thể tự nhiên kháng A, kháng B sẵn có trong huyết thanh sẽ ngưng kết hồng cầu lạ.
> - Nhóm máu chỉ dùng để **loại trừ**, không dùng để **khẳng định** cha con. Ví dụ bố mẹ **O × AB** chỉ sinh được con **A hoặc B**, không thể có con O hay AB. Ngày nay xác định huyết thống bằng **xét nghiệm ADN**.

> [!cap-nhat] Cơ sở phân tử của ABO và hệ nhóm máu Rh (bổ sung – kiến thức hiện nay)
> - Gen *ABO* (NST 9) mã hóa một **enzym gắn đường** (glycosyltransferase). Alen I^A^ gắn N-acetylgalactosamin, alen I^B^ gắn galactose lên chất H; hai alen chỉ khác nhau vài acid amin (amino acid). Alen **i** (O) phổ biến nhất bị **mất một nucleotid** làm lệch khung đọc, tạo enzym không hoạt động, nên chất H để "trần". Đây là ví dụ rõ: "trội – lặn" thực chất là **có enzym hoạt động hay không**.
> - **Hệ Rh**: kháng nguyên quan trọng nhất là **D**, do gen *RHD* (NST 1). Người **Rh dương** có ít nhất một bản gen *RHD*; người **Rh âm** thường là **mất cả hai bản** gen này nên Rh dương "trội" so với Rh âm. Khác ABO, người Rh âm **không có sẵn** kháng thể kháng D; chỉ sinh ra sau khi tiếp xúc hồng cầu Rh dương (truyền máu, mang thai).
> - Người Việt Nam có tỷ lệ Rh âm rất thấp, chỉ khoảng **0,04–0,07%** (người châu Âu khoảng 15%), nên máu Rh âm là **nhóm máu hiếm** ở nước ta. Mẹ Rh âm mang thai con Rh dương có thể sinh kháng thể kháng D, gây **tan máu ở thai và sơ sinh** từ lần mang thai sau; phòng bằng tiêm **globulin miễn dịch kháng D** cho mẹ (nguồn: Thompson & Thompson Genetics in Medicine 9th ed.; Vinmec).

## 4. Tương tác giữa hai gen không alen phân ly độc lập

**Bối cảnh:** hai gen không alen nằm trên **hai cặp NST khác nhau** nên vẫn **phân ly độc lập**. Ở F2 (AaBb × AaBb), tỷ lệ các **nhóm kiểu gen** vẫn là:

=> 9 A-B- : 3 A-bb : 3 aaB- : 1 aabb

Nhưng vì hai gen **cùng quy định một tính trạng**, sản phẩm của chúng tác động qua lại, nên **một số nhóm cho cùng kiểu hình**. Kết quả là F2 thường có **ít hơn 4 kiểu hình**, với tỷ lệ là **biến dạng của 9:3:3:1**. Mẹo nhận biết: **tổng các số luôn bằng 16**.

- Nếu hai gen tương tác nhưng vẫn cho **4 kiểu hình** về một tính trạng thì tỷ lệ vẫn là **9 : 3 : 3 : 1** (sách gọi là hiện tượng **liên hợp**). Ví dụ kinh điển: hình dạng mào gà (mào hồng, mào hạt đậu, mào hồ đào, mào đơn).
- Ba gen tương tác, phân ly độc lập → biến dạng của **27 : 9 : 9 : 9 : 3 : 3 : 3 : 1** (tổng 64). Bốn gen thì phức tạp hơn nữa.

Bảng tỷ lệ kiểu hình F2 (Giáo trình tr. 77); cột ví dụ là **bổ sung, không có trong giáo trình**:

| Kiểu tương tác | Tỷ lệ F2 | Nhóm nào gộp lại | Ví dụ |
|---|---|---|---|
| Kinh điển (không gộp) | **9:3:3:1** | Không gộp | Mào gà |
| **Át chế của gen trội** | **12:3:1** | 9 A-B- + 3 A-bb = 12 | Màu quả bí: trắng : vàng : xanh |
| **Át chế của gen lặn** | **9:3:4** | 3 aaB- + 1 aabb = 4 | Màu lông chuột; kiểu hình Bombay ở người |
| **Bổ trợ, hiệu quả bổ sung** | **9:6:1** | 3 A-bb + 3 aaB- = 6 | Hình dạng quả bí: dẹt : tròn : dài |
| **Cộng gộp** | **15:1** | 9 + 3 + 3 = 15 (có ít nhất một alen trội) | Màu hạt lúa mì: đỏ : trắng |
| **Bổ trợ giữa hai gen trội** | **9:7** | 3 + 3 + 1 = 7 (thiếu A hoặc thiếu B) | Màu hoa đậu thơm: đỏ : trắng |
| **Át chế (tác động khử)** | **13:3** | 9 A-B- + 3 A-bb + 1 aabb = 13 | Màu lông gà: trắng : có màu |

**Hiểu bản chất từng kiểu (vì sao gộp như vậy):**

- **Bổ trợ 9 : 7**: cần **cả A lẫn B** mới có kiểu hình (ví dụ hai enzym nối tiếp trên **một con đường** tạo sắc tố; thiếu một trong hai là đứt chuỗi). Chỉ nhóm A-B- (9) có màu; 3 + 3 + 1 = **7** đều không màu.
- **Bổ trợ 9 : 6 : 1**: có cả A và B → một kiểu hình (dẹt); có một trong hai → kiểu hình khác (tròn, 3 + 3 = **6**); không có gen trội nào → kiểu hình thứ ba (dài).
- **Át chế gen lặn 9 : 3 : 4**: kiểu gen **aa** "khóa" không cho B biểu hiện. aaB- và aabb trông như nhau → 3 + 1 = **4**.
- **Át chế gen trội 12 : 3 : 1**: alen trội **A** lấn át B; hễ có A là cùng một kiểu hình → 9 + 3 = **12**.
- **Tác động khử 13 : 3**: A trội "khử" sắc tố, aabb cũng không có sắc tố (thiếu B) → A-B- + A-bb + aabb = 9 + 3 + 1 = **13** không màu; chỉ **aaB-** (3) có màu.
- **Cộng gộp 15 : 1**: mỗi alen trội góp một phần sắc tố; chỉ cần có **ít nhất một** alen trội là có màu; riêng aabb không màu.

> [!vi-du] Cộng gộp: 15 : 1 hay 1 : 4 : 6 : 4 : 1?
> Ở màu hạt lúa mì (Nilsson-Ehle), nếu chỉ chia "có màu" và "trắng" thì F2 là **15 : 1**. Nếu xếp hạng theo **độ đậm**, đếm số alen trội trong kiểu gen (4, 3, 2, 1, 0) thì được **1 : 4 : 6 : 4 : 1**. Đây là cầu nối sang di truyền đa gen (mục 6): càng nhiều gen cộng gộp, các bậc càng sát nhau, biến thiên càng **liên tục**.

> [!ung-dung] Tương tác gen trong y học
> - **Kiểu hình Bombay (át chế lặn)**: kháng nguyên A, B được gắn lên một "nền" gọi là **chất H**, do gen **H** tạo ra. Người **hh** không có chất H, nên dù mang I^A^ hay I^B^ thì hồng cầu vẫn **không có A, không có B**: thử nhóm máu thông thường ra **nhóm O**. Họ có thể sinh con nhóm A hoặc B "trái quy luật" và chỉ được nhận máu của người Bombay. Đây là lý do sách gọi là hệ **ABH**.
> - **Bổ trợ ở người**: điếc bẩm sinh có thể do đồng hợp lặn ở **những gen khác nhau**. Hai vợ chồng cùng điếc (một người aaBB, người kia AAbb) có thể sinh **toàn con nghe bình thường** (AaBb), vì mỗi bên bù cho bên kia gen còn thiếu.

## 5. Tính đa hiệu của gen

**Gen đa hiệu**: **một gen** gây ra **nhiều biểu hiện** kiểu hình khác nhau. Tất cả các biểu hiện ấy là "hiệu quả" của gen đa hiệu.

Mức độ đa dạng:

- Một gen vừa quy định một tính trạng bề ngoài, vừa ảnh hưởng **sức sống, sức sinh sản**. Ví dụ: gen gây **cánh cụt** ở ruồi giấm đồng thời làm ruồi **giảm sức sinh sản**.
- Một gen có thể **trội** đối với tính trạng này nhưng **lặn** đối với tính trạng khác. Ví dụ: đột biến **lông vàng ở chuột** trội về màu lông, nhưng **gây chết khi đồng hợp** (hiệu quả gây chết là lặn).

> [!vi-du] Gen gây chết làm "méo" tỷ lệ 3 : 1
> Lai hai chuột lông vàng (đều phải là dị hợp Aa, vì AA chết): Aa × Aa → 1 AA (**chết** từ phôi) : 2 Aa (vàng) : 1 aa (không vàng). Số con sống sót có tỷ lệ **2 vàng : 1 không vàng**, chứ không phải 3 : 1. Gặp tỷ lệ 2 : 1 trong đề, hãy nghĩ đến **gen gây chết ở trạng thái đồng hợp**.

> [!ung-dung] Đa hiệu trong bệnh di truyền người
> Nhiều bệnh đơn gen có triệu chứng ở **nhiều cơ quan** vì gen tác động lên một thành phần dùng chung. Ví dụ **hội chứng Marfan** (gen fibrillin, một protein của mô liên kết): người cao, chân tay và ngón dài, lệch thể thủy tinh, phình giãn động mạch chủ. Hoặc bệnh **hồng cầu hình liềm**: một đột biến hemoglobin gây thiếu máu, tắc mạch, đau, tổn thương lách, thận.

> [!cap-nhat] Độ thâm nhập và mức biểu hiện (bổ sung – kiến thức hiện nay)
> Ngay cả bệnh đơn gen cũng không phải lúc nào "có gen là có bệnh y hệt nhau":
> - **Độ thâm nhập** (penetrance): tỷ lệ % người mang kiểu gen bệnh **thực sự biểu hiện** bệnh. **Thâm nhập không hoàn toàn**: phụ nữ mang biến thể gây bệnh ở *BRCA1* có nguy cơ ung thư vú suốt đời khoảng **55–72%**, không phải 100%. Vì vậy trong phả hệ bệnh trội có thể "nhảy" qua một thế hệ.
> - **Mức biểu hiện** (expressivity): những người **cùng** mắc bệnh nhưng **nặng nhẹ khác nhau**. Ví dụ bệnh **u xơ thần kinh type 1** (NF1): trong cùng một gia đình, người chỉ có vài đốm cà phê sữa, người lại có rất nhiều u.
> - Nguyên nhân: gen khác (gen bổ trợ), môi trường, yếu tố ngẫu nhiên. Đây là cầu nối giữa di truyền đơn gen và đa nhân tố (nguồn: Thompson & Thompson 9th ed.; NCI – BRCA fact sheet).

## 6. Di truyền đa gen và đa nhân tố

### 6.1. Khái niệm

Lịch sử:

| Năm | Tác giả | Đóng góp |
|---|---|---|
| **1760** | **Kolreuter** | Lai thuốc lá cao × thấp: F1 **trung gian**, F2 biến thiên **liên tục** từ thấp đến cao; chưa giải thích được |
| **1869** | **Galton** | Nhiều tính trạng người (**mạch, huyết áp, vân da**…) và vật nuôi (sữa bò, trứng gà, len cừu) biến thiên liên tục; cho rằng do **nhiều nhân tố** di truyền |
| **1908** (theo sách) | **Nilsson-Ehle** và **East** | Giả thuyết **đa gen**: nhiều gen **tích gộp, tác động cùng chiều** |

**Định nghĩa di truyền đa gen**: tính trạng do **nhiều gen không alen** kiểm soát; **mỗi gen** chỉ có tác động **nhỏ**, một mình không đủ tạo thay đổi thấy được; nhưng **tổng nhiều gen** tác động **cùng một hướng** thì gây thay đổi **về lượng** thấy được ở kiểu hình.

**Di truyền đa nhân tố**: kiểu hình là kết quả của **nhiều gen** tương tác + **nhiều yếu tố môi trường**. Trong đa số trường hợp, hai thuật ngữ "đa gen" và "đa nhân tố" được dùng **như nhau**.

### 6.2. Đặc điểm

1. Phần lớn là **tính trạng số lượng** (đo đếm được), do **nhiều locus** kiểm soát.
2. Ngoài nhiều locus, **dãy nhiều alen** ở mỗi locus cũng góp phần tạo biến thiên. Mỗi thay đổi alen chỉ có hiệu quả nhỏ; **nhiều kiểu gen khác nhau** có thể cho kiểu hình **giống nhau**.
3. Kiểu hình **biến thiên rất lớn** do ảnh hưởng của **môi trường**.
4. Trong quần thể, tính trạng phân bố **liên tục**; quần thể đồng nhất thì có **phân phối chuẩn** (hình chuông). Ví dụ của sách: chiều cao người trưởng thành trong một quần thể biến thiên liên tục **1,42 m → 1,75 m**, trung bình **1,60 m**.
5. Riêng một yếu tố không quyết định tính trạng, nên **không thể tính trước** cho đời con bằng công thức như di truyền hai alen. Chỉ đánh giá được qua **số liệu điều tra quần thể** (con số **kinh nghiệm**, thống kê).

**Ví dụ màu da người:** được đánh giá do **2 đến 20 đôi gen**. **Davenport** (ở **Jamaica**) phân tích **2 đôi gen chủ yếu** và lập bảng phân loại màu da theo **% sắc tố**.

| So sánh | Đơn gen (Mendel) | Đa gen – đa nhân tố |
|---|---|---|
| Số gen | Một locus | Nhiều locus, mỗi gen tác động nhỏ |
| Kiểu tính trạng | Chất lượng, rời rạc (có/không) | Số lượng, đo được |
| Phân bố trong quần thể | Thành nhóm tách biệt | Liên tục, hình chuông |
| Ảnh hưởng môi trường | Thường ít | Lớn |
| Dự đoán ở đời con | Tính được bằng tỷ lệ | Chỉ ước lượng theo số liệu thống kê |

> [!ung-dung] Bệnh đa nhân tố
> Phần lớn bệnh **thường gặp** ở người thuộc nhóm này: **tăng huyết áp, đái tháo đường type 2, bệnh mạch vành, béo phì**, nhiều dị tật bẩm sinh như **khe hở môi – vòm miệng**, **dị tật ống thần kinh**. Gen tạo "nền" nguy cơ; lối sống, môi trường quyết định có phát bệnh hay không. Vì vậy:
> - Nguy cơ cho người thân được ước lượng bằng **số liệu kinh nghiệm**, không bằng tỷ lệ Mendel; người họ hàng càng gần, nguy cơ càng cao.
> - Can thiệp vào **yếu tố môi trường** có hiệu quả thật. Ví dụ bổ sung **acid folic** trước và đầu thai kỳ làm giảm rõ dị tật ống thần kinh.

> [!cap-nhat] Từ "nhiều gen nhỏ" đến điểm nguy cơ đa gen (bổ sung – kiến thức hiện nay)
> - **Mô hình ngưỡng**: với bệnh đa nhân tố, mỗi người có một "mức nhạy cảm" (tổng của nhiều gen nhỏ + môi trường) phân bố hình chuông; chỉ ai vượt **ngưỡng** mới phát bệnh. Mô hình này giải thích vì sao bệnh "có tính gia đình" nhưng không theo tỷ lệ Mendel.
> - **Nghiên cứu liên kết toàn bộ gen** (GWAS) quét hàng trăm nghìn đến hàng triệu **đa hình đơn nucleotid** (SNP) trên rất nhiều người, đã tìm ra hàng nghìn vị trí liên quan đến chiều cao, đái tháo đường type 2, bệnh mạch vành… Riêng chiều cao, một nghiên cứu năm 2022 trên khoảng 5,4 triệu người tìm được **hơn 12.000** biến thể, mỗi biến thể chỉ làm chênh vài milimét: đúng như giả thuyết đa gen của Nilsson-Ehle.
> - **Điểm nguy cơ đa gen** (polygenic risk score, PRS): cộng các "điểm" nhỏ của rất nhiều SNP thành một con số ước lượng nguy cơ. Hiện PRS chủ yếu dùng trong **nghiên cứu**; dự báo cho từng người còn hạn chế và **kém chính xác ở người châu Á, châu Phi** vì dữ liệu gốc phần lớn từ người châu Âu. Một PRS cao **không** có nghĩa chắc chắn mắc bệnh, vì môi trường vẫn góp phần lớn (nguồn: Thompson & Thompson 9th ed.; Yengo et al., *Nature* 2022).

## 7. Liên kết gen và tái tổ hợp gen

### 7.1. Sự liên kết gen

**Lập luận xuất phát:** mỗi loài có **rất nhiều gen** nhưng **ít cặp NST**. Ví dụ của sách:

| Loài | Số gen đã biết (theo sách) | Số cặp NST |
|---|---|---|
| Ngô | > 500 | 10 |
| Ruồi giấm | > 1000 | 4 |
| Người | > 30.000 | 23 |

→ Mỗi NST phải mang **cả một nhóm gen**. Các gen trên cùng một NST hợp thành một **nhóm liên kết** và có xu hướng **di truyền cùng nhau**. Số nhóm liên kết bằng **số NST trong bộ đơn bội** (n).

**Lịch sử:**

- **Bateson và Punnett (1906)**: lần đầu thấy hiện tượng liên kết khi lai các thứ **đậu thơm**. Lai hai tính nhưng **không** ra kết quả độc lập như Mendel; hai tính trạng có xu hướng đi cùng nhau qua nhiều thế hệ.
- **Morgan và cộng sự (từ 1910)**, trên **ruồi giấm**: chứng minh có các **nhóm gen liên kết** ứng với từng NST. Và liên kết **không tuyệt đối**: gen trên hai NST tương đồng (một nguồn bố, một nguồn mẹ) có thể **đổi chỗ** cho nhau.
- **Nguyên nhân liên kết không hoàn toàn**: ở kỳ đầu giảm phân I, hai NST tương đồng **tiếp hợp** rồi **bắt chéo** (hình chữ X). Morgan cho rằng lúc bắt chéo có **trao đổi đoạn** giữa hai NST khác nguồn, mang theo gen trên đoạn ấy → **hoán vị gen**.

![Hình 2. Liên kết gen và hoán vị gen: trao đổi chéo giữa hai chromatid không chị em tạo ra giao tử tái tổ hợp](hoan-vi-gen.svg)

| | Liên kết hoàn toàn | Liên kết không hoàn toàn (có hoán vị) |
|---|---|---|
| Trao đổi chéo giữa hai gen | Không xảy ra | Xảy ra ở một số tế bào |
| Giao tử của AB/ab | 2 loại: AB, ab (mỗi loại 50%) | 4 loại: 2 **liên kết** chiếm đa số + 2 **hoán vị** chiếm thiểu số |
| Lai phân tích AB/ab × ab/ab | **1 : 1** | 2 lớp **lớn bằng nhau** + 2 lớp **nhỏ bằng nhau** |

**Sturtevant** (sách ghi năm 1919) phân tích liên tiếp sự bắt chéo của **ba gen** trong cùng nhóm liên kết và thấy: nếu tần số giữa A–B là **M**, giữa A–C là **H**, thì tần số giữa B–C luôn là **M + H** hoặc **M − H**. Điều này **chỉ** giải thích được nếu các gen **xếp thẳng hàng** trên NST, theo chiều dài. Từ đó lập được **bản đồ đường thẳng** của NST ở nhiều sinh vật.

> [!cap-nhat] Mốc thời gian và số gen
> - Sturtevant công bố **bản đồ di truyền đầu tiên** (trên NST X ruồi giấm) năm **1913**; giáo trình ghi 1919.
> - Giáo trình ghi người có "hơn 30.000 gen". Từ khi hoàn thành giải trình tự bộ gen người (2003) và các ước tính về sau, số gen **mã hóa protein** ở người khoảng **20.000**. Đi thi theo sách.

### 7.2. Nguyên tắc lập bản đồ di truyền

**Bản đồ di truyền**: sơ đồ **vị trí tương đối** của các gen trên các NST của **bộ đơn bội**. Loài có NST giới X và Y khác nhau thì lập bản đồ cho **cả X và Y**.

**Bước 1. Xác định gen có cùng nhóm liên kết không:**

| Phép lai | Hai gen trên **hai NST khác nhau** | Hai gen trên **cùng một NST** |
|---|---|---|
| F1 × F1 (lai hai tính) | F2 **9 : 3 : 3 : 1** | F2 **3 : 1** hoặc gần 3 : 1 (do có thể có trao đổi chéo) |
| **Lai phân tích** F1 × đồng hợp lặn (hay dùng hơn) | **1 : 1 : 1 : 1** | **1 : 1**, hoặc 2 lớp lớn bằng nhau + 2 lớp nhỏ bằng nhau |

**Bước 2. Xác định vị trí gen theo khoảng cách:**

- Khoảng cách giữa hai gen **tỷ lệ thuận** với **tần số trao đổi chéo** (tần số hoán vị). *Vì sao?* Hai gen càng xa nhau, chỗ bắt chéo càng dễ rơi vào khoảng giữa chúng.
- **1% trao đổi chéo = 1 đơn vị bản đồ = 1 centiMorgan (cM).**
- Một cặp NST có thể bắt chéo **một, hai, ba lần** hoặc hơn; trao đổi có thể liên quan **hai, ba hay cả bốn** chromatid của cặp NST kép.

=> Tần số hoán vị (f) = số cá thể tái tổ hợp / tổng số cá thể đời con của phép lai phân tích × 100%

> [!vi-du] Bài tập hoán vị gen
> Ruồi cái F1 dị hợp **AB/ab** lai phân tích với đực ab/ab, đời con: **415** A-B- : **415** aabb : **85** A-bb : **85** aaB-.
> - Hai lớp lớn (A-B-, aabb) là **kiểu liên kết** (giống P); hai lớp nhỏ là **tái tổ hợp**.
> - f = (85 + 85) / 1000 = **17%** → hai gen cách nhau **17 cM**.
> - Ngược lại, biết f = 20% thì cơ thể AB/ab cho giao tử: AB = ab = (100 − 20)/2 = **40%**; Ab = aB = 20/2 = **10%**.
>
> Lưu ý: ở **ruồi giấm đực** hầu như **không có** trao đổi chéo trong giảm phân, nên ruồi đực AB/ab lai phân tích cho **1 : 1**. Đây là chi tiết Morgan dùng để chứng minh liên kết hoàn toàn.

> [!bay]
> - Tần số hoán vị **không vượt quá 50%**. Hai gen rất xa nhau trên cùng NST cho kết quả giống phân ly độc lập (1:1:1:1).
> - Phải xác định đúng **pha**: AB/ab (dị hợp **đều**, "cis") khác Ab/aB (dị hợp **chéo**, "trans"). Với Ab/aB, hai lớp **lớn** lại là Ab và aB.

### 7.3. Bắt chéo soma và lai tế bào soma

- **Bắt chéo soma**: trao đổi chéo **không chỉ** xảy ra trong giảm phân mà cả trong **tế bào soma** (tế bào sinh dưỡng). Phát hiện trên ruồi giấm (sách ghi "Steri", tức **Curt Stern**); **Pontecorvo** thấy ở nhân lưỡng bội của nấm mốc **Aspergillus**. Hiện tượng này **khá nhiều** nhưng ít được phát hiện vì **hiếm khi biểu hiện ra kiểu hình**.
- **Lai tế bào soma** (từ thập niên **70** thế kỷ XX): dung hợp tế bào khác loài (ví dụ người – chuột). Tế bào lai dần mất NST người, nên đối chiếu "còn NST nào thì còn sản phẩm gen nào" giúp **gán gen vào NST**. Phương pháp này rút ngắn rất nhiều thời gian lập **bản đồ gen người**.

**Ý nghĩa:** liên kết gen là hiện tượng **phổ biến ở mọi sinh vật**. Các quy luật liên kết của Morgan (trên NST thường và NST giới tính) **bổ sung** cho Mendel, giải thích được liên kết hoàn toàn, liên kết không hoàn toàn và liên kết giới tính.

> [!ung-dung] Liên kết gen trong chẩn đoán
> Trước khi tìm ra chính xác gen bệnh, người ta dùng các **dấu ấn ADN** nằm **sát** gen bệnh (liên kết chặt, ít hoán vị) để theo dõi gen bệnh trong gia đình, phục vụ chẩn đoán trước sinh. Dấu ấn càng gần gen, tần số hoán vị càng nhỏ, chẩn đoán càng tin cậy.

## 8. Sự di truyền giới tính

Sinh vật có **hai giới** là một bước tiến hóa giúp tăng khả năng **thích nghi di truyền** (tái tổ hợp qua sinh sản hữu tính). Có nhiều cơ chế xác định giới tính và tỷ lệ đực : cái; **phần lớn** do **yếu tố di truyền** kiểm soát, **rất ít** loài do **môi trường**.

### 8.1. Xác định giới tính do nhiễm sắc thể giới

#### 8.1.1. Nhiễm sắc thể giới

| Năm | Tác giả | Phát hiện |
|---|---|---|
| **1891** | **Henking** (Đức) | Ở tế bào dòng tinh của côn trùng có một cấu trúc đặc biệt, chỉ **1/2** số tế bào có; đặt tên "**vật thể X**"; suy ra có **hai loại tinh trùng** |
| **1902** | McClung (sách ghi "Chung M.C") | Châu chấu cái và đực có **số lượng NST khác nhau** |
| **1905** | **Wilson và Stevens** | Liên hệ giới tính với NST; tìm ra hai cơ chế **XX – XO** và **XX – XY** |
| **1906** | **Wilson** | Định nghĩa NST giới |

**Định nghĩa (Wilson 1906, diễn đạt lại):** NST giới là **một, hai hoặc một nhóm** NST đặc biệt, có ở tế bào Eukaryota **phân tính đực – cái**, **đại diện cho hai giới** đã phân hóa. Loài **lưỡng tính** thì **không có** các NST này; tế bào sinh dục đực, cái hình thành nhờ **phân hóa mô**.

**Ba nhóm hệ thống NST giới** (xét ở **giới dị giao tử**):

1. **Có ghép đôi và trao đổi chéo** trong giảm phân: X và Y còn **một số đoạn tương ứng** (một số loài XX/XY).
2. **Không có ghép đôi, trao đổi chéo**: ví dụ **XX/XO** (chỉ có một X, không có bạn để ghép).
3. **Khác biệt hoàn toàn**: X không có đoạn nào tương ứng trên Y và ngược lại (một số loài XX/XY).

#### 8.1.2. Các cơ chế xác định giới tính do NST giới

| Cơ chế | Giới **dị giao tử** | Giới đồng giao tử | Ví dụ |
|---|---|---|---|
| **XX – XY** | **Đực XY** | Cái XX | **Người, động vật có vú, ruồi giấm** |
| **XX – XO** | **Đực XO** | Cái XX | Bộ **Hemiptera, Orthoptera**: rệp, **châu chấu** |
| **ZZ – ZW** | **Cái ZW** | Đực ZZ | **Bướm, tằm**, một số **chim** và **cá** |
| **ZZ – ZO** | **Cái ZO** | Đực ZZ | **Bọ nhậy** |

*Vì sao tỷ lệ đực : cái ≈ 1 : 1?* Giới dị giao tử tạo **hai loại giao tử** với tỷ lệ **bằng nhau**; giới đồng giao tử chỉ tạo **một loại**.

=> Người: P ♀XX × ♂XY → G: X ; (1/2 X, 1/2 Y) → F1: 1 XX (gái) : 1 XY (trai)

=> Tằm: P ♂ZZ × ♀ZW → G: Z ; (1/2 Z, 1/2 W) → F1: 1 ZZ (đực) : 1 ZW (cái)

> [!bay]
> - Ở người, giới tính con do **tinh trùng (bố)** quyết định; ở **chim, bướm, tằm**, lại do **trứng (mẹ)** quyết định vì con **cái** là giới dị giao tử.
> - XO ở **châu chấu** là **đực** bình thường; còn ở người, **45,X** là **nữ** mắc **hội chứng Turner**. Cơ chế xác định giới khác nhau giữa các loài.

> [!cap-nhat] Ở người, Y quyết định giới nam nhờ gen SRY
> Giáo trình chỉ nêu cơ chế XX – XY. Hiện nay biết rằng ở người, giới nam được quyết định bởi **gen SRY** trên nhánh ngắn NST **Y**: có SRY thì tuyến sinh dục nguyên thủy phát triển thành **tinh hoàn**. Vì thế người 47,XXY (Klinefelter) vẫn là **nam**, còn người 45,X (Turner) là **nữ**. Rất hiếm khi SRY bị chuyển sang X, tạo ra **nam 46,XX**. Ngoài ra, ở **chim** nói chung (không riêng "một số chim") đều là hệ **ZZ – ZW**.

#### 8.1.3. Xác định giới tính ở thực vật

Ở một số thực vật **phân tính khác gốc** (cây đực, cây cái riêng), giới tính do cặp **NST giới** quy định.

- **Rêu *Sphaerocarpus*** (thực vật sinh sản bằng bào tử, cơ thể **đơn bội n**; Allen, 1917): cây **đực** có **7 NST thường + 1 Y nhỏ** hình dấu chấm; cây **cái** có **7 NST thường + 1 X rất dài**.
- **Cây có hoa *Melandrium album*** (cơ thể 2n): cây **cái 22A + XX**, cây **đực 22A + XY**. Cây đực cho hai loại tinh trùng **11A + X** và **11A + Y**; cây cái cho noãn **11A + X**. Hợp tử 22A + XX → hạt mọc cây cái; 22A + XY → cây đực.

### 8.2. Xác định giới tính đơn bội thể

Ở **bộ cánh màng (Hymenoptera)**: **kiến, ong mật, ong bò vẽ**…

- Con **cái lưỡng bội (2n)**, phát triển từ trứng **được thụ tinh**.
- Con **đực đơn bội (n)**, phát triển từ trứng **không thụ tinh**, có số NST bằng **một nửa** con cái.
- Ở ong mật, **đơn bội hay lưỡng bội** quyết định **đực hay cái**; còn **dinh dưỡng** quyết định con cái **hữu thụ hay bất thụ**: chỉ ấu trùng được nuôi bằng thức ăn đặc biệt (sữa ong chúa) mới thành **ong chúa** hữu thụ; các con cái 2n khác thành **ong thợ** bất thụ.

**Ví dụ ong ký sinh *Habrobracon juglandis***: có một **locus giới tính** với **9 alen**.

- Con **cái** luôn **dị hợp** về locus này (ví dụ s^a^s^b^, s^a^s^c^…).
- Con **đực bình thường** đơn bội, chỉ có **một** alen (s^a^, s^c^…).
- Khi **giao phối cận huyết**, có thể xuất hiện cá thể **lưỡng bội nhưng đồng hợp** (s^a^s^a^…) → thành **đực 2n**, và **bất thụ** rõ rệt nên thực tế không có vai trò gì.
- Tóm lại: **dị hợp → cái**; **đồng hợp hoặc đơn bội → đực**.

### 8.3. Giới tính do một gen quy định

**Một cặp alen** (hay gặp ở cây phân tính khác gốc, hiếm ở động vật):

| Loài | Đực | Cái | Phép lai thường gặp → tỷ lệ |
|---|---|---|---|
| Cây ***Bryonia dioica*** (Correns) | **Mm** (M: đực) | **mm** | Mm × mm → 1 đực : 1 cái |
| Cá **Gupi** (*Lebistes reticulatus*) | **Mf** (M trội) | **ff** | Mf × ff → 1 đực : 1 cái |

**Nhiều alen của một gen phụ trợ**: chính là trường hợp *Habrobracon* (mục 8.2): giới tính phụ thuộc cả **đơn bội** lẫn trạng thái **đồng hợp** ở một locus có 9 alen.

### 8.4. Xác định giới tính do môi trường

Một số trường hợp đặc biệt, giới tính chỉ phụ thuộc **môi trường**. Ví dụ cây ***Arisaema japonica*** (chi Thiên nam tinh): **củ to**, nhiều chất dinh dưỡng → cây ra **hoa cái**; **củ gầy** → chỉ ra **hoa đực**.

*Vì sao hợp lý?* Tạo hạt, quả tốn nhiều chất dinh dưỡng hơn tạo phấn, nên chỉ cây "đủ vốn" mới làm cây cái.

## 9. Di truyền liên kết giới tính

### 9.1. Nguyên lý chung

Cặp NST giới **vốn là một cặp NST thường** đã phân hóa. Vì vậy, ngoài gen quy định giới, chúng còn mang **nhiều gen quy định tính trạng thường**. Trong tiến hóa, X và Y khác nhau dần; một số gen bị bất hoạt, mất đi ở NST này hoặc NST kia. Kết quả có ba vùng:

| Vùng | Gen nằm ở đâu | Ví dụ kiểu di truyền |
|---|---|---|
| Vùng **không tương đồng trên X** | Có trên X, **không có alen trên Y** | Liên kết X (mục 9.2) |
| Vùng **không tương đồng trên Y** | Có trên Y, **không có alen trên X** | Liên kết Y (mục 9.3) |
| Vùng **tương đồng** của X và Y | Có alen trên **cả X và Y** (chỉ ở loài mà X–Y còn ghép đôi, trao đổi chéo) | Mục 9.4 |

Quy luật di truyền phụ thuộc vào gen nằm ở **vùng nào**, và loài có giới **dị giao tử đực** hay **dị giao tử cái**.

### 9.2. Gen trên X không có alen trên Y (hoặc gen trên Z không có alen trên W)

**Nguyên lý cốt lõi:** ở giới dị giao tử (XY), Y **không có alen tương ứng**, nên **một alen đơn độc trên X**, dù trội hay lặn, **đều biểu hiện ra kiểu hình**. Người ta nói con đực XY là **bán hợp tử** (hemizygous) về gen trên X.

- Ở loài ZZ – ZW: tương tự, **con cái ZW** biểu hiện mọi gen trên Z ở dạng đơn.
- Ở giới **XO** hoặc **ZO**: mọi gen trên X (hoặc Z) đều biểu hiện vì không có NST thứ hai.

**Hệ quả với gen lặn liên kết X ở người (ví dụ mù màu, hemophilia):**

Ký hiệu: X^H^ bình thường, X^h^ gây bệnh hemophilia A.

| Kiểu gen | Nữ | Nam |
|---|---|---|
| X^H^X^H^ | Bình thường | |
| X^H^X^h^ | **Bình thường, mang gen** | |
| X^h^X^h^ | Bị bệnh (rất hiếm) | |
| X^H^Y | | Bình thường |
| X^h^Y | | **Bị bệnh** (chỉ cần **một** alen) |

**Phép lai 1: mẹ mang gen × bố bình thường**

=> P: X^H^X^h^ × X^H^Y

| ♂ \ ♀ | **X^H^** | **X^h^** |
|---|---|---|
| **X^H^** | X^H^X^H^ (gái bình thường) | X^H^X^h^ (gái mang gen) |
| **Y** | X^H^Y (trai bình thường) | **X^h^Y (trai bị bệnh)** |

→ Trong số **con trai**: **1/2 bị bệnh**. Trong số **con gái**: không ai bệnh, **1/2 mang gen**. Tính trên tổng số con: 1/4 là con trai bị bệnh.

**Phép lai 2: bố bị bệnh × mẹ bình thường (không mang gen)**

=> P: X^H^X^H^ × X^h^Y → con gái 100% X^H^X^h^ (mang gen); con trai 100% X^H^Y (bình thường)

**Đặc điểm nhận dạng di truyền lặn liên kết X:**

1. Bệnh gặp chủ yếu ở **nam**.
2. **Không truyền từ bố sang con trai** (bố cho con trai **Y**, không cho X).
3. Bố bị bệnh → **mọi con gái** đều mang gen.
4. Bệnh thường **"cách thế hệ"**: ông ngoại bị → mẹ mang gen → cháu trai bị (di truyền **chéo** qua con gái).

![Hình 3. Phả hệ minh họa bốn kiểu di truyền: trội NST thường, lặn NST thường, lặn liên kết X, ty thể (theo dòng mẹ)](pha-he.svg)

> [!ung-dung] Bệnh lặn liên kết X thường gặp
> - **Mù màu đỏ – lục**: gặp ở vài phần trăm nam giới (tới 5–8% ở người châu Âu), rất ít ở nữ (nữ phải là X^a^X^a^ mới bị).
> - **Hemophilia A** (thiếu yếu tố đông máu **VIII**) và **hemophilia B** (thiếu yếu tố **IX**): chảy máu kéo dài, chảy máu khớp. Ví dụ lịch sử: Nữ hoàng Victoria mang gen, truyền qua các con gái vào nhiều hoàng tộc châu Âu.
> - **Thiếu men G6PD**: tan máu khi gặp tác nhân oxy hóa; **phổ biến ở Việt Nam**. Tỷ lệ thay đổi nhiều theo vùng và dân tộc (khoảng 0,5% ở người Kinh phía Bắc nhưng khoảng 9–14% ở một số nhóm phía Nam và tới 10–31% ở một số dân tộc thiểu số vùng núi phía Bắc; Malaria Journal, 2009); một nghiên cứu sàng lọc sơ sinh ở Hà Nội cho khoảng **4–5%** trẻ có kết quả nguy cơ cao (Medlatec, 2023). Thiếu G6PD nằm trong danh mục **sàng lọc sơ sinh** của Bộ Y tế (Thông tư 12/2026/TT-BYT). Trước khi dùng **primaquin/tafenoquin** (diệt thể ngủ của ký sinh trùng sốt rét *P. vivax*), WHO khuyến cáo xét nghiệm G6PD.
> - **Loạn dưỡng cơ Duchenne**: bé trai yếu cơ tiến triển, thường phải ngồi xe lăn khoảng 10–12 tuổi.
> Trong tư vấn: con gái của người bố bị bệnh **chắc chắn mang gen**; mỗi con trai của cô ấy sau này có nguy cơ **1/2**.

> [!yhct] Thiếu G6PD: thận trọng với một số dược liệu
> Người thiếu G6PD (lặn liên kết X, chủ yếu là nam) bị **tan máu** khi tiếp xúc chất oxy hóa: **đậu tằm** (*Vicia faba*), **băng phiến** (naphthalen), một số thuốc (primaquin, sulfonamid…). Với dược liệu chứa **berberin** (**Hoàng liên**, **Hoàng bá**), mối lo chính là ở **trẻ sơ sinh**: thực nghiệm trên động vật cho thấy berberin **đẩy bilirubin khỏi albumin**, có thể làm vàng da sơ sinh nặng hơn (nguy cơ vàng da nhân), mà trẻ thiếu G6PD vốn dễ vàng da nặng. Vì lo ngại này, Singapore từng cấm các sản phẩm chứa berberin trong nhiều năm (sau đã dỡ bỏ). Còn việc berberin trực tiếp gây tan máu ở người thiếu G6PD chỉ dựa trên một số báo cáo ca, **chưa được chứng minh chắc chắn**. Thực hành thận trọng: **hỏi tiền sử thiếu G6PD** (thường có trong kết quả sàng lọc sơ sinh), tránh dùng các vị này cho trẻ sơ sinh (nhất là trẻ thiếu G6PD hoặc đang vàng da) và cân nhắc kỹ ở phụ nữ có thai, cho con bú.

### 9.3. Gen trên Y không có alen trên X

Trong tiến hóa, Y bị **tiêu giảm** nhiều; ở nhiều loài Y chỉ còn **chất dị nhiễm sắc bất hoạt**. Nhưng một số loài Y vẫn có **đoạn đặc hiệu** mang gen.

Vì **không có alen trên X**, các gen này:

- chỉ truyền trong **giới XY**: **bố → 100% con trai** (di truyền "**thẳng**");
- **không bao giờ** biểu hiện ở giới XX.

> [!vi-du] Gen trên Y ở người
> Gen trên Y được biết rõ nhất ở người là **SRY** (quyết định tinh hoàn) và các gen vùng **AZF** cần cho **sinh tinh**: mất đoạn AZF gây **không có tinh trùng** hoặc ít tinh trùng ở nam giới vô sinh. Sách phổ thông hay lấy ví dụ "**túm lông ở vành tai**" là tính trạng liên kết Y; hiện nay ví dụ này **không còn được xem là chắc chắn**.

### 9.4. Gen trên đoạn tương đồng của X và Y

- Ở ***Melandrium album***, X và Y có **đoạn tương đồng**. Gen gây **phiến lá hẹp** và **lá vàng nhạt** liên kết **X**; gen **hạn chế đốm lá** liên kết **Y**; còn gen quy định **các màu lá khác** nằm trên **đoạn tương đồng** của X và Y.
- Ở đoạn tương đồng, X và Y **tiếp hợp** trong giảm phân (tạo **lưỡng trị**); cặp alen trên X và Y **tương tác** với nhau như cặp alen trên NST thường.
- Ở **người**, gần đây xác định được một **đoạn nhỏ tương đồng** ở **vùng đầu mút** của X và Y.

> [!cap-nhat] Vùng giả NST thường (PAR)
> Đoạn tương đồng đầu mút X – Y ở người ngày nay gọi là **vùng giả NST thường** (pseudoautosomal region, **PAR1** ở đầu nhánh ngắn và **PAR2** ở đầu nhánh dài). Ở PAR1 luôn có trao đổi chéo giữa X và Y trong giảm phân ở nam, nên gen ở đây di truyền **gần giống gen trên NST thường**. Ví dụ gen **SHOX** (liên quan chiều cao) nằm ở PAR1.

## 10. Tính trạng bị hạn chế bởi giới tính

**Phải phân biệt** với liên kết giới tính:

| | Liên kết giới tính | **Hạn chế bởi giới tính** |
|---|---|---|
| Gen nằm ở | **NST giới** (X, Y, Z…) | **Bất kỳ** cặp NST nào (thường là NST thường) |
| Có mặt ở | Phân bố khác nhau giữa hai giới | **Cả hai giới** |
| Biểu hiện | Theo quy luật của NST giới | Chỉ hoặc chủ yếu ở **một giới** |
| Nguyên nhân khác biệt | Số lượng và loại NST giới | Ảnh hưởng của **hormon sinh dục** đực, cái |

**Ví dụ điển hình:** **khả năng cho sữa của bò**. Bò đực cũng mang gen quy định lượng sữa nhiều hay ít, nhưng **không biểu hiện** ở chính nó; gen chỉ biểu hiện ở **con cái** thế hệ sau. Vì thế chọn bò đực giống phải dựa vào **năng suất sữa của đàn con gái**.

> [!vi-du] Ở người
> Nhiều tài liệu phân biệt thêm hai loại: **hạn chế bởi giới** (chỉ biểu hiện ở một giới, như lượng sữa, râu) và **chịu ảnh hưởng của giới** (biểu hiện ở cả hai nhưng mạnh yếu khác nhau). Ví dụ của loại thứ hai là **hói đầu kiểu nam** (hói do androgen): gen không nằm trên X hay Y, nhưng có **androgen** nên nam bị nhiều và sớm hơn hẳn nữ. Giáo trình gộp hai loại này lại.

> [!cap-nhat] In dấu bộ gen: cùng một gen nhưng "bố khác mẹ" (bổ sung – kiến thức hiện nay)
> Mendel ngầm cho rằng alen nhận từ bố hay từ mẹ đều có giá trị như nhau. Hiện nay biết có khoảng **100–200 gen** ở người bị **in dấu bộ gen** (genomic imprinting): trong giao tử, bản gen của một bên được **methyl hóa ADN** và **tắt**, chỉ bản của bên kia hoạt động. Đây là cơ chế **biểu sinh** (thay đổi biểu hiện gen mà không đổi trình tự ADN), được "xóa và in lại" ở mỗi thế hệ khi tạo giao tử.
> - Ví dụ kinh điển ở vùng **15q11–q13**: một số gen chỉ hoạt động trên bản **của bố**, gen *UBE3A* (trong nơron) chỉ hoạt động trên bản **của mẹ**.
> - **Mất vùng này trên NST 15 của bố** (khoảng 70% ca) hoặc **cả hai NST 15 đều từ mẹ** (khoảng 25%, gọi là **disomy một bố mẹ**) → **hội chứng Prader-Willi**: trẻ sơ sinh giảm trương lực cơ, sau đó **ăn không biết no**, béo phì, chậm phát triển trí tuệ nhẹ, thấp, suy sinh dục.
> - **Mất cùng vùng đó nhưng trên NST 15 của mẹ** (khoảng 70% ca), hoặc đột biến *UBE3A* của mẹ → **hội chứng Angelman**: chậm phát triển nặng, gần như không nói, động kinh, dáng đi mất thăng bằng, hay cười.
> - Bài học: cùng một mất đoạn, **nguồn gốc bố hay mẹ** quyết định bệnh nào; đây là điều tỷ lệ Mendel không dự đoán được (nguồn: MedlinePlus Genetics – Prader-Willi syndrome, Angelman syndrome; Thompson & Thompson 9th ed.).

## 11. Di truyền ngoài nhiễm sắc thể

### 11.1. Đặc điểm chung

Phần lớn ADN và phần lớn tính trạng do **gen trong nhân** quy định. Nhưng có một số tính trạng do **yếu tố di truyền ngoài NST** ở tế bào chất: ADN của **ty thể**, **lạp thể**, và các đơn vị di truyền **tự do** trong tế bào chất. Tất cả hợp thành **hệ gen ngoài NST**.

**Đặc điểm (Giáo trình tr. 84–85):**

1. Tính trạng **không phân ly**, hoặc phân ly **không theo kiểu Mendel**.
2. **Thay nhân** bằng nhân có cấu trúc di truyền khác thì tính trạng **không đổi**. Lai trở lại (lai ngược) nhiều thế hệ với dòng bố thì tính trạng (theo mẹ) vẫn **giữ nguyên**.
3. **Lai thuận và lai nghịch cho kết quả khác nhau** (ở loài noãn giao).
4. Di truyền **theo dòng mẹ**. *Vì sao?* Trứng góp cho hợp tử **gần như toàn bộ tế bào chất**; tinh trùng góp rất ít. Nên gen tế bào chất của hợp tử chủ yếu là của **mẹ**.
5. Đột biến gen tế bào chất **không xếp được** vào nhóm liên kết nào bằng các phương pháp lập bản đồ ở mục 7.
6. Một số nhân tố tế bào chất truyền theo kiểu **giống lây nhiễm**.
7. Gen ngoài NST cũng **đột biến**, và đột biến ấy di truyền theo quy luật tế bào chất.

> [!bay] Hiệu quả dòng mẹ khác di truyền tế bào chất
> - **Hiệu quả dòng mẹ** (*maternal effect*): con giống mẹ vì **sản phẩm của gen trong nhân của mẹ** (mARN/mRNA, protein) đã tích sẵn trong tế bào chất của trứng trước khi thụ tinh. Chỉ kéo dài **một thế hệ**; đến đời sau, kiểu hình lại theo kiểu gen của mẹ đời đó (tức là tuân theo Mendel nhưng **chậm một thế hệ**). Ví dụ kinh điển: chiều xoắn vỏ **ốc Limnaea**.
> - **Di truyền tế bào chất**: gen nằm **ngoài nhân**, truyền theo dòng mẹ **qua nhiều thế hệ**.

### 11.2. Hệ gen lạp thể

- ADN lạp thể: **xoắn kép, dạng vòng**; chiếm khoảng **1–5%** ADN của tế bào; khoảng **10^−11^ – 10^−12^ mg** trên một lạp thể; mã hóa acid amin cho **hàng trăm** loại protein.
- Quy định một số tính trạng của lạp thể: khả năng **hóa lục** và **quang hợp** bình thường; đột biến làm **mất màu lục**.
- **Đặc điểm riêng**: lạp thể **phân ly lộn xộn** khi tế bào phân chia (phân phối **ngẫu nhiên**), nên thế hệ con có **nhiều kiểu hình khác nhau** (ví dụ lá **khảm**, có đốm xanh trắng).

### 11.3. Hệ gen ty thể

#### 11.3.1. ADN ty thể

- Phân tử ADN **xoắn kép, dạng vòng**, khoảng **15.000 cặp base** (theo sách); nhỏ hơn bộ gen của sinh vật tự do nhỏ nhất (*Mycoplasma*) khoảng **10 lần**.
- Mã hóa: **rARN, tARN của ty thể**, và một số **protein** cần cho cấu trúc, chức năng của ribosom và màng ty thể.
- **Mã di truyền của ty thể không hoàn toàn giống mã di truyền phổ biến** (ví dụ ở ty thể người, UGA mã hóa tryptophan thay vì là mã kết thúc).

> [!cap-nhat] Kích thước bộ gen ty thể người
> Giáo trình ghi khoảng 15.000 cặp base. Bộ gen ty thể người đã được giải trình tự đầy đủ: **16.569 cặp base**, chứa **37 gen** (13 gen mã hóa protein của chuỗi hô hấp, 22 tARN, 2 rARN). Phần lớn protein của ty thể vẫn do **gen trong nhân** mã hóa rồi chuyển vào. Đi thi trả lời "khoảng 15.000 cặp base" theo sách.

#### 11.3.2. Sự di truyền ty thể

- Ty thể **tự nhân đôi**, rồi **phân chia ngẫu nhiên** theo tế bào chất khi tế bào phân chia.
- ADN ty thể cũng **đột biến**, và đột biến được truyền đi qua nhân đôi ADN vòng và nhân đôi ty thể.
- **Sinh sản hữu tính**: truyền **theo dòng mẹ** qua tế bào chất của trứng.
- **Sinh sản vô tính** (và phân bào nói chung): ty thể chia về các tế bào con **đều hoặc không đều**, ngẫu nhiên.

> [!ung-dung] Bệnh ty thể ở người
> - **Quy luật truyền**: mẹ mang đột biến → **có thể truyền cho tất cả con** (cả trai lẫn gái); **bố bị bệnh không truyền** cho con (xem Hình 3).
> - Ví dụ: **bệnh thần kinh thị giác di truyền Leber (LHON)**: mất thị lực trung tâm ở người trẻ, nam nhiều hơn nữ. **MELAS**: bệnh cơ, não, nhiễm acid lactic, cơn giống đột quỵ. Bệnh ty thể hay ảnh hưởng **não, cơ, tim, mắt** là những mô **tiêu thụ nhiều ATP**.
> - **Điếc do kháng sinh nhóm aminoglycosid** (gentamicin, streptomycin…): một số người mang đột biến ADN ty thể (gen rARN 12S) rất dễ điếc sau khi dùng thuốc, kể cả liều thường. Vì truyền theo dòng mẹ, **cả họ ngoại** đều có thể mang; trong lâm sàng cần hỏi tiền sử "điếc sau tiêm thuốc" ở họ hàng bên mẹ.
> - Một tế bào có hàng trăm ty thể; tỷ lệ ADN ty thể đột biến có thể khác nhau giữa các tế bào và các mô (giống "phân ly lộn xộn" của lạp thể), nên cùng một gia đình bệnh có thể **nặng nhẹ rất khác nhau**.

### 11.4. Di truyền tế bào chất (theo dòng mẹ)

Có những trường hợp di truyền **hoàn toàn theo mẹ**, **không kèm phân ly** tính trạng, liên quan đến đặc tính cơ bản của tế bào chất.

**Ví dụ của sách: yếu tố sigma ở ruồi giấm.** Một số ruồi giấm **nhạy cảm với CO~2~** (bị tê liệt khi tiếp xúc CO~2~). Tính nhạy cảm do một **vật thể nhỏ giống virus** trong tế bào chất của tế bào cơ thể và tế bào sinh dục, gọi là **yếu tố sigma**. Nó hoạt động như **gen ngoài nhân** (*plasmogen*) và truyền qua tế bào chất (đây cũng là ví dụ cho đặc điểm "di truyền giống kiểu lây nhiễm").

> [!cap-nhat] Liệu pháp thay thế ty thể
> Để tránh truyền bệnh ty thể nặng, hiện nay một số nước đã cho phép **liệu pháp thay thế ty thể** (Anh hợp pháp hóa năm 2015, Úc năm 2022): chuyển **bộ NST nhân** (từ trứng hoặc từ hợp tử) của người mẹ mang bệnh sang trứng hoặc hợp tử của người cho (đã bỏ nhân) có ty thể bình thường. Tháng 7/2025, nhóm Newcastle (Anh) báo cáo trên *NEJM* **8 trẻ** đã ra đời bằng kỹ thuật chuyển nhân hợp tử (pronuclear transfer); các trẻ khỏe, dù 3/8 trẻ vẫn còn khoảng 5–16% ADN ty thể đột biến của mẹ, nên trẻ cần được theo dõi lâu dài. Đứa trẻ mang ADN nhân của bố mẹ và ADN ty thể của người cho (báo chí gọi là "con của ba người"). Kỹ thuật này dựa đúng vào đặc điểm di truyền ty thể **theo dòng mẹ, tách biệt với nhân**. Đây là kiến thức mở rộng, không có trong giáo trình (nguồn: Newcastle Hospitals NHS, HFEA, 2025).

## Tóm tắt

| Chủ đề | Ý chính |
|---|---|
| Thuật ngữ | Tính trạng; kiểu hình = kiểu gen + môi trường, không phản ánh đủ kiểu gen; kiểu gen quy định mức phản ứng; idiotyp = gen trong nhân + ngoài nhân; alen = dạng khác nhau của cùng một gen, cùng locus |
| Ký hiệu | P bố mẹ (P1, P2…), F con (F1, F2…); in hoa trội, thường lặn, lấy chữ đầu của tính trạng đột biến (g = green); đồng trội: L^M^, L^N^; dãy alen W > … > w |
| Định luật I, II | P thuần chủng → F1 đồng tính (trội); F2 3 trội : 1 lặn = 1 : 2 : 1 kiểu gen; trong số cây trội F2, 1/3 thuần chủng; cơ sở: cặp NST tương đồng phân ly trong giảm phân |
| Định luật III | Hai cặp gen trên hai cặp NST khác nhau phân ly độc lập; F2 9:3:3:1 = (3:1)^2^, 9 kiểu gen; n cặp: 2^n^ giao tử, 4^n^ tổ hợp, 3^n^ kiểu gen, 2^n^ kiểu hình |
| Lịch sử | 1866 công bố (Brno); 1900 phát hiện lại |
| Đơn gen hai alen | Trội hoàn toàn (3:1); trội không hoàn toàn: hoa mõm chó đỏ–hồng–trắng (1:2:1); đồng trội: MN |
| Nhiều alen | Locus phức hợp; mỗi cơ thể chỉ 2 alen; n(n+1)/2 kiểu gen, n đồng hợp, n(n−1)/2 dị hợp; ABO: I^A^ = I^B^ > i |
| Tương tác gen | Tổng 16: át chế trội 12:3:1; át chế lặn 9:3:4; bổ trợ 9:6:1 và 9:7; cộng gộp 15:1; khử 13:3; 3 gen: biến dạng 27:9:9:9:3:3:3:1 |
| Đa hiệu | Một gen nhiều biểu hiện: cánh cụt + giảm sinh sản (ruồi); lông vàng chuột trội, gây chết đồng hợp (2:1) |
| Đa gen – đa nhân tố | Kolreuter 1760, Galton 1869, Nilsson-Ehle và East; nhiều gen nhỏ cùng chiều + môi trường; tính trạng số lượng, phân bố chuẩn (chiều cao 1,42–1,75 m, TB 1,60 m); màu da 2–20 đôi gen (Davenport, Jamaica); không tính bằng công thức |
| Liên kết, hoán vị | Bateson – Punnett 1906 (đậu thơm); Morgan 1910 (ruồi giấm); số nhóm liên kết = n; bắt chéo → hoán vị; Sturtevant: gen xếp thẳng hàng (M ± H); 1% = 1 cM; lai phân tích: 1:1:1:1 (độc lập) vs 1:1 hoặc 2 lớn + 2 nhỏ (liên kết) |
| Bắt chéo soma | Stern (ruồi giấm), Pontecorvo (Aspergillus); lai tế bào soma (từ thập niên 70) giúp lập bản đồ gen người |
| Cơ chế giới tính | XX–XY (người, thú, ruồi giấm); XX–XO (rệp, châu chấu); ZZ–ZW (bướm, tằm, chim, cá); ZZ–ZO (bọ nhậy); thực vật: rêu Sphaerocarpus, Melandrium (22A+XX/XY); đơn bội: Hymenoptera, Habrobracon 9 alen; một gen: Bryonia (Mm đực), cá Gupi (Mf đực); môi trường: Arisaema (củ to → cái) |
| Liên kết X | Giới XY: một alen trên X cũng biểu hiện; lặn liên kết X: nam bị nhiều, không truyền bố → con trai, di truyền chéo; mù màu, hemophilia, G6PD |
| Liên kết Y, đoạn tương đồng | Y: chỉ truyền bố → con trai, không biểu hiện ở XX; đoạn tương đồng X–Y: Melandrium, ở người là đầu mút (PAR) |
| Hạn chế bởi giới | Gen trên NST bất kỳ, có ở cả hai giới, biểu hiện ở một giới do hormon: sữa bò |
| Ngoài NST | Không theo Mendel; lai thuận ≠ lai nghịch; theo dòng mẹ; không xếp vào nhóm liên kết; lạp thể phân ly lộn xộn; ADN ty thể vòng khoảng 15.000 cặp base (thực tế 16.569), mã riêng; yếu tố sigma (ruồi nhạy CO~2~); hiệu quả dòng mẹ chỉ kéo dài 1 thế hệ |
