---
title: Đột biến
thoi-gian: 45 phút
muc-tieu:
- Trình bày được khái niệm đột biến; phân biệt đột biến ở tế bào soma và tế bào sinh dục.
- Trình bày được định nghĩa, cơ chế và phân loại đột biến số lượng NST (đa bội, lệch bội), trong đó có cơ chế không phân ly và thất lạc NST.
- Trình bày được các dạng rối loạn cấu trúc NST kiểu chromatid và kiểu NST (mất đoạn, đảo đoạn, chuyển đoạn, nhân đoạn, NST hai tâm, NST đều) và hiện tượng trao đổi chromatid chị em.
- Trình bày được cơ chế đột biến gen (các dạng biến đổi nucleotid), hậu quả lên protein và sự biểu hiện của gen đột biến.
- Nhận ra được một số hội chứng NST và bệnh gen thường gặp, các tác nhân gây đột biến và cách phòng tránh trong thực hành (kể cả bảo quản dược liệu).
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. **Đột biến** = biến đổi **di truyền được** của vật chất di truyền, ở mức **NST** (nhiễm sắc thể: số lượng, cấu trúc) hoặc mức **gen** (nucleotid); xảy ra ở tế bào **soma** (chỉ ảnh hưởng bản thân) hoặc **sinh dục** (có thể truyền cho con).
> 2. **Số lượng NST**: **đa bội** (3n, 4n… — cả bộ) và **lệch bội** (2n ± 1, 2n ± 2… — một vài chiếc). Cơ chế chính của lệch bội là **không phân ly** (trong giảm phân hoặc khi phân cắt hợp tử) và **thất lạc NST**.
> 3. **Cấu trúc NST**: luôn bắt đầu bằng **đứt gãy**. Kiểu **chromatid** (tác động khi NST đã nhân đôi: S, G2) và kiểu **NST** (tác động khi chưa nhân đôi: G1, đầu S): mất đoạn, đảo đoạn, chuyển đoạn (tương hỗ, hòa hợp tâm), nhân đoạn, NST hai tâm, NST đều, NST vòng.
> 4. **Đột biến gen**: **thay thế, đảo, mất, thêm** nucleotid. Mất/thêm 1–2 nucleotid → **đột biến khung**. Thay thế → **im lặng, sai nghĩa** (vd HbS, HbE) hoặc **vô nghĩa** (tạo UAA, UAG, UGA).
> 5. Tác nhân gây đột biến: **vật lý** (tia X, tia γ, tia UV), **hóa học** (chất alkyl hóa, aflatoxin…), **sinh học** (virus). Phần lớn tổn thương được tế bào **tự sửa chữa**.

## 1. Khái niệm đột biến

Mỗi loài có một **bộ NST đặc trưng** về số lượng, hình thái và cấu trúc. Ở Eukaryota (sinh vật nhân thực), NST được cấu tạo từ **ADN (DNA) và histon**. Bộ NST này bình thường rất ổn định qua các thế hệ tế bào và thế hệ cơ thể.

Dưới tác động của các **tác nhân vật lý, hóa học hoặc sinh học**, đôi khi số lượng, hình thái hay cấu trúc NST bị biến đổi. Biến đổi có thể ở **mức NST** hoặc **mức gen**. Đó là **đột biến**. Đột biến là một dạng **biến dị di truyền được** (khác với biến dị do môi trường, chỉ thay đổi kiểu hình).

Tác nhân gây đột biến có thể tác động lên hai loại tế bào:

| Tác động lên | Có thể gây | Hậu quả |
|---|---|---|
| **Tế bào soma** (sinh dưỡng) | Đột biến gen, đột biến NST | Chỉ xảy ra **trong đời cá thể** bị đột biến, **không truyền** cho con (vd: ung thư) |
| **Tế bào sinh dục** | Đột biến gen, đột biến NST | Có thể **di truyền cho thế hệ sau** |

**Vì sao đột biến không xảy ra liên tục?** Phần lớn tổn thương ADN, NST sau khi xuất hiện được tế bào **tự sửa chữa** về trạng thái bình thường. Chỉ một phần nhỏ không được sửa mới thành đột biến và gây biến đổi kiểu hình ở các mức độ khác nhau. Bài này tập trung vào **cơ chế**; hậu quả bệnh lý được học kỹ ở môn **Di truyền Y học**.

> [!bay]
> "Đột biến soma" **không di truyền cho con** qua sinh sản hữu tính, nhưng **vẫn truyền** cho các tế bào con của tế bào bị đột biến (qua nguyên phân). Ung thư là ví dụ điển hình: một dòng tế bào mang đột biến tăng sinh trong cơ thể, nhưng con cái không nhận được đột biến đó.

## 2. Đột biến nhiễm sắc thể

Đột biến NST gồm 2 loại: **đột biến số lượng** và **đột biến cấu trúc**. Giáo trình dùng bộ NST người làm ví dụ: tế bào sinh dưỡng có **46 NST = 23 cặp**, gồm **22 cặp NST thường** và **1 cặp NST giới tính** (XX ở nữ, XY ở nam).

Cách ghi karyotype: **số NST, NST giới tính, bất thường**. Ví dụ 46,XX (nữ bình thường); 47,XY,+21 (nam có 3 NST 21); 45,X (chỉ 1 NST X).

> [!cap-nhat] Danh pháp ISCN 2024 — từ "di truyền tế bào" sang "di truyền tế bào – hệ gen"
> Cách ghi trên theo **ISCN** (*International System for Human Cytogenomic Nomenclature*). Phiên bản hiện hành là **ISCN 2024** (Karger, 12/2024; cập nhật khoảng 4 năm một lần). Quy tắc cơ bản không đổi: **số NST, giới tính, bất thường**, các thành phần cách nhau bằng **dấu phẩy, không có dấu cách**; thể khảm ngăn bằng dấu **/** (vd 46,XX/47,XX,+21). Tên đầy đủ đã đổi từ *cytogenetic* thành ***cytogenomic*** vì ISCN nay quy định cả cách ghi kết quả **FISH**, **microarray** (bắt đầu bằng **arr**, kèm phiên bản bộ gen tham chiếu, vị trí và số bản sao: **x1** = mất một bản, **x3** = thêm một bản) và **giải trình tự**. (Nguồn: ISCN 2024, Karger.)

### 2.1. Đột biến số lượng NST

Có 2 dạng: **đa bội** (polyploidy) và **lệch bội** (aneuploidy).

#### 2.1.1. Đa bội

**Định nghĩa.** Thể đa bội có bộ NST trong tế bào sinh dưỡng **lớn hơn 2n**, do **cả bộ đơn bội n** được tăng thêm một số chẵn hoặc lẻ lần: **3n** (tam bội), **4n** (tứ bội)… Ở người: 3n = 69, 4n = 92.

**Ba cơ chế gây đa bội:**

| Cơ chế | Diễn biến | Kết quả |
|---|---|---|
| **1. Thụ tinh của giao tử bất thường** | Trong giảm phân, **cả bộ NST không phân ly** → giao tử **2n** | n + 2n → **3n**; 2n + 2n → **4n** |
| **2. Phân chia bất thường của hợp tử** | a) NST nhân đôi nhưng **tế bào chất không chia** → tế bào 4n | Cơ thể **4n** |
| | b) Hợp tử 2n chia **không đều**: phôi bào n (chết) + phôi bào 3n | Cơ thể **3n** |
| | c) Hợp tử **3n chia ba cực** → phôi bào n (chết), 2n, 3n | Thể **khảm 2n/3n** |
| | d) Hợp tử **4n chia ba cực** | Thể **khảm 2n/3n** |
| **3. Thụ tinh kép hoặc tế bào cực xâm nhập** | Một trứng (n) thụ tinh với **hai tinh trùng** (n + n) | Hợp tử **3n** |
| | **Tế bào cực** nhập vào một phôi bào ở giai đoạn 2 phôi bào | Thể **khảm 2n/3n** |

> [!bay] Những chỗ hay hỏi
> - Phôi bào **n** (đơn bội) ở người **luôn bị tiêu biến**, nên trong mọi sơ đồ "chia ba cực" chỉ còn lại các dòng 2n và 3n.
> - Thụ tinh kép (2 tinh trùng + 1 trứng) cho **3n**, không phải 4n.
> - Giao tử 2n + giao tử 2n mới cho 4n.

**Đa bội ở sinh giới.**

- **Thực vật**: rất hay gặp, cả ở cây hoang dại và cây trồng. Cây đa bội thường **to hơn** cây lưỡng bội. Người ta gây đa bội nhân tạo bằng **colchicin, vinblastin** (chất ức chế thoi vô sắc — xem bài *Phân chia tế bào*) hoặc **sốc nhiệt** nóng/lạnh.
- **Động vật**: hiếm; phôi đa bội thường **chết trước khi sinh**.
- **Người**: càng hiếm hơn. Phần lớn phôi đa bội chết trong tử cung. Số ít sống đến lúc sinh hoặc sau sinh thì hầu hết **có dị tật**.

> [!ung-dung] Tam bội trong sản khoa
> Tam bội (69 NST) là một nguyên nhân quan trọng của **sẩy thai sớm**. Một dạng tam bội do **một trứng thụ tinh với hai tinh trùng** liên quan đến **chửa trứng bán phần**. Vì thế mô sẩy thai, mô chửa trứng thường được gửi xét nghiệm di truyền.

**Đa bội nội sinh.** NST nhân lên nhưng tế bào chất không chia, nên tế bào 2n thành **4n**, và **4 NST cùng cặp vẫn nằm cạnh nhau**. Gặp ở cả thực vật và động vật. Ở người, đôi khi thấy ở **lympho bào nuôi cấy** và **mô ung thư**.

#### 2.1.2. Lệch bội

**Định nghĩa.** Số NST của tế bào **tăng hoặc giảm một hoặc vài chiếc** so với bộ lưỡng bội. Khác với đa bội: lệch bội chỉ liên quan đến **một vài cặp**, không phải cả bộ.

**Các dạng lệch bội:**

| Dạng | Công thức | Ý nghĩa | Ví dụ ở người |
|---|---|---|---|
| **Thể không** (nullisomy) | 2n − 2 | Thiếu **cả hai** chiếc của một cặp | Không sống được |
| **Thể đơn** (monosomy) | 2n − 1 | Thiếu **một** chiếc của một cặp | **45,X** (Turner) |
| **Thể ba** (trisomy) | 2n + 1 | Thừa **một** chiếc | **47,XXY** (Klinefelter); **47,XX,+21** (Down) |
| **Thể đa** (polysomy) | 2n + 2, 2n + 3… | Thừa 2–3 chiếc **cùng loại** | **48,XXXY** |
| **Thể ba kép** | 2n + 1 + 1 | Thừa 1 chiếc ở **hai cặp khác nhau** | **48,XXX,+18** (3 NST X và 3 NST 18) |
| **Thể khảm** (mosaic) | — | Một cơ thể có **2–3 dòng tế bào** với karyotype khác nhau | **46,XX/47,XX,+21** |

> [!bay]
> - **48,XXXY** là thể **đa** (thừa 2 chiếc của **cùng** cặp giới tính). **48,XXX,+18** là thể ba **kép** (thừa ở **hai** cặp khác nhau). Cả hai đều có 48 NST.
> - Thể đơn hoàn toàn một NST thường gần như không sống được (chỉ có vài ca rất hiếm, thường là khảm). **45,X là thể đơn hoàn toàn duy nhất hay gặp** ở trẻ sinh sống, dù phần lớn thai 45,X (khoảng 99%) cũng bị sẩy.

**Cơ chế gây lệch bội.** Có 3 cơ chế.

**a) Không phân ly trong giảm phân.** Một cặp NST (hoặc hai chromatid chị em) **không tách nhau** mà cùng đi về một giao tử. Kết quả là có giao tử **thừa** một NST (n + 1) và giao tử **thiếu** một NST (n − 1). Khi thụ tinh với giao tử bình thường sẽ cho hợp tử **2n + 1** hoặc **2n − 1**.

Hiện tượng này có thể xảy ra:

- trong quá trình **tạo tinh** hoặc **tạo trứng**;
- ở **lần phân bào I** hoặc **lần phân bào II**;
- với **NST thường** hoặc **NST giới tính**.

![Hình 1. Không phân ly ở giảm phân I và giảm phân II](khong-phan-ly.svg)

| | Không phân ly ở **giảm phân I** | Không phân ly ở **giảm phân II** |
|---|---|---|
| Cái gì không tách | **Hai NST tương đồng** của một cặp | **Hai chromatid chị em** |
| Số giao tử bất thường / 4 | **4/4** (2 cái n + 1, 2 cái n − 1) | **2/4** (1 cái n + 1, 1 cái n − 1); 2 giao tử còn lại bình thường |
| Giao tử n + 1 mang | 1 NST của bố + 1 NST của mẹ (hai chiếc **khác nhau**) | Hai bản **giống hệt nhau** của cùng một NST |

> [!vi-du] Vì sao không phân ly hay xảy ra ở trứng của mẹ lớn tuổi?
> Noãn bào I hình thành **từ khi người mẹ còn là bào thai** và **dừng ở kỳ đầu I** cho tới lúc rụng trứng, nghĩa là có thể "chờ" 35–45 năm (xem bài *Phân chia tế bào*). Suốt thời gian đó, các protein giữ cặp NST tương đồng và chromatid chị em dính với nhau (cohesin) bị hao mòn dần. Vì vậy khi giảm phân được hoàn tất, các NST dễ đi sai cực. Đây là lý do nguy cơ Down tăng theo **tuổi mẹ**, và phần lớn trường hợp Down do không phân ly ở **giảm phân I của mẹ**.

**b) Không phân ly trong quá trình phân cắt hợp tử.** Hợp tử bình thường (46), nhưng một NST không phân ly trong một lần nguyên phân sớm:

- Ở **lần phân cắt thứ nhất** → hai phôi bào **47** và **45** → cơ thể có hai dòng **47/45**. Nếu dòng 45 không sống được (thường gặp), cơ thể chỉ còn dòng **47**.
- Ở **lần phân cắt thứ hai** → ba dòng **47/46/45**. Nếu dòng 45 chết → thể khảm **46/47**.
- Xảy ra **nhiều lần** → thể khảm phức tạp hơn.

**Vì sao thể khảm thường nhẹ hơn?** Cơ thể có cả tế bào bình thường. Mức biểu hiện tùy **tỷ lệ** và **vị trí** (mô nào) của dòng tế bào bất thường. Ví dụ người Down thể khảm 46,XX/47,XX,+21 thường có biểu hiện nhẹ hơn Down thuần.

**c) Thất lạc NST.** Ở kỳ sau, một NST **không bám được vào thoi vô sắc**, không đi về cực, nằm lơ lửng trong tế bào chất rồi **bị tiêu biến**. Một tế bào con thiếu một NST. Có thể xảy ra trong giảm phân hoặc khi phân cắt hợp tử, với NST thường hoặc NST giới tính. (Ví dụ: thất lạc một NST X hoặc Y trong lần phân cắt sớm là một cách tạo thể khảm 45,X/46,XX hoặc 45,X/46,XY.)

> [!bay]
> Không phân ly tạo **cả hai** loại tế bào thừa và thiếu (47 và 45). **Thất lạc NST chỉ tạo tế bào thiếu** (45), tế bào kia vẫn bình thường (46).

### 2.2. Đột biến cấu trúc NST

**Ba nguyên tắc cơ bản** để hiểu cơ chế:

1. Phân bào chỉ chiếm thời gian ngắn trong chu kỳ tế bào, nên **phần lớn tác động lên NST xảy ra ở gian kỳ**.
2. **Mọi dạng cấu trúc lại** của NST đều **bắt đầu bằng sự đứt gãy**.
3. **Hai đầu mút** (telomer) của NST rất **bền**, giúp bộ NST ổn định. Còn mỏm đứt thì "dính", dễ nối với mỏm đứt khác. Phần lớn chỗ đứt **nối lại đúng như cũ**; chỉ một số nhỏ nối sai và tạo NST cấu trúc lại.

Đột biến cấu trúc chia 2 kiểu, **tùy thời điểm tác động so với pha S** (lúc ADN nhân đôi):

| | **Kiểu chromatid** | **Kiểu nhiễm sắc thể** |
|---|---|---|
| Thời điểm tác động | NST **đã nhân đôi** (pha **S** hoặc **G2**) | NST **chưa nhân đôi** (pha **G1** hoặc **đầu S**) |
| Tổn thương thấy ở | **Một** chromatid | **Cả hai** chromatid, cùng vị trí |
| Các dạng | Khuyết màu đơn, đứt đơn, trao đổi chromatid | Khuyết màu kép, đứt kép, mất đoạn, đảo đoạn, NST hai tâm, chuyển đoạn, nhân đoạn, NST đều |

**Vì sao thời điểm lại quyết định kiểu tổn thương?** Nếu NST bị đứt **trước** khi nhân đôi, khi pha S sao chép, bản sao cũng "chép luôn" chỗ đứt. Đến kỳ giữa ta thấy **hai chromatid cùng đứt** ở một vị trí. Nếu NST bị đứt **sau** khi đã nhân đôi, chỉ chromatid bị trúng đích mới đứt.

#### 2.2.1. Rối loạn cấu trúc kiểu chromatid

1. **Khuyết màu đơn** (gap): một điểm trên **một** chromatid không bắt màu. Chỗ nhạt **không rộng quá đường kính** chromatid (phần hai bên vẫn thẳng hàng).
2. **Đứt đơn** (break): một đoạn của một chromatid **đứt hẳn**, tách xa phần còn lại và thường **lệch trục**.
3. **Trao đổi chromatid** (chromatid exchange): hai hoặc nhiều chromatid (của các NST khác nhau) cùng đứt rồi ghép chéo vào nhau, tạo hình **ba cánh** hoặc **bốn cánh**.

- **Khuyết đơn và đứt đơn** có thể gặp ở NST của **một số người bình thường**.
- **Trao đổi chromatid rất hiếm** ở người bình thường.
- Đứt đơn ở chu kỳ trước có thể thành **NST mất đoạn** ở chu kỳ sau.

> [!bay] Gap khác break thế nào?
> **Khuyết màu** (gap): chỗ nhạt **hẹp** (≤ đường kính chromatid), hai phần **vẫn thẳng trục**. **Đứt** (break): đoạn đứt **tách xa** và **lệch trục**. "Đơn" = một chromatid; "kép" (isogap, isobreak) = cả hai chromatid ở cùng vị trí.

#### 2.2.2. Rối loạn cấu trúc kiểu nhiễm sắc thể

1. **Khuyết màu kép** (isogap): không bắt màu ở **cùng vị trí trên cả hai** chromatid.
2. **Đứt kép** (isobreak): đứt ở cả hai chromatid, **vị trí giống nhau**.

Tùy **số chỗ đứt**, **vị trí** đứt và đứt trên **một, hai hay ba NST** mà hình thành các dạng cấu trúc lại dưới đây.

![Hình 2. Các dạng đột biến cấu trúc trong một nhiễm sắc thể (mỗi chữ là một đoạn gen)](dot-bien-cau-truc.svg)

**3. Mất đoạn** (thiếu đoạn, deletion) — NST bị **thiếu một đoạn**.

- **Mất đoạn cuối**: **một** chỗ đứt trên một nhánh; đoạn **không tâm** bị tiêu đi. Nếu mất đoạn cuối ở **cả hai nhánh**, hai đoạn không tâm tiêu đi, phần mang tâm **uốn cong, hai mỏm nối lại** → **NST vòng có tâm** (ring, r).
- **Mất đoạn giữa**: **hai** chỗ đứt trên **cùng một nhánh**. Đoạn giữa bị tiêu đi hoặc khép thành **vòng không tâm**. Hai phần còn lại nối với nhau.

**Hậu quả — vì sao gen lặn "lộ ra"?** NST mất đoạn ngắn hơn NST tương đồng. Các gen ở đoạn mất không còn, nên trên NST nguyên vẹn chỉ còn **một alen đơn độc** (trạng thái bán hợp tử). Nếu alen đó là **lặn**, nó vẫn biểu hiện được tính trạng vì không còn alen trội đối diện át đi.

> [!ung-dung] Hội chứng mèo kêu (cri du chat) — 46,XX,5p− hoặc 46,XY,5p−
> Do **mất đoạn nhánh ngắn NST số 5**. Trẻ sơ sinh khóc **the thé như mèo kêu** (do bất thường thanh quản), đầu nhỏ, mặt tròn, hai mắt xa nhau, chậm phát triển trí tuệ. Một ví dụ mất đoạn khác là **4p−** (hội chứng Wolf-Hirschhorn). Các mất đoạn rất nhỏ (vi mất đoạn) không thấy trên karyotype thường mà cần kỹ thuật **FISH** hoặc **microarray**.

> [!cap-nhat] Biến thể số lượng bản sao (CNV) và microarray NST (CMA)
> (bổ sung – kiến thức hiện nay) Karyotype nhuộm băng chỉ thấy được mất/nhân đoạn lớn khoảng **5–10 triệu bp** trở lên. Những đoạn mất hoặc lặp nhỏ hơn gọi chung là **biến thể số lượng bản sao** (*copy number variant*, **CNV**). Nhiều CNV vô hại (gặp ở người khỏe), một số gây bệnh — điển hình là **vi mất đoạn 22q11.2** (hội chứng DiGeorge: tim bẩm sinh, hở vòm, thiếu tuyến ức, hạ calci máu), một trong những vi mất đoạn hay gặp nhất.
> - **Microarray NST** (*chromosomal microarray*, **CMA**) đọc đồng thời hàng trăm nghìn điểm trên toàn bộ gen nên phát hiện được CNV rất nhỏ. Từ năm **2010**, đồng thuận quốc tế khuyến cáo CMA là xét nghiệm **đầu tay** cho trẻ **chậm phát triển, khuyết tật trí tuệ, tự kỷ** không rõ nguyên nhân và **đa dị tật bẩm sinh**: tỷ lệ tìm ra nguyên nhân **15–20%**, so với khoảng **5%** của karyotype.
> - Giới hạn: CMA **không** phát hiện được chuyển đoạn, đảo đoạn **cân bằng** (vì không mất, không thừa chất liệu), nên karyotype vẫn cần, ví dụ khi tìm nguyên nhân **sẩy thai liên tiếp**.
>
> (Nguồn: Miller và cs., *Am J Hum Genet* 2010.)

**4. Đảo đoạn** (inversion, inv) — NST **đứt ở hai chỗ**, đoạn giữa **quay 180°** rồi nối lại theo trật tự mới.

- **Đảo đoạn ngoài tâm** (paracentric): hai chỗ đứt trên **cùng một nhánh**. Chiều dài và **vị trí tâm không đổi**, nên **khó nhận ra** bằng nhuộm thường. Nhờ **kỹ thuật nhuộm băng** người ta đã xác định chính xác nhiều trường hợp.
- **Đảo đoạn quanh tâm** (pericentric): hai chỗ đứt ở **hai nhánh, hai bên tâm**. Nếu hai chỗ đứt cách tâm **không bằng nhau**, **chỉ số tâm thay đổi** (tỷ lệ nhánh ngắn/nhánh dài khác đi) → dễ nhận ra hơn.

Đảo đoạn **giữ đủ số gen**, chỉ **đổi trật tự** gen trong đoạn đảo. Khi giảm phân, để các đoạn tương ứng bắt cặp với nhau, NST mang đảo đoạn phải tạo **vòng đảo**, còn NST bình thường uốn thành **chỗ lồi** ôm lấy vòng đó.

> [!vi-du] Người mang đảo đoạn bình thường, nhưng con thì sao?
> Bản thân người mang đảo đoạn thường **khỏe mạnh** vì không mất gen. Nhưng nếu có **trao đổi chéo bên trong vòng đảo** khi giảm phân, một số giao tử sẽ mang NST thiếu đoạn hoặc thừa đoạn. Vì vậy cặp vợ chồng sẩy thai liên tiếp được khuyên làm karyotype để tìm đảo đoạn hoặc chuyển đoạn cân bằng.

**5. NST hai tâm** (dicentric, dic) — **hai NST**, mỗi chiếc bị đứt; hai phần **không tâm tiêu đi**, hai phần **có tâm nối lại** → NST có **hai tâm**. Hay gặp **sau nhiễm xạ**. Nếu ba NST cùng đứt và ba phần có tâm nối lại → **NST ba tâm** (rất hiếm).

> [!ung-dung] "Liều kế sinh học" sau tai nạn phóng xạ
> NST hai tâm trong lympho bào máu ngoại vi gần như chỉ xuất hiện sau **bức xạ ion hóa**, và **tần số tăng theo liều**. Vì vậy đếm NST hai tâm là phương pháp chuẩn để **ước tính liều phóng xạ** một người đã nhận (khi không có liều kế đeo người).

![Hình 3. Chuyển đoạn tương hỗ, chuyển đoạn hòa hợp tâm và NST hai tâm](chuyen-doan.svg)

**6. Chuyển đoạn** (translocation, t) — hiện tượng **trao đổi đoạn** giữa các NST.

**a) Chuyển đoạn tương hỗ** (reciprocal). Hai NST **mỗi chiếc đứt một chỗ** và **đổi đoạn đứt cho nhau** → hai NST mới. Cả hai đổi hình thái nếu hai đoạn trao đổi khác kích thước.

Đặc điểm chính:

- **Số lượng NST không đổi** (vẫn 46).
- Bộ NST có **2 NST không bình thường**.
- Tổng chất liệu di truyền **không mất**, chỉ đổi chỗ → trạng thái **cân bằng** → **kiểu hình thường bình thường**.
- Người mang chuyển đoạn **có thể truyền** NST chuyển đoạn cho con.

Khi giảm phân I, hai NST chuyển đoạn bắt cặp với hai NST tương đồng nguyên vẹn thành hình **chữ thập chuyển đoạn** (4 NST). Ở kỳ sau, từ chữ thập có thể có **7 kiểu phân ly → 14 loại giao tử**; nhiều loại trong số đó **không cân bằng** (thừa đoạn này, thiếu đoạn kia).

**b) Chuyển đoạn hòa hợp tâm** (Robertson). **Chỉ xảy ra giữa các NST tâm đầu** (nhóm D: 13, 14, 15 và nhóm G: 21, 22). Hai NST đứt ngang **gần tâm**; hai nhánh dài nối với nhau thành **một NST lớn**, còn hai nhánh ngắn tạo **một NST rất nhỏ bị tiêu biến** → mất một ít chất liệu di truyền.

Đặc điểm chính:

- Tế bào kỳ giữa **chỉ có 45 NST**.
- Thiếu **hai NST tâm đầu**, thay vào đó là:
  - một NST **tâm giữa lớn** (chuyển đoạn **D/D**), hoặc
  - một NST **tâm lệch** giống nhóm C (chuyển đoạn **D/G**), hoặc
  - một NST **tâm giữa nhỏ** (chuyển đoạn **G/G**).
- Người mang thường có **kiểu hình bình thường** → gợi ý **nhánh ngắn NST tâm đầu không chứa gen quan trọng** (chủ yếu là các bản sao gen rARN/rRNA, đã có nhiều bản ở các NST tâm đầu khác).
- Khi giảm phân, NST chuyển đoạn bắt cặp với hai NST tương đồng thành **hình ba cánh** → **4 kiểu phân ly, 8 loại giao tử**.

| | Chuyển đoạn **tương hỗ** | Chuyển đoạn **hòa hợp tâm** |
|---|---|---|
| NST tham gia | Bất kỳ | **Chỉ NST tâm đầu** (D, G) |
| Số NST của người mang | **46** | **45** |
| Số NST bất thường | **2** | **1** (NST lớn do hai nhánh dài nhập lại) |
| Mất chất liệu di truyền | Không | Mất hai nhánh ngắn (ít gen quan trọng) |
| Hình bắt cặp ở giảm phân I | **Chữ thập** (4 NST) | **Ba cánh** (3 NST) |
| Số kiểu phân ly → loại giao tử | **7 → 14** | **4 → 8** |
| Kiểu hình người mang | Thường bình thường | Thường bình thường |

> [!ung-dung] Down do chuyển đoạn — vì sao phải làm karyotype cho cả bố mẹ?
> Khoảng 4% người Down có 46 NST nhưng mang **một NST chuyển đoạn hòa hợp tâm có thêm nhánh dài 21**, theo danh pháp quốc tế (ISCN) ghi là 46,XX,rob(14;21)(q10;q10),+21 (sách cũ hay viết gọn t(14q21q)). Tổng cộng người bệnh vẫn có **ba bản nhánh dài NST 21**. Thường một trong hai bố mẹ là **người mang cân bằng 45,XX,rob(14;21)** (hoặc 45,XY,…), kiểu hình bình thường. Người mang này có nguy cơ sinh **thêm con Down** cao hơn nhiều so với người bình thường cùng tuổi, nên cần **tư vấn di truyền**. Đặc biệt, người mang t(21;21) **không thể** sinh con có bộ NST 21 bình thường.

> [!ung-dung] Nhiễm sắc thể Philadelphia
> Chuyển đoạn tương hỗ **t(9;22)** xảy ra ở **tế bào soma** (tế bào gốc tạo máu) tạo NST 22 ngắn gọi là **NST Philadelphia**. Chỗ nối tạo gen lai **BCR-ABL** mã hóa một tyrosin kinase luôn hoạt động → **bạch cầu mạn dòng tủy (CML)**. Thuốc **imatinib** ức chế đúng enzym này. Đây là ví dụ một đột biến NST soma gây ung thư (không di truyền cho con).

**c) Các kiểu chuyển đoạn khác.** Đôi khi người ta xếp vào chuyển đoạn cả sự **thêm đoạn**: một NST đứt hai chỗ trên cùng một nhánh, NST khác đứt một chỗ; đoạn đứt của NST thứ nhất **chèn sang** NST thứ hai, **không có trao đổi ngược lại** (chuyển đoạn **không tương hỗ**). Kết quả: một NST **thêm** một đoạn, một NST **mất** một đoạn.

**7. Nhân đoạn** (duplication, dup) — một đoạn NST được **lặp lại 2 hoặc 3 lần**.

- **Nhân đoạn nguyên phát**: khi ghép đôi và **bắt chéo** ở kỳ đầu giảm phân, các locus trên hai NST tương đồng **xếp lệch nhau** (không đúng vị trí tương ứng). Trao đổi chéo lệch làm một NST **nhận thêm** một đoạn (nhân đoạn), còn NST kia **mất** đoạn đó.
- **Nhân đoạn thứ phát**: xảy ra ở NST **đã có đảo đoạn**. Khi ghép đôi và bắt chéo, một số gen giữa hai NST không ăn khớp, dẫn tới chuyển đoạn từ NST này sang NST kia.

> [!vi-du] Trao đổi chéo lệch — bệnh thật ngoài đời
> Cơ chế "trao đổi chéo không cân bằng" giữa các đoạn ADN giống nhau nằm gần nhau giải thích nhiều bệnh: ví dụ nhân đoạn nhỏ chứa gen *PMP22* trên NST 17 gây bệnh thần kinh ngoại biên **Charcot-Marie-Tooth type 1A**; còn mất chính đoạn đó gây một bệnh thần kinh khác. Cùng một lần trao đổi lệch tạo ra **cặp sản phẩm đối xứng**: một NST thừa, một NST thiếu.

**8. NST đều** (isochromosome, i) — bình thường ở kỳ sau, phần tâm tách **theo chiều dọc** để hai chromatid thành hai NST. Ở đây phần tâm lại tách **theo chiều ngang** (vuông góc với trục chromatid). Kết quả là hai NST bất thường, mỗi chiếc có **hai nhánh giống hệt nhau** về kích thước và nội dung gen: một chiếc **hai nhánh dài**, một chiếc **hai nhánh ngắn**. Có thể coi như **nhân đôi một nhánh và mất nhánh kia**.

> [!ung-dung]
> NST X đều nhánh dài **i(Xq)** — tức 46,X,i(Xq) — là một nguyên nhân của **hội chứng Turner**: người bệnh thiếu các gen ở nhánh ngắn Xp (trong đó có gen liên quan chiều cao) nên lùn, giống Turner 45,X.

**Rối loạn bền vững và không bền vững.** Đây là cách xếp loại theo khả năng "sống sót" qua các lần phân bào:

| Dạng | Ví dụ | Vì sao |
|---|---|---|
| **Không bền vững** | NST **nhiều tâm**, đoạn **không tâm**, NST **vòng** | Không phân ly bình thường ở các lần phân bào sau: đoạn không tâm không có chỗ bám thoi; NST hai tâm bị kéo về hai cực rồi đứt |
| **Bền vững** | Mất đoạn, đảo đoạn, chuyển đoạn, nhân đoạn, NST đều… (vẫn **một tâm**) | Phân bào bình thường, truyền được qua nhiều thế hệ tế bào |

### 2.3. Trao đổi chromatid chị em (Sister Chromatid Exchange — SCE)

Hai **chromatid chị em** của cùng một NST **đứt và nối lại chéo** với nhau ở từng phần. Có 2 loại:

- **SCE cân bằng**: đứt – nối ở **vị trí tương đồng** trên hai chromatid → mỗi chromatid nhận lại đúng lượng ADN.
- **SCE không cân bằng**: đứt – nối ở **vị trí không tương đồng**.

**Cách phát hiện.** Cho tế bào nhân đôi ADN hai lần trong môi trường có **5-bromodeoxyuridin (BrdU)** (chất giống thymidin, được gắn vào ADN mới). Sau đó dùng **nhuộm phân biệt**: hai chromatid chị em bắt màu đậm – nhạt khác nhau, nên chỗ đổi đoạn hiện ra rõ dưới **kính hiển vi quang học** (hình ảnh chromatid "khoang" đậm nhạt).

**Ý nghĩa.** SCE có ở người bình thường với **tần suất tự nhiên nhất định**. Các tác nhân gây đột biến làm **tăng tần suất SCE**, nên đếm SCE là **test nhạy** để đánh giá khả năng gây đột biến của một chất (thuốc, hóa chất, dịch chiết…).

> [!ung-dung]
> Bệnh di truyền hiếm **hội chứng Bloom** (thiếu một enzym helicase sửa chữa ADN) có tần suất SCE **tăng gấp khoảng 10 lần**; đây là xét nghiệm giúp chẩn đoán. Người bệnh rất dễ mắc ung thư.

### 2.4. Một số hội chứng NST thường gặp ở người (mở rộng)

Giáo trình để phần hậu quả cho môn Di truyền Y học. Bảng dưới đây giúp gắn cơ chế ở trên với bệnh thật.

| Hội chứng | Karyotype | Dạng đột biến | Đặc điểm nổi bật |
|---|---|---|---|
| **Down** | 47,XX,+21 hoặc 47,XY,+21 (khoảng 95%); chuyển đoạn (khoảng 4%); khảm (khoảng 1%) | Thể ba NST 21 | Khoảng 1/700 trẻ sinh; mặt dẹt, mắt xếch, lưỡi to, nếp gấp khỉ ở bàn tay, chậm phát triển trí tuệ, tim bẩm sinh; nguy cơ tăng theo tuổi mẹ |
| **Edwards** | 47,XX,+18 hoặc 47,XY,+18 | Thể ba NST 18 | Nắm tay chặt, ngón trỏ chồng lên ngón giữa, bàn chân "đế giày lắc", dị tật tim; phần lớn tử vong trong năm đầu |
| **Patau** | 47,XX,+13 hoặc 47,XY,+13 | Thể ba NST 13 | Sứt môi – hở hàm ếch, thừa ngón, mắt nhỏ, dị tật não; phần lớn tử vong trong năm đầu |
| **Turner** | 45,X (cũng có thể khảm hoặc i(Xq)) | Thể đơn NST X | Nữ, lùn, cổ có màng, buồng trứng thoái hóa (dải xơ), vô kinh nguyên phát, vô sinh; trí tuệ thường bình thường; không có vật thể Barr |
| **Klinefelter** | 47,XXY (có thể 48,XXXY…) | Thể ba NST giới tính | Nam, cao, tinh hoàn nhỏ, vô sinh (không có tinh trùng), có thể vú to; có 1 vật thể Barr |
| **3X** (siêu nữ) | 47,XXX | Thể ba X | Thường gần bình thường, có 2 vật thể Barr |
| **Mèo kêu** | 46,XX,5p− hoặc 46,XY,5p− | Mất đoạn nhánh ngắn NST 5 | Tiếng khóc như mèo, đầu nhỏ, chậm phát triển |

> [!bay] Đếm nhanh để không nhầm
> - **Số vật thể Barr = số NST X − 1**: Turner 0, nữ bình thường 1, Klinefelter 47,XXY **1**, 47,XXX **2**, 48,XXXY **2**.
> - Có **Y** thì thường là kiểu hình **nam** dù có bao nhiêu X (gen *SRY* trên Y quyết định tinh hoàn).
> - Thứ tự NST thường gặp trong thể ba sống được: **21 (Down), 18 (Edwards), 13 (Patau)** — đều là NST **ít gen**; thể ba các NST lớn, nhiều gen gây chết phôi.

> [!ung-dung] Sàng lọc trước sinh
> Lệch bội có thể được **sàng lọc** bằng siêu âm đo độ mờ da gáy, xét nghiệm huyết thanh mẹ (double test, triple test) hoặc **NIPT** (phân tích ADN tự do của thai trong máu mẹ). Kết quả sàng lọc nguy cơ cao cần **chẩn đoán** bằng karyotype tế bào ối hoặc gai nhau. Sàng lọc chỉ cho biết **nguy cơ**; chẩn đoán mới cho kết luận.

## 3. Đột biến gen

**Gen** là một đoạn phân tử ADN mang chức năng di truyền, là **đơn vị cơ sở của thông tin di truyền**. Gen có 3 đặc điểm:

- **Tự nhân đôi** → di truyền bền vững.
- **Phiên mã** → bảo đảm tính đặc trưng của protein được tạo ra.
- **Có thể bị đột biến**.

**Đột biến gen** là những biến đổi trong **cấu trúc của gen**: một hoặc một số **cặp nucleotid** bị biến đổi dưới tác động của tác nhân gây đột biến. Đột biến gen quá nhỏ nên **không thấy được trên karyotype**; phải phát hiện bằng phân tích ADN hoặc phân tích protein.

### 3.1. Cơ chế đột biến gen

#### 3.1.1. Các dạng biến đổi nucleotid

**1. Thay thế nucleotid** (substitution) — hay gặp nhất là thay **một bazơ bằng một bazơ khác**; cũng có khi thay đồng thời **một nhóm** bazơ. Có thể xảy ra ở ADN **mã hóa** lẫn ADN **không mã hóa**.

| Loại thay thế | Định nghĩa | Thuật ngữ quốc tế |
|---|---|---|
| **Cùng loại** | Pyrimidin → pyrimidin (C ↔ T) hoặc purin → purin (A ↔ G) | Đồng hoán (transition) |
| **Khác loại** | Pyrimidin ↔ purin | Đảo hoán (transversion) |

**Thay thế cùng loại hay gặp hơn** khác loại, đặc biệt ở **ADN ty thể**. Lý do dễ hiểu: purin thay bằng purin thì kích thước bazơ gần như không đổi, chuỗi xoắn kép ít bị "méo" nên enzym sửa sai khó phát hiện hơn.

Tùy bazơ bị thay nằm ở vị trí nào trong bộ ba mà kết quả là **đổi acid amin** (amino acid) này thành acid amin khác, hoặc **không đổi** acid amin (vì mã di truyền có tính **thoái hóa**: nhiều bộ ba cùng mã hóa một acid amin, khác nhau thường ở nucleotid thứ ba).

**2. Đảo nucleotid** — **đảo vị trí** các nucleotid **trong một bộ ba** (ví dụ GAC → GCA), nên cũng làm thay một acid amin bằng acid amin khác.

Trường hợp đơn giản nhất — **thay thế hoặc đảo một nucleotid** — gọi là **đột biến điểm** (point mutation).

**3. Mất nucleotid** (deletion) — mất một hoặc vài nucleotid. **Hay gặp ở vùng không mã hóa**; nếu ở vùng mã hóa thì có thể gây **đột biến khung**. Mất **đoạn lớn** hiếm hơn, thường ở vùng có các **đoạn ADN lặp lại** (lặp lại ngẫu nhiên hoặc lặp lại xen vào), vì các đoạn giống nhau dễ bắt cặp lệch.

**4. Thêm nucleotid** (insertion) — một hoặc vài nucleotid được **chèn thêm** vào trình tự bình thường.

**Đột biến khung (frameshift).** Ribosom đọc mARN theo từng **bộ ba liên tiếp, không gối lên nhau**. Nếu **mất hoặc thêm 1 hoặc 2 nucleotid**, mọi bộ ba **từ chỗ đột biến trở đi** bị đọc lệch → chuỗi polypeptid **sai hoàn toàn từ điểm đó**, thường gặp sớm một mã kết thúc.

Nếu mất hoặc thêm **đúng 3 nucleotid (hoặc bội số của 3)**, khung đọc **không lệch**: protein chỉ **mất hoặc thêm một vài acid amin**, các acid amin phía sau **giữ nguyên**.

> [!vi-du] Câu "đọc theo bộ ba"
> Mạch bình thường: **CON MÈO ĐEN ĂN CÁ** (đọc theo cụm 3 chữ).
> - Mất 1 chữ ("O" của CON): **CNM ÈOĐ ENĂ NCÁ** → vô nghĩa từ chỗ mất (đột biến khung).
> - Mất 3 chữ (cả "MÈO"): **CON ĐEN ĂN CÁ** → chỉ mất một "từ", phần sau vẫn đúng.
>
> Ví dụ thật: bệnh **xơ nang** (cystic fibrosis) dạng hay gặp nhất do **mất 3 nucleotid** trong gen *CFTR*, làm protein mất đúng **một acid amin** (phenylalanin ở vị trí 508) nhưng vẫn đủ phần còn lại.

**Điểm nóng CpG.** Đột biến điểm hay xảy ra ở **dinucleotid CpG** (một C đứng ngay trước một G trên cùng mạch, nối bằng liên kết phosphodiester).

- Ở động vật có xương sống, C trong CpG thường bị enzym **ADN methyltransferase** gắn thêm nhóm methyl → **5-methylcytosin**.
- 5-methylcytosin **dễ mất nhóm amin** (khử amin, deamination) và biến thành **thymin**. Thymin là bazơ "hợp lệ" của ADN nên enzym sửa chữa khó nhận ra.
- Kết quả: **CpG → TpG** trên mạch này (và **CpA** trên mạch đối diện). Đó là một **thay thế cùng loại** (C → T).
- Khoảng **3% cytosin** trong ADN người bị methyl hóa, chủ yếu ở CpG; một tỷ lệ rất nhỏ ở **CpNpG** (N là nucleotid bất kỳ).

> [!cap-nhat] Chi tiết hóa học về CpG
> Giáo trình viết nhóm methyl gắn ở "vị trí carbon số 5′" và sản phẩm là "thymidin". Hiện nay mô tả chuẩn là: nhóm methyl gắn vào **carbon số 5 của vòng cytosin** (không có dấu phẩy; 5′ là carbon của đường deoxyribose), và khử amin tạo **bazơ thymin** (thymidin là nucleosid). Ý chính để thi không đổi: **5-methylcytosin khử amin → thymin → CpG thành TpG**.

#### 3.1.2. Biến đổi chất lượng hoặc số lượng protein

**1. Đột biến chất lượng protein.** Trình tự acid amin do trình tự nucleotid của **gen cấu trúc** quy định. Đột biến gen cấu trúc → protein **thay đổi về chất** (sai acid amin).

Ví dụ của giáo trình: chuỗi **β-globin** có **146 acid amin**. Ở **hemoglobin E** (HbE), acid amin thứ **26** là **acid glutamic** bị thay bằng **lysin**.

> [!cap-nhat] Ví dụ HbE trong giáo trình bị lẫn chi tiết
> Giáo trình ghi: mã của Glu (GAA/GAG) đổi **nucleotid thứ hai A → U** thành **GUA/GUG**, "mã hóa lysin", tạo HbE. Chi tiết này **không đúng**: GUA/GUG mã hóa **valin**, và sự thay Glu → Val là của **HbS** (ở vị trí **6**), không phải HbE. Hiện nay đã biết rõ:
> - **HbE**: β26 **GAG → AAG** (thay **nucleotid thứ nhất** G → A), **Glu → Lys**.
> - **HbS**: β6 **GAG → GUG** (trên mARN; nucleotid thứ hai A → U), **Glu → Val**.
>
> Đi thi: nhớ ý của giáo trình "**HbE — vị trí 26 — Glu thay bằng Lys**"; nếu đề hỏi bộ ba, hãy dựa vào bảng mã di truyền (GUA/GUG = Val; AAA/AAG = Lys).

> [!ung-dung] Hồng cầu hình liềm (HbS) — một nucleotid, cả một bệnh
> Chỉ **một thay thế nucleotid** (A → T trên ADN, tức thay thế **khác loại**) làm Glu (ưa nước, tích điện âm) ở vị trí 6 thành Val (kỵ nước). Khi thiếu oxy, các phân tử HbS **dính vào nhau** thành sợi dài, kéo hồng cầu thành **hình liềm**. Hồng cầu liềm cứng, dễ vỡ (thiếu máu tan máu) và làm **tắc mạch nhỏ** (cơn đau, tổn thương cơ quan). Đây là ví dụ kinh điển của **đột biến sai nghĩa** và "**bệnh phân tử**". **HbE** thì rất phổ biến ở **Đông Nam Á, kể cả Việt Nam**; HbE kết hợp với β-thalassemia (HbE/β-thal) là một thể thalassemia hay gặp ở nước ta.

> [!cap-nhat] Danh pháp đột biến chuẩn quốc tế HGVS — vì sao "β6" lại thành "p.Glu7Val"?
> (bổ sung – kiến thức hiện nay) Phiếu xét nghiệm gen hiện nay ghi đột biến theo danh pháp **HGVS** (Human Genome Variation Society):
> - **c.** = vị trí trên ADN mã hóa (cADN), đếm từ chữ **A của ATG** = 1; **p.** = thay đổi trên protein, acid amin ghi 3 chữ, dừng ghi **Ter** (hoặc \*), mất ghi **del**, lệch khung ghi **fs**; **g.** = vị trí trên bộ gen.
> - HGVS **đếm cả methionin mở đầu**, còn cách gọi kinh điển (β6, β26) **không đếm** Met vì nó bị cắt khỏi chuỗi β-globin trưởng thành. Vì vậy:
>   - **HbS**: *HBB* c.20A>T, **p.Glu7Val** (= β6 Glu→Val kinh điển).
>   - **HbE**: *HBB* c.79G>A, **p.Glu27Lys** (= β26 Glu→Lys).
>   - **Xơ nang** dạng hay gặp: *CFTR* c.1521_1523del, **p.Phe508del** (ΔF508).
> - Khi đọc tài liệu, hai cách đánh số lệch nhau **1 acid amin** là bình thường. Đi thi theo cách gọi của giáo trình (vị trí 6, vị trí 26). (Nguồn: HGVS Nomenclature; NCBI ClinVar NM_000518.5.)

**2. Đột biến số lượng protein.** Lượng protein được tổng hợp do **vùng điều chỉnh** của gen quy định. Đột biến ở vùng điều chỉnh làm rối loạn tổng hợp: kìm hãm chuỗi này, kích thích chuỗi kia → protein bất thường về **số lượng**.

Ví dụ của giáo trình: **kìm hãm tổng hợp chuỗi β** và **kích thích tổng hợp chuỗi γ** ở người trưởng thành → lượng **HbF (α~2~γ~2~)** tăng bất thường. Đây là một nguyên nhân của **bệnh β-thalassemia**.

> [!vi-du] Ôn nhanh các loại hemoglobin
> - Người lớn: **HbA = α~2~β~2~** (chiếm phần lớn), HbA~2~ = α~2~δ~2~ (ít).
> - Thai nhi: **HbF = α~2~γ~2~**; sau sinh, gen γ "tắt" dần, gen β "bật" lên.
> - Trong β-thalassemia, chuỗi β thiếu nên chuỗi γ được tạo bù → **HbF tăng**. Phần lớn đột biến β-thalassemia nằm ngay trên gen β-globin hoặc vùng điều hòa sát gen đó (vùng khởi động, vị trí cắt nối intron, mã vô nghĩa, đột biến khung), làm **giảm hoặc mất** chuỗi β.

### 3.2. Biểu hiện của gen đột biến

**Theo quan hệ trội – lặn:**

- Gen **trội A** đột biến thành alen **lặn a** (hay gặp: gen mất chức năng).
- Gen **lặn a** đột biến thành alen **trội A**.

Gen đột biến có biểu hiện ra kiểu hình hay không, và ở mức nào, còn tùy **mức độ biểu hiện** của gen đó.

**Theo ảnh hưởng lên sản phẩm của gen:**

| Loại | Bản chất | Hậu quả |
|---|---|---|
| **Im lặng** (silent) | **Không đổi** sản phẩm gen (vd bộ ba mới vẫn mã hóa cùng acid amin) | Thường không biểu hiện |
| **Không im lặng** | **Đổi** chuỗi polypeptid hoặc chức năng ARN (đổi, thêm, bớt acid amin) | Có thể gây bệnh |
| → **Sai nghĩa** (missense) | Thay **acid amin này bằng acid amin khác** | Vd HbS, HbE |
| → **Vô nghĩa** (nonsense) | Bộ ba mã hóa acid amin thành **mã kết thúc UAA, UAG, UGA** | Chuỗi polypeptid **ngắn cụt** |

Các đột biến không im lặng thường **làm giảm mạnh chức năng gen**. Chúng **hiếm khi vô hại**, nên chịu **áp lực chọn lọc** tự nhiên.

Các dạng đột biến trên cũng có thể xảy ra ở **bộ ba mở đầu** (AUG — protein không được khởi đầu), **mã kết thúc** (chuỗi bị kéo dài) hoặc **vị trí cắt nối exon – intron** (mARN trưởng thành bị sai).

> [!bay]
> - **"Vô nghĩa" ≠ "sai nghĩa"**: vô nghĩa = thành **mã dừng** (protein cụt); sai nghĩa = thành **acid amin khác**.
> - Đột biến **im lặng** vẫn là đột biến (ADN đã đổi), chỉ là **protein không đổi**.
> - Đột biến **điểm** (1 nucleotid) có thể là im lặng, sai nghĩa hoặc vô nghĩa; còn **mất/thêm 1 nucleotid** trong vùng mã hóa thì gây **đột biến khung**.

> [!ung-dung] β-thalassemia ở Việt Nam — đủ cả các loại đột biến
> Các đột biến gen β-globin hay gặp ở người Việt minh họa trọn bài: **đột biến vô nghĩa** ở bộ ba 17 (AAG → **UAG**, Lys → dừng), **đột biến khung** ở bộ ba 41/42 (mất 4 nucleotid), đột biến **vị trí cắt nối intron**, và **HbE** (sai nghĩa ở bộ ba 26, làm giảm lượng chuỗi β tạo ra). Vì thalassemia di truyền lặn và tỷ lệ người mang gen khá cao, **xét nghiệm tầm soát trước hôn nhân và trước sinh** được khuyến cáo rộng rãi.

### 3.2b. Đột biến động — bệnh do lặp ba nucleotid (bổ sung – kiến thức hiện nay)

Giáo trình chỉ nêu các đột biến "tĩnh" (một lần thay đổi, truyền nguyên vẹn). Từ những năm 1990 người ta biết thêm một kiểu khác: **đột biến động**. Một đoạn **ba nucleotid lặp lại** liên tiếp (vd CAG CAG CAG…) có thể **dài thêm** qua mỗi lần truyền cho con. Khi số lần lặp vượt một ngưỡng thì gây bệnh.

| Bệnh | Gen (NST) | Bộ ba | Bình thường | Gây bệnh | Ghi chú |
|---|---|---|---|---|---|
| **Huntington** (múa giật, sa sút trí tuệ; trội NST thường) | *HTT* (4p) | **CAG** (mã Gln) trong exon | 10–35 | **36–39**: có thể bệnh hoặc không; **≥40**: hầu như chắc chắn bệnh | Lặp dài thêm hay gặp khi truyền **qua bố**; thể khởi phát ở tuổi thiếu niên (thường >60 lần lặp) phần lớn nhận gen từ bố |
| **Hội chứng X dễ gãy** (fragile X; nguyên nhân di truyền đơn gen hay gặp nhất của khuyết tật trí tuệ) | *FMR1* (Xq27.3) | **CGG** ở vùng 5' không dịch mã | ≈5–40 | **Tiền đột biến 55–200** (chưa gây X dễ gãy nhưng có nguy cơ suy buồng trứng sớm, run – thất điều tuổi già); **đột biến đầy đủ >200** | Đoạn lặp >200 bị **methyl hóa**, gen bị **tắt** (biểu sinh). Lặp dài thêm xảy ra khi truyền **qua mẹ**. Gặp ≈1/4.000 nam, 1/8.000 nữ |

> [!ghi-nho] Hiện tượng "di truyền tiên phát" (anticipation)
> Vì đoạn lặp **dài thêm qua mỗi thế hệ**, bệnh **khởi phát sớm hơn và nặng hơn** ở đời sau. Đây là dấu hiệu gợi ý bệnh do lặp ba nucleotid khi đọc phả hệ. Các bệnh cùng cơ chế: loạn dưỡng cơ trương lực (CTG), thất điều tủy – tiểu não (CAG), thất điều Friedreich (GAA).

*Vì sao đoạn lặp dễ dài thêm?* Khi tái bản, mạch mới trên đoạn lặp có thể **trượt và tạo kẹp tóc**, polymerase "chép lại" vài đơn vị lặp → số lần lặp tăng. Đoạn càng dài càng dễ trượt, nên bệnh càng có xu hướng nặng dần.

(Nguồn: MedlinePlus Genetics — Huntington disease, Fragile X syndrome; Thompson & Thompson *Genetics in Medicine* 9th.)

### 3.3. Đột biến ở các loại tế bào

| | **Tế bào sinh dục** (giao tử) | **Tế bào sinh dưỡng** (soma) |
|---|---|---|
| Truyền cho đời sau? | **Có thể** truyền từ bố mẹ sang con | **Không** — chỉ ở cá thể bị đột biến |
| Biểu hiện | Tùy đột biến trội, lặn hay trội không hoàn toàn mà có biểu hiện ở con hay không | Tùy trội/lặn; còn tùy **độ biểu hiện** của gen và **tác động của môi trường** |
| Ví dụ | Bệnh di truyền (thalassemia, hồng cầu liềm) | Phần lớn **ung thư**; nốt ruồi, khảm màu da |

> [!cap-nhat] Đột biến soma và ung thư: gen tiền ung thư và gen ức chế khối u
> (bổ sung – kiến thức hiện nay) Ung thư là bệnh do **tích lũy nhiều đột biến soma** (thường vài đến hàng chục đột biến "chủ chốt") trong một dòng tế bào. Hai nhóm gen quan trọng nhất:
>
> | | **Gen tiền ung thư → gen ung thư** (*proto-oncogene → oncogene*) | **Gen ức chế khối u** (*tumor suppressor gene*) |
> |---|---|---|
> | Chức năng bình thường | **Thúc** tế bào phân chia ("chân ga") | **Hãm** phân chia, sửa ADN, gây apoptosis ("chân phanh") |
> | Kiểu đột biến gây ung thư | **Tăng chức năng** | **Mất chức năng** |
> | Số alen cần hỏng | **Một** alen là đủ (tác động trội ở mức tế bào) | **Cả hai** alen (giả thuyết **"hai cú đánh"** của Knudson) |
> | Ví dụ | *KRAS*; *HER2* (khuếch đại gen, ung thư vú); *BCR-ABL* (chuyển đoạn t(9;22), mục 2.2) | *TP53* (đột biến trong khoảng một nửa số ung thư), *RB1* (u nguyên bào võng mạc), *BRCA1/2* |
>
> - Người **mang sẵn một alen hỏng** của gen ức chế khối u từ bố mẹ (đột biến **dòng mầm**) chỉ cần thêm một "cú đánh" soma → ung thư **sớm, nhiều ổ**, có tính gia đình (vd *BRCA1/2* — ung thư vú, buồng trứng).
> - Mỗi tác nhân gây đột biến để lại một kiểu thay thế base đặc trưng gọi là **chữ ký đột biến** (*mutational signature*): tia UV → C>T ở hai pyrimidin kề nhau (ung thư da); benzo[a]pyren khói thuốc lá, aflatoxin → G>T; acid aristolochic → **A>T** (mục 4). Giải trình tự khối u có thể "đọc ra" tác nhân đã gây bệnh.
>
> (Nguồn: Alberts MBoC 7th, ch. 20; Thompson & Thompson 9th, ch. 15; Alexandrov và cs., *Nature* 2013, 2020.)

## 4. Tác nhân gây đột biến (mở rộng)

Giáo trình nêu 3 nhóm tác nhân: **vật lý, hóa học, sinh học**. Biết cơ chế của chúng giúp hiểu vì sao phải phòng tránh.

| Nhóm | Tác nhân | Cách gây tổn thương | Dạng đột biến chủ yếu |
|---|---|---|---|
| **Vật lý** | **Tia X, tia γ** (bức xạ ion hóa) | Ion hóa, **cắt đứt** cả hai mạch ADN | **Đột biến NST** (đứt gãy, NST hai tâm, vòng, mất đoạn) |
| | **Tia tử ngoại (UV)** | Nối hai **pyrimidin** cạnh nhau trên cùng mạch thành **dimer** (hay gặp nhất là dimer thymin T–T; dimer có C gây đột biến nhiều nhất) | Đột biến gen (thay thế **C → T**, có khi CC → TT); ung thư da |
| | **Sốc nhiệt** | Rối loạn thoi vô sắc | Đa bội (dùng ở thực vật) |
| **Hóa học** | **Chất tương tự bazơ** (5-bromouracil — tương tự thymin) | Gắn vào ADN thay T nhưng hay bắt cặp nhầm với G | Thay thế A-T → G-C |
| | **Chất alkyl hóa** (khí mù tạt, một số thuốc chống ung thư như cyclophosphamid) | Gắn nhóm alkyl vào bazơ (nhất là G) → bắt cặp sai, đứt mạch | Đột biến gen và NST |
| | **Acid nitrơ** | **Khử amin**: C → U, A → hypoxanthin | Thay thế |
| | **Acridin** (chất xen giữa) | Chen vào giữa hai cặp bazơ, làm chuỗi "giãn" | Mất/thêm nucleotid → **đột biến khung** |
| | **Benzo[a]pyren** (khói thuốc lá, thịt nướng cháy), **aflatoxin** | Được gan hoạt hóa thành chất gắn vào G | Thay thế G → T |
| | **Colchicin, vinblastin** | Ức chế thoi vô sắc | Đa bội, lệch bội |
| **Sinh học** | **Virus** (vd virus viêm gan B, HPV), yếu tố di động (transposon) | Chèn ADN lạ vào bộ gen, làm hỏng gen hoặc rối loạn điều hòa | Đột biến gen, đứt NST; ung thư gan, ung thư cổ tử cung |

> [!ung-dung] Vì sao thuốc chống ung thư và tia xạ lại có thể gây ung thư thứ phát?
> Hóa trị (chất alkyl hóa) và xạ trị diệt khối u bằng cách **làm hỏng ADN** của tế bào phân chia nhanh. Nhưng chính cơ chế đó cũng gây đột biến ở tế bào lành. Vì vậy người bệnh sau hóa trị, xạ trị có nguy cơ bị **ung thư thứ phát** (thường là bệnh bạch cầu) sau nhiều năm; nhân viên y tế pha chế thuốc chống ung thư phải dùng **tủ an toàn sinh học, găng, khẩu trang**; phụ nữ có thai tránh chụp X quang khi không cần thiết.

> [!yhct] Aflatoxin trong dược liệu bị mốc — vì sao phải bảo quản đúng
> - **Aflatoxin** do nấm mốc *Aspergillus flavus*, *A. parasiticus* sinh ra trên nguyên liệu **ẩm, giàu tinh bột hoặc dầu** (lạc, ngô, các loại hạt). **Aflatoxin B~1~** là chất gây ung thư nhóm 1 (IARC): ở gan nó được enzym cytochrom P450 hoạt hóa thành dạng **epoxid**, gắn vào **guanin** của ADN, gây đột biến thay thế **G → T**, kể cả trong gen ức chế khối u *TP53* (điển hình là "điểm nóng" ở **codon 249**, AGG → AGT, Arg → Ser, gặp nhiều trong ung thư gan ở vùng nhiễm aflatoxin cao). (IARC khẳng định lại trong Monograph 100F, 2012.) Phơi nhiễm lâu dài, nhất là ở người **nhiễm virus viêm gan B**, làm tăng mạnh nguy cơ **ung thư gan**.
> - **Dược liệu** cũng có thể bị nhiễm, nhất là các vị là **hạt, nhân, rễ củ nhiều tinh bột** khi phơi sấy chưa khô hoặc kho ẩm (nhiều nghiên cứu đã phát hiện aflatoxin ở Ý dĩ, Đào nhân, Hạnh nhân, Bá tử nhân, Đại táo…). Dược điển nhiều nước đặt **giới hạn aflatoxin** cho dược liệu.
> - Điểm thực hành quan trọng: aflatoxin **chịu nhiệt tốt**, **sắc thuốc không phá hủy được**. Vì vậy **không dùng dược liệu đã mốc**, kể cả sau khi rửa, sao hay "sắc kỹ".
> - Phòng ngừa: phơi sấy **đủ khô** ngay sau thu hái; kho **khô, thoáng, mát**, kê cao cách nền và tường; đóng gói kín; kiểm tra định kỳ; mua dược liệu có nguồn gốc và phiếu kiểm nghiệm.

> [!yhct] Acid aristolochic — khi nhầm vị thuốc trở thành nhầm chất gây đột biến
> - Một số cây chi *Aristolochia* chứa **acid aristolochic**, chất gây độc thận và gây ung thư **nhóm 1** (IARC, Monograph 100A, 2012 — xếp cả acid aristolochic lẫn "cây chứa acid aristolochic"). Được hoạt hóa trong cơ thể, nó gắn vào **adenin** của ADN và để lại "chữ ký đột biến" đặc trưng là thay thế **A → T** (chữ ký SBS22), thấy rõ ở ung thư biểu mô đường tiết niệu trên và cả ở một tỷ lệ ung thư gan tại châu Á. Nhờ chữ ký này, giải trình tự khối u có thể cho biết người bệnh từng phơi nhiễm, dù đã ngừng thuốc nhiều năm.
> - Đầu thập niên 1990 ở Bỉ, **Quảng phòng kỷ** (*Aristolochia fangchi*) bị dùng **nhầm thay** Hán phòng kỷ (*Stephania tetrandra*) trong một phác đồ giảm cân, gây hơn một trăm ca **suy thận** (lúc đầu gọi là "bệnh thận do thảo dược Trung Quốc"), về sau nhiều người bị **ung thư biểu mô đường niệu**.
> - **Quan mộc thông** (*Aristolochia manshuriensis*) từng được dùng thay **Mộc thông** (*Akebia*) hoặc Xuyên mộc thông (*Clematis*), cũng gây nhiều ca suy thận. Trung Quốc đã **loại** Quan mộc thông (2003), Quảng phòng kỷ và Thanh mộc hương (2004) khỏi danh mục được dùng; nhiều nước khác cấm hoặc hạn chế các vị chứa acid aristolochic (kể cả **Mã đâu linh**). **Tế tân** (*Asarum*) có lượng nhỏ, tập trung ở phần trên mặt đất, nên Dược điển Trung Quốc hiện chỉ dùng **rễ và thân rễ**.
> - Bài học: **định danh đúng loài** dược liệu (nhất là các vị trùng tên "phòng kỷ", "mộc thông", "mộc hương") là vấn đề an toàn, không chỉ là vấn đề hiệu quả. Tổn thương thận và ung thư có thể xuất hiện **nhiều năm sau** khi đã ngừng thuốc, và sắc thuốc không làm mất chất này.

## Tóm tắt

| Chủ đề | Điểm then chốt |
|---|---|
| Khái niệm | Biến dị **di truyền được**, ở mức NST hoặc gen; soma (không truyền cho con) / sinh dục (có thể truyền); phần lớn được tự sửa chữa |
| Đa bội | Cả bộ n tăng: 3n, 4n. Cơ chế: giao tử 2n; hợp tử phân chia bất thường; thụ tinh kép / tế bào cực xâm nhập. Hay ở thực vật (colchicin, sốc nhiệt); ở người hiếm, gây sẩy thai, dị tật |
| Lệch bội | Thể không 2n−2, thể đơn 2n−1 (45,X), thể ba 2n+1 (47,XXY; 47,+21), thể đa (48,XXXY), thể ba kép (48,XXX,+18), thể khảm (46/47,+21) |
| Cơ chế lệch bội | **Không phân ly** (giảm phân I → 4/4 giao tử bất thường; giảm phân II → 2/4; phân cắt hợp tử → khảm) và **thất lạc NST** (chỉ tạo tế bào thiếu) |
| Kiểu chromatid | Tác động sau nhân đôi (S, G2): khuyết màu đơn, đứt đơn (gặp ở người bình thường), trao đổi chromatid (3–4 cánh, hiếm) |
| Kiểu NST | Tác động trước nhân đôi (G1, đầu S): khuyết kép, đứt kép, mất đoạn (cuối, giữa, NST vòng), đảo đoạn (ngoài tâm, quanh tâm), NST hai tâm (nhiễm xạ), chuyển đoạn, nhân đoạn, NST đều |
| Chuyển đoạn | Tương hỗ: 46 NST, 2 NST bất thường, chữ thập, 7 kiểu → 14 giao tử. Hòa hợp tâm: NST tâm đầu, **45 NST**, ba cánh, 4 kiểu → 8 giao tử. Người mang thường bình thường |
| Bền vững | Không bền: nhiều tâm, không tâm, vòng. Bền: còn 1 tâm |
| SCE | Đứt – nối giữa 2 chromatid chị em; phát hiện bằng BrdU + nhuộm phân biệt; **test nhạy** đánh giá chất gây đột biến |
| Đột biến gen | Thay thế (cùng loại > khác loại), đảo, mất, thêm nucleotid. Mất/thêm 1–2 nu → **lệch khung**; 3 nu → mất/thêm acid amin. Điểm nóng **CpG** (5-methylC → T) |
| Hậu quả protein | Chất lượng: HbE (β26 Glu → Lys), HbS (β6 Glu → Val). Số lượng: β-thalassemia (giảm β, tăng γ → HbF α~2~γ~2~) |
| Biểu hiện | Im lặng / không im lặng (sai nghĩa, vô nghĩa → UAA, UAG, UGA); có thể ở mã mở đầu, mã kết thúc, vị trí cắt nối |
| Tác nhân | Vật lý (X, γ → đứt NST; UV → dimer pyrimidin), hóa học (alkyl hóa, tương tự bazơ, acridin, aflatoxin, acid aristolochic), sinh học (virus) |
| Bổ sung hiện nay | ISCN 2024; CNV và microarray (CMA, xét nghiệm đầu tay cho chậm phát triển, đa dị tật); HGVS (HbS = p.Glu7Val); đột biến động lặp ba nucleotid (Huntington CAG ≥40, X dễ gãy CGG >200) và hiện tượng di truyền tiên phát; ung thư = tích lũy đột biến soma ở gen tiền ung thư (1 alen) và gen ức chế khối u (2 alen) |
