---
title: Cơ chế điều khiển phát triển phôi và các nhân tố ảnh hưởng
thoi-gian: 35 phút
muc-tieu:
- Trình bày được vai trò của chương trình thông tin di truyền (bộ gen của trứng, của hợp tử, gen biệt hóa, nhân tố từ nguồn mẹ) trong sự phát triển phôi.
- Giải thích được hiện tượng cảm ứng phôi và nêu được các tính chất của tổ chức tố.
- Trình bày được hoạt động của operon (cơ chế kìm hãm – giải kìm hãm) trong sự phát triển cá thể theo giáo trình.
- Trình bày được vai trò của môi trường ngoại cảnh và cơ sở sinh học của sự phát sinh quái thai; vận dụng vào việc dùng thuốc cho phụ nữ có thai.
- Nêu được các thực nghiệm phôi (chuyển nhân, chuyển gen, thụ tinh trong ống nghiệm), các mức độ tái sinh và hai loại đa thai.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Mọi tế bào của cơ thể có **cùng một bộ gen** như hợp tử. Tế bào khác nhau vì **mỗi loại chỉ "mở" một số gen** — đó là **biệt hóa**. Đi từ hợp tử → phôi vị, tế bào chuyển từ **đa tiềm năng** sang **tiềm năng bị hạn chế**.
> 2. Hướng biệt hóa do một **chuỗi cảm ứng** quyết định: tinh trùng → **cảm ứng tố cơ sở** (có sẵn trong tế bào chất trứng) → **cảm ứng tố sơ cấp** (do trung tâm tổ chức, vd **môi lưng** phôi vị ếch, tiết ra) → **cảm ứng tố thứ cấp**… Về sau được thay bằng điều hòa **thần kinh – nội tiết**.
> 3. Theo giáo trình, ở động vật đa bào chất kìm hãm gen là **histon**; **chất cảm ứng + histon → giải kìm hãm** → gen cấu trúc hoạt động → tế bào biệt hóa.
> 4. Bộ gen của tế bào đã biệt hóa vẫn **vững chắc** (còn đủ thông tin): chứng minh bằng chuyển nhân ở cóc *Xenopus* và **cừu Dolly (1996)**.
> 5. Giai đoạn **tạo giao tử và phôi** nhạy cảm nhất với môi trường. Tác nhân gây quái thai tác động qua **3 cơ chế**: rối loạn vật liệu di truyền, rối loạn phân bào, gây chết tế bào có định hướng. Ở người, **tuần 3–8 sau thụ tinh** là thời kỳ dễ gây dị tật lớn nhất.

Bài trước (*Quá trình phát triển cá thể*) mô tả **cái gì** xảy ra: hợp tử phân cắt, thành phôi nang, phôi vị, ba lá phôi rồi các cơ quan. Bài này trả lời câu hỏi **vì sao** và **cái gì điều khiển**: làm sao từ một tế bào, với một bộ gen duy nhất, lại sinh ra hơn 200 loại tế bào khác nhau đúng chỗ, đúng lúc? Và môi trường có thể làm hỏng quá trình đó như thế nào?

## 1. Cơ chế điều khiển phát triển cá thể ở giai đoạn phôi

### 1.1. Chương trình thông tin di truyền

Ý chính của giáo trình: **phôi tự điều khiển sự phát triển của mình**. Cơ thể mẹ (hoặc môi trường ngoài, với trứng đẻ ra ngoài) chỉ **cung cấp chất dinh dưỡng và điều kiện**; còn việc tế bào nào biệt hóa thành gì, lúc nào hình thành mô nào thì do **chương trình đã ghi sẵn trong bộ gen** của trứng và hợp tử quyết định (Giáo trình tr. 142).

#### 1.1.1. Vai trò của bộ gen đơn bội ở trứng và bộ gen lưỡng bội ở hợp tử

**a) Bộ gen đơn bội của trứng đã đủ thông tin để tạo một cơ thể hoàn chỉnh.** Bằng chứng:

- Châm kim vào **trứng ếch** chưa thụ tinh, hoặc lắc, thay đổi nồng độ muối với **trứng cầu gai** → trứng vẫn phát triển thành ếch, cầu gai hoàn chỉnh.
- Trong tự nhiên có **đơn tính sinh** (trinh sản) ở một số loài: trứng không thụ tinh vẫn thành cơ thể.

**b) Nhưng nhân lưỡng bội của hợp tử lại cần thiết** cho sự phát triển bình thường. Vì sao?

- Hai bộ gen từ bố và mẹ tạo thành các **cặp alen tương tác** với nhau → cơ thể **sức sống mạnh hơn**, kết hợp ưu điểm của hai nguồn gen.
- Hợp tử dị hợp về nhiều cặp gen → nhiều **biến dị tổ hợp** → kiểu hình đa dạng → nguyên liệu cho chọn lọc tự nhiên, thúc đẩy tiến hóa.

**Chương trình thông tin di truyền** của hợp tử được giáo trình ví như một bộ nhiều **"con đường chỉ đạo"** ghi trong bộ gen. Các con đường này **không đọc cùng lúc**, mà được đọc **lần lượt, đúng thời điểm**, khi có **tín hiệu cảm ứng tương ứng**. Tín hiệu đó là:

- **Cảm ứng tố cơ sở**: chuẩn bị sẵn từ lúc tạo giao tử, tích trong tế bào chất của trứng.
- Về sau: các chất do nhóm tế bào phôi tiết ra, chất trong môi trường gian bào (**cảm ứng tố sơ cấp, thứ cấp**), **hormon**…

> [!ung-dung] Vì sao đơn tính sinh không xảy ra ở người?
> Ở động vật có vú, bộ gen của bố và của mẹ **không tương đương** về chức năng: một số gen chỉ hoạt động khi đến từ bố, số khác chỉ hoạt động khi đến từ mẹ (hiện tượng **in dấu bộ gen** — *genomic imprinting*). Phôi chỉ có 2 bộ gen của mẹ hoặc chỉ có 2 bộ gen của bố đều phát triển bất thường. Ví dụ lâm sàng: **chửa trứng toàn phần** có bộ nhiễm sắc thể **hoàn toàn từ bố** — chỉ có nhau phát triển quá mức, không có phôi. Đây là minh họa rõ cho ý của giáo trình: **hợp tử lưỡng bội gồm cả hai nguồn gen là cần thiết**.

#### 1.1.2. Tác động của gen biệt hóa

**Biệt hóa** (*differentiation*) là quá trình các tế bào vốn giống nhau trở nên khác nhau về cấu trúc và chức năng. Bản chất: mỗi loại tế bào **"mở" một nhóm gen riêng**, tổng hợp bộ protein riêng — **không mất gen nào**.

Có thể tóm tắt hướng đi của nhân tế bào phôi: **đa tiềm năng → tiềm năng bị hạn chế dần**.

**a) Giai đoạn phân cắt (tới phôi dâu, phôi nang): tế bào còn đa tiềm năng**

- **Hợp tử** là tế bào đa tiềm năng cao nhất: có thể sinh ra mọi loại tế bào của cơ thể.
- Đến phôi dâu, phôi nang, các tế bào còn **khá đồng nhất** về hình thái, **chưa biệt hóa** chức năng.
- Bằng chứng: lấy **nhân tế bào phôi nang** thay vào nhân hợp tử → hợp tử "thế nhân" **phát triển bình thường** thành cơ thể hoàn chỉnh.
- Ở giai đoạn này chỉ có **nhóm gen liên quan đến phân chia tế bào** được hoạt hóa (nhờ thụ tinh). Các gen biệt hóa vẫn **bị kìm hãm**.
- Phôi chủ yếu dùng **thông tin di truyền từ mẹ**, có sẵn trong tế bào chất trứng (ARN (RNA) thông tin dự trữ). Theo giáo trình, đến **cuối giai đoạn phôi nang** thông tin di truyền của chính hợp tử mới bắt đầu hoạt động.

> [!cap-nhat] Khi nào bộ gen của phôi người "thức dậy"?
> Giáo trình ghi gen của hợp tử bắt đầu hoạt động ở cuối giai đoạn phôi nang (hoặc phôi vị). Đó là đúng với nhiều loài thí nghiệm như ếch, cầu gai. Hiện nay đã biết ở **người**, bộ gen của phôi được hoạt hóa mạnh từ rất sớm, khoảng giai đoạn **4–8 phôi bào** (ngày thứ 3 sau thụ tinh); trước đó phôi sống nhờ ARN và protein của mẹ. Đi thi trả lời theo giáo trình.

**Trứng khảm và trứng điều hòa** — phân biệt dựa vào quan hệ giữa các phôi bào trong giai đoạn phân cắt:

| | Trứng khảm | Trứng điều hòa |
|---|---|---|
| Ví dụ (sách) | Trứng **Thân mềm** | Trứng **ếch**, trứng **cầu gai** |
| Tế bào chất | Chia thành **các vùng đã định sẵn**, mỗi vùng cần cho một mầm cơ quan | Các phôi bào sớm còn **tương đương** nhau |
| Tách 1 phôi bào ở giai đoạn 2 phôi bào | Phát triển **không hoàn chỉnh** (chỉ ra phần cơ thể tương ứng) | Mỗi phôi bào thành **một cơ thể hoàn chỉnh**, chỉ **nhỏ hơn** |
| Ý nghĩa | Số phận tế bào được "khảm" sẵn rất sớm | Phôi có khả năng tự **điều chỉnh**, bù trừ phần bị mất |

Ranh giới hai loại **không tuyệt đối**: với trứng điều hòa, nếu **thắt ngang** (chứ không tách dọc theo trục), mỗi nửa chỉ phân cắt đến một giai đoạn rồi dừng. Lý do: thắt ngang chia **tế bào chất** của trứng thành hai phần **không đều** về các cảm ứng tố cơ sở. Thí nghiệm này chứng minh **vai trò quan trọng của tế bào chất**.

> [!bay]
> - Tách **dọc theo trục** (từ cực động vật đến cực thực vật) → mỗi nửa nhận đủ các vùng tế bào chất → phát triển hoàn chỉnh.
> - Thắt **ngang** → mỗi nửa thiếu một số vùng → dừng lại. Đề hay hỏi đúng chi tiết hướng cắt này.

> [!ung-dung] Phôi người là phôi "điều hòa"
> Phôi người sớm có tính điều hòa cao. Nhờ vậy:
> - **Sinh đôi cùng trứng** xảy ra được: một phôi tách thành hai, mỗi phần vẫn thành người hoàn chỉnh (mục 5).
> - Trong **chẩn đoán di truyền tiền làm tổ** (PGT) khi thụ tinh ống nghiệm, có thể lấy ra 1 vài tế bào để xét nghiệm mà phôi còn lại vẫn phát triển bình thường.

**b) Từ giai đoạn phôi vị hóa: tế bào bắt đầu biệt hóa, tiềm năng bị hạn chế**

Thí nghiệm thế nhân cho thấy rõ nhân "già" đi theo giai đoạn phát triển:

| Nguồn nhân thay vào hợp tử | Kết quả |
|---|---|
| Tế bào **phôi nang** | Phát triển **bình thường**, cơ thể hoàn chỉnh |
| Tế bào **phôi vị** | Phát triển bất thường, chỉ phân cắt **tới phôi nang rồi dừng** |
| Tế bào **lá phôi giữa** | Không phát triển, hoặc có phát triển nhưng **thần kinh và biểu bì không đầy đủ** |
| Tế bào giai đoạn **muộn hơn** | Hợp tử **không phân chia** |

Giáo trình kết luận: sự chuyển nhân sang dạng tiềm năng bị hạn chế **chính là sự biệt hóa chức năng** của bộ máy di truyền — bộ máy này vốn **đồng nhất** từ hợp tử ban đầu.

![Hình 1. Tiềm năng của nhân giảm dần theo giai đoạn phát triển và chuỗi cảm ứng phôi](tiem-nang-cam-ung.svg)

**Vì sao ba lá phôi lại khác nhau?** Trong trứng, các **cảm ứng tố cơ sở** phân bố **không đều** từ **cực sinh vật** (cực động vật) đến **cực dinh dưỡng** (cực thực vật). Khi phân cắt, mỗi tế bào nhận **một phần tế bào chất khác nhau**, tức nhận **cảm ứng tố khác nhau**. Mỗi loại cảm ứng tố "mở" một bộ gen đặc trưng → tổng hợp protein khác nhau → tế bào phân hóa thành **lá phôi ngoài, giữa, trong**, mang các mầm cơ quan khác nhau.

**c) Sau phôi vị hóa: cảm ứng phôi**

Một số tế bào phôi vị trở thành **nhóm tế bào chỉ huy** (**trung tâm tổ chức**). Nhóm này:

- tự biệt hóa được một cách độc lập;
- tiết ra chất gọi là **tổ chức tố** (= **chất cảm ứng sơ cấp**), tác động lên tế bào lân cận, bắt chúng biệt hóa theo hướng xác định.

> [!ghi-nho] Định nghĩa cảm ứng phôi
> **Cảm ứng phôi** là hiện tượng **một mô định hướng sự biệt hóa và sự phát triển của mô xung quanh**. Đó là cách phôi **tự điều tiết** trong quá trình phát triển và biệt hóa.

Ở phôi vị ếch, trung tâm chỉ huy là **vùng môi lưng** (của phôi khẩu). Vùng bị chỉ huy (ví dụ **vùng bụng**) có kiểu **biệt hóa lệ thuộc**.

**Thí nghiệm ghép môi lưng phôi vị ếch:**

| Ghép | Kết quả | Kết luận |
|---|---|---|
| Mảnh **môi lưng** → vùng **bụng** của phôi khác | Phôi thành **ếch hai đầu**. Đầu thứ hai do **cả mảnh ghép lẫn tế bào vùng bụng xung quanh** tạo nên | Môi lưng **cảm ứng** được tế bào lân cận đổi hướng |
| Mảnh **vùng bụng** → vùng **môi lưng** | Mảnh bụng **không** biến vùng lưng thành bụng; ngược lại nó **bị** môi lưng chi phối, phát triển thành **đầu** | Vùng bụng **không có** khả năng cảm ứng; chỉ là vùng **bị** cảm ứng |

> [!bay]
> Đầu thứ hai **không phải** chỉ do tế bào của mảnh ghép tạo ra. Ý chính là mảnh ghép đã **lôi kéo tế bào chủ** xung quanh biệt hóa theo — đó mới là "cảm ứng".

> [!cap-nhat] "Môi lưng" chính là bộ tổ chức Spemann
> Thí nghiệm này do **Spemann và Mangold** công bố năm 1924 trên phôi kỳ giông (Spemann nhận giải Nobel 1935). Vùng môi lưng được gọi là **bộ tổ chức Spemann** (*Spemann organizer*). Hiện nay biết "tổ chức tố" thật ra là **nhiều protein tín hiệu** (như chordin, noggin) hoạt động bằng cách **chặn** tín hiệu "hóa bụng" của vùng xung quanh; ở phôi gà, chuột, người có cấu trúc tương đương (nút nguyên thủy — *node*).

**Chuỗi cảm ứng.** Tế bào đã biệt hóa nhờ chất cảm ứng sơ cấp lại tiết ra sản phẩm gen làm **chất cảm ứng thứ cấp**, tác động lên tế bào xa hơn, và cứ thế tiếp diễn. Các sản phẩm gen có thể là **chất cảm ứng** hoặc **chất ức chế** cho một hay nhiều gen. Toàn bộ quá trình phát triển phôi là một dây chuyền:

=> Tinh trùng (thụ tinh) → cảm ứng tố cơ sở → cảm ứng tố sơ cấp → cảm ứng tố thứ cấp → … → cơ thể hoàn chỉnh

Khác biệt về **thành phần hóa học** của tế bào dẫn tới khác biệt sâu sắc về **chức năng và hình thái**, tạo ra các mô, các cơ quan.

> [!bay]
> **Cảm ứng tố đầu tiên** trong chuỗi là **tinh trùng** (khi thụ tinh), không phải cảm ứng tố cơ sở. (Giáo trình in nhầm "cảm ứng tố *cơ cấp*" — đọc là **sơ cấp**.)

**Tính chất của tổ chức tố** (câu Tự lượng giá số 2):

| Tính chất | Bằng chứng/ví dụ của sách |
|---|---|
| **Không đặc hiệu loài** | Ghép giữa **ếch và kỳ giông** cho kết quả như ghép cùng loài |
| **Một trung tâm tổ chức có thể tạo nhiều tổ chức tố** | **Củng mạc** cần cho sự hình thành cả **nhân mắt** (thể thủy tinh) và **giác mạc** |
| **Tế bào càng biệt hóa, cảm ứng càng giảm** | Ghép môi lưng vào vùng lưng phôi khác: **trước** khi có thượng bì → tạo **tấm thần kinh**; ghép **muộn**, khi thượng bì đã hình thành → mô **không đổi hướng** |
| **Vị trí trung tâm tổ chức liên quan với nơi tạo hệ thần kinh** | Thấy ở gà, ếch, cóc, kỳ giông… |

- Ở **giai đoạn muộn** của phôi, cơ chế cảm ứng **giảm dần** và được thay bằng điều tiết **thần kinh và nội tiết**. Ở cơ thể trưởng thành, thay thế **hoàn toàn**.
- Giáo trình còn nêu: ngoài bộ gen chung, ở các tế bào đã phân hóa có nhiều **"bộ phụ"** có chức năng đặc trưng — đó là các lớp **protein cơ sở loại histon** làm nhiệm vụ điều chỉnh.

> [!vi-du] Vì sao "càng biệt hóa, cảm ứng càng giảm"?
> Một tế bào chỉ đáp ứng được tín hiệu khi nó còn **"sẵn sàng tiếp nhận"** (có thụ thể, có các gen chưa bị khóa chặt) — gọi là **khả năng đáp ứng** (*competence*). Khi tế bào đã đi sâu vào một hướng, các gen của hướng khác bị đóng lại, nên tín hiệu có đến cũng không làm nó đổi hướng nữa. Đó là lý do thượng bì đã hình thành thì không thể biến thành tấm thần kinh.

#### 1.1.3. Tính vững chắc tương đối về chức năng của chương trình thông tin di truyền

Ở cơ thể hoàn chỉnh, mỗi mô chỉ có **một số gen hoạt động**: các gen tạo protein cho **chức năng biệt hóa** riêng và các gen cho **phân bào**. **Đại đa số gen ở trạng thái "đóng"**.

Tuy vậy, các gen bị đóng **không mất** và **không hỏng**: nếu được **giải kìm hãm**, chúng vẫn hoạt động nguyên vẹn. Nói cách khác, bộ gen tế bào biệt hóa vẫn **đầy đủ như bộ gen của hợp tử** — đó là **tính vững chắc tương đối**.

Bằng chứng:

- **Cóc châu Phi *Xenopus*** (giáo trình viết *Senopus*): nhân tế bào đã biệt hóa thay vào nhân hợp tử → phát triển thành cơ thể mới **khỏe mạnh, hữu thụ**.
- **Cừu Dolly**: nhân tế bào **tuyến vú** (biệt hóa rất sâu) vẫn đủ thông tin tạo nên cả một cơ thể (mục 3.1).

> [!cap-nhat] Chi tiết thí nghiệm *Xenopus* và tế bào gốc vạn năng cảm ứng
> - Giáo trình ghi nhân lấy "từ cơ thể cóc trưởng thành". Thực ra thí nghiệm kinh điển của **John Gurdon** (1962) dùng nhân **tế bào biểu mô ruột của nòng nọc**, thu được ếch trưởng thành hữu thụ. Nhân từ tế bào của con **trưởng thành** thì thường chỉ phát triển được đến **nòng nọc**. Kết luận "nhân biệt hóa vẫn đủ thông tin" vẫn đúng.
> - Năm 2006, **Yamanaka** đưa **4 yếu tố phiên mã** vào nguyên bào sợi (tế bào mô liên kết) của chuột, năm 2007 làm được với nguyên bào sợi da người, và biến chúng trở lại trạng thái giống tế bào phôi — gọi là **tế bào gốc vạn năng cảm ứng** (iPS). Gurdon và Yamanaka cùng nhận Nobel 2012. Đây là bằng chứng mạnh nhất cho tính vững chắc của bộ gen.

#### 1.1.4. Các nhân tố từ nguồn mẹ

Bố và mẹ góp **lượng ADN (DNA) nhân tương đương** (mỗi bên một bộ đơn bội). Nhưng **tế bào chất** của hợp tử gần như **toàn bộ là của trứng**. Trong đó mẹ đã dự trữ sẵn các nhân tố ảnh hưởng tới phôi, thậm chí tới vài đặc điểm ở con trưởng thành:

- **Cảm ứng tố cơ sở**;
- **ARN thông tin có đời sống dài**, **ARN ribosom** (ribosom);
- **ADN ty thể**, các ADN tự do trong tế bào chất — tích lũy trong quá trình tạo noãn.

**a) Cảm ứng tố cơ sở**

- Tổng hợp **trong quá trình hình thành trứng**, thường nằm ở **lớp ngoài** của trứng.
- Phân bố **khác nhau ở các vùng** khác nhau của trứng → phôi bào nhận phần nào thì biệt hóa theo hướng đó (lá phôi, mầm cơ quan).
- Dựa vào cách phân bố cảm ứng tố cơ sở mà chia ra **trứng điều hòa** và **trứng khảm** (mục 1.1.2).

**b) Sản phẩm gen từ nguồn mẹ**

- mARN đời sống dài, ribosom, ty thể được tổng hợp với **trữ lượng rất lớn** và để ở trạng thái **bất hoạt** trong trứng.
- **Sau thụ tinh**, trứng được hoạt hóa → các thành phần này **cũng được hoạt hóa**.
- **mARN của mẹ** làm khuôn tổng hợp protein ở giai đoạn sớm của phôi. Thông tin này có thể **trội** hơn gen của hợp tử → phôi sớm mang **kiểu hình giống mẹ**, đôi khi kéo dài suốt đời.
- Bằng điện di enzym, protein, người ta thấy mARN của chính hợp tử chỉ bắt đầu được tổng hợp ở **cuối phôi nang**, thậm chí **phôi vị** (ở các loài được nghiên cứu).

**Ví dụ của sách:**

| Phép lai | Con lai | Giống ai hơn |
|---|---|---|
| **Ngựa cái × lừa đực** | **La** | Mang nhiều đặc điểm của **ngựa** (mẹ) |
| **Lừa cái × ngựa đực** | **Boocđô** (*hinny*) | Giống **lừa** (mẹ) hơn, khác la |

Ở người, một số nghiên cứu thấy con giống mẹ hơn giống bố về **nếp vân da** ngón tay, bàn chân.

> [!bay]
> Mẹo nhớ: con lai **giống mẹ** — la có mẹ là **ngựa** nên giống ngựa; boocđô có mẹ là **lừa** nên giống lừa. Đừng nhớ theo con đực.

> [!ung-dung] ADN ty thể — di truyền theo dòng mẹ
> Ty thể của phôi gần như **chỉ đến từ trứng**. Vì vậy các **bệnh do đột biến ADN ty thể** (ví dụ bệnh thần kinh thị giác di truyền Leber, một số bệnh cơ ty thể) chỉ truyền **từ mẹ**: mẹ mang đột biến thì truyền ADN ty thể đột biến cho **tất cả các con** (mức biểu hiện bệnh có thể khác nhau), bố không truyền. Đây là một "nhân tố từ nguồn mẹ" có ảnh hưởng suốt đời.

### 1.2. Hoạt động của operon trong sự phát triển cá thể

**Operon** (theo giáo trình) là một hệ thống gồm:

| Thành phần | Ký hiệu | Vai trò |
|---|---|---|
| **Gen điều chỉnh** | R | Sản xuất **chất kìm hãm** hoặc **chất hoạt hóa** để điều chỉnh operon |
| **Vùng khởi đầu** | Pr | Chỉ định **nơi bắt đầu phiên mã** |
| **Vị trí vận hành** | O | **Kiểm tra** (cho phép/không cho phép) hoạt động của gen cấu trúc |
| **Gen cấu trúc** (1 hoặc nhiều) | Ct | Mang thông tin để **sản xuất protein** |

**Cơ chế theo giáo trình ở động vật đa bào:**

- Chất kìm hãm là **histon**. Cơ chế histon kìm hãm gen chỉ bắt đầu từ **giai đoạn phôi vị hóa**.
- Histon là **protein dị lập thể** (*allosteric*) → chất cảm ứng gắn được vào một vị trí nhất định trên histon → histon đổi cấu hình → **giải kìm hãm**.

=> Histon → kìm hãm gen
=> Chất cảm ứng + Histon → giải kìm hãm → gen cấu trúc hoạt động

- Chất cảm ứng **đầu tiên** do **trung tâm tổ chức** sản sinh. Nó giải kìm hãm một hay nhiều operon → gen cấu trúc hoạt động → **tế bào bắt đầu biệt hóa** → sản phẩm gen cấu trúc lại là **chất cảm ứng tiếp theo** cho tế bào lân cận. Chuỗi cảm ứng tạo ra sự biệt hóa.

**Hai bước của sự biệt hóa:**

| Bước | Điều xảy ra | Biểu hiện |
|---|---|---|
| 1. **Định hướng** (*determination*) | Đa số operon vẫn bị kìm hãm, chỉ **vài operon được giải kìm hãm** | Chỉ thay đổi về **lượng**, ở mức **hóa sinh**; **chưa** có dấu hiệu hình thái |
| 2. **Biệt hóa** thể hiện | Gen cấu trúc hoạt động, tạo protein cần thiết | Thay đổi về **hình thái** → biệt hóa rõ |

> [!bay]
> Tế bào ở giai đoạn **định hướng** trông chưa khác gì, nhưng "số phận" đã được quyết định. Câu hỏi "giai đoạn chỉ thay đổi ở mức hóa sinh, chưa có biểu hiện hình thái" → đáp án là **định hướng (determination)**.

> [!cap-nhat] Operon, histon và gen điều khiển phát triển — hiểu theo ngày nay
> - **Operon** đúng nghĩa (nhiều gen cấu trúc chung một promoter, ví dụ operon *lac*) là đặc trưng của **vi khuẩn**. Ở sinh vật nhân chuẩn, mỗi gen thường có promoter riêng và được điều hòa chủ yếu bởi **yếu tố phiên mã**, vùng **tăng cường** (*enhancer*), và trạng thái **chất nhiễm sắc**.
> - **Histon** đúng là có vai trò "đóng – mở" gen: ADN quấn chặt quanh histon thì khó phiên mã. Nhưng việc mở ra diễn ra qua **gắn/gỡ nhóm hóa học** lên histon (acetyl hóa, methyl hóa…) và **methyl hóa ADN** — gọi chung là **điều hòa ngoại di truyền** (*epigenetic*) — chứ không phải histon là "chất kìm hãm dị lập thể" của operon. Giáo trình ghi histon "được sản xuất trong hạch nhân"; thực ra histon (như mọi protein) được tổng hợp trên **ribosom trong tế bào chất** rồi đi vào nhân. Hạch nhân là nơi tạo **rARN** và lắp ráp tiểu đơn vị ribosom.
> - Câu cuối mục này của giáo trình ("ngày nay đã chỉ rõ tên các gen quyết định biệt hóa") nói về các **gen điều khiển phát triển**. Nổi bật nhất là các **gen Hox** (chứa đoạn **homeobox**): xếp thành cụm trên NST (nhiễm sắc thể) theo đúng thứ tự từ đầu đến đuôi cơ thể, quyết định "vùng nào thành bộ phận nào". Đột biến Hox ở ruồi giấm có thể làm **mọc chân ở chỗ râu**. Ở người, đột biến gen *HOXD13* gây **dính ngón – thừa ngón** (synpolydactyly). Nobel 1995 trao cho các nghiên cứu về gen điều khiển phát triển phôi sớm.
> - Đi thi môn này vẫn trả lời theo giáo trình: chất kìm hãm ở động vật đa bào là **histon**.

## 2. Các nhân tố ảnh hưởng lên sự phát triển phôi

### 2.1. Vai trò của môi trường ngoại cảnh

Gen là "bản thiết kế", nhưng bản thiết kế chỉ được thực hiện đúng trong **điều kiện bình thường nhất định**. Ví dụ của sách:

| Đối tượng | Đòi hỏi của môi trường |
|---|---|
| Trứng gà | Chỉ phát triển ở khoảng **38 °C** (vì vậy phải ấp) |
| Trứng giun | Chỉ phát triển trong môi trường **pH acid** |
| Nòng nọc | Chỉ **biến thái** thành ếch khi có **đủ thyroxin** |
| Nói chung | **Nhiệt độ** và **nồng độ oxy** rất quan trọng |

Phôi động vật có vú nằm trong cơ thể mẹ, điều kiện khá ổn định, nhưng **biến đổi sinh lý của mẹ** và **biến động môi trường** vẫn tác động đến phôi.

> [!ghi-nho] Hai giai đoạn nhạy cảm nhất
> Trong cả đời cá thể, tế bào **mẫn cảm mạnh nhất** với nhân tố môi trường ở **giai đoạn tạo giao tử** và **giai đoạn phôi**. Cùng một tác nhân nhưng tác động ở các giai đoạn khác nhau sẽ cho hậu quả khác nhau.

**Vì sao giai đoạn phôi lại nhạy cảm nhất?** Vì đây là lúc tế bào **phân chia nhanh nhất** và đang **"bật – tắt" gen hàng loạt** theo chuỗi cảm ứng. Một sai lệch nhỏ ở một mắt xích sớm sẽ lan truyền xuống mọi mắt xích sau. Ngược lại, khi cơ quan đã hình thành xong, tác nhân chỉ còn làm hỏng **kích thước hoặc chức năng**, không còn tạo được dị dạng lớn.

> [!ung-dung] Nòng nọc cần thyroxin — trẻ sơ sinh cũng vậy
> Hormon tuyến giáp không chỉ cần cho nòng nọc biến thái. Ở người, thiếu hormon giáp trong bào thai và những tháng đầu sau sinh (do mẹ **thiếu iod** nặng, hoặc **suy giáp bẩm sinh**) làm não chậm phát triển, gây **chậm phát triển trí tuệ** không hồi phục nếu không điều trị sớm. Vì vậy có chương trình **muối iod** và **sàng lọc sơ sinh** (lấy máu gót chân đo TSH).

Vi phạm những đòi hỏi thiết yếu của phôi đều có thể gây rối loạn phát triển. **Chiếu xạ, một số hóa chất độc, vi khuẩn, virus** có thể làm phôi phát triển bất thường, thậm chí **sinh quái thai** (xem thêm bài *Đột biến* — tác nhân gây đột biến).

### 2.2. Cơ sở sinh học của sự phát sinh quái thai

Bất thường của phôi có thể do **môi trường** hoặc do **di truyền**. Bất thường nặng về hình thái thì gọi là **quái thai** (ngày nay thường dùng *dị tật bẩm sinh*). Chất hay yếu tố gây ra chúng gọi là **tác nhân gây quái thai** (*teratogen*).

**Ba cơ chế tác động** theo giáo trình:

| Cơ chế | Hậu quả | Ví dụ minh họa (bổ sung) |
|---|---|---|
| 1. **Rối loạn cấu trúc vật liệu di truyền** | Một hoặc vài cơ quan phát triển bất thường | Tia xạ ion hóa làm đứt gãy ADN, NST |
| 2. **Rối loạn quá trình phân bào** | Cơ quan phát triển **quá mức** hoặc **không đầy đủ** | Thuốc kháng chuyển hóa (methotrexat) ức chế tổng hợp ADN; virus rubella làm chậm phân bào |
| 3. **Gây chết tế bào có định hướng** | Chỉ **một hoặc một số loại tế bào nhạy cảm** chết, các loại khác không sao → cơ quan đó **không phát triển** hoặc phát triển không đầy đủ | Rượu gây chết tế bào mào thần kinh, tế bào não; isotretinoin ảnh hưởng tế bào mào thần kinh |

> [!bay]
> Cơ chế 3 là **chết có chọn lọc** (có định hướng): chỉ những tế bào **nhạy cảm** với tác nhân mới chết. Không phải "gây chết toàn bộ phôi".

### 2.3. Giai đoạn nhạy cảm theo tuần và các tác nhân gây quái thai thường gặp (bổ sung)

Phần này không có chi tiết trong giáo trình nhưng là kiến thức nền bắt buộc của người làm y — nhất là khi kê đơn cho phụ nữ tuổi sinh đẻ.

**Ba thời kỳ** (tính theo tuần **sau thụ tinh**):

| Thời kỳ | Đang xảy ra gì | Hậu quả khi gặp tác nhân |
|---|---|---|
| **Tuần 1–2** (trước và quanh làm tổ) | Phân cắt, phôi nang, phôi hai lá; tế bào còn đa tiềm năng | Quy luật **"tất cả hoặc không"**: hoặc phôi chết (sẩy rất sớm), hoặc các tế bào còn lại **bù trừ** hoàn toàn → thường **không dị tật** |
| **Tuần 3–8** (thời kỳ phôi) | Phôi vị hóa, hình thành **mầm mọi cơ quan** | **Nhạy cảm nhất** → **dị tật lớn** về hình thái |
| **Tuần 9 → sinh** (thời kỳ thai) | Cơ quan lớn lên, hoàn thiện chức năng | Dị tật nhỏ, **chậm lớn**, rối loạn **chức năng** (nhất là não, tai, cơ quan sinh dục ngoài) |

![Hình 2. Giai đoạn nhạy cảm với tác nhân gây quái thai theo tuần sau thụ tinh](giai-doan-nhay-cam.svg)

> [!bay] Tuổi phôi khác tuổi thai lâm sàng
> - Phôi học tính tuần **từ lúc thụ tinh**. Sản khoa tính tuổi thai **từ ngày đầu kỳ kinh cuối** (KKC), tức **cộng thêm khoảng 2 tuần**.
> - Vậy "tuần 3–8 sau thụ tinh" ≈ **tuần 5–10 tính theo KKC**. Nhiều phụ nữ **chưa biết mình có thai** trong chính thời kỳ nguy hiểm nhất này.
> - Quy luật "tất cả hoặc không" là quy luật **thống kê**, không phải lời bảo đảm; vài chất tồn lưu lâu trong cơ thể (như isotretinoin, acitretin) vẫn gây hại về sau.

**Các nhóm tác nhân hay gặp:**

| Nhóm | Tác nhân | Hậu quả điển hình |
|---|---|---|
| **Thuốc** | **Thalidomid** | **Chi ngắn như vây hải cẩu** (phocomelia), dị tật tai, tim; giai đoạn nguy hiểm khoảng **ngày 20–36 sau thụ tinh** |
| | **Isotretinoin** (dẫn chất vitamin A trị mụn) và retinoid khác | Dị tật tai, mặt, tim, não, tuyến ức; nguy cơ rất cao |
| | **Warfarin** (chống đông kháng vitamin K) | **Bệnh phôi warfarin**: mũi tẹt do kém phát triển, đầu xương có chấm vôi hóa (phơi nhiễm khoảng tuần 6–12 thai kỳ); về sau gây chảy máu não thai |
| | **Acid valproic** (chống động kinh) | Khoảng **10%** trẻ phơi nhiễm có dị tật lớn (**dị tật ống thần kinh**, tim, hở môi – vòm, tật lỗ tiểu thấp…); **30–40%** có rối loạn phát triển thần kinh (chậm nói, tự kỷ, giảm IQ). Châu Âu bắt buộc **chương trình phòng tránh thai** khi dùng cho nữ từ 2018 |
| | **Ức chế men chuyển, ức chế thụ thể angiotensin** | Ở quý 2–3: tổn thương **thận thai**, thiểu ối |
| | **Methotrexat**, thuốc kháng ung thư | Sẩy thai, dị tật sọ – mặt, chi |
| | **Tetracyclin** | **Răng vàng**, ảnh hưởng xương (từ quý 2 trở đi) |
| | **Misoprostol** | Sẩy thai; dị tật chi, liệt dây thần kinh sọ (Möbius) nếu thai còn sống |
| **Rượu** | Ethanol | **Rối loạn phổ rượu bào thai** (FASD): thể nặng nhất là **hội chứng rượu bào thai** — mặt đặc trưng (khe mắt ngắn, rãnh nhân trung phẳng, môi trên mỏng), chậm lớn, tổn thương não; nhiều trẻ chỉ có rối loạn học tập, hành vi mà **không** có mặt đặc trưng. **Không có ngưỡng an toàn**, không có thời điểm an toàn trong thai kỳ |
| **Nhiễm trùng** | **Virus rubella** | **Tam chứng**: đục thủy tinh thể, điếc, tim bẩm sinh (còn ống động mạch). Nguy cơ cao nhất khi nhiễm trong **3 tháng đầu** |
| | Cytomegalovirus, *Toxoplasma*, giang mai, thủy đậu | Tật đầu nhỏ, vôi hóa não, điếc, tổn thương mắt… CMV là nhiễm trùng bẩm sinh hay gặp nhất, nguyên nhân hàng đầu gây **điếc** bẩm sinh không do di truyền |
| | **Virus Zika** (muỗi *Aedes* truyền, như sốt xuất huyết) | **Hội chứng Zika bẩm sinh**: **tật đầu nhỏ** nặng, vôi hóa não, tổn thương mắt, co cứng khớp. Phát hiện qua dịch ở **Brazil 2015**; WHO tuyên bố **tình trạng y tế công cộng khẩn cấp quốc tế** từ 1/2/2016 đến 18/11/2016. Việt Nam ghi nhận ca tật đầu nhỏ đầu tiên liên quan Zika ở Đắk Lắk (10/2016) |
| **Tia xạ ion hóa** | Liều cao (tai nạn hạt nhân, xạ trị) | Tật **đầu nhỏ**, chậm phát triển trí tuệ (nhạy nhất khoảng tuần 8–15), tăng nguy cơ ung thư |
| **Bệnh của mẹ** | Đái tháo đường không kiểm soát; **thiếu acid folic** | Dị tật tim, xương cùng; **dị tật ống thần kinh** |
| **Hóa chất** | Thủy ngân hữu cơ (thảm họa Minamata), chì | Tổn thương não, bại não |

> [!ung-dung] Thalidomid — bài học làm thay đổi ngành dược
> - Cuối những năm 1950, thalidomid được bán ở nhiều nước như **thuốc ngủ, chống nôn nghén** "an toàn". Đến 1961 người ta nhận ra nó gây chi ngắn như vây hải cẩu cho hơn **10 000 trẻ**. Chuột (loài dùng thử nghiệm khi đó) lại **không** bị dị tật → bài học: **tính nhạy cảm phụ thuộc loài và kiểu gen**.
> - Hậu quả: từ đó mọi thuốc mới phải được **thử độc tính sinh sản** trên nhiều loài trước khi lưu hành.
> - Ngày nay thalidomid vẫn được dùng (bệnh phong thể phản ứng, đa u tủy xương) nhưng kèm **chương trình phòng tránh thai nghiêm ngặt**. Tương tự, người dùng **isotretinoin** phải tránh thai từ trước, trong và ít nhất 1 tháng sau khi ngừng thuốc.

> [!ung-dung] Phòng ngừa trong thực hành
> - **Hỏi khả năng có thai** ở mọi phụ nữ tuổi sinh đẻ trước khi kê thuốc, chụp X-quang.
> - Phụ nữ chuẩn bị mang thai: uống **acid folic** (khoảng 400 µg/ngày) từ **ít nhất 1 tháng** trước khi có thai đến hết 3 tháng đầu để giảm dị tật ống thần kinh; người **từng có con bị dị tật ống thần kinh** dùng **4 mg/ngày** theo chỉ định (CDC); **tiêm vắc xin sởi – quai bị – rubella** trước khi có thai và **tránh thai ít nhất 1 tháng** sau tiêm (vắc xin sống).
> - Người đang dùng warfarin muốn có thai: bác sĩ chuyên khoa thường chuyển sang **heparin** (phân tử lớn, **không qua nhau thai**) trong giai đoạn nguy cơ.
> - Chụp X-quang chẩn đoán thông thường cho liều tới thai **rất thấp**, dưới ngưỡng gây dị tật (khoảng 50–100 mGy). Không nên vì lo sợ quá mức mà bỏ chẩn đoán cần thiết, nhưng vẫn che chắn và chọn phương pháp không dùng tia khi có thể.

> [!cap-nhat] Phân loại thuốc thai kỳ A/B/C/D/X đã bị FDA bỏ
> (bổ sung – kiến thức hiện nay) Nhiều tài liệu (kể cả sách, phần mềm tra thuốc ở Việt Nam) vẫn ghi thuốc thuộc "nhóm A, B, C, D, X" theo hệ phân loại của **FDA Hoa Kỳ (1979)**. Hệ này bị chê là **quá đơn giản**: người đọc hiểu nhầm thành thang nguy cơ tăng dần, trong khi chữ C có thể chỉ là "chưa có dữ liệu", và nó không nói nguy cơ khác nhau theo **liều, thời điểm** phơi nhiễm.
> - **Quy định nhãn thuốc thai kỳ và cho con bú** (*Pregnancy and Lactation Labeling Rule*, **PLLR**) do FDA ban hành **12/2014**, có hiệu lực từ **30/6/2015**, **bỏ các chữ cái** A/B/C/D/X. Nhãn thuốc mới thay bằng **phần mô tả bằng lời**: mục **8.1 Mang thai** (tóm tắt nguy cơ, dữ liệu người và động vật, cân nhắc lâm sàng, sổ đăng ký phơi nhiễm thai kỳ nếu có), **8.2 Cho con bú**, **8.3 Nữ và nam có khả năng sinh sản** (thử thai, tránh thai, ảnh hưởng khả năng sinh sản).
> - Một số nước vẫn dùng hệ chữ cái của riêng mình (vd **Úc**: A, B1–B3, C, D, X), nên khi đọc "nhóm D", "nhóm X" cần biết đó là của hệ nào.
> - Thực hành: không dựa vào một chữ cái; tra **dữ liệu cụ thể** (tuổi thai lúc phơi nhiễm, liều, nguy cơ của chính bệnh nếu không điều trị). (Nguồn: FDA, Federal Register 79(233), 4/12/2014.)

> [!yhct] Vị thuốc "kỵ thai" (thai kỵ) theo Dược học cổ truyền
> Theo cách phân loại kinh điển của Dược học cổ truyền (Trung dược học, Dược điển Trung Quốc), các vị kỵ thai chia **hai mức**:
>
> | Mức | Đặc điểm chung | Ví dụ thường gặp |
> |---|---|---|
> | **Cấm dùng** | Độc tính mạnh hoặc tác dụng rất mạnh (**trục thủy, tả hạ mạnh; phá huyết tiêu trưng; thơm tẩu thoán**) | **Xạ hương**; **Ba đậu**; trục thủy: **Khiên ngưu tử** (Hắc sửu), **Đại kích**, **Cam toại**, **Nguyên hoa**, Thương lục; phá huyết: **Thủy điệt** (Đỉa), **Manh trùng**, **Tam lăng**, **Nga truật**; vị rất độc: Ban miêu, Hùng hoàng, Thạch tín |
> | **Thận trọng** (dùng khi thật cần, liều thấp, có người có chuyên môn theo dõi) | **Thông kinh khứ ứ** (hoạt huyết hóa ứ), **hành khí phá trệ**, **công hạ**, **tân nhiệt** (cay nóng), **hoạt lợi** | Hoạt huyết: **Đào nhân**, **Hồng hoa**, **Ngưu tất** (dẫn huyết đi xuống); hành khí phá trệ: **Chỉ thực**; công hạ: **Đại hoàng**; tân nhiệt: **Phụ tử**, **Can khương**, **Nhục quế** |
>
> - Lý luận cổ truyền: các vị phá huyết, hoạt huyết, tả hạ, trục thủy, thơm tẩu thoán làm "**động thai**", dễ sẩy thai, đẻ non.
> - **Mức bằng chứng**: danh mục chủ yếu dựa trên **kinh nghiệm cổ điển** và một phần dữ liệu thực nghiệm (gây co tử cung, độc với phôi trên động vật). Điều cổ nhân lo chủ yếu là **sẩy thai và độc tính trên mẹ**. Khả năng **gây dị tật** (quái thai theo nghĩa của bài này) của phần lớn dược liệu **chưa được nghiên cứu đầy đủ trên người**. "Chưa có dữ liệu" **không có nghĩa là an toàn**.
> - Xếp mức (cấm hay thận trọng) của một số vị **khác nhau giữa các tài liệu** (vd Hồng hoa, Phụ tử, Ngưu tất có nơi ghi "cấm", nơi ghi "thận trọng"). Khi kê đơn phải tra **chuyên luận từng vị** trong Dược điển và tài liệu hiện hành.
> - Nguyên tắc thực hành giống y học hiện đại: **hỏi khả năng có thai trước khi kê đơn**; tránh mọi thuốc không thật cần thiết, nhất là **tuần 3–8 sau thụ tinh**.

## 3. Một số thực nghiệm về phôi

### 3.1. Chuyển nhân và tạo dòng tế bào đặc hiệu

- Ban đầu làm trên sinh vật có **trứng to** (ếch, cóc): lấy nhân phôi bào của phôi dâu có đặc tính chọn trước, cấy vào trứng **đã bỏ nhân** → trứng phát triển thành dòng tế bào mang **tính chất do nhân chi phối**.
- Về sau làm được ở **động vật có vú** (trứng nhỏ), mở đầu là **cừu Dolly ra đời năm 1996**.

**Cừu Dolly** — ba con cừu tham gia:

| Vai trò | Cừu | Có quyết định kiểu hình Dolly? |
|---|---|---|
| Cho **nhân** (tế bào **tuyến vú**, nuôi trong môi trường nghèo dinh dưỡng để dừng ở **G~0~**) | **Finn Dorset**, lông **trắng** | **Có** — Dolly lông trắng, giống hệt cừu này |
| Cho **trứng đã rút nhân** (tế bào chất) | Cừu đầu đen **Blackface** | Không |
| **Mang thai** (tử cung) | Cừu khác (sách ghi lông đen; thực tế cũng là cừu Blackface mặt đen) | Không |

Sau Dolly, nhiều phòng thí nghiệm tạo được cừu, lợn, bò bằng chuyển nhân.

> [!bay]
> - Dolly giống con **cho nhân**, không giống con cho trứng, không giống con mang thai → chứng minh **nhân** quyết định kiểu hình chính.
> - Vì sao phải đưa tế bào cho nhân về **G~0~**? Để nhân "nghỉ", chưa nhân đôi ADN, dễ được tế bào chất trứng **lập trình lại** về trạng thái giống hợp tử.

> [!cap-nhat] Dolly "giống hoàn toàn" con cho nhân?
> Về kiểu hình chính thì đúng. Nhưng **ADN ty thể** của Dolly đến từ **trứng** (cừu Blackface), nên về di truyền Dolly không phải bản sao 100%. Dolly ra đời tháng 7/1996, công bố đầu năm 1997 (*Nature*). Nhân bản vô tính **sinh sản** ở người bị cấm ở hầu hết các nước; còn nhân bản phôi để lấy tế bào gốc (**nhân bản trị liệu**) thì được nghiên cứu có kiểm soát. Năm 2018 Trung Quốc nhân bản thành công **khỉ** (linh trưởng đầu tiên) bằng chuyển nhân tế bào soma.

> [!cap-nhat] "Phôi tổng hợp" — mô hình phôi từ tế bào gốc
> (bổ sung – kiến thức hiện nay) Từ năm **2022** (chuột) và **2023** (người), một số phòng thí nghiệm cho tế bào gốc (tế bào gốc phôi hoặc iPS) **tự tổ chức** thành cấu trúc giống phôi sớm, có cả phần giống lá nuôi và túi noãn hoàng, **không cần trứng và tinh trùng**. Báo chí gọi là "phôi tổng hợp"; tên khoa học là **mô hình phôi từ tế bào gốc** (*stem cell–based embryo models*, SCBEM). Chúng giúp nghiên cứu giai đoạn **làm tổ và tuần 2–3** (thời điểm hay sẩy thai, khó quan sát ở người) mà không dùng phôi thật.
> - Hướng dẫn quốc tế **ISSCR** (cập nhật 8/2025) yêu cầu mọi nghiên cứu loại này phải qua hội đồng chuyên môn; **cấm** chuyển mô hình phôi người vào **tử cung** người hay động vật, và **cấm** nuôi chúng trong hệ thống nhân tạo đến mức có thể sống được (*ectogenesis*).
> - Với **phôi người thật**, nhiều nước (vd Anh) giới hạn nuôi cấy trong phòng thí nghiệm tối đa **14 ngày** (trước khi xuất hiện đường nguyên thủy).
>
> (Nguồn: ISSCR Guidelines, targeted update 8/2025; PET/BioNews 2025.)

### 3.2. Chuyển gen

Kỹ thuật di truyền cho phép chuyển gen của sinh vật này sang sinh vật khác. Ví dụ của sách: gen **hormon sinh trưởng của người** ghép vào ADN trứng **chuột nhắt** → chuột nhắt lớn như **chuột cống**.

**Liệu pháp gen** (*gene therapy*) được kỳ vọng nhiều, nhưng đưa gen vào **mọi tế bào** của cơ thể đã hình thành là rất khó. Theo giáo trình, làm dễ nhất khi mầm cơ thể mới chỉ có **một hoặc vài tế bào**. **Ba phương pháp** cơ bản:

| Phương pháp | Gen có mặt ở |
|---|---|
| 1. Đưa đoạn ADN vào **tiền nhân của trứng** | **Mọi tế bào** khi cơ thể hình thành |
| 2. Đưa gen vào **phôi bào nhờ retrovirus** | **Mọi tế bào** |
| 3. Đưa gen vào **tế bào nguồn của mô cần gen** (vd dùng retrovirus đưa gen insulin vào **tế bào mầm tụy**) | **Chỉ** tế bào của cơ quan cần gen hoạt động |

Mục tiêu: chữa **tận gốc** bệnh di truyền phân tử, và tập trung nhiều gen có lợi vào một sinh vật.

> [!cap-nhat] Liệu pháp gen ngày nay
> Hiện nay liệu pháp gen ở người chủ yếu làm trên **tế bào sinh dưỡng** (giống phương pháp 3), không làm trên phôi. Một số mốc đã được cấp phép:
> - **Luxturna** (FDA 12/2017): virus AAV mang gen *RPE65* tiêm dưới võng mạc, chữa một dạng **mù bẩm sinh** di truyền.
> - **Zolgensma** (FDA 5/2019): AAV mang gen *SMN1* truyền tĩnh mạch một lần cho trẻ **teo cơ tủy sống**.
> - **Casgevy** (Anh 11/2023, Mỹ 12/2023): chỉnh sửa gen **CRISPR** tế bào gốc tạo máu, cho **hồng cầu hình liềm** và **β-thalassemia** (xem bài *Cơ sở phân tử của hiện tượng di truyền*).
>
> Sửa gen trên **phôi người** để sinh con bị cấm rộng rãi vì lý do an toàn và đạo đức; vụ hai bé gái có phôi bị sửa gen *CCR5* ở Trung Quốc (2018) bị cộng đồng khoa học lên án và người thực hiện bị kết án tù.

### 3.3. Sinh vật trong ống nghiệm và thụ tinh trong ống nghiệm

- **Sinh vật trong ống nghiệm**: nhờ môi trường nuôi cấy tế bào, mô, người ta lấy phôi (từ trứng đã thụ tinh trong cơ thể mẹ) ra **nuôi in vitro** và phôi phát triển thành cơ thể hoàn chỉnh.
- **Thụ tinh trong ống nghiệm** (IVF — *in vitro fertilization*): cho **tinh trùng đã chọn lọc** thụ tinh với **trứng chín** trong ống nghiệm → khi hợp tử có **4 hoặc 8 phôi bào** thì chuyển vào **buồng tử cung đã chuẩn bị** → phôi phát triển như thai thường.

> [!cap-nhat] IVF hiện nay
> Em bé IVF đầu tiên (Louise Brown) ra đời năm 1978; Robert Edwards nhận Nobel 2010. Hiện nay ngoài chuyển phôi ngày 2–3 (giai đoạn 4–8 phôi bào như giáo trình), nhiều trung tâm nuôi phôi đến **phôi nang ngày 5** rồi mới chuyển; với tinh trùng yếu thì **tiêm tinh trùng vào bào tương trứng** (ICSI).

## 4. Sự tái sinh

Cơ thể ở **"trạng thái động"**: có thể mất một phần và **tái sinh** lại. Tái sinh xảy ra ở mức **tế bào, mô, cơ quan** hoặc **cả cơ thể**. Ba mức độ:

| Mức độ | Định nghĩa | Ví dụ của sách | Bản chất |
|---|---|---|---|
| **Tái tạo sinh lý** | Bù lại tế bào, mô **già, chết** trong hoạt động **bình thường** | Mỗi tinh hoàn tạo khoảng **350 × 10^6^ tế bào/24 giờ**; khoảng **2,5 × 10^6^ hồng cầu/giây** được bổ sung; thượng bì da luôn thay mới | Tế bào gốc của mô liên tục phân chia |
| **Tái tạo khôi phục** (tu bổ) | Phục hồi mô, cơ quan **bị tổn thương** hoặc bị tách khỏi cơ thể | Thằn lằn mọc lại **đuôi**; lưỡng cư ***Ambystoma*** mọc lại **chi**; người: **liền xương**, **liền vết thương** | **Giải kìm hãm một phần** bộ gen bị ức chế |
| **Tạo phôi sinh dưỡng** | Một mảnh, thậm chí một tế bào sinh dưỡng tạo lại **cả cơ thể** | **Thủy tức, giun đất, đỉa**; rất phổ biến ở **thực vật** | Hoạt hóa lại **toàn bộ** bộ gen như hợp tử |

**Cơ chế tái tạo khôi phục:**

1. Tại chỗ tổn thương, tế bào được hoạt hóa, tạo **mầm gốc tái tạo**.
2. Tế bào được **giải biệt hóa** → trở nên **đa tiềm năng hơn** → phân chia tăng số lượng.
3. Đủ số lượng → tế bào **biệt hóa lại**, lặp lại cách bộ phận ấy hình thành trong phôi → tạo phần bị mất.
4. Trong quá trình tái tạo, **thần kinh đóng vai trò tổ chức**.

- Động vật **bậc thấp** tái tạo khôi phục mạnh; **động vật có vú, người** rất yếu, chỉ tái tạo được **một phần nhỏ** của cơ quan.
- Giáo trình (2008) nêu: chưa biết tác nhân nào thích hợp để đưa bộ gen trở lại trạng thái đa tiềm năng — đây là hướng hấp dẫn của **y học tương lai**. (Xem khung cập nhật về tế bào iPS ở mục 1.1.3.)

> [!bay]
> - Tái tạo **sinh lý** = thay mới **bình thường** (máu, da, tinh trùng). Tái tạo **khôi phục** = sửa chữa **sau tổn thương** (liền xương, vết thương).
> - Giáo trình xếp máu là "tổ chức dạng lỏng", nên tái tạo hồng cầu, bạch cầu là tái tạo **của tổ chức** (thuộc tái tạo sinh lý).
> - Tạo phôi sinh dưỡng = hoạt hóa **toàn bộ** bộ gen; tái tạo khôi phục = giải kìm hãm **một phần**.

> [!ung-dung] Gan người — "cơ quan tái tạo giỏi nhất"
> Gan là ngoại lệ đáng chú ý ở người: cắt bỏ tới khoảng 2/3 gan, phần còn lại có thể lớn lên bù lại khối lượng trong vài tuần (tế bào gan trở lại chu kỳ phân bào). Nhờ đó có thể **ghép gan từ người cho sống** (lấy một phần gan). Đây thực chất là phì đại bù trừ chứ không mọc lại đúng hình dạng thùy cũ.

## 5. Đa phôi

**Ở động vật** đẻ nhiều con một lứa (lợn, mèo): nhiều trứng rụng cùng lúc, mỗi trứng được thụ tinh → các cá thể **độc lập, di truyền khác nhau**.

**Ở người** thường đẻ một con, nhưng có thể **đa thai** (2, 3, 4, 5 con). Hai loại:

| | Đa thai **một hợp tử** (cùng trứng) | Đa thai **khác hợp tử** (khác trứng) |
|---|---|---|
| Nguồn gốc | **Một trứng + một tinh trùng** → phôi bào tách thành 2, 3, 4 khối ở giai đoạn đầu | **2, 3, 4 trứng** rụng cùng lúc, **mỗi trứng một tinh trùng** |
| Di truyền | **Giống nhau hoàn toàn** | Khác nhau như **anh chị em ruột** sinh khác năm |
| Giới tính | **Luôn cùng giới** | Có thể cùng hoặc khác giới |
| Cơ sở | Phôi người là **phôi điều hòa** (mục 1.1.2) | Rụng nhiều trứng (yếu tố gia đình, thuốc kích thích phóng noãn, IVF chuyển nhiều phôi) |

> [!vi-du] Tách lúc nào thì ra kiểu sinh đôi nào?
> Sinh đôi cùng trứng có thể tách ở nhiều thời điểm, không chỉ "giai đoạn phân cắt đầu" như sách ghi gọn:
> - Tách trong **3 ngày đầu** (giai đoạn vài phôi bào): mỗi thai có **bánh nhau và màng ối riêng**.
> - Tách khi đã là **phôi nang** (ngày 4–8, chia đôi khối tế bào trong): **chung bánh nhau**, màng ối riêng — kiểu hay gặp nhất.
> - Tách muộn hơn (ngày 8–13): chung cả bánh nhau và màng ối.
> - Tách **không hoàn toàn** sau đó: **sinh đôi dính nhau**.
> Hiện tượng đa thai sẽ học tiếp ở phần **Di truyền Y học**.

## Tóm tắt

| Chủ đề | Ý chính |
|---|---|
| Nguyên tắc chung | Phôi **tự điều khiển** theo chương trình trong bộ gen; mẹ/môi trường cung cấp dinh dưỡng, điều kiện |
| Bộ gen đơn bội trứng | Đủ thông tin cho một cơ thể (kích thích trứng ếch, cầu gai; đơn tính sinh) |
| Hợp tử lưỡng bội | Cần thiết: cặp alen tương tác → sức sống mạnh, biến dị tổ hợp |
| Giai đoạn phân cắt | Tế bào **đa tiềm năng**; chỉ gen phân bào hoạt động; dùng thông tin từ mẹ; nhân phôi nang thế vào hợp tử → bình thường |
| Trứng khảm / điều hòa | Thân mềm / ếch, cầu gai; tách dọc → điều hòa ra 2 cơ thể nhỏ; thắt ngang → dừng; vai trò tế bào chất |
| Từ phôi vị | Tiềm năng hạn chế; nhân phôi vị → dừng ở phôi nang; nhân lá phôi giữa → thần kinh, biểu bì không đủ; muộn hơn → không chia |
| Cảm ứng phôi | Một mô định hướng biệt hóa mô xung quanh; trung tâm tổ chức = **môi lưng** phôi vị ếch; ghép vào bụng → ếch 2 đầu |
| Tính chất tổ chức tố | Không đặc hiệu loài; một trung tâm → nhiều tổ chức tố (củng mạc → nhân mắt, giác mạc); càng biệt hóa càng giảm cảm ứng; liên quan nơi tạo hệ thần kinh |
| Chuỗi cảm ứng | Tinh trùng → cơ sở → sơ cấp → thứ cấp…; muộn: thay bằng thần kinh – nội tiết |
| Vững chắc tương đối | Đa số gen "đóng" nhưng còn nguyên; *Xenopus*, cừu Dolly |
| Nhân tố từ mẹ | Cảm ứng tố cơ sở, mARN đời sống dài, ribosom, ADN ty thể; la giống ngựa (mẹ), boocđô giống lừa (mẹ) |
| Operon (sách) | R, Pr, O, Ct; chất kìm hãm ở động vật đa bào là **histon** (từ phôi vị hóa); chất cảm ứng + histon → giải kìm hãm; định hướng (hóa sinh) → biệt hóa (hình thái) |
| Môi trường | Trứng gà 38 °C, trứng giun pH acid, nòng nọc cần thyroxin; nhạy cảm nhất: **tạo giao tử và phôi** |
| Quái thai — cơ chế | Rối loạn vật liệu di truyền; rối loạn phân bào; chết tế bào có định hướng |
| Giai đoạn nhạy cảm (bổ sung) | Tuần 1–2: tất cả hoặc không; **tuần 3–8**: dị tật lớn; tuần 9 → sinh: dị tật nhỏ, chức năng |
| Tác nhân (bổ sung) | Thalidomid, isotretinoin, warfarin, valproat (≈10% dị tật, 30–40% rối loạn phát triển thần kinh), ức chế men chuyển, methotrexat; rượu (FASD, không ngưỡng an toàn); rubella, CMV, Zika (tật đầu nhỏ, 2015–2016); tia xạ liều cao; thiếu acid folic (400 µg/ngày; 4 mg nếu từng có con dị tật ống thần kinh) |
| Nhãn thuốc thai kỳ (bổ sung) | FDA bỏ A/B/C/D/X theo PLLR (hiệu lực 30/6/2015) → mô tả bằng lời: 8.1 Mang thai, 8.2 Cho con bú, 8.3 Khả năng sinh sản |
| Thực nghiệm phôi | Chuyển nhân (Dolly 1996, nhân tuyến vú Finn Dorset ở G~0~); chuyển gen (3 cách); IVF chuyển phôi 4–8 phôi bào. Hiện nay: iPS (Nobel 2012), liệu pháp gen tế bào soma (Luxturna, Zolgensma, Casgevy), mô hình phôi từ tế bào gốc (ISSCR 2025 cấm chuyển vào tử cung) |
| Tái sinh | Sinh lý (máu, da, tinh trùng); khôi phục (giải kìm hãm một phần, thần kinh tổ chức); tạo phôi sinh dưỡng (hoạt hóa toàn bộ) |
| Đa thai | Một hợp tử: giống hệt, cùng giới; khác hợp tử: như anh chị em ruột |
