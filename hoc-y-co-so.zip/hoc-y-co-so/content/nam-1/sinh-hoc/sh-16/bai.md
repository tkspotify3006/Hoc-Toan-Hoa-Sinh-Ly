---
title: Tiến hóa của hệ thống sinh giới
thoi-gian: 55 phút
muc-tieu:
- Kể được 5 biểu hiện cho thấy toàn bộ sinh giới thống nhất về nguồn gốc.
- Nêu được các bậc phân loại (loài, dưới loài, trên loài) và cách sắp xếp sinh giới thành 2 trên giới, 5 giới.
- Viết đúng tên khoa học của một loài sinh vật và đọc được vị trí phân loại của loài đó.
- So sánh được đặc điểm nhân tế bào của Prokaryota và Eukaryota.
- Trình bày được các xu hướng tiến hóa của giới Thực vật (từ Tảo đến Hạt kín).
- Nêu được đặc điểm, phân loại các ngành chính của giới Động vật.
- Trình bày được sự tiến hóa của các hệ cơ quan ở động vật: tiêu hóa, bài tiết, tuần hoàn, hô hấp, thần kinh, nội tiết.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Mọi sinh vật **chung một nguồn gốc**, nên cùng có: cấu tạo tế bào, trao đổi chất, sinh trưởng–phát triển–sinh sản, cảm ứng, và **mã di truyền giống nhau** (tính vạn năng).
> 2. **Loài** là đơn vị cơ sở. Thang phân loại: Loài → Chi → Họ → Bộ → Lớp → Ngành → Giới → Trên giới. Giáo trình xếp sinh giới thành **2 trên giới, 5 giới**: Prokaryota (sinh vật nhân sơ; Monera) và Eukaryota (sinh vật nhân thực: Protista, Nấm, Thực vật, Động vật).
> 3. Tên khoa học viết bằng tiếng **La tinh**, kiểu **tên kép**: Chi viết hoa + loài viết thường, ví dụ *Homo sapiens*, *Mus musculus*.
> 4. **Prokaryota**: không màng nhân, 1 nhiễm sắc thể (NST, thường vòng), không histon, gen liên tục, có plasmid. **Eukaryota**: có màng nhân, nhiều NST hình sợi gắn histon, gen có **exon xen intron**, có ty thể (thực vật thêm lạp thể).
> 5. Tiến hóa = đi từ **chưa có → có, đơn giản → phức tạp**: thực vật từ nước lên cạn (mạch dẫn, hạt, hoa, thể 2n trội); động vật từ Thân lỗ đến Có xương sống — tim từ 2 ngăn (cá) → 3 ngăn (lưỡng cư) → 4 ngăn (chim, thú).

Bài này nối tiếp bài **Tiến hóa của chất sống** (các thuyết tiến hóa, nhân tố tiến hóa, cách ly sinh sản). Ở đây ta nhìn sinh giới "từ trên cao": các sinh vật thống nhất ra sao, được xếp vào hệ thống thế nào, và cơ thể chúng tiến hóa theo hướng nào.

> [!bay] Đoạn đầu trang 182
> Đoạn mở đầu trang 182 (giao phối được nhưng không thụ tinh, hoặc hợp tử chết, con lai bất thụ; *cách ly sinh sản kết thúc quá trình tiến hóa nhỏ, hình thành loài mới*) thuộc phần **cơ chế cách ly** của bài trước. Xem bài Tiến hóa của chất sống.

## 1. Tính thống nhất của hệ thống sinh giới

Mọi sinh vật đều bắt nguồn từ **một tổ tiên chung**. Từ các phân tử vô cơ và hữu cơ, mầm mống chất sống hình thành, rồi sinh ra những sinh vật đầu tiên. Qua thời gian rất dài, **phân ly tính trạng** dưới tác dụng của chọn lọc (tự nhiên và nhân tạo) làm tổ tiên ban đầu tách thành nhiều loài mới. Hai loài càng xa nhau về nguồn gốc thì càng khác nhau về hình thái, sinh lý.

Kết quả là sinh giới **vô cùng đa dạng** (về hình thái, sinh lý, sinh thái, sinh sản, di truyền…). Nhưng vì chung gốc, mọi sinh vật vẫn **thống nhất** ở 5 điểm:

| # | Biểu hiện thống nhất | Ý chính |
|---|---|---|
| 1 | **Cấu tạo bằng tế bào** | Từ đơn bào đến đa bào, tế bào là đơn vị **cấu trúc** và đơn vị **chức năng** |
| 2 | **Trao đổi chất** | Lấy chất từ môi trường, biến đổi nhờ **enzym đặc hiệu**; **đồng hóa** (hấp thụ để tạo nên cơ thể) và **dị hóa** (thải chất không dùng được); cung cấp năng lượng cho mọi hoạt động |
| 3 | **Sinh trưởng, phát triển, sinh sản** | Hợp tử → phôi → thai → cá thể non → trưởng thành → sinh dục. Nhờ sinh sản mà thể hiện được **di truyền và biến dị** |
| 4 | **Cảm ứng** | Trả lời kích thích bằng **phản ứng tức thời** (vận động, phản ứng hóa học, dòng điện sinh học…) hoặc bằng **thích nghi** khi kích thích kéo dài (thích nghi kiểu hình, hoặc thích nghi kiểu gen qua lịch sử) |
| 5 | **Mã di truyền giống nhau** | Một bộ ba mã hóa cùng một acid amin (amino acid) ở mọi sinh vật = **tính vạn năng** của mã di truyền |

*Vì sao* mã di truyền là bằng chứng mạnh nhất? Ba đặc điểm đầu có thể "tình cờ giống nhau" do cùng yêu cầu sống. Còn việc bộ ba nào ứng với acid amin nào phần lớn là ngẫu nhiên lịch sử. Mọi sinh vật cùng dùng một "bảng mã" chỉ có thể giải thích bằng **thừa hưởng từ tổ tiên chung**.

> [!ung-dung] Tính vạn năng của mã di truyền trong y học
> Vì vi khuẩn đọc gen người đúng như tế bào người, có thể đưa gen **insulin người** vào *E. coli* hoặc nấm men để sản xuất insulin tái tổ hợp. Vaccin viêm gan B tái tổ hợp cũng làm theo nguyên lý này. (Mã di truyền có vài ngoại lệ nhỏ, ví dụ trong ty thể; xem phần di truyền.)

## 2. Các đơn vị phân loại và hệ thống sinh giới

### 2.1. Loài (species)

**Loài là đơn vị cơ sở của phân loại.** Theo giáo trình, loài là nhóm cá thể:

- giống nhau về **cấu tạo, hình thái, sinh lý**;
- có **chung nguồn gốc**;
- **giao phối được với nhau** (và sinh con hữu thụ — chính là tiêu chuẩn cách ly sinh sản ở bài trước).

Ví dụ: loài chuột nhắt, loài chuột cống, loài lúa tẻ, loài người.

### 2.2. Đơn vị dưới loài

**Phân loài** (subspecies), **thứ** (varietas), **chủng**. Chúng chỉ khác nhau chút ít, giữa chúng còn **các dạng trung gian**, nên nhiều khi rất khó phân biệt.

> [!vi-du] Chủng trong y học
> Vi sinh vật học dùng "chủng" rất nhiều: chủng *E. coli* O157:H7 gây tiêu chảy xuất huyết, chủng *Staphylococcus aureus* kháng methicillin (MRSA). Cùng một loài, nhưng khác chủng thì độc lực và độ nhạy kháng sinh có thể rất khác.

### 2.3. Đơn vị trên loài

Các bậc xếp lồng nhau, mỗi bậc gồm nhiều đơn vị gần nhau của bậc dưới:

=> Loài → Chi → Họ → Bộ → Lớp → Ngành → Giới → Trên giới

- **Chi** (genus) trước đây gọi là **giống**: gồm nhiều loài giống nhau nhiều, có tổ tiên chung.
- Nhiều chi gần nhau → **Họ**; nhiều họ → **Bộ**; nhiều bộ → **Lớp**; nhiều lớp → **Ngành**; nhiều ngành → **Giới**; trên Giới là **Trên giới**.
- **Đơn vị phụ**: thêm tiền tố **phân / phụ** (sub-) để chỉ bậc ngay dưới (phân loài, phân chi, phân ngành); thêm **trên / liên** (super-) để chỉ bậc ngay trên (liên họ, liên lớp).

> [!bay]
> - Sơ đồ trong giáo trình ghi "Loài → Giống → Chi → …". **Giống và chi là một bậc** (giống là tên cũ của chi), không phải hai bậc khác nhau.
> - Thứ tự hay bị đảo: **Bộ nằm dưới Lớp** (Bộ Linh trưởng thuộc Lớp Có vú), **Họ nằm dưới Bộ** (họ Người thuộc bộ Linh trưởng). Mẹo nhớ từ lớn đến nhỏ: **Giới – Ngành – Lớp – Bộ – Họ – Chi – Loài**.

### 2.4. Phân loại hệ thống sinh giới (theo giáo trình)

| Trên giới | Giới | Đặc điểm chính |
|---|---|---|
| **Prokaryota** (nhân sơ) | **Monera** | Giáo trình xếp vào đây: virus, vi khuẩn, vi khuẩn lam |
| **Eukaryota** (nhân chuẩn) | **Protista** | Đơn bào hoặc tập đoàn đa bào đơn giản |
| | **Nấm** | Không diệp lục, dị dưỡng, hấp thụ |
| | **Thực vật** | Đa bào, có diệp lục, tự dưỡng |
| | **Động vật** | Đa bào, dị dưỡng, phần lớn di chuyển được |

![Hình 1. Hệ thống 5 giới của giáo trình và cây phát sinh 3 lĩnh vực hiện nay](cay-phat-sinh.svg)

> [!cap-nhat] Hệ thống 3 lĩnh vực (domain)
> **Giáo trình ghi**: 2 trên giới, 5 giới; Prokaryota gồm virus, vi khuẩn, vi khuẩn lam.
>
> **Hiện nay**: từ phân tích trình tự **ARN (RNA) ribosom 16S/18S**, Carl Woese phát hiện nhóm **Archaea** (1977) và đề xuất (1990) chia sinh giới thành **3 lĩnh vực**:
> - **Bacteria** (vi khuẩn thật, gồm cả vi khuẩn lam);
> - **Archaea** (vi khuẩn cổ, nhiều loài sống ở suối nóng, hồ muối, ruột động vật; có loài sinh methan);
> - **Eukarya** (mọi sinh vật nhân chuẩn).
>
> Archaea trông giống vi khuẩn (không có nhân) nhưng về phân tử (ARN polymerase, có protein giống histon, màng lipid ether) lại **gần Eukarya hơn** Bacteria. Vì vậy "Prokaryota" chỉ còn là một kiểu tổ chức tế bào, **không phải một nhóm có chung nguồn gốc riêng**. Giới "Protista" cũng không còn được xem là một nhóm tự nhiên.
>
> **Virus không thuộc lĩnh vực nào**: virus không có cấu tạo tế bào, không tự trao đổi chất, nên không xếp vào cây sự sống của tế bào.
>
> **Quan điểm mới hơn: cây "hai lĩnh vực"** (bổ sung – kiến thức hiện nay). Từ năm 2015, giải trình tự ADN (DNA) môi trường phát hiện nhóm **Asgard archaea** mang nhiều gen trước đây tưởng chỉ có ở nhân thực (actin, protein vận chuyển màng…). Phân tích hệ gen năm 2023 (*Nature*) xếp **Eukarya nằm bên trong Archaea** (gần nhánh Heimdallarchaeia của Asgard). Nghĩa là tế bào nhân thực sinh ra từ sự **hợp nhất** giữa một vi khuẩn cổ Asgard (tế bào chủ) và một vi khuẩn α-proteobacteria (thành ty thể). Vì vậy nhiều nhà sinh học hiện nay nói chỉ có **2 lĩnh vực sơ cấp: Bacteria và Archaea**, Eukarya là một nhánh "lai" mọc ra từ Archaea. Hệ 3 lĩnh vực vẫn được dùng phổ biến trong sách giáo khoa như một cách sắp xếp tiện dụng.
>
> Đi thi: trả lời theo giáo trình (2 trên giới, 5 giới).

## 3. Cách viết tên khoa học của một loài

Tên khoa học viết bằng **chữ La tinh**, theo **danh pháp kép** (của Linné):

1. **Tên Chi** (viết **hoa** chữ đầu) + **tên loài** (viết **thường**). Ví dụ chuột nhắt trắng: *Mus musculus*.
2. Có **phân chi**: tên chi (hoa) + **(tên phân chi)** (hoa, trong ngoặc đơn) + tên loài (thường). Ví dụ muỗi truyền sốt xuất huyết: *Aedes (Stegomyia) aegypti*.
3. Có thể ghi thêm **tên người đặt tên** (viết tắt hoặc đầy đủ) và **năm** công bố. Ví dụ lúa tẻ *Oryza sativa* L. (L., giáo trình ghi "Linn", là viết tắt của Linné); muỗi *Anopheles tonkinensis* Galliard, Ngữ, 1941.

Quy ước in ấn hiện nay: tên chi và tên loài **in nghiêng** (viết tay thì gạch dưới); tên tác giả **không** in nghiêng.

> [!bay]
> - Tên loài **không bao giờ viết hoa**, kể cả khi đặt theo tên người hay địa danh: *tonkinensis* (Bắc Kỳ), *aegypti*.
> - Chỉ viết tên loài một mình ("sapiens") là **sai**; tên loài luôn đi kèm tên chi. Lần nhắc sau có thể viết tắt chi: *E. coli*, *H. sapiens*.
> - Giáo trình in nhầm vài chữ: "aegypty" → đúng là *aegypti*; "Ozyza" → *Oryza*; "Homonidae" → **Hominidae**.

**Tên khoa học cho biết vị trí trong hệ thống.** Ba ví dụ của giáo trình:

| Bậc | Người | Muỗi sốt rét | Lúa tẻ |
|---|---|---|---|
| Trên giới | Eukaryota | Eukaryota | Eukaryota |
| Giới | Động vật (Animalia) | Động vật | Thực vật |
| Ngành | Dây sống (Chordata) | Tiết túc (Arthropoda) | Hạt kín |
| Phân ngành | Có xương sống (Vertebrata) | — | — |
| Lớp | Có vú (Mammalia) | Côn trùng (Insecta) | Một lá mầm (Monocotyledonae) |
| Phân lớp | Có rau (Placentalia) | — | — |
| Bộ | Linh trưởng (Primates) | Hai cánh (Diptera) | Hòa thảo (Graminales) |
| Họ | Người (Hominidae) | Muỗi (Culicidae); phân họ Anophelinae | Hòa thảo (Gramineae) |
| Chi | *Homo* | *Anopheles*, phân chi *Myzomyia* | *Oryza* |
| Loài | *sapiens* | *minimus* | *sativa* |

![Hình 2. Các bậc phân loại lồng nhau — ví dụ loài người](bac-phan-loai.svg)

> [!ung-dung] Vì sao bác sĩ phải đọc đúng tên khoa học
> - *Anopheles minimus* là một trong những véc-tơ chính truyền **sốt rét** ở vùng rừng núi Việt Nam; *Aedes aegypti* truyền **sốt xuất huyết Dengue**, Zika, sốt vàng. Biết đúng loài muỗi mới chọn đúng biện pháp phòng (giờ đốt, nơi đẻ trứng khác nhau).
> - Kết quả cấy vi sinh luôn ghi tên khoa học (*Klebsiella pneumoniae*, *Candida albicans*…). Hai loài cùng chi có thể nhạy kháng sinh/kháng nấm rất khác nhau.

> [!yhct] Tên khoa học giúp tránh nhầm dược liệu
> Tên Việt/Hán của vị thuốc thường trùng nhau giữa nhiều loài (ví dụ "Phòng kỷ" có thể là *Stephania tetrandra* hoặc *Aristolochia fangchi*; loài *Aristolochia* chứa acid aristolochic độc cho thận), nên dược điển luôn ghi kèm **tên La tinh** và kiểm nghiệm dược liệu bắt đầu từ việc xác định đúng loài (xem bài *Đột biến*, mã sh-10).

> [!cap-nhat] Chi *Homo* không chỉ có loài người hiện đại (bổ sung – kiến thức hiện nay)
> Giáo trình chỉ nêu *Homo sapiens*. Các nghiên cứu hóa thạch và ADN cổ (đồng thuận rộng) cho thấy:
> - **Tuổi loài người hiện đại**: hóa thạch ở **Jebel Irhoud** (Morocco), định tuổi lại năm 2017 (*Nature*), khoảng **300.000 năm** (≈ 315.000 năm), là hóa thạch *H. sapiens* cổ nhất đã biết; trước đó người ta thường nói khoảng 200.000 năm (hóa thạch Omo, Ethiopia). Phát hiện này ủng hộ ý *H. sapiens* hình thành **trên khắp châu Phi**, không chỉ ở Đông Phi.
> - Chi *Homo* từng có nhiều loài, một số **sống cùng thời** với *H. sapiens*:
>   - **Người Neanderthal** (*H. neanderthalensis*, châu Âu – Tây Á, tuyệt chủng ≈ 40.000 năm trước). Người hiện đại ngoài châu Phi mang khoảng **1–2% ADN Neanderthal** do **lai giống**; hai nghiên cứu năm 2024 (*Nature*, *Science*) cho thấy phần lớn sự lai giống này diễn ra trong một giai đoạn kéo dài vài nghìn năm, khoảng **47.000 năm trước**. Một số biến thể gốc Neanderthal liên quan đến miễn dịch, chuyển hóa và cả nguy cơ COVID-19 nặng.
>   - **Người Denisova**: xác định chủ yếu nhờ **giải trình tự ADN** từ một đốt ngón tay ở hang Denisova (Siberia, công bố 2010). Năm 2025, phân tích protein và ADN ty thể từ cao răng xác định **hộp sọ Cáp Nhĩ Tân** (Trung Quốc, ≥ 146.000 năm tuổi) là của người Denisova (*Science*, *Cell*) — lần đầu biết được hình dạng hộp sọ của nhóm này. Người Melanesia, Papua mang một tỷ lệ ADN Denisova đáng kể (vài phần trăm); một biến thể gen *EPAS1* giúp người Tây Tạng thích nghi độ cao có nguồn gốc Denisova.
>   - ***H. floresiensis*** (đảo Flores, Indonesia; cao khoảng 1 m, não nhỏ, còn sống tới khoảng 50.000 năm trước), ***H. luzonensis*** (hang Callao, đảo Luzon, Philippines; công bố 2019, ≈ 50.000–67.000 năm) và ***H. naledi*** (Nam Phi; não nhỏ, sống khoảng 335.000–236.000 năm trước).
> - **Svante Pääbo** nhận **giải Nobel Sinh lý học hoặc Y học 2022** vì giải trình tự hệ gen Neanderthal, phát hiện người Denisova và mở ra ngành **di truyền học cổ** (paleogenomics).
> - Phân loại hiện nay: **họ Người (Hominidae)** gồm cả các loài **vượn lớn** (đười ươi, gorilla, tinh tinh) cùng người; người và họ hàng gần đã tuyệt chủng được xếp vào **tông Hominini**. Tinh tinh là loài còn sống gần người nhất.
>
> Nghĩa là: *H. sapiens* hiện là loài người **duy nhất còn sống**, nhưng không phải lúc nào cũng vậy. Phần này không có trong giáo trình.

## 4. Đặc điểm nhân tế bào Prokaryota và Eukaryota

### 4.1. Trên giới Prokaryota

Giáo trình gọi Prokaryota là sinh vật có **nhân thô sơ (nhân sơ)**, gồm vi khuẩn (kể cả **vi khuẩn lam**, tên cũ *tảo lam* — Cyanophyta) và virus. Đặc điểm "nhân":

- **Đơn bội**: chỉ có **1 NST duy nhất** (giáo trình vẫn gọi virus là "cơ thể", dù virus ký sinh bắt buộc).
- NST **hình vòng hoặc hình sợi**.
- Thành phần hóa học rất đa dạng:

| Loại acid nucleic | Ví dụ (giáo trình) |
|---|---|
| ADN sợi kép | Vi khuẩn *E. coli*, virus polyoma, phage T4 |
| ADN sợi đơn | Phage ΦX174 |
| ARN sợi kép | Reovirus |
| ARN sợi đơn | Virus cúm (influenza), virus khảm thuốc lá |

- ADN/ARN **không gắn histon** (một số gắn protein khác, chưa giống histon).
- Nhiều vi khuẩn có thêm **plasmid**: ADN nhỏ ngoài NST, mang gen **không cần cho sinh trưởng** nhưng giúp **kháng kháng sinh, kháng chất độc** và một số tính trạng khác.
- **Không có màng nhân** ngăn với tế bào chất.
- Gen **liên tục**, không có exon–intron (rất hiếm ngoại lệ).

> [!ung-dung] Plasmid và kháng kháng sinh
> Plasmid có thể **truyền ngang** giữa các vi khuẩn (kể cả khác loài) qua tiếp hợp. Đó là lý do gen kháng kháng sinh (ví dụ gen tạo **β-lactamase phổ rộng – ESBL**, carbapenemase) lan rất nhanh trong bệnh viện. Dùng kháng sinh bừa bãi tạo áp lực chọn lọc giữ lại các vi khuẩn mang plasmid kháng thuốc.

### 4.2. Trên giới Eukaryota

Eukaryota là sinh vật có **nhân chuẩn**: động vật, nấm, thực vật (cả tảo). Giáo trình gọi chung là sinh vật bậc cao. Đặc điểm nhân:

- Tế bào cơ thể thường **lưỡng bội (2n)** (trừ một số nấm, tảo, rêu có cơ thể chính đơn bội).
- Mỗi nhân có **nhiều cặp NST** (giáo trình: ít nhất 2 cặp).
- NST **hình sợi** (không vòng).
- NST gồm **ADN sợi kép gắn histon** và protein không histon.
- Gen **phân mảnh**: **exon** (đoạn mã hóa) xen kẽ **intron** (đoạn không mã hóa). Intron được phiên mã vào **mARN tiền thân** rồi bị **cắt bỏ** khi tạo mARN trưởng thành.
- Có **màng nhân** ngăn nhân với tế bào chất.
- Có **ty thể**, thực vật còn có **lạp thể**; cả hai chứa **ADN vòng riêng**, mã hóa một số protein của chính bào quan đó.

| Đặc điểm | Prokaryota | Eukaryota |
|---|---|---|
| Màng nhân | **Không** | **Có** |
| Số NST | 1 | Nhiều cặp |
| Hình NST | Vòng (hoặc sợi) | Sợi |
| Bộ NST | Đơn bội (n) | Thường lưỡng bội (2n) |
| Protein histon | Không | Có |
| Cấu trúc gen | Liên tục | Exon xen intron |
| ADN ngoài nhân | Plasmid | ADN ty thể, lạp thể |
| Ty thể, lạp thể | Không | Có |

*Vì sao* ty thể và lạp thể có ADN vòng riêng? Theo **thuyết nội cộng sinh**, chúng vốn là **vi khuẩn sống cộng sinh** trong tế bào nhân chuẩn nguyên thủy. ADN vòng, ribosom loại 70S của chúng là "dấu vết" tổ tiên vi khuẩn.

> [!bay]
> - Prokaryota **không có nhân thật**; vùng chứa ADN gọi là **vùng nhân** (nucleoid). Khi giáo trình nói "nhân đơn bội" của Prokaryota là nói vùng nhân.
> - "Eukaryota luôn lưỡng bội" là **sai**: rêu, nhiều tảo, nhiều nấm sống chủ yếu ở dạng đơn bội.
> - Câu "ít nhất 2 cặp NST" là theo giáo trình. Thực tế có ngoại lệ hiếm: giun đũa ngựa *Parascaris univalens* chỉ có 2n = 2.

## 5. Một số ngành thuộc Prokaryota

### 5.1. Ngành Virus

- Kích thước **siêu hiển vi**, **ký sinh bắt buộc** trong tế bào chủ (vi khuẩn, thực vật, động vật, người).
- Hình **cầu, que, khối** (khối đa diện).
- Cấu tạo rất đơn giản: **acid nucleic (ADN hoặc ARN)** + **vỏ protein**; có loại virus **trần** (không có vỏ ngoài).
- **Thể thực khuẩn** (bacteriophage, phage) ký sinh trong vi khuẩn, hình **nòng nọc**: đầu nhiều cạnh hoặc hình cầu, đuôi hình trụ có bao đuôi, cuối đuôi có **đĩa gốc**.

> [!cap-nhat] Virus có phải Prokaryota?
> **Giáo trình** xếp virus vào Prokaryota. **Hiện nay** virus **không** được xem là sinh vật nhân sơ, vì virus **không có cấu tạo tế bào** (không màng sinh chất, không ribosom, không tự trao đổi chất). Mỗi hạt virus chỉ chứa **một loại** acid nucleic (ADN *hoặc* ARN), trong khi mọi tế bào đều chứa cả hai. Đi thi trả lời theo giáo trình.
>
> **Phân loại virus hiện nay** do **Ủy ban Quốc tế về Phân loại Virus (ICTV)** quy định, tách riêng khỏi hệ thống phân loại sinh vật tế bào:
> - Từ năm 2019–2020, ICTV dùng hệ thống nhiều bậc giống sinh vật, bậc cao nhất là **"realm" (lĩnh vực virus)**, ví dụ *Riboviria* gồm phần lớn virus ARN (virus cúm, corona, HIV…). Theo bản phân loại năm 2025 có khoảng **10 realm** và hơn **16.000 loài virus**.
> - Từ năm 2021, tên **loài virus** phải viết theo **danh pháp kép** như sinh vật: ví dụ loài chứa SARS-CoV-2 nay có tên *Betacoronavirus pandemicum*. Cần phân biệt **tên loài** (đơn vị phân loại, in nghiêng) với **tên virus** dùng hằng ngày (SARS-CoV-2, virus sởi…).
> - Việc phân loại virus dựa chủ yếu vào **trình tự gen** và cấu trúc protein vỏ, không dựa vào bệnh mà virus gây ra.

### 5.2. Ngành Vi khuẩn (Bacteriophyta)

- Cơ thể đơn giản, **không diệp lục**, chưa có nhân điển hình; phần lớn **đơn bào**, vài loài sống thành tập đoàn đặc trưng.
- Sống **hoại sinh, ký sinh** hoặc cả hai; một số **tự dưỡng**.
- Màng sinh chất bao tế bào chất; ngoài màng là **vỏ dày** (thành tế bào).
- NST = **1 phân tử ADN sợi kép, vòng**, nằm ở vùng nhân; vùng nhân thường gắn với chỗ lõm của màng sinh chất gọi là **mesosom** (theo giáo trình; hiện nay mesosom được cho là **ảnh giả** do kỹ thuật cố định mẫu khi làm tiêu bản hiển vi điện tử).
- Đơn bội; có thêm **plasmid**. Một số di động nhờ **roi**.
- Sinh sản chủ yếu **vô tính** (phân đôi); sinh sản hữu tính chỉ gặp ở số ít, chưa điển hình.

> [!ung-dung] Thành tế bào vi khuẩn — đích của kháng sinh
> Tế bào người **không có thành tế bào**, nên kháng sinh nhóm **β-lactam** (penicillin, cephalosporin) ức chế tổng hợp thành vi khuẩn mà ít độc với người. Ribosom 70S của vi khuẩn khác ribosom 80S của người là cơ sở cho kháng sinh nhóm aminoglycosid, macrolid, tetracyclin.

### 5.3. Ngành Vi khuẩn lam (Cyanophyta)

- Dạng **tản**, đơn bào hoặc đa bào **dạng sợi chuỗi**; sống tự do trong nước, nơi ẩm; có loài sống trong tế bào thực vật.
- Có **sắc tố lam**, **tự dưỡng** (quang hợp, thải oxy).
- Chưa có màng nhân; tế bào đơn bội, NST là **ADN sợi kép vòng**.

*Vì sao* "tảo lam" được đổi thành "vi khuẩn lam"? Vì tế bào của chúng là tế bào **nhân sơ**, cùng kiểu với vi khuẩn, dù quang hợp giống tảo. Lục lạp của thực vật chính là hậu duệ của một vi khuẩn lam nội cộng sinh.

## 6. Giới Protista và giới Nấm

### 6.1. Giới Protista

Gồm sinh vật **đơn bào** hoặc **tập đoàn đa bào đơn giản**. Theo **phương thức sống**, chia 3 nhóm:

| Nhóm | Đặc điểm | Ví dụ |
|---|---|---|
| **Protista Thực vật** | Tảo đơn bào, có **diệp lục a, b hoặc c** + sắc tố khác → **tự dưỡng**, quang hợp, thải O~2~; nước ngọt và mặn; di động bằng roi hoặc lông | Tảo silic, tảo vàng, tảo giáp |
| **Protista Nấm** | Nhóm "kỳ lạ nhất": đơn bào nhưng sống thành **đám nhầy** đỏ, vàng, trắng; dị dưỡng từ chất hữu cơ; **vận động kiểu amip**; ở nơi ẩm, xác sinh vật phân hủy | Nấm nước, nấm nhầy |
| **Protista Động vật** (động vật nguyên sinh) | Một tế bào (đôi khi tập đoàn) nhưng có đủ biểu hiện của một cơ thể nhờ **bào quan phân hóa cao**; sống ở biển, nước ngọt hoặc ký sinh | Lớp **Chân giả** (Sarcodina): amip. Lớp **Bào tử trùng** (Sporozoa): hoàn toàn ký sinh, **không có cơ quan di động**, có giai đoạn tạo bào tử — **ký sinh trùng sốt rét** |

> [!ung-dung] Protista gây bệnh
> - *Plasmodium* (Bào tử trùng) gây **sốt rét**, truyền qua muỗi *Anopheles* — nối với ví dụ tên khoa học ở mục 3.
> - *Entamoeba histolytica* (Chân giả) gây **lỵ amip**, áp xe gan amip.
> - Thuốc điều trị sốt rét **artemisinin** chiết từ cây **Thanh hao hoa vàng** (*Artemisia annua*) — công trình được giải Nobel Y học 2015 (Đồ U U).

### 6.2. Giới Nấm (Fungi)

- Tế bào **không diệp lục** → **dị dưỡng**: **ký sinh** trên sinh vật khác, hoặc **hoại sinh** nhờ tiết enzym phân hủy chất hữu cơ phức tạp (xác động, thực vật) thành chất đơn giản rồi **hấp thụ**.
- Cơ quan dinh dưỡng phần lớn là **sợi nấm** phân nhánh nhiều; số ít có tế bào hình tròn, bầu dục (**nấm men**).
- Sợi nấm **không vách ngăn** (mốc trắng *Mucor*) hoặc **có vách ngăn** (mốc xanh *Penicillium*). Ở nấm bậc cao, sợi kết chặt thành **mô giả**.
- Thành tế bào: giáo trình ghi bằng cellulose, pectin; nấm bậc cao có thêm **kitin**. Màu sắc do sắc tố là sản phẩm tế bào.
- Nhân **rất nhỏ** nhưng là **nhân điển hình** (có màng nhân).
- Sinh sản: **sinh dưỡng**, **vô tính bằng bào tử**, hoặc **hữu tính**.

> [!cap-nhat] Thành tế bào nấm
> Giáo trình ghi thành tế bào nấm bằng cellulose, pectin, nấm bậc cao thấm thêm kitin. Hiện nay, thành phần đặc trưng của thành nấm thật là **kitin** và **glucan**; các "nấm" có thành cellulose (nấm nước – Oomycetes) đã được tách khỏi giới Nấm. Phân tích phân tử còn cho thấy nấm có họ hàng **gần động vật hơn thực vật** (cùng nhóm Opisthokonta) — một lý do khiến thuốc kháng nấm dễ có độc tính với tế bào người hơn so với kháng sinh với vi khuẩn. Vì người không có kitin/glucan, đây là đích của thuốc kháng nấm nhóm **echinocandin** (ức chế tổng hợp β-glucan). Còn **azol** và **amphotericin B** nhắm vào **ergosterol** của màng nấm (người dùng cholesterol).

> [!ung-dung] Nấm và y học
> - *Penicillium* cho **penicillin** (Fleming, 1928).
> - *Aspergillus flavus* sinh **aflatoxin** trong lạc, ngô mốc — chất gây **ung thư gan** mạnh. *Aspergillus fumigatus* gây nhiễm nấm phổi ở người suy giảm miễn dịch.
> - Nấm men *Candida albicans* gây tưa miệng, viêm âm đạo.

## 7. Giới Thực vật — các ngành và sự tiến hóa

### 7.1. Đặc điểm các ngành

| Ngành | Cơ thể | Mạch dẫn | Sinh sản, vòng đời | Ghi nhớ |
|---|---|---|---|---|
| **Tảo** (Algae) | **Tản**, chưa có thân, lá, rễ | Chưa có | Vô tính; hữu tính **đẳng giao, dị giao, noãn giao, tiếp hợp** | Chia ngành theo **sắc tố**: tảo lục, nâu, đỏ |
| **Rêu** (Bryophyta) | **Chồi giả** (thân, lá, rễ giả); có lục lạp | **Chưa có** → chỉ sống nơi ẩm | Xen kẽ thể giao tử **1n** và thể bào tử **2n**; **thể 1n chiếm ưu thế** | **Trung gian** giữa Tảo và thực vật có mạch |
| **Quyết thực vật** (Pterophyta) | Thân, lá, **rễ thật**; lá to | **Có**, mạch kép: **gỗ** (đi lên) và **libe** (đi xuống) | Thể 1n (nguyên tản) sống ngắn; **thể 2n là dạng sống chính** | 4 lớp: Khỏa quyết, Thạch tùng, Mộc tặc, **Dương xỉ** |
| **Hạt trần** (Gymnospermae) | Cây gỗ; lá **hình kim, mác** (chịu hạn) | **Quản bào** (bị vách ngang chia đốt) | **Nón** đực (hạt phấn), nón cái (trứng); **thụ tinh không cần nước**; hạt nằm **hở** trên lá noãn | Điển hình: lớp **Thông** |
| **Hạt kín** (Angiospermae) | Thân, lá, rễ đa dạng; ~**250.000 loài** | **Hoàn thiện nhất** | **Hoa** có **nhụy** (đầu, vòi, bầu) bao kín noãn; **thụ tinh kép**; bầu → **quả**, noãn → hạt | Ngành tiến hóa nhất |

> [!bay]
> - Điểm **căn bản** phân biệt Hạt kín với Hạt trần: **noãn nằm kín trong bầu nhụy** (lá noãn khép kín) → hạt nằm trong **quả**. Hạt trần cũng **có hạt có vỏ**, nhưng hạt nằm **hở** trên lá noãn.
> - Rêu có "thân, lá" nhưng là **giả**, vì **không có mạch dẫn**. Ngành đầu tiên có rễ thật và mạch dẫn là **Quyết thực vật**.
> - Số hạt trong quả **tương đương số noãn** trong bầu.

### 7.2. Các xu hướng tiến hóa của giới Thực vật

**a) Hình thái, cấu tạo thích nghi với môi trường**

- **Dưới nước** → **dạng tản** (Tảo): toàn thân tiếp xúc nước, hút chất qua toàn bộ bề mặt, không cần mạch dẫn.
- **Lên cạn** → xuất hiện **chồi** (thân, lá, rễ có mạch dẫn bên trong):
  - Rêu: **chồi giả**, chưa có mạch → phải sống nơi ẩm.
  - Dương xỉ: **chồi thật**. Bào tử nảy mầm thành **nguyên tản** (rễ giả, phải ở nơi ẩm); sau thụ tinh, hợp tử mọc thành cây có mạch dẫn → **từ đây thực vật mới thật sự sống được trên cạn**.
  - Hạt trần: **quản bào**, thông suốt hơn Dương xỉ nhưng chưa hoàn thiện.
  - Hạt kín: mạch dẫn **tiến hóa cao nhất**.

**Vì sao mạch gỗ có "hoa vân"?** Mạch gỗ đưa nước **ngược chiều trọng lực**, nên phải thỏa hai yêu cầu: (1) **lòng mạch thông suốt** — vách ngăn giữa các tế bào xếp nối tiếp tiêu biến; (2) **thành mạch không nhẵn** — có các gờ dày lên như "tay vịn" giữ cột nước. Hạt kín có đủ kiểu: **mạch vòng, mạch xoắn, mạch thang, mạch điểm, mạch mạng**.

**Mạch libe** chuyển chất dinh dưỡng chủ yếu **cùng chiều trọng lực**, nên yêu cầu ngược lại: lòng mạch thoáng nhưng không quá thoáng → vách ngang **thủng lỗ như cái rây** = **mạch rây**.

- **Thân, lá chịu hạn**: lá **hình kim** (thông) giữ diện tích hứng sáng nhưng giảm thoát hơi nước; lá mọng nước (cây lá bỏng), thân mọng nước (xương rồng).
- **Hình thức thụ tinh**: Tảo, Rêu, Dương xỉ có **tinh trùng có roi bơi trong nước** đến noãn cầu → phụ thuộc nước. Từ Hạt trần, **hạt phấn không roi**, đến noãn nhờ **gió, côn trùng** → thoát khỏi phụ thuộc nước.

**b) Từ sinh sản vô tính đến hữu tính và lưỡng bội hóa**

Muốn sinh sản hữu tính thì phải có giai đoạn **lưỡng bội**. Xu hướng: **thể 2n ngày càng chiếm ưu thế**.

| Nhóm | Dạng sống chính | Diễn biến |
|---|---|---|
| Tảo | Hầu hết **1n** | Sinh sản bằng bào tử 1n hoặc đoạn tản; hữu tính tạo hợp tử 2n |
| Rêu | **1n** chiếm ưu thế | Hợp tử 2n **ký sinh trên cây rêu cái 1n**, mọc thành thể mang túi bào tử 2n → giảm phân → bào tử 1n → **nguyên ty** → cây rêu mới. Lưỡng bội hóa mới "mở màn" |
| Dương xỉ | **2n** chiếm tuyệt đại đa số vòng đời | Hợp tử 2n ký sinh **tạm thời** trên nguyên tản 1n → cây non 2n → cây trưởng thành 2n → túi bào tử ở mặt dưới lá → bào tử 1n → nguyên tản 1n |
| Hạt trần, Hạt kín | **2n** ưu thế tuyệt đối | Kèm theo thích nghi nhiều mặt với điều kiện sống |

*Vì sao 2n có lợi?* Cơ thể 2n có **hai bản sao** mỗi gen: một alen hỏng có thể được alen kia "che" đi, và cơ thể biểu hiện được **tác động phối hợp của từng cặp alen**. Điều này giúp sinh vật chịu được đột biến và tích lũy biến dị.

**c) Kết hợp hai nguồn gen bằng giao phấn**

Sinh sản hữu tính chỉ thật sự có giá trị khi **hai bộ gen khác nguồn** kết hợp → tổ hợp lại phong phú. Thực vật giải quyết bằng **giao phấn**, thể hiện qua hoa: **cấu tạo, số lượng nhị và nhụy**, tổ chức thành **cụm hoa (hoa tự)**, **màu sắc** hoa, **thời gian chín lệch nhau** giữa nhị và nhụy (để tránh tự thụ).

**d) Hoàn thiện cơ quan sinh sản cái để bảo vệ noãn và phôi**

Lúc đầu chưa có gì bảo vệ noãn và phôi → thụ tinh **trong túi** → túi trứng **kín** dần → Hạt trần: **lá noãn** mang noãn nhưng hạt chưa được bọc kín → Hạt kín: lá noãn **khép kín** che noãn, hạt được bảo vệ **trong quả**.

## 8. Giới Động vật — các ngành chính

### 8.1. Bảng tổng hợp

| Ngành | Đặc điểm nổi bật | Phân loại / ví dụ |
|---|---|---|
| **Thân lỗ** (Porifera) | Tổ chức **thấp nhất**; 2 lớp tế bào bao quanh một xoang; tế bào còn **hoạt động riêng rẽ** | Toàn bộ sống ở **biển** (bọt biển) |
| **Ruột túi** (Coelenterata) | Như trên: 2 lớp tế bào, tổ chức thấp | Lớp **Thủy tức** (nước ngọt); lớp **Sứa**, lớp **San hô** (biển; san hô sống tập đoàn) |
| **Giun dẹp** (Plathelminthes) | **Đối xứng hai bên**; dẹp lưng–bụng, hình lá hoặc dải; thành cơ thể **3 lớp tế bào**, bước đầu phân hóa cơ quan; thường **lưỡng tính**, **thụ tinh chéo** | 3 lớp: **Sán tiêm mao** (tự do, có lông); **Sán lá** (ký sinh, hình lá, không đốt, cơ quan bám phát triển, qua 1–3 vật chủ trung gian); **Sán dây** (ký sinh, có đốt: **đầu** – bám bằng giác, móc; **cổ** – sinh ra đốt; **thân** – nhiều đốt) |
| **Giun tròn** (Nemathelminthes) | **Hình trụ**, thon hai đầu; **không chia đốt**; tinh trùng **không đuôi**; có **xoang cơ thể nguyên sinh** (chưa có biểu mô bao); đa số **đơn tính**, phân biệt đực cái bằng hình dạng | 5 lớp; lớp **Nematoda** gồm giun ký sinh người: **giun đũa, giun tóc, giun móc, giun kim** |
| **Giun đốt** (Annelida) | **Chia đốt**, có **xoang cơ thể chính thức**; tổ chức cao | 3 lớp: **Giun nhiều tơ** (biển; rươi); **Giun ít tơ** (giun đất); **Đỉa** (không lông, giác bám phát triển) |
| **Tiết túc** (Arthropoda) | Tổ chức cao; **nhiều loài nhất** giới động vật; đối xứng hai bên; cơ thể và chân gồm **nhiều đốt khớp nhau** (nên gọi "tiết túc" = chân có đốt) | Xem 8.2 |
| **Thân mềm** (Mollusca) | Tổ chức cao; cơ thể **mềm, không phân đốt**; nội quan bọc trong **áo**, áo tiết ra **vỏ** | Phân theo vị trí các bộ phận: **Chân bụng** (ốc); **Chân rìu** (trai, sò — đối xứng hai bên); **Chân đầu** (mực, bạch tuộc — chân ở đầu chia nhiều thùy, **mai** là xương trong) |
| **Da gai** (Echinodermata) | Tổ chức cao; **đối xứng tỏa tròn (5 cánh)**; xương ngoài bằng **tấm đá vôi**; có hệ **chân ống** để hô hấp và di động; **toàn bộ sống ở biển** | 5 lớp: Nhím biển, Sao biển, Tay rắn (đuôi rắn), Huệ biển, Dưa biển (hải sâm) |
| **Dây sống** (Chordata) | Xem 8.3 | 4 phân ngành |

### 8.2. Ngành Tiết túc — chia theo cách thở

| Phân ngành | Lớp | Râu | Chân | Ví dụ |
|---|---|---|---|---|
| **Thở bằng mang** (Branchiata) — sống ở nước | **Giáp xác** (Crustacea) | **Có** | Nhiều | Tôm, cua |
| | **Sam** (Merostomata) | Không | — | Sam |
| **Thở bằng khí quản/phổi** (Tracheata) — sống trên cạn | **Nhện** (Arachnida) | **Không** | **4 đôi** | Nhện, **ve, mò, mạt** |
| | **Nhiều chân** (Myriapoda) | Có | Nhiều đôi | Rết, cuốn chiếu |
| | **Côn trùng** (Insecta) | Có | **3 đôi** | Muỗi, ruồi, chấy… — **lớp nhiều loài nhất** |

> [!bay]
> - **Ve, mò, mạt** thuộc lớp **Nhện** (4 đôi chân, không râu), **không phải** côn trùng.
> - Côn trùng: **3 đôi chân, có râu**. Nhện: **4 đôi chân, không râu**. Sam cũng không râu nhưng thở bằng mang.

> [!ung-dung] Tiết túc và Giun sán trong y học
> - **Véc-tơ truyền bệnh**: muỗi *Anopheles* (sốt rét), *Aedes* (sốt xuất huyết), *Culex* (viêm não Nhật Bản, giun chỉ); **mò** truyền **sốt mò** (*Orientia tsutsugamushi*); ve truyền bệnh Lyme.
> - **Gây bệnh ngoài da**: cái ghẻ (*Sarcoptes scabiei*, lớp Nhện) gây **bệnh ghẻ**; chấy, rận.
> - **Nọc độc**: bọ cạp, rết, ong.
> - **Giun sán**: ăn **gỏi cá** nhiễm ấu trùng → **sán lá gan nhỏ** (*Clonorchis sinensis*); ăn rau thủy sinh sống → **sán lá gan lớn** (*Fasciola*); ăn thịt lợn/bò tái → **sán dây** (*Taenia*); giun đũa, giun móc, giun kim lây qua đất, tay bẩn. Biết chu kỳ phát triển (bao nhiêu vật chủ trung gian) mới cắt được đường lây.

### 8.3. Ngành Dây sống (Chordata)

**Bốn đặc điểm** (đi từ lưng xuống bụng):

1. **Dây sống** ở phía lưng nâng đỡ cơ thể. Lớp thấp: có **suốt đời**. Lớp cao: chỉ có ở **phôi**, trưởng thành được thay bằng **cột xương sống**.
2. **Ống thần kinh** nằm **trên** dây sống: phần trước phát triển thành **não bộ**, phần sau là **tủy sống**. Loài càng cao, não càng lớn.
3. **Ống tiêu hóa** nằm **dưới** dây sống, từ miệng đến hậu môn. Phần trước là **hầu**, một phần phân hóa thành **khe mang** hoặc **phổi**: loài ở nước giữ khe mang suốt đời; loài ở cạn chỉ có khe mang ở **phôi**, sau thay bằng phổi.
4. **Hệ tuần hoàn**: một **mạch lưng** (máu chảy từ đầu xuống) và một **mạch bụng** (máu chảy từ sau lên); một phần mạch bụng co bóp được → **tim**. Hai mạch nối với nhau bằng các mạch nhỏ, có mạch qua cơ quan hô hấp.

**Bốn phân ngành** (theo giáo trình):

| Phân ngành | Dây sống | Đại diện |
|---|---|---|
| **Nửa sống** (Hemichordata) | Chỉ ở **phần trước** cơ thể | Ít loài, sống ở biển |
| **Sống đuôi** (Urochordata, Tunicata) | Chỉ ở **phần đuôi**; cơ thể có áo bọc kín | Sống tự do hoặc bám rong biển |
| **Sống đầu** (Cephalochordata, Acrania) | Chạy **suốt từ đầu đến đuôi** | **Cá lưỡng tiêm**, sống vùi trong cát biển nóng |
| **Có xương sống** (Vertebrata) | Chỉ ở phôi; mô sinh xương quanh dây sống tạo **cột sống** | 6 lớp: **Cá miệng tròn, Cá, Lưỡng cư, Bò sát, Chim, Có vú** |

Phân ngành Có xương sống có **tổ chức cao nhất**: cột sống, tủy sống hình trụ, não bộ **nằm trong hộp sọ**.

> [!bay]
> - Giáo trình ghi tên Latin của phân ngành Sống đầu là "Cephalopoda hay Acrania". **Cephalopoda** là lớp **Chân đầu** của Thân mềm (mực, bạch tuộc); tên đúng của phân ngành là **Cephalochordata** (Acrania). Đừng nhầm hai nhóm.
> - Hiện nay **Nửa sống** (Hemichordata) được tách thành **ngành riêng** (gần với Da gai), không còn xếp vào Dây sống. Đi thi theo giáo trình: 4 phân ngành.

> [!yhct] Động vật làm thuốc — xếp theo ngành
> Nhiều vị thuốc YHCT có nguồn gốc động vật; biết ngành giúp hiểu thành phần chính:
> - **Thân mềm**: **Mẫu lệ** (vỏ hàu), **Thạch quyết minh** (vỏ bào ngư), **Ô tặc cốt** (mai mực nang *Sepia* — chính là "tấm mai trong" của lớp Chân đầu). Thành phần chủ yếu là **CaCO~3~**, cơ sở hóa học của tác dụng **trung hòa acid dạ dày** (chế toan) (xem bài *Hợp chất vô cơ: oxide, acid, base, muối*, mã vc-05).
> - **Giun đốt**: **Địa long** (giun đất), **Thủy điệt** (đỉa). Đỉa hút máu (chi *Hirudo*) tiết **hirudin** ức chế trực tiếp thrombin; thận trọng khi dùng Thủy điệt cùng thuốc chống đông vì nguy cơ **chảy máu** (cơ chế, mức bằng chứng: xem bài *Hóa học acid amin, protein và hemoglobin*, mã hs-03).
> - **Tiết túc**: **Toàn yết** (bọ cạp, lớp Nhện), **Ngô công** (rết, lớp Nhiều chân), **Thuyền thoái** (xác lột ve sầu, lớp Côn trùng). Toàn yết, Ngô công là vị có độc, phải đúng liều.
>
> Phần lớn tác dụng lâm sàng của các vị này mới có bằng chứng ở mức kinh nghiệm và thực nghiệm; riêng hirudin và CaCO~3~ có cơ chế dược lý rõ.

## 9. Sự tiến hóa trong tổ chức các cơ quan của động vật

**Quy luật chung**: cơ quan tiến hóa từ **chưa có → có**, từ **đơn giản → phức tạp**; sự **phân hóa cấu tạo đi đôi với phân hóa chức năng**. Ngoại lệ: một số **ký sinh trùng** bị **thoái hóa** cơ quan (ví dụ sán dây không có ống tiêu hóa, hấp thụ qua bề mặt cơ thể) — vì sống trong ruột vật chủ đã có sẵn chất dinh dưỡng.

### 9.1. Hệ tiêu hóa

| Mức | Nhóm | Đặc điểm |
|---|---|---|
| Chưa có cơ quan | Thân lỗ, Ruột túi | Tiêu hóa **trong từng tế bào** |
| Ống thẳng | Giun dẹp, Giun tròn | Có ống tiêu hóa nhưng chỉ là **ống thẳng**, chưa chia phần |
| Ống phân đoạn | Từ **Giun đốt** | Ống tiêu hóa **chia thành nhiều phần**, mỗi phần một chức năng |
| Có tuyến tiêu hóa | Tiết túc, Thân mềm | **Tuyến nước bọt** (côn trùng), **tuyến gan–tụy** (giáp xác như tôm; thân mềm) |
| Hoàn thiện | Có xương sống | Dịch và enzym từ **tuyến nước bọt, tụy, gan với túi mật** |

### 9.2. Hệ bài tiết (qua thận)

Bài tiết = thải sản phẩm không cần của trao đổi chất. Ngoài thận, **da, phổi, ống tiêu hóa** cũng bài tiết; ở đây chỉ xét thận.

- **Thân lỗ, Ruột túi**: chưa có cơ quan bài tiết; thải qua **không bào co bóp** hoặc **khuếch tán** qua màng.
- **Giun dẹp, Giun tròn**: **nguyên đơn thận** — các **tế bào ngọn lửa** (nhiều tiêm mao rung) ở tận cùng hệ ống, đẩy chất thải vào ống nhỏ → ống lớn → **2 ống dọc cơ thể** → lỗ bài tiết.
- **Giun đốt**: **hậu đơn thận** — **phễu có lông rung** mở vào xoang cơ thể, nối ống đơn thận, đổ ra lỗ bài tiết (mỗi đốt một đôi).
- **Tiết túc** (côn trùng): **ống Malpighi** nằm trong xoang cơ thể, gom chất thải đổ vào ống tiêu hóa (giáo trình: ở mặt sau dạ dày).
- **Có xương sống**: thận gắn chặt với cơ quan sinh dục → **hệ niệu–sinh dục**. Trong phát triển phôi có **3 kiểu thận** thay thế nhau:

| Kiểu thận | Vị trí / thời điểm | Đặc điểm ống thận | Là thận hoạt động của |
|---|---|---|---|
| **Tiền thận** | Trước nhất | Đầu trong **có lông, thông xoang cơ thể**; đầu ngoài thông **ống dẫn niệu sơ cấp** | Chỉ có ở **phôi** của mọi động vật có xương sống |
| **Trung thận** | Sau tiền thận | Đầu trong **kín**; đầu ngoài thông **ống Wolff**. Từ ống niệu sơ cấp còn tách ra **ống Müller** (dẫn trứng ở con cái) | **Cá, Lưỡng cư** trưởng thành |
| **Hậu thận** | Sau cùng | Nhiều ống thận đầu trong kín; thông với **ống dẫn niệu thứ cấp** (nhánh mọc từ cuối ống Wolff) | **Bò sát, Chim, Có vú** |

Hậu thận ở thú là đôi thận **hình hạt đậu**; phía trong lõm, tạo **bể thận** hình phễu → **niệu quản** → **bàng quang**. Ngoài tạo nước tiểu, thận còn **điều hòa nồng độ chất hòa tan trong máu, cân bằng acid–base, thể tích máu**, nồng độ các chất trong dịch cơ thể.

> [!ung-dung] Phôi người "lặp lại" ba kiểu thận
> Phôi người cũng lần lượt có tiền thận → trung thận → hậu thận (thận vĩnh viễn). **Ống Wolff** về sau thành **ống dẫn tinh** ở nam; **ống Müller** thành **vòi tử cung, tử cung** ở nữ. Rối loạn quá trình này gây các dị tật như **thận lạc chỗ, thận móng ngựa, niệu quản đôi**, tử cung đôi. Vì thận và đường sinh dục cùng nguồn gốc phôi, bệnh nhân dị tật tử cung thường được kiểm tra cả thận.

### 9.3. Hệ tuần hoàn và máu

- **Thân lỗ, Ruột túi, Giun dẹp, Giun tròn**: **chưa có** hệ tuần hoàn; vận chuyển chất nhờ **co rút nhịp nhàng** của cả cơ thể.
- **Giun đốt**: có **mạch lưng, mạch bụng** và **5 đôi mạch bên** phía trước co bóp được, đóng vai trò "tim".
- **Côn trùng**: chỉ có **một mạch lưng**, một đoạn phình thành **các phòng tim** có cơ hai bên.
- **Thân mềm**: đã có **tim** gồm **1 tâm thất, 2 tâm nhĩ** (theo giáo trình; bổ sung: số tâm nhĩ khác nhau theo lớp, ví dụ ốc sên cạn chỉ có 1 tâm nhĩ).
- **Tiết túc và Thân mềm**: hệ tuần hoàn **hở** vì **chưa có mao mạch**.
- **Có xương sống**: hệ tuần hoàn **kín**, có **mao mạch** nối động mạch và tĩnh mạch. Ở phôi, tim là **một ống** (giống động vật không xương sống), sau đó phân hóa thành nhĩ, thất có vách và van.

![Hình 3. Tiến hóa của tim ở động vật có xương sống](tim-dong-vat.svg)

| Lớp | Tim | Vòng tuần hoàn | Pha trộn máu |
|---|---|---|---|
| **Cá** | **2 ngăn**: 1 nhĩ, 1 thất | **1 vòng** | Tim chỉ chứa máu nghèo O~2~ |
| **Lưỡng cư** | **3 ngăn**: 2 nhĩ, 1 thất | **2 vòng**, chưa tách hẳn | Có pha trộn ở tâm thất |
| **Bò sát** (trừ cá sấu) | **4 ngăn**, nhưng vách liên thất **không hoàn toàn** | 2 vòng | Còn pha trộn |
| **Cá sấu, Chim, Có vú** | **4 ngăn** riêng biệt: 2 nhĩ, 2 thất | 2 vòng tách hẳn | **Không pha trộn** |

*Vì sao* tim 4 ngăn là bước tiến? Máu giàu O~2~ và máu nghèo O~2~ hoàn toàn tách nhau, và vòng tuần hoàn lớn có áp lực cao riêng. Điều này đáp ứng nhu cầu oxy rất lớn của động vật **hằng nhiệt** (chim, thú).

> [!ung-dung] Tim phôi người đi qua các "giai đoạn tiến hóa"
> Tim phôi người bắt đầu là **ống tim**, rồi gấp khúc và **phân vách** thành 4 ngăn. Nếu quá trình phân vách không hoàn tất sẽ gây **tim bẩm sinh**: **thông liên thất** (giống tim bò sát — máu trộn ở tâm thất), **thông liên nhĩ**, còn ống động mạch… Đây là nhóm dị tật bẩm sinh hay gặp nhất ở trẻ sơ sinh.

**Máu.** Ở giun đốt, côn trùng, thân mềm đã có tế bào máu chứa **sắc tố hô hấp**; sắc tố của thân mềm là **hemocyanin** (chứa **đồng, Cu**). Động vật có xương sống: máu gồm **huyết tương** và **thành phần hữu hình** (hồng cầu, bạch cầu, tiểu cầu); hồng cầu chứa **hemoglobin** (chứa **sắt**).

| | Thú (có vú) | Bò sát, Lưỡng cư, Cá (và Chim) |
|---|---|---|
| Hình hồng cầu (máu ngoại vi) | **Đĩa lõm hai mặt** | **Bầu dục** |
| Nhân | **Không nhân** | **Có nhân** |

Động vật có vú còn có **hệ bạch huyết**.

> [!bay]
> - Hemocyanin chứa **đồng (Cu)**, máu thân mềm có màu **xanh lam** khi gắn O~2~. Hemoglobin chứa **sắt (Fe)**.
> - Bổ sung: giáo trình viết sắc tố nằm trong "tế bào máu", nhưng hemocyanin thực ra **hòa tan trong huyết tương** (dịch bạch huyết) chứ không nằm trong tế bào; côn trùng phần lớn không cần sắc tố hô hấp vì O~2~ đi thẳng tới mô theo hệ khí quản.
> - Hồng cầu **không nhân** là đặc điểm của **thú** (có vú). Hồng cầu **chim** vẫn **có nhân** (giáo trình không nêu chim, nhưng đây là điểm hay bị bẫy).

### 9.4. Cơ quan hô hấp

| Nhóm | Hô hấp |
|---|---|
| Thân lỗ, Ruột túi, Giun dẹp, Giun tròn, Giun đốt | **Chưa có** cơ quan chuyên biệt; O~2~ **khuếch tán** qua tế bào bề mặt |
| Thân mềm | Loài ở biển: **mang**; một số loài (ốc sên cạn): **phổi** |
| Tiết túc Tracheata | **Phổi** hoặc **khí quản** (hệ ống dẫn khí đặc biệt, chỉ có ở phân ngành này) |
| Tiết túc Branchiata | **Mang** (sống ở nước) |
| Cá | **Mang**: vừa hô hấp vừa **bài tiết muối** |
| Có xương sống ở cạn | Mang chỉ có ở **phôi**; trưởng thành thở bằng **phổi** |
| Lưỡng cư (ếch) | Phổi chỉ là **2 túi đơn giản** → **hô hấp qua da** rất quan trọng |
| Chim, Thú | Phổi hoàn thiện; **chim có thêm túi khí** khắp cơ thể, cần cho bay |

Mang và phổi ở các ngành đều cấu tạo từ **nhiều tấm mỏng xếp chồng** — *vì sao*? Để **tăng diện tích trao đổi khí** trên một thể tích nhỏ. Phổi người có khoảng vài trăm triệu phế nang, tổng diện tích trao đổi khí khoảng 70–100 m^2^.

### 9.5. Hệ thần kinh

Chức năng: **dẫn truyền xung động** và **điều hòa** hoạt động các cơ quan.

| Nhóm | Kiểu hệ thần kinh |
|---|---|
| Thân lỗ | **Chưa có** cơ quan thần kinh riêng |
| Ruột túi (thủy tức) | **Lần đầu xuất hiện tế bào thần kinh**, nối nhau thành **lưới thần kinh** |
| Giun dẹp | **Một đôi hạch não**, các dây thần kinh chạy về phía sau |
| Giun tròn (Nematoda) | **Vòng thần kinh hầu**, dây đến núm môi, dây lưng và dây bụng |
| Giun đốt, Tiết túc, Thân mềm | **Hạch não + hạch dưới hầu + chuỗi hạch bụng**, nối bằng dây thần kinh → **đã có thần kinh trung ương và ngoại biên**, có dây vận động và dây cảm giác |
| Có xương sống | Rất phát triển; cấu tạo cơ bản giống nhau, khác nhau ở **mức phát triển, kích thước các phần não** (tùy lối sống) |

**Phát triển phôi của hệ thần kinh động vật có xương sống**: **tấm thần kinh → máng thần kinh → ống thần kinh**. Phần trước ống thần kinh tạo não: lúc đầu **3 bọng (thùy) não**, sau đó bọng trước và bọng sau **chia đôi** → **5 phần não**:

| Phần não (5) | Thành phần (theo giáo trình) | Não thất |
|---|---|---|
| **Não trước** (đoan não) | 2 **bán cầu đại não**; phía trước có 2 thùy khứu giác | I và II |
| **Não trung gian** | Tầng thị giác (đồi thị), **tuyến đỉnh** (tùng), **tuyến hạ não** (tuyến yên) | III |
| **Não giữa** | Các **thùy thị giác** | — |
| **Não sau** | **Tiểu não** | — |
| **Não cùng** | **Hành tủy**; tiếp sau là tủy sống | IV |

Ngoài thần kinh trung ương còn có **hệ thần kinh thực vật** (tự chủ), điều khiển tim, phổi, ống tiêu hóa và nội tạng.

> [!bay]
> - **3 bọng → 5 bọng**: chỉ có bọng **trước** và bọng **sau** chia đôi; **bọng giữa giữ nguyên** (thành não giữa).
> - Lưới thần kinh (không có trung ương) là của **Ruột túi**; hạch não đầu tiên là của **Giun dẹp**; chuỗi hạch bụng là của **Giun đốt, Tiết túc, Thân mềm**. Ở động vật có xương sống, ống thần kinh nằm ở **lưng**.

> [!ung-dung] Khi ống thần kinh không đóng
> Ống thần kinh người khép trong khoảng tuần thứ 3–4 của thai kỳ, thường trước khi người mẹ biết mình có thai. Nếu ống không khép kín sẽ gây **dị tật ống thần kinh**: **nứt đốt sống** (spina bifida), **vô sọ**. Bổ sung **acid folic** trước và trong đầu thai kỳ làm giảm rõ rệt nguy cơ — vì vậy khuyến cáo phụ nữ chuẩn bị mang thai uống acid folic.

### 9.6. Hệ nội tiết và feromon

**Động vật không xương sống**: hệ nội tiết của **Tiết túc** được nghiên cứu nhiều nhất, gắn với hiện tượng **lột xác**. Trước khi lột xác, tuyến ở biểu bì tiết chất làm **tan lớp kitin và protein** của vỏ cũ. Hoạt động này do **hormon** của tuyến nội tiết điều hòa. Giáp xác và côn trùng có tuyến nội tiết ở **não**, **hạch dưới hầu** và các hạch khác.

**Động vật có xương sống**: tuyến nội tiết rất phát triển. Hormon theo **máu** đến **cơ quan đích** để điều hòa trao đổi chất, nồng độ các chất, kích thích cơ quan đích hoạt động và điều hòa sự phát triển chung.

**Feromon (pheromone)**: chất do **tuyến ngoại tiết** tiết ra ngoài cơ thể, tác động lên sinh lý/hành vi của **cá thể khác cùng loài**, thường được nhận qua **khứu giác**.

| | Hormon | Feromon |
|---|---|---|
| Tuyến tiết | **Nội tiết** | **Ngoại tiết** |
| Đường đi | Theo **máu** | Ra **môi trường** (không khí, nước) |
| Tác động lên | Cơ quan đích **trong cùng cơ thể** | **Cá thể khác cùng loài** |

Ví dụ feromon trong giáo trình:

- **Chất quyến rũ sinh dục**: tằm/bướm **cái** tiết ra, con **đực** nhận bằng thụ quan ở **râu** (từ rất xa). Giáo trình ghi các chất này thường có phân tử lớn.
- **Chất đánh dấu, chất báo động** ở **kiến, ong**: đánh dấu đường đến nguồn thức ăn, báo nguy hiểm.
- Ở **chuột**: nhiều chuột cái nhốt chung → chu kỳ động dục **bị rối loạn**; có chuột đực → rối loạn **giảm**; chuột vừa thụ tinh nhốt chung với **chuột đực lạ** → **phôi không phát triển** (không làm tổ được).

> [!vi-du] Ứng dụng feromon
> Bẫy **feromon giới tính** tổng hợp được dùng để giám sát và diệt côn trùng hại cây (ví dụ ruồi vàng hại quả): con đực bị hút vào bẫy, con cái không giao phối được. Đây là biện pháp sinh học, ít dùng thuốc trừ sâu. Ở người, vai trò của feromon vẫn còn tranh luận, chưa có bằng chứng chắc chắn.

## Tóm tắt

| Chủ đề | Điểm cần nhớ |
|---|---|
| Thống nhất sinh giới | Tế bào; trao đổi chất; sinh trưởng–phát triển–sinh sản; cảm ứng; mã di truyền vạn năng |
| Đơn vị phân loại | Loài (cơ sở) → Chi (= giống) → Họ → Bộ → Lớp → Ngành → Giới → Trên giới; dưới loài: phân loài, thứ, chủng; phụ: sub- / super- |
| Hệ thống (giáo trình) | Prokaryota (Monera) + Eukaryota (Protista, Nấm, Thực vật, Động vật). *Hiện nay: 3 lĩnh vực Bacteria, Archaea, Eukarya; virus ngoài hệ thống* |
| Tên khoa học | La tinh, **Chi viết hoa + loài viết thường**; phân chi trong ngoặc; có thể kèm tác giả, năm |
| Prokaryota | Không màng nhân; 1 NST vòng/sợi; không histon; plasmid; gen liên tục |
| Eukaryota | Màng nhân; nhiều cặp NST sợi + histon; exon–intron; ty thể (+ lạp thể) có ADN vòng |
| Thực vật | Tảo (tản) → Rêu (chồi giả, 1n trội) → Dương xỉ (rễ thật, mạch, 2n trội) → Hạt trần (hạt hở, quản bào) → Hạt kín (hoa, nhụy kín, thụ tinh kép, quả) |
| Động vật | Thân lỗ, Ruột túi (2 lớp tế bào) → Giun dẹp (3 lớp, đối xứng 2 bên) → Giun tròn (xoang giả) → Giun đốt (xoang thật, có đốt) → Tiết túc, Thân mềm, Da gai → Dây sống |
| Tiêu hóa | Nội bào → ống thẳng → ống phân đoạn (Giun đốt) → tuyến tiêu hóa → gan, tụy, nước bọt |
| Bài tiết | Không bào co bóp → nguyên đơn thận (tế bào ngọn lửa) → hậu đơn thận → ống Malpighi → tiền / trung / hậu thận |
| Tuần hoàn | Chưa có → mạch co bóp (Giun đốt) → hở (Tiết túc, Thân mềm) → kín: cá 2 ngăn, lưỡng cư 3, bò sát 4 không hoàn toàn, chim–thú 4 |
| Hô hấp | Khuếch tán → mang / khí quản / phổi; ếch thở thêm qua da; chim có túi khí |
| Thần kinh | Lưới (Ruột túi) → hạch não (Giun dẹp) → chuỗi hạch bụng (Giun đốt…) → ống thần kinh lưng, 3 → 5 bọng não |
| Nội tiết | Lột xác ở Tiết túc; hormon theo máu; feromon ngoại tiết, tác động cá thể cùng loài |
