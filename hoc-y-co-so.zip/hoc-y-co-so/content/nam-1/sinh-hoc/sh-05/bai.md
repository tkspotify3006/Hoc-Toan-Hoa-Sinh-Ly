---
title: Phân chia tế bào và sự hình thành giao tử ở người
thoi-gian: 40 phút
muc-tieu:
- Nêu được khái niệm chu kỳ tế bào; mô tả đặc điểm gian kỳ (G1, S, G2) và các kỳ của nguyên phân.
- Mô tả được diễn biến các kỳ của giảm phân, nhất là 5 giai đoạn của kỳ đầu I; theo dõi được số NST và lượng ADN qua từng kỳ.
- Trình bày và so sánh được quá trình sinh tinh trùng và sinh trứng ở người.
- Trình bày được khái niệm, biểu hiện, cơ sở phân tử và ý nghĩa của sự chết tế bào có chương trình (apoptosis).
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. **Chu kỳ tế bào** = gian kỳ (**G1 → S → G2**) + phân bào chính thức (**M**: đầu → giữa → sau → cuối). G1 dài ngắn rất thay đổi; ADN (DNA) nhân đôi ở **S**.
> 2. **Nguyên phân**: 1 tế bào 2n → **2 tế bào 2n** giống hệt nhau (tế bào sinh dưỡng, tế bào sinh dục giai đoạn đầu).
> 3. **Giảm phân**: ADN nhân đôi **1 lần**, phân chia **2 lần** → 1 tế bào 2n cho **4 tế bào n**. Lần I tách **cặp tương đồng** (giảm số nhiễm sắc thể — NST), lần II tách **chromatid chị em**.
> 4. **Sinh tinh**: liên tục từ dậy thì, 1 tinh bào I → **4 tinh trùng**. **Sinh trứng**: noãn bào I có từ bào thai, **dừng ở kỳ đầu I** nhiều năm; rụng trứng ở **kỳ giữa II**; chỉ xong giảm phân khi **thụ tinh**; 1 noãn bào I → **1 trứng** + cực cầu.
> 5. **Apoptosis**: tế bào **teo lại**, màng còn nguyên, nhân kết đặc, ADN cắt thành mảnh đều nhau, bị thực bào; gen **p53** cần cho apoptosis khi ADN tổn thương — p53 hỏng → nguy cơ **ung thư**.

## 1. Phân bào nguyên nhiễm (nguyên phân) và chu kỳ tế bào

Phân bào là một quá trình liên tục. Người ta chia nó thành từng kỳ chỉ để dễ mô tả. Khoảng thời gian trọn vẹn của một lần phân bào nguyên nhiễm gọi là **một chu kỳ tế bào** (cell cycle). Chu kỳ gồm **gian kỳ** (interphase) và **các kỳ phân bào chính thức**, ký hiệu **M** (mitosis).

Nguyên phân xảy ra ở **tế bào sinh dưỡng** (soma) và ở tế bào sinh dục **giai đoạn đầu** của quá trình tạo giao tử (tinh nguyên bào, noãn nguyên bào). Đặc điểm cốt lõi: tế bào mẹ có **2n** NST, sau phân bào được **hai tế bào con cũng có 2n** NST.

![Hình 1. Chu kỳ tế bào và các điểm kiểm soát](chu-ky-te-bao.svg)

### 1.1. Gian kỳ — giai đoạn chuẩn bị

Gian kỳ nằm xen giữa hai lần phân bào. Đây là lúc tế bào **chuẩn bị vật chất** cho lần phân chia tới. Gian kỳ gồm 3 giai đoạn **G1, S, G2**.

Thời gian chu kỳ khác nhau tùy loại tế bào. Nhưng có quy luật: **S, G2 và M khá ổn định**, còn **G1 biến thiên rất nhiều**. Vì vậy, tế bào phân chia nhanh hay chậm chủ yếu là do G1 ngắn hay dài.

| Giai đoạn | Thời gian (động vật có vú, theo giáo trình) | Việc chính |
|---|---|---|
| **G1** (Gap 1) | Từ 2–3 giờ đến nhiều ngày; **thay đổi nhiều nhất** | Tế bào lớn lên, tổng hợp ARN (RNA), protein; "quyết định" có phân chia tiếp hay không |
| **G0** | Có thể suốt đời | Tế bào **ra khỏi chu kỳ**, ngừng phân chia |
| **S** (Synthesis) | Khoảng **7 giờ** | **ADN nhân đôi**, đồng thời tổng hợp **histon** → mỗi NST thành **2 chromatid** |
| **G2** (Gap 2) | Khoảng **3–4 giờ** | **Sửa chữa** các sai sót khi nhân đôi ADN; chuẩn bị vào M |

**Giai đoạn G0.** Khi tế bào ngừng phân chia, chu kỳ bị ngắt, tế bào đi vào G0. Có loại tế bào ở G0 suốt đời, ví dụ **tế bào thần kinh**. Có loại nằm ở G0 một thời gian không xác định, khi có **kích thích mới** thì quay lại G1 và phân chia tiếp (ví dụ tế bào gan sau khi cắt bớt một phần gan).

**Giai đoạn S.** ADN nhân đôi, histon và một số protein khác được tổng hợp, sợi chromatin mới hình thành. Kết quả: mỗi NST gồm **hai chromatid chị em** dính nhau ở tâm động. Số NST **không đổi** (vẫn 2n) nhưng lượng ADN **tăng gấp đôi** (từ 2c thành 4c).

Giáo trình nêu thêm: trong và sau khi ADN nhân đôi có **trao đổi đoạn giữa hai chromatid chị em** (sister chromatid exchange). Theo giáo trình, nhờ vậy không chromatid nào "già" hoàn toàn hay "non" hoàn toàn.

> [!cap-nhat] ADN nhân đôi theo kiểu bán bảo toàn
> Giáo trình mô tả chromatid mới được tạo "bên cạnh" NST cũ, NST cũ thành chromatid khuôn. **Hiện nay** đã chứng minh (thí nghiệm Meselson–Stahl, 1958) ADN nhân đôi theo nguyên tắc **bán bảo toàn**: mỗi chromatid con gồm **một mạch ADN cũ + một mạch mới**. Như vậy, ngay từ đầu không có chromatid nào hoàn toàn cũ. Trao đổi chromatid chị em có thật, nhưng chủ yếu là **hệ quả của sửa chữa ADN** (tái tổ hợp tương đồng). Tần số của nó tăng khi ADN bị tổn thương, nên được dùng làm xét nghiệm đánh giá tác nhân gây đột biến. Đi thi vẫn trả lời theo giáo trình.

**Giai đoạn G2.** Tế bào tiếp tục **sửa chữa** các sai sót phát sinh khi nhân đôi ADN, rồi mới bước vào M.

> [!bay]
> - Sau S, tế bào vẫn có **2n NST** (mỗi NST kép), **không phải 4n**. Cái tăng gấp đôi là **lượng ADN** (4c) và số chromatid.
> - Giai đoạn **biến thiên nhiều nhất là G1**, không phải S hay M.
> - G0 **không phải** một kỳ của nguyên phân; đó là trạng thái ngừng chu kỳ.

> [!cap-nhat] Điều khiển chu kỳ tế bào: cyclin–CDK và các điểm kiểm soát (bổ sung – kiến thức hiện nay)
> Giáo trình không đề cập, nhưng đây là kiến thức nền của ung thư học.
> - **"Động cơ" của chu kỳ** là các **kinase phụ thuộc cyclin** (CDK). CDK chỉ hoạt động khi gắn với **cyclin**. Lượng cyclin tăng rồi bị phân hủy theo từng pha, nên mỗi pha có một cặp cyclin–CDK riêng đẩy tế bào sang pha sau. Phát hiện này được **giải Nobel Sinh lý – Y học 2001** (Hartwell, Hunt, Nurse).
> - **"Phanh" ở G1**: protein **Rb** (sản phẩm gen *RB1*, xem khung trao đổi chéo soma bên dưới) giữ tế bào ở G1. Cyclin D–**CDK4/6** phosphoryl hóa Rb thì "nhả phanh", tế bào vượt điểm giới hạn để vào S.
> - **Các điểm kiểm soát** (checkpoint). **G1/S**: ADN có tổn thương không, điều kiện có đủ không. Khi ADN hỏng, **p53** tích tụ, hoạt hóa protein **p21** ức chế CDK → dừng chu kỳ để sửa; hỏng nặng thì đẩy tế bào vào **apoptosis** (mục 4).
> - **G2/M**: ADN đã nhân đôi xong và đúng chưa.
> - **Kiểm soát thoi phân bào** (chuyển kỳ giữa → kỳ sau): mọi NST đã gắn đúng vào thoi chưa, rồi mới cho chromatid tách nhau.
> - Tế bào ung thư thường hỏng các "phanh" (Rb, p53) hoặc có "chân ga" quá mạnh (tăng cyclin D, CDK) nên phân chia không ngừng.
> - **Thuốc ức chế CDK4/6** (palbociclib, được FDA cấp phép năm 2015; ribociclib và abemaciclib năm 2017) giữ tế bào ung thư lại ở G1. Chúng dùng phối hợp với liệu pháp nội tiết cho **ung thư vú thụ thể hormon dương tính, HER2 âm tính** giai đoạn tiến xa (nguồn: Nobel Prize 2001; AACR, 2017).

### 1.2. Các kỳ của phân bào chính thức (M)

**Kỳ đầu (prophase).** Ở gian kỳ, NST là những sợi rất mảnh, không thấy rõ dưới kính hiển vi quang học. Sang kỳ đầu, NST **xoắn lại, kết đặc** dần và bắt đầu thấy được từng chiếc. Hạch nhân còn thấy ở đầu kỳ, rồi **biến mất**.

**Kỳ giữa sớm (prometaphase).** Thời gian ngắn. **Màng nhân biến mất**, **sợi thoi vô sắc** xuất hiện. NST gắn vào sợi thoi tại **tâm động** (centromere).

**Kỳ giữa (metaphase).** Thoi vô sắc đã hoàn chỉnh, **trung thể** đã về hai cực đối diện. NST xếp thành **một hàng trên mặt phẳng xích đạo**. NST **co ngắn tối đa**, nên đây là kỳ **quan sát và đếm NST tốt nhất**.

**Kỳ sau (anaphase).** Tâm động **tách dọc**, hai **chromatid chị em** rời nhau, mỗi chromatid trở thành một NST đơn và đi về **hai cực** đối diện.

**Kỳ cuối (telophase).** NST về đến cực, **duỗi xoắn**. Hạch nhân và màng nhân **hình thành lại**. Tế bào chất thắt lại, tạo hai tế bào.

**Kết quả:** hai tế bào con **giống hệt nhau** và giống tế bào mẹ, mỗi tế bào có đủ bộ NST 2n. Chúng bước vào gian kỳ và chu kỳ lặp lại.

> [!vi-du] Trao đổi chéo soma
> Ở mô sinh dưỡng của nhiều loài (nhất là thực vật), trong S, G2 và kỳ đầu, có khi xảy ra **trao đổi chéo soma**. Bình thường, khi sửa sai ADN, chromatid cũ được dùng làm khuôn. Nhưng đôi khi khuôn lại lấy từ chromatid của **NST tương đồng** (không phải chị em). Ở người, hiện tượng này gặp trong **u nguyên bào võng mạc** (retinoblastoma) ở trẻ em. *Vì sao gây u?* Ở thể di truyền, trẻ đã mang sẵn một bản gen RB1 hỏng; trao đổi chéo soma có thể làm tế bào võng mạc mất nốt bản gen lành, nên không còn "phanh" chu kỳ tế bào.

> [!ung-dung] Thuốc chống ung thư tác động lên phân bào
> Tế bào ung thư phân chia nhanh, nên nhiều thuốc hóa trị nhắm vào chu kỳ tế bào:
> - **Ức chế thoi vô sắc** (vi ống) → tế bào dừng ở **kỳ giữa**: nhóm **vinca alkaloid** (vinblastin, vincristin) ngăn vi ống trùng hợp; nhóm **taxan** (paclitaxel) lại làm vi ống quá bền, không tháo ra được.
> - **Ức chế tổng hợp ADN** (tác động pha **S**): methotrexat, 5-fluorouracil…
>
> Thuốc cũng hại các mô **tự đổi mới nhanh** của cơ thể: niêm mạc tiêu hóa (loét miệng, tiêu chảy), tủy xương (giảm bạch cầu), nang tóc (rụng tóc). Đó là lý do có tác dụng phụ điển hình của hóa trị.

## 2. Phân bào giảm nhiễm (giảm phân)

Giảm phân là **hai lần phân bào cuối cùng** của tế bào sinh dục để tạo **giao tử**. Nó đưa tế bào từ trạng thái **lưỡng bội (2n)** về **đơn bội (n)**. Khi tinh trùng kết hợp với trứng (**thụ tinh**), trạng thái 2n được khôi phục. *Vì sao cần giảm phân?* Nếu giao tử vẫn 2n thì sau mỗi thế hệ số NST sẽ tăng gấp đôi.

Giảm phân gồm **hai lần phân chia liên tiếp** (lần I và lần II). Trước lần I có một gian kỳ, trong đó ADN nhân đôi ở pha S. **ADN chỉ nhân đôi một lần cho cả hai lần phân chia.**

### 2.1. Lần phân bào I — giảm số NST

#### a) Kỳ đầu I

Kỳ đầu I luôn **rất dài** (thời gian thay đổi tùy tế bào) và chia thành **5 giai đoạn**:

| Giai đoạn | Tên quốc tế | Sự kiện chính |
|---|---|---|
| 1. **Sợi mảnh** | Leptoten | NST bắt đầu co lại, thành những sợi như sợi chỉ, thấy được dưới kính hiển vi điện tử |
| 2. **Tiếp hợp** | Zygoten | NST **tương đồng** bắt cặp với nhau suốt chiều dài (thường bắt đầu từ đầu mút) → tạo **lưỡng trị** (bivalent). Sự bắt cặp gọi là **synapsis**, mở đầu cho trao đổi chéo |
| 3. **Sợi dày** (co ngắn) | Pachyten | NST co ngắn, dày lên. **Trao đổi chéo** (crossing-over) xảy ra: chromatid không chị em đứt, đổi đoạn và nối lại |
| 4. **Thể kép** | Diploten | Các chromatid tách dần, lộ rõ **bộ tứ** (4 chromatid). Chúng chỉ còn dính ở **điểm bắt chéo** (chiasma); điểm bắt chéo trượt dần ra đầu mút |
| 5. **Hướng cực** | Diakinesis | Lưỡng trị chỉ còn dính ở đầu mút chromatid, hai tâm động xa nhau. Hình dạng này giữ đến hết kỳ giữa I |

*Mẹo nhớ thứ tự*: **Mảnh – Hợp – Dày – Kép – Cực** (lepto – zygo – pachy – diplo – diakinesis).

**Lưỡng trị ở người.** Người có **23 lưỡng trị**: 22 lưỡng trị NST thường và 1 lưỡng trị giới tính.

- Ở **nữ**, lưỡng trị XX giống lưỡng trị thường.
- Ở **nam**, X và Y chỉ bắt cặp ở **đầu mút nhánh ngắn**, vùng tương đồng này gọi là **vùng giả NST thường** (giáo trình: *vùng giả autosom*; pseudoautosomal region).
- Lưỡng trị thường có các **điểm bắt chéo**, là nơi chromatid không chị em trao đổi đoạn. Giáo trình ghi lưỡng trị X–Y **không có** điểm bắt chéo.

> [!cap-nhat] Lưỡng trị X–Y cũng có trao đổi chéo
> Giáo trình ghi lưỡng trị X–Y không có điểm bắt chéo. **Hiện nay** biết rằng trong giảm phân ở nam, vùng giả NST thường ở nhánh ngắn (PAR1) **luôn có ít nhất một trao đổi chéo**. Chính điểm bắt chéo này giữ X và Y dính nhau để chúng phân ly đúng về hai cực. Gen nằm trong vùng này di truyền gần giống gen trên NST thường. Đi thi trả lời theo giáo trình.

#### b) Kỳ giữa I

Màng nhân và hạch nhân đã biến mất. Các **lưỡng trị** xếp trên mặt phẳng xích đạo. Hai tâm động của mỗi lưỡng trị nằm **đối xứng hai bên** mặt phẳng xích đạo, gắn vào sợi thoi. Mỗi NST trong cặp nằm **ngẫu nhiên** bên này hay bên kia.

> [!bay] Kỳ giữa I khác kỳ giữa nguyên phân
> - Nguyên phân: **từng NST kép** xếp thành **một hàng**; tâm động nằm **trên** mặt phẳng xích đạo.
> - Giảm phân I: **từng cặp tương đồng** (lưỡng trị) xếp; hai tâm động nằm **hai bên** mặt phẳng xích đạo (về mặt hình ảnh là "hai hàng"). Mỗi NST của cặp nối với thoi từ một cực khác nhau.

#### c) Kỳ sau I

Hai NST của **cặp tương đồng** tách nhau, đi về hai cực. Mỗi NST **vẫn ở dạng kép** (tâm động **không** tách).

#### d) Kỳ cuối I

Màng nhân hình thành quanh bộ NST ở mỗi cực, tế bào chất thắt lại. Kết quả: **2 tế bào**, mỗi tế bào có **n NST kép** (số NST đã giảm một nửa, mỗi NST vẫn gồm 2 chromatid).

> [!ghi-nho] Vì sao giảm phân tạo ra giao tử đa dạng?
> - **Phân ly độc lập**: ở kỳ giữa I, mỗi cặp xếp ngẫu nhiên, NST nguồn bố và nguồn mẹ về một cực theo kiểu "tung đồng xu". Với 23 cặp, một người có thể tạo 2^23^ ≈ 8,4 triệu loại giao tử khác nhau, chưa kể trao đổi chéo.
> - **Trao đổi chéo** (kỳ đầu I) làm hoán vị gen giữa NST nguồn bố và nguồn mẹ.
>
> Hai cơ chế cộng lại → thông tin di truyền của thế hệ trước được **tổ hợp lại**, mỗi giao tử gần như là duy nhất.

### 2.2. Lần phân bào II — tách chromatid chị em

**Kỳ xen kẽ** (interkinesis). Gọi là "kỳ" nhưng thực tế lần II diễn ra **ngay sau** kỳ cuối I. **Không có nhân đôi ADN** (không có pha S). Hai tế bào vào kỳ giữa II khi thoi vô sắc xuất hiện.

**Kỳ giữa II.** NST **vẫn kép**, xếp trên mặt phẳng xích đạo; tâm động mỗi NST bám vào sợi thoi.

**Kỳ sau II.** Tâm động tách, **chromatid chị em** rời nhau thành NST đơn, đi về hai cực.

**Kỳ cuối II.** NST về đến cực, màng nhân hình thành, tế bào chất chia đôi.

**Tóm lại:** 1 tế bào **2n** → qua 2 lần phân bào → **4 tế bào đơn bội (n)**. Lần II diễn ra giống nguyên phân, nhưng trên tế bào chỉ có n NST.

### 2.3. Số NST và lượng ADN qua các kỳ — bảng phải thuộc

Quy ước: **n** = số NST đơn bội (ở người n = 23); **c** = lượng ADN trong bộ đơn bội. "Kép" = NST gồm 2 chromatid.

![Hình 2. Lượng ADN và trạng thái NST trong một tế bào qua nguyên phân và giảm phân](nst-adn.svg)

| Thời điểm | Bộ NST | Lượng ADN | Ở người: số NST / số phân tử ADN |
|---|---|---|---|
| **G1** | 2n đơn | 2c | 46 / 46 |
| **G2**, kỳ đầu, kỳ giữa **nguyên phân** | 2n kép | 4c | 46 / 92 |
| **Kỳ sau nguyên phân** (cả tế bào) | **4n đơn** | 4c | 92 / 92 |
| Sau nguyên phân (mỗi tế bào con) | 2n đơn | 2c | 46 / 46 |
| **Kỳ đầu I, kỳ giữa I** | 2n kép (n lưỡng trị) | 4c | 46 / 92 (23 lưỡng trị) |
| **Kỳ sau I** (cả tế bào) | 2n kép (đang tách thành 2 nhóm n kép) | 4c | 46 / 92 |
| **Kỳ cuối I** → kỳ giữa II (mỗi tế bào) | **n kép** | 2c | 23 / 46 |
| **Kỳ sau II** (cả tế bào) | **2n đơn** | 2c | 46 / 46 |
| **Giao tử** | **n đơn** | 1c | 23 / 23 |

> [!bay] Những chỗ hay bị gài
> - **Số NST giảm một nửa ở lần phân bào I**, không phải lần II. Lần II chỉ giảm lượng ADN từ 2c xuống 1c.
> - Tế bào sau giảm phân I đã là **đơn bội (n)**, dù mỗi NST còn kép.
> - **Kỳ sau II** tạm thời có **2n NST đơn** trong một tế bào, nhưng đó **không phải** tế bào lưỡng bội (các NST không thành cặp tương đồng).
> - Đếm NST = **đếm tâm động**. Đếm phân tử ADN = đếm chromatid (NST kép có 2 phân tử ADN).
> - Kỳ sau nguyên phân: **4n đơn**; kỳ sau I: **2n kép**; kỳ sau II: **2n đơn**.

### 2.4. So sánh nguyên phân và giảm phân

| | **Nguyên phân** | **Giảm phân** |
|---|---|---|
| Xảy ra ở | Tế bào sinh dưỡng; tế bào sinh dục giai đoạn nguyên bào | Tế bào sinh dục ở giai đoạn chín (tinh bào I, noãn bào I) |
| Số lần nhân đôi ADN / số lần phân chia | 1 / 1 | **1 / 2** |
| Tiếp hợp, trao đổi chéo | Không (trừ trao đổi chéo soma hiếm gặp) | **Có**, ở kỳ đầu I |
| Kỳ giữa | NST kép xếp **1 hàng** | Kỳ giữa I: **lưỡng trị** xếp, tâm động hai bên mặt phẳng xích đạo |
| Kỳ sau | Chromatid chị em tách | Kỳ sau I: **cặp tương đồng** tách; kỳ sau II: chromatid tách |
| Kết quả | **2** tế bào **2n**, giống hệt mẹ | **4** tế bào **n**, khác nhau về di truyền |
| Ý nghĩa | Sinh trưởng, thay thế tế bào, lành vết thương | Tạo giao tử, duy trì bộ NST qua các thế hệ, tạo biến dị tổ hợp |

> [!ung-dung] Không phân ly NST và hội chứng Down
> Nếu một cặp NST **không phân ly** (nondisjunction) ở kỳ sau I (hoặc hai chromatid không tách ở kỳ sau II), sẽ có giao tử **thừa** (n + 1) và giao tử **thiếu** (n − 1) một NST. Giao tử n + 1 mang 2 NST số 21 kết hợp với giao tử bình thường → hợp tử **47 NST, ba nhiễm 21**: **hội chứng Down** (karyotype 47,XX,+21 hoặc 47,XY,+21).
> - Phần lớn trường hợp do không phân ly trong giảm phân **của mẹ**, chủ yếu ở **lần I**.
> - **Nguy cơ tăng rõ theo tuổi mẹ**: con số thường dùng khi sinh là khoảng **1/1.250 ở tuổi 25**, **1/400 ở tuổi 35**, **1/100 ở tuổi 40**, **1/30 ở tuổi 45**. Một cách giải thích là noãn bào I đã **dừng ở kỳ đầu I** từ khi mẹ còn là bào thai (xem mục 3.2). Noãn càng "chờ" lâu, cơ chế giữ các cặp NST càng dễ hỏng.
> - Vì vậy sàng lọc trước sinh (double test, NIPT) nên được tư vấn cho mọi thai phụ, đặc biệt là người mẹ lớn tuổi; kết quả nguy cơ cao cần **chẩn đoán xác định** bằng chọc ối hoặc sinh thiết gai nhau.

> [!cap-nhat] Vì sao noãn "chờ lâu" thì dễ không phân ly? Vai trò của cohesin (bổ sung – kiến thức hiện nay)
> Các chromatid và các NST trong lưỡng trị được "khóa" với nhau bằng một vòng protein tên là **cohesin**. Ở noãn, cohesin được nạp **một lần duy nhất từ thời bào thai** và hầu như không được bổ sung trong suốt thời gian noãn bào nằm chờ ở kỳ đầu I. Theo tuổi, cohesin hao dần; các lưỡng trị lỏng ra, tách sớm hoặc xếp sai trên thoi, nên tỷ lệ noãn lệch bội tăng mạnh sau 35–40 tuổi. Đây là cơ chế được ủng hộ nhiều nhất hiện nay cho "hiệu ứng tuổi mẹ", bên cạnh sự suy yếu của điểm kiểm soát thoi phân bào ở noãn già (nguồn: các tổng quan về mất gắn kết NST theo tuổi ở noãn, ví dụ *Age-related loss of cohesion: causes and effects*, PMC5536066, 2017; Down: bảng nguy cơ theo tuổi mẹ, GLOWM).

## 3. Sự hình thành giao tử ở người

![Hình 3. Quá trình sinh tinh và sinh trứng ở người](giao-tu.svg)

### 3.1. Sự phát sinh tinh trùng

- Tế bào gốc sinh tinh (**tinh nguyên bào**, 2n = 44 + XY) **nguyên phân nhiều lần** để tăng số lượng.
- Từ **tuổi dậy thì**, một số tinh nguyên bào ngừng phân chia, **lớn lên** thành **tinh bào I** (2n kép), rồi bước vào giảm phân. Quá trình này diễn ra **liên tục** từ dậy thì cho đến khi chết.
- **Tinh bào I** → giảm phân I → **2 tinh bào II** (n kép; 22 + X hoặc 22 + Y).
- Mỗi tinh bào II → giảm phân II → 2 **tinh tử** (n đơn). Tổng cộng **4 tinh tử**.
- Tinh tử **biệt hóa** (không phân chia nữa) thành **4 tinh trùng**: 2 mang X, 2 mang Y.

### 3.2. Sự phát sinh trứng

Ở người và động vật có vú nói chung, sinh trứng khác sinh tinh ở nhiều điểm.

1. **Noãn nguyên bào** (2n = 44 + XX) nguyên phân nhiều lần, chỉ trong **thời kỳ bào thai**.
2. Noãn nguyên bào ngừng phân chia, lớn lên thành **noãn bào I**. Noãn bào I đã có từ **giai đoạn phôi muộn** (khoảng **tháng thứ 5** của thai kỳ).
3. Noãn bào I vào giảm phân I. Qua giai đoạn thể kép (diploten), NST có hình **chổi lông**, gọi là **giai đoạn thể lưới** (dictyoten). Tế bào **bị hãm** ở giai đoạn này **nhiều năm**. Sau khi bé gái ra đời, **phần lớn** noãn bào bị thoái hóa.
4. Sau **dậy thì**, mỗi chu kỳ một số noãn bào phát triển, **hoàn tất giảm phân I**, chia không đều thành **noãn bào II** (lớn, n kép) và **cực cầu I** (rất nhỏ). Noãn bào II đi tiếp đến **kỳ giữa II** và **dừng lại**. Đây là lúc **trứng rụng**.
5. Chỉ khi **được thụ tinh**, giảm phân II mới kết thúc: noãn bào II → **noãn cầu** (trứng) + **cực cầu II**. Cực cầu I có thể chia thành 2 cực cầu II.
6. Mỗi tháng rụng **1 trứng**, lần đầu khoảng **13 tuổi**, lần cuối khoảng **50 tuổi**.

> [!cap-nhat] Vốn noãn theo tuổi (bổ sung – kiến thức hiện nay)
> Giáo trình ghi noãn bào I có từ khoảng tháng thứ 5. Các sách phôi thai học hiện nay (Langman) mô tả: noãn nguyên bào bắt đầu biệt hóa thành noãn bào I từ **khoảng tháng thứ 3**; số tế bào mầm đạt **đỉnh khoảng 6–7 triệu ở tháng thứ 5**, rồi thoái hóa nhanh. Lúc sinh còn **khoảng 1–2 triệu** noãn bào I, đến dậy thì còn **khoảng 300.000–400.000**, và cả đời chỉ **khoảng 400–500** noãn được rụng. Đi thi trả lời theo giáo trình.

**Kết quả**: 1 noãn bào I → 4 tế bào đơn bội, nhưng chỉ **1 noãn cầu** thành thục, chứa đủ tế bào chất (chất dự trữ, bào quan) cho phôi. **3 cực cầu** hầu như không có tế bào chất và sẽ thoái hóa. *Vì sao chia không đều?* Để dồn hầu hết tế bào chất vào một trứng duy nhất, đủ nuôi phôi những ngày đầu.

> [!bay] Trứng rụng ở kỳ nào?
> - Trứng rụng là **noãn bào II đang ở kỳ giữa II**, chưa phải giao tử đã hoàn tất giảm phân.
> - Noãn bào I **dừng ở kỳ đầu I** (giai đoạn thể lưới, sau thể kép) từ thời bào thai, **không phải** dừng ở kỳ giữa I.
> - Cực cầu I tách ra **trước** khi rụng trứng; cực cầu II tách ra **sau** khi tinh trùng xâm nhập.

### 3.3. So sánh sinh tinh và sinh trứng

| | **Sinh tinh** | **Sinh trứng** |
|---|---|---|
| Bắt đầu giảm phân | Từ **dậy thì** | Từ **bào thai** (dừng ở kỳ đầu I) |
| Tính liên tục | **Liên tục** đến khi chết | **Gián đoạn**: dừng ở kỳ đầu I hàng chục năm; dừng lần nữa ở kỳ giữa II |
| Kết thúc giảm phân | Không cần chờ thụ tinh | **Chỉ hoàn tất khi được thụ tinh** |
| Phân chia tế bào chất | **Đều** | **Không đều** |
| Sản phẩm của 1 tế bào sinh dục | **4 tinh trùng** | **1 trứng** + 2–3 cực cầu |
| Số lượng | Rất nhiều | Ít; noãn bào **thoái hóa nhiều**, chỉ số ít rụng |
| Bộ NST giao tử | 22 + X hoặc 22 + Y (2 loại) | 22 + X (1 loại) |

> [!ung-dung] Ý nghĩa thực tế
> - **Giới tính của con do tinh trùng quyết định**: tinh trùng X → con gái (XX), tinh trùng Y → con trai (XY).
> - Phụ nữ sinh ra đã có **toàn bộ** vốn noãn bào và vốn này giảm dần theo tuổi. Đây là cơ sở của suy giảm khả năng sinh sản và tăng nguy cơ lệch bội ở mẹ lớn tuổi.
> - Hóa trị, xạ trị có thể làm hỏng các tế bào sinh dục. Vì vậy người bệnh trẻ thường được tư vấn **trữ tinh trùng, trữ trứng** trước điều trị.

## 4. Sự chết tế bào có chương trình (apoptosis)

### 4.1. Khái niệm

Có hai kiểu chết tế bào:

| | **Chết hoại** (hoại tử, necrosis) | **Chết có chương trình** (apoptosis) |
|---|---|---|
| Hoàn cảnh | **Bệnh lý**, ví dụ tế bào thiếu máu nuôi | **Sinh lý**, là một phần bình thường của đời sống tế bào |
| Hình dạng tế bào | **Trương lên**, màng nứt rách, tế bào **vỡ tung** | **Teo lại**, màng **vẫn còn** nhưng sần sùi |
| Nhân | Bị phá hủy cùng tế bào | **Kết đặc** chromatin, rồi vỡ thành mảnh |
| Hậu quả | Lan ra, gây chết cả vùng mô | Từng tế bào riêng lẻ, bị **thực bào** dọn sạch |

Trong cơ thể bình thường, **phân bào** (tăng số tế bào) và **apoptosis** (giảm số tế bào) là hai quá trình **ngược chiều**. Sự cân bằng giữa chúng giữ cho cơ thể và cơ quan có số lượng tế bào và hình dạng bình thường.

### 4.2. Biểu hiện của apoptosis

Giống phân bào, apoptosis là một chuỗi bước liên tục:

1. **Nhận tín hiệu chết.** "Chất thu nhận chết" (thụ thể) trên màng tế bào nhận tín hiệu. Tín hiệu có thể là chất kích thích, tín hiệu sinh hóa, **bức xạ ion hóa, tia cực tím, tia X**.
2. **Hoạt hóa enzym "giết chết".** Chỉ trong vài giây, các enzym bên trong tế bào hoạt hóa lẫn nhau theo kiểu dây chuyền, rồi cùng lúc cắt các thành phần của tế bào:
   - phá hủy **khung xương của nhân** → nhân xẹp, vật chất di truyền **kết đặc**;
   - phá hủy **enzym nhân đôi và enzym sửa chữa ADN**;
   - hoạt hóa enzym **cắt ADN thành những mảnh nhỏ đều nhau**;
   - làm **tan rã khung xương tế bào**;
   - gây **kết dính các tế bào** với nhau (theo giáo trình);
   - chuyển một số **phospholipid từ lớp trong ra lớp ngoài** màng, làm "tín hiệu ăn tôi" thu hút **thực bào**.
3. **Hình thái cuối.** Màng tế bào **sần sùi, lồi ra** thành nhiều thùy; nhân vỡ, các mảnh ADN thoát ra; tế bào vỡ thành những **mảnh** được bọc màng và bị **thực bào** nuốt.

> [!ghi-nho] 7 biểu hiện của tế bào apoptosis (theo giáo trình)
> Teo nhân, kết đặc chromatin – ngừng sửa chữa ADN – dừng nhân đôi ADN – enzym cắt ADN hoạt động – tan rã khung xương tế bào – dính tế bào thành khối – có tín hiệu trên bề mặt cho thực bào.
>
> **Không phải** biểu hiện apoptosis: tế bào trương to, màng rách, vỡ tung (đó là hoại tử); tiếp tục nhân đôi ADN.

**Cơ sở phân tử — gen p53.** Nghiên cứu trên chuột cho thấy gen **p53** cần cho apoptosis khi **ADN bị tổn thương**. Nếu ADN hỏng mà không sửa được, p53 được hoạt hóa và đẩy tế bào vào apoptosis. Nếu **p53 bị đột biến**, tế bào không tự hủy, tiếp tục phân chia và truyền ADN hỏng cho tế bào con. Đây có thể là một cơ chế **phát sinh ung thư**.

> [!cap-nhat] Apoptosis hiểu theo y sinh học hiện nay
> - Các enzym "giết chết" chính là họ **caspase** (protease).
> - Có hai đường khởi phát: **đường ngoại sinh** qua **thụ thể chết** trên màng (Fas, thụ thể TNF) — đúng với "chất thu nhận chết" của giáo trình; và **đường nội sinh** qua **ty thể** (giải phóng cytochrom c), là đường chính khi ADN bị tổn thương do tia xạ, hóa chất. Như vậy tia X, tia cực tím phần lớn gây apoptosis từ **bên trong** tế bào, không nhất thiết qua thụ thể màng.
> - Phospholipid bị chuyển ra mặt ngoài là **phosphatidylserin**.
> - Tế bào apoptosis thực ra **tách khỏi** các tế bào xung quanh. "Dính" mà giáo trình nhắc có lẽ là sự **liên kết chéo protein** trong tế bào chết.
> - Vì tế bào được thực bào dọn trước khi vỡ ra ngoài, apoptosis **không gây viêm**, khác với hoại tử.
> - Apoptosis không chỉ là sinh lý: nó cũng tăng hoặc giảm bất thường trong nhiều bệnh (ví dụ tế bào bị nhiễm virus, bệnh thoái hóa thần kinh, ung thư).
> - **p53** ("người bảo vệ bộ gen") bị đột biến trong khoảng một nửa số ca ung thư ở người. Người mang sẵn một alen *TP53* đột biến từ bố hoặc mẹ (**hội chứng Li-Fraumeni**) mắc nhiều loại ung thư từ khi còn trẻ.
> - Đường ty thể được "cân" bởi họ protein **BCL-2**: có loại chống chết (BCL-2) và loại thúc chết (BAX, BAK). Nhiều tế bào ung thư máu sống dai vì thừa BCL-2; thuốc **venetoclax** (ức chế BCL-2, FDA cấp phép năm 2016 cho bạch cầu lympho mạn) "mở khóa" để chúng tự chết.
> - Các gen điều khiển apoptosis được phát hiện trên giun tròn *C. elegans*; công trình này được **giải Nobel Sinh lý – Y học 2002** (Brenner, Horvitz, Sulston).
>
> Đi thi trả lời theo giáo trình.

### 4.3. Ý nghĩa

Apoptosis là quá trình **sinh lý**. Nó giúp phôi sinh trưởng, phát triển hài hòa, bảo vệ cơ thể và **thay thế mô** ở người trưởng thành.

| Tế bào | Thời gian sống trước khi apoptosis (giáo trình) |
|---|---|
| Tế bào **biểu mô** (mô lát) ống tiêu hóa | **2–3 ngày** |
| Tế bào **biểu bì** da | **2–3 tuần**, sau đó bong ra |
| **Bạch cầu đa nhân trung tính** | **24 giờ** sau khi tạo ra ở tủy xương |

- **Miễn dịch**: theo giáo trình, **bạch cầu lympho** cũng **tự sát** (apoptosis) cùng với tế bào đích mà nó tấn công.
- **Phát triển phôi**: phân bào và apoptosis diễn ra đồng thời để không mô nào phát triển quá nhanh hay quá chậm. Ví dụ, gan của trẻ được giữ ổn định về hình thái cho đến khi trưởng thành.
- **Phối hợp nhanh – chậm**: khi da bị rách, phân bào tăng để làm lành vết thương. Khi da bị **rám nắng**, apoptosis làm bong các tế bào da bị tổn thương, vì những tế bào này có thể thành ung thư.

> [!vi-du] Vì sao cần cả hai?
> Phân bào mà không có apoptosis → tế bào hỏng tích tụ, khối u. Apoptosis quá mức mà phân bào không bù → teo mô (như tế bào thần kinh chết dần trong một số bệnh thoái hóa). Sức khỏe của mô là **thế cân bằng** giữa sinh ra và chết đi.

## 5. Ứng dụng: colchicin và lập karyotype

**Karyotype** (bộ NST) của một người được lập như sau:

1. Lấy máu, nuôi cấy **tế bào lympho** và kích thích chúng phân chia.
2. Thêm **colchicin** (hoặc dẫn chất colcemid). Colchicin gắn vào tubulin, **ngăn tạo thoi vô sắc** → tế bào bị chặn ở **kỳ giữa**, là lúc NST co ngắn tối đa.
3. Xử lý dung dịch **nhược trương** cho tế bào trương lên, NST tản ra; cố định, nhỏ lên lam, nhuộm (Giemsa tạo băng).
4. Chụp, sắp xếp 23 cặp NST theo kích thước, vị trí tâm động, băng nhuộm → phát hiện **lệch bội** (Down 47,+21; Turner 45,X; Klinefelter 47,XXY) và bất thường cấu trúc.

> [!yhct] Alkaloid từ cây tác động lên thoi vô sắc: colchicin, vinca, taxan
> - **Colchicin** có trong cây *Colchicum autumnale* (Tỏi độc, châu Âu; nguồn chiết ban đầu) và cây **Ngót nghẻo** (*Gloriosa superba*, mọc ở Việt Nam; hạt và củ chứa colchicin, là một nguồn chiết xuất). **Cơ chế đã chứng minh**: colchicin gắn **tubulin**, ngăn trùng hợp ống vi thể nên không tạo được **thoi vô sắc**; tế bào đang phân chia dừng ở **kỳ giữa**. Từ đó có ba ứng dụng: (1) **lập karyotype** (mục 5 ở trên; colchicin hoặc dẫn chất colcemid); (2) **gây đa bội** trong chọn giống cây trồng (NST nhân đôi mà tế bào không chia); (3) thuốc trị **gút cấp**: bạch cầu trung tính cần ống vi thể để di chuyển, nên colchicin làm giảm bạch cầu kéo vào khớp và giảm viêm.
> - **Độc tính**: khoảng cách giữa liều điều trị và liều độc của colchicin **rất hẹp**. Ngộ độc gây nôn, tiêu chảy nặng, sau đó suy tủy, suy đa tạng, có thể tử vong. Toàn cây Ngót nghẻo, nhất là **củ**, **rất độc** (đã có ca ngộ độc do ăn nhầm củ). Ngót nghẻo chỉ là nguyên liệu chiết xuất; colchicin chỉ dùng dạng thuốc đã chuẩn hóa liều, theo chỉ định. Không dùng cây tươi, không tự bào chế.
> - **Vinblastin, vincristin** từ cây **Dừa cạn** (*Catharanthus roseus*) cũng ức chế trùng hợp tubulin, dừng phân bào ở kỳ giữa; đây là thuốc **chống ung thư**. Hàm lượng các alkaloid này trong lá rất thấp, nên **uống nước sắc Dừa cạn không thay được hóa trị** và có thể gây độc.
> - **Paclitaxel** (taxol) từ cây **Thông đỏ** (chi *Taxus*) tác động **ngược lại**: làm ống vi thể **quá bền**, không tháo ra được, nên cũng chặn phân bào. Paclitaxel lúc đầu chiết từ vỏ loài thông đỏ Bắc Mỹ (*T. brevifolia*); nay chủ yếu bán tổng hợp từ tiền chất trong lá thông đỏ. Ở Việt Nam có thông đỏ ở Lâm Đồng và một số tỉnh núi cao phía Bắc; đều là cây quý hiếm, cần bảo tồn.
>
> **Mức bằng chứng**: đây là các hoạt chất **tinh khiết** chiết từ cây, liều tính bằng miligam, đã qua thử nghiệm lâm sàng. **Không** suy ra rằng vị thuốc thô (cây tươi, nước sắc) có cùng tác dụng chống ung thư hay trị gút.

## Tóm tắt

| Chủ đề | Điểm then chốt |
|---|---|
| Chu kỳ tế bào | Gian kỳ (G1 – S – G2) + M. G1 biến thiên; S ≈ 7 giờ (nhân đôi ADN + histon); G2 ≈ 3–4 giờ (sửa sai). G0: ngừng chu kỳ (tế bào thần kinh) |
| Nguyên phân | Đầu (NST xoắn, hạch nhân mất) → giữa sớm (màng nhân mất, thoi xuất hiện) → giữa (NST co ngắn tối đa, 1 hàng) → sau (chromatid tách) → cuối. 2n → 2 tế bào 2n |
| Giảm phân I | Kỳ đầu I: sợi mảnh – tiếp hợp – sợi dày (trao đổi chéo) – thể kép – hướng cực. 23 lưỡng trị. Cặp tương đồng tách → 2 tế bào n kép |
| Giảm phân II | Không có pha S; chromatid tách → 4 tế bào n đơn |
| NST/ADN | G1: 2n, 2c → G2: 2n kép, 4c → sau GP I: n kép, 2c → giao tử: n đơn, 1c |
| Sinh tinh | Từ dậy thì, liên tục; 1 tinh bào I → 4 tinh trùng (22 + X hoặc 22 + Y) |
| Sinh trứng | Noãn bào I từ tháng 5 thai, dừng ở thể lưới (kỳ đầu I); rụng ở kỳ giữa II; xong giảm phân khi thụ tinh; 1 trứng + cực cầu |
| Apoptosis | Teo tế bào, màng còn, nhân kết đặc, ADN cắt mảnh đều, thực bào. p53 hỏng → ung thư. Biểu mô ruột 2–3 ngày, biểu bì 2–3 tuần, BC trung tính 24 giờ |
| Ứng dụng | Không phân ly NST → Down (47,+21), tăng theo tuổi mẹ; thuốc ức chế thoi (vinca, taxan, colchicin); colchicin dùng lập karyotype |
