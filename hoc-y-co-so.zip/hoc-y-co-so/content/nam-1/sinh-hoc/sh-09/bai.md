---
title: Cơ sở phân tử của hiện tượng di truyền
thoi-gian: 70 phút
muc-tieu:
- Trình bày được các thí nghiệm chứng minh acid nucleic (ADN, ở một số virus là ARN) là vật chất mang thông tin di truyền.
- Nêu được cấu trúc, đặc điểm của ADN và đặc điểm bộ gen của Prokaryota, Eukaryota.
- Phân loại được ARN; nêu cấu tạo, chức năng của rARN, tARN, mARN, snARN; nêu các đặc điểm của mã di truyền.
- Mô tả được quá trình tái bản ADN, phiên mã (kể cả tạo mARN thuần thục) và dịch mã ở Prokaryota và Eukaryota.
- Giải thích được mô hình operon, cấu trúc một gen Eukaryota và các bước điều chỉnh biểu hiện gen ở Eukaryota.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Vật chất di truyền là **acid nucleic**: ADN (DNA) ở hầu hết sinh vật, **ARN (RNA) ở một số virus** (bằng chứng: Griffith, Avery, Hershey–Chase, virus khảm thuốc lá, chuột chuyển gen).
> 2. ADN = **2 mạch đối song song** xoắn phải, base bổ sung **A=T (2 liên kết hydro), G≡C (3 liên kết hydro)**; chu kỳ xoắn **3,4 nm ≈ 10 cặp base**, đường kính **2 nm**.
> 3. **Tái bản** bán bảo tồn, luôn theo chiều **5'→3'**, cần **ARN mồi**: một mạch liên tục (sợi nhanh), một mạch gián đoạn (đoạn **Okazaki**).
> 4. **Phiên mã** (ADN → ARN) rồi **dịch mã** (mARN → protein) theo **mã bộ ba**: AUG mở đầu; UAA, UAG, UGA kết thúc; mã thoái biến và gần như vạn năng.
> 5. **Điều chỉnh**: Prokaryota (sinh vật nhân sơ) theo **operon** (gen điều chỉnh – chất kìm hãm/hoạt hóa – vị trí vận hành); Eukaryota (sinh vật nhân thực) gen có **exon/intron**, điều chỉnh qua **6 bước** từ ADN đến protein.

## 1. Bằng chứng acid nucleic là vật chất di truyền

Acid nucleic được **Miescher** tách ra từ năm **1869**. Nhưng phải khoảng 50 năm sau người ta mới hiểu vai trò di truyền của nó. Một loạt thí nghiệm kinh điển dưới đây đã trả lời câu hỏi: *gen làm bằng chất gì — protein hay acid nucleic?*

### 1.1. Hiện tượng chuyển thể ở vi khuẩn (Griffith, 1928)

Griffith dùng **phế cầu khuẩn** (*Diplococcus pneumoniae*, nay gọi là *Streptococcus pneumoniae*). Loài này có hai chủng:

| Chủng | Vỏ bọc polysaccharid | Khuẩn lạc | Độc lực |
|---|---|---|---|
| **S** (smooth) | Có | Nhẵn | **Có** — gây chết chuột |
| **R** (rough) | Không | Xù xì | Không |

| Thí nghiệm | Tiêm cho chuột | Kết quả |
|---|---|---|
| 1 | S sống | Chuột **chết** |
| 2 | R sống | Chuột sống |
| 3 | S đã đun nóng cho chết | Chuột sống |
| 4 | **R sống + S chết vì nhiệt** | Một số chuột **chết**; mổ ra phân lập được **vi khuẩn S sống** |

Ở thí nghiệm 4, "cái gì đó" từ xác vi khuẩn S đã biến R thành S. Đặc tính S mới có này **truyền được qua nhiều thế hệ** khi nuôi cấy. Griffith gọi đó là **hiện tượng chuyển thể** (transformation), nhưng ông chưa biết chất gây chuyển thể là gì.

### 1.2. Bản chất chất gây chuyển thể là ADN (Avery, 1944)

**Avery, MacLeod và McCarty** (1944) làm thí nghiệm trong ống nghiệm, không dùng chuột:

- Môi trường nuôi **R** + **ADN tinh khiết của S** → thế hệ sau có cả R và S. S rất ít (khoảng **1/1 triệu**) nhưng giữ tính chất S qua các thế hệ.
- Môi trường nuôi **R** + ADN của S + **deoxyribonuclease** (enzym phân hủy ADN) → **không** có chuyển thể.

*Vì sao thí nghiệm có DNase quan trọng?* Nó loại trừ khả năng một chất lẫn khác (protein, polysaccharid) gây chuyển thể. Phá ADN là mất chuyển thể, nên **ADN chính là chất mang thông tin di truyền**.

### 1.3. Sự sinh sản của phagiơ (Hershey – Chase)

**Phagiơ** (bacteriophage) là virus ký sinh vi khuẩn, hình **nòng nọc** (đầu, đuôi, sợi đuôi). Bên ngoài là **vỏ protein**, trong đầu chứa **ADN**. Khi nhiễm, phagiơ bám vào vi khuẩn, **chỉ bơm ADN vào trong**; vỏ protein nằm lại bên ngoài. Vài phút sau phagiơ mới được tạo ra, làm vỡ vi khuẩn.

Đánh dấu phóng xạ cho thấy:

- ADN đánh dấu **^32^P** → đi **vào** tế bào vi khuẩn.
- Protein đánh dấu **^35^S** → **không** vào.

*Vì sao chọn P và S?* ADN chứa nhiều phospho nhưng không có lưu huỳnh. Protein có lưu huỳnh (trong methionin, cystein) nhưng hầu như không có phospho. Mỗi đồng vị "đánh dấu riêng" một loại phân tử.

### 1.4. Virus khảm thuốc lá — ARN cũng có thể là vật chất di truyền

Virus khảm thuốc lá gồm **vỏ protein** và **lõi ARN** (không có ADN).

- Tiêm riêng protein vỏ vào cây thuốc lá → **không** gây bệnh. Chỉ ARN mới gây bệnh.
- **Thí nghiệm lai**: trộn ARN của chủng này với protein của chủng kia rồi gây nhiễm → bệnh sinh ra (và virus con) **thuộc chủng cho ARN**.

**Kết luận chung**: acid nucleic (ADN **hoặc** ARN) là vật liệu mang thông tin di truyền ở virus và vi khuẩn.

> [!bay]
> - **Griffith** phát hiện **hiện tượng** chuyển thể (1928) nhưng **chưa** biết bản chất. **Avery** (1944) mới chứng minh chất đó là **ADN**.
> - Phagiơ: ^32^P đánh dấu **ADN** (vào trong), ^35^S đánh dấu **protein** (ở ngoài). Đề hay đảo hai đồng vị.
> - Thí nghiệm virus khảm thuốc lá là bằng chứng **ARN** là vật chất di truyền, không phải ADN.

### 1.5. Ở Eukaryota

**Chiết tách và định lượng ADN.** Lượng ADN trong nhân được đo bằng **phản ứng Feulgen** (nhuộm đặc hiệu ADN) kết hợp quang phổ kế. Kết quả rất "đúng kiểu vật chất di truyền":

- Mọi **tế bào sinh dưỡng** của một cơ thể có **lượng ADN bằng nhau**.
- **Giao tử** chỉ có **một nửa** lượng đó.
- Tế bào **sắp phân chia** có lượng ADN **gấp đôi** (xem bài *Phân chia tế bào*).

**Chuột chuyển gen.**

- *Thí nghiệm 1*: lấy trứng chuột vừa thụ tinh (khi **tiền nhân đực và cái chưa hợp nhất**), **vi tiêm ADN tinh khiết** vào tiền nhân đực. ADN gắn vào một vị trí ngẫu nhiên trong bộ gen hợp tử. Nuôi đến giai đoạn **phôi dâu**, rồi cấy vào tử cung chuột mẹ đã được tiêm hormon. Kiểm tra chuột con bằng **Southern blot**: khoảng **10–30%** chuột con mang đoạn ADN được tiêm. Gen được truyền tiếp cho đời sau như một gen trội theo Mendel.
- *Thí nghiệm 2*: tiêm **gen hormon sinh trưởng của chuột cống** vào trứng chuột nhắt. Gen hoạt động mạnh, tạo nhiều hormon. Giáo trình ghi chuột chuyển gen nặng **gấp 3 lần** chuột thường.

Như vậy, đưa một đoạn ADN vào là cơ thể **biểu hiện tính trạng do đoạn ADN đó quy định** — ADN là vật chất di truyền ở cả Eukaryota.

## 2. Acid nucleic

Gen là vật chất di truyền ở mức phân tử. Ở **đa số** sinh vật gen là **ADN**; chỉ **một số virus** có gen là **ARN**.

### 2.1. Cấu trúc ADN (acid deoxyribonucleic)

#### a) Cấu trúc bậc một — chuỗi polynucleotid

ADN là **polyme**, đơn phân là **nucleotid**. Mỗi nucleotid gồm 3 phần:

- Đường **deoxyribose** C~5~H~10~O~4~ (thiếu một O ở C2' so với ribose).
- **Acid phosphoric** H~3~PO~4~.
- Một trong 4 **base**: **adenin (A), guanin (G)** thuộc nhóm **purin** (2 vòng); **cytosin (C), thymin (T)** thuộc nhóm **pyrimidin** (1 vòng).

Các nucleotid nối nhau bằng **liên kết 3'–5' phosphodiester**: một phân tử acid phosphoric nối **–OH ở C3'** của đường này với **–OH ở C5'** của đường kế tiếp. Vì vậy mỗi mạch có **hướng**: một đầu **5'-phosphat** tự do, đầu kia **3'-OH** tự do. Quy ước viết trình tự từ 5' sang 3', ví dụ **5'-CCGATTACG-3'**.

#### b) Cấu trúc bậc hai — chuỗi xoắn kép Watson – Crick

Năm **1953**, **Watson và Crick** đề xuất mô hình xoắn kép, dựa trên ảnh nhiễu xạ tia X của **Franklin và Wilkins**. Hình dung ADN như một **cái thang dây xoắn**:

- Hai "tay vịn" là **khung đường – phosphat** nằm phía ngoài.
- Các "bậc thang" là **cặp base** nằm phía trong, mỗi cặp gồm **1 purin + 1 pyrimidin**.
- Hai mạch chạy **ngược chiều** nhau (**đối song song**): một mạch 5'→3', mạch kia 3'→5'.
- Hai mạch gắn nhau theo **nguyên tắc bổ sung**: **A với T bằng 2 liên kết hydro**, **G với C bằng 3 liên kết hydro**.

| Thông số (ADN dạng B) | Giá trị |
|---|---|
| Đường kính | **2 nm** |
| Một chu kỳ xoắn | **3,4 nm**, khoảng **10 cặp base** (chính xác hơn 10,4) |
| Khoảng cách giữa hai cặp base | **0,34 nm** |

![Hình 1. ADN xoắn kép: hai mạch đối song song, bắt cặp A=T và G≡C](xoan-kep.svg)

*Vì sao purin luôn bắt cặp với pyrimidin?* Purin to (2 vòng), pyrimidin nhỏ (1 vòng). Cặp "to + nhỏ" có chiều rộng bằng nhau ở mọi vị trí, nên đường kính phân tử luôn đều 2 nm. Cặp purin–purin quá rộng, pyrimidin–pyrimidin quá hẹp.

**Hệ quả của nguyên tắc bổ sung (quy luật Chargaff):**

- **A = T** và **G = C**, nên **A + G = T + C**: tổng purin bằng tổng pyrimidin, tỷ số **(A+G)/(T+C) = 1** ở mọi ADN kép.
- Tỷ số **(A+T)/(G+C) thay đổi tùy loài** nhưng **hằng định trong một loài**. Ví dụ theo giáo trình: tinh trùng người 1,67; tuyến ức và gan người 1,54; gan bò đực 1,57; nấm men 1,80; phế cầu khuẩn 1,59; *E. coli* 1,00; thể thực khuẩn T2 1,87.
- Mỗi mạch mang trình tự **khác** mạch kia nhưng **suy ra được** từ mạch kia. Đây là cơ sở của tái bản.

> [!bay]
> - Tỷ số **hằng định = 1** là **(A+G)/(T+C)**. Tỷ số **đặc trưng loài** là **(A+T)/(G+C)**. Hai tỷ số rất dễ bị đảo trong đề.
> - Cặp G–C có 3 liên kết hydro nên **bền hơn** A–T. ADN giàu G–C cần nhiệt độ cao hơn mới tách hai mạch.
> - Quy luật A = T, G = C chỉ đúng với ADN **mạch kép**. ADN của một số virus là mạch đơn, không tuân theo.

#### c) Các dạng khác nhau của ADN

| Dạng | Chiều xoắn | Đường kính | Cặp base/chu kỳ | Một chu kỳ | Ghi chú |
|---|---|---|---|---|---|
| **B** | **Phải** | 2 nm | 10,4 | 3,4 nm | Dạng Watson–Crick, phổ biến trong tế bào |
| **A** | Phải | **2,6 nm** (to nhất) | 11 | 2,8 nm | Cặp base nghiêng khoảng 20° so với mặt phẳng ngang |
| **Z** (zigzag) | **Trái** | **1,8 nm** (mảnh nhất) | 12 | 4,5 nm | Đoạn ngắn 12–24 nucleotid ở vùng điều hòa; có thể ảnh hưởng biểu hiện gen |
| **H** | — | — | — | — | Một mạch polypurin bắt cặp với mạch polypyrimidin, có đoạn **xoắn ba** (triple helix); gặp ở vùng điều hòa gen Eukaryota |

Dạng B có thể đổi hình thể vì đường deoxyribose khá linh hoạt.

> [!bay] Chỉ có ADN dạng **Z** xoắn **trái**. Dạng A và B đều xoắn phải. Mẹo nhớ: **A** to nhất (2,6 nm), **Z** mảnh nhất (1,8 nm), **B** ở giữa (2 nm).

#### d) Các bậc cấu trúc cao hơn

- ADN nhân **Eukaryota**: xoắn kép **thẳng**, có hai đầu tự do (cuộn quanh histon thành nhiễm sắc thể [NST] — xem bài *Nhân tế bào Eukaryota*).
- ADN **Prokaryota** (vi khuẩn, nhiều virus): xoắn kép **vòng**, gấp khúc tạo cấu trúc không gian ba chiều.
- ADN **ty thể, lạp thể**: cũng là xoắn kép **vòng**, giống ADN vi khuẩn.

### 2.2. Đặc điểm của ADN

1. **Bảo quản và truyền đạt thông tin di truyền** bằng trình tự base. Một đoạn dài n base có **4^n^** trình tự khả dĩ. Vì vậy chỉ 4 "chữ cái" vẫn mã hóa được vô số thông tin. Toàn bộ trình tự ADN của một cơ thể gọi là **bộ gen** (genome).
2. **Biến tính và hồi tính.** *Biến tính* (denaturation): liên kết hydro đứt, hai mạch tách rời, do **nhiệt** (gần 100 °C), **kiềm**, **formamid, urê**. *Hồi tính* (renaturation): hạ nhiệt từ từ, chỉnh nồng độ muối thích hợp, các mạch đơn bắt cặp bổ sung trở lại. Đây là cơ sở của kỹ thuật **lai phân tử**.
3. **Tái bản** theo kiểu **bán bảo tồn**: mỗi ADN con gồm **một mạch cũ + một mạch mới**.
4. **Phiên mã** tạo ra ARN.
5. **Có thể bị đột biến**: sai sót khi tái bản được sao chép sang mọi thế hệ tế bào sau. Hậu quả tùy vị trí; có đột biến "**im lặng**", không đổi chức năng protein.

**Kích thước bộ gen.** Virus nhỏ nhất chỉ vài nghìn cặp base. *E. coli* khoảng **4 × 10^6^** cặp base (ước tính **3000 gen**). Người khoảng **3 × 10^9^** cặp base (giáo trình ghi **31.780 gen**). Kích thước ADN ở Eukaryota **không tương quan** với độ lớn hay mức tiến hóa: một số thực vật và lưỡng cư có ADN lớn **gấp trăm lần** người.

> [!ung-dung] PCR — "tái bản ADN trong ống nghiệm"
> Xét nghiệm **PCR** (phản ứng chuỗi polymerase) dùng đúng các đặc điểm trên. Đun khoảng **94–95 °C** để **biến tính** ADN; hạ nhiệt để **mồi** (primer) **hồi tính**, tức bắt cặp bổ sung với đoạn cần tìm; rồi **ADN polymerase chịu nhiệt** kéo dài mồi theo chiều 5'→3'. Lặp 30–40 chu kỳ, một đoạn ADN được nhân lên hàng tỷ lần. PCR dùng chẩn đoán virus (HBV, HIV, SARS-CoV-2), phát hiện đột biến gây bệnh, xác định huyết thống. Với virus ARN, phải chuyển ARN thành ADN trước bằng **enzym phiên mã ngược** (RT-PCR, xem mục 3.1.3).

> [!cap-nhat] Số gen người và kích thước bộ gen
> Giáo trình ghi bộ gen người có **31.780 gen**; *E. coli* khoảng 3000 gen. **Hiện nay**:
> - Số gen **mã hóa protein** của người chỉ khoảng **19.000–20.000**. Bản chú giải GENCODE 49 (2025) đếm được **≈19.400** gen mã hóa protein, cộng thêm **≈36.000 gen ARN không mã hóa dài** (lncARN), **≈7.500 gen ARN nhỏ** (xem mục 2.5) và **≈14.700 gen giả** (pseudogene). Con số còn được tinh chỉnh qua từng phiên bản.
> - Năm **2022**, nhóm **T2T** (Telomere-to-Telomere) công bố trình tự **hoàn chỉnh từ đầu mút đến đầu mút** đầu tiên của bộ gen người (T2T-CHM13), dài **≈3,055 tỷ bp** (bộ đơn bội), lấp nốt **≈8%** mà bản "hoàn thành" năm 2003 còn để trống (chủ yếu tâm động, nhánh ngắn NST tâm đầu, đoạn lặp).
> - *E. coli* K-12 có bộ gen ≈**4,6 × 10^6^ bp** với ≈**4.300 gen** mã hóa protein.
>
> Đi thi trả lời theo giáo trình. (Nguồn: GENCODE/Ensembl 2025; Nurk và cs., *Science* 2022.)

### 2.3. Đặc điểm của bộ gen

- **Prokaryota**: gen là những đoạn ADN **liên tục**, hầu như toàn bộ ADN đều mã hóa protein.
- **Eukaryota**: bộ gen gồm mọi đơn vị di truyền trong **bộ NST đơn bội**, cộng **gen ngoài nhân** (ty thể; lạp thể ở thực vật). Gen gồm đoạn **mã hóa (exon)** xen kẽ đoạn **không mã hóa (intron)**.

Theo mức độ lặp lại, ADN Eukaryota chia 3 loại:

| Loại trình tự | Tỷ lệ (giáo trình) | Đặc điểm |
|---|---|---|
| **Duy nhất** (không lặp) | ≈**10%** bộ gen sinh vật bậc cao | Là các **gen mã hóa protein**, đặc trưng cho từng gen |
| **Lặp lại nhiều lần** | **10–15%** bộ gen động vật có vú | **Không mã hóa**; tập trung ở **tâm động** và **đầu mút** NST. Đơn vị lặp ngắn **5–10 bp** (chiếm đa số, tới hàng trăm triệu bản sao) hoặc dài hơn **100–200 bp**. Có thể giúp NST di chuyển trên thoi (tâm động) và sao chép trọn vẹn đầu mút |
| **Lặp lại trung bình** | **25–40%** bộ gen người | Đơn vị lặp **100–1000 bp**, **phân tán** khắp bộ gen. Có thể không mã hóa, nhưng cũng có thể là **gen rARN, tARN** và một số gen khác |

**Gen nhảy (transposon).** Đoạn ADN có thể **chèn vào hoặc rời khỏi** một vị trí trong bộ gen, làm thay đổi hoạt động gen. Phát hiện đầu tiên ở *E. coli*, sau đó ở cả động vật và thực vật.

- Transposon vi khuẩn có nguồn gốc **ADN**.
- Phần lớn transposon Eukaryota bắt nguồn từ **ARN**: ARN được chép ngược thành ADN rồi chèn vào bộ gen, theo cơ chế giống **retrovirus**. Vì vậy gọi là **retroposon**. Có 2 nhóm: nguồn gốc từ **ARN của tế bào**, và nguồn gốc từ **retrovirus**.

**Gen gối nhau (overlapping genes).** Hai hay nhiều gen **dùng chung một phần trình tự ADN**. Gặp ở virus và sinh vật bậc cao. Ví dụ của giáo trình: gen **calcitonin/neuropeptid** có **6 exon**. Ghép nối exon theo hai cách khác nhau cho hai mARN, từ đó tạo hai protein khác nhau: **calcitonin** (ở tuyến giáp) và một **neuropeptid** (ở mô thần kinh).

> [!vi-du] Một gen — nhiều protein
> Ví dụ calcitonin/neuropeptid ngày nay thường được gọi là **ghép nối thay thế** (alternative splicing). Neuropeptid đó là **CGRP**, một chất giãn mạch mạnh liên quan đến cơn **đau nửa đầu (migraine)**. Thuốc kháng thể đơn dòng chặn CGRP hoặc thụ thể của nó hiện được dùng để **dự phòng migraine**. Khoảng **95% gen người có nhiều exon** được ghép nối thay thế. Nhờ vậy khoảng 20.000 gen tạo ra số loại protein lớn hơn nhiều.
>
> *Liên hệ lâm sàng (bổ sung – kiến thức hiện nay):* thuốc **nusinersen** (oligonucleotid đối nghĩa) trị **teo cơ tủy sống** hoạt động bằng cách **sửa cách ghép nối** của gen *SMN2*, giúp giữ lại exon 7 để tạo protein SMN có chức năng.

> [!cap-nhat] Bộ gen người: phần mã hóa protein rất nhỏ
> Giáo trình ghi trình tự duy nhất (gen mã hóa protein) khoảng 10%. **Hiện nay** biết rằng các **exon mã hóa protein** chỉ chiếm khoảng **1–2%** bộ gen người. Khoảng **một nửa** bộ gen là trình tự lặp lại, phần lớn có nguồn gốc từ **transposon/retroposon** (LINE, SINE như *Alu*…).
>
> Phần còn lại không phải "rác" hoàn toàn: dự án **ENCODE** (công bố lớn năm 2012) lập bản đồ các vùng điều hòa (promoter, enhancer, vị trí gắn yếu tố phiên mã) và báo cáo khoảng **80%** bộ gen có "hoạt tính hóa sinh" (được phiên mã hoặc gắn protein). Con số 80% này **gây tranh cãi**: "có hoạt tính" chưa chắc là "có chức năng"; nhiều nhà khoa học ước chỉ khoảng **10%** bộ gen thực sự chịu chọn lọc. Đi thi trả lời theo giáo trình. (Nguồn: ENCODE Consortium, *Nature* 2012.)

### 2.4. Cấu tạo ARN (acid ribonucleic)

**Bậc một.** ARN là polyme của **ribonucleotid**. Mỗi ribonucleotid gồm acid phosphoric, đường **ribose** C~5~H~10~O~5~ và base. 4 base chủ yếu: **A, G** (purin) và **C, U (uracil)** (pyrimidin). ARN còn có một số **base hiếm**: **uridin giả** (pseudouridin), ribothymidin, inosin… Tỷ lệ base hiếm ở ARN **nhiều hơn** ở ADN. Base gắn vào **C1'** của đường. Các ribonucleotid nối bằng cầu **3'–5' phosphodiester**, tạo chuỗi polyribonucleotid.

ARN thường là **mạch đơn**, dài khoảng **50–6000** ribonucleotid.

**Bậc hai, bậc ba.** Mạch đơn ARN có thể **gập lại**, các đoạn bổ sung bắt cặp với nhau (**A–U, G–C**), tạo những "kẹp tóc". Gấp khúc tiếp tạo cấu trúc bậc ba phức tạp.

| | ADN | ARN |
|---|---|---|
| Đường | Deoxyribose | Ribose |
| Base | A, G, C, **T** | A, G, C, **U** |
| Số mạch | Thường **2 mạch** | Thường **1 mạch** (có đoạn tự bắt cặp) |
| Base hiếm | Ít | Nhiều hơn |
| Kích thước | Rất lớn | 50–6000 nucleotid |

### 2.5. Phân loại ARN

**ARN di truyền.** Mang thông tin di truyền "bậc một" (thay cho ADN) ở **đa số virus thực vật**, một số virus động vật và một số thể thực khuẩn. Có thể là **mạch đơn hoặc mạch kép**.

**ARN không di truyền.** Được **phiên mã từ ADN** trong tế bào. Mỗi loại được tổng hợp từ gen riêng (gọi là rADN, tADN, mADN).

| Loại | Tỷ lệ ARN tế bào | Đặc điểm chính | Chức năng |
|---|---|---|---|
| **rARN** | **~80%** (nhiều nhất) | Kẹp tóc dài ngắn khác nhau; có ở ribosom, ty thể, lục lạp | **Cấu trúc** ribosom; một số rARN có chức năng **xúc tác** |
| **tARN** | **10–15%** | ≈**75 nucleotid**; bậc hai hình **lá ba chẽ**, gấp lại thành bậc ba (hình chữ L) | **Vận chuyển acid amin** (amino acid) đến ribosom và đặt đúng chỗ |
| **mARN** | **5–10%** (ít nhất) | Dài rất thay đổi (500–6000 nucleotid ở *E. coli*) | **Mang thông tin** từ ADN để tổng hợp protein |
| **snARN** (ARN nhỏ trong nhân) | — | **90–300 nucleotid**, kết hợp protein thành **snRNP** (U1, U2, U4, U5, U6) | **Cắt intron, nối exon** tạo ARN thuần thục |

#### a) rARN và ribosom

- Ribosom **Prokaryota**: **70S** = phân đơn vị lớn **50S** + nhỏ **30S**.
- Ribosom **Eukaryota**: **80S** = lớn **60S** + nhỏ **40S**.

> [!bay] 50 + 30 ≠ 70 và 60 + 40 ≠ 80. "S" (Svedberg) là đơn vị **hệ số lắng** khi ly tâm, phụ thuộc cả khối lượng lẫn hình dạng, nên **không cộng được**.

#### b) tARN — "người phiên dịch"

Hai vị trí quan trọng nhất:

- **Vị trí gắn acid amin**: trình tự **CCA ở đầu 3'**.
- **Vị trí đối mã** (anticodon): bộ ba base **bắt cặp bổ sung** với mã tương ứng trên mARN; **đặc hiệu** cho từng tARN.

Ngoài ra có **vòng D** (chứa **dihydrouridin**) và **vòng TψC** (thymin – pseudouridin – cytosin). Phân loại tARN dựa trên độ dài **vòng thay đổi**: khoảng 80% tARN có vòng này dài 4–5 nucleotid, số còn lại dài tới khoảng 20 nucleotid.

Mỗi tARN chỉ gắn **tạm thời** với **một** acid amin nhất định nhờ enzym **aminoacyl-tARN synthetase**, enzym này **đặc hiệu cho từng acid amin**. Có **trên 60 loại tARN** cho khoảng **20 acid amin**, nên một acid amin có thể được vài loại tARN chở. Số gen tARN: **40–80** ở Prokaryota; **520–1400** ở Eukaryota, xếp thành chùm rải rác trên các NST.

#### c) mARN — khác nhau giữa Prokaryota và Eukaryota

| | Prokaryota | Eukaryota |
|---|---|---|
| Số chuỗi polypeptid mã hóa | **Vài chuỗi** (mARN đa cistron) | **Một chuỗi** |
| Xử lý sau phiên mã | **Không**; dịch mã **ngay** (cả khi đang phiên mã) | ARN tiền thân phải qua 3 bước: **gắn mũ 5'**, **cắt intron – nối exon**, **gắn đuôi poly A 3'** |

- **Mũ 5'**: 7-methylguanosin (giáo trình ghi *7 methylguanozin triphosphat*). Vai trò: **khởi đầu dịch mã** và **bảo vệ** ARN khỏi bị phân hủy.
- **Đuôi poly A 3'**: giúp mARN **ra khỏi nhân** vào tế bào chất và **bảo vệ** mARN khi dịch mã.

> [!cap-nhat] ARN không mã hóa — không chỉ có rARN, tARN, snARN
> Giáo trình nêu các ARN chính là rARN, tARN, mARN, snARN. **Hiện nay** biết thêm nhiều ARN không mã hóa có chức năng **điều hòa gen**:
> - **microARN (miARN)**, dài khoảng **22 nucleotid**, bắt cặp (thường ở vùng 3'-UTR) với mARN đích làm **giảm dịch mã** hoặc làm mARN bị phân hủy — tức điều hòa gen **sau phiên mã**. miARN đầu tiên (*lin-4*) được **Victor Ambros** phát hiện năm **1993** ở giun tròn *C. elegans*; **Gary Ruvkun** chứng minh nó ức chế mARN *lin-14*, và năm 2000 tìm ra *let-7* được bảo tồn ở cả người. Hai ông nhận **giải Nobel Y học 2024**. Người có khoảng **2.000 gen miARN**; mỗi miARN điều hòa hàng trăm mARN, rối loạn miARN liên quan ung thư và nhiều bệnh khác.
> - **siARN** gây **can thiệp ARN** (RNA interference). Cơ chế này đã thành thuốc: ví dụ **patisiran** (siARN) làm giảm tổng hợp protein transthyretin đột biến trong bệnh **amyloid do transthyretin di truyền**.
> - **ARN không mã hóa dài (lncARN)**, ví dụ **XIST** làm bất hoạt một NST X ở nữ.
>
> Ribosom cũng đã được chứng minh là một **ribozym**: phản ứng tạo liên kết peptid do **rARN** xúc tác, không phải do protein.

## 3. Chức năng của acid nucleic

### 3.1. Tái bản ADN

Tái bản xảy ra **trước khi tế bào phân chia** (pha S). Hai mạch mở xoắn, **mỗi mạch làm khuôn** cho một mạch mới theo nguyên tắc bổ sung. Kết quả là hai ADN con, mỗi phân tử gồm một mạch cũ và một mạch mới (**bán bảo tồn**).

**Nguyên liệu và thành phần:** mạch khuôn; 4 loại **deoxyribonucleosid triphosphat** (dATP, dGTP, dTTP, dCTP); protein gắn đặc hiệu; các enzym.

> [!ghi-nho] Quy tắc vàng: luôn 5' → 3'
> **ADN polymerase chỉ gắn nucleotid mới vào đầu 3'-OH tự do** có sẵn. Vì vậy:
> 1. Mạch mới luôn kéo dài theo chiều **5'→3'** (đọc mạch khuôn theo chiều 3'→5').
> 2. ADN polymerase **không tự bắt đầu** được, cần **ARN mồi** (do primase tổng hợp) để có đầu 3'-OH đầu tiên.
> 3. Hai mạch khuôn ngược chiều nhau, nên ở chạc tái bản **một mạch mới tổng hợp liên tục**, **mạch kia gián đoạn**.

**ADN polymerase ở Prokaryota:**

| Enzym | Chức năng (theo giáo trình) |
|---|---|
| **ADN polymerase III** | **Enzym chính** tổng hợp mạch mới |
| **ADN polymerase I** | **Sửa chữa** ADN, **loại bỏ ARN mồi** và lấp khoảng trống |
| ADN polymerase II | Chưa rõ; xuất hiện cùng lúc với pol I |

#### a) Tái bản ở Prokaryota

**Tháo xoắn.** Trước khi tái bản, ADN siêu xoắn được tháo xoắn nhờ **topoisomerase** (có 2 loại: **topoisomerase I và II**).

**Giai đoạn khởi đầu.**

- **Protein SSB** (protein gắn sợi đơn) xác định **điểm khởi đầu** tái bản và **ngăn hai sợi đơn dính lại**.
- **ADN helicase** gắn với SSB, **mở xoắn** kép, tạo **chạc chữ Y** (giáo trình gọi là *rĩa chẽ hai*, *rĩa tái bản*).
- Helicase + **ADN primase** tạo **thể khởi đầu (primosome)**. Thể này chạy trên **sợi chậm**, tới đâu tổng hợp **ARN mồi** tới đó.
- **Hai phân tử ADN polymerase III** giống hệt nhau gắn vào chạc: một ở **sợi nhanh**, một ở **sợi chậm**.

**Giai đoạn kéo dài.**

- **Sợi nhanh** (leading strand): tổng hợp **liên tục**. ADN polymerase III được **"cái kẹp"** protein giữ cho trượt trên khuôn, tới đâu tổng hợp tới đó theo chiều 5'→3', **cùng chiều** với chạc tái bản đang mở.
- **Sợi chậm** (lagging strand): tổng hợp **gián đoạn** thành từng đoạn ngắn gọi là **đoạn Okazaki**, mỗi đoạn bắt đầu từ một ARN mồi. Sợi chậm phải **gấp khúc** lại để polymerase làm việc. Mỗi đơn vị (mồi + đoạn Okazaki) dài khoảng **1000–2000 nucleotid ở vi khuẩn** và **100–200 nucleotid ở Eukaryota**.

**Giai đoạn kết thúc.**

- Trên sợi chậm, **ADN polymerase I** nhận ra và **loại bỏ ARN mồi** (nó nhận biết được đoạn lai ARN/ADN), để lại các **khoảng trống** (gap).
- ADN polymerase I **lấp khoảng trống**, rồi **ADN ligase** (enzym nối) **nối các đoạn** thành mạch liền.
- Trên sợi nhanh, **tín hiệu kết thúc** báo dừng tổng hợp.

![Hình 2. Chạc tái bản: sợi nhanh tổng hợp liên tục, sợi chậm tổng hợp gián đoạn thành các đoạn Okazaki](chac-tai-ban.svg)

> [!bay]
> - "Gián đoạn" là do **chiều 5'→3'** của polymerase, **không** phải do sợi chậm thiếu nucleotid hay thiếu enzym.
> - **Primase** tổng hợp **ARN** mồi (không phải ADN mồi). **Pol I** loại mồi, **ligase** nối. Pol III **không** loại mồi.
> - Đoạn Okazaki ở **vi khuẩn dài hơn** (1000–2000) so với Eukaryota (100–200).
> - Tái bản theo **hai hướng** từ điểm khởi đầu: mỗi đơn vị tái bản có 2 chạc chạy ngược nhau. Ở mỗi chạc đều có một sợi nhanh và một sợi chậm.

> [!cap-nhat] Chi tiết khởi đầu ở vi khuẩn
> Theo hiểu biết hiện nay, **điểm khởi đầu** (oriC) ở *E. coli* được nhận biết bởi protein **DnaA**; **SSB** chủ yếu có vai trò **giữ sợi đơn ổn định**. Topoisomerase II của vi khuẩn (**gyrase**) tháo siêu xoắn dương phía trước chạc. **ADN polymerase II** (giáo trình ghi chưa rõ chức năng) nay biết chủ yếu tham gia **sửa chữa ADN** và tái khởi động chạc tái bản bị đình trệ. Đi thi trả lời theo giáo trình (SSB xác định điểm khởi đầu).

#### b) Tái bản ở Eukaryota

**Giống Prokaryota** ở 4 nguyên tắc: **hai hướng**; theo chiều **5'→3'**; **một sợi liên tục, một sợi gián đoạn**; **cần ARN mồi**.

**Khác Prokaryota:**

- ADN rất lớn nên tái bản bắt đầu **đồng thời ở nhiều điểm khởi đầu** (Prokaryota chỉ **một** điểm).
- Có **nhiều loại ADN polymerase** hơn:

| ADN polymerase Eukaryota | Chức năng theo giáo trình |
|---|---|
| **α** (gắn với primase) | Tổng hợp **ARN mồi** cho mạch chậm; **không** có hoạt tính exonuclease (không sửa sai) |
| **β** | Giống **pol I** của Prokaryota: tổng hợp kèm sửa sai, hoàn chỉnh mạch mới sau khi loại mồi |
| **γ** | Ở **ty thể** |
| **δ** | Gần giống **pol III** của Prokaryota: tổng hợp mạch mới (đoạn Okazaki) |
| **ε** | Mới phát hiện, vai trò chưa rõ |

Các protein hỗ trợ: **kháng nguyên nhân tế bào đang phân chia** (PCNA — hoạt hóa pol δ và ε), **nhân tố sao chép A và C** (RF-A, RF-C — cần cho pol α và δ).

**Mô hình của giáo trình:** topoisomerase và RF-A tháo xoắn → trên mạch chậm, pol α + RF-A tổng hợp **ARN mồi ≈10 nucleotid** → pol α + RF-C nối dài thêm **~20 nucleotid** → PCNA chặn pol α lại, cho **pol δ** gắn vào tổng hợp đoạn Okazaki → pol α được giải phóng, chuyển sang mạch đối diện tổng hợp liên tục.

> [!cap-nhat] Phân công ADN polymerase ở Eukaryota
> **Hiện nay**: **pol ε** tổng hợp chủ yếu **mạch liên tục (sợi nhanh)**; **pol δ** tổng hợp **mạch gián đoạn**; **pol α–primase** chỉ làm mồi (ARN + một đoạn ADN ngắn). **Pol β** chủ yếu tham gia **sửa chữa ADN** (cắt bỏ base hỏng), không phải enzym tái bản chính. Mồi ARN được loại bỏ chủ yếu nhờ RNase H và nuclease FEN1, sau đó **ligase** nối. **PCNA** là "cái kẹp" hình vòng giữ polymerase bám vào ADN. Đi thi trả lời theo giáo trình.

> [!vi-du] Vấn đề đầu mút NST và telomerase
> Ở đầu mút ADN thẳng, khi ARN mồi cuối cùng của sợi chậm bị loại bỏ thì **không còn đầu 3'-OH** phía trước để lấp chỗ trống. Vì vậy mỗi lần tái bản, NST có xu hướng **ngắn đi một chút**. Đây là lý do giáo trình nói trình tự lặp ở đầu mút có thể giúp "sao chép toàn vẹn" đầu mút. Enzym **telomerase** (một enzym phiên mã ngược mang sẵn khuôn ARN) kéo dài đầu mút. Tế bào sinh dục và tế bào gốc có telomerase. Phần lớn tế bào sinh dưỡng có rất ít, nên đầu mút ngắn dần theo tuổi. Đa số tế bào ung thư **tái hoạt hóa telomerase**, nhờ vậy phân chia vô hạn.

#### c) Tổng hợp ADN nhờ phiên mã ngược

Năm **1970**, **Baltimore và Temin** phát hiện ở virus ARN một enzym tổng hợp **ADN từ khuôn ARN**: **ADN polymerase phụ thuộc ARN**, tức **enzym phiên mã ngược** (reverse transcriptase).

=> ARN → (ADN polymerase phụ thuộc ARN) → ADN

Enzym này được tìm thấy đầu tiên ở **virus gây ung thư**, sau đó cả ở **mô bình thường**. Nhờ nó, từ phân tử lai ARN–ADN tạo ra ADN kép mang thông tin sao từ ARN. Phát hiện này cho thấy thông tin **có thể đi ngược** từ ARN về ADN.

> [!ung-dung] Phiên mã ngược trong lâm sàng
> - **HIV** là retrovirus. Nhóm thuốc **ức chế enzym phiên mã ngược** (zidovudin, tenofovir, lamivudin…) là trụ cột điều trị HIV. Tenofovir và lamivudin cũng ức chế enzym tương tự của **virus viêm gan B**.
> - Trong phòng xét nghiệm, enzym phiên mã ngược dùng để làm **RT-PCR** phát hiện virus ARN.

### 3.2. Phiên mã (tổng hợp ARN)

**Phiên mã** là quá trình dùng **ADN làm khuôn** để tạo ra các loại ARN.

#### a) Phiên mã ở Prokaryota

**Chỉ có một loại ARN polymerase** tổng hợp mọi loại ARN. Enzym ở *E. coli* là phức hợp lớn (giáo trình ghi khối lượng phân tử *500.000 KDa*; thực tế khoảng **500 kDa**), gồm 5 loại chuỗi: **α, β, β', ω và σ (sigma)**.

- **Lõi enzym** gồm **2 chuỗi α**, β, β' và ω; theo giáo trình β, β', ω **xúc tác** tổng hợp ARN.
- **Chuỗi σ** gắn **tạm thời** vào lõi, giúp enzym **nhận ra vùng khởi đầu** để bắt đầu phiên mã. σ khác nhau ở các vi khuẩn. Ở *E. coli*, **σ70** khởi đầu phiên mã đa số gen; **σ28** khởi đầu gen protein cấu tạo **roi**.

**Giai đoạn khởi đầu.** ARN polymerase trượt dọc ADN đến khi gắn vào **vùng khởi đầu (promoter)**, dài khoảng **20–200 bp**. Trong promoter có **vùng −35 và −10** (cách điểm bắt đầu phiên mã 35 và 10 bp về phía trước), chứa các **"hộp khởi đầu"** gần giống nhau ở mọi vi khuẩn. Một đoạn ADN ngắn tháo xoắn, **chỉ một mạch** làm khuôn. Nucleotid đầu tiên thường là **ATP hoặc GTP**. Khi ARN dài khoảng **10 nucleotid**, enzym đổi cấu hình, **σ được giải phóng**, kết thúc giai đoạn khởi đầu.

**Giai đoạn kéo dài.** Lõi enzym gắn thêm **nhân tố kéo dài** (elongation factor), thành phức hợp phiên mã hoạt động. ARN được kéo dài theo chiều **5'→3'**. Phía trước vùng phiên mã hình thành siêu xoắn dương, phía sau là siêu xoắn âm.

**Giai đoạn kết thúc.** Có hai cách:

- **Phụ thuộc yếu tố Rho (ρ)**: protein Rho gắn vào ARN, báo hiệu dừng.
- **Không cần Rho**: trên ADN khuôn có **tín hiệu kết thúc** (vùng có tỷ lệ base đặc trưng); gặp vùng này enzym dừng lại.

ARN tách khỏi khuôn, hai mạch ADN xoắn lại, enzym được giải phóng cho chu kỳ mới. **mARN Prokaryota được dùng ngay** để dịch mã.

> [!ung-dung] Kháng sinh tác động lên phiên mã và tái bản vi khuẩn
> - **Rifampicin** (thuốc chống lao chủ lực) gắn vào **chuỗi β của ARN polymerase vi khuẩn**, chặn phiên mã. Enzym của người khác cấu trúc nên ít bị ảnh hưởng. Lao kháng rifampicin thường do đột biến gen mã hóa chuỗi β (gen *rpoB*); xét nghiệm GeneXpert phát hiện đột biến này.
> - Nhóm **quinolon** (ciprofloxacin, levofloxacin) ức chế **topoisomerase II (gyrase) và topoisomerase IV** của vi khuẩn, ADN không tháo xoắn được để tái bản.

#### b) Phiên mã ở Eukaryota

Có **3 loại ARN polymerase**:

| Enzym | Vị trí | Sản phẩm |
|---|---|---|
| **ARN polymerase I** | **Hạch nhân** | **rARN** (các rARN lớn) |
| **ARN polymerase II** | Nhân | **Tiền thân mARN** và các **snARN** (hiện nay biết thêm: cả tiền thân **miARN**, lncARN) |
| **ARN polymerase III** | Nhân | Tiền thân **tARN**, **rARN 5S**, một số ARN nhỏ khác (kể cả snARN **U6**) |

*Mẹo nhớ*: **I – r, II – m, III – t** (theo thứ tự chữ **r – m – t**: rARN, mARN, tARN).

Mỗi enzym có **2 tiểu đơn vị lớn** và **6–10 tiểu đơn vị nhỏ**. Ví dụ ARN polymerase II có hai tiểu đơn vị lớn 215 kDa và 139 kDa; số tiểu đơn vị nhỏ khác nhau tùy loài (thực vật 8, động vật có xương sống 6). Điểm then chốt: **ARN polymerase Eukaryota không tự khởi động được phiên mã**, phải nhờ các yếu tố phiên mã.

**Vùng khởi đầu và khởi đầu phiên mã.** Promoter Eukaryota lớn, phức tạp và đa dạng hơn. Nhiều promoter của ARN polymerase II có **hộp TATA**, nằm khoảng **25–30 nucleotid** trước điểm bắt đầu phiên mã.

- **Yếu tố phiên mã** (transcription factor, TF) là protein. **TFIID** gắn vào hộp TATA trước tiên, tiếp theo là **TFIIB**, rồi lần lượt **TFIIE, TFIIH, TFIIF** gắn vào ARN polymerase II.
- **TFIIH gắn gốc phosphat** vào ARN polymerase II → enzym **hoạt động**, bắt đầu phiên mã.
- Khi **yếu tố kích thích phiên mã** gắn vào trình tự **enhancer**, hiệu quả phiên mã **tăng**.

> [!ung-dung] Ngộ độc nấm độc Amanita
> Nấm độc nhóm *Amanita* (ở Việt Nam hay gặp nấm độc trắng, nấm độc tán trắng) chứa **α-amanitin**. Chất này **ức chế ARN polymerase II**, làm tế bào không tổng hợp được mARN. Tế bào gan (nhận chất độc đầu tiên qua tĩnh mạch cửa) bị chết hàng loạt, gây **suy gan cấp**. Triệu chứng thường xuất hiện **muộn** (sau 6–12 giờ) nên dễ chẩn đoán trễ; đây là nguyên nhân hàng đầu gây tử vong do ngộ độc nấm.

#### c) Tạo mARN thuần thục

Sản phẩm phiên mã ban đầu là **mARN tiền thân**, còn chứa **cả exon và intron**. Ba biến đổi:

1. **Gắn mũ 5'** (7-methylguanosin) ngay khi vừa phiên mã.
2. **Gắn đuôi poly A 3'**: enzym **poly A polymerase** thêm **100–200** gốc adenylic.
3. **Cắt intron, nối exon** nhờ **thể nối (spliceosome)**, cấu tạo từ **U1, U2, U4, U5, U6 snRNP** và các thành phần khác. Thể nối **cắt ở vị trí nối 5'** của intron, rồi gắn đầu intron vào một **nucleotid A** gần vị trí nối 3', tạo **"thòng lọng"** (lariat). Sau đó cắt vị trí nối 3', **nối hai exon** lại. Thòng lọng intron cùng thể nối bị phân hủy trong nhân.

Kết quả là **mARN thuần thục** chỉ còn exon, có mũ và đuôi, đi ra tế bào chất. **Phiên mã ở nhân, dịch mã ở tế bào chất** — hai quá trình **tách biệt** về không gian và thời gian (khác Prokaryota).

> [!ung-dung] Bệnh do lỗi cắt nối — HbE và β-thalassemia
> Đột biến làm hỏng vị trí cắt nối, hoặc tạo ra vị trí cắt nối "giả", khiến mARN bị cắt sai. Ví dụ **HbE** (rất phổ biến ở Đông Nam Á, kể cả Việt Nam): đột biến ở codon 26 gen β-globin đổi Glu thành Lys, đồng thời tạo một vị trí nối giả. Một phần mARN bị cắt sai và hỏng, nên lượng β-globin **giảm** → biểu hiện giống **β-thalassemia nhẹ**. Người mang đồng thời HbE và một gen β-thalassemia (thể **HbE/β-thalassemia**) có thể thiếu máu nặng, phụ thuộc truyền máu.

## 4. Mã di truyền

Theo giáo trình, đến năm **1964** người ta đã xác định mã của cả **20 acid amin**. Đặc điểm của mã:

1. **Mã bộ ba** (triplet): 3 nucleotid liên tiếp mã hóa 1 acid amin. Các bộ ba **xếp cạnh nhau, thẳng hàng**, đọc liên tục **không gối nhau, không có dấu phẩy**.
2. **Tính thoái biến**: một acid amin có thể được **nhiều mã** quy định. Giáo trình nêu chỉ riêng **tryptophan có một mã** (UGG).
3. **Nucleotid thứ ba** là vị trí **dễ thay đổi** mà ý nghĩa của mã thường **không đổi**.
4. **Tính vạn năng**: mã **chung cho mọi sinh vật**.
5. **Một mã mở đầu AUG** (methionin) và **ba mã kết thúc UAA, UAG, UGA** (không mã hóa acid amin nào).

*Vì sao phải là bộ ba?* Có 4 loại nucleotid. Nếu mã gồm 2 nucleotid thì chỉ có 4^2^ = 16 tổ hợp, không đủ cho 20 acid amin. Bộ ba cho 4^3^ = **64 mã**: 61 mã cho acid amin, 3 mã kết thúc. Thừa mã nên mới có tính thoái biến.

**Bảng mã di truyền (trên mARN, đọc 5'→3').** Hàng là nucleotid thứ nhất, cột là nucleotid thứ hai; trong mỗi ô liệt kê theo nucleotid thứ ba.

| I \ II | **U** | **C** | **A** | **G** |
|---|---|---|---|---|
| **U** | UUU, UUC: Phe · UUA, UUG: Leu | UCU, UCC, UCA, UCG: Ser | UAU, UAC: Tyr · **UAA, UAG: Stop** | UGU, UGC: Cys · **UGA: Stop** · UGG: Trp |
| **C** | CUU, CUC, CUA, CUG: Leu | CCU, CCC, CCA, CCG: Pro | CAU, CAC: His · CAA, CAG: Gln | CGU, CGC, CGA, CGG: Arg |
| **A** | AUU, AUC, AUA: Ile · **AUG: Met (mở đầu)** | ACU, ACC, ACA, ACG: Thr | AAU, AAC: Asn · AAA, AAG: Lys | AGU, AGC: Ser · AGA, AGG: Arg |
| **G** | GUU, GUC, GUA, GUG: Val | GCU, GCC, GCA, GCG: Ala | GAU, GAC: Asp · GAA, GAG: Glu | GGU, GGC, GGA, GGG: Gly |

> [!bay]
> - **Methionin cũng chỉ có một mã (AUG)**, giống tryptophan. Giáo trình chỉ nêu tryptophan; nếu đề hỏi "acid amin nào chỉ có một mã" mà có cả Met và Trp trong lựa chọn thì cần đọc kỹ.
> - Mã di truyền **viết trên mARN** (có U). Trên mạch mã hóa của ADN thì T thay U (mã mở đầu là **ATG**; kết thúc **TAA, TAG, TGA**), như giáo trình mô tả ở mục 6.2.
> - **Thoái biến** = nhiều mã cho một acid amin. Không có chiều ngược lại: một mã **không bao giờ** quy định hai acid amin (mã có tính **đặc hiệu**).
> - Leu, Ser, Arg có nhiều mã nhất (**6 mã** mỗi loại).

> [!ung-dung] Một chữ sai — một bệnh
> **Bệnh hồng cầu hình liềm**: ở codon 6 của gen β-globin, **GAG** (Glu) đổi thành **GTG** (Val) (trên mARN là GUG). Chỉ thay một base mà hemoglobin đổi tính chất, hồng cầu biến dạng hình liềm. Ngược lại, đổi GAG thành **GAA** vẫn là Glu: đây là đột biến **im lặng** (nhờ tính thoái biến, nucleotid thứ ba).

> [!cap-nhat] Mã "gần như" vạn năng
> Giáo trình ghi mã có tính vạn năng. **Hiện nay** biết có một số ngoại lệ, nổi bật là **ty thể**: ở ty thể người, **UGA mã hóa tryptophan** (không phải mã kết thúc), **AUA mã hóa methionin**, còn **AGA, AGG** là mã kết thúc. Vì thế mã di truyền được gọi là **gần như vạn năng**. Ngoài ra, giáo trình ghi năm 1964; bộ mã thường được coi là giải xong hoàn toàn khoảng năm **1966** (Nirenberg, Khorana). Đi thi trả lời theo giáo trình.

## 5. Sinh tổng hợp protein (dịch mã)

![Hình 3. Dòng thông tin di truyền: tái bản, phiên mã, dịch mã và phiên mã ngược](trung-tam.svg)

Thông tin trong gen được chép sang **mARN** (phiên mã), rồi từ mARN sang **protein** (dịch mã). Ở Prokaryota, dịch mã gồm **4 giai đoạn**.

### 5.1. Dịch mã ở Prokaryota

#### a) Hoạt hóa acid amin

Mỗi acid amin được gắn vào tARN tương ứng nhờ enzym **aminoacyl-tARN synthetase**. Enzym này **đặc hiệu rất cao** với từng acid amin và tARN của nó.

=> acid amin + tARN + ATP → aminoacyl-tARN + AMP + PP~i~

Liên kết ester giữa acid amin và tARN là liên kết **giàu năng lượng**. Năng lượng này về sau được dùng để tạo liên kết peptid.

*Vì sao enzym này quan trọng?* tARN chỉ "đọc" mã bằng anticodon, còn **không kiểm tra** acid amin nó chở. Nếu synthetase gắn sai acid amin thì protein sẽ sai. Synthetase chính là nơi **mã di truyền được "dịch" thật sự**.

#### b) Giai đoạn mở đầu

- Ở Prokaryota, mọi protein bắt đầu bằng **methionin** dưới dạng **N-formylmethionin (f-Met)**, chở bởi **f-Met-tARN**.
- Có **3 yếu tố mở đầu**: **IF1, IF2, IF3** (initiation factor), đều là protein.

Trình tự:

1. **Phân đơn vị nhỏ 30S** kết hợp **IF3**, rồi gắn **mARN**.
2. **f-Met-tARN** gắn với **IF2–GTP**, rồi gắn vào phức hợp IF3–30S–mARN → **phức hợp mở đầu**. IF2 giúp **nhận ra mã AUG** và đặt f-Met-tARN vào **vị trí P** của ribosom.
3. **GTP thủy phân** (thành GDP + P~i~) → ribosom đổi cấu hình, **phân đơn vị 50S** gắn vào → **ribosom 70S** hoàn chỉnh. IF2, IF3 được giải phóng. Vai trò IF1 chưa rõ (theo giáo trình).

#### c) Giai đoạn kéo dài

Mã trên mARN được đọc theo chiều **5'→3'**. Có sự tham gia của các **yếu tố kéo dài** (EF). Mỗi vòng gồm **3 bước**:

1. **Gắn aminoacyl-tARN vào vị trí A**: aminoacyl-tARN thứ hai gắn với **EF-Tu–GTP**; GTP thủy phân giải phóng EF-Tu–GDP, aminoacyl-tARN nằm lại ở vị trí A. **EF-Ts** cũng tham gia (tái tạo EF-Tu–GTP).
2. **Tạo liên kết peptid**: enzym **peptidyl transferase** tạo cầu nối **–CO–NH–** giữa acid amin ở vị trí P và acid amin ở vị trí A. Năng lượng lấy từ **liên kết ester giàu năng lượng** của aminoacyl-tARN. Chuỗi peptid lúc này gắn vào tARN ở **vị trí A**; tARN ở vị trí P (đã mất acid amin) được giải phóng.
3. **Chuyển vị**: nhờ **EF-G–GTP** (GTP thủy phân), ribosom dịch đi **một mã** trên mARN. Peptidyl-tARN chuyển từ **A sang P**, vị trí A trống để đón aminoacyl-tARN mới.

Vòng này lặp lại đến khi **mã kết thúc** vào vị trí A.

> [!cap-nhat] Vị trí E và ribosom là một ribozym
> Giáo trình mô tả hai vị trí **A** và **P**; tARN đã mất acid amin "được giải phóng". **Hiện nay** biết ribosom có **ba** vị trí: **A** (đón aminoacyl-tARN), **P** (giữ peptidyl-tARN) và **E** (*exit*): sau chuyển vị, tARN "rỗng" sang vị trí **E** rồi mới rời ribosom. Hoạt tính **peptidyl transferase** nằm ở **rARN** của phân đơn vị lớn (rARN 23S ở vi khuẩn, 28S ở người), không phải ở protein. Cấu trúc nguyên tử của ribosom được trao Nobel Hóa học 2009 (Ramakrishnan, Steitz, Yonath). Đi thi trả lời theo giáo trình.

#### d) Giai đoạn kết thúc

- Khi **UAA, UAG hoặc UGA** vào vị trí A, không aminoacyl-tARN nào vào được (không có tARN mang anticodon tương ứng).
- **Yếu tố giải phóng** (release factor, RF) nhận ra mã kết thúc: **RF1 nhận UAA và UAG**; **RF2 nhận UAA và UGA**; **RF3** chưa rõ, có thể kích thích RF1, RF2.
- GTP thủy phân → peptidyl transferase **thủy phân** liên kết giữa chuỗi peptid và tARN ở vị trí P → **chuỗi polypeptid được giải phóng**.
- mARN tách khỏi ribosom; ribosom **tách thành hai phân đơn vị**.

> [!bay]
> - Vị trí **P** (peptidyl) giữ tARN mang **chuỗi peptid**; vị trí **A** (aminoacyl) đón **aminoacyl-tARN mới**. Riêng **tARN mở đầu** vào thẳng **vị trí P**.
> - **RF1**: UAA, **UAG**. **RF2**: UAA, **UGA**. Mã chung của cả hai là **UAA**. Mẹo: RF1 – UA**G**, RF2 – U**G**A.
> - Các bước tiêu tốn **GTP** (không phải ATP): IF2, EF-Tu, EF-G và giai đoạn kết thúc (RF3). ATP chỉ dùng ở bước **hoạt hóa acid amin**.
> - Prokaryota mở đầu bằng **f-Met**; Eukaryota bằng **Met** (không formyl hóa).

### 5.2. Dịch mã ở Eukaryota

Tương tự Prokaryota, khác ở các điểm:

| | Prokaryota | Eukaryota |
|---|---|---|
| Ribosom | 70S (50S + 30S) | **80S (60S + 40S)** |
| Acid amin mở đầu | **f-Met** | **Met** |
| Yếu tố mở đầu | IF1, IF2, IF3 | **eIF** (ví dụ **eIF-2** gắn GTP) |
| Yếu tố kéo dài (gắn aminoacyl-tARN) | EF-Tu, EF-Ts | **eEF-1α, eEF-1β, eEF-1γ** |
| Yếu tố chuyển vị | EF-G | **eEF-2** |
| Yếu tố giải phóng | RF1, RF2, RF3 | **eRF** (gắn GTP) |
| Mã kết thúc | UAA, UAG, UGA | **Giống**: UAA, UAG, UGA |
| Quan hệ với phiên mã | Dịch mã **ngay khi đang phiên mã** | Phiên mã ở **nhân**, dịch mã ở **tế bào chất** |

> [!ung-dung] Kháng sinh nhắm vào ribosom vi khuẩn
> Ribosom vi khuẩn (70S) khác ribosom người (80S), nên nhiều kháng sinh **ức chế dịch mã chọn lọc** ở vi khuẩn:
> - Gắn **30S**: **aminoglycosid** (gentamicin, amikacin, streptomycin) gây đọc sai mã; **tetracyclin** (doxycyclin) chặn aminoacyl-tARN vào **vị trí A**.
> - Gắn **50S**: **macrolid** (azithromycin, clarithromycin); **cloramphenicol** ức chế **peptidyl transferase**.
>
> *Vì sao vẫn có độc tính?* Ribosom **ty thể** người giống ribosom vi khuẩn. Đó là một lý do aminoglycosid có thể gây **điếc** (nhất là người mang đột biến A1555G ở rARN ty thể) và cloramphenicol có thể gây **ức chế tủy xương**.

> [!cap-nhat] Vắc xin mARN
> Hiểu biết về mũ 5', đuôi poly A và **uridin giả** (base hiếm của ARN, mục 2.4) đã giúp tạo ra **vắc xin mARN** (như vắc xin COVID-19). mARN tổng hợp nhân tạo dùng một dẫn xuất uridin giả (N1-methylpseudouridin) thay cho uridin, nên ít gây phản ứng viêm và được dịch mã hiệu quả hơn. Phát hiện này được trao giải Nobel Y học năm **2023** (Karikó và Weissman).

## 6. Điều chỉnh sinh tổng hợp protein

Tế bào cần protein **đúng loại, đúng lượng, đúng lúc**. Tổng hợp thừa thì phí năng lượng; thiếu thì không đáp ứng được môi trường.

### 6.1. Ở Prokaryota — mô hình operon

Giáo trình nêu hai hiện tượng ở *E. coli*:

- **Hiện tượng kích thích** (cảm ứng): môi trường **có lactose** → enzym **β-galactosidase** (phân giải lactose) được tổng hợp **mạnh**; không có lactose thì giảm hẳn. **Lactose là tác nhân kích thích** tổng hợp enzym.
- **Hiện tượng kìm hãm**: môi trường **không có tryptophan** → vi khuẩn tăng tổng hợp các enzym **tạo tryptophan**; có sẵn tryptophan thì các enzym này giảm. **Tryptophan là tác nhân kìm hãm**.

*Ý nghĩa*: vi khuẩn chỉ làm enzym **khi cần** — có lactose mới cần enzym tiêu lactose; đã có tryptophan thì không cần tự tổng hợp.

#### a) Các thành phần của mô hình operon (Jacob và Monod)

| Thành phần | Ký hiệu | Vai trò |
|---|---|---|
| **Gen cấu trúc** (cistron) | Ct1, Ct2, Ct3… | Phiên mã ra mARN để tổng hợp các enzym E1, E2, E3… của một con đường chuyển hóa |
| **Vùng khởi đầu** (promoter) | Pr | Đoạn ADN kề gen cấu trúc, được **ARN polymerase nhận diện** để bắt đầu phiên mã |
| **Vị trí vận hành** (operator) | O | Thường nằm trong vùng khởi đầu. **Tự do** → ARN polymerase vào được, gen **mở**. **Bị chất kìm hãm gắn** → ARN polymerase bị chặn, gen **đóng** |
| **Gen điều chỉnh** (regulator) | Re | Tổng hợp **chất kìm hãm** (R, repressor) hoặc **chất hoạt hóa** (A, activator). Ở Prokaryota có thể nằm cùng NST với gen cấu trúc; ở Eukaryota có thể ở NST khác |

> [!ghi-nho] Operon = gen cấu trúc + vùng khởi đầu + vị trí vận hành
> **Gen điều chỉnh không thuộc operon** (nó chỉ tạo ra protein điều chỉnh tác động lên operon).

#### b) Hai cơ chế, bốn trường hợp

| Cơ chế | Trường hợp | Protein điều chỉnh khi chưa có "chất gắn đặc hiệu" | Khi có chất gắn đặc hiệu |
|---|---|---|---|
| **Kích thích** (điều hòa dương) — dùng **chất hoạt hóa** | 1 | Chất hoạt hóa **hoạt động**, gắn vị trí vận hành → gen **mở** | Chất hoạt hóa rời đi → gen **đóng** |
| | 2 | Chất hoạt hóa **không hoạt động** → gen **đóng** | Chất hoạt hóa thành hoạt động, gắn vào → gen **mở** |
| **Kìm hãm** (điều hòa âm) — dùng **chất kìm hãm** | 1 | Chất kìm hãm **hoạt động**, gắn vị trí vận hành → gen **đóng** | Chất kìm hãm rời vị trí vận hành → gen **mở** (**operon cảm ứng**, ví dụ **operon Lac**) |
| | 2 | Chất kìm hãm **không hoạt động** → gen **mở** | Chất kìm hãm thành hoạt động, gắn vào → gen **đóng** (**operon ức chế**, ví dụ **operon Trp**) |

*Quy tắc chung*: protein điều chỉnh **có thể đổi trạng thái** khi gắn với một **phân tử nhỏ** đặc hiệu (lactose, tryptophan…). Phân tử nhỏ chính là "tín hiệu môi trường".

#### c) Operon Lac — ví dụ điển hình

![Hình 4. Operon Lac: không có lactose (đóng) và có lactose (mở)](operon-lac.svg)

- **Không có lactose**: gen điều chỉnh tạo chất kìm hãm **hoạt động**. Chất này gắn vào **vị trí vận hành O**, chặn ARN polymerase → các gen cấu trúc **không phiên mã**.
- **Có lactose**: lactose (chính xác là dạng đồng phân của nó, **allolactose**) gắn vào chất kìm hãm, làm nó **đổi cấu hình và rời khỏi O** → ARN polymerase phiên mã các gen cấu trúc trên **một mARN chung** → tạo **β-galactosidase** và các enzym liên quan. Khi lactose bị dùng hết, chất kìm hãm lại hoạt động, operon đóng.

> [!bay] "Kích thích" nhưng lại là cơ chế **kìm hãm**
> Giáo trình gọi lactose là ví dụ của **hiện tượng kích thích**. Nhưng **về cơ chế**, operon Lac (theo mô hình kinh điển) thuộc **cơ chế kìm hãm – trường hợp 1**: protein điều chỉnh là **chất kìm hãm**; lactose "kích thích" bằng cách **gỡ chất kìm hãm**. Còn operon Trp thuộc **kìm hãm – trường hợp 2** (tryptophan hoạt hóa chất kìm hãm). Phân biệt rõ: **hiện tượng** (enzym tăng hay giảm) và **cơ chế** (protein điều chỉnh là chất kìm hãm hay chất hoạt hóa).

> [!vi-du] Đào sâu: chi tiết operon Lac
> - Operon Lac gồm 3 gen cấu trúc: **lacZ** (β-galactosidase), **lacY** (permease đưa lactose vào tế bào), **lacA** (transacetylase). Gen điều chỉnh là **lacI**.
> - Operon Lac còn có **điều hòa dương**: khi **thiếu glucose**, cAMP tăng, phức hợp **CAP–cAMP** gắn cạnh promoter giúp ARN polymerase hoạt động mạnh. Vì vậy khi có **cả glucose và lactose**, vi khuẩn dùng glucose trước (glucose là nguồn năng lượng "rẻ" hơn).
> - Đột biến làm chất kìm hãm **không gắn được O**, hoặc O hỏng, khiến operon **luôn mở** (biểu hiện thường trực).

### 6.2. Ở Eukaryota — điều chỉnh biểu hiện gen

#### a) Mục đích và đặc điểm

Cơ thể đa bào phát triển từ **một hợp tử**. Mọi tế bào có **bộ gen giống nhau**, nhưng mỗi mô chỉ **biểu hiện một phần nhỏ** gen của mình:

- Hồng cầu non tổng hợp **hemoglobin**; tế bào cơ tổng hợp **myoglobin**; tế bào tụy tổng hợp **insulin**; tuyến nội tiết tổng hợp **hormon**.
- Cùng một loại tế bào, **theo giai đoạn phát triển** lại làm protein khác nhau: hồng cầu thời **bào thai** tổng hợp **HbF**, ở **người trưởng thành** tổng hợp **HbA**.
- Cùng một protein có lúc làm nhiều, lúc làm ít, lúc không làm.

**Tín hiệu điều chỉnh** ở cơ thể đa bào chủ yếu là **phân tử protein** do tế bào chuyên biệt tiết ra, lưu thông theo **thể dịch** tới **tế bào đích**: **yếu tố sinh trưởng** (GF), **hormon**, **yếu tố đặc hiệu mô**. Chúng điều chỉnh gen qua tương tác đặc hiệu **ADN – protein**, cùng phức hợp ARN polymerase.

*Khác Prokaryota*: Prokaryota phản ứng nhanh với **chất dinh dưỡng** trong môi trường; Eukaryota điều chỉnh theo **chương trình phát triển** và **tín hiệu của toàn cơ thể**, qua **nhiều bước** từ ADN → mARN tiền thân → mARN → protein.

#### b) Mô hình cấu trúc một gen Eukaryota

![Hình 5. Cấu trúc một gen Eukaryota và quá trình tạo mARN thuần thục](gen-eukaryota.svg)

**Gen cấu trúc** quy định một protein, gồm **exon** và **intron**:

- **Exon**: đoạn được phiên mã và **mã hóa** protein. **Intron**: được phiên mã nhưng **không mã hóa**, bị cắt bỏ.
- Đầu **exon 1** có mã mở đầu **ATG**; cuối **exon cuối** có một mã kết thúc **TAA, TGA hoặc TAG**.
- Trước exon đầu và sau exon cuối có **vùng không dịch mã** (UTR).
- Mỗi intron bắt đầu bằng **5'-GT** (**vị trí cho nối**) và kết thúc bằng **AG-3'** (**vị trí nhận nối**). Đây là **quy tắc GT–AG**.

**Vùng kiểm soát biểu hiện gen:**

| Thành phần | Vị trí / đặc điểm | Vai trò |
|---|---|---|
| **Vùng khởi đầu** (promoter) | Đầu 5' của gen, có thể dài vài kb. **Hộp TATA**: khoảng **−25 đến −30** bp. **Hộp CCAAT**: khoảng **−75 đến −80** bp | Xác định điểm bắt đầu phiên mã, kiểm soát **lượng mARN** và **tính đặc hiệu mô**. Hộp CCAAT **tăng hiệu quả** phiên mã |
| **Enhancer** (vị trí gắn yếu tố kích thích phiên mã) | Có thể ở phía **5' hoặc 3'** của gen | **Tăng phiên mã** các gen kề bên |
| **Vị trí gắn yếu tố đặc hiệu mô** | — | Chỉ huy gen tạo protein đặc hiệu cho từng mô |
| **Vị trí bắt đầu phiên mã** | Còn gọi **"cap site"** | Nơi phiên mã bắt đầu (và về sau gắn mũ) |
| **Vị trí gắn các thành phần đặc hiệu promoter khác** | — | Tương tác với các yếu tố điều hòa khác |

**Vùng 3' của gen**: có tín hiệu gắn **đuôi poly A** (khoảng **200 adenin**). Đuôi này giúp mARN ra tế bào chất và bảo vệ nó khi dịch mã.

> [!bay] So sánh các "hộp" trong promoter
> - Prokaryota: vùng **−10** và **−35**.
> - Eukaryota: hộp **TATA ≈ −25 đến −30**; hộp **CCAAT ≈ −75 đến −80**.
> - Enhancer **không cố định vị trí** (có thể ở xa, phía 5' hay 3'), khác promoter luôn ở **đầu 5'** của gen.

#### c) Sáu bước điều chỉnh biểu hiện gen ở Eukaryota

Theo giáo trình, biểu hiện gen Eukaryota có thể được điều chỉnh ở **6 bước**:

| Bước | Quá trình | Yếu tố kiểm soát |
|---|---|---|
| 1 | Gen → **mARN tiền thân** (phiên mã) | Kiểm soát **phiên mã**: gen được phiên mã khi nào, mức nào |
| 2 | mARN tiền thân → **mARN thuần thục** | Kiểm soát **thuần thục hóa ARN** (gắn mũ, cắt nối, poly A) |
| 3 | mARN từ **nhân → tế bào chất** | Kiểm soát **vận chuyển ARN** |
| 4 | mARN → **protein** (dịch mã ở ribosom) | Kiểm soát **dịch mã** |
| 5 | mARN bị **phân hủy** | Kiểm soát **giáng cấp mARN** |
| 6 | Protein → **hoạt hóa hay bất hoạt** | Kiểm soát **hoạt tính protein** |

Bất thường ở **bất kỳ bước nào** trên con đường ADN → mARN → protein đều có thể gây bệnh.

> [!cap-nhat] Biểu sinh (epigenetics)
> Giáo trình chưa đề cập, nhưng hiện nay đây là một tầng điều chỉnh rất quan trọng **trước cả bước 1**. **Biểu sinh** là những thay đổi biểu hiện gen **truyền được qua phân bào** mà **không đổi trình tự ADN**. Hai cơ chế chính:
> - **Methyl hóa ADN** ở cytosin của cặp **CpG** vùng promoter → gen thường bị **tắt**.
> - **Biến đổi histon** (acetyl hóa, methyl hóa…) → chromatin **mở** hoặc **đóng**. Histon được acetyl hóa thường làm chromatin "lỏng", gen dễ phiên mã.
>
> Ví dụ: **bất hoạt NST X** ở nữ; **in dấu bộ gen** (genomic imprinting, gen chỉ hoạt động khi nhận từ bố hoặc chỉ khi nhận từ mẹ); nhiều ung thư có gen ức chế khối u bị **tắt do methyl hóa**. Một số thuốc chống ung thư (azacitidin, decitabin) hoạt động bằng cách **ức chế methyl hóa ADN**.
>
> *Ví dụ in dấu kinh điển (bổ sung – kiến thức hiện nay):* cùng là mất đoạn vùng **15q11–q13**, nhưng mất trên NST 15 **nhận từ bố** gây hội chứng **Prader-Willi** (giảm trương lực, ăn không no, béo phì), còn mất trên NST 15 **nhận từ mẹ** gây hội chứng **Angelman** (chậm phát triển nặng, không nói, hay cười, co giật). Lý do: các gen ở vùng này bình thường chỉ hoạt động trên một bản (bản kia bị methyl hóa "khóa"), nên mất bản đang hoạt động là mất chức năng.

> [!cap-nhat] Chỉnh sửa gen CRISPR–Cas9
> **CRISPR–Cas9** vốn là hệ miễn dịch của vi khuẩn chống phagiơ. Người ta dùng một **ARN dẫn đường** bắt cặp bổ sung với đoạn ADN đích, dẫn enzym **Cas9** tới **cắt đúng vị trí** đó để sửa gen (giải Nobel Hóa học **2020**, Charpentier và Doudna). Cuối năm **2023** (Anh: cả hai bệnh, 11/2023; Mỹ: hồng cầu hình liềm 12/2023, β-thalassemia 1/2024), liệu pháp **Casgevy** (exagamglogene autotemcel, exa-cel) được phê duyệt cho **bệnh hồng cầu hình liềm** và **β-thalassemia** phụ thuộc truyền máu. Liệu pháp này cắt vào vùng tăng cường (enhancer) của gen **BCL11A** trong tế bào gốc tạo máu của chính người bệnh. BCL11A là protein "tắt" gen γ-globin sau khi sinh. Tắt BCL11A thì hồng cầu lại tổng hợp **HbF** như thời bào thai, bù cho HbA bị hỏng. Đây chính là ví dụ HbF → HbA của giáo trình, được ứng dụng ngược lại để chữa bệnh.
>
> **Thế hệ chỉnh sửa mới — không cắt đứt hai mạch ADN** (bổ sung – kiến thức hiện nay):
> - **Chỉnh sửa base** (*base editing*, nhóm David Liu, 2016): Cas9 "cùn" (chỉ cắt một mạch hoặc không cắt) gắn với enzym **khử amin**, đổi trực tiếp **một base** (C→T hoặc A→G) mà không gây đứt gãy hai mạch. Năm **2025**, một trẻ nhũ nhi ở Mỹ mắc thiếu enzym **CPS1** (rối loạn chu trình urê) là người đầu tiên được điều trị bằng một liệu pháp chỉnh sửa base **thiết kế riêng** cho đột biến của mình (NIH, *NEJM* 5/2025).
> - **Chỉnh sửa "prime"** (*prime editing*, 2019): Cas9 cắt một mạch gắn với **enzym phiên mã ngược** (mục 3.1.3); ARN dẫn đường mang sẵn khuôn để "viết lại" một đoạn ngắn — sửa được cả thay thế, mất, thêm nucleotid nhỏ. Dữ liệu lâm sàng đầu tiên (bệnh u hạt mạn tính) được công bố năm 2025.

> [!yhct] Hoạt chất từ cây ức chế topoisomerase
> Hai nhóm thuốc chống ung thư quan trọng có nguồn gốc từ cây, tác động đúng vào enzym tháo xoắn ADN ở mục 3.1:
> - **Camptothecin**, alkaloid chiết từ cây **Hỷ thụ** (*Camptotheca acuminata*, cây gốc Trung Quốc). Nó **ức chế topoisomerase I**. Các dẫn chất bán tổng hợp **irinotecan, topotecan** dùng điều trị ung thư đại trực tràng, buồng trứng, phổi.
> - **Podophyllotoxin**, lignan có trong thân rễ các cây chi *Podophyllum* và *Dysosma* (ở Việt Nam có **Bát giác liên**, *Dysosma* spp., là cây **rất độc**). Từ chất này bán tổng hợp ra **etoposid**, thuốc **ức chế topoisomerase II**.
>
> Đây là các **hoạt chất tinh khiết hoặc dẫn chất** đã qua thử nghiệm lâm sàng. Không suy ra rằng dùng vị thuốc thô có tác dụng chống ung thư; Bát giác liên dùng không đúng có thể gây ngộ độc nặng.

## Tóm tắt

| Chủ đề | Điểm then chốt |
|---|---|
| Bằng chứng | Griffith 1928 (chuyển thể R → S); Avery 1944 (chất chuyển thể là ADN, DNase làm mất); phagiơ (^32^P-ADN vào, ^35^S-protein ở ngoài); virus khảm thuốc lá (ARN); Feulgen; chuột chuyển gen 10–30% |
| ADN | Nucleotid = deoxyribose + phosphat + base (A, G purin; C, T pyrimidin); liên kết 3'–5' phosphodiester; 2 mạch đối song song; A=T (2 H), G≡C (3 H); (A+G)/(T+C) = 1, (A+T)/(G+C) đặc trưng loài |
| Dạng ADN | B: phải, 2 nm, 10 bp/3,4 nm; A: phải, 2,6 nm, 11 bp; Z: **trái**, 1,8 nm, 12 bp/4,5 nm; H: xoắn ba |
| Bộ gen | Prokaryota: gen liên tục. Eukaryota: exon/intron; trình tự duy nhất ≈10%, lặp nhiều lần 10–15%, lặp trung bình 25–40%; transposon, retroposon; gen gối nhau. Người 3 × 10^9^ bp |
| ARN | Ribose, U thay T, mạch đơn 50–6000 nt. rARN 80% (ribosom 70S = 50S + 30S; 80S = 60S + 40S); tARN 10–15%, ≈75 nt, lá ba chẽ, CCA-3', đối mã; mARN 5–10%; snARN 90–300 nt (U1, U2, U4, U5, U6) |
| Tái bản | Bán bảo tồn, 5'→3', cần ARN mồi; sợi nhanh liên tục, sợi chậm gián đoạn (Okazaki). Pro: topo, SSB, helicase, primase, pol III (chính), pol I (bỏ mồi), ligase; 1 điểm khởi đầu. Eu: nhiều điểm khởi đầu, pol α (mồi), β, γ (ty thể), δ, ε |
| Phiên mã ngược | Baltimore, Temin 1970; ARN → ADN; retrovirus (HIV) |
| Phiên mã | Pro: 1 ARN pol (α~2~ββ'ω + σ), promoter −35/−10, kết thúc Rho hoặc tín hiệu ADN. Eu: pol I (rARN, hạch nhân), II (mARN, snARN), III (tARN, 5S); TATA −25/−30; TFIID trước; mũ 5', poly A, cắt intron (spliceosome, thòng lọng) |
| Mã di truyền | Bộ ba, thẳng hàng; thoái biến (Trp chỉ 1 mã); nucleotid 3 dễ đổi; vạn năng; AUG mở đầu; UAA, UAG, UGA kết thúc |
| Dịch mã | Hoạt hóa aa (aminoacyl-tARN synthetase, ATP) → mở đầu (f-Met, IF1–3, 30S → 70S, vị trí P) → kéo dài (EF-Tu vào A, peptidyl transferase, EF-G chuyển vị) → kết thúc (RF1: UAA/UAG; RF2: UAA/UGA). Eu: 80S, Met, eIF-2, eEF-1, eEF-2, eRF |
| Operon | Gen cấu trúc + promoter + operator; gen điều chỉnh tạo chất kìm hãm/hoạt hóa. Lac: lactose gỡ chất kìm hãm → mở. Trp: tryptophan hoạt hóa chất kìm hãm → đóng |
| Gen Eukaryota | ATG ở exon 1, stop ở exon cuối, intron GT…AG; TATA, CCAAT, enhancer, yếu tố đặc hiệu mô, cap site; poly A ≈200. Điều chỉnh 6 bước: phiên mã → thuần thục → vận chuyển → dịch mã → giáng cấp mARN → hoạt tính protein |
