---
title: Loài người và môi trường ngoại cảnh
thoi-gian: 35 phút
muc-tieu:
- Trình bày được tác động của các nhân tố vô sinh (nhiệt độ, nước, không khí, phóng xạ, thức ăn, tiếng động, môi trường lao động, chu kỳ địa vật lý) lên cơ thể và sức khỏe con người.
- Trình bày được quan hệ giữa loài người với ngoại cảnh hữu sinh: nhu cầu thức ăn, gia tăng dân số và cuộc đấu tranh với sinh vật gây bệnh.
- Phân biệt được đột biến cảm ứng ở tế bào soma và ở tế bào sinh dục.
- Kể được các tác nhân vật lý, hóa học và sinh vật học gây đột biến cảm ứng ở người, kèm ví dụ của sách.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Người là sinh vật **hằng nhiệt** và tự tạo được **vi khí hậu** cho mình, nhưng nhiệt độ bất lợi và **thay đổi đột ngột** vẫn gây hại lớn.
> 2. Nước, không khí, thức ăn đều bị **ô nhiễm** do chính hoạt động của con người: chất tẩy rửa, thuốc trừ sâu (DDT), SO~2~, CO, CO~2~, benzopyren, khói thuốc lá, bụi, phóng xạ (**Stronti 90**), tiếng ồn.
> 3. Cơ thể có **nhịp sinh học** (nhịp ngày đêm) hình thành do thích nghi lâu dài với các chu kỳ địa vật lý; ngủ – thức phải khớp với tối – sáng.
> 4. Dân số tăng nhanh (1 tỷ năm 1850 → 6,1 tỷ năm 2001) tạo **mâu thuẫn giữa nhu cầu và nguồn thức ăn**; con người vẫn đang đấu tranh với vi sinh vật gây bệnh, nhất là chủng **kháng thuốc** (năm 2021 ≈ 1,1 triệu ca tử vong trực tiếp do kháng kháng sinh — GRAM, *Lancet* 2024; số liệu cập nhật định kỳ tại WHO).
> 5. **Đột biến cảm ứng** do tác nhân ngoại cảnh: **vật lý** (tia phóng xạ, tia X, tia cực tím, nhiệt độ), **hóa học** (thuốc, hóa chất nông nghiệp, công nghiệp), **sinh vật** (virus như Rubella, vi khuẩn, Toxoplasma). Đột biến **soma** không di truyền; đột biến **tế bào sinh dục** di truyền cho đời sau.

Bài này nhìn con người như **một loài sinh vật** sống trong hệ sinh thái. Có hai chiều tác động: môi trường tác động lên cơ thể, và con người (với khoa học – kỹ thuật) lại làm biến đổi môi trường rất mạnh, nhiều khi quay lại gây hại cho chính mình.

## 1. Loài người và các nhân tố vô sinh

### 1.1. Nhân tố nhiệt độ

**Người là sinh vật hằng nhiệt.** Nhờ biện pháp bảo vệ chủ động, con người có thể sống và làm việc từng thời gian ở nơi rất lạnh (âm vài chục độ) hoặc rất nóng (60–70 °C). Con người còn tự tạo **vi khí hậu** quanh mình: quần áo chống rét, nhà cửa, tường cách nhiệt, máy điều hòa…

Dù vậy, nhiệt độ không thích hợp và nhất là **thay đổi nhiệt độ đột ngột** vẫn là yếu tố gây hại lớn.

- **Bị lạnh đột ngột** (kể cả khi nhiệt độ không quá thấp): hệ **thần kinh giao cảm** phản ứng, làm **tăng oxy hóa** trong cơ thể để giữ thân nhiệt.
  - *Vì sao chịu lạnh lâu lại chết?* Muốn sinh nhiệt, cơ thể phải đốt năng lượng dự trữ. Lạnh kéo dài thì dự trữ cạn dần, cơ thể kiệt sức rồi chết.
- **Thay đổi nhiệt độ đột ngột** gây: rối loạn sâu sắc về **chuyển hóa**, biến đổi **thành phần máu**, rối loạn **nhịp tim** và **dung tích hô hấp**.

> [!ung-dung] "Ngủ đông nhân tạo" trong phẫu thuật
> Sách nêu một ứng dụng: tiêm thuốc **ức chế giao cảm** (để cơ thể không chống lại lạnh) rồi làm lạnh từ từ, hạ thân nhiệt xuống **26–28 °C**. Người bệnh vào trạng thái giống **ngủ đông** ở động vật, chuyển hóa giảm, mô chịu thiếu oxy lâu hơn. Nhờ vậy có thể tiến hành các ca **mổ dài và phức tạp**.
> Ngày nay hạ thân nhiệt chủ động vẫn được dùng, ví dụ trong một số phẫu thuật tim – mạch lớn, và hạ thân nhiệt có kiểm soát (khoảng 32–36 °C) sau ngừng tuần hoàn để bảo vệ não.

> [!yhct] Lục dâm: quan niệm truyền thống của YHCT về tác động của thời tiết
> YHCT gọi sáu yếu tố khí hậu bình thường là **lục khí**: **phong, hàn, thử, thấp, táo, hỏa**. Khi chúng **thái quá, bất cập, hoặc đến không đúng thời** (ví dụ trời đang nóng chuyển rét đột ngột), hay khi chính khí con người suy, lục khí trở thành **lục dâm** — nguyên nhân bên ngoài gây bệnh. Ý "thay đổi đột ngột mới gây hại" ở trên có **nét tương đồng** với quan niệm này; **thử** (nắng nóng mùa hè) gợi tới say nắng, say nóng; **hàn** gợi tới nhiễm lạnh.
> Đây là **một hệ quan điểm** về bệnh nguyên, đúc kết từ quan sát lâm sàng lâu đời, không phải mô hình sinh lý học đã được chứng minh bằng thực nghiệm. Đi thi môn Sinh học vẫn trả lời theo cơ chế của giáo trình.

### 1.2. Nước và sự ô nhiễm nguồn nước

#### a) Nhu cầu, trữ lượng và sự mất cân bằng

- **Nhu cầu** nước ngọt và nước sạch rất lớn: ăn uống, sinh hoạt, tưới nông nghiệp, công nghiệp. Sách ghi nước cho **công nghiệp chiếm 2/3** tổng nhu cầu nước thế giới.
- **Trữ lượng:** **97% là nước mặn, chỉ 3% là nước ngọt**; trong 3% đó phần lớn đóng băng. Phần còn lại:

| Dạng nước ngọt dùng được | Trữ lượng (theo sách) |
|---|---|
| Nước bề mặt (sông, suối, ao hồ) | 350.000 km^3^ |
| Nước ngầm | 150.000 km^3^ |
| Hơi nước trong khí quyển | 13.000 km^3^ |

- **Mất cân bằng:** nhu cầu ngày càng tăng, nguồn nước ngọt ngày càng giảm vì hai lý do:
  1. **Phá rừng, đốt rừng** → nước mưa chảy tràn rửa trôi bề mặt nhiều hơn, thấm xuống đất ít hơn → **nước ngầm giảm**, nước đổ ra biển tăng.
  2. Phần nước còn lại bị **ô nhiễm** nên không dùng được.

> [!cap-nhat] Ai dùng nhiều nước nhất?
> Giáo trình ghi công nghiệp chiếm 2/3 nhu cầu nước. Theo số liệu của FAO (AQUASTAT) hiện nay, **nông nghiệp** (chủ yếu tưới tiêu) mới là ngành lấy nhiều nước nhất, khoảng **70%** lượng nước khai thác toàn cầu; công nghiệp khoảng 20%, sinh hoạt khoảng 10%. Tỉ lệ khác nhau nhiều giữa các nước. Đi thi trả lời theo sách.

#### b) Các dạng ô nhiễm nước

| Dạng ô nhiễm | Nguồn | Đặc điểm |
|---|---|---|
| **Mầm bệnh** | Thành phố đông dân, bệnh viện, xí nghiệp thực phẩm, lò mổ, trại chăn nuôi | Rất nguy hiểm nhưng **xử lý tương đối dễ**: chu trình tự làm sạch của tự nhiên, lọc thường (trừ **virus xuyên lọc**) |
| **Chất thải, rác, dầu** | Cảng sông, cảng biển, vùng lọc dầu, nơi đổ rác | **Váng dầu** phủ kín mặt nước nhiều năm; **bao bì chất dẻo** hầu như không bị vi sinh vật phân hủy |
| **Phóng xạ** | Xem mục 1.4 | |
| **Chất độc hóa học** | Chất tẩy rửa, thuốc trừ sâu, diệt cỏ… | Tan trong nước, **không bị vi sinh vật phân hủy**, **xuyên qua lọc** → vào nước ngầm, nước máy, cơ thể. **Khó giải quyết nhất** |

*Vì sao váng dầu, rác làm "chết" cả vùng nước?* Váng dầu cản trao đổi khí và ánh sáng. Vi sinh vật, tảo, thực vật và động vật thủy sinh vốn làm nhiệm vụ phân hủy chất bẩn bị yếu đi, chết hoặc đột biến. Tảo chết thì **O~2~ do quang hợp giảm**, các sinh vật cần O~2~ tiếp tục chết. Cuối cùng nước rất bẩn, không còn sự sống và **mất khả năng tự làm sạch**.

Sách nêu con số: con người đã tạo khoảng **nửa triệu chất nhân tạo**, mỗi năm thêm **400–500 chất mới**, nhưng phần lớn chưa được thử độc tính trên sinh vật.

#### c) Hai nhóm hóa chất ô nhiễm điển hình

**Bột tẩy rửa (chất tẩy rửa tổng hợp)**

- Xuất hiện khoảng thập niên 1940, đến khoảng 1960 thay dần xà phòng.
- Loại cũ có **mạch hydrocarbon phân nhánh** → vi khuẩn **không phân hủy được**. Sau đó có loại **mạch thẳng** vi khuẩn phân hủy được, nhưng vi khuẩn **kỵ khí** vẫn không phân hủy được.
- Tác hại: lượng lớn làm chết vi sinh vật, đảo lộn hệ thủy sinh, làm chết cá. Bột tẩy rửa còn là **dung môi kéo hydrocarbon** vào nước, giúp chúng **xuyên qua lọc** vào giếng.
- Một số nghiên cứu cho rằng cả loại phân hủy được cũng độc; vấn đề chưa giải quyết xong.

> [!bay] Mốc năm trong sách
> Sách viết loại không nhánh được chế ra "năm 1950", nhưng ngay trước đó lại nói bột tẩy rửa đến 1960 mới thay xà phòng. Thực tế loại mạch thẳng (dễ phân hủy) phổ biến từ **giữa thập niên 1960**. Không nên học thuộc mốc năm này; ý chính cần nhớ là **mạch nhánh → khó phân hủy; mạch thẳng → vi khuẩn hiếu khí phân hủy được**.

**Thuốc trừ sâu, diệt cỏ, diệt chuột (hóa chất bảo vệ thực vật)**

- Dùng trên cạn nhưng rồi có mặt **ở mọi nguồn nước**: nước mặt, nước ngầm, đại dương, cả băng tuyết **Bắc cực, Nam cực** và tuyết ở độ cao 7000 m trên Himalaya. Ước tính băng tuyết Nam cực chứa khoảng **2.000 tấn DDT**.
- **Ba nhóm chính** (cộng thêm nhóm pyrethroid dùng nhiều hiện nay):

| Nhóm | Ví dụ | Đặc điểm phân hủy |
|---|---|---|
| **Clo hữu cơ** | DDT, dieldrin, aldrin, endrin | Phân hủy **rất chậm** → tồn lưu, tích lũy |
| **Phospho hữu cơ** | Parathion, wofatox | **Rất độc**, nhưng phân hủy **nhanh** |
| **Carbamat** | | Phân hủy **nhanh** |

- Một số thuốc **ngấm vào nhựa cây** đi khắp cây, tập trung ở **cơ quan sinh sản** (hạt, quả).
- **DDT** — con dao hai lưỡi:
  - Lợi: đã cứu nhiều vùng khỏi **sốt rét** và **bệnh ngủ** (do ruồi tsé-tsé truyền).
  - Hại: phân hủy rất chậm; làm rối loạn **chuyển hóa calci** → **vỏ trứng chim mỏng**, vỡ khi ấp → giảm số lượng chim ăn thịt, chim ăn hạt. Ở Canada, phun DDT liều thường xử lý rừng đã làm chết hàng chục vạn cá. DDT trộn vào thức ăn gây **ung thư thực nghiệm** ở chuột nhắt.
  - Ngấm xuống đất, thuốc diệt **vi sinh vật đất và giun đất**, làm thay đổi cấu tạo đất (**ô nhiễm đất**).
- **Chất diệt cỏ, làm rụng lá dùng trong chiến tranh ở miền Nam Việt Nam:** chứa tạp chất cực độc **dioxin** lẫn trong **2,4-D và 2,4,5-T**. Tài liệu của chính tác giả Mỹ cho thấy ở Bệnh viện Tây Ninh, **tỷ lệ chết sơ sinh tăng từ 5,8% (1968) lên 10,1% (1970)**.

![Hình 1. Khuếch đại sinh học: chất khó phân hủy, tan trong mỡ (như DDT) đậm đặc dần qua mỗi bậc của chuỗi thức ăn](khuech-dai-sinh-hoc.svg)

> [!vi-du] Vì sao chim ăn thịt bị hại nặng nhất?
> DDT **khó phân hủy** và **tan trong mỡ**, nên sinh vật hấp thụ vào mà không thải ra được; nó tích trong mô mỡ. Mỗi bậc dinh dưỡng phải ăn rất nhiều sinh vật bậc dưới, nên nồng độ DDT trong cơ thể **tăng lên qua mỗi bậc** (khuếch đại sinh học). Chim ăn cá đứng ở đỉnh chuỗi nên nhận liều cao nhất. Người cũng ở đỉnh chuỗi thức ăn; sách cũng nêu DDT đã được tìm thấy trong mỡ hải cẩu và chim cánh cụt ở vùng cực.

> [!cap-nhat] DDT và chất độc da cam ngày nay
> - DDT nằm trong danh sách hạn chế của **Công ước Stockholm** về các chất ô nhiễm hữu cơ khó phân hủy (POPs, có hiệu lực từ 2004): cấm dùng trong nông nghiệp, chỉ còn được phép dùng hạn chế để **phun diệt muỗi truyền sốt rét** ở một số nước.
> - Dioxin trong chất diệt cỏ chiến tranh chủ yếu là **TCDD**, được Cơ quan Nghiên cứu Ung thư Quốc tế (IARC) xếp vào **nhóm 1 — chắc chắn gây ung thư ở người**. Dioxin tan trong mỡ, tồn lưu lâu trong đất, trầm tích và cơ thể.

### 1.3. Các khí và sự ô nhiễm không khí

Con người sống trong **tầng đối lưu** (từ mặt đất lên khoảng 11 km); phía trên là **tầng bình lưu** (sách ghi 11–20 km).

**Thành phần không khí bình thường của tầng đối lưu** (theo sách):

| Khí | Tỉ lệ |
|---|---|
| Nitơ | 78,1% |
| Oxy (và ozon) | 20,9% |
| Khí hiếm (heli, argon…) | gần 1% |
| CO~2~ | 0,04% |

Khi các tạp chất có hại lẫn vào làm thay đổi thành phần này thì không khí **bị ô nhiễm**. Công – nông nghiệp càng phát triển thì hai xu hướng càng rõ: **giảm khí cần cho hô hấp** và **tăng khí độc**.

#### a) Sự giảm khí oxy

- **Nguồn O~2~** khí quyển: **30% từ cây xanh trên cạn, 70% từ tảo** (chủ yếu **khuê tảo** ở biển).
- O~2~ giảm vì: biển bị ô nhiễm làm **tảo chết**; khoảng **20% diện tích rừng** của hành tinh đã bị phá; đất trồng trọt bị biến thành đường sá, nhà máy, thành phố; **máy bay phản lực** đốt rất nhiều O~2~ (một chiếc Boeing 707 bay qua Đại Tây Dương tiêu thụ khoảng **35 tấn O~2~**).
- O~2~ **không phải chất ô nhiễm**, nhưng là khí cần cho hô hấp của mọi sinh vật, nên nó giảm là có hại.

> [!cap-nhat] Oxy khí quyển có thật sự đang cạn?
> Đo đạc hiện nay cho thấy O~2~ khí quyển có giảm do đốt nhiên liệu, nhưng mức giảm **rất nhỏ** (cỡ phần triệu mỗi năm). Tỉ lệ O~2~ vẫn khoảng **21%**, nên **không đe dọa hô hấp** trong tương lai gần. Vấn đề đáng lo hơn của cùng quá trình đốt nhiên liệu là **CO~2~ tăng** (biến đổi khí hậu) và **bụi mịn**. Câu "hàng chục tỷ hecta đất trồng trọt mất mỗi năm" trong sách chắc chắn là lỗi số liệu, vì toàn bộ diện tích đất liền của Trái đất chỉ khoảng 15 tỷ ha.

#### b) Các khí và chất độc hại trong khí quyển

| Chất | Nguồn | Tác hại chính |
|---|---|---|
| **SO~2~, SO~3~** | Nhà máy | Kết hợp hơi nước → **H~2~SO~4~** → viêm, dị ứng đường hô hấp |
| **CO** | Than, dầu cháy **không hoàn toàn** (xe, máy). Trên 150 triệu tấn/năm | Gắn hemoglobin → **carboxyhemoglobin**, Hb mất khả năng chở O~2~ → **ngạt** |
| **CO~2~** | Nhiên liệu cháy **hoàn toàn** | Tăng khoảng 2×10^11^ tấn (ứng với chất đốt dùng trong 50 năm), trong khi quang hợp không tăng → **mất cân bằng CO~2~** |
| **Hydrocarbon** | Lò công nghiệp, lò sưởi, xe chạy dầu cháy không hoàn toàn | Có **benzopyren** gây ung thư mạnh |
| **Khói thuốc lá** | Thuốc cháy ở khoảng 700 °C | Amoniac, aldehyd, phenol, ceton, acid cyanhydric, base pyridic, acrolein, furfural, benzopyren, cả cặn DDT → ung thư phổi, miệng – hầu, thực quản, bàng quang; viêm phế quản |
| **Bụi khói** | Thành phố công nghiệp | Hạt **0,1–10 µm** (có thể tới 1000 µm) làm đục bầu trời |
| **Bụi kim loại, sợi độc** | Công nghiệp, nông nghiệp | Chì, amiăng, berili; thuốc trừ sâu đi khắp Trái đất (cả vùng cực) |

Sách còn lưu ý: nơi đông người qua lại, **mầm bệnh và virus phát tán** qua không khí dễ hơn.

> [!bay] CO và CO~2~
> - **CO** sinh ra khi cháy **không hoàn toàn**, gây ngạt vì **chiếm chỗ O~2~ trên hemoglobin**.
> - **CO~2~** sinh ra khi cháy **hoàn toàn**; tác hại trong bài là **mất cân bằng CO~2~ khí quyển**, không phải gắn Hb tạo carboxyhemoglobin.

> [!ung-dung] Ngộ độc CO và bụi mịn
> - CO **không màu, không mùi**; ái lực với hemoglobin cao hơn O~2~ khoảng **200–250 lần**. Vì vậy chỉ một nồng độ nhỏ trong phòng kín (đốt than sưởi, chạy máy phát điện trong nhà, nổ máy xe trong gara) cũng gây ngộ độc. Xử trí: đưa ra chỗ thoáng, **thở oxy** (oxy liều cao, có khi oxy cao áp) để đẩy CO khỏi hemoglobin. Lưu ý máy đo SpO~2~ thông thường có thể cho kết quả **bình thường giả** vì không phân biệt được HbCO với HbO~2~.
> - Hạt bụi càng nhỏ càng vào sâu: **PM10** (đường kính ≤ 10 µm) vào đường hô hấp; **PM2.5** (≤ 2,5 µm) vào tới phế nang và một phần qua máu. Bụi mịn liên quan bệnh hô hấp, tim mạch, đột quỵ, ung thư phổi.

> [!cap-nhat] Số liệu không khí hiện nay
> - **CO~2~**: giáo trình ghi 0,04%; năm 2024 nồng độ trung bình toàn cầu ≈ **424 ppm** (≈ 0,042%; WMO) và mỗi năm tăng thêm ≈ 2–3,5 ppm (số liệu cập nhật hằng năm tại WMO, NOAA — xem sh-13), chủ yếu do đốt nhiên liệu hóa thạch.
> - **Bụi mịn PM2.5**: hướng dẫn chất lượng không khí của **WHO năm 2021** hạ mức khuyến nghị xuống **5 µg/m³ (trung bình năm)** và 15 µg/m³ (trung bình 24 giờ). Theo WHO, **99% dân số thế giới** (kể cả các đô thị lớn của Việt Nam) sống ở nơi vượt mức này, và ô nhiễm không khí ngoài trời cộng trong nhà (đun nấu bằng củi, than) gây khoảng **7 triệu ca tử vong sớm mỗi năm**, chủ yếu do đột quỵ, bệnh tim thiếu máu cục bộ, COPD, ung thư phổi, viêm phổi.
> - **Khói thuốc lá** được xác định chứa trên **7.000 chất**, trong đó khoảng **70 chất gây ung thư**. Benzopyren (benzo[a]pyren) là một chất tiêu biểu.

### 1.4. Nhân tố phóng xạ

Phóng xạ có hại cho người là các **tia phóng xạ ion hóa**. Điều đáng lo nhất:

- **Tác hại lên bộ máy di truyền** ở tế bào sinh dục → ảnh hưởng **thế hệ sau**.
- **Tác hại trước mắt**: ung thư các loại, quái thai.

Ngoài phóng xạ tự nhiên, con người ngày càng tiếp xúc nhiều hơn với phóng xạ từ **y học** (chẩn đoán, điều trị) và **năng lượng nguyên tử**.

#### a) Nguồn phóng xạ tự nhiên

- Gồm **tia vũ trụ** và chất phóng xạ trong **đất, đá, mỏ phóng xạ**.
- Tia vũ trụ bị khí quyển hấp thụ bớt, nên **càng lên cao liều càng lớn**: người đi máy bay nhận liều cao hơn người ở mặt đất.
- **Số liệu của sách:** mỗi người nhận khoảng **150 milirad/năm**; một thế hệ (30 năm) nhận trung bình **4,5 rad**.
- **Vùng Travancore (Ấn Độ)** có mỏ **monazit chứa thori**: một số người nhận tới **2 roentgen/năm** tia gamma, trung bình **10–30 rad mỗi thế hệ** — rất cao so với mức chung, nhưng con người **vẫn sống được ở đó**. Đây là thích nghi hay một tính không cảm ứng ngoại lệ thì **chưa được giải thích đầy đủ**.

> [!cap-nhat] Đơn vị và liều nền hiện nay
> - Sách dùng đơn vị cũ **rad** (liều hấp thụ) và **roentgen**. Đơn vị SI hiện nay: **gray (Gy)**, với 1 Gy = 100 rad; và liều hiệu dụng tính bằng **sievert (Sv)**, 1 Sv = 100 rem.
> - Theo UNSCEAR, liều phóng xạ **tự nhiên trung bình** mỗi người khoảng **2,4 mSv/năm**, trong đó khoảng **một nửa** (≈ 1,3 mSv) đến từ khí **radon** trong nhà (sách 2008 chưa nhắc radon); con số này dao động nhiều theo vùng (khoảng 1–10 mSv/năm). Con số 150 mrad/năm của sách thấp hơn, nhiều khả năng vì không tính radon.
> - **Giới hạn liều** theo khuyến cáo ICRP (Công bố 103, 2007; vẫn là nền tảng của quy định hiện hành): người làm nghề bức xạ **20 mSv/năm** (trung bình 5 năm, không năm nào quá 50 mSv); công chúng **1 mSv/năm** (không tính chiếu xạ tự nhiên và chiếu xạ y tế của chính người bệnh). Để so sánh: một phim X-quang ngực ≈ 0,02–0,1 mSv; một lần chụp CT bụng ≈ vài đến 10 mSv.

#### b) Phóng xạ trong y học và năng lượng nguyên tử

- **Người làm điện quang**, bệnh nhân chụp X-quang, dùng đồng vị phóng xạ, xạ trị đều nhận liều cao hơn bình thường. Cần bảo vệ đặc biệt **vùng tuyến sinh dục** và nơi **tế bào đang phân chia**, vì đó là nơi **nhạy cảm nhất** và tổn thương ở đây để lại hậu quả cho con cháu.
- **Bụi phóng xạ** từ nổ, thử vũ khí hạt nhân, lò phản ứng → vào khí quyển → rơi xuống đất → vào cây cỏ → theo **chuỗi thức ăn** vào người. Tính đến đầu thập niên 1970, tổng sức nổ của các vụ thử hạt nhân bằng khoảng **37.500 lần** quả bom Hiroshima.
- Lò phản ứng, nhà máy điện hạt nhân về nguyên tắc có bảo hộ đầy đủ nhưng vẫn **có sự cố**. **Chất thải phóng xạ** là vấn đề nan giải.

**Stronti 90 — nguyên tố phóng xạ nguy hiểm nhất** sinh ra từ thử vũ khí hạt nhân:

- *Vì sao nguy hiểm?* Cấu trúc hóa học **gần giống calci**, nên cơ thể sinh vật "nhận nhầm" là calci. Nó đi theo chuỗi: cây cỏ, tảo → thân mềm, giáp xác, cá → trứng, **sữa bò** → người.
- Khoảng **25%** lượng Sr-90 qua đường miệng được hấp thu. Nó **đọng vào xương**, chiếu xạ **tủy xương** lâu dài → **thiếu máu ác tính, ung thư xương, ung thư máu**.
- Sr-90 còn **qua được nhau thai**, gây đột biến ở thai.

**Phôi, thai đặc biệt nhạy cảm với phóng xạ** vì đang có quá trình **biệt hóa tế bào** mạnh để tạo các cơ quan, nhất là hệ thần kinh. **Võng mạc** cũng rất nhạy cảm.

- Các bà mẹ mang thai bị nhiễm xạ trong vụ nổ nguyên tử năm 1945 ở Nhật Bản sinh con bị: **đầu nhỏ**, mắt nhỏ, mù, **đục nhân mắt**, tật khe mắt, viêm võng mạc, lác, giật nhãn cầu, mất phối hợp, **nứt đốt sống**, **chậm trí tuệ**, dị tật sọ não.
- Tế bào thần kinh bị hủy sẽ bị thực bào; tế bào còn lại chỉ tái tạo được hạn chế. Tác hại có thể **kín đáo**, về sau mới lộ ra; mối lo lớn là **ung thư** ở trẻ bị chiếu xạ từ trong bào thai.
- Chiếu xạ trực tiếp **tinh hoàn** gây đột biến tinh trùng, rối loạn nhiễm sắc thể.

> [!ung-dung] Nguyên tắc an toàn bức xạ
> - Chỉ định chụp X-quang, CT khi thật cần; với phụ nữ trong độ tuổi sinh đẻ phải **hỏi khả năng có thai** trước khi chụp vùng bụng – chậu.
> - Che chắn tuyến sinh dục, giữ liều **thấp nhất có thể đạt được** (nguyên tắc ALARA); nhân viên bức xạ đeo **liều kế** cá nhân.
> - Siêu âm và cộng hưởng từ (MRI) **không dùng tia ion hóa**, nên là lựa chọn ưu tiên trong thai kỳ khi phù hợp.
> - Sau sự cố hạt nhân, người ta có thể phát **viên kali iodid** để tuyến giáp "no iod" và không hấp thu **iod phóng xạ** (I-131).

### 1.5. Ô nhiễm thức ăn do nhân tố vô sinh

- **Hóa học hóa nông nghiệp** giúp thâm canh nhưng để lại **dư lượng** thuốc trừ sâu, diệt chuột, diệt cỏ, chất kích thích sinh trưởng trong hạt, rau, thịt, mỡ, hoặc đi qua nhiều sinh vật trung gian của chuỗi thức ăn rồi vào người.
- **Phụ gia** tạo mùi, vị, màu bằng hóa chất ít nhiều có hại.
- **Đồ nhựa:** tránh dùng bao bì chất dẻo **không dành cho thực phẩm**; dụng cụ ăn uống bằng nhựa khi **lão hóa** có thể sinh chất có hại, có thể gây ung thư.

> [!ung-dung] Áp dụng hằng ngày
> Tuân thủ **thời gian cách ly** sau phun thuốc bảo vệ thực vật trước khi thu hái; rửa và ngâm rau quả kỹ; chỉ dùng hộp nhựa có ghi dùng cho thực phẩm, không quay lò vi sóng bằng hộp nhựa không ghi "dùng được cho lò vi sóng". Với cơ sở sản xuất thực phẩm, dư lượng thuốc bảo vệ thực vật và phụ gia đều có **giới hạn tối đa** theo quy chuẩn an toàn thực phẩm.

> [!cap-nhat] Vi nhựa (bổ sung – kiến thức hiện nay)
> Rác nhựa không bị vi sinh vật phân hủy (như sách nêu) mà **vỡ vụn dần** thành **vi nhựa** (hạt < 5 mm) và **nano nhựa** (< 1 µm). Chúng có mặt trong nước biển, nước máy, muối, hải sản, không khí, và đã được phát hiện trong **máu, nhau thai, phổi, mảng xơ vữa** của người. Một nghiên cứu trên *NEJM* (2024) thấy người có vi/nano nhựa trong mảng xơ vữa động mạch cảnh có nguy cơ nhồi máu cơ tim, đột quỵ, tử vong cao hơn trong khoảng 3 năm theo dõi. Tuy vậy đây mới là **mối liên quan**, chưa chứng minh nhân quả; tác hại sức khỏe của vi nhựa **vẫn đang được nghiên cứu**. Một số chất phụ gia trong nhựa (như **bisphenol A**, phthalat) đã được biết là chất gây rối loạn nội tiết.

### 1.6. Tiếng động

- **Yên lặng tuyệt đối kéo dài** cũng gây **rối loạn tâm thần**. Vì vậy người ta tạo tiếng động nền bình thường cho người làm việc trong môi trường vũ trụ yên lặng.
- **Tiếng ồn quá mức** (thành phố công nghiệp, công trường, đường đông xe) gây rối loạn, chủ yếu là rối loạn **hệ thần kinh**.

**Thang tiếng động (theo sách):**

| Cường độ | Tác động |
|---|---|
| Đến 85 dB | Chịu được |
| 85–140 dB | Khó chịu |
| 140–145 dB | Không chịu nổi, có thể **điếc** |
| Nhạc khuếch đại ≥ 100 dB | **Điếc tạm thời** |

**Tác hại toàn thân của tiếng ồn:** tăng **cholesterol** máu, tăng **huyết áp**, co mao mạch ở ngón tay và mắt, giãn mạch máu não gây nhức đầu.

Giải pháp: quy hoạch đô thị, máy móc giảm thanh, điều tiết giao thông, ý thức không gây ồn.

Sách còn lưu ý: **siêu âm** (trong thực nghiệm) cũng có thể gây rối loạn và **tổn thương nhiễm sắc thể**.

> [!bay] Decibel
> Sách viết "1 dB là âm nhỏ nhất tai người nghe được". Chính xác hơn: decibel là **đơn vị theo thang logarit** so với một mức chuẩn; mức chuẩn ứng với **ngưỡng nghe** của tai người được quy ước là **0 dB**. Vì là thang logarit, **cứ tăng 10 dB thì cường độ âm tăng 10 lần** (nên 100 dB không phải "gấp đôi" 50 dB mà mạnh hơn 100.000 lần). Mốc **85 dB** của sách trùng với ngưỡng mà các quy định vệ sinh lao động hiện nay thường dùng cho 8 giờ tiếp xúc.

### 1.7. Môi trường làm việc và bệnh nghề nghiệp

Chính hệ thống sản xuất do con người lập ra lại tạo điều kiện sinh thái bất lợi cho người lao động:

- **Tác nhân:** bụi bông, bụi kim loại, bụi than, khí độc, hóa chất công nghiệp, nhiệt độ và áp suất cao…
- **Bệnh:** phổi, tai, mắt, tim mạch, thần kinh…
- **Biện pháp:** vệ sinh lao động, phòng hộ lao động, máy khử tiếng ồn, máy hút bụi, thông khí, điều hòa nhiệt độ.

> [!vi-du] Một số bệnh nghề nghiệp quen thuộc
> Bụi phổi silic (thợ mỏ, đá), bụi phổi bông (công nhân dệt), bệnh do amiăng (u trung biểu mô màng phổi), điếc nghề nghiệp do tiếng ồn, nhiễm độc chì. Ở Việt Nam đây là các bệnh nằm trong danh mục bệnh nghề nghiệp được bảo hiểm.

### 1.8. Chu kỳ địa vật lý và nhịp sinh học thích ứng ở người

**Nguồn gốc.** Trái đất tự quay và quay quanh Mặt trời, Mặt trăng quay quanh Trái đất… nên ánh sáng, nhiệt độ, độ ẩm, áp suất, trường điện từ khí quyển **biến đổi theo chu kỳ**: ngày – đêm, mùa, tuần trăng. Qua tiến hóa thích nghi lâu dài, cơ thể người hình thành **nhịp sinh học thích ứng**.

**Định nghĩa (diễn lại):** nhịp sinh học thích ứng là các **nhịp điệu bên trong** — nhịp sinh lý, sinh hóa của cơ thể — khớp với nhịp chu kỳ của môi trường ngoài; chúng tạo thành một hệ thống tập tính có tính chu kỳ và **di truyền qua các thế hệ**.

**Nhịp ngày đêm:**

- **Đêm:** bóng tối, yên tĩnh, nhiệt độ giảm → **ức chế** nhiều trung khu não → **pha ngủ**.
- **Ngày:** ánh sáng **kích thích** trung khu thần kinh, não liên tục nhận thông tin → **pha thức** (năng hoạt).
- Nhiều chức năng chạy theo nhịp ngày đêm: **thân nhiệt, hô hấp, nhịp tim, huyết áp động mạch, bài tiết chất điện giải**…

**Số liệu của sách cần nhớ:**

| Nội dung | Số liệu |
|---|---|
| Thân nhiệt | Ban đêm thấp hơn ban ngày (nghiên cứu của T. Hellbrügge, sách phiên âm "Henbrucae") |
| Giờ thân nhiệt thấp nhất | Trẻ 2–3 tuần: 21 giờ; từ 6 tháng: 23 giờ; 2–3 tuổi: 3 giờ sáng; 10–14 tuổi: 5 giờ sáng; người lớn: 7 giờ sáng |
| Nhịp tim | Nhịp ngày đêm xuất hiện từ **tuần thứ 6** sau sinh, rõ từ **5–6 tháng**; ban ngày cao hơn ban đêm **30%** |
| Thời gian ngủ | Cuối năm đầu: 16–17 giờ; 2–3 tuổi: 14–15 giờ; 4–5 tuổi: 13 giờ; từ 6 tuổi: 12 giờ; người lớn: **7–8 giờ** (thức 17–18 giờ) |

**Các nguyên tắc rút ra:**

- Các chức năng ở trẻ hình thành nhịp **tương đối độc lập**, vào thời điểm khác nhau; **biên độ nhịp tăng dần** theo tuổi; ban đêm các chức năng đều giảm.
- Muốn giữ nhịp ngày đêm của các chức năng sinh lý thì **pha thức phải trùng ban ngày**.
- Thức: ưu thế các quá trình hoạt động sống; ngủ: ưu thế các quá trình nghỉ ngơi, phục hồi. Sự phân bố chặt chẽ này là kết quả **chọn lọc tự nhiên**.
- **Mất ngủ kéo dài** gây rối loạn nghiêm trọng, thậm chí chết; giấc ngủ bình thường **bảo vệ thần kinh trung ương**.
- Khi đổi giờ làm việc (làm ca đêm…) cần **tập luyện trước** và theo dõi để điều chỉnh.

> [!cap-nhat] Đồng hồ sinh học
> - Hiện nay đã biết "đồng hồ trung tâm" nằm ở **nhân trên chéo thị** (vùng dưới đồi), được ánh sáng qua võng mạc chỉnh giờ; ban đêm tuyến tùng tiết **melatonin**. Mỗi tế bào còn có đồng hồ phân tử dựa trên các **gen đồng hồ** điều hòa ngược lẫn nhau. Phát hiện cơ chế phân tử này được trao **giải Nobel Y học 2017** (Hall, Rosbash, Young).
> - Ở người lớn, thân nhiệt thấp nhất thường rơi vào **cuối đêm, khoảng 2 giờ trước giờ thức dậy** quen thuộc; thời điểm cụ thể thay đổi theo thói quen ngủ. Đi thi vẫn theo số liệu sách.

> [!yhct] "Thiên nhân hợp nhất" (quan niệm truyền thống): con người tương ứng với trời đất
> YHCT (từ *Hoàng Đế Nội Kinh*) coi con người là một bộ phận của tự nhiên, **"thiên nhân tương ứng"** (thiên nhân hợp nhất): hoạt động sinh lý thay đổi theo ngày đêm và bốn mùa. Ví dụ quan niệm dương khí mạnh ban ngày, thu vào ban đêm; dưỡng sinh khuyên "xuân hạ dưỡng dương, thu đông dưỡng âm", ngủ thức theo nhịp trời. Ý tưởng này **tương đồng về hướng** với khái niệm nhịp sinh học thích ứng: cơ thể khớp nhịp với chu kỳ môi trường.
> Tuy vậy đây là **quan điểm triết học – y học cổ**, không phải bằng chứng khoa học; các chi tiết cụ thể (như giờ vượng của từng tạng phủ theo "tý ngọ lưu chú") chưa được chứng minh tương ứng với đồng hồ sinh học phân tử.

## 2. Loài người và ngoại cảnh hữu sinh

Quan hệ giữa người và sinh giới là quan hệ **hữu cơ, mật thiết**, trong đó con người **tác động trở lại rất mạnh** lên các nhân tố hữu sinh để phục vụ lợi ích của mình. Sách giới hạn ở ba vấn đề: **dinh dưỡng**, **phát triển dân số** và **bệnh tật do sinh vật**.

### 2.1. Quan hệ dinh dưỡng

#### a) Nhu cầu lương thực

- Thức ăn dùng để **xây dựng cơ thể**, bù năng lượng mất trong trao đổi chất, và nhất là để **hoạt động, lao động**. Nhu cầu thay đổi theo **giới, tuổi, tính chất lao động**.
- Khẩu phần một người: **2250–2750 kcal/ngày**, trung bình **2400 kcal/người/ngày**.
- Sách nhận định: dân số tăng nhanh nên nhu cầu đã vượt khả năng cung cấp của sinh quyển; lại thêm thức ăn **phân bố không đều** giữa các vùng và các tầng lớp xã hội → thiếu lương thực càng nghiêm trọng.

#### b) Gia tăng dân số và mâu thuẫn với nguồn thức ăn

Thời xa xưa người ít, sống nhờ săn bắt, hái lượm. Nhờ **trồng trọt và chăn nuôi**, dân số tăng ngày càng nhanh:

| Thời điểm | Dân số thế giới (theo sách) | Thời gian để tăng thêm 1 tỷ |
|---|---|---|
| 8000 năm TCN | ≈ 5 triệu | |
| Đầu Công nguyên | ≈ 200 triệu | |
| 1850 | ≈ 1 tỷ | (hàng chục nghìn năm) |
| 1930 | ≈ 2 tỷ | 80 năm |
| 1960 | ≈ 3 tỷ | 30 năm |
| 1976 | ≈ 4 tỷ | 16 năm |
| 1997 | ≈ 5 tỷ | 21 năm |
| 2001 | 6.134.135.000 | |

![Hình 2. Dân số thế giới theo các mốc của giáo trình (cột đậm) và số liệu cập nhật sau năm 2001 (cột nhạt)](dan-so.svg)

> [!cap-nhat] Dân số hiện nay
> - Theo Liên Hợp Quốc, thế giới đạt **7 tỷ người khoảng năm 2011** và **8 tỷ người vào tháng 11/2022**; năm 2024 khoảng **8,2 tỷ**. Tốc độ tăng đã chậm lại (dưới 1%/năm). Dự báo *Triển vọng Dân số Thế giới 2024* (UN WPP 2024): dân số đạt **đỉnh ≈ 10,3 tỷ vào giữa thập niên 2080** rồi giảm nhẹ; tuổi thọ trung bình thế giới năm 2024 ≈ **73,3 năm**.
> - **Việt Nam** đạt **100 triệu dân năm 2023**; dân số trung bình năm 2025 ≈ **102,3 triệu**, tổng tỷ suất sinh **1,93 con/phụ nữ** (dưới mức sinh thay thế 2,1), tuổi thọ trung bình **74,7 năm**, tỷ số giới tính khi sinh ≈ 110 bé trai/100 bé gái (Cục Thống kê – trước đây là Tổng cục Thống kê, công bố 2026; số liệu cập nhật hằng năm tại nso.gov.vn). Vấn đề dân số của Việt Nam hiện nay không còn là "tăng quá nhanh" mà là **mức sinh thấp, già hóa nhanh và mất cân bằng giới tính khi sinh**.
> - Các mốc lịch sử của sách (5 tỷ năm 1997…) khác đôi chút so với ước tính hiện nay của LHQ (5 tỷ vào khoảng 1987, 6 tỷ khoảng 1999). Đi thi dùng số liệu sách.
> - Về lương thực: thế giới hiện **sản xuất đủ calo** cho tổng dân số, nhưng do phân phối không đều, nghèo đói, xung đột nên năm 2025 vẫn còn khoảng **645 triệu người thiếu đói** (≈ 8% dân số; FAO và cộng sự, báo cáo SOFI 2026) — đúng như ý "phân bố không đều" của sách.

**Vì sao nguồn thức ăn có nguy cơ giảm?**

1. **Diện tích canh tác thu hẹp:** xói mòn; đất bị lấy làm thành phố, khu công nghiệp, giao thông.
2. **Đất còn lại bị thoái hóa, bạc màu:** canh tác bừa bãi; khoáng chất bị lấy đi theo mùa màng mà **không được bón bù** đủ → đất nghèo dần (sách liệt kê mất "natri", phospho, kali, calci). Nước tưới, nước ngầm giảm; bãi chăn thả cằn cỗi.
3. **Phá hoại của sinh vật:** côn trùng, nấm, gặm nhấm, dịch bệnh cây trồng và vật nuôi. Hằng năm khoảng **20%** tổng sản lượng thức ăn **không đến được tay người tiêu dùng**.

> [!bay] "Natri" hay "nitơ"?
> Ba nguyên tố đa lượng cây lấy đi nhiều nhất và phải bón bù là **N – P – K** (nitơ, phospho, kali), cùng calci. Chữ "natri" trong danh sách của sách nhiều khả năng là **lỗi in của "nitơ"**. Nếu đề thi chép nguyên câu của sách thì nhận ra ý chính: đất mất khoáng do thu hoạch mà không bón bù.

#### c) Biện pháp khắc phục

1. **Hạ tỷ lệ tăng dân số** toàn thế giới; **kế hoạch hóa dân số** theo từng quốc gia, từng quần thể.
2. **Tăng nguồn lương thực, thực phẩm** bằng khoa học:
   - bảo vệ, bồi dưỡng, cải tạo, phát triển đất canh tác;
   - hạn chế tối đa phá hoại của côn trùng, gặm nhấm, nấm bệnh cây, bệnh gia súc;
   - dùng **di truyền chọn giống** năng suất và phẩm chất cao;
   - khai thác nguồn lợi **biển và đại dương**;
   - **hóa tổng hợp** thức ăn; thức ăn từ **nấm men, vi sinh vật giàu protein**.

### 2.2. Quan hệ với sinh vật ký sinh gây bệnh

- Vi sinh vật gây bệnh luôn tìm cách xâm nhập, nhưng cơ thể có các tuyến phòng thủ: **da** vững chắc (hàng rào), **hệ thực bào** tiêu diệt mầm bệnh, **tế bào có thẩm quyền miễn dịch** tiết **kháng thể** trung hòa độc tố…
- Nhờ y – dược học, vệ sinh phòng bệnh, **vaccin**, thuốc điều trị, các trận dịch không còn tự do cướp đi hàng triệu người trong thời gian ngắn; ở nhiều nước phát triển, bệnh nhiễm trùng không còn là vấn đề lớn.
- Nhưng qua **chọn lọc**, xuất hiện các quần thể ký sinh **đột biến** vẫn giữ độc lực và **kháng thuốc** → phải tìm kháng sinh mới thay kháng sinh cũ.
- Kết luận của sách: cuộc đấu tranh đang nghiêng về phía con người nhưng **vẫn tiếp diễn quyết liệt**.

> [!ung-dung] Kháng thuốc là chọn lọc tự nhiên diễn ra trước mắt
> Mỗi lần dùng kháng sinh, vi khuẩn nhạy cảm chết, vi khuẩn mang gen kháng sống sót và nhân lên. Dùng kháng sinh **không cần thiết, sai liều, bỏ dở liệu trình**, hay dùng tràn lan trong chăn nuôi đều làm **tăng áp lực chọn lọc**. WHO coi kháng kháng sinh là một trong những mối đe dọa lớn nhất với sức khỏe toàn cầu. Đại dịch COVID-19 (2020) cũng cho thấy dịch bệnh mới vẫn có thể lan khắp thế giới rất nhanh.

> [!cap-nhat] Kháng kháng sinh (AMR) và "Một sức khỏe" (bổ sung – kiến thức hiện nay)
> - **Gánh nặng AMR**: theo dự án GRAM (*The Lancet*, 2024), năm 2021 vi khuẩn kháng thuốc **trực tiếp gây ≈ 1,14 triệu ca tử vong** và **liên quan tới ≈ 4,71 triệu ca**; nếu không can thiệp, giai đoạn 2025–2050 sẽ có **hơn 39 triệu ca tử vong** trực tiếp do AMR, nặng nhất ở Nam Á và Đông Nam Á. Tử vong liên quan **kháng carbapenem** và **MRSA** tăng mạnh nhất.
> - **Một sức khỏe (One Health)**: cách tiếp cận được WHO, FAO, Tổ chức Thú y Thế giới (WOAH) và UNEP thống nhất định nghĩa năm 2021 — sức khỏe **con người, vật nuôi, động vật hoang dã, thực vật và môi trường** gắn chặt với nhau, nên phải được xử lý **liên ngành**. Ví dụ: khoảng 60% bệnh truyền nhiễm ở người và phần lớn bệnh mới nổi có nguồn gốc từ động vật (cúm gia cầm, SARS, COVID-19…); kháng sinh dùng trong chăn nuôi tạo gen kháng có thể lan sang người qua thực phẩm, nước, đất.
> - Năm 2025, Đại hội đồng Y tế Thế giới đã thông qua **Hiệp định Đại dịch** của WHO, trong đó cách tiếp cận Một sức khỏe là một nội dung trọng tâm.
>
> Đây đúng là ý "cuộc đấu tranh vẫn tiếp diễn quyết liệt" của giáo trình, nay có số liệu cụ thể.

## 3. Các nhân tố sinh thái gây đột biến cảm ứng ở người

### 3.1. Khái niệm

- **Đột biến tự nhiên**: xảy ra trong quần thể người với một tần số nhất định.
- **Đột biến cảm ứng**: do các **tác nhân đã biết của ngoại cảnh** gây ra.

Tác nhân đột biến cảm ứng có thể tác động lên hai loại tế bào với hậu quả rất khác nhau:

| | **Đột biến tế bào soma** (tế bào thể) | **Đột biến tế bào sinh dục** |
|---|---|---|
| Tế bào bị tác động | Tế bào lưỡng bội của các mô cơ thể | Dòng tế bào sinh dục |
| Dạng đột biến | Số lượng, cấu trúc NST (nhiễm sắc thể) hoặc đột biến gen | (như bên) |
| Hậu quả | Dòng tế bào bất thường → **thể khảm**, khiếm khuyết kiểu hình (hình thái, sinh lý, sinh hóa); hoặc dòng tế bào **giảm ức chế tiếp xúc**, có ưu thế chọn lọc → phát triển thành **khối u, ung thư** | Chết giao tử, chết hợp tử, chết phôi, chết thai; hoặc bất thường, dị tật, bệnh ở **thế hệ sau** |
| Di truyền cho đời sau? | **Không** — tác hại tại chỗ ở người mang đột biến | **Có** |

> [!bay]
> Ung thư phần lớn là bệnh của **đột biến soma**: nó có thể "di truyền" từ tế bào mẹ sang tế bào con trong cơ thể (tạo khối u) nhưng **không truyền cho con cái**. Chỉ đột biến ở dòng tế bào sinh dục mới di truyền qua thế hệ.

### 3.2. Tác nhân vật lý

**Tia phóng xạ ion hóa (tia β, tia γ) và tia cực tím** gây đột biến rất mạnh, đặc biệt ở người.

- Liều **10 rad** đã có thể gây **sai lệch cấu trúc NST**: đứt NST, NST **hai tâm, ba tâm**, NST **hình vòng**.
- Có thể làm bất hoạt chức năng **tâm động** hoặc **phá hủy thoi vô sắc** → **đa bội**, nội nhân đôi toàn phần hoặc một phần.
- **Mức nhạy cảm:** NST đang phân chia (nhất là **kỳ đầu, kỳ giữa**) > NST ở gian kỳ; NST trong **giảm phân** > trong **nguyên phân**.
- **Thời gian tác hại:** bắt đầu khoảng **1 giờ** sau chiếu xạ và có thể kéo dài tới **30 năm**.
- Chiếu xạ tế bào phôi thường tạo phôi, thai **không sống được**.
- **Liều – đáp ứng:** tần số đột biến **tăng khi liều tăng**, nhưng **không tỷ lệ thuận nghiêm ngặt**.

**Hai kiểu nhận liều chiếu xạ:**

| Kiểu | Đặc điểm | Ví dụ |
|---|---|---|
| **Chiếu xạ tai biến** | Một liều **lớn**, trong **thời gian ngắn** | Nạn nhân bom nguyên tử Hiroshima, Nagasaki |
| **Chiếu xạ hệ thống** | Liều **rất nhỏ**, **nhiều lần**, kéo dài **nhiều năm** | Người làm nghề tiếp xúc phóng xạ, tia X |

Theo sách, chiếu xạ hệ thống tuy liều nhỏ nhưng **hiệu quả gây đột biến không nhỏ hơn** chiếu xạ tai biến → phải có phương tiện **bảo vệ an toàn** cho người làm việc với phóng xạ.

**Đồng vị phóng xạ** dùng trong phòng thí nghiệm và nghiên cứu sinh lý cũng gây đột biến được: cobalt phóng xạ (^60^Co, nguồn tia gamma), phospho phóng xạ (^32^P), iod phóng xạ.

> [!bay] Iod phóng xạ
> Sách in "^135^I". Đồng vị iod phóng xạ dùng phổ biến trong y học là **^131^I** (điều trị cường giáp, ung thư tuyến giáp) và ^123^I (chẩn đoán). Nhiều khả năng sách in nhầm.

**Tia cực tím (UV):** được **ADN (DNA) hấp thụ** (sách giải thích "do bước sóng dài" — dài hơn tia X, tia gamma) → tần số đột biến cảm ứng khá cao, nhất là **đột biến gen**.

> [!vi-du] UV gây đột biến như thế nào?
> ADN hấp thụ mạnh tia cực tím ở bước sóng khoảng **260 nm**. Năng lượng này làm hai base **pyrimidin đứng cạnh nhau** trên cùng một mạch (thường là hai T) liên kết cộng hóa trị với nhau, tạo **dimer thymin**. Chỗ này làm ADN polymerase sao chép sai → đột biến điểm. UV không đủ năng lượng để ion hóa, nên **không xếp vào bức xạ ion hóa**. Đây là cơ chế chính của **ung thư da** do phơi nắng; bệnh **khô da sắc tố** (xeroderma pigmentosum) là do thiếu enzym sửa dimer, người bệnh bị ung thư da từ rất sớm.

**Tia Rơnghen (tia X):** gây đột biến rõ ràng → phải **hạn chế tối đa** chụp, chiếu X-quang cho **phụ nữ có thai** và **đang trong thời kỳ có thể thụ thai**.

**Nguyên tắc chung (theo sách):** tia có **bước sóng ngắn** (năng lượng cao) rất có hại vì bị cơ thể hấp thụ; tia có bước sóng khác chỉ gây hại khi được **ADN hoặc protein hấp thụ đặc hiệu**.

**Nhiệt độ:**

- Tăng nhiệt độ **10 °C** → tần số đột biến có thể tăng **5 lần**, dễ gây biến đổi cấu trúc NST.
- *Vì sao?* Nhiệt độ tăng làm phân tử, nguyên tử hoạt động mạnh hơn, biến đổi bên trong phân tử dễ xảy ra.
- Sách mô tả: biến đổi chủ yếu là thay một **purin bằng một pyrimidin** (thay thế khác loại); một số tác giả cho rằng nhiệt làm biến đổi **guanin ở vị trí N1**, tạo cặp **G – T** bất thường (thay vì G – C).

> [!bay] Hai ý trong sách chưa khớp nhau
> Cặp G – T bất thường, sau một lần sao chép, làm G – C thành **A – T**: purin vẫn thay bằng purin (G → A), tức là **thay thế cùng loại** (transition), chứ không phải thay thế khác loại. Khi học, nhớ đúng hai dữ kiện của sách: **nhiệt độ tăng → đột biến tăng**, và **cặp G – T bất thường**.

### 3.3. Tác nhân hóa học

Ba nhóm, khác nhau ở **mức độ phổ biến của tiếp xúc**:

| Nhóm | Đặc điểm tiếp xúc | Ví dụ trong sách |
|---|---|---|
| **Thuốc và dược liệu** | **Số lượng chất lớn nhất** | Thalidomid; thuốc ức chế phân bào (dẫn xuất **6-mercaptopurin**, **cytosin arabinosid**…); thuốc ức chế tổng hợp ADN, một số kháng sinh, thuốc điều trị ung thư; hormon steroid; một số thuốc mê (paraldehyd, chloral hydrat); chất gây ảo giác LSD (sách in "ZSD") |
| **Hóa chất nông nghiệp, sinh hoạt** | Ít loại nhưng **dùng phổ cập khắp nơi** | Thuốc trừ sâu, diệt cỏ, diệt côn trùng, diệt nấm |
| **Hóa chất phòng thí nghiệm, công nghiệp** | **Ít người tiếp xúc hơn** | Formaldehyd, diazomethan, phenol, cafein, methylcholanthren, dibenzanthracen; sản phẩm quặng mỏ (peroxyd hydro, clorua sắt, clorua mangan, clorua nhôm); khí độc **yperit** (mù tạt) trong chiến tranh |

Một số điểm sách nhấn mạnh:

- **Thalidomid** gây ra **hàng nghìn trẻ dị dạng nặng** do mẹ dùng thuốc khi mang thai.
- **Thuốc ức chế phân bào** gây sai lệch cấu trúc, khu trú ở **vùng dị nhiễm sắc** của NST.
- **Thuốc ức chế tổng hợp ADN**, kháng sinh, thuốc trị u ác tính gây **tái tổ hợp, cấu trúc lại NST**, trao đổi chéo ở tế bào soma.
- Một số chất (sách gọi "sản phẩm alkali") dễ **vượt hàng rào máu – tuyến sinh dục**, đạt nồng độ cao ở **tinh hoàn**, gây hại trực tiếp cho tế bào sinh dục.
- Vì hóa chất bảo vệ thực vật gây đột biến ngày càng được xác định nhiều, cần **quy chế sử dụng chặt chẽ**.

> [!cap-nhat] Thalidomid: gây quái thai chứ không phải chất gây đột biến
> Giáo trình xếp thalidomid vào nhóm gây đột biến cảm ứng. Hiện nay thalidomid được xác định là chất **gây quái thai** (teratogen) điển hình: nó gắn protein **cereblon**, làm thay đổi sự phân hủy một số protein điều hòa phát triển chi ở phôi, gây tật **chi ngắn kiểu "chân tay hải cẩu"** (phocomelia). Nó **không làm biến đổi ADN** và dị tật **không di truyền** cho thế hệ sau. Thảm họa thalidomid (cuối thập niên 1950 – đầu 1960, trên 10.000 trẻ) dẫn tới yêu cầu **thử độc tính sinh sản** bắt buộc với thuốc mới. Hiện thalidomid vẫn được dùng (có kiểm soát nghiêm ngặt) để điều trị **đa u tủy xương** và phong thể ban đỏ nút. Đi thi theo sách: thalidomid là ví dụ đầu tiên của nhóm thuốc.

> [!ung-dung] Thuốc chống ung thư — tác dụng điều trị cũng chính là nguy cơ
> Nhiều thuốc hóa trị diệt tế bào ung thư bằng cách **làm hỏng ADN hoặc chặn phân bào**. Vì vậy chúng cũng tổn thương tế bào lành đang phân chia (tủy xương, niêm mạc, nang tóc, tế bào sinh dục), có thể gây **ung thư thứ phát** về sau và ảnh hưởng thai nhi. Người dùng thuốc cần tránh thai trong và sau điều trị; nam giới trẻ có thể được tư vấn **trữ tinh trùng** trước khi hóa trị. Nhân viên y tế pha thuốc hóa trị phải có tủ an toàn sinh học và đồ bảo hộ.

### 3.4. Tác nhân sinh vật học

**Virus — quan trọng nhất.**

- Hầu hết virus gây bệnh ở người đều gây được đột biến **in vitro** (trong ống nghiệm); mức độ **in vivo** (trong cơ thể) chưa đánh giá hết, nhưng việc virus gây đột biến và **quái thai** đã được khẳng định.
- **Rubella:** mẹ nhiễm trong **những tuần đầu thai kỳ** → con có thể dị tật **mắt, tai, tim, não**.
- *Nghịch lý về mức độ tổn thương:* tổn thương **quá nặng** (NST tan vụn) làm tế bào **chết nhanh**, không tạo dòng đột biến; còn tổn thương **nhẹ hơn** lại sinh ra **nhiều đột biến** (vì tế bào sống sót và truyền lỗi cho tế bào con).

**Vi khuẩn, nguyên sinh động vật:**

| Tác nhân | Tác động |
|---|---|
| Rickettsia, Mycoplasma | Thương tổn cấu trúc NST |
| Độc tố vi khuẩn: streptolysin O, độc tố bạch hầu, độc tố tả | Thương tổn cấu trúc NST |
| Nuclease của nhiều vi khuẩn | Rối loạn trao đổi acid nucleic → rối loạn NST |
| Mycobacteria (vi khuẩn lao) | Phân bào bất thường → **tế bào nhiều nhân ở phổi** trong quá trình lao hóa |
| **Toxoplasma** (nguyên sinh động vật) | Lệch bội, nội nhân đôi, NST tan vụn, đứt gãy NST ngay trên bệnh nhân |

**Tự miễn dịch và sai lệch NST:** một số bệnh tuyến giáp và tâm thần phân liệt có liên quan giữa quá trình **tự miễn** và **sai lệch NST**. Quan hệ có thể theo **hai chiều**: tự miễn gây sai lệch NST, hoặc tế bào sai lệch NST bị coi là "vật lạ" và khởi động tự miễn. Ví dụ: có **kháng thể kháng tuyến giáp** ở bệnh nhân Down và ở mẹ họ; rối loạn chức năng tuyến giáp ở gia đình bệnh nhân Down cao **gấp 2 lần** quần thể chung.

**Tuổi và chuyển hóa:** rối loạn chuyển hóa trong tế bào và sự tích lũy sản phẩm chuyển hóa khi tế bào **già** làm tăng đột biến gen và đột biến NST. Phụ nữ **trên 35 tuổi** có nguy cơ sinh con **lệch bội NST** cao hơn người trẻ.

> [!ung-dung] Phòng ngừa trong thực hành
> - **Tiêm vaccin sởi – quai bị – rubella** cho trẻ em gái và phụ nữ trước khi mang thai; không tiêm vaccin sống này khi đang có thai.
> - Phòng **Toxoplasma** khi mang thai: ăn thịt chín kỹ, rửa rau sống, hạn chế dọn phân mèo.
> - Thai phụ **từ 35 tuổi** được tư vấn **sàng lọc trước sinh** các lệch bội NST (như hội chứng Down).

## Tóm tắt

| Chủ đề | Ý chính |
|---|---|
| Nhiệt độ | Người hằng nhiệt, tạo vi khí hậu; lạnh đột ngột → giao cảm tăng oxy hóa, kéo dài thì kiệt sức; ứng dụng hạ thân nhiệt 26–28 °C khi mổ; thay đổi đột ngột → rối loạn chuyển hóa, máu, tim, hô hấp |
| Nước | 97% mặn, 3% ngọt (phần lớn đóng băng); mất cân bằng do phá rừng và ô nhiễm; 4 dạng ô nhiễm: mầm bệnh (dễ xử lý), rác – dầu, phóng xạ, hóa chất (khó nhất) |
| Hóa chất | Bột tẩy rửa mạch nhánh khó phân hủy; thuốc trừ sâu 3 nhóm: clo hữu cơ (chậm), phospho hữu cơ và carbamat (nhanh); DDT làm mỏng vỏ trứng; dioxin trong 2,4-D, 2,4,5-T |
| Không khí | N~2~ 78,1%, O~2~ 20,9%, CO~2~ 0,04%; O~2~ 70% từ tảo; SO~2~ → H~2~SO~4~; CO → carboxyhemoglobin; CO~2~ mất cân bằng; benzopyren gây ung thư; khói thuốc lá; bụi 0,1–10 µm |
| Phóng xạ | Hại di truyền và gây ung thư, quái thai; nền tự nhiên 150 mrad/năm (4,5 rad/thế hệ); Travancore; **Sr-90** giống calci → xương, tủy, qua nhau thai; thai và võng mạc rất nhạy cảm |
| Thức ăn, tiếng ồn, nghề nghiệp | Dư lượng hóa chất, phụ gia, đồ nhựa; ≤ 85 dB chịu được, 140–145 dB điếc; ồn → tăng cholesterol, huyết áp; bệnh nghề nghiệp do bụi, khí, nhiệt, áp suất |
| Nhịp sinh học | Do chu kỳ địa vật lý; nhịp ngày đêm của thân nhiệt, tim (ngày > đêm 30%), ngủ (người lớn 7–8 giờ); pha thức phải trùng ban ngày |
| Dân số – thức ăn | 2400 kcal/người/ngày; 1 tỷ (1850) → 6,13 tỷ (2001); hiện ≈ 8,2 tỷ (2024), VN ≈ 102,3 triệu (2025); thức ăn giảm do mất đất, đất bạc màu, 20% bị sâu bệnh phá hoại; giải pháp: kế hoạch hóa dân số + tăng lương thực bằng khoa học |
| Sinh vật gây bệnh | Da, thực bào, miễn dịch; vaccin, thuốc; chủng kháng thuốc → cuộc đấu tranh còn tiếp diễn |
| Đột biến cảm ứng | Soma (khảm, ung thư, không di truyền) vs sinh dục (di truyền); vật lý: tia β, γ, X, UV, nhiệt (+10 °C → ×5); 10 rad gây sai lệch NST; chiếu xạ tai biến vs hệ thống; hóa học: thuốc (thalidomid…), nông dược, hóa chất công nghiệp; sinh vật: virus (Rubella), vi khuẩn, Toxoplasma; mẹ > 35 tuổi |
