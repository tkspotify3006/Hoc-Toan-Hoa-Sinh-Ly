---
title: Màng tế bào và tế bào chất
thoi-gian: 60 phút
muc-tieu:
- Mô tả được cấu trúc, thành phần hóa học (lipid, protein, carbohydrat) và chức năng của màng tế bào; giải thích được màng mới hình thành như thế nào.
- Trình bày được cấu trúc, thành phần hóa học và chức năng của các bào quan: ribosom, lưới nội sinh chất có hạt và nhẵn, bộ Golgi, tiêu thể, peroxysom, lạp thể, ty thể, trung thể.
- Mô tả được bộ khung xương tế bào (ống vi thể, sợi vi thể, sợi trung gian) và các thành phần khác của tế bào chất (không bào, thể vùi).
- So sánh được các loại màng sinh chất qua tỷ lệ protein/lipid và hàm lượng cholesterol; liên hệ được các bệnh lý, thuốc tác động lên từng bào quan.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Mọi màng trong tế bào đều là **màng sinh chất**: lớp kép lipid (phospholipid + cholesterol) làm **nền**, protein làm **chức năng đặc hiệu**, carbohydrat ở mặt ngoài tạo **lớp áo tế bào** mang điện âm.
> 2. **Màng chỉ sinh ra từ màng**: lưới nội sinh chất có hạt tổng hợp lipid màng, ribosom tổng hợp protein màng, Golgi bổ sung carbohydrat.
> 3. Dây chuyền protein tiết: **ribosom → lưới có hạt (glycosyl hóa bước 1) → thể đậm → Golgi cis → trans (thuần thục hóa, bao gói) → túi tiết / tiêu thể / màng tế bào**.
> 4. **Tiêu thể** tiêu hóa bằng enzym thủy phân acid (pH ≤ 4,8); **peroxysom** chứa catalase phân giải H~2~O~2~; **ty thể** hô hấp tạo ATP (38 ATP/glucose theo giáo trình), có ADN (DNA) vòng riêng, **di truyền theo dòng mẹ**, nửa tự trị.
> 5. Khung xương tế bào gồm **ống vi thể** (tubulin, 24 nm, bị colchicin phá), **sợi vi thể** (actin 8 nm, myozin) và **sợi trung gian** (~10 nm: keratin, neurofilament, lamin).

Tế bào nhân thực (Eukaryota) gồm 3 phần chính: **màng tế bào, tế bào chất và nhân**. Bài này học hai phần đầu; nhân tế bào học ở bài sau.

![Hình 1. Sơ đồ tế bào động vật với các bào quan chính (không theo tỷ lệ)](te-bao-dong-vat.svg)

## 1. Màng tế bào

### 1.1. Đặc điểm chung của màng sinh chất

Không chỉ màng bao ngoài tế bào mà **mọi màng bên trong** (màng lưới nội sinh chất, Golgi, tiêu thể, ty thể, lạp thể, màng nhân…) đều có cùng bản chất là **màng sinh chất**. Chúng chung một kiểu cấu tạo:

- Là màng **lipoprotein**: thành phần gồm **lipid, protein** và một ít **carbohydrat**.
- Lipid xếp thành **lớp kép**: đầu ưa nước quay ra hai phía (tiếp xúc nước), đuôi kỵ nước quay vào giữa.
- Protein phân bố **đa dạng, linh hoạt** trong lớp kép (như những "mảnh khảm" trôi trên biển lipid).
- Carbohydrat gắn với lipid hoặc protein.

Tỷ lệ các thành phần và cách sắp xếp **khác nhau tùy chức năng** từng loại màng. Vì vậy giáo trình hay so sánh các màng bằng **tỷ lệ protein/lipid (P/L)** và **lượng cholesterol** (xem bảng ở mục 9).

**Dưới kính hiển vi điện tử**, màng tế bào dày khoảng **100 Å (10 nm)**, hiện ra như **ba lớp**: hai lớp sẫm song song kẹp một lớp sáng ở giữa, mỗi lớp dày khoảng 25–30 Å. Lớp sáng là phần kỵ nước của lớp kép lipid; giáo trình cho rằng hai lớp sẫm chủ yếu do phần ưa nước của protein tạo nên.

> [!cap-nhat] Hình ảnh "ba lớp" của màng
> Giáo trình ghi hai lớp sẫm chủ yếu do protein. Hiện nay người ta giải thích hai lớp sẫm chủ yếu là **các đầu phân cực của phospholipid** (bắt thuốc nhuộm osmi), cùng với protein bám ở hai mặt; lớp sáng là vùng đuôi acid béo. Mô hình được chấp nhận là **mô hình khảm lỏng** (fluid mosaic, Singer và Nicolson, 1972). Đi thi trả lời theo giáo trình.

> [!cap-nhat] Mô hình màng hiện nay: khảm lỏng nhưng "có tổ chức" (bổ sung – kiến thức hiện nay)
> - Màng **không đồng nhất** như "biển lipid" đều đặn. Cholesterol và sphingolipid có xu hướng tụ lại thành các vùng nhỏ, động, gọi là **bè lipid** (*lipid raft*, Simons và Ikonen, 1997); hội nghị Keystone 2006 định nghĩa đó là những vi vùng **≈ 10–200 nm**, tồn tại thoáng qua, gom một số receptor và protein truyền tin lại với nhau. **Hõm màng (caveolae)** giàu protein caveolin là một dạng vùng như vậy.
> - Nhiều protein màng **không trôi tự do**: chúng bị khung actin dưới màng "rào" lại (mô hình *hàng rào – cọc*), hoặc neo vào khung xương, vào protein của tế bào bên cạnh.
> - Cholesterol được hiểu là **chất đệm tính lỏng**: ở thân nhiệt nó làm màng **bớt lỏng** (như giáo trình), nhưng khi nhiệt độ hạ thấp nó lại **ngăn màng đông cứng**.

![Hình 2. Mô hình khảm lỏng của màng sinh chất](mang-kham-long.svg)

| Thành phần | Tỷ lệ (theo giáo trình) | Vai trò chính |
|---|---|---|
| **Lipid** | Phospholipid ~55%; cholesterol 25–30%; glycolipid ~18%; acid béo kỵ nước ~2% | **Cấu trúc nền**, tạo tính lỏng linh động, vận chuyển thụ động |
| **Protein** | Xuyên màng ~70%; ngoại vi ~30% | **Chức năng đặc hiệu**: vận chuyển, receptor, giữ hình dạng tế bào |
| **Carbohydrat** | Oligosaccharid gắn vào protein, lipid ở mặt ngoài | Tạo **lớp áo tế bào** mang điện âm: bảo vệ, nhận diện, miễn dịch |

### 1.2. Lipid màng

Lipid màng gồm hai loại chính là **phospholipid** và **cholesterol**. Cả hai đều là phân tử **lưỡng tính**: một đầu ưa nước, một đầu kỵ nước.

**Vì sao lipid tự xếp thành lớp kép và tự khép kín?** Đuôi kỵ nước "trốn" nước. Cách duy nhất để mọi đuôi đều không chạm nước là xếp hai lớp áp đuôi vào nhau, rồi cuộn lại thành **túi kín** (không còn mép hở). Cũng nhờ vậy, khi màng bị rách, bị mở ra (như lúc tạo túi) hay nhận thêm lipid mới, nó **tự hàn lại rất nhanh**.

**Phospholipid** (~55% lipid màng)

- Rất ít tan trong nước. Bốn loại chính, từ nhiều đến ít: **phosphatidylcholin > sphingomyelin > phosphatidylethanolamin > phosphatidylserin**; ngoài ra có ít phosphatidylinositol.
- Hai lớp của màng thường có **thành phần lipid khác nhau** (màng bất đối xứng).
- Phân tử phospholipid **chuyển động liên tục**: tự quay quanh trục, đổi chỗ với phân tử bên cạnh **trong cùng một lớp** (chiều ngang) rất dễ. Muốn **lật sang lớp đối diện** thì đầu ưa nước phải băng qua vùng kỵ nước ở giữa, nên rất khó và **cần protein màng hỗ trợ**.
- Chức năng: **nền tảng cơ bản** của màng; sự đổi chỗ liên tục tạo nên **tính lỏng linh động**; là hàng rào và đường đi chính cho **vận chuyển thụ động**. Vùng kỵ nước ở giữa **chặn các chất tan trong nước**, nên chúng phải đi qua kênh protein.

**Cholesterol** (25–30% lipid màng)

- Là lipid steroid trung tính, **luôn có** ở màng sinh chất Eukaryota, nằm xen giữa các phospholipid ở cả hai lớp.
- **Màng tế bào là màng có tỷ lệ cholesterol cao nhất** trong các màng sinh chất. Màng tế bào gan còn cao hơn: khoảng **40%** lipid toàn phần.
- Cholesterol **làm giảm tính lỏng linh động** của màng: nhân steroid cứng chèn vào giữa các đuôi acid béo, hạn chế chúng cử động.

Phần còn lại của lipid màng là **glycolipid** (~18%) và **acid béo kỵ nước** (~2%).

> [!yhct] Saponin và màng tế bào
> - Nhiều dược liệu chứa **saponin**: Cam thảo, Nhân sâm, Tam thất, Cát cánh, Viễn chí, Ngưu tất… Saponin có tính "xà phòng". **Cơ chế đã chứng minh** (in vitro): nhiều saponin gắn với **cholesterol của màng**, tạo lỗ thủng, làm tăng tính thấm của màng.
> - Hệ quả: nhiều saponin làm **tan hồng cầu** khi tiếp xúc trực tiếp, mạnh yếu tùy loại (glycyrrhizin của Cam thảo tác dụng này rất yếu). Ngành Dược liệu dùng chính tính chất này để định tính và đánh giá saponin (**chỉ số phá huyết**). Lưu ý thuật ngữ: "phá huyết" ở đây nghĩa là **làm vỡ hồng cầu**, khác hẳn "phá huyết" (phá huyết ứ) trong lý luận YHCT. Dung dịch, dịch chiết thô chứa saponin **không được tiêm** vào máu.
> - Khi **uống**, saponin hấp thu rất ít nên tác dụng tan máu không đáng kể. Tác dụng long đờm của Cát cánh, Viễn chí được giải thích **một phần** là do saponin kích thích niêm mạc (giả thuyết, bằng chứng chủ yếu thực nghiệm).
> - Trong phòng thí nghiệm, **digitonin** (một saponin) được dùng để đục lỗ màng tế bào có chọn lọc nhờ ái lực với cholesterol.

### 1.3. Protein màng

Lipid lo phần "khung", còn **chức năng đặc hiệu** của màng phần lớn do **protein** đảm nhận. Đã biết trên 50 loại protein cùng có mặt trên một màng. Ở **màng hồng cầu, tỷ lệ P/L xấp xỉ 1**.

Dựa vào cách liên kết với lipid, chia hai loại:

| | **Protein xuyên màng** (~70%) | **Protein ngoại vi** (~30%) |
|---|---|---|
| Vị trí | Có đoạn **xuyên suốt** lớp lipid, hai đầu thò ra hai mặt màng | Nằm ở **mặt ngoài hoặc mặt trong** màng |
| Liên kết | Đoạn trong màng **kỵ nước**, hai đầu thò ra **ưa nước** | **Hấp phụ** vào đầu thò ra của protein xuyên màng bằng lực **tĩnh điện** hoặc **kỵ nước**, **không phải liên kết cộng hóa trị** |
| Đặc điểm | Xuyên 1 lần hoặc nhiều lần (tới 6–7 lần); di động tịnh tiến trong màng | Dễ tách khỏi màng hơn |
| Ví dụ (hồng cầu) | **Glycophorin**, **band 3**, các protein vận tải | Mặt ngoài: **fibronectin**; mặt trong: **spectrin, actin, ankyrin, band 4.1** |

**Vì sao protein xuyên màng phân bố đều?** Đầu thò vào bào tương của nhiều protein xuyên màng mang nhóm **–COO^−^** tích điện âm. Chúng **đẩy nhau**, nên dù di động được, chúng vẫn rải đều trên màng (tính chất này thay đổi khi pH thay đổi).

**Các ví dụ protein xuyên màng của hồng cầu**

- **Glycophorin**: đoạn xuyên màng ngắn; đầu ngoài mang nhiều chuỗi oligosaccharid và polysaccharid. Các chuỗi này tạo **phần lớn carbohydrat bề mặt** hồng cầu. Đầu –COOH quay vào trong, có thể liên kết với protein khác.
- **Band 3**: phân tử dài, **xuyên màng tới 6 lần** (theo giáo trình; cấu trúc tinh thể hiện nay cho thấy khoảng 14 đoạn xuyên màng). Đoạn xuyên màng **vận chuyển anion** qua màng. Phần thò vào bào tương có hai vùng: vùng **gắn ankyrin** và vùng gắn **enzym phân ly glucose** và **hemoglobin**. Khi neo lưới protein vào màng, band 3 đứng thành **cặp đôi** (2 band 3 + 2 ankyrin).
- Ngày càng biết thêm nhiều **protein vận tải** (permease); tên của chúng gọi theo chất mà chúng vận chuyển.

**Lưới protein lát mặt trong màng hồng cầu.** Bốn protein ngoại vi **spectrin, actin, band 4.1, ankyrin** tạo thành một lưới gồm các mắt **hình 6 cạnh**:

- **Cạnh** là **spectrin** (phân tử sợi xoắn).
- **Đỉnh** có hai loại xen kẽ: loại gồm **actin + band 4.1**, và loại gồm **2 phân tử ankyrin**.
- Ankyrin bám vào **band 3**, nhờ đó lưới **neo vào màng** (chỉ khoảng 20% band 3 tham gia neo).

Lưới này làm hồng cầu **bền** và giữ **hình đĩa lõm hai mặt**.

> [!ung-dung] Khi lưới protein hồng cầu bị hỏng
> **Bệnh hồng cầu hình cầu di truyền** (hereditary spherocytosis) do đột biến gen mã hóa **spectrin, ankyrin, band 3** hoặc protein 4.2. Màng mất dần từng mảnh, hồng cầu thành **hình cầu**, kém mềm dẻo, bị **lách** giữ lại và phá hủy. Người bệnh bị thiếu máu tan máu, vàng da, lách to; cắt lách giúp cải thiện. Đây là ví dụ rõ nhất cho thấy "protein ngoại vi xác định hình dạng tế bào".

**Fibronectin** là protein ngoại vi mặt ngoài, có ở hầu hết động vật (từ san hô đến người), trên tế bào sợi, cơ trơn, nội mô… Nó giúp tế bào **bám dính vào chất nền**. *(Hiện nay fibronectin được xếp là glycoprotein do tế bào **tiết ra chất nền ngoại bào**; nó bám vào màng qua receptor xuyên màng **integrin**.)* Tế bào ung thư vẫn tiết fibronectin nhưng **không giữ được trên bề mặt**, nên **mất khả năng bám dính**, tạo điều kiện cho **di căn**.

**Chức năng chung của protein màng**

- **Vận chuyển**: dẫn nước và các chất qua màng theo cơ chế thụ động và chủ động, có chọn lọc. Theo giáo trình, kênh protein **xuyên một lần** thường dẫn **phân tử lớn**, kênh **xuyên nhiều lần** dẫn **phân tử nhỏ** có chọn lọc. *(Cập nhật: hầu hết kênh và chất vận chuyển đã biết cấu trúc đều là protein **xuyên màng nhiều lần**; protein xuyên một lần thường là **receptor** hoặc protein bám dính. Đi thi theo giáo trình.)*
- **Thụ quan (receptor)**: tiếp nhận và truyền thông tin, nhận dạng tế bào, liên kết với tế bào khác; nhiều phản ứng enzym quan trọng diễn ra trên màng.
- **Xác định hình dạng tế bào**: protein ngoại vi nối màng với **khung xương tế bào**, tạo khung đỡ mặt trong màng.

### 1.4. Carbohydrat màng

- Có mặt dưới dạng **oligosaccharid**, gắn vào **hầu hết** đầu ưa nước của protein màng thò ra **mặt ngoài**, và vào đầu ưa nước của khoảng **1/10** phân tử lipid ở lớp ngoài.
- Việc gắn oligosaccharid gọi là **glycosyl hóa**: protein → **glycoprotein**, lipid → **glycolipid**.
- Chuỗi đường giúp protein **gấp đúng cấu trúc bậc ba**, bền và **đến đúng vị trí** trong tế bào. Nói chung carbohydrat **không tham gia xúc tác**.
- **Acid sialic** ở glycoprotein và **gangliosid** ở glycolipid tích **điện âm**. Vì vậy **mặt ngoài hầu hết tế bào động vật mang điện âm**: các tế bào đẩy nhau, không dính chập vào nhau.

**Lớp áo tế bào (cell coat, glycocalyx)** là toàn bộ phần carbohydrat của glycoprotein và glycolipid ở mặt ngoài. Chức năng:

- **Bảo vệ**, tạo **điện tích âm** bề mặt, tham gia **trao đổi chất**.
- **Miễn dịch, nhận diện**: mang **kháng nguyên nhóm máu** và **kháng nguyên bạch cầu người HLA** (human leukocyte antigen), đặc trưng cho từng cá thể, từng mô.
- Từng vùng trên màng có thành phần khác nhau, tạo các "trung tâm" chuyên nhận diện, đề kháng, truyền tin, vận tải.

> [!ung-dung] Nhóm máu và ghép tạng
> Kháng nguyên **A, B** của hệ ABO thực chất là **chuỗi đường** khác nhau ở đầu tận của oligosaccharid trên glycoprotein, glycolipid màng hồng cầu. Truyền nhầm nhóm máu gây tan máu cấp. **HLA** cũng nằm trên màng; ghép tạng phải xét nghiệm hòa hợp HLA để hạn chế thải ghép.

### 1.5. Sự hình thành màng tế bào

> [!ghi-nho] Màng chỉ được sinh ra từ màng
> Tế bào không "đắp" màng mới từ con số không; màng mới luôn là phần nối dài của màng có sẵn.

- Màng được nhân lên mạnh nhất **trước khi phân bào**, đủ cho hai tế bào con.
- Bào quan **trực tiếp tổng hợp màng mới** là **lưới nội sinh chất có hạt**: nó tổng hợp **lipid màng**.
- **Protein màng** do **ribosom tự do** và **ribosom bám trên lưới có hạt** tổng hợp.
- **Carbohydrat** lấy từ tế bào chất và một phần lớn do **túi Golgi** cung cấp (qua túi tiết và túi thải cặn bã).

**Cân bằng diện tích màng.** Màng tế bào liên tục bị **hụt đi** vì phải lõm vào để tạo túi **thực bào, ẩm bào**. Bù lại, các **túi tiết** và **túi thải cặn bã** sau khi đổ chất ra ngoài thì **vỏ túi hòa nhập vào màng tế bào**. Sự hòa nhập này dễ dàng vì màng túi và màng tế bào có cấu tạo tương tự nhau.

### 1.6. Chức năng của màng tế bào

1. **Bao bọc, ngăn cách** tế bào với môi trường, biến tế bào thành một hệ thống riêng biệt.
2. **Trao đổi nước và vật chất** với môi trường: thụ động, chủ động, có chọn lọc.
3. **Thu nhận thông tin** (vật lý, hóa học) qua **receptor**, thường là protein xuyên màng. Chất đặc hiệu gắn vào đầu ngoài (đã glycosyl hóa) làm **đổi hình dạng đầu trong** của protein, từ đó thay đổi hoạt động tế bào. Thiếu receptor đặc hiệu với hormon thì cơ thể rối loạn chuyển hóa; thiếu kháng thể bề mặt thì không tự bảo vệ được.
4. **Trao đổi thông tin** giữa các tế bào: phát và nhận tín hiệu để điều hòa hoạt động sống.
5. **Xử lý thông tin**: nhận diện tế bào **quen – lạ – kẻ thù**; kích thích hoặc ức chế tiếp xúc giữa tế bào với tế bào, tế bào với chất nền.
6. **Cố định chất độc, dược liệu, virus**, tạo sức đề kháng; là chỗ **bám** của các cấu trúc bên trong tế bào.

> [!vi-du] Receptor và bệnh
> - **Đái tháo đường týp 2**: insulin vẫn có, nhưng tín hiệu sau receptor insulin kém (kháng insulin).
> - **Tăng cholesterol máu gia đình**: đột biến **receptor LDL** trên màng tế bào gan, LDL không được thu nhận, cholesterol máu rất cao, xơ vữa sớm.
> - Virus muốn vào tế bào phải gắn vào một **receptor** đặc hiệu trên màng: HIV gắn CD4, SARS-CoV-2 gắn ACE2. Đó là lý do mỗi virus "chọn" những loại tế bào nhất định.

## 2. Tế bào chất và ribosom

**Tế bào chất** là mọi thứ nằm **giữa màng nhân và màng tế bào**, gồm: **bào quan, thể vùi, dịch tế bào chất** (bào tương) và các thành phần khác.

Có thể chia bào quan thành hai nhóm:

- **Không có màng**: ribosom, trung thể, bộ khung xương.
- **Có màng** (màng sinh chất nội bào): lưới nội sinh chất, Golgi, tiêu thể, peroxysom, ty thể, lạp thể, không bào.

### 2.1. Ribosom — "xưởng lắp ráp protein"

Ribosom **không có màng bao**. Nó là phức hợp **rARN (rRNA) + protein**, nằm rải rác khắp tế bào chất: **tự do**, hoặc **bám** vào lưới nội sinh chất có hạt và **mặt ngoài màng nhân ngoài**.

**Cấu trúc.** Mỗi ribosom gồm **hai phân đơn vị**. Kích thước được đo bằng **hệ số lắng S** (Svedberg): tốc độ lắng khi siêu ly tâm trong điều kiện chuẩn.

- **Phân đơn vị nhỏ**: thuôn dài, cong, úp lên phân đơn vị lớn như **cái vung đậy không kín**.
- **Phân đơn vị lớn**: có **3 mấu** nhô lên ôm lấy phân đơn vị nhỏ.

| | **Prokaryota** (nhân sơ) | **Eukaryota** (nhân thực) |
|---|---|---|
| Ribosom hoàn chỉnh | **70S** | **80S** |
| Phân đơn vị nhỏ | **30S** = rARN **16S** (1540 base) + **21 protein** (S1–S21) | **40S** = rARN **18S** (1900 base) + **33 protein** (S1–S33) |
| Phân đơn vị lớn | **50S** = rARN **5S** (120 base) + **23S** (2900 base) + **34 protein** (L1–L34) | **60S** = rARN **5S** (120) + **28S** (4700) + **5,8S** (160 base) + **49 protein** (L1–L49) |

> [!cap-nhat] Ribosom người theo số liệu cấu trúc hiện nay
> Cấu trúc ribosom người (cryo-EM, 2013 trở đi) cho thấy ribosom 80S có **khoảng 80 protein**: **≈ 33** ở 40S và **≈ 47** ở 60S (giáo trình: 33 và 49); rARN 28S của người dài **≈ 5000 nucleotid** (giáo trình ghi 4700). Cấu trúc nguyên tử của ribosom được trao **giải Nobel Hóa học 2009** (Ramakrishnan, Steitz, Yonath). Đi thi dùng số liệu giáo trình.

Mẹo nhớ: phân đơn vị nhỏ có **1 rARN**; phân đơn vị lớn có **2 rARN** — ở Eukaryota giáo trình tính là 5S và "28S liên kết với 5,8S" (thực chất là 3 phân tử, nhưng 5,8S bắt cặp chặt với 28S). Protein: "**21–34**" (nhân sơ), "**33–49**" (nhân thực).

> [!bay]
> - Hệ số S **không cộng được**: 30S + 50S = **70S**, không phải 80S; 40S + 60S = **80S**, không phải 100S. S phụ thuộc cả khối lượng lẫn hình dạng.
> - Ribosom của **ty thể và lạp thể** nhỏ hơn và **giống ribosom vi khuẩn**.
> - Phân đơn vị ribosom được **lắp ráp ở hạch nhân** trong nhân tế bào.

**Chức năng.** Ribosom là nơi **tổng hợp protein**. rARN không chỉ là "giá đỡ": nó phối hợp với protein ribosom để **đón mARN đúng vị trí**, chọn đúng phức hợp **tARN–acid amin** (amino acid) (bước tốn thời gian nhất), nối các acid amin, và trả chuỗi peptid khi xong. Sự khởi đầu cần cả một phức hợp: mARN, **Met-tARN^Met^**, **GTP**, codon khởi đầu **AUG** và phân đơn vị nhỏ. Năng lượng từ **thủy phân GTP** làm ribosom đổi hình dạng để **dịch chuyển mARN** qua nó.

Giáo trình nêu thêm vai trò bắt cặp base của rARN:

- Một đoạn ngắn trên rARN (giáo trình ghi là **5S**; có tác giả cho là **16S** ở vi khuẩn) bắt cặp với một đoạn trên mARN nằm **trước codon đầu tiên**.
- Một đoạn trên rARN **28S** bắt cặp với trình tự **TΨCG** (không đặc hiệu) trên tARN khi tARN mang acid amin đến. T và Ψ (pseudouridin) là những nucleotid "lạ" trong ARN, sinh ra do **biến đổi sau phiên mã**: U thứ nhất của bộ UUCG bị **methyl hóa thành T**, U thứ hai sắp xếp lại thành **Ψ** (ribose nối với C thay vì N).

> [!cap-nhat] rARN là enzym
> - Ở vi khuẩn, đoạn bắt cặp với trình tự Shine–Dalgarno trên mARN nằm ở đầu 3' của **rARN 16S** (không phải 5S). Ở Eukaryota, ribosom nhận mARN chủ yếu nhờ **mũ 5'** rồi trượt tìm AUG.
> - Phản ứng nối peptid do chính **rARN của phân đơn vị lớn** xúc tác (23S ở vi khuẩn, 28S ở người): ribosom là một **ribozym**.
> - Đi thi trả lời theo giáo trình.

**Dạng tồn tại của ribosom**

- Trong tế bào chất, hai phân đơn vị thường **tách rời**, chỉ **hợp lại khi tổng hợp protein**.
- **Ribosom tự do**: tổng hợp protein **ở lại trong bào tương** và protein cho bào quan không thuộc hệ lưới: protein **khung xương**, protein thêm vào **ty thể**, protein của **peroxysom** (như catalase). Mỗi protein có một đoạn acid amin ngắn làm **tín hiệu dẫn đường**. "Tự do" nhưng thực ra chúng thường bám vào khung xương tế bào.
- **Ribosom bám** lưới nội sinh chất và màng nhân: chuyên tổng hợp **protein tiết** (theo nghĩa rộng: chất tiết thật, protein màng, enzym tiêu thể, glycoprotein…), những protein cần được "bảo quản" ngay và giao nhận bằng **túi vận tải**. Ribosom bám bằng **phân đơn vị lớn** vào protein receptor trên màng lưới gọi là **ribophorin**. Đoạn acid amin **đầu tiên** của chuỗi mới sinh là tín hiệu dẫn ribosom đến lưới.
- Ribosom tự do và ribosom bám **giống hệt nhau** về rARN và protein; khác nhau chỉ ở **protein đang tổng hợp**.
- **Polysom (polyribosom)**: nhiều ribosom cùng đọc **một sợi mARN**. Mỗi ribosom làm ra một chuỗi peptid riêng, các chuỗi **giống hệt nhau** vì cùng một khuôn.

> [!ung-dung] Kháng sinh nhắm vào ribosom 70S
> Ribosom vi khuẩn (70S) khác ribosom người (80S), nên nhiều kháng sinh ức chế **chọn lọc** tổng hợp protein vi khuẩn: **aminoglycosid** (gentamicin), **tetracyclin** gắn 30S; **macrolid** (erythromycin), **cloramphenicol** gắn 50S. Nhưng ribosom **ty thể** người giống ribosom vi khuẩn, nên một số tác dụng phụ (suy tủy do cloramphenicol, độc tai do aminoglycosid ở người mang đột biến rARN ty thể) được giải thích qua ty thể.

## 3. Hệ thống màng nội bào: lưới nội sinh chất, Golgi, tiêu thể, peroxysom

### 3.1. Lưới nội sinh chất có hạt (RER)

**Cấu trúc.** Hệ thống **túi dẹt và ống nhỏ** lan khắp tế bào chất, bao bởi **một lớp màng**, tạo một không gian riêng (lòng lưới) tách biệt với bào tương. Lòng lưới **thông với khoang quanh nhân** (giữa hai lớp màng nhân); theo giáo trình, nó còn nối với màng tế bào để thông với khoảng gian bào.

**Màng lưới có hạt khác màng tế bào ở chỗ:**

- **P/L cao hơn**: lớn hơn 1, có thể **gần bằng hoặc bằng 2**.
- **Cholesterol thấp**: chỉ **6%** lipid (tế bào gan chuột), so với **30%** ở màng tế bào. Vì vậy màng **lỏng linh động hơn**, phospholipid đổi chỗ dễ dàng, dễ tách và nhập túi.
- **Phosphatidylcholin chiếm ưu thế: 55%** (màng tế bào chỉ 18%).
- Nhiều **enzym**: chính là **glucose-6-phosphatase**, **nucleotid-phosphatase**; có các **chuỗi vận chuyển điện tử**.
- Mặt ngoài có **ribosom bám** khá cố định (nên gọi là "có hạt"). Tế bào tiết protein mạnh thì lưới có hạt rất phát triển.

**Protein đi vào lưới như thế nào?** Ribosom gắn vào phức hợp **ribophorin** bằng phân đơn vị lớn. Lực bám là lực ion cộng với lực của chính chuỗi polypeptid đang sinh ra. Chuỗi peptid mới **luồn qua phân đơn vị lớn**, rồi qua màng vào lòng lưới; nếu không có **permease** (protein vận chuyển xuyên màng) thì chuỗi tự luồn qua lipid nhờ **tín hiệu dẫn đường**. Với một số protein như globulin, ribosom chỉ tìm đến lưới **sau khi đã bắt đầu tổng hợp**: chính đoạn đầu chuỗi dẫn ribosom đến. Tín hiệu dẫn đường có loại bị **cắt bỏ** khi vào lòng lưới, có loại **giữ lại** để tiếp tục dẫn protein đến địa chỉ sau.

> [!cap-nhat] Giả thuyết tín hiệu: SRP và kênh Sec61 (bổ sung – kiến thức hiện nay)
> Cơ chế được chấp nhận hiện nay (**Günter Blobel**, Nobel Y học 1999): khi **đoạn tín hiệu** (khoảng 15–30 acid amin kỵ nước ở đầu N) vừa ló ra khỏi ribosom, **hạt nhận diện tín hiệu (SRP)** bám vào, tạm dừng dịch mã và đưa cả ribosom đến **receptor của SRP** trên màng lưới. Chuỗi peptid sau đó luồn qua một **kênh protein xuyên màng (translocon Sec61)** vào lòng lưới, đoạn tín hiệu bị **peptidase tín hiệu** cắt bỏ. Ribophorin mà giáo trình nêu là một thành phần của phức hợp quanh kênh này. Chuỗi peptid **không tự luồn qua lớp lipid**.

**Kiểm soát chất lượng.** Protein vào lưới thường là **oligome** (khoảng 3 đơn phân). Chúng phải **gấp nếp đúng** mới được xuất khỏi lưới (chủ yếu đi về Golgi). Phân tử gấp sai bị **giữ lại**, tích tụ hoặc bị **giáng cấp**. Protein riêng của lưới được giữ lại có chọn lọc. (Cập nhật — hiện nay biết: protein gấp sai bị đưa ngược ra bào tương và phân hủy ở **proteasom** sau khi gắn ubiquitin — gọi là **ERAD**; khi protein gấp sai ứ quá nhiều, tế bào bật **đáp ứng protein không gấp nếp (UPR)**, nếu kéo dài sẽ dẫn tới chết tế bào theo chương trình.)

**Chức năng của lưới có hạt**

1. **Tiếp nhận, bảo quản, chế biến** protein do ribosom bám tổng hợp.
2. **Glycosyl hóa bước một**: gắn chuỗi ngắn đường (glucose, mannose…) vào protein. Chuỗi đường cùng đoạn acid amin đầu N làm **tín hiệu tìm địa chỉ giao nhận**.
3. **Bao gói và gửi đi**: protein được dồn ra **mép túi lưới**, vào ống nhỏ, rồi đứt ra thành **túi vận tải**. Túi này bắt màu đậm dưới kính hiển vi điện tử nên gọi là **thể đậm**. Thể đậm đi đến Golgi, màng tế bào…
4. **Tổng hợp phospholipid và cholesterol** ngay trong màng lưới, dùng để **thay màng già** và **tạo màng mới** khi phân bào. Cholesterol còn được chuyển cho lưới nhẵn làm nguyên liệu tổng hợp chất khác.

> [!ung-dung] Khi protein gấp sai bị giữ lại trong lưới
> Ví dụ kinh điển là **thiếu α~1~-antitrypsin** (dạng đột biến Z): protein gấp sai bị **ứ đọng trong lưới nội sinh chất của tế bào gan**, gây **tổn thương gan**; đồng thời máu thiếu α~1~-antitrypsin nên phổi bị elastase phá hủy, gây **khí phế thũng** sớm. Đây là minh họa cho chức năng "kiểm soát chất lượng" của lưới có hạt.

### 3.2. Lưới nội sinh chất nhẵn (SER)

**Cấu trúc.** Không phải chồng túi dẹt mà là **hệ thống ống** lớn nhỏ, phân nhánh, **thông với nhau và thông với lưới có hạt**; **không có ribosom**. Trên ảnh hiển vi điện tử thấy như những đám ống nhỏ cắt cụt rời rạc.

- **P/L như lưới có hạt**; **cholesterol cao hơn: 10%** (RER: 6%); **phosphatidylcholin 55%**.
- Màng và lòng lưới chứa nhiều enzym **nối dài hoặc bão hòa hóa acid béo**.

**Tỷ lệ hai loại lưới phản ánh chức năng tế bào:**

| Tế bào | Loại lưới chủ yếu | Vì sao |
|---|---|---|
| Tụy ngoại tiết (tiết protein) | Hầu như chỉ **lưới có hạt** | Sản xuất enzym tiêu hóa (protein) |
| Tế bào cơ | Hầu như chỉ **lưới nhẵn** | Dự trữ và giải phóng Ca^2+^ |
| Tế bào gan | Có hạt / nhẵn **≈ 1** | Vừa tổng hợp protein huyết tương, vừa giải độc, chuyển hóa lipid |
| Tuyến bã, tế bào tổng hợp steroid | **Lưới nhẵn** rất phát triển | Tổng hợp lipid mạnh |

**Chức năng của lưới nhẵn**

1. **Tổng hợp lipid**: tổng hợp và chuyển hóa **acid béo, phospholipid**; tạo lipid cho **lipoprotein**.
2. **Tổng hợp hormon steroid** từ cholesterol: hormon sinh dục (ví dụ ở **tinh hoàn**) và hormon **vỏ thượng thận**.
3. **Giải độc**: chất độc, thuốc, hóa chất, thuốc trừ sâu, chất gây ung thư được enzym của lưới nhẵn chuyển **từ dạng không tan trong nước thành tan trong nước** để **thải qua nước tiểu**. Khi chất độc nhiều, lưới nhẵn **tăng sinh**; xong việc, phần thừa bị **tiêu thể** tiêu hủy.
4. **"Nâng cấp" acid béo**: ở ruột, mỡ bị cắt vụn thành monoglycerid và acid béo để qua màng; vào tế bào, lưới nhẵn **nối lại** thành phân tử lớn (triglycerid) và xuất đi dưới dạng chất tiết.
5. **Co duỗi cơ**: màng lưới nhẵn ở tế bào cơ (lưới cơ tương) có **Ca^2+^-ATPase** (bơm Ca^2+^). Bơm Ca^2+^ **vào lòng lưới** thì **cơ duỗi**; Ca^2+^ **thoát ra** bào tương thì **cơ co**.

> [!ung-dung] Lưới nội sinh chất nhẵn của gan và tương tác thuốc
> Enzym giải độc chính của lưới nhẵn là hệ **cytochrom P450** (CYP). Nhiều thuốc và chất làm **tăng sinh lưới nhẵn, tăng lượng enzym** (gọi là **cảm ứng enzym**): phenobarbital, rifampicin, rượu uống lâu ngày. Khi đó thuốc khác dùng cùng bị chuyển hóa nhanh, **giảm tác dụng** (ví dụ thuốc tránh thai, thuốc chống đông). Ngược lại, chất **ức chế CYP** (như nước bưởi chùm với CYP3A4) làm thuốc tích lũy, dễ ngộ độc. Một số dược liệu cũng gây tương tác qua CYP (bằng chứng rõ nhất là **Ban Âu**, *Hypericum perforatum*, gây cảm ứng CYP3A4), nên cần hỏi kỹ bệnh nhân đang dùng thuốc tây gì khi kê thuốc nam.

### 3.3. Bộ Golgi

**Cấu trúc.** Bộ Golgi là một **chồng túi dẹt** hình chỏm cầu xếp song song, gọi là **dictiosom**, thường nằm **gần nhân**.

- Mỗi túi dẹt nhìn như **lưỡi liềm**, dày khoảng **150 Å**; miệng túi rộng **0,5–1 µm**. Túi và màng túi **mỏng hơn** của lưới nội sinh chất.
- **Mặt cis** (thường là mặt **lồi**, quay về phía lưới nội sinh chất): **đầu vào**, nhận sản phẩm từ lưới có hạt.
- **Mặt trans** (mặt đối diện): **đầu ra**, túi dẹt có nhiều chỗ **phình ở mép**.
- Từ các túi dẹt tách ra các **túi cầu Golgi** chứa sản phẩm, đi giao đúng địa chỉ.
- Một tế bào có thể có **một hoặc nhiều dictiosom**; các dictiosom gần nhau nối với nhau bằng kênh nhỏ ở phía cis.

**Sự phân cực của bộ Golgi.** Từ cis đến trans, các túi dẹt khác nhau về **hình thái, thành phần hóa học, enzym và chức năng**, và vật chất luôn đi **một chiều từ cis sang trans**.

| | **Phía cis** | **Vùng giữa** | **Phía trans** |
|---|---|---|---|
| Thành phần màng | Giống màng **lưới có hạt** | Trung gian | Giống **màng tế bào** |
| P/L | **≈ 2** | Giữa 2 và 1 | **≈ 1** |
| Độ dày màng | **50–60 Å** | | **~100 Å** |
| Cholesterol | Thấp | | **Cao** |

**Vì sao màng biến đổi dần như vậy?** Golgi là "trạm chuyển tiếp": nó nhận màng kiểu lưới nội sinh chất ở đầu vào và xuất ra túi có màng kiểu màng tế bào ở đầu ra, để túi tiết **hòa nhập được với màng tế bào**.

**Sự hình thành bộ Golgi**

- Nguồn chính là **lưới có hạt**: các **thể đậm** hòa vào túi dẹt phía cis; nếu nhiều, chúng nhập lại thành **túi dẹt mới** rồi di chuyển dọc **ống vi thể** đến ghép vào phía cis.
- Túi dẹt Golgi cũng tự **lớn lên và chia đôi**.
- Màng Golgi liên tục **hụt đi** (do tạo túi Golgi) và được **bù lại** bằng thể đậm và túi từ **màng nhân**.

**Chức năng của bộ Golgi**

Khái quát: **tiếp nhận** protein, glycolipid, carbohydrat từ lưới nội sinh chất, **thuần thục hóa**, **bao gói** và **phân phát** đúng địa chỉ (bào quan khác hoặc ra ngoài tế bào). Cụ thể:

- **Thuần thục hóa** (tăng tính đặc hiệu, quan trọng nhất là gắn **tín hiệu dẫn đường, nhận diện địa chỉ**):
  - **Glycosyl hóa** protein và lipid (bước hai, hoàn thiện chuỗi đường);
  - **Sulfat hóa** glycoprotein (gắn gốc SO~4~^2−^, kiểu ester hóa);
  - **Phosphoryl hóa**;
  - chuyển protein sang **cấu trúc bậc hai, bậc ba**;
  - **gắn acid béo**, **polyme hóa** polysaccharid.
- **Glycosyl hóa hầu hết glycoprotein của chất nhầy**.
- **Tạo tiêu thể**.
- **Tạo thể đầu (acrosom)** của tinh trùng.
- **Xuất chất tiết** (cả chất độc) ra ngoài bằng túi Golgi có màng giống màng tế bào. Khi túi mở ra, màng túi hòa vào màng tế bào; **mặt trong của túi trở thành mặt ngoài của màng tế bào**. Vì vậy carbohydrat trong lòng túi thành **lớp áo tế bào**: Golgi có lẽ là nơi tạo nên **phần lớn lớp áo tế bào**.
- **Biệt hóa các loại màng**: tạo túi có màng khác nhau, mỗi loại hòa nhập vào màng có cấu tạo tương ứng.

> [!bay]
> - Glycosyl hóa **bước một** ở **lưới có hạt**; Golgi glycosyl hóa **tiếp** và thêm sulfat hóa, phosphoryl hóa.
> - Sản phẩm ở **miền trans**: túi tạo **tiêu thể**, túi tạo **màng tế bào**, **túi tiết** (cũng góp phần tạo màng tế bào).
> - Trình tự đúng: **lưới có hạt → thể đậm → cis Golgi → trans Golgi → túi**; không phải ngược lại.

> [!cap-nhat] Túi vận tải: COPII, COPI, clathrin (bổ sung – kiến thức hiện nay)
> "Thể đậm" của giáo trình nay được hiểu là các **túi vận tải có áo protein**: túi **COPII** đưa protein **lưới → Golgi**; túi **COPI** đưa ngược **Golgi → lưới** (thu hồi protein của lưới) và giữa các túi dẹt; túi **clathrin** đi từ **trans Golgi** đến thể nội bào và từ màng tế bào vào trong. Túi nhận đúng màng đích nhờ cặp protein **SNARE**. Cơ chế vận chuyển túi được trao **giải Nobel Y học 2013** (Rothman, Schekman, Südhof).

> [!cap-nhat] Protein gấp nếp ở đâu?
> Giáo trình xếp việc "chuyển protein sang cấu trúc bậc hai, bậc ba" vào chức năng của Golgi. Hiện nay biết protein tiết **gấp nếp chủ yếu trong lòng lưới nội sinh chất có hạt** (nhờ các chaperon); Golgi chủ yếu **sửa đổi chuỗi đường, phân loại và bao gói**. Đi thi trả lời theo giáo trình.

### 3.4. Tiêu thể (lysosom)

Tiêu thể là **bào quan tiêu hóa chính** của tế bào. Một tế bào có nhiều tiêu thể, kích thước không đều, rải rác trong tế bào chất.

**Cấu trúc và thành phần**

- Túi cầu nhỏ, **một lớp màng**. P/L gần giống màng tế bào, nhưng **cholesterol chỉ bằng một nửa**.
- Màng có **bơm H^+^** đẩy proton vào lòng, giữ **pH ≤ 4,8** (bào tương pH **7–7,3**). Màng có protein vận chuyển đưa sản phẩm tiêu hóa ra bào tương.
- Lòng chứa **enzym thủy phân acid** (hoạt động tốt ở pH ≈ 5):
  - **protease** (protein), **lipase** (lipid), **glucosidase** (glucid), **nuclease** (acid nucleic);
  - và **phosphatase, phospholipase, sulfatase**…
- Bộ enzym này tiêu hóa được **mọi chất hữu cơ** của tế bào, cho lại **đường đơn, acid amin, nucleotid**.

**Vì sao tiêu thể không tự tiêu hóa tế bào?** Có ba "lớp an toàn":

1. **Màng tiêu thể gói enzym lại**, và chính màng này **glycosyl hóa mạnh** ở mặt trong nên không bị enzym cắt.
2. Enzym **chỉ hoạt động ở pH acid**. Nếu vài tiêu thể rách, enzym rơi ra bào tương **pH 7 thì bất hoạt**.
3. Enzym ở dạng **tiền enzym** (proenzym), chỉ được hoạt hóa ở pH 4,8.

Tuy vậy, khi bị kích thích mạnh, **hàng loạt tiêu thể vỡ cùng lúc** sẽ gây **tiêu bào** (tế bào tự hủy). Cũng có **tiêu bào sinh lý** để dọn những mô đã hết nhiệm vụ, ví dụ **đuôi nòng nọc tự tiêu**.

**Sự hình thành tiêu thể và đường đi của enzym**

=> Ribosom bám → lòng lưới có hạt (glycosyl hóa đầu N) → thể đậm → Golgi (phosphoryl hóa mannose) → túi cầu Golgi → thể nội bào muộn → tiêu thể

1. Enzym thủy phân acid được tổng hợp và đưa vào **lưới có hạt**, được **glycosyl hóa ở đầu N** (gắn oligosaccharid làm tín hiệu đi Golgi).
2. Enzym được dồn ra rìa lưới, đóng gói thành **thể đậm**, đi đến Golgi.
3. Tại Golgi, một vài gốc **mannose** trên chuỗi oligosaccharid được **phosphoryl hóa** thành **mannose-6-phosphat**. Đây là **tín hiệu dẫn đường** của enzym tiêu thể: nó cho phép enzym gắn vào **receptor** ở mặt trong túi dẹt Golgi (liên kết này xảy ra ở **pH trung tính**). Phần màng chứa phức hợp receptor–enzym thắt lại thành **túi cầu Golgi**.
4. Túi cầu Golgi đến **thể nội bào muộn**. Ở đây **pH acid** làm phức hợp receptor–enzym tách ra; phosphat bị cắt (phosphatase). **Receptor quay về Golgi** để dùng lại.
5. **Thể nội bào** sinh ra từ **nội thực bào**: thể nội bào sớm trả một số chất về màng tế bào, phần còn lại thành **thể nội bào muộn**; nhận enzym, pH tiếp tục giảm, trở thành **tiêu thể**.

**Ba con đường đưa "rác" đến tiêu thể:**

| Con đường | Đưa gì vào |
|---|---|
| **Nội thực bào** | Chất từ ngoài vào qua thể nội bào sớm → muộn |
| **Thực bào** | Vật lớn (vi khuẩn, mảnh tế bào): túi thực bào kết hợp với tiêu thể |
| **Tự thực bào** | Thành phần của chính tế bào cần thải bỏ (ty thể già, mảnh màng lưới…): thể tự thực bào kết hợp với tiêu thể hoặc thể nội bào muộn |

> [!cap-nhat] Tự thực bào (autophagy) — Nobel Y học 2016 (bổ sung – kiến thức hiện nay)
> - **Yoshinori Ohsumi** (Nobel Y học 2016) tìm ra các **gen ATG** điều khiển tự thực bào ở nấm men; người cũng có các gen tương ứng.
> - Cơ chế: một màng kép bao lấy phần bào tương cần dọn (protein kết tụ, ty thể hỏng — gọi riêng là **mitophagy**, cả vi khuẩn xâm nhập) tạo **thể tự thực bào (autophagosom)**, rồi hòa với tiêu thể để tiêu hóa và **tái chế** nguyên liệu.
> - Tự thực bào tăng mạnh khi tế bào **đói** (thiếu dinh dưỡng). Rối loạn tự thực bào liên quan **bệnh thoái hóa thần kinh** (Parkinson, Huntington), ung thư, nhiễm trùng và lão hóa.
> - Tiêu thể nay còn được xem là **trung tâm cảm nhận dinh dưỡng**: trên màng tiêu thể có phức hợp **mTORC1** quyết định tế bào "xây dựng" (đủ chất) hay "tái chế" (đói).

Khi gặp thể thực bào hay thể tự thực bào, tiêu thể chuyển sang **dạng hoạt động**: proenzym gặp pH 4,8 bị cắt thành enzym hoạt động. Sản phẩm tiêu hóa được trả cho bào tương để **tái tạo** tế bào. Cặn bã, chất độc được đưa vào **túi bài tiết** và đẩy ra ngoài (ngược với nội thực bào). Việc tiêu hóa các mảnh màng cũ được xem như **làm sạch tế bào**.

**Bệnh tiêu thể** là bệnh do **thiếu hoặc sai sót một enzym** của tiêu thể. Chất không được tiêu hóa sẽ **tích tụ** trong tiêu thể; nhiều trường hợp chỉ thiếu một enzym mà bệnh rất nặng.

> [!ung-dung] Bệnh Tay–Sachs và các bệnh "ứ đọng tiêu thể"
> - **Tay–Sachs**: thiếu enzym **N-acetyl-β-hexosaminidase A**, gangliosid **GM2** tích tụ trong tế bào thần kinh. Trẻ thoái triển thần kinh, chậm trí tuệ, thường **tử vong khoảng 4–5 tuổi**. Bệnh **di truyền lặn, nhiễm sắc thể thường**; gen nằm ở **nhánh dài NST số 15**.
> - Các bệnh cùng nhóm: **Gaucher** (thiếu glucocerebrosidase), **Pompe** (thiếu α-glucosidase acid, ứ glycogen trong tiêu thể), mucopolysaccharidosis (Hurler…). Hiện đã mô tả **khoảng 70 bệnh tiêu thể**, gộp lại gặp khoảng **1/5.000–1/8.000** trẻ sinh (từng bệnh thì hiếm).
> - Điều trị hiện nay *(bổ sung – kiến thức hiện nay)*: **thay thế enzym** (enzym tái tổ hợp truyền tĩnh mạch; nhiều enzym mang sẵn **mannose-6-phosphat** hoặc mannose để tế bào thu nhận qua receptor rồi chuyển vào tiêu thể — chính là "nhãn địa chỉ" đã học ở trên), **giảm cơ chất** (thuốc ức chế tạo chất bị ứ, như miglustat), và **liệu pháp gen** đang được thử nghiệm, áp dụng. Enzym truyền tĩnh mạch qua hàng rào máu – não kém, nên thể bệnh tổn thương thần kinh khó chữa hơn.
> - **I-cell disease** (bệnh tế bào I) là bằng chứng cho vai trò của mannose-6-phosphat: Golgi không gắn được "nhãn" này, nên enzym tiêu thể **bị tiết ra ngoài** thay vì vào tiêu thể.

### 3.5. Peroxysom

Gọi tiêu thể là bào quan tiêu hóa "chính" vì còn một bào quan khác là **peroxysom**.

- **Cấu trúc**: túi hình cầu, một lớp màng lipoprotein dày **6–8 nm**, đường kính **0,15–1,7 µm**; bên trong là chất nền đồng nhất, có khi có hạt nhỏ hoặc sợi.
- Chứa **phần lớn catalase** của tế bào và các **enzym oxy hóa**; **không chứa enzym thủy phân acid**. Enzym hoạt động trong môi trường **kiềm nhẹ**.
- Protein của peroxysom được tổng hợp ở **ribosom tự do**, có tín hiệu dẫn đường; đến nơi thì tín hiệu bị cắt.

| Enzym đặc trưng | Tác dụng |
|---|---|
| **Catalase** | Phân giải **H~2~O~2~** thành H~2~O (và O~2~) |
| **D-aminoacid oxydase** | Oxy hóa đặc hiệu các **D-acid amin** |
| **Urat oxydase (uricase)** | Phân giải acid uric. **Người và linh trưởng không có** nên nước tiểu người có **acid uric** |

=> 2 H~2~O~2~ → 2 H~2~O + O~2~ (catalase)

**Chức năng chủ yếu** (theo giáo trình): tham gia điều chỉnh **chuyển hóa glucose** và **phân giải H~2~O~2~** nhờ catalase. Hoạt động của peroxysom xoay quanh H~2~O~2~: các oxydase **tạo ra** H~2~O~2~, catalase **phân giải** nó.

> [!cap-nhat] Peroxysom và uricase
> - Hiện nay chức năng quan trọng nhất của peroxysom ở người được xác định là **β-oxy hóa acid béo chuỗi rất dài** và **tổng hợp plasmalogen** (lipid của myelin), bên cạnh phân giải H~2~O~2~. Thiếu peroxysom gây **hội chứng Zellweger** (tổn thương não, gan, thận nặng ở trẻ sơ sinh; do đột biến các gen **PEX** cần cho việc tạo peroxysom). **Loạn dưỡng chất trắng thượng thận liên kết X (X-ALD)** do hỏng protein vận chuyển **ABCD1** trên màng peroxysom: acid béo chuỗi rất dài không vào được peroxysom để β-oxy hóa, tích tụ và phá myelin.
> - Uricase bị mất ở **người và các loài vượn người**; nhiều động vật khác cũng không phân giải acid uric (chim, bò sát thải chính acid uric). Câu "các động vật khác không có acid uric trong nước tiểu" chỉ đúng với phần lớn động vật có vú.
> - Đi thi trả lời theo giáo trình.

> [!ung-dung] Vì sao người bị gút?
> Thiếu uricase nên acid uric là **sản phẩm cuối** của chuyển hóa purin ở người. Khi acid uric máu cao, tinh thể urat lắng ở khớp gây **gút**. Thuốc **rasburicase, pegloticase** chính là **uricase tái tổ hợp**, dùng khi acid uric tăng rất cao (ví dụ hội chứng ly giải u khi hóa trị) hoặc gút nặng kháng trị.

## 4. Lạp thể (ở tế bào thực vật)

Lạp thể là bào quan của **tế bào thực vật**, chuyên **tổng hợp carbohydrat từ chất vô cơ** nhờ năng lượng ánh sáng.

| Loại | Sắc tố | Đặc điểm theo giáo trình |
|---|---|---|
| **Sắc lạp** màu **vàng** | **Xantophyl** | Thu ánh sáng **yếu**, ánh sáng còn sót ở tầng lá dưới; "làm việc" vào mùa đông khi lá vàng |
| **Sắc lạp** màu **đỏ** | **Caroten** | Như trên |
| **Lục lạp** màu **lục** (quan trọng nhất) | **Chlorophyl (diệp lục)** | Thu ánh sáng **mạnh** của mặt trời |

### 4.1. Cấu trúc lục lạp

Lục lạp hình hạt, **khác mọi bào quan khác vì có ba lớp màng**:

1. **Màng ngoài**: **tính thấm cao**.
2. **Màng trong**: kém thấm hơn; có protein vận tải đẩy **glyceraldehyd-3-phosphat** (sản phẩm glucid của lục lạp) ra bào tương.
3. **Màng túi (thylakoid)**: **quan trọng nhất**, **P/L rất cao (= 3)**. Hình thành từ màng trong nhô ra và tách thành hệ màng mới.

- **Lòng lục lạp (stroma)**: **pH = 8**, nhiều enzym tự do tổng hợp **glyceraldehyd-3-phosphat (P-GAL)**; giữ tạm P-GAL hoặc dự trữ lâu dài dưới dạng **tinh bột**.
- **Khoang túi thylakoid**: **pH = 5**, nhờ **bơm H^+^** trên màng túi.
- Màng túi có phần xếp thành **tấm mỏng** song song, xen với những **chồng đĩa** gấp nếp nhiều lần gọi là **hạt (grana)**.
- Trên màng túi có: **diệp lục**, **bơm H^+^**, **hệ thống quang hợp**, các chất **nhận và truyền điện tử**, phức hợp **ATP synthetase (CF~0~–CF~1~)** hình chùy, đầu chùy đường kính 9 nm (còn gọi **oxysom**), phosphoryl hóa ADP thành ATP.
- **Hệ thống quang hợp 2** hấp thu ánh sáng **680 nm**; **hệ thống quang hợp 1** hấp thu **700 nm**. Ánh sáng tự nhiên dao động 600–700 nm, nên phối hợp hai hệ cho hiệu quả cao nhất.

### 4.2. Chức năng: quang hợp

Lục lạp thu năng lượng ánh sáng: một phần tạo ngay **ATP**, một phần tích vào **carbohydrat**. Gồm hai giai đoạn.

**a) Pha sáng** — chuỗi nhận và truyền điện tử trên màng thylakoid, nhằm tạo **ATP** và **NADPH**.

| | **Phosphoryl hóa vòng** | **Phosphoryl hóa không vòng** |
|---|---|---|
| Hệ thống tham gia | Chỉ **hệ 1** | **Hệ 2 rồi hệ 1** |
| Đường đi e^−^ | Diệp lục a → ferredoxin → cytochrom → plastocyanin → **trở về** diệp lục a | Diệp lục (hệ 2) → chất nhận "X" → plastoquinon → plastocyanin → diệp lục hệ 1 → ferredoxin → NADP^+^ |
| e^−^ bù cho diệp lục ban đầu | Chính e^−^ quay về | **Lấy từ nước** (quang phân ly nước) |
| Sản phẩm | **2 ATP** | **2 ATP + NADPH** (dùng H^+^ từ nước) |

Theo giáo trình, hệ 1 có **diệp lục a** (700 nm), hệ 2 có **diệp lục b** (680 nm). Diệp lục a là sắc tố chính, có ở mọi Eukaryota quang hợp và cả **vi khuẩn lam**.

**b) Pha tối (chu trình Calvin)** — trong **lòng lục lạp**, cố định **CO~2~** bằng năng lượng của **ATP** và **NADPH**, tạo **P-GAL (3C)**. P-GAL ra bào tương để tạo glucose (6C); thực vật dự trữ glucose dưới dạng **tinh bột**.

=> n C~6~H~12~O~6~ → (C~6~H~10~O~5~)~n~ + n H~2~O

> [!cap-nhat] Một số điểm về lục lạp
> - **Chlorophyl không phải protein**: nó là **sắc tố** (vòng porphyrin chứa Mg^2+^), gắn vào các protein xuyên màng thylakoid tạo phức hợp thu nhận ánh sáng.
> - Trung tâm phản ứng của **cả hai hệ quang hợp đều là diệp lục a** (P700 ở hệ 1, P680 ở hệ 2); diệp lục b chỉ là sắc tố **phụ** thu ánh sáng rồi chuyển năng lượng.
> - **O~2~ sinh ra ở pha sáng** do quang phân ly nước, không phải ở pha tối. Phương trình pha tối trong giáo trình có O~2~ ở vế phải là cách viết gộp, dễ gây hiểu nhầm.
> - Giáo trình cho rằng sắc lạp (xantophyl, caroten) "làm việc" khi lá vàng. Hiện nay biết **carotenoid nằm ngay trong lục lạp**, là sắc tố **phụ** hỗ trợ thu ánh sáng và bảo vệ diệp lục; lá chuyển vàng vì **diệp lục bị phân hủy** làm lộ màu carotenoid. Sắc lạp thực thụ (ở cánh hoa, quả chín) **không quang hợp**.
> - Giáo trình ghi năng lượng một glucose là 780.000 cal (mục lục lạp) nhưng lại dùng 688 kcal (mục ty thể, mục 5); trị số đúng là khoảng **686 kcal/mol**. Khi tính hiệu suất hô hấp, dùng **688 kcal** như giáo trình.

**ADN lạp thể**: dạng **vòng**, khoảng **145.000 cặp base**, mã hóa tARN, rARN, mARN; lạp thể có **ribosom riêng** (giống vi khuẩn). Phần lớn protein của lạp thể vẫn **nhận từ bào tương**. **Lạp thể chỉ sinh ra từ lạp thể**: tiền thân là **tiền lạp thể** (chỉ có màng ngoài, màng trong, ít màng túi); khi ra ánh sáng thì phát triển dần thành lục lạp. Giống ty thể (mục 5), lạp thể cũng là bào quan **nửa tự trị**.

## 5. Ty thể

Ty thể là bào quan **hô hấp tế bào**, hình túi như **quả bí đao nhỏ**, rải rác khắp tế bào chất, **tập trung nhiều ở tế bào hoạt động mạnh** (tế bào gan động vật có vú có **1000–1500** ty thể).

![Hình 3. Cấu trúc ty thể (sơ đồ cắt dọc)](ty-the.svg)

### 5.1. Cấu trúc và thành phần hóa học

Ty thể có **hai màng**, chia nó thành hai khoang: **khoảng gian màng** và **lòng ty thể** (chất nền).

| | **Màng ngoài** | **Màng trong** |
|---|---|---|
| P/L | **1** | **3** (rất cao) |
| Cholesterol | Thấp, bằng **1/6 màng hồng cầu** | Còn thấp hơn, bằng **1/2 màng ngoài** |
| Đặc điểm lipid | **Phosphatidylcholin** gấp 2,5 lần màng tế bào | Có **cardiolipin**, chặn H^+^ |
| Hình dạng | Trơn, bao ngoài | Gấp nếp thành **mào (crista)** để **tăng diện tích làm việc** |
| Protein đặc trưng | Phức hợp **vận tải protein** vào ty thể | (1) Vận tải đặc hiệu; (2) **chuỗi hô hấp**; (3) **ATP synthetase** |

- **Màng ngoài** phải nhập **phần lớn protein ty thể** (sản xuất ngoài bào tương). Các protein này mang một đoạn **tín hiệu dẫn đường ở đầu N**. Chúng hoặc đi thẳng vào màng ngoài, màng trong, khoảng gian màng hay lòng ty thể; hoặc phải qua **ổ thu nhận đặc hiệu** trên màng ngoài. Xong việc, tín hiệu bị **cắt bỏ** và giáng cấp trong lòng ty thể.
- **Khoảng gian màng**: môi trường **tương tự và cân bằng với bào tương**. Chứa **cytochrom c và b~2~**, cytochrom peroxydase, các enzym dùng ATP từ lòng ty thể ra để phosphoryl hóa các nucleotid (không phải adenin).
- **Màng trong**: **cardiolipin** làm màng **không thấm H^+^**. Đây là điều kiện để giữ chênh lệch H^+^ giữa hai bên màng; H^+^ chỉ có thể quay về lòng ty thể qua **ATP synthetase** và nhờ đó tạo ATP.
- **Lòng ty thể (chất nền)**: nhiều enzym, một phần do ty thể **tự tổng hợp** nhờ ADN riêng, phần lớn nhập từ bào tương. Có enzym **oxy hóa pyruvat và acid béo thành acetyl-CoA**, enzym của **chu trình Krebs**. Có **ADN vòng** và **ribosom** riêng.

### 5.2. Chức năng: hô hấp tế bào

Hô hấp **ái khí** (cần O~2~) gồm hai giai đoạn: **phân ly glucose** ở **bào tương** và **oxy hóa pyruvat** ở **ty thể**.

**a) Phân ly glucose (đường phân) — trong bào tương**

Glucose 6C bị cắt đôi thành **2 acid pyruvic (3C)**. Tiêu tốn 2 ATP, thu 4 ATP, **lời 2 ATP**.

=> C~6~H~12~O~6~ + 2 ATP → 2 C~3~H~4~O~3~ + 4 H + 2 ADP + 2 P + (năng lượng ≈ 4 ATP)

**b) Chu trình Krebs — trong lòng ty thể**

Pyruvat (và acid béo) vào ty thể, bị oxy hóa thành **acetyl-CoA (2C)** nhờ **pyruvat dehydrogenase**. Acetyl-CoA vào chu trình Krebs:

=> CH~3~COOH (dạng acetyl-CoA) + 2 H~2~O + 3 NAD^+^ + FAD → 2 CO~2~ + 3 NADH + FADH~2~ (+ 1 ATP)

CO~2~ ra khỏi ty thể. **Phần lớn năng lượng vẫn nằm trong điện tử của NADH và FADH~2~**, sẽ được thu ở chuỗi hô hấp.

**c) Chuỗi hô hấp và phosphoryl hóa oxy hóa — trên màng trong**

=> NADH → NADH dehydrogenase → ubiquinon → phức hợp cytochrom b–c~1~ → cytochrom c → cytochrom oxydase → O~2~ (tạo H~2~O)

- Điện tử đi **một chiều**, cuối cùng giao cho **O~2~**, tạo nước.
- Đồng thời **H^+^ bị bơm ra** khỏi lòng ty thể, tạo **gradient proton điện hóa** qua màng trong.
- H^+^ chảy ngược về qua **ATP synthetase** (phức hợp protein xuyên màng), làm quay "tua-bin" tổng hợp ATP. Quá trình gọi là **phosphoryl hóa oxy hóa**; lượng ATP tạo ra **tỷ lệ với lượng O~2~ tiêu thụ**: **thiếu O~2~ thì ATP giảm**.

**d) Bảng cân đối năng lượng (theo giáo trình)**

| Giai đoạn | Nơi xảy ra | ATP |
|---|---|---|
| Phân ly glucose | Bào tương | 2 |
| Oxy hóa pyruvat (Krebs + chuỗi hô hấp) | Ty thể | 36 |
| **Tổng** | | **38 ATP / 1 glucose** |

- Mỗi ATP tích **8 kcal**, nên 38 ATP = **304 kcal**.
- Đốt cháy tự do 1 glucose giải phóng **688 kcal**.
- **Hiệu suất** = 304 / 688 ≈ **44%**. Phần còn lại tỏa thành nhiệt.

> [!cap-nhat] Con số 38 ATP
> Giáo trình ghi 38 ATP/glucose và 8 kcal/ATP. Hiện nay, tính đến việc màng trong bị "rò" proton và chi phí vận chuyển ATP, pyruvat, phosphat qua màng, sách hóa sinh hiện đại ước tính khoảng **30–32 ATP/glucose**; năng lượng tự do chuẩn của ATP là khoảng **7,3 kcal/mol**. Đi thi môn Sinh học trả lời **38 ATP** theo giáo trình.

> [!ung-dung] Ngộ độc làm "tắt" chuỗi hô hấp
> **Cyanid** (sắn, măng chưa chế biến kỹ, nhân hạt đào, mơ…) gắn vào **cytochrom oxydase**, chặn khâu cuối giao điện tử cho O~2~ (**CO** ngoài gắn hemoglobin cũng ức chế enzym này). Tế bào có O~2~ mà **không dùng được**, nên ATP sụt nhanh; não và tim tổn thương đầu tiên. Đây là ví dụ cho thấy vì sao "thiếu khâu cuối thì cả chuỗi đứng lại".

Vi khuẩn ái khí **không có ty thể**: các phức hợp hô hấp nằm ngay trên **màng vi khuẩn**.

### 5.3. ADN ty thể

- Ty thể **sinh sản bằng cách phân đôi**, không theo nhịp phân bào của tế bào.
- Có **ADN riêng** và **ribosom riêng**, nhưng **không đủ** cho toàn bộ nhu cầu protein.
- ADN ty thể **giống ADN vi khuẩn**: **sợi kép, vòng**, 1–2 vòng mỗi ty thể, tự do trong chất nền hoặc bám màng trong.
- Ở người: dài **16.569 cặp base**, rất ổn định (có chút đa hình theo chủng tộc). Đặc biệt **cả hai mạch đơn đều mang gen** mã hóa độc lập.
- Chứa gen **rARN 12S và 16S**, các **tARN**, các tiểu đơn vị **I, II, III của cytochrom oxydase**, tiểu đơn vị **ATPase**, **cytochrom b** và một số gen protein khác.
- **Khoảng 9/10 protein ty thể do gen trong nhân** mã hóa; ty thể tự mã hóa khoảng **10%** (theo giáo trình).
- Mã di truyền ty thể có vài **ngoại lệ**: theo giáo trình, **UAG mã hóa tryptophan** (không phải mã kết thúc); **AGA, AGG là mã kết thúc** (không mã hóa arginin).

> [!cap-nhat] Hệ gen ty thể người
> - Hệ gen ty thể người có **37 gen**: **13 gen protein** (đều thuộc chuỗi hô hấp và ATP synthase), **22 gen tARN**, **2 gen rARN** (12S, 16S). Ty thể có khoảng 1000–1500 loại protein, nên phần do ty thể tự mã hóa thực ra **chưa tới 2%** (giáo trình ghi khoảng 10%).
> - Ngoại lệ mã di truyền đã được xác định ở ty thể người là **UGA mã hóa tryptophan** (giáo trình in là UAG); **AUA mã hóa methionin**; **AGA, AGG** là tín hiệu kết thúc.
> - Đi thi trả lời theo giáo trình.

**Di truyền theo dòng mẹ.** Noãn bào có **rất nhiều ty thể**; ty thể tinh trùng nằm ở **cổ (đoạn giữa)** và **không truyền lại** cho hợp tử. Vì vậy mọi ty thể của cơ thể đều có **nguồn gốc từ mẹ**. Bệnh do đột biến gen ty thể **chỉ do mẹ truyền**, và gặp **như nhau ở con trai và con gái**. (Có ngoại lệ: một loài thân mềm chân rìu có ADN ty thể của bố và mẹ đóng vai trò ngang nhau.)

> [!cap-nhat] Ty thể của tinh trùng
> Giáo trình ghi tinh trùng chỉ có 4 ty thể và chúng không vào noãn. Hiện nay biết đoạn giữa tinh trùng người có **vài chục ty thể** xếp xoắn ốc; chúng **có vào noãn** nhưng được **đánh dấu (ubiquitin) và phân hủy** sớm. Kết luận "ADN ty thể di truyền theo dòng mẹ" vẫn đúng.

> [!cap-nhat] Bệnh ty thể và liệu pháp thay ty thể (bổ sung – kiến thức hiện nay)
> - Mỗi tế bào có hàng trăm đến hàng nghìn bản ADN ty thể. Khi đột biến chỉ có ở **một phần** các bản sao (**dị tế bào chất – heteroplasmy**), bệnh chỉ biểu hiện khi tỷ lệ ADN đột biến vượt một **ngưỡng** ở mô; vì vậy mức độ bệnh **khác nhau rất nhiều** giữa các con của cùng một mẹ.
> - "Bệnh ty thể" theo nghĩa rộng còn do **đột biến gen nhân** mã hóa protein ty thể (di truyền theo quy luật Mendel), vì phần lớn protein ty thể do gen nhân mã hóa (danh mục MitoCarta3.0 có **1.136 gen** người mã hóa protein ty thể).
> - **Liệu pháp thay ty thể** (mitochondrial donation): chuyển nhân (tiền nhân) từ trứng/hợp tử của mẹ mang bệnh sang trứng của người cho có ty thể khỏe. Vương quốc Anh là nước đầu tiên cho phép (luật **2015**), thực hiện tại Newcastle; tháng **7/2025** công bố **8 trẻ** khỏe mạnh ra đời bằng kỹ thuật này (tạp chí NEJM). Úc thông qua luật cho phép năm **2022** (Maeve's Law). Một số trẻ vẫn còn **ít ADN ty thể đột biến** của mẹ, nên trẻ cần được theo dõi lâu dài.
> - Ty thể còn giữ vai trò "công tắc" của **chết tế bào theo chương trình (apoptosis)**: khi bị tổn thương, ty thể giải phóng **cytochrom c** ra bào tương, hoạt hóa chuỗi enzym **caspase**.

> [!ung-dung] Ứng dụng của ADN ty thể
> - **Bệnh ty thể** ảnh hưởng nặng nhất đến mô cần nhiều năng lượng: **thần kinh và cơ** (ví dụ bệnh thần kinh thị giác di truyền Leber, hội chứng MELAS). Mẹ bệnh thì con trai, con gái đều có thể mắc; bố bệnh không truyền cho con.
> - **Pháp y**: mỗi tế bào chỉ có một bộ ADN nhân nhưng có **hàng nghìn bản ADN ty thể**, nên ADN ty thể còn sót lại cao hơn nhiều khi mẫu bị hủy hoại (kể cả **bị đốt cháy**). Người ta dùng nó để **xác định danh tính nạn nhân**, so sánh với họ hàng bên mẹ.

### 5.4. Tính nửa tự trị của ty thể

Ty thể có ADN vòng, ribosom riêng giống ribosom vi khuẩn, phân đôi như vi khuẩn. Giả thuyết **nội cộng sinh** cho rằng từ rất lâu, một tế bào **Prokaryota** đã vào sống cộng sinh trong tế bào Eukaryota. Dần dần, phần lớn gen của nó **chuyển sang nhân** tế bào chủ. Ngày nay ty thể chỉ còn một phần nhỏ gen riêng, nên **độc lập một phần về di truyền**. Đó là **tính nửa tự trị** của ty thể.

## 6. Trung thể

**Phân bố.** Có ở **mọi tế bào động vật** (giáo trình ghi trừ tế bào thần kinh) và ở **thực vật bậc thấp**; **không có** ở **Prokaryota** và **thực vật bậc cao**. Nói cách khác, có ở mọi sinh vật bậc cao mà ít nhất một giai đoạn có **tế bào di động** (như tinh trùng bơi).

**Cấu trúc**

- Gồm **hai trung tử** và **chất quanh trung tử**; thường nằm **gần nhân**, đôi khi cạnh Golgi (ở một số tế bào biểu mô thì nằm sát màng tế bào).
- Mỗi trung tử như **mẩu bút chì**: đường kính khoảng **150 nm**, dài **300–500 nm**, **một đầu kín, một đầu hở**; lòng chứa dịch với các hạt sẫm màu.
- Thành ống gồm **9 bộ ba ống vi thể** (9 tấm protein, mỗi tấm 3 ống liền nhau: **A** gần tâm nhất, rồi **B, C**). Các tấm xếp cách đều, nghiêng góc **30°** so với tiếp tuyến, nhìn trên lát cắt như **chong chóng 9 cánh**. Ống A của tấm này nối với ống C của tấm bên cạnh.
- Lòng rỗng, không có ống trung tâm: cấu trúc **9 + 0**.
- **Hai trung tử luôn vuông góc** với nhau.

**Sự hình thành.** Ở **kỳ đầu** phân bào, trước khi có thoi vô sắc, một **trung thể mới xuất hiện ngay cạnh trung thể cũ**: tiền thân trung tử ngắn rồi dài dần, ống vi thể rõ dần. Điều này từng khiến người ta **nhầm rằng trung thể có ADN riêng**, nhưng thực tế **không có**. Trung thể mới di chuyển về **cực đối diện**. Sau đó **sợi vô sắc** mọc ra từ vùng quanh trung tử, tạo **thoi vô sắc**. Quanh trung tử có các sợi ngắn gọi là **sợi sao** (thực vật không có).

Ngày nay trung thể được gọi là **trung tâm tổ chức ống vi thể (MTOC, microtubule organizing centre)**.

**Chức năng**

- **Làm mốc cho thoi vô sắc**, bảo đảm bộ nhiễm sắc thể chia đôi **đúng số lượng, đúng hướng**.
- Ở **động vật nguyên sinh**: tham gia **di động** tế bào.
- Nhưng **không bắt buộc** cho phân bào: thực vật bậc cao (thụ phấn nhờ gió, không có tinh trùng bơi) **không có trung thể** mà vẫn có thoi vô sắc hoạt động chính xác (không có sợi sao).

> [!bay]
> - Trung tử **9 bộ ba + 0** (không có cặp trung tâm). Lông, roi có cấu trúc **9 đôi + 2** (sẽ học sau); thể đáy của lông, roi lại giống trung tử (9 + 0).
> - Trung thể **không có ADN**.
> - Thực vật bậc cao: **không trung thể, không sợi sao, vẫn có thoi vô sắc**.

> [!cap-nhat] Trung thể
> - Hiện nay biết trung tử **nhân đôi ở pha S của gian kỳ** (mỗi trung tử cũ làm "khuôn" cho một trung tử mới mọc vuông góc bên cạnh); đến **kỳ đầu** hai trung thể mới tách nhau về hai cực.
> - Tế bào thần kinh trưởng thành **vẫn có trung tử** (làm thể đáy cho lông nguyên phát), chỉ là không phân bào.
> - Đi thi trả lời theo giáo trình.

## 7. Bộ khung xương tế bào

Ngoài các bào quan, tế bào chất còn có hệ thống **ống vi thể, sợi vi thể và sợi trung gian** tạo nên **khung xương tế bào (cytoskeleton)**.

| | **Ống vi thể** (microtubule) | **Sợi vi thể** (microfilament) | **Sợi trung gian** (IF) |
|---|---|---|---|
| Đường kính | **~24 nm**, thành dày 5 nm, **rỗng** | **~8 nm** (actin) | **~10 nm** (giữa hai loại kia) |
| Protein | **Tubulin α và β** | **Actin** (G → F); **myozin** | Nhiều loại: **keratin**, **neurofilament** (NF-L, NF-M, NF-H), **lamin** A, B, C |
| Cấu tạo | **13 sợi protein** (9–14) quây thành ống; không phân nhánh, dài tới vài µm | Actin: 2 chuỗi xoắn nhau, bước xoắn 72 nm | Nhiều sợi xoắn nhau theo nhiều bậc |
| Chức năng chính | Khung xương, **vận tải nội bào**, **thoi phân bào**, **trung tử, lông, roi** | Nâng đỡ, **cố định màng**; cùng myozin tạo **vận động** | **Khung xương**, chịu lực; lamina màng nhân |
| Chất tác động | **Colchicin, vinblastin** phá ống | | |

### 7.1. Ống vi thể

**Cấu tạo.** Các phân tử **tubulin α và β** kết hợp thành sợi protein; thường **13 sợi** xếp thành thành ống. Trong cấu trúc có **trung tâm liên kết nucleotid** (giáo trình ghi là ATP) và **trung tâm liên kết các alcaloid ức chế** như **colchicin, vinblastin**. Vì vậy các chất này **ức chế tạo thoi phân bào**. Ống vi thể có thể tự do trong tế bào chất, tạo **sao** và **thoi phân bào**.

**Chức năng**

- Tạo **khung xương**, giữ **hình dạng** tế bào và **vị trí** các cấu trúc trong tế bào chất.
- **Vận tải nội bào**: bào quan, hạt sắc tố… di chuyển dọc ống vi thể.
- Tham gia **vận động và biệt hóa** tế bào: nhiều tế bào biệt hóa giữ được hình dạng nhờ cách sắp xếp ống vi thể.
- Tạo cấu trúc ổn định như **trung tử**; quan trọng trong **nguyên phân và giảm phân**.
- Là thành phần và yếu tố vận động của **lông, roi**.

**Thí nghiệm kinh điển**: xử lý tế bào bằng **colchicin**, ống vi thể **biến mất**, tế bào mất hình dạng riêng, trở nên **tròn hoặc đa giác**.

> [!cap-nhat] Protein vận động trên khung xương (bổ sung – kiến thức hiện nay)
> - "Vận tải dọc ống vi thể" do hai họ **protein vận động** dùng ATP đảm nhận: **kinesin** thường đi về **đầu (+)** (từ trung tâm ra ngoại vi, ví dụ dọc sợi trục thần kinh từ thân ra tận cùng), **dynein** đi về **đầu (−)** (về phía trung tâm). Trên sợi actin, "động cơ" là **myozin**.
> - Hỏng dynein của lông chuyển gây **rối loạn vận động lông nguyên phát** (hội chứng Kartagener: viêm xoang – phế quản tái diễn, vô sinh nam, có thể đảo ngược phủ tạng). Hỏng **lông nguyên phát** (lông "ăng-ten" cảm nhận tín hiệu) gây nhóm **bệnh lông (ciliopathy)**, ví dụ bệnh thận đa nang.

> [!cap-nhat] Tubulin gắn GTP
> Giáo trình ghi tubulin có trung tâm liên kết ATP. Hiện nay đã xác định **tubulin gắn GTP**; thủy phân GTP liên quan đến việc ống vi thể kéo dài hay tháo rời (tính "bất ổn động"). Đi thi trả lời theo giáo trình.

> [!yhct] Alkaloid thực vật tác động lên ống vi thể
> **Colchicin** (cây Ngót nghẻo), **vinblastin, vincristin** (cây Dừa cạn) gắn tubulin, chặn trùng hợp ống vi thể; **paclitaxel** (cây Thông đỏ) ngược lại làm ống vi thể quá bền. Đây là thuốc đã tinh chế, liều tính bằng miligam; Ngót nghẻo **rất độc**, không tự dùng cây tươi. Nguồn gốc, công dụng và độc tính (xem bài *Phân chia tế bào và sự hình thành giao tử ở người*, mã sh-05).

### 7.2. Sợi vi thể

- **Sợi actin**: protein **actin G** (hình cầu) **trùng hợp** thành **actin F** (hình sợi). Mỗi sợi gồm **hai chuỗi actin xoắn nhau**, đường kính **~8 nm**, bước xoắn **72 nm**. Sự trùng hợp là **thuận nghịch**, được điều chỉnh đúng nơi, đúng lúc tế bào cần. Chức năng: **nâng đỡ, cố định màng sinh chất**; là thành phần khung xương.
- **Sợi myozin**: phân tử myozin gồm **6 chuỗi polypeptid**: **2 chuỗi nặng** và **2 đôi chuỗi nhẹ**. Ở tế bào chất thường ngắn; trong sợi cơ dài tới **1,5 µm**. Myozin **không chỉ có ở tế bào cơ** mà có ở nhiều tế bào khác. Myozin liên kết với actin bảo đảm **tính vận động** của tế bào (co cơ, tách tế bào chất khi phân bào, chuyển động amip).

### 7.3. Sợi trung gian

Đường kính **~10 nm**: dày hơn sợi vi thể, mảnh hơn ống vi thể. Cấu tạo từ **nhiều loại protein** tùy loại tế bào, gồm nhiều sợi xoắn nhau nhiều bậc:

- **Keratin**: tế bào **biểu mô**.
- **Neurofilament** (NF-L, NF-M, NF-H): sợi thần kinh.
- **Lamin A, B, C**: tạo **lamina** lót mặt trong **màng nhân**, có ở mọi loại tế bào.

Chức năng: góp phần tạo **khung xương tế bào**.

> [!ung-dung] Sợi trung gian trong chẩn đoán
> Mỗi loại mô có loại sợi trung gian riêng, nên nhuộm hóa mô miễn dịch tìm **cytokeratin** (u biểu mô), **vimentin**, **desmin** (u cơ)… giúp xác định **nguồn gốc khối u** di căn. Đột biến **lamin A** gây hội chứng **lão nhi (progeria)**: một đột biến điểm ở gen *LMNA* tạo ra lamin A bất thường (**progerin**) còn giữ gốc farnesyl, bám chặt màng nhân làm nhân biến dạng. Thuốc **lonafarnib** (ức chế farnesyltransferase) được FDA Hoa Kỳ phê duyệt tháng **11/2020** — thuốc đầu tiên cho progeria, giúp kéo dài đời sống (bổ sung – kiến thức hiện nay).

## 8. Không bào và thể vùi

**Không bào.** Nếu coi bào quan là cấu trúc được bao bởi màng sinh chất nội bào, thì không bào cũng là bào quan. Ở **động vật đơn bào**, không bào là bào quan thực sự: **không bào tiêu hóa**, **không bào co bóp** (bài tiết, điều tiết nước). Ở **thực vật**, không bào chứa **chất dự trữ**; nói chung đều chứa đầy **dịch**.

**Thể vùi** là chất dự trữ trong tế bào chất, **không có màng bao** (trừ khi nằm trong không bào):

- **Glycogen**: nhiều ở **gan, cơ**; con vật ăn tốt thì glycogen có thể tới **10% trọng lượng khô của gan**.
- **Giọt triacylglycerol** lớn trong **tế bào mỡ**: dạng dự trữ acid béo.
- Ở thực vật: hạt tinh bột…

## 9. So sánh các loại màng sinh chất

| Màng | P/L | Cholesterol | Điểm đặc trưng |
|---|---|---|---|
| **Màng tế bào** | ≈ 1 (hồng cầu) | **25–30%** lipid (gan 40%), **cao nhất** | Lớp áo tế bào; phosphatidylcholin 18% |
| **Lưới có hạt** | > 1, ≈ **2** | **6%** | Phosphatidylcholin 55%; ribosom, ribophorin; glucose-6-phosphatase |
| **Lưới nhẵn** | ≈ 2 (như RER) | **10%** | Phosphatidylcholin 55%; enzym chuyển hóa lipid, giải độc |
| **Golgi** | cis ≈ 2 → trans ≈ 1 | Tăng dần về phía trans | Màng dày 50–60 Å (cis) → ~100 Å (trans) |
| **Tiêu thể** | ≈ màng tế bào | **1/2** màng tế bào | Bơm H^+^; mặt trong glycosyl hóa mạnh |
| **Ty thể – màng ngoài** | **1** | **1/6** màng hồng cầu | Phosphatidylcholin ×2,5; vận tải protein |
| **Ty thể – màng trong** | **3** | **1/2** màng ngoài | Cardiolipin; chuỗi hô hấp; ATP synthetase |
| **Thylakoid** | **3** | | Diệp lục, hệ quang hợp 1 và 2, ATP synthetase |

Quy luật chung: **màng làm nhiều "việc" (enzym, vận chuyển) thì P/L cao**; **cholesterol càng nhiều thì màng càng kém lỏng**.

## Tóm tắt

| Bào quan | Màng | Chức năng cốt lõi | Con số/điểm cần nhớ |
|---|---|---|---|
| Màng tế bào | Lớp kép lipid | Bao bọc, trao đổi chất, nhận và xử lý thông tin | Dày ~100 Å; lipid: phospholipid 55%, cholesterol 25–30%; protein xuyên màng 70% |
| Ribosom | Không | Tổng hợp protein | 70S (30S + 50S) / 80S (40S + 60S) |
| Lưới có hạt | 1 màng | Nhận, chế biến, glycosyl hóa bước 1, gửi protein; tổng hợp lipid màng | P/L ≈ 2; cholesterol 6% |
| Lưới nhẵn | 1 màng | Lipid, steroid, giải độc, Ca^2+^ ở cơ | Cholesterol 10% |
| Golgi | 1 màng | Thuần thục hóa, bao gói, phân phát; tạo tiêu thể, acrosom, lớp áo | cis (vào) → trans (ra) |
| Tiêu thể | 1 màng | Tiêu hóa nội bào | pH ≤ 4,8; enzym thủy phân acid; mannose-6-phosphat |
| Peroxysom | 1 màng | Phân giải H~2~O~2~ | Catalase, D-aminoacid oxydase, uricase (người không có) |
| Ty thể | 2 màng | Hô hấp, ATP | 38 ATP; P/L ngoài 1, trong 3; ADN 16.569 bp, dòng mẹ |
| Lục lạp | 3 màng | Quang hợp | Thylakoid P/L = 3; hệ 1: 700 nm, hệ 2: 680 nm |
| Trung thể | Không | MTOC, mốc thoi vô sắc | 2 trung tử vuông góc, 9 bộ ba + 0 |
| Khung xương | Không | Hình dạng, vận chuyển, vận động | Ống vi thể 24 nm; sợi trung gian 10 nm; sợi actin 8 nm |
