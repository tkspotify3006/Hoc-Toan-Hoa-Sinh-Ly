---
title: Nhân tế bào Eukaryota
thoi-gian: 35 phút
muc-tieu:
- Mô tả được hình dạng, kích thước và số lượng nhân trong các loại tế bào.
- Trình bày được cấu trúc và chức năng của màng nhân (màng ngoài, khoảng quanh nhân, màng trong, lamina, lỗ màng nhân) và dịch nhân.
- Trình bày được cấu trúc vi thể và siêu vi thể của nhiễm sắc thể; thành phần hóa học của chromatin (histon, HMG, nucleosom).
- Phân biệt được dị nhiễm sắc và nhiễm sắc thực; nêu được cấu trúc và chức năng của hạch nhân.
- Nêu được chức năng chung của nhân tế bào.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Nhân gồm 4 thành phần chính: **màng nhân, dịch nhân, nhiễm sắc thể, hạch nhân**.
> 2. Màng nhân là **màng kép**: màng ngoài nối với lưới nội sinh chất (có ribosom), màng trong được lót bởi **lamina**; hai màng nối với nhau ở **lỗ màng nhân** (kênh nước 9 nm) — cửa ngõ duy nhất giữa nhân và tế bào chất.
> 3. ADN (DNA) quấn quanh **lõi 8 histon** (2 H2A, 2 H2B, 2 H3, 2 H4; 146 cặp nu) thành **nucleosom** → chuỗi hạt **10 nm** → sợi **30 nm** → vòng bám khung protein → NST (nhiễm sắc thể) kỳ giữa.
> 4. NST kỳ giữa = **2 chromatid** dính ở phần tâm; phần tâm chia NST thành nhánh **p** (ngắn) và **q** (dài) → tâm giữa, tâm lệch, tâm đầu.
> 5. **Hạch nhân** không có màng, tạo rARN (rRNA) và lắp ráp tiểu đơn vị ribosom; ở người gen rARN nằm trên NST **13, 14, 15, 21, 22**.

## 1. Hình dạng, kích thước, số lượng nhân

### 1.1. Hình dạng

Nhân thường có hình dạng **phù hợp với hình dạng tế bào**:

| Loại tế bào | Hình dạng nhân |
|---|---|
| Biểu mô hình khối | Hình cầu |
| Cơ trơn | Hình thuôn dài (đa giác) |
| Biểu mô lát | Hình đĩa |

Có những ngoại lệ, nhân không giống hình tế bào: **bạch cầu hạt** có nhân chia nhánh, chia thùy; tế bào **tuyến tơ của tằm** hình khối vuông nhưng nhân lại phân nhánh.

Hình dạng nhân còn thay đổi theo **tuổi** và **mức hoạt động** của tế bào. Tế bào hoạt động mạnh thường có nhân to ra, chia nhánh hoặc chia thùy. *Vì sao?* Nhân chia nhánh làm **tăng diện tích màng nhân** so với thể tích, nên trao đổi chất (ARN đi ra, protein đi vào) giữa nhân và tế bào chất nhanh hơn.

### 1.2. Kích thước

- Nhân **rất nhỏ**: tế bào nhầy của tuyến nước bọt.
- Nhân **đặc biệt lớn**: tế bào thần kinh nhiều cực ở **sừng trước tủy sống**, tế bào **hình tháp** (vỏ não).

Mỗi loại tế bào giữ một **tỷ lệ nhân/tế bào chất** nhất định. Khi tỷ lệ này thay đổi, tế bào sẽ đi vào **phân bào** hoặc bị **hủy hoại**.

> [!ung-dung] Tỷ lệ nhân/bào tương trong giải phẫu bệnh
> Khi đọc tiêu bản tế bào học (ví dụ phết tế bào cổ tử cung), tế bào **ác tính** thường có nhân to, **tỷ lệ nhân/bào tương tăng**, nhân tăng sắc và hạch nhân to. Đây là một trong các tiêu chuẩn hình thái để nghi ngờ ung thư.

### 1.3. Số lượng

- Thông thường mỗi tế bào có **1 nhân**.
- Có tế bào **2 nhân**: ví dụ tế bào gan (chiếm khoảng **15%** số tế bào gan).
- Tế bào **đa nhân** có hai kiểu, phân biệt theo cách hình thành:

| | Cộng bào | Hợp bào |
|---|---|---|
| Cách tạo | Nhân **phân chia** nhưng tế bào chất **không chia** | Nhiều tế bào **hợp nhất** thành một khối |
| Ví dụ (giáo trình) | — | Tế bào **hủy xương** |

- **Không có nhân**: **hồng cầu** ở máu ngoại vi của **động vật có vú** (hồng cầu chim, ếch vẫn có nhân).

> [!cap-nhat] Nguồn gốc tế bào hủy xương
> Giáo trình ghi tế bào hủy xương do nhiều **tế bào tạo xương** hợp nhất lại. Hiện nay đã xác định tế bào hủy xương (osteoclast) do các tế bào tiền thân thuộc dòng **mono bào – đại thực bào** (từ tủy xương) hợp nhất tạo thành; tế bào tạo xương (osteoblast) chỉ đóng vai trò điều hòa. Khi thi, ví dụ "hợp bào = tế bào hủy xương" vẫn đúng.

> [!bay]
> - **Cộng bào** = chia nhân, không chia bào tương; **hợp bào** = nhiều tế bào nhập lại. Dễ đảo ngược hai khái niệm.
> - Hồng cầu **người trưởng thành** không có nhân; hồng cầu **chim** có nhân (giáo trình dùng hồng cầu chim làm ví dụ đếm lỗ màng nhân).

## 2. Màng nhân

Nhân có **4 thành phần chính**: màng nhân, dịch nhân, nhiễm sắc thể và hạch nhân.

Dưới kính hiển vi điện tử, màng nhân gồm **hai màng đồng tâm**: màng nhân ngoài và màng nhân trong. Giữa hai màng là **khoảng quanh nhân**.

![Hình 1. Sơ đồ màng nhân kép, lamina và lỗ màng nhân](mang-nhan.svg)

### 2.1. Màng nhân ngoài

- **Hình thái** giống màng **lưới nội sinh chất có hạt**: mặt ngoài có rải rác **ribosom** bám vào. Protein do các ribosom này tổng hợp được đưa vào khoảng quanh nhân hoặc vào lòng lưới nội sinh chất.
- **Thành phần hóa học** lại giống màng **lưới nội sinh chất nhẵn**: **cholesterol chiếm khoảng 10%**, các lipid khác cũng tương tự.
- Màng nhân ngoài **nối liền** với màng lưới nội sinh chất. Có thể coi nó là **một vùng đặc biệt của lưới nội sinh chất**.

**Chức năng**: tái tạo màng nhân; tham gia tạo màng lưới nội sinh chất và các màng nội bào khác, kể cả màng tế bào. Cách làm: tách những mảnh màng mới, cuộn lại thành **túi hình cầu** (giống túi vận tải nội bào) rồi gửi tới nơi cần.

> [!bay]
> Màng nhân ngoài: **hình thái** giống lưới nội sinh chất **có hạt** (có ribosom), nhưng **thành phần hóa học** giống lưới nội sinh chất **nhẵn** (cholesterol 10%). Đề thi hay đảo hai ý này.

### 2.2. Khoảng quanh nhân

- Nằm giữa màng nhân ngoài và màng nhân trong, dày **10–15 nm** (không đều).
- **Thông với lòng lưới nội sinh chất có hạt** (và theo giáo trình, thông ra ngoài tế bào). Vật chất di chuyển **hai chiều** trong khoảng này.

*Vì sao thông được?* Vì màng nhân ngoài liền với màng lưới nội sinh chất, nên lòng của hai hệ thống này là một khoang chung.

### 2.3. Màng nhân trong và lamina

Màng nhân trong gồm **hai phần**:

1. **Phần màng sinh chất**: giống màng nhân ngoài.
2. **Lamina** lót ở mặt trong:
   - Là mạng lưới protein dày **10–20 nm**, gồm những **lỗ mắt cáo vuông** do **sợi trung gian** tạo thành.
   - Ở động vật có vú gồm 3 loại protein sợi trung gian: **A, B và C** (giáo trình gọi là "laminin"). Mỗi phân tử có **phần hình que** và **hai đầu hình cầu** ở một đầu mút.
   - Lamina **chừa lại các lỗ màng nhân**.

**Chức năng của lamina**: làm **giá đỡ** cho màng nhân, và là **nơi bám** của các sợi chromatin ở **vùng ngoại vi** nhân.

> [!cap-nhat] "Laminin" hay "lamin"?
> Giáo trình gọi các protein của lamina là **laminin A, B, C**. Tên đúng hiện nay là **lamin A, B, C** (sợi trung gian type V). **Laminin** là một protein khác hẳn, nằm ở **màng đáy** ngoài tế bào. Đi thi nếu đề dùng chữ "laminin" thì hiểu là lamin của lamina nhân.

> [!ung-dung] Bệnh của lamina (laminopathy)
> Đột biến gen *LMNA* (mã hóa lamin A/C) làm lamina yếu, nhân biến dạng. Hậu quả là nhóm bệnh như **hội chứng lão hóa sớm Hutchinson–Gilford (progeria)**, một số bệnh **loạn dưỡng cơ** và **bệnh cơ tim**. Ví dụ này cho thấy lamina không chỉ "đỡ" màng nhân mà còn ảnh hưởng đến tổ chức chromatin và biểu hiện gen.
> - *(Bổ sung – kiến thức hiện nay)* Progeria kinh điển do **một đột biến điểm** ở *LMNA* (c.1824C>T) làm lộ một vị trí cắt bất thường, tạo lamin A bị thiếu đoạn gọi là **progerin**; progerin giữ gốc lipid **farnesyl** nên bám chặt màng nhân, làm nhân phồng, nhăn. Thuốc **lonafarnib** (ức chế farnesyltransferase) được FDA phê duyệt ngày **20/11/2020**, là thuốc đầu tiên điều trị progeria.

### 2.4. Lỗ màng nhân

**Có ở tất cả Eukaryota** (sinh vật nhân thực), từ nấm đến người. Số lỗ thay đổi theo loại tế bào:

| Tế bào | Mật độ lỗ |
|---|---|
| Hồng cầu chim | khoảng 4–6 lỗ/µm² |
| Tế bào động vật có vú | 3000–4000 lỗ/tế bào, khoảng 11 lỗ/µm² |

**Cấu trúc phức hợp lỗ màng nhân:**

- Thành lỗ được tạo do **màng nhân ngoài nối liền với màng nhân trong**.
- Mỗi lỗ nằm trong một cấu trúc lớn **hình đĩa**, khối lượng phân tử lớn, gọi là **phức hợp lỗ màng nhân**.
- Phức hợp gồm các hạt protein lớn xếp thành **hình tám cạnh**, tạo **3 vòng hạt** đính trên thành, có **hình chiếu trùng nhau**.
- Ở trung tâm là **kênh nước** đường kính **9 nm**, dài **15 nm**. Các phân tử tan trong nước đi qua lại theo kênh này.
- Kênh thường bị lấp bởi một **hạt trung tâm**: đó là ribosom mới tạo hoặc phân tử khác đang đi qua.
- Chất có kích thước lớn muốn qua lỗ thì cần các **protein quanh lỗ** "nới rộng" lỗ ra.

**Chiều vận chuyển qua lỗ:**

| Chiều | Chất được vận chuyển | Để làm gì |
|---|---|---|
| Tế bào chất → nhân | Protein (histon, enzym…) | Nhân đôi ADN, phiên mã, cấu tạo ribosom |
| Nhân → tế bào chất | **mARN, tARN, các tiểu đơn vị ribosom** | Dịch mã ở tế bào chất |
| **Hai chiều** | **snARN** (small nuclear ARN) | Tổng hợp trong nhân → ra tế bào chất kết hợp protein thành **RNP** → quay lại nhân để **thuần thục mARN** |

> [!cap-nhat] Lỗ màng nhân theo hiểu biết hiện nay (bổ sung – kiến thức hiện nay)
> - Phức hợp lỗ màng nhân là một trong những cấu trúc protein lớn nhất của tế bào (ở động vật có xương sống **> 100 MDa**), gồm **khoảng 30 loại nucleoporin**, mỗi loại có nhiều bản sao, xếp theo **đối xứng bậc 8** (khớp với "8 cạnh" của giáo trình). Năm 2022 cấu trúc gần như toàn bộ phức hợp đã được dựng lại nhờ kết hợp cryo-ET và dự đoán cấu trúc protein bằng trí tuệ nhân tạo (AlphaFold).
> - Lòng kênh chứa các sợi nucleoporin giàu lặp **FG** (phenylalanin – glycin) tạo một "hàng rào gel". Phân tử nhỏ (dưới khoảng **40 kDa**) khuếch tán tự do; phân tử lớn phải được **importin/exportin** nhận diện qua **tín hiệu định vị nhân (NLS)** hoặc tín hiệu xuất nhân, với năng lượng và chiều đi do protein **Ran-GTP** quyết định. Đây là cách hiểu hiện nay của việc "nới rộng lỗ" mà giáo trình mô tả.

*Vì sao cần lỗ?* Màng kép là hàng rào kín, mà nhân không tự tổng hợp protein (không có ribosom hoạt động bên trong), còn tế bào chất cần ARN từ nhân. Lỗ màng nhân là **cửa ngõ duy nhất** cho mọi trao đổi này.

> [!vi-du] Tế bào hoạt động mạnh có nhiều lỗ hơn
> Tế bào tổng hợp protein mạnh cần xuất nhiều mARN và tiểu đơn vị ribosom, nên có nhiều lỗ màng nhân hơn. Ngược lại nhân hồng cầu chim kết đặc, gần như không hoạt động, nên chỉ có vài lỗ trên mỗi µm².

## 3. Dịch nhân

Dịch nhân chứa **nguyên liệu** và nhiều **protein** phục vụ chức năng của nhân:

- **Histon**;
- **ADN polymerase** (nhân đôi), **ARN polymerase** (phiên mã);
- **Protein điều chỉnh gen**;
- **Enzym thuần thục ARN**.

Trong dịch nhân còn có hệ thống sợi protein (trong đó có **actin**) gọi là **khung xương của nhân**. Một số sợi neo vào lamina, số khác gắn với những vùng nhất định của chromatin. Khung xương nhân cùng lamina có thể tạo thành một phức hợp giúp **điều chỉnh biểu hiện gen** và **đưa ARN ra tế bào chất**; phức hợp này có thể liên hệ với khung xương tế bào chất và màng tế bào.

## 4. Nhiễm sắc thể

### 4.1. Đại cương

- NST là nơi **tập trung thông tin di truyền** của tế bào và cơ thể.
- NST chỉ thấy rõ **hình thái** dưới kính hiển vi quang học trong phân bào, **từ cuối kỳ đầu đến đầu kỳ cuối**.
- **Số lượng**: tế bào sinh dưỡng có **2n** NST (2 bộ, mỗi bộ n NST khác nhau). Số n **hằng định trong một loài**, khác nhau giữa các loài.
- Ở người: **2n = 46**, tức **23 cặp** = **22 cặp NST thường** + **1 cặp NST giới tính** (nam **XY**, nữ **XX**).

### 4.2. Cấu trúc vi thể (kính hiển vi quang học)

**Ở gian kỳ**, nhuộm nhân thấy chất nhiễm sắc ở nhiều mức:

- **Hạt nhiễm sắc**: hạt nhỏ lấm tấm bắt màu;
- **Khối nhiễm sắc**: hạt lớn hơn;
- **Sợi nhiễm sắc**: sợi dài, mảnh;
- **Lưới nhiễm sắc**: các sợi đan chằng chịt như lưới.

**Ở kỳ giữa**, NST **co ngắn nhất** và nhìn rõ nhất. Mỗi NST (dạng kép) gồm **2 chromatid** nối nhau ở **eo sơ cấp**, gọi là **phần tâm (centromere)**.

![Hình 2. Hình thái nhiễm sắc thể kỳ giữa và ba dạng theo vị trí phần tâm](hinh-thai-nst.svg)

Các bộ phận của NST kỳ giữa:

- **Phần tâm** chia NST thành **nhánh ngắn (p)** và **nhánh dài (q)**.
- **Đầu mút (telomere)**: phần cuối của mỗi chromatid.
- **Vệ tinh (S – satellite)**: núm hình cầu nhỏ đôi khi nối tiếp nhánh p của **NST tâm đầu**.
- **Tâm động (kinetochore)**: cấu trúc **3 lớp**, hình **lòng máng ngắn** ôm lấy phần tâm. Từ hai bên tâm động mọc ra **sợi thoi vô sắc**, nối với sợi thoi từ trung thể khi phân bào.

**Phân loại NST ở người theo vị trí phần tâm:**

| Dạng | Điều kiện | Ghi chú |
|---|---|---|
| **Tâm giữa** | p = q | Hai nhánh bằng nhau |
| **Tâm lệch** | p < q | Nhánh p ngắn hơn rõ |
| **Tâm đầu** | p ≈ 0 | p rất ngắn; có thể mang vệ tinh |

> [!bay] Tâm động ≠ phần tâm trong giáo trình này
> Giáo trình phân biệt hai thuật ngữ:
> - **Phần tâm (centromere)** = eo sơ cấp, chỗ hai chromatid dính nhau, là vùng ADN.
> - **Tâm động (kinetochore)** = phức hợp protein **3 lớp** bám lên phần tâm, là nơi gắn **sợi thoi vô sắc**.
>
> Nhiều sách phổ thông dùng "tâm động" để chỉ centromere. Khi làm bài môn này, bám theo cách gọi của giáo trình.

> [!ung-dung] Nhiễm sắc thể đồ (karyotype)
> Xét nghiệm NST đồ nuôi cấy tế bào (thường là lympho bào máu ngoại vi), **dừng phân bào ở kỳ giữa** rồi nhuộm và xếp NST theo kích thước, vị trí phần tâm. Ứng dụng: chẩn đoán **hội chứng Down** (3 NST 21), Turner (45,X), Klinefelter (47,XXY)… Các NST **tâm đầu** (13, 14, 15, 21, 22) hay tham gia **chuyển đoạn hòa hợp tâm (Robertson)**, một nguyên nhân gây Down có tính gia đình.

> [!yhct] Colchicin — từ cây thuốc đến phòng xét nghiệm NST
> **Colchicin** (từ cây Ngót nghẻo *Gloriosa superba*) giữ tế bào ở **kỳ giữa**, lúc NST co ngắn và rõ nhất, nên được dùng (hoặc dẫn chất colcemid) khi làm NST đồ. Ngót nghẻo **rất độc**, không tự dùng; chi tiết nguồn gốc và độc tính (xem bài *Phân chia tế bào và sự hình thành giao tử ở người*, mã sh-05).

### 4.3. Cấu trúc siêu vi thể (kính hiển vi điện tử)

#### a) Khung xương nhiễm sắc thể

Khi **phân hủy histon** và **tiêu ADN bằng ADNase**, người ta thấy còn lại một **khung xương protein** có hình dạng giống NST kỳ giữa. **Paulson và Laemmli (1977)**: khung gồm **2 protein khung** có khối lượng phân tử rất cao (**180 kDa**), liên kết với nhau nhờ **ion Cu** ở nồng độ rất thấp (**10^-8^ M**).

Khi chỉ tiêu hủy histon, thấy rõ cấu trúc chung:

- Mỗi chromatid chứa **một phân tử ADN liên tục**, dài **0,5–2,5 × 10^8^ cặp base**.
- ADN tạo thành những **vòng dài 10–90 kb**; chân vòng tiếp xúc với protein khung.
- ADN của các vòng cùng histon tạo thành nucleosom, giống sợi chromatin ở gian kỳ.

> [!cap-nhat] Protein khung NST
> Giáo trình nêu 2 protein khung khoảng 180 kDa. Hiện nay đã biết hai protein chính của khung NST kỳ giữa là **topoisomerase II** và **condensin** (phức hợp SMC). Topoisomerase II là đích tác dụng của một số thuốc chống ung thư (etoposid, doxorubicin).

#### b) Các mức cuộn xoắn của sợi chromatin

![Hình 3. Các mức cuộn xoắn từ phân tử ADN đến nhiễm sắc thể kỳ giữa](cac-muc-xoan.svg)

| Mức | Cấu trúc | Đường kính |
|---|---|---|
| 1 | Chuỗi xoắn kép ADN | ≈ 2 nm |
| 2 | **Chuỗi hạt**: nucleosom nối nhau bằng ADN nối (ADN tự do) | **≈ 10 nm** |
| 3 | Chuỗi hạt **cuộn xoắn cấp thấp nhất** | **30 nm** |
| 4 | Sợi chromatin xoắn tiếp cấp cao, tạo **múi vi thể chromatin** (microconvules) bám quanh khung xương NST | — |
| 5 | NST kỳ giữa | co ngắn tối đa |

*Vì sao phải xoắn nhiều cấp?* ADN của một tế bào người (6 × 10^9^ cặp nu) nếu duỗi thẳng dài khoảng 2 m, trong khi nhân chỉ vài µm. Xoắn nhiều cấp giúp **nén gọn** ADN, **tránh rối và đứt** khi chia đều cho hai tế bào con.

> [!cap-nhat] Sợi 30 nm và tổ chức 3 chiều của bộ gen
> - Sợi 30 nm thấy rõ khi tách chromatin trong ống nghiệm (và trong nhân hồng cầu gà). Khi chụp chromatin **ngay trong nhân** (tế bào được cố định, không tách chiết), ví dụ kỹ thuật **ChromEMT** (Ou và cs., *Science* 2017), người ta thấy chromatin là chuỗi nucleosom **gấp khúc không đều, đường kính ≈ 5–24 nm**, kể cả trong NST kỳ giữa; sợi 30 nm đều đặn dường như **không phổ biến**. Vấn đề **còn đang tranh luận**; đi thi vẫn trả lời theo mô hình của giáo trình.
> - *(Bổ sung – kiến thức hiện nay)* Kỹ thuật **Hi-C** (2009) cho thấy trong nhân gian kỳ, mỗi NST chiếm một **lãnh thổ** riêng; chromatin chia thành **ngăn A** (hoạt động, nằm phía trong) và **ngăn B** (bất hoạt, hay áp sát lamina); ở mức nhỏ hơn là các **miền liên kết topo (TAD)** dài khoảng hàng trăm kb đến 1–2 Mb, trong đó các đoạn ADN tiếp xúc với nhau nhiều hơn với bên ngoài. Vòng và TAD được tạo nhờ phức hợp **cohesin "đùn vòng"** ADN cho đến khi gặp protein ranh giới **CTCF**. Khi ranh giới TAD bị phá (do mất đoạn, đảo đoạn), một gen có thể bị "bật" sai chỗ và gây bệnh, ví dụ một số **dị tật chi bẩm sinh**. Ý này gần với "vòng ADN 10–90 kb bám khung protein" mà giáo trình mô tả.

#### c) Thành phần hóa học của chromatin

**Chromatin** = phức hợp **ADN + protein histon + protein không histon** của tế bào Eukaryota.

| Thành phần | Số lượng | Liên kết với ADN |
|---|---|---|
| **ADN** | Phần lớn | — |
| **Histon** | Rất nhiều | **Thường xuyên** |
| **HMG** (High Mobility Group) | Nhiều | **Không** thường xuyên |
| Protein thiểu số (enzym, cấu trúc, điều chỉnh, tương tác protein–protein) | Rất ít (vài bản sao/tế bào), hàng trăm loại | Chức năng chưa rõ hết |

**Histon:**

- Protein nhỏ (**11–28 kDa**), rất giàu acid amin (amino acid) **tích điện dương** (**lysin, arginin**), có tính **kiềm** (pH > 10).
- *Vì sao histon bám chặt ADN?* ADN tích điện **âm** (nhóm phosphat), histon tích điện **dương** → hút tĩnh điện.
- Có **5 loại**, chia **2 nhóm**:

| | Histon nucleosom | Histon H1 |
|---|---|---|
| Gồm | H2A, H2B, H3, H4 | H1 |
| Kích thước | 102–135 acid amin | ~220 acid amin (lớn hơn) |
| Tính bảo thủ | **Cao**; H3, H4 bảo thủ nhất | **Thấp hơn** |
| Vị trí | Tạo **lõi** nucleosom | **Bên ngoài** nucleosom, nối 2 nucleosom liền nhau |
| Vai trò | Quấn ADN | **Kết đặc** sợi chromatin |

#### d) Nucleosom

- Lõi histon hình **đĩa dày hai mặt lồi**, đường kính **11 nm**, gồm **8 phân tử**: **2 H2A + 2 H2B + 2 H3 + 2 H4**.
- Bên ngoài quấn một đoạn ADN dài **146 cặp nucleotid**.
- Tương tác ADN–histon chủ yếu do **H3 và H4**.
- ADN nối giữa hai nucleosom dài **0–80 cặp nu**; trung bình cứ **~200 cặp nu** lặp lại 1 nucleosom.

> [!cap-nhat] Nucleosom và "mã histon" (bổ sung – kiến thức hiện nay)
> - Cấu trúc tinh thể của nucleosom (1997) cho thấy ADN quấn **khoảng 1,65 vòng** quanh lõi; các nghiên cứu ghi **146–147 cặp nu** (giáo trình: 146). ADN nối thường dài khoảng **10–80 cặp nu**.
> - Đuôi đầu N của histon nhô ra ngoài nucleosom và bị **biến đổi hóa học**: **acetyl hóa** (trung hòa điện tích dương → ADN lỏng ra, gen dễ phiên mã), **methyl hóa** (tùy vị trí: bật hoặc tắt gen), phosphoryl hóa… Cùng với **methyl hóa ADN** ở các đảo CpG, đây là cơ sở của **biểu sinh (epigenetics)**: thay đổi biểu hiện gen mà không đổi trình tự ADN. Một số thuốc ung thư nhắm vào các enzym này (ví dụ thuốc ức chế histon deacetylase, thuốc giảm methyl hóa ADN).
> - Ở phần tâm, histon H3 được thay bằng biến thể **CENP-A** — "dấu hiệu" để tâm động (kinetochore) biết chỗ lắp ráp.

> [!vi-du] Bài toán nucleosom (giáo trình)
> - 1 gen Eukaryota ~10 000 cặp nu ÷ 200 = **50 nucleosom**.
> - 1 tế bào người có 6 × 10^9^ cặp nu ÷ 200 = **3 × 10^7^ nucleosom**.

**Histon H1⁰** (H1 "zero"):

- Chỉ có ở tế bào **nghỉ, không phân bào**.
- **Thiếu H1⁰ thì tế bào phân chia.** Khi tế bào ngừng phân chia (tự nhiên hoặc do tác nhân), H1⁰ **xuất hiện**, đồng thời lượng **H1 giảm**.

#### e) Protein HMG

- Có ở mọi cơ quan, mọi Eukaryota; số lượng lớn (khoảng **10^6^ bản sao/nhân**).
- **4 loại chính**: HMG1, HMG2, HMG14, HMG17.
- Gen HMG14 và HMG17 đã được tạo dòng (clon hóa) ở người; mỗi gen có **20–50 bản sao** trong bộ gen, **không có intron** (giống gen histon).
- **Mỗi nucleosom có 2 vị trí bám** cho HMG.

> [!cap-nhat] Tên gọi HMG hiện nay
> Theo danh pháp hiện hành, **HMG1, HMG2** nay gọi là **HMGB1, HMGB2**; **HMG14, HMG17** gọi là **HMGN1, HMGN2**. HMGB1 chủ yếu nằm trong nhân, uốn cong ADN; khi tế bào bị hoại tử, HMGB1 thoát ra ngoài và trở thành **tín hiệu báo động viêm** (DAMP). Giáo trình ghi HMG1, 2 "gian kỳ chủ yếu ở tế bào chất" — đi thi theo giáo trình.

| | HMG1, HMG2 | HMG14, HMG17 |
|---|---|---|
| Khối lượng | Nặng hơn: **28 000–30 000 Da** | Nhẹ hơn: **12 000–14 000 Da** |
| Vị trí | Gian kỳ chủ yếu ở **tế bào chất**, vào nhân ở **pha S** | **Luôn ở trong nhân** |
| Vai trò | **Nhân đôi và phiên mã** | **Liên kết các nucleosom** |

#### f) Sự hình thành sợi chromatin

- Sợi chromatin hình thành ở **pha S** (khi ADN nhân đôi).
- Phần lớn histon được tổng hợp ở pha S trong tế bào chất, đi ngay vào nhân để cùng **ADN mới** tạo sợi chromatin.
- Khi khung xương NST hình thành, sợi chromatin **xoắn nhiều cấp**, **luôn chỉ xoắn với chính nó** (không xoắn lẫn sợi khác), cuối cùng tạo các **múi vi thể chromatin** quanh lõi khung protein.

> [!bay]
> Giáo trình viết "pha S của sự phân bào". Cần hiểu đúng: pha S thuộc **gian kỳ** (giai đoạn chuẩn bị), không phải trong quá trình nguyên phân.

### 4.4. Dị nhiễm sắc và nhiễm sắc thực

| | **Dị nhiễm sắc** (heterochromatin) | **Nhiễm sắc thực** (euchromatin) |
|---|---|---|
| Tỷ lệ (giáo trình) | ~**80%** ADN của nhân | phần còn lại |
| Trạng thái | Vẫn **kết đặc** sau phân bào | Duỗi xoắn |
| Hoạt động | **Không phiên mã** | **Có phiên mã** mARN, tARN |
| Đặc điểm | Rất ít ARN, **giàu histon H1** | ADN **không lặp lại** |

Dị nhiễm sắc gồm **2 loại**:

- **Dị nhiễm sắc cấu trúc** (constitutive): ở người khu trú tại **phần tâm** mỗi NST; phần lớn chứa **ADN lặp lại đơn giản** (**ADN satellite**), không phiên mã.
- **Dị nhiễm sắc ngẫu nhiên** (facultative): những vùng ADN khác kết đặc ngẫu nhiên ở gian kỳ; **không** có ADN lặp lại đơn giản, cũng không phiên mã; số lượng thay đổi nhiều tùy loại tế bào.

*Vì sao kết đặc thì không phiên mã?* ADN bị nén chặt quanh histon (nhiều H1) nên ARN polymerase và protein điều chỉnh không tiếp cận được.

> [!ung-dung] Vật thể Barr — dị nhiễm sắc ngẫu nhiên
> Ở nữ, một trong hai NST X bị bất hoạt và kết đặc thành **vật thể Barr** (thấy được trong nhân tế bào niêm mạc miệng). Đây là ví dụ kinh điển của dị nhiễm sắc ngẫu nhiên. Số vật thể Barr = số NST X − 1, nên từng được dùng để sàng lọc nhanh Turner (45,X: 0 vật thể) hoặc Klinefelter (47,XXY: 1 vật thể).

> [!cap-nhat] Telomere và telomerase — Nobel Y học 2009 (bổ sung – kiến thức hiện nay)
> - **Telomere** ở người là đoạn lặp **TTAGGG** nối tiếp hàng nghìn lần (dài khoảng **5–15 kb**), cùng phức hợp protein **shelterin** bọc đầu mút, giúp tế bào **không nhận nhầm** đầu NST là chỗ ADN bị đứt.
> - ADN polymerase không sao chép được tận cùng đầu mút, nên mỗi lần phân bào telomere **ngắn đi một ít**. Khi quá ngắn, tế bào ngừng phân chia vĩnh viễn (lão hóa tế bào) — giải thích **giới hạn Hayflick** (tế bào người nuôi cấy chỉ chia được vài chục lần).
> - **Telomerase** là enzym mang sẵn khuôn ARN, **kéo dài telomere** (một dạng phiên mã ngược). Có ở tế bào mầm sinh dục, tế bào gốc; bị tắt ở phần lớn tế bào sinh dưỡng; **được bật lại ở khoảng 85% ung thư** (phần còn lại dùng cơ chế ALT), giúp tế bào ung thư phân chia vô hạn.
> - Blackburn, Greider, Szostak nhận **giải Nobel Y học 2009** cho phát hiện này. Đột biến gen telomerase gây nhóm **bệnh telomere** (ví dụ loạn sừng bẩm sinh, xơ phổi, suy tủy).

**Bộ gen:**

- Mỗi NST (mỗi chromatid) được cấu tạo bởi **một phân tử ADN**. Toàn bộ thông tin di truyền trong các NST của cơ thể tạo thành **bộ gen**.
- *E. coli*: **4,7 × 10^6^ cặp nu**, trong **1 phân tử ADN** (1 NST).
- Người: khoảng **3 × 10^9^ cặp nu** trong **24 loại NST** (22 thường + X + Y) = **24 loại phân tử ADN**.
- Cơ thể lưỡng bội có **2 bản sao** mỗi loại NST, một từ mẹ, một từ bố → một tế bào người có **46 NST**, khoảng **6 × 10^9^ cặp nu**.

> [!cap-nhat] Bộ gen người theo số liệu hiện nay (bổ sung – kiến thức hiện nay)
> - Bản giải trình tự **hoàn chỉnh từ đầu mút đến đầu mút (T2T-CHM13)** công bố năm **2022** (tạp chí *Science*) lấp nốt khoảng 8% bộ gen còn thiếu từ Dự án Bộ gen người (2003): bộ gen đơn bội dài **≈ 3,05 × 10^9^ cặp nu** — vẫn khớp con số "khoảng 3 × 10^9^" của giáo trình. Phần mới giải chủ yếu là **ADN lặp** ở phần tâm, nhánh ngắn các NST tâm đầu (chứa gen rARN) — đúng những vùng dị nhiễm sắc học ở trên.
> - Số **gen mã hóa protein** chỉ khoảng **19.000–20.000** (GENCODE ≈ 19.400), chiếm **chưa tới 2%** bộ gen; phần lớn còn lại là trình tự điều hòa, gen ARN không mã hóa, ADN lặp.
> - *E. coli* K-12: ≈ 4,6 × 10^6^ cặp nu (giáo trình ghi 4,7 × 10^6^).

> [!bay]
> - **3 × 10^9^** cặp nu = bộ gen **đơn bội** (24 loại NST). **6 × 10^9^** = một tế bào **lưỡng bội** (46 NST).
> - Bộ gen người có **24** loại phân tử ADN (vì X và Y khác nhau), không phải 23.

## 5. Hạch nhân

- Dưới KHV quang học: **hình cầu**, kích thước lớn, là cấu trúc **rõ nhất** của nhân ở gian kỳ; **không có lúc phân bào**.
- Dưới KHV điện tử: **không có màng bao** (khác các bào quan trong tế bào chất).
- Kích thước thay đổi nhiều theo loại tế bào và **mức hoạt động** (tế bào tổng hợp protein mạnh có hạch nhân to).

**Ba vùng của hạch nhân (KHV điện tử):**

| Vùng | Chứa |
|---|---|
| Vùng sợi **ít kết đặc** | ADN **không** hoạt động phiên mã |
| Vùng sợi **kết đặc** | Phân tử **ARN** đang được tạo ra trong phiên mã |
| Vùng **hạt** | Từ ribosom **tiền thân** đến ribosom **trưởng thành** |

**Hạch nhân trong chu kỳ tế bào:**

1. Chuẩn bị phân bào: hạch nhân **nhỏ dần**.
2. **Kỳ giữa**: hạch nhân **biến mất**, tổng hợp ARN ngừng.
3. **Kỳ cuối**: tổng hợp rARN bắt đầu lại, hạch nhân xuất hiện lại **rất nhỏ**, nằm trên các NST mang **gen rARN**.
4. Sau phân bào: các hạch nhân nhỏ **lớn lên và hợp lại** thành một hạch nhân lớn điển hình ở gian kỳ.

**Ở người:**

- Gen rARN nằm **gần đầu mút** của **5 cặp NST: 13, 14, 15, 21, 22** → **10 NST** trong tế bào lưỡng bội → **10 hạch nhân nhỏ** lúc đầu.
- Vùng mang gen rARN gọi là **vùng tổ chức hạch nhân (NOR)**.
- Riêng gen **rARN 5S** nằm ở **cuối nhánh dài NST số 1**, **không** tập trung ở hạch nhân.
- Tại hạch nhân, **protein từ tế bào chất** đi vào, gặp **rARN mới tạo**, lắp ráp thành **tiểu đơn vị lớn và nhỏ** của ribosom; các tiểu đơn vị này đi qua **lỗ màng nhân** ra tế bào chất.

*Vì sao hạch nhân biến mất ở kỳ giữa?* Khi NST co xoắn tối đa, gen rARN ngừng phiên mã; không còn rARN mới để lắp ráp nên cấu trúc hạch nhân tan đi.

> [!cap-nhat] Hạch nhân — "giọt lỏng" không có màng
> - Thực tế hạch nhân tan rã từ **cuối kỳ đầu** (cùng lúc màng nhân tan), nên đến kỳ giữa đã không còn thấy; giáo trình viết gọn là "kỳ giữa".
> - Ba vùng của giáo trình nay gọi là **trung tâm sợi (FC)**, **vùng sợi đặc (DFC)** và **vùng hạt (GC)**. Hạch nhân không cần màng vì nó hình thành theo kiểu **tách pha lỏng – lỏng** (như giọt dầu trong nước): protein và ARN tự tụ lại thành giọt đặc, trao đổi liên tục với dịch nhân (bổ sung – kiến thức hiện nay).

> [!bay]
> - 5 NST mang gen rARN (13, 14, 15, 21, 22) đều là **NST tâm đầu** — trùng với các NST có **vệ tinh**. NOR nằm ở cuống vệ tinh trên nhánh p.
> - Giáo trình viết NOR là "Nuclear Organization Region"; tên chuẩn là **Nucleolus Organizer Region** (vùng tổ chức **hạch nhân**). NOR là một **vùng trên NST**, không phải bản thân hạch nhân.

## 6. Chức năng chung của nhân tế bào

Nhân chứa vật liệu di truyền, quyết định tính di truyền của tế bào và cơ thể:

- **Cần thiết cho sự sống** của tế bào (tế bào mất nhân như hồng cầu không phân chia được và có đời sống giới hạn).
- **Mang toàn bộ thông tin di truyền** dưới dạng ADN, **trừ** phần thông tin trong **ADN ty thể**.

> [!ung-dung] Kháng thể kháng nhân (ANA)
> Trong một số bệnh tự miễn, cơ thể tạo kháng thể chống lại chính thành phần của nhân: **ANA** dương tính ở hầu hết bệnh nhân **lupus ban đỏ hệ thống**; kháng thể **kháng ADN sợi kép** khá đặc hiệu cho lupus; kháng thể **kháng histon** gặp trong **lupus do thuốc** (hydralazin, procainamid…).

## Tóm tắt

| Thành phần | Điểm cốt lõi |
|---|---|
| Hình dạng – số lượng | Theo hình tế bào (có ngoại lệ: bạch cầu hạt); gan 2 nhân ~15%; cộng bào ≠ hợp bào; hồng cầu có vú không nhân |
| Màng nhân ngoài | Có ribosom, nối lưới nội sinh chất; hóa học giống lưới nhẵn (cholesterol 10%); tạo màng mới |
| Khoảng quanh nhân | 10–15 nm, thông lòng lưới nội sinh chất có hạt |
| Màng nhân trong + lamina | Lamina 10–20 nm, mắt cáo vuông, sợi trung gian lamin A, B, C; đỡ màng, neo chromatin |
| Lỗ màng nhân | 8 cạnh, 3 vòng hạt; kênh 9 × 15 nm; 3000–4000 lỗ/tế bào có vú; protein vào – ARN, tiểu đơn vị ribosom ra; snARN hai chiều |
| Dịch nhân | Histon, ADN/ARN polymerase, protein điều chỉnh gen; khung xương nhân có actin |
| NST vi thể | 2n = 46; 2 chromatid, phần tâm, p/q, telomere, vệ tinh, kinetochore 3 lớp; tâm giữa – lệch – đầu |
| NST siêu vi thể | Khung 2 protein 180 kDa (nối nhờ ion Cu); vòng 10–90 kb; 10 nm → 30 nm → múi vi thể |
| Nucleosom | Lõi 8 histon (2 × H2A, H2B, H3, H4), 11 nm, 146 cặp nu; lặp ~200 cặp; H1 ở ngoài, kết đặc |
| HMG | 10^6^ bản sao; HMG1, 2 (nặng, nhân đôi – phiên mã); HMG14, 17 (nhẹ, luôn trong nhân, nối nucleosom) |
| Dị nhiễm sắc / nhiễm sắc thực | 80% / còn lại; kết đặc, không phiên mã, giàu H1 / phiên mã; dị NS cấu trúc ở phần tâm (ADN satellite) |
| Hạch nhân | Không màng; 3 vùng; biến mất kỳ giữa; NOR trên NST 13, 14, 15, 21, 22; rARN 5S ở NST 1 |
| Chức năng nhân | Cần cho sự sống; mang toàn bộ thông tin di truyền trừ ADN ty thể |
