---
title: Sự vận động của tế bào
thoi-gian: 25 phút
muc-tieu:
- Trình bày được trạng thái lý học của nguyên sinh chất (hệ keo, nhũ tương, chuyển hóa sol – gel, độ nhớt) làm nền cho sự vận động.
- Mô tả được sự vận động của tế bào chất (dòng nội chất), của bào quan và của nhân.
- Nêu và giải thích được ba hình thức di động của tế bào: bằng chân giả, bằng lông – roi, và sự co duỗi của tế bào cơ.
- Mô tả được cấu tạo 9 + 2 của lông, roi và vai trò của cánh tay dynein, ATP, Ca^2+^.
- Nêu được cơ sở của hệ thống kết dính tế bào và liên hệ được với một số bệnh lý.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Nguyên sinh chất là một **hệ keo**: chuyển qua lại giữa **sol** (lỏng) và **gel** (đặc). Độ nhớt gấp **40–50 lần nước**.
> 2. Trong tế bào luôn có **dòng nội chất** chảy vòng; bào quan trôi theo dòng hoặc tự di chuyển; nhân tự quay.
> 3. **Chân giả** (amip, bạch cầu): nội chất sol chảy về phía trước, đầu chân giả hóa gel làm điểm tựa; động cơ là **sợi actin** trùng hợp – giải trùng hợp.
> 4. **Lông, roi**: lõi **9 + 2** ống vi thể; **dynein** dùng ATP làm các đôi ống trượt lên nhau → lông uốn cong. Gốc là **thể đáy** cấu trúc giống trung tử (9 + 0, bộ ba).
> 5. **Tế bào cơ**: actin trượt trên myozin, cần **ATP**; **Ca^2+^ gắn troponin** → tropomyozin dịch ra → lộ vị trí gắn → cơ co.

## 1. Trạng thái lý học của nguyên sinh chất

Muốn hiểu tế bào "chuyển động" được, trước hết phải biết khối chất bên trong nó ở trạng thái nào. Nguyên sinh chất gồm nước, chất vô cơ, chất hữu cơ… Khi các chất này kết hợp với nước, chúng tạo ra nhiều trạng thái vật lý khác nhau. Nhìn chung, nguyên sinh chất mang tính chất của một **hệ keo** (Giáo trình tr. 58).

### 1.1. Các dạng dung dịch của nguyên sinh chất

**Nhũ tương.** Các chất không tan trong nước (dầu, mỡ) bị chia thành những giọt rất nhỏ lơ lửng trong nước, gọi là nhũ tương. Nhũ tương trong nguyên sinh chất là **nhũ tương bền**.

- *Vì sao bền?* Trong nguyên sinh chất có nhiều chất keo, nhất là **protein và phospholipid**. Chúng hấp phụ mạnh lên bề mặt các giọt, như một lớp áo bọc. Lớp áo này ngăn các giọt chạm vào nhau và gộp lại. Nhờ vậy các vật thể cứ phân tán, lơ lửng.

**Dung dịch keo.** Ở điều kiện bình thường, dung dịch keo khá bền; để yên các hạt keo cũng không lắng.

- *Vì sao không lắng?* Các hạt keo **mang điện tích cùng dấu**, nên chúng đẩy nhau và luôn tách rời trong nước.
- **Hiện tượng đông tụ:** khi điện tích bề mặt hạt bị giảm (ví dụ thêm **chất điện ly**), lực đẩy mất đi, hạt dính lại rồi kết tủa. Hiện tượng này thấy được ở cả tế bào sống lẫn tế bào chết khi gặp **chất định hình**.
- **Chuyển động Brown** (giáo trình viết "Brow"): các hạt keo chuyển động hỗn loạn vì bị phân tử dung môi va đập và va vào nhau.

> [!ung-dung] Định hình tiêu bản
> Trong xét nghiệm giải phẫu bệnh, mảnh sinh thiết được ngâm ngay vào **chất định hình** (thường là formol 10%, cồn…). Chất định hình "đóng băng" cấu trúc tế bào ở đúng trạng thái lúc lấy mẫu, không cho mô tự hủy. Cồn làm protein **đông tụ** đúng như hiện tượng đông tụ keo ở trên; formol thì chủ yếu tạo **liên kết chéo** giữa các protein, nhưng mục đích giống nhau.

### 1.2. Tính chất chuyển hóa sol – gel

| Trạng thái | Đặc điểm |
|---|---|
| **Sol** | Dung dịch keo ở dạng **lỏng**; các hạt keo phân tán tự do trong nước |
| **Gel** | Dạng **đặc hơn**, tương đối rắn và **co giãn được**; hạt keo liên kết thành mạng giữ nước bên trong |

Dưới tác động của một số yếu tố lý hóa, sol có thể chuyển thành gel.

- **Chuyển hóa một chiều**: đã thành gel thì không quay lại sol được. Ví dụ của sách: **lòng trắng trứng** khi đun nóng; **huyết tương đông lại** trong phản ứng đông máu.
- Trong tế bào sống, chuyển hóa sol ⇌ gel còn có thể xảy ra **hai chiều**, liên tục. Đây là cơ sở của di động bằng chân giả (mục 3.1).

> [!yhct] Cao động vật: một ví dụ sol – gel hai chiều quen thuộc
> Phần tạo keo của **A giao, Quy bản giao, Cao ban long (Lộc giác giao)** chủ yếu là **gelatin** (collagen của da, xương, sừng bị thủy phân khi nấu lâu). Khi cô cao nóng, gelatin ở dạng **sol** lỏng; để nguội, nó đông thành **gel** dẻo, đổ khuôn cắt miếng được. Khi dùng, miếng cao lại tan chảy trong nước nóng, tức là gel trở về sol. Ngược lại, protein bị **đun đến biến tính** như lòng trắng trứng thì chỉ đi một chiều. Đây là liên hệ về mặt lý hóa của chất keo, không nói gì về tác dụng điều trị (hóa học collagen – gelatin và mức bằng chứng: xem bài *Amin, amid, amino acid*, mã hc-10).

### 1.3. Độ nhớt của nguyên sinh chất

**Cách đo:**
- Theo dõi **tốc độ lắng** khi ly tâm của các vật thể trong tế bào (hạt mỡ, hạt tinh bột, lục lạp) hoặc của hạt kim loại nhỏ đưa vào tế bào.
- Quan sát **chuyển động Brown** và sự chuyển động tự nhiên của vật thể trong tế bào chất (ví dụ lục lạp ở tế bào thực vật).

**Số liệu cần nhớ:** độ nhớt nguyên sinh chất **lớn gấp 40–50 lần nước**.

Độ nhớt **thay đổi theo trạng thái sinh lý**:

| Tình trạng tế bào | Độ nhớt |
|---|---|
| Tăng cường hoạt động, **đang phân chia** | **Tăng** |
| Giảm hoạt động, bị **thuốc mê** ức chế | **Giảm** |

> [!bay]
> Dễ nhớ ngược. Tế bào "hăng hái" (hoạt động mạnh, phân chia) thì nguyên sinh chất **đặc lại** (độ nhớt tăng); bị thuốc mê ức chế thì **loãng ra** (độ nhớt giảm).

## 2. Sự vận động của tế bào chất và của nhân

**Dòng nội chất.** Trong tế bào có sự tuần hoàn liên tục của tế bào chất, gọi là **dòng nội chất**. Dòng này thấy rõ nhất ở vùng **nội chất** (lớp tế bào chất phía trong, lỏng hơn). Nó giúp phân phối chất dinh dưỡng, bào quan khắp tế bào.

| Yếu tố | Ảnh hưởng tới dòng nội chất |
|---|---|
| Ánh sáng, nhiệt độ (yếu tố vật lý) | Có thể làm **tăng** tốc độ |
| Môi trường **nhiều oxy** | **Tăng** vận động |
| **Ête, chloroform** | **Giảm**, thậm chí **làm liệt** vận động |
| Tuổi tế bào | Non: **chậm** → trưởng thành: **nhanh nhất** → già: lại **rất chậm** |

**Bào quan** hoặc trôi theo dòng nội chất, hoặc có cách vận động riêng:

- **Ty thể** di động kiểu **lượn sóng**, đi từ nơi cần ít năng lượng đến nơi cần **nhiều năng lượng**. *Vì sao hợp lý?* Ty thể là "nhà máy ATP", nên nó tập trung ở chỗ tiêu thụ ATP.
- **Lục lạp** (tế bào thực vật) bị kéo theo dòng nội chất; ngoài ra còn chịu tác động của **ánh sáng**.

**Cơ sở:** vận động của tế bào chất gắn với hoạt động của **bộ xương tế bào**: hệ thống **ống vi thể, sợi vi thể và sợi trung gian**.

> [!cap-nhat] Protein vận động: "xe tải" chạy trên bộ xương tế bào (bổ sung – kiến thức hiện nay)
> Bào quan không chỉ trôi theo dòng. Phần lớn được **chở có định hướng** bởi các **protein vận động** dùng ATP: **kinesin** thường chở hàng ra **ngoại vi** tế bào dọc ống vi thể, **dynein bào tương** chở hàng vào **trung tâm** (về phía nhân), còn **myozin** chạy trên sợi actin. Ví dụ rõ nhất là **vận chuyển dọc sợi trục** thần kinh (dài tới 1 m): túi chất dẫn truyền, ty thể được kinesin chở từ thân nơron ra tận cúc tận cùng. Hỏng bộ máy này góp phần gây một số bệnh thần kinh di truyền (nguồn: Alberts, Molecular Biology of the Cell 7th ed., 2022).

**Nhân** cũng có vận động riêng: nhân **tự quay liên tục**, nên bề mặt nhân lần lượt tiếp xúc với nhiều vùng khác nhau của tế bào chất.

> [!vi-du] Ty thể "đi tới nơi cần năng lượng"
> Ở tinh trùng, ty thể xếp xoắn quanh **đoạn giữa** (ngay sau đầu), sát gốc đuôi, nơi dynein tiêu thụ nhiều ATP nhất. Ở tế bào cơ, ty thể nằm xen giữa các tơ cơ.

## 3. Sự di động của tế bào

Sách chia ba hình thức: bằng **chân giả**, bằng **lông – roi**, và **co duỗi của tế bào cơ**.

| | Chân giả | Lông, roi | Tế bào cơ |
|---|---|---|---|
| Ví dụ | Amip, **bạch cầu**, nguyên bào sợi nuôi cấy | Động vật đơn bào, **tinh trùng**, biểu mô có lông | Cơ vân, cơ trơn, cơ tim |
| Bộ máy | **Sợi actin** (+ chuyển sol ⇌ gel) | **Ống vi thể** 9 + 2 + **dynein** | **Actin + myozin** (+ troponin, tropomyozin) |
| Năng lượng, điều hòa | ATP | **ATP**, Ca^2+^ | **ATP**, **Ca^2+^** |

### 3.1. Di động theo lối chân giả

**Ở amip:** tế bào thò ra một chỗ lồi gọi là **chân giả**. Đi từ ngoài vào, phần trước của chân giả gồm:

1. **Màng sinh chất** mỏng;
2. **Ngoại chất** (ngoại sinh chất): tương đối **đặc** (gel);
3. **Nội chất** (nội sinh chất): **lỏng** hơn (sol), chảy dồn về phía chân giả.

Nội chất dồn tới đâu, tế bào tiến theo hướng đó.

![Hình 1. Di động bằng chân giả theo cơ chế sol – gel (sơ đồ)](chan-gia.svg)

**Giải thích theo sol – gel:** khi tế bào chất lồi về một phía và gặp giá thể rắn, tại đó sol chuyển thành **gel** đặc hơn. Chỗ gel này là **điểm tựa** để cả tế bào kéo tới vị trí mới. Rồi quá trình lặp lại: sol chảy tới, hóa gel, tựa, kéo…

**Vai trò của sợi actin:** sự chuyển đổi sol ⇌ gel do hệ thống **sợi actin** thực hiện. Sợi actin **trùng hợp** (nối dài) rồi **giải trùng hợp** (tháo rời) theo chu kỳ, làm hệ sợi căng – chùng có nhịp. Ví dụ của sách: **nguyên bào sợi** (fibroblast) **trườn** trên bề mặt đĩa nuôi cấy, nhờ các sợi actin liên kết với protein nối vào giá thể.

**Ở bạch cầu:** bạch cầu thò chân giả, **lách giữa hai tế bào nội mô** để chui qua thành mạch ra mô (gọi là **xuyên mạch**, diapedesis).

> [!ung-dung] Bạch cầu: xuyên mạch và thực bào
> - Khi mô bị viêm hoặc nhiễm khuẩn, bạch cầu trung tính và bạch cầu mono được các chất hóa học từ ổ viêm "gọi" tới (**hóa ứng động**). Chúng bám vào nội mô, thò chân giả lách ra ngoài mạch, rồi bò đến ổ viêm. Kết quả là **mủ** (xác bạch cầu + vi khuẩn).
> - Khi tới nơi, bạch cầu lại dùng chân giả **ôm lấy vi khuẩn** rồi nuốt vào (**thực bào**). Cùng bộ máy actin vừa để đi vừa để "ăn".
> - Amip gây bệnh lỵ (*Entamoeba histolytica*) cũng di động bằng chân giả và có thể ăn hồng cầu; nhờ đó xét nghiệm phân thấy "amip ăn hồng cầu".

> [!cap-nhat] Cơ chế chân giả hiện nay
> Giáo trình giải thích chủ yếu bằng chuyển đổi sol – gel. Hiện nay mô tả chi tiết hơn: ở **mép trước**, actin trùng hợp nhanh và **đẩy màng** lồi ra (chân giả dẹt, chân giả sợi); tế bào **bám** vào giá thể nhờ protein xuyên màng **integrin**; ở **phía sau**, **myozin II** co kéo actin làm đuôi co lại và rời giá thể. "Sol – gel" vẫn đúng ở mức mô tả: mạng actin dày đặc chính là trạng thái gel. Đi thi trả lời theo sách.

### 3.2. Di động bằng lông, roi

**Lông** (cilia) và **roi** (flagella) có **cùng cấu tạo và cùng cơ chế** chuyển động. Khác nhau chủ yếu ở chỗ: **roi dài hơn**, số lượng ít; lông ngắn, thường rất nhiều.

#### 3.2.1. Cấu tạo của lông, roi

- Hình **trụ**, đường kính khoảng **0,2 µm**.
- **Vỏ**: chính là **màng sinh chất** kéo dài ra.
- **Lõi** (sợi trục, axonem): các **ống vi thể** xếp song song, gồm **9 đôi ngoại vi** quanh **1 đôi trung tâm** → **mô hình 9 + 2** (sách ghi có tác giả gọi là 9 + 1).
- Cấu trúc 9 + 2 chạy suốt chiều dài lông, roi, **trừ phần gốc**.
- Ở gốc là **thể gốc** (thể đáy, basal body), cấu trúc **gần giống trung tử (9 + 0)**: 9 **bộ ba** ống vi thể, không có đôi trung tâm. Thể gốc còn là nơi **tái sinh** lông, roi.

![Hình 2. Mặt cắt ngang sợi trục lông/roi (9 + 2) và thể đáy (9 × 3)](long-roi-9-2.svg)

> [!bay]
> - **9 + 2** là ở **thân** lông, roi. **9 + 0** (9 bộ ba) là ở **thể gốc** và **trung tử**. Đề hay đảo hai cái này.
> - "9" là **9 đôi** ở sợi trục (tức 18 ống ngoại vi), nhưng là **9 bộ ba** ở thể gốc (27 ống).
> - Màng của lông là **màng sinh chất**, không phải một lớp màng riêng.

#### 3.2.2. Lông, roi ở vi khuẩn

Theo giáo trình:

| | Lông vi khuẩn | Roi vi khuẩn |
|---|---|---|
| Chiều dài | 19–20 µm | Dài hơn, tới 150 µm |
| Số lượng / tế bào | Nhiều, có khi tới **300** | Chỉ **1–2** |
| Cấu trúc | **Đơn giản, không theo 9 + 2** | |

Sách cũng ghi **đuôi tinh trùng** được xem như một roi và có cấu tạo giống roi.

> [!cap-nhat] Roi vi khuẩn khác hẳn roi tế bào nhân thực
> Roi vi khuẩn được làm từ protein **flagellin**, không có ống vi thể, không có dynein. Nó **quay** như chân vịt nhờ một "động cơ" cắm ở gốc, chạy bằng dòng ion H^+^ qua màng chứ không bằng ATP. Lông vi khuẩn (pili) chủ yếu để **bám dính**, không để bơi. Các con số chiều dài, số lượng trong sách chỉ để tham khảo. Đuôi **tinh trùng người** là roi của tế bào **nhân thực**, có cấu trúc **9 + 2** (còn có thêm các sợi đặc bọc ngoài). Đi thi: nhớ ý "vi khuẩn không theo 9 + 2" và các số liệu của sách.

#### 3.2.3. Sự di động bằng lông, roi

**Vai trò:**
- Giúp **động vật đơn bào** bơi trong nước.
- Giúp **tinh trùng** bơi ngược dòng trong đường sinh dục.
- Ở các **tế bào biểu mô có lông** lót lòng ống, lông đập nhịp nhàng tạo **dòng chảy** trong lòng ống (đường hô hấp, vòi trứng).

**Cơ chế:**
1. Các đôi ống ngoại vi nối với nhau bằng protein hình "quả đấm" gọi là **cánh tay dynein**.
2. Khi có **ATP** và **Ca^2+^**, cánh tay dynein bám vào đôi ống bên cạnh. Dynein có hoạt tính **ATPase**: nó thủy phân ATP → ADP + P, giải phóng năng lượng.
3. Năng lượng đó làm **các đôi ống ngoại vi trượt lên nhau**.
4. Vì các đôi ống bị neo ở gốc và nối với nhau, chúng không trượt tự do được, nên chuyển động trượt biến thành **uốn cong** cả lông, roi.

=> ATP —(dynein ATPase)→ ADP + P + năng lượng → các đôi ống trượt → lông, roi uốn cong

> [!vi-du] Vì sao "trượt" lại thành "uốn"?
> Thử dán hai thanh thước kẻ chồng lên nhau ở một đầu, rồi đẩy thanh trên trượt về phía đầu dán: hai thanh buộc phải cong. Trong lông, đầu "dán" là thể gốc và các cầu nối (nexin, nan nối). Khi dynein ở các phía khác nhau hoạt động luân phiên, lông đập qua lại.

> [!ung-dung] Khi lông, roi hỏng: hội chứng Kartagener
> **Rối loạn vận động lông nguyên phát** (primary ciliary dyskinesia, PCD) là bệnh di truyền (chủ yếu **lặn trên nhiễm sắc thể thường**), gặp khoảng **1/7.500** người. Hiện đã biết **hơn 50 gen** gây bệnh; hay gặp nhất là các gen mã hóa **cánh tay dynein** (như *DNAH5*, *DNAH11*). Lông và roi vẫn có khung ống vi thể nhưng **thiếu hoặc hỏng cánh tay dynein**, nên **không đập** hoặc đập sai. Hậu quả đi đúng theo các vị trí có lông, roi:
> - **Đường hô hấp**: lông không quét được chất nhầy, gây **viêm xoang mạn, viêm phế quản tái diễn, giãn phế quản**, viêm tai giữa.
> - **Tinh trùng bất động** → **vô sinh nam** (tinh dịch đồ có tinh trùng nhưng không di động).
> - **Vòi trứng**: có thể giảm khả năng sinh sản ở nữ, tăng nguy cơ chửa ngoài tử cung.
> - Khoảng **40–50%** bệnh nhân bị **đảo ngược phủ tạng** (tim bên phải). Khi có bộ ba **viêm xoang + giãn phế quản + đảo ngược phủ tạng** thì gọi là **hội chứng Kartagener**. Lý do: ở phôi sớm, lông chuyển động tạo dòng chảy quyết định bên trái – phải của cơ thể.
>
> Liên hệ thường gặp hơn: **khói thuốc lá** làm liệt và phá hủy lông chuyển của phế quản. Đó là một lý do người hút thuốc ho khạc đờm buổi sáng.

> [!cap-nhat] Lông nguyên phát và nhóm bệnh lông (ciliopathy) (bổ sung – kiến thức hiện nay)
> Giáo trình chỉ nói lông, roi để **vận động**. Hiện nay biết rằng hầu hết tế bào của người (thận, mắt, não, sụn…) còn có **một lông đơn độc, không vận động**, gọi là **lông nguyên phát** (primary cilium). Lõi của nó là **9 + 0** (không có đôi trung tâm, không có cánh tay dynein). Lông nguyên phát hoạt động như một **"ăng-ten" cảm nhận**: mang các thụ thể nhận tín hiệu hóa học, ánh sáng, dòng chảy (ví dụ đường truyền tín hiệu Hedgehog trong phát triển phôi).
> - Bệnh do hỏng lông (vận động hoặc nguyên phát) gọi chung là **bệnh lông** (ciliopathy). Ví dụ: **thận đa nang di truyền trội** (protein polycystin nằm trên lông nguyên phát của ống thận), hội chứng **Bardet–Biedl** (béo phì, thừa ngón, thoái hóa võng mạc, bệnh thận), hội chứng **Joubert** (dị dạng tiểu não). Tế bào que, nón của võng mạc cũng là một dạng lông nguyên phát biến đổi.
> - Bẫy: **9 + 2** là lông **vận động**; **9 + 0** gặp ở **thể đáy, trung tử** và cả ở **lông nguyên phát** (nhưng lông nguyên phát là bộ đôi, thể đáy là bộ ba).
> - Chẩn đoán PCD hiện nay phối hợp: đo **NO mũi** (thấp), quay video tần số – kiểu đập của lông, kính hiển vi điện tử xem cánh tay dynein, và **xét nghiệm gen** (nguồn: MedlinePlus Genetics – Primary ciliary dyskinesia, cập nhật 2024; Alberts, Molecular Biology of the Cell 7th ed., 2022).

> [!yhct] Colchicin: alkaloid tác động lên ống vi thể
> Trong bệnh **gút**, colchicin (có trong cây Ngót nghẻo *Gloriosa superba*) làm **bạch cầu trung tính giảm di chuyển** vào khớp và giảm viêm, vì vận động của bạch cầu cần bộ xương tế bào (ống vi thể). Colchicin **rất độc**, khoảng điều trị hẹp, chỉ dùng thuốc đã chuẩn hóa liều; nguồn gốc và độc tính (xem bài *Phân chia tế bào và sự hình thành giao tử ở người*, mã sh-05).

### 3.3. Sự vận động của tế bào cơ

**Ba loại cơ:**

| Loại | Vị trí | Điều khiển |
|---|---|---|
| **Cơ vân** | Bám xương; co duỗi làm khớp cử động | **Theo ý muốn** |
| **Cơ trơn** | Nội tạng (dạ dày, ruột…) | **Không** theo ý muốn |
| **Cơ tim** | Tim; là cơ **vân đặc biệt** | **Không** theo ý muốn, **tự điều khiển** (tự động) |

**Cấu tạo:** trong tế bào cơ, **sợi actin** kết hợp với **sợi myozin** tạo thành **tơ cơ** (myofibril). Cơ co hay duỗi chính là do hai loại sợi này hoạt động.

**Cơ chế co:**
1. Sợi actin **trượt lên** sợi myozin. Hai loại sợi không ngắn lại; chúng chỉ chồng lên nhau nhiều hơn.
2. **Mấu bên** (đầu) của sợi myozin gắn vào **trung tâm kết hợp** trên actin, tạo **phức hợp actomyozin**. Quá trình này cần **ATP**.
3. Bình thường các trung tâm kết hợp trên actin bị **tropomyozin che**. Khi có **Ca^2+^**, ion này gắn vào **troponin** (troponin có ái lực mạnh với Ca^2+^). Troponin đổi hình dạng, kéo **tropomyozin dịch đi**, làm lộ trung tâm kết hợp.
4. Nhờ năng lượng ATP, đầu myozin đổi hình dạng, bám vào actin và kéo → **cơ co**.

**Cơ chế duỗi:** **Ca^2+^ rời khỏi troponin** → tropomyozin trở về chỗ cũ, **che lại** trung tâm kết hợp → myozin không bám được → **cơ duỗi**.

![Hình 3. Vai trò của Ca²⁺, troponin và tropomyozin (sơ đồ)](troponin-tropomyozin.svg)

| Protein | Đặc điểm theo giáo trình | Vai trò |
|---|---|---|
| **Actin** | Sợi mảnh, có trung tâm kết hợp | Bị myozin kéo trượt |
| **Myozin** | Sợi dày, có mấu bên (đầu) | Gắn actin, dùng ATP để kéo |
| **Troponin** | Protein **hình cầu**; ái lực mạnh với **Ca^2+^** | "Công tắc" nhận Ca^2+^ |
| **Tropomyozin** | Protein **sợi**, đường kính **2 nm**, dài **40 nm**, gồm **2 chuỗi polypeptid** xoắn nhau; nằm dọc **rãnh xoắn** của sợi actin | **Che / mở** trung tâm kết hợp |

> [!bay]
> - Ca^2+^ gắn vào **troponin**, **không** gắn vào tropomyozin hay myozin.
> - Thứ trực tiếp **che** vị trí gắn là **tropomyozin**. Trong ngoặc, giáo trình có câu "troponin… phủ các vị trí kết hợp", nhưng chính đoạn văn ngay sau lại mô tả tropomyozin che. Hãy nhớ: **troponin = công tắc, tropomyozin = tấm che**.
> - Khi co cơ, **sợi actin và myozin không co ngắn**; chúng trượt lên nhau.
> - Sách gọi myozin là "sợi vi thể myozin". Thực ra **sợi vi thể** (vi sợi) là tên của sợi **actin**; myozin tạo **sợi dày** riêng.

> [!vi-du] Co cứng tử thi
> Sau khi chết vài giờ, tế bào hết ATP. Đầu myozin đã gắn actin thì **không nhả ra được**, vì cần ATP mới tách được đầu myozin khỏi actin. Cơ cứng đờ lại (co cứng tử thi). Như vậy ATP cần cho **cả lúc co lẫn lúc duỗi**.

> [!ung-dung] Troponin tim và thuốc chẹn kênh calci
> - **Troponin tim** (cTnI, cTnT) có cấu trúc hơi khác troponin cơ vân. Khi tế bào cơ tim bị hoại tử, troponin tim thoát vào máu. Xét nghiệm **troponin tim (hs-troponin)** là chỉ số chính để chẩn đoán **nhồi máu cơ tim**.
> - **Bệnh cơ tim phì đại** (gặp khoảng **1/500** người) thường do đột biến trội ở gen protein sợi cơ tim, hay gặp nhất là **myozin tim** (*MYH7*) và protein gắn myozin (*MYBPC3*): đầu myozin hoạt động quá mức làm thành tim dày, cứng. Thuốc **ức chế myozin tim** (mavacamten, FDA cấp phép năm 2022) giảm số đầu myozin gắn actin, đúng cơ chế trượt sợi ở trên (bổ sung – kiến thức hiện nay).
> - **Thuốc chẹn kênh calci** (amlodipin, nifedipin…) giảm Ca^2+^ vào tế bào **cơ trơn mạch máu** → cơ trơn bớt co, mạch giãn → **hạ huyết áp**. (Ở cơ trơn, Ca^2+^ điều khiển co cơ qua calmodulin chứ không qua troponin, nhưng nguyên tắc "có Ca^2+^ mới co" vẫn giữ.)

## 4. Hệ thống kết dính của tế bào

Trong cơ thể đa bào, các tế bào gắn với nhau qua **khoảng gian bào**. Khoảng này được giới hạn bởi màng của các tế bào kề nhau, chứa các **phân tử đặc trưng trên bề mặt tế bào** và các chất làm nhiệm vụ **kết dính**.

**Lực kết dính dựa vào:**
- tác động qua lại giữa các **nhóm chức hóa học**;
- **cầu nối trung gian qua ion** (ví dụ Ca^2+^);
- **lực tĩnh điện** giữa hai tế bào.

**Các kiểu kết dính** (ví dụ của sách): kiểu **kháng nguyên – kháng thể**, kiểu **enzym** (giáo trình chỉ nêu tên), kết dính bằng **fibronectin** (đã học ở phần protein màng).

> [!cap-nhat] Các phân tử kết dính tế bào (CAM)
> Hiện nay người ta xếp các phân tử kết dính thành vài họ chính: **cadherin** (nối tế bào – tế bào, **cần Ca^2+^**), **integrin** (nối tế bào với chất nền như fibronectin), **selectin** và họ **immunoglobulin**. Ví dụ ứng dụng:
> - Bạch cầu xuyên mạch (mục 3.1) phải qua các bước: **lăn** trên nội mô nhờ selectin → **bám chặt** nhờ integrin → lách ra ngoài. Trẻ thiếu integrin của bạch cầu bị nhiễm khuẩn nặng, tái diễn mà **không có mủ** (bạch cầu không ra khỏi mạch được).
> - Tế bào ung thư biểu mô **mất E-cadherin** thì dễ tách khỏi khối u và **di căn**.

## Tóm tắt

| Chủ đề | Ý chính |
|---|---|
| Trạng thái nguyên sinh chất | Hệ keo; nhũ tương bền (nhờ protein, phospholipid); hạt keo cùng dấu điện nên không lắng; chất điện ly, chất định hình → đông tụ; chuyển động Brown |
| Sol – gel | Sol lỏng ⇌ gel đặc, co giãn; một chiều: lòng trắng trứng đun nóng, huyết tương đông |
| Độ nhớt | Gấp 40–50 lần nước; tăng khi hoạt động mạnh, phân chia; giảm khi bị thuốc mê |
| Dòng nội chất | Rõ ở nội chất; tăng bởi ánh sáng, nhiệt độ, oxy; giảm/liệt bởi ête, chloroform; non chậm → trưởng thành nhanh → già chậm |
| Bào quan, nhân | Ty thể lượn sóng tới nơi cần năng lượng; lục lạp theo dòng và ánh sáng; nhân tự quay |
| Chân giả | Amip, bạch cầu (xuyên mạch); nội chất sol chảy tới, đầu hóa gel làm điểm tựa; sợi actin trùng hợp – giải trùng hợp; nguyên bào sợi trườn |
| Lông, roi | Đường kính 0,2 µm; màng sinh chất bọc lõi 9 + 2; gốc là thể gốc 9 + 0 (giống trung tử, tái sinh lông); dynein ATPase + ATP + Ca^2+^ → đôi ống trượt → uốn cong |
| Vi khuẩn | Lông 19–20 µm, tới 300/tế bào; roi tới 150 µm, 1–2/tế bào; không theo 9 + 2 |
| Tế bào cơ | Vân (theo ý muốn), trơn, tim (không theo ý muốn); actin trượt trên myozin, cần ATP; Ca^2+^ gắn troponin → tropomyozin dịch → lộ vị trí gắn → co; Ca^2+^ rời → duỗi |
| Kết dính | Qua khoảng gian bào; nhóm chức, cầu nối ion, lực tĩnh điện; kiểu kháng nguyên – kháng thể, enzym, fibronectin |
