---
title: Sự vận chuyển vật chất qua màng tế bào
thoi-gian: 35 phút
muc-tieu:
- Trình bày được đặc điểm, các yếu tố ảnh hưởng và ví dụ của ba kiểu vận chuyển thấm: vận chuyển thụ động, vận chuyển có trung gian và vận chuyển chủ động.
- Giải thích được cơ chế bơm Na^+^-K^+^-ATPase, bơm Ca^2+^ và bơm proton.
- Mô tả và phân biệt được ẩm bào, nội thực bào (qua ổ tiếp nhận, ví dụ LDL), thực bào và ngoại tiết bào.
- Vận dụng được các kiến thức trên để hiểu dịch truyền đẳng/ưu/nhược trương và cơ chế một số thuốc (glycosid tim, lợi tiểu, ức chế bơm proton).
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Vật chất qua màng theo 2 con đường: **vận chuyển thấm** (từng phân tử, ion đi xuyên màng) và **ẩm thực bào** (đi trong **túi** làm bằng màng).
> 2. **Thụ động** (khuếch tán đơn thuần): không cần protein, không tốn năng lượng, đi **theo gradient**, hai chiều. Ví dụ O~2~, CO~2~, ethanol, urê.
> 3. **Có trung gian**: cần **protein vận tải** nhưng **không tốn năng lượng của tế bào**, vẫn theo gradient, hai chiều. Ví dụ glucose permease, band3 ở hồng cầu.
> 4. **Chủ động**: cần protein (cái **bơm**), **tốn ATP**, đi được **ngược gradient**, **một chiều**. Ví dụ bơm Na^+^-K^+^: **1 ATP → 3 Na^+^ ra, 2 K^+^ vào**.
> 5. Ẩm thực bào có 4 hình thức: **ẩm bào** (uống dịch, không đặc hiệu), **nội thực bào** (đặc hiệu, qua ổ tiếp nhận, ví dụ LDL), **thực bào** (ăn mồi lớn), **ngoại tiết bào** (đẩy chất ra).

Màng sinh chất là lớp **lipid kép** có protein xen vào. Lõi của lớp kép là các đuôi acid béo **kỵ nước**. Vì vậy màng như một "hàng rào dầu": chất **nhỏ và tan trong lipid** lách qua dễ; chất **tan trong nước, tích điện hoặc to** thì bị chặn lại và phải nhờ protein hoặc nhờ túi màng. Toàn bộ bài này là câu trả lời cho câu hỏi: *mỗi loại chất vượt hàng rào đó bằng cách nào?*

![Hình 1. So sánh các kiểu vận chuyển thấm qua màng](van-chuyen-tham.svg)

## 1. Vận chuyển thấm

Vận chuyển thấm là kiểu vận chuyển trong đó chất đi **xuyên qua màng** dưới dạng từng phân tử hoặc ion, không tạo túi. Giáo trình chia làm 3 loại: **thụ động**, **có trung gian** và **chủ động**.

### 1.1. Vận chuyển thụ động (khuếch tán đơn thuần)

Giáo trình viết là *khuyếch tán đơn thuần*. Phân tử nhỏ **hòa tan vào lớp lipid kép**, đi xuyên qua, rồi hòa vào dịch nước ở phía bên kia. Không có protein nào "chọn lọc" nên quá trình này **rất ít đặc hiệu**.

Ví dụ: **ethanol, urê, glycerol, O~2~, CO~2~**.

**Vì sao không tốn năng lượng?** Phân tử luôn chuyển động hỗn loạn do nhiệt. Ở phía đậm đặc, nhiều phân tử va vào màng hơn, nên số phân tử đi sang phía loãng nhiều hơn số đi ngược lại. Kết quả là dòng **thực** đi từ nơi **cao → thấp**, cho đến khi hai bên cân bằng. Động lực là chính **gradient nồng độ**, không phải ATP.

#### a) Đặc điểm (5 đặc điểm — hay hỏi)

| Đặc điểm | Ý nghĩa |
|---|---|
| Chất vận chuyển **không bị biến đổi hóa học** | Đi vào thế nào thì ra thế ấy |
| Chất vận chuyển **không kết hợp** với chất khác | Không cần protein mang |
| **Không cần năng lượng** | Không dùng ATP |
| Phụ thuộc **gradient nồng độ hoặc điện thế** | Đi từ bên cao sang bên thấp |
| Vận chuyển **hai chiều**, tiến tới **cân bằng** trong – ngoài | Khi hai bên bằng nhau thì dòng thực bằng 0 |

#### b) Các yếu tố ảnh hưởng đến khuếch tán

1. **Kích thước phân tử**: càng lớn càng khó qua. Theo giáo trình:

| Chất | Khối lượng (dalton) | Tốc độ qua màng |
|---|---|---|
| O~2~ | 32 | Nhanh |
| CO~2~ | 40 (giáo trình ghi; thực tế ≈ 44) | Nhanh |
| Ethanol | 46 | Nhanh |
| Urê | 60 | Nhanh |
| Glycerol | 92 | **Chậm** |
| Glucose | 180 | **Rất khó** qua |

2. **Độ tan trong lipid**: chất càng tan trong lipid càng dễ qua. Ví dụ alcol, aldehyd, aceton, glycerol, **các thuốc gây mê**.
3. **Gradient nồng độ** (xem mục c về môi trường đẳng/ưu/nhược trương).
4. **Mức ion hóa**: ion **hóa trị 1 dễ qua hơn ion hóa trị 2**. Ion bị một lớp nước bao quanh (ion hydrat hóa) nên to ra và càng khó qua.
5. **Nhiệt độ**: tăng vừa phải thì tính thấm tăng. Cứ tăng **10 °C** thì tính thấm tăng khoảng **1,4 lần**. Lý do: phân tử chuyển động nhanh hơn và lớp lipid "lỏng" hơn.
6. **Nhu cầu hoạt động**: khi **cơ hoạt động** thì glucose và acid amin (amino acid) đi vào; khi cơ nghỉ (duỗi) thì không.
7. **Tác động qua lại giữa các chất**: Ca^2+^ (liên kết với nước) làm **giảm** tính thấm; glycerin khi có **thuốc mê** thì **tăng** thấm.

> [!ung-dung] Vì sao thuốc gây mê và nhiều thuốc an thần "vào não" dễ?
> Hàng rào máu – não được tạo bởi các tế bào nội mô nối khít, nên chất muốn vào não gần như phải **đi xuyên qua màng tế bào**. Chất **nhỏ, tan trong lipid** (thuốc mê bay hơi, ethanol, diazepam) qua dễ. Chất phân cực, tích điện thì khó vào. Đây là lý do rượu tác động lên não rất nhanh, và vì sao khi thiết kế thuốc người ta phải tính đến độ tan trong lipid.

#### c) Thẩm thấu — môi trường đẳng, ưu, nhược trương

Lớp lipid kép cho **nước** qua tương đối dễ nhưng chặn phần lớn chất hòa tan (muối, đường…). Vì vậy khi nồng độ chất tan hai bên khác nhau, chất tan không qua được thì **nước di chuyển**: nước đi từ nơi **ít** chất tan sang nơi **nhiều** chất tan. Hiện tượng này gọi là **thẩm thấu**.

| Môi trường | So với trong tế bào | Nước đi | Tế bào động vật | Tế bào thực vật |
|---|---|---|---|---|
| **Nhược trương** | Chất tan bên ngoài **thấp hơn** | Vào tế bào | **Trương** rồi **tan bào** (vỡ) | Trương nước (thành cellulose giữ không cho vỡ) |
| **Ưu trương** | Chất tan bên ngoài **cao hơn** | Ra khỏi tế bào | **Teo bào** (co lại) | **Co nguyên sinh** |
| **Đẳng trương** | Bằng nhau | Cân bằng | Giữ nguyên — **môi trường sinh lý** | Giữ nguyên |

Nồng độ đẳng trương **khác nhau** tùy loại tế bào động vật và thực vật.

> [!bay]
> - "Nhược/ưu" luôn nói về **môi trường bên ngoài so với bên trong tế bào**. Môi trường **nhược** trương → tế bào **trương** (dễ nhầm vì hai chữ ngược nghĩa).
> - **Co nguyên sinh** chỉ dùng cho tế bào **thực vật** (khối nguyên sinh chất tách khỏi thành tế bào). Tế bào động vật trong môi trường ưu trương thì gọi là **teo bào**.
> - Hồng cầu cho vào **nước cất** → tan bào (tan máu). Vì vậy **không bao giờ tiêm nước cất vào tĩnh mạch**.

> [!ung-dung] Dịch truyền — áp dụng trực tiếp bài này
> - **Đẳng trương**: **NaCl 0,9%** (nước muối sinh lý), **glucose 5%**, Ringer lactat. Dùng bù dịch thông thường.
> - **Ưu trương**: NaCl 3%, glucose 10–30%, **mannitol 20%**. Dịch ưu trương **kéo nước ra khỏi tế bào**, nên NaCl 3% và mannitol được dùng để giảm **phù não**. Dịch ưu trương đậm đặc dễ gây viêm tĩnh mạch ngoại vi.
> - **Nhược trương**: NaCl 0,45%. Dùng thận trọng vì nước sẽ đi **vào** tế bào.
> - Mẹo: glucose 5% đẳng trương **trong chai**, nhưng sau khi vào cơ thể glucose bị chuyển hóa hết, phần còn lại như **nước tự do**. Vì thế không dùng glucose 5% cho bệnh nhân phù não.

> [!yhct] Saponin và tính thấm của màng
> Nhiều saponin dược liệu (Cát cánh, Viễn chí, Nhân sâm…) gắn cholesterol của màng, tạo lỗ thủng và làm tăng tính thấm, nên làm tan hồng cầu khi tiếp xúc trực tiếp; vì vậy không được tiêm dịch chiết chứa saponin vào máu. Chi tiết, mức bằng chứng và lưu ý thuật ngữ "phá huyết" (xem bài *Màng tế bào và tế bào chất*, mã sh-02).

### 1.2. Vận chuyển có trung gian

Đây vẫn được xếp là vận chuyển **thụ động**, nhưng chất phải **nhờ một protein xuyên màng** mới qua được. Giáo trình coi đây là loại **chuyển tiếp giữa thụ động và chủ động**, vì đã có sự tham gia của protein (một phần "tính chủ động").

#### a) Đặc điểm

- Phải có **protein màng** tiếp nhận chất và làm **vận tải viên** (permease, chất mang).
- **Không cần năng lượng** của tế bào.
- Vẫn đi **theo gradient nồng độ**.
- **Hai chiều** (thuận nghịch).

**Vì sao cần protein?** Glucose (180 dalton), ion Cl^−^, HCO~3~^−^ đều **tan trong nước, không tan trong lipid**. Chúng không tự lách qua lõi kỵ nước được. Protein vận tải tạo "lối đi" riêng cho chúng. Vì mỗi protein chỉ khớp với một số chất nhất định, kiểu vận chuyển này **đặc hiệu** hơn nhiều so với khuếch tán đơn thuần.

#### b) Ví dụ 1 — Glucose vào hồng cầu qua glucose permease

- Vận tải viên là protein xuyên màng **glucose permease**, chiếm khoảng **2% tổng protein màng hồng cầu**.
- **D-glucose** gắn tạm thời vào permease → permease **đổi hình dạng** → đẩy glucose vào trong. **L-glucose không vào được** (protein phân biệt được đồng phân quang học).
- Năng lượng đến từ **gradient nồng độ của chính glucose**, không phải ATP của tế bào.
- Permease vận chuyển hai chiều. Nhưng glucose vừa vào đã bị **phosphoryl hóa thành glucose-6-phosphat**, chất này không ra được. Nhờ đó nồng độ glucose tự do trong tế bào **luôn thấp** (nội bào "nhược trương về glucose"), gradient được giữ nguyên, glucose tiếp tục đi vào.
- Permease còn mang được **các đường đơn dãy D khác** (với tần suất thấp hơn glucose), nên có tên chung là **D-hexose permease**.

> [!vi-du] "Bẫy" glucose bằng phosphoryl hóa
> Đây là một mẹo rất thông minh của tế bào. Glucose-6-phosphat mang nhóm phosphat tích điện âm và **không phải là cơ chất của permease**, nên bị "nhốt" trong tế bào. Gradient glucose vì thế không bao giờ triệt tiêu, dù không tốn năng lượng cho việc vận chuyển (năng lượng tốn ở bước phosphoryl hóa, thuộc chuyển hóa).

#### c) Ví dụ 2 — Trao đổi anion qua band3 ở hồng cầu

- **Band3** là protein xuyên màng **đi qua lại màng nhiều lần**, gồm một chuỗi polypeptid khoảng **930 acid amin**. Mỗi hồng cầu có khoảng **10^6^ chuỗi** band3.
- Band3 trao đổi **1 đổi 1**: đưa **1 HCO~3~^−^** qua màng thì đưa **1 Cl^−^** theo chiều ngược lại. Band3 **không cho anion đi một chiều**.
- Vai trò: giúp hồng cầu chuyên chở CO~2~. Ở mô, CO~2~ vào hồng cầu → thành HCO~3~^−^ → HCO~3~^−^ ra huyết tương, Cl^−^ đi vào. Ở phổi, quá trình đảo ngược để thải CO~2~.

> [!cap-nhat] Kênh protein và tên gọi hiện nay
> - Giáo trình chỉ nói đến protein **mang** (permease). Hiện nay "khuếch tán được hỗ trợ" (*facilitated diffusion*) gồm hai loại protein: **chất mang** (gắn chất rồi đổi hình, như glucose permease — nay gọi là **GLUT1**) và **kênh** (tạo lỗ, chất đi qua rất nhanh, như **kênh ion** và **aquaporin** — kênh nước).
> - Các sách hiện nay xếp loại này hoàn toàn vào **vận chuyển thụ động** (không tốn năng lượng), không coi là "có tính chủ động một phần". Band3 nay gọi là **AE1** (*anion exchanger 1*).
> - Thực tế ion (Na^+^, K^+^, Cl^−^…) gần như **không qua được lớp lipid kép thuần**; chúng đi chủ yếu qua **kênh ion** và chất mang. Câu "ion hóa trị 1 dễ qua hơn hóa trị 2" của giáo trình chỉ nên hiểu là xu hướng chung (ion càng tích điện, càng hydrat hóa mạnh thì càng khó vào lõi lipid).
> - Band3 (AE1) của người dài **911 acid amin** theo cơ sở dữ liệu protein hiện nay (giáo trình ghi khoảng 930).
> - Đi thi trả lời theo giáo trình.

> [!cap-nhat] Kênh ion và aquaporin (bổ sung – kiến thức hiện nay)
> - **Kênh ion** là protein xuyên màng tạo lỗ nước, **chọn lọc** theo loại ion (kênh K^+^, Na^+^, Ca^2+^, Cl^−^…) và có **cổng** đóng/mở theo: **điện thế màng** (kênh Na^+^ tạo điện thế hoạt động), **chất gắn** (receptor acetylcholin ở bản vận động), hoặc **lực cơ học** (kênh Piezo cảm nhận áp lực, xúc giác — Nobel Y học 2021). Ion qua kênh nhanh hơn qua chất mang hàng nghìn lần.
> - Kỹ thuật **kẹp miếng vá (patch clamp)** đo được dòng ion qua **một kênh đơn lẻ** (Neher và Sakmann, **Nobel Y học 1991**). **Nobel Hóa học 2003** trao cho Peter **Agre** (tìm ra **aquaporin** — kênh nước) và Roderick **MacKinnon** (cấu trúc **kênh K^+^**, giải thích vì sao kênh cho K^+^ qua mà chặn Na^+^ nhỏ hơn).
> - **Aquaporin** giải thích vì sao một số tế bào (hồng cầu, ống thận) thấm nước rất nhanh, nhanh hơn nhiều so với nước "lách" qua lớp lipid. Ở ống góp thận, hormon **ADH (vasopressin)** đưa **aquaporin-2** lên màng để tái hấp thu nước; hỏng receptor ADH hoặc aquaporin-2 gây **đái tháo nhạt do thận**.
> - Các họ protein vận chuyển lớn của người: **họ SLC** (*solute carrier*, hơn 400 gen chia thành 66 họ — gồm cả GLUT, SGLT, band3/AE1, các đồng vận chuyển Na^+^-K^+^-2Cl^−^, Na^+^-Cl^−^…) và **họ ABC** (48 gen, 7 phân họ A–G — dùng ATP để vận chuyển). Ví dụ họ ABC quan trọng trong y học: **P-glycoprotein** (ABCB1/MDR1) bơm thuốc ra khỏi tế bào gây **kháng đa thuốc** trong ung thư; **ABCG2** đào thải acid uric ở ruột, thận (biến thể giảm chức năng làm tăng nguy cơ **gút**).

> [!ung-dung] Bệnh do hỏng kênh, hỏng chất mang
> - **Bệnh xơ nang** (cystic fibrosis): hỏng **kênh Cl^−^** (CFTR) → chất nhầy ở phổi, tụy quá đặc. Đột biến hay gặp nhất là **F508del** (mất phenylalanin 508): protein gấp sai, bị lưới nội sinh chất giữ lại và phân hủy, không lên được màng. Bệnh hay gặp ở người gốc châu Âu, **hiếm** ở người châu Á.
> - **Thiếu GLUT1** bẩm sinh: glucose vào não kém → co giật ở trẻ nhỏ.
> - Phát hiện aquaporin được trao **giải Nobel Hóa học 2003** (Peter Agre).

> [!cap-nhat] CFTR và thuốc điều biến (bổ sung – kiến thức hiện nay)
> - **CFTR** thực chất thuộc **họ ABC** (tên khác ABCC7) nhưng hoạt động như một **kênh Cl^−^** có cổng, mở nhờ ATP và phosphoryl hóa — ví dụ cho thấy ranh giới "kênh" và "chất mang" không tuyệt đối.
> - Thuốc **điều biến CFTR** sửa chữa chính protein hỏng: **chất điều chỉnh** (*corrector*: elexacaftor, tezacaftor) giúp protein F508del **gấp đúng và lên được màng**; **chất tăng cường** (*potentiator*: ivacaftor) giúp kênh trên màng **mở lâu hơn**.
> - Phối hợp **elexacaftor/tezacaftor/ivacaftor** (Trikafta, ở châu Âu là Kaftrio) được FDA phê duyệt **10/2019** cho người từ 12 tuổi có ít nhất một alen F508del, sau đó mở rộng xuống **từ 2 tuổi**. Tháng **12/2024** FDA phê duyệt phối hợp dùng 1 lần/ngày **vanzacaftor/tezacaftor/deutivacaftor** (Alyftrek). Tháng **4/2026** nhãn của hai thuốc được mở rộng cho mọi biến thể vẫn tạo ra protein CFTR, ước tính bao phủ khoảng **95%** người bệnh xơ nang ở Hoa Kỳ. Đây là ví dụ tiêu biểu của **y học chính xác**: thuốc chọn theo đột biến của từng người.

### 1.3. Vận chuyển chủ động

Vận chuyển chủ động diễn ra **hoàn toàn theo nhu cầu của tế bào**: tế bào tốn năng lượng để "bơm" chất đến nơi nó cần, kể cả khi bên đó đã đậm đặc hơn.

#### a) Đặc điểm

- **Bắt buộc** có protein vận tải, gọi là **vận tải viên** hay **cái bơm** của tế bào.
- **Tốn năng lượng** (ATP).
- Có thể đi **ngược gradient** nồng độ hoặc điện thế.
- Vận chuyển **chỉ một chiều**.

**Vì sao phải tốn năng lượng?** Đẩy chất từ nơi thấp lên nơi cao giống như bơm nước lên bồn trên mái: không thể tự chảy, phải có máy bơm và điện. Ở tế bào, "điện" là ATP.

#### b) Ví dụ 1 — Bơm Na^+^-K^+^ (Na^+^-K^+^-ATPase)

**Vai trò.** Bên trong tế bào, **K^+^ cao hơn bên ngoài khoảng 10–20 lần** (theo giáo trình); Na^+^ thì ngược lại, cao ở ngoài. Bơm Na^+^-K^+^ là cái **duy trì** sự chênh lệch đó. Bơm có ở màng sinh chất của **hầu hết tế bào động vật**; nó **đẩy Na^+^ ra** và **đưa K^+^ vào**.

**Cấu tạo.**

- **Phân đơn vị lớn** (khoảng **1000 acid amin**), đi qua màng **nhiều lần**, làm nhiệm vụ xúc tác vận chuyển.
- **Phân đơn vị nhỏ** là một **glycoprotein** (giáo trình viết *glucoprotein*).
- Trên phân đơn vị lớn:

| Mặt **ngoài** màng | Mặt **trong** màng |
|---|---|
| **2 vị trí cho K^+^** | **3 vị trí cho Na^+^** |
| **1 vị trí cho uabain** (ouabain) | **1 vị trí cho ATP** |

**Hiệu suất: thủy phân 1 ATP → đẩy ra 3 Na^+^, đưa vào 2 K^+^.**

*(Bổ sung – kiến thức hiện nay: bơm Na^+^-K^+^-ATPase do **Jens Skou** phát hiện năm 1957 — enzym vận chuyển ion đầu tiên được biết — và ông được **giải Nobel Hóa học 1997**. Trong chu kỳ bơm, chính phân đơn vị lớn được **gắn tạm nhóm phosphat** từ ATP; bơm thuộc nhóm **ATPase type P**, cùng nhóm với bơm Ca^2+^ và bơm H^+^/K^+^ dạ dày.)*

![Hình 2. Ba bước hoạt động của bơm Na⁺-K⁺-ATPase](bom-na-k.svg)

**Ba bước** (theo giáo trình):

1. **3 Na^+^** từ trong tế bào chất gắn vào 3 vị trí ở **mặt trong** của vận tải viên (ATP cũng gắn vào).
2. ATP bị thủy phân, vận tải viên đổi hình: **3 Na^+^ được đẩy ra ngoài**, đồng thời **2 K^+^** gắn vào vị trí của chúng ở **mặt ngoài**.
3. **2 K^+^ được đưa vào trong** tế bào; vận tải viên **trở lại trạng thái ban đầu**.

Giáo trình ghi thêm: Na^+^ đi trở lại vào tế bào bằng **con đường khác** — con đường đi cùng glucose.

> [!vi-du] Vì sao bơm Na-K quan trọng đến vậy?
> - Mỗi vòng bơm đưa ra 3 điện tích dương nhưng chỉ đưa vào 2, nên bơm góp phần làm **mặt trong màng âm hơn** (điện thế nghỉ), nền tảng cho dẫn truyền thần kinh và co cơ.
> - Bơm giữ Na^+^ trong tế bào thấp, nhờ vậy **giữ thể tích tế bào ổn định**. Khi tế bào thiếu ATP (thiếu máu, thiếu oxy), bơm ngừng → Na^+^ và nước tràn vào → **tế bào phù**.
> - Bơm Na-K tiêu tốn một phần rất lớn ATP của cơ thể lúc nghỉ (ước tính 20–30%, ở tế bào thần kinh còn cao hơn).
> - Giá trị thường gặp: K^+^ trong tế bào ~140 mmol/L, ngoài 3,5–5 mmol/L; Na^+^ ngoài ~140 mmol/L, trong ~10–15 mmol/L. Tức chênh lệch K^+^ vào khoảng 30 lần, Na^+^ khoảng 10 lần — các sách ghi khác nhau, **đi thi dùng con số 10–20 lần của giáo trình**.

> [!cap-nhat] Đồng vận chuyển Na^+^ – glucose (vận chuyển chủ động thứ phát)
> Câu "Na^+^ vào tế bào bằng con đường permease của glucose" của giáo trình **không** đúng với hồng cầu: glucose permease của hồng cầu (GLUT1) **không** mang Na^+^. Ý này chỉ đúng với tế bào **niêm mạc ruột** và **ống thận**. Ở đó có protein **SGLT** mang **Na^+^ và glucose cùng vào** một lúc. Na^+^ đi xuôi gradient (do bơm Na-K tạo ra), và kéo glucose đi **ngược** gradient theo. Kiểu này nay gọi là **vận chuyển chủ động thứ phát**: không trực tiếp dùng ATP nhưng **dựa vào gradient Na^+^ do bơm Na-K tạo ra**.

> [!ung-dung] Thuốc tác động lên bơm Na-K và đồng vận chuyển Na
> - **Digoxin** (glycosid tim, chiết từ cây *Digitalis*) **ức chế bơm Na^+^-K^+^-ATPase** ở tế bào cơ tim, gắn vào **mặt ngoài** — đúng vị trí gắn **uabain** mà giáo trình nêu. Na^+^ trong tế bào tăng → bộ trao đổi Na^+^/Ca^2+^ kém đẩy Ca^2+^ ra → Ca^2+^ trong tế bào tăng → **tim co bóp mạnh hơn**. Dùng trong suy tim, rung nhĩ.
> - Liều điều trị **rất gần** liều độc. **Hạ K^+^ máu** (ví dụ do dùng kèm thuốc lợi tiểu) làm **tăng độc tính** digoxin, vì K^+^ và digoxin tranh nhau cùng vị trí ở mặt ngoài bơm.
> - **Dung dịch bù nước uống (ORS, oresol)** chứa **cả muối lẫn glucose** chính là để tận dụng SGLT ở ruột: glucose kéo Na^+^, Na^+^ kéo nước vào máu. Đó là lý do ORS cứu sống rất nhiều trẻ tiêu chảy, mất nước.
> - Nhóm thuốc **ức chế SGLT2** (dapagliflozin, empagliflozin) chặn tái hấp thu glucose ở ống thận → thải glucose qua nước tiểu, dùng trong đái tháo đường type 2 và suy tim.

> [!yhct] Glycosid tim trong dược liệu
> Nhiều cây có **glycosid tim** tác dụng cùng cơ chế với digoxin (ức chế bơm Na-K):
> - **Trúc đào** (*Nerium oleander*): lá chứa **oleandrin** và các glycosid tim khác.
> - **Thông thiên** (*Thevetia peruviana*): hạt chứa **thevetin** (A, B) và các glycosid tim khác.
> - Chi ***Strophanthus*** (ở Việt Nam có cây **Sừng dê**, *S. divaricatus*): loài *S. gratus* ở châu Phi là nguồn của **uabain** (G-strophanthin) — chính chất mà giáo trình nêu có vị trí gắn trên bơm.
> - **Thiềm tô** (nhựa tiết khô từ tuyến da cóc): chứa **bufadienolid** (như bufalin), cũng ức chế bơm Na-K.
>
> Tất cả đều **rất độc**, khoảng cách giữa liều có tác dụng và liều độc rất hẹp: chỉ một lượng nhỏ lá trúc đào hay hạt thông thiên đã có thể gây **loạn nhịp tim, tử vong** (nhất là ở trẻ em). Ngộ độc **cóc** (ăn thịt cóc còn sót da, gan, trứng) ở Việt Nam cũng là ngộ độc glycosid tim. **Không tự bào chế để dùng**; chỉ dùng chế phẩm đã chuẩn hóa hàm lượng, theo chỉ định của thầy thuốc.

#### c) Ví dụ 2 — Bơm Ca^2+^ (Ca^2+^-ATPase)

- Có ở **màng lưới nội sinh chất nhẵn của tế bào cơ** và ở **màng sinh chất của hồng cầu**.
- Ở **hồng cầu**: đẩy Ca^2+^ **ra khỏi** tế bào.
- Ở **tế bào cơ**: bơm Ca^2+^ **vào lòng lưới nội sinh chất nhẵn** → Ca^2+^ trong tế bào chất giảm → **cơ duỗi**. Khi Ca^2+^ được trả lại tế bào chất → **cơ co**.
- Ca^2+^-ATPase cần **Mg^2+^** để hoạt động.

> [!cap-nhat] Ca^2+^ trở lại tế bào chất không phải nhờ "bơm"
> Giáo trình viết "khi bơm trả lại Ca^2+^ cho tế bào chất thì cơ co". Hiện nay biết rõ: khi có xung thần kinh, Ca^2+^ thoát ra khỏi lưới nội sinh chất qua **kênh Ca^2+^** (thụ thể ryanodin), tức là **xuôi gradient, không tốn ATP**. **Bơm** (tốn ATP) chỉ làm nhiệm vụ **thu hồi** Ca^2+^ để cơ duỗi. Vì vậy cơ duỗi cũng **cần ATP**. Khi chết, ATP cạn: đầu myozin không tách được khỏi actin (cần ATP mới nhả ra) và Ca^2+^ không được thu hồi → **co cứng tử thi** (xem Bài 6).

#### d) Ví dụ 3 — Bơm proton (H^+^)

- Là hệ thống vận chuyển H^+^ **phụ thuộc ATP**.
- Ở **màng tiêu thể**: bơm H^+^ **vào trong** tiêu thể, giữ **pH acid** (khoảng 4,5–5) cho các enzym thủy phân hoạt động.
- Giáo trình nêu thêm: gặp ở **màng thylakoid của lục lạp**, tạo chênh lệch lớn về H^+^ (gradient điện thế) giữa hai phía màng.

> [!bay]
> Ở thylakoid, gradient H^+^ chủ yếu do **chuỗi chuyền điện tử** (dùng năng lượng ánh sáng) tạo ra, rồi gradient đó được dùng để **tổng hợp** ATP. Tức là ở đây là chiều "H^+^ → ATP", ngược với bơm tiêu thể "ATP → H^+^". Khi thi, nhớ ý của giáo trình: bơm H^+^ có ở **màng tiêu thể** và **màng thylakoid**.

> [!ung-dung] Thuốc ức chế bơm proton
> Tế bào viền dạ dày có bơm **H^+^/K^+^-ATPase** tiết acid vào lòng dạ dày. Các thuốc **ức chế bơm proton** (omeprazol, esomeprazol, pantoprazol…) khóa bơm này → giảm tiết acid. Dùng trong loét dạ dày – tá tràng, trào ngược dạ dày – thực quản.

### 1.4. So sánh ba kiểu vận chuyển thấm

| | **Thụ động** (khuếch tán đơn thuần) | **Có trung gian** | **Chủ động** |
|---|---|---|---|
| Protein vận tải | **Không** | **Có** (permease) | **Bắt buộc** (bơm) |
| Năng lượng của tế bào | Không | Không | **Có (ATP)** |
| Chiều so với gradient | Theo gradient | Theo gradient | **Có thể ngược gradient** |
| Hai chiều / một chiều | Hai chiều | Hai chiều | **Một chiều** |
| Tính đặc hiệu | Rất ít | Cao | Cao |
| Ví dụ (giáo trình) | O~2~, CO~2~, ethanol, urê, glycerol | Glucose vào hồng cầu; Cl^−^/HCO~3~^−^ qua band3 | Bơm Na^+^-K^+^, bơm Ca^2+^, bơm H^+^ |

> [!bay]
> - Có protein **chưa chắc** là chủ động. Dấu hiệu quyết định của vận chuyển chủ động là **tốn năng lượng** và **ngược gradient**.
> - Glucose vào **hồng cầu** là vận chuyển **có trung gian** (không tốn ATP). Đừng nhầm với glucose được hấp thu ở ruột (đồng vận chuyển với Na^+^).
> - Bơm Na-K: **3 Na ra – 2 K vào – 1 ATP**. Dễ đảo nhầm thành "3 K vào".

## 2. Ẩm thực bào (vận chuyển bằng túi màng)

Phân tử lớn (protein, LDL), giọt dịch, vi khuẩn không thể đi xuyên màng. Tế bào giải quyết bằng cách **dùng chính màng sinh chất làm túi**: hoặc bọc chất lại để đưa vào, hoặc đưa túi ra hòa vào màng để thải ra. Giáo trình gọi chung là **ẩm thực bào**, gồm **4 hình thức**:

![Hình 3. Bốn hình thức ẩm thực bào](am-thuc-bao.svg)

### 2.1. Ẩm bào (pinocytosis)

- Là sự tiếp thu **không đặc hiệu** các chất hòa tan trong dịch ngoại bào ("tế bào uống").
- Màng **lõm vào** thành túi bao lấy một giọt dịch. Chất tan trong túi có nồng độ **bằng** nồng độ ở dịch ngoại bào (tế bào lấy cả giọt, không chọn lọc).
- Túi tách khỏi màng và đi vào tế bào chất.

### 2.2. Nội thực bào (endocytosis — qua ổ tiếp nhận)

**Giống ẩm bào**: màng cũng bao lấy chất (giáo trình gọi là **mồi**) tạo thành túi rồi đưa vào tế bào chất.
**Khác ẩm bào**: mồi là **đặc hiệu**, phải có **ổ tiếp nhận** (receptor) nhận diện.

**Trình tự:**

1. Mồi gắn tạm thời với ổ tiếp nhận → **phức hợp mồi – ổ tiếp nhận**.
2. Tại chỗ có phức hợp này, màng **lõm xuống** thành túi bao lấy mồi.
3. Túi tách khỏi màng, đi vào tế bào chất đến **bào quan tiếp nhận** (tiêu thể, lưới nội sinh chất không hạt…).

**Ổ tiếp nhận:**

- Màng một tế bào động vật có tới **vài chục nghìn** ổ tiếp nhận, gồm nhiều loại, mỗi loại **rất đặc hiệu**, và mỗi loại tế bào có bộ ổ tiếp nhận riêng.
- Thành phần chính là **protein** (đôi khi là phức hợp protein), thường được **glycosyl hóa** (gắn nhánh carbohydrat). Các nhánh đường này giúp tạo **cấu trúc bậc 3**, làm **bền** protein và có thể tham gia **nhận diện** chất gắn.
- Mỗi lần màng lõm thành túi, một phần ổ tiếp nhận đi theo túi nên có thể bị **hao hụt** (một phần được gửi trở lại màng).

#### Túi áo (túi có bao clathrin) — ví dụ LDL

Một loại nội thực bào đặc biệt dùng để thu nhận chất đặc biệt và **giao đúng địa chỉ**. Túi của loại này gọi là **túi áo** (giáo trình còn gọi là *acantosom*). Ví dụ điển hình: chất gắn là **cholesterol este hóa** (trong LDL), địa chỉ giao là **tiêu thể**.

**LDL** (*Low Density Lipoprotein*, lipoprotein tỷ trọng thấp) là dạng chở phần lớn cholesterol trong máu:

- Hình cầu, đường kính **22 nm**.
- **Lõi**: cholesterol este hóa.
- Bao ngoài: một lớp **phospholipid**; ngoài cùng là protein **Apo-B**.

**Quá trình thu nhận LDL:**

1. Ở một số vùng màng tập trung nhiều ổ tiếp nhận LDL, màng lõm xuống thành **lõm màng**. Ở mặt tế bào chất, protein **clathrin** tập trung lại và **polyme hóa** thành mạng lưới bao lấy lõm → **lõm áo**. Khi túi khép lại, lưới clathrin bao quanh túi → **túi áo**. (Cũng có thể phức hợp LDL – ổ tiếp nhận di chuyển đến một lõm áo đã có sẵn.)
2. Túi áo vào tế bào chất, **lưới clathrin rã ra**, các phân tử clathrin trở về tế bào chất (để dùng lại).
3. Túi chuyển chất bên trong đến **thể nội bào** (endosome).
4. Phần màng mang **ổ tiếp nhận được gửi trở lại màng sinh chất**; còn LDL đi đến **tiêu thể** và bị **thủy phân**.
5. Trong tiêu thể, cholesterol este bị thủy phân → **cholesterol tự do**, được tế bào dùng chủ yếu để **tạo màng mới**.
6. Nếu cholesterol tự do tích lũy quá nhiều, tế bào **ngừng tự tổng hợp cholesterol** và **ngừng tiếp nhận LDL** (cơ chế tự điều hòa).

Ý nghĩa: nếu tế bào ngừng hấp thu LDL, cholesterol **tích lũy trong máu** và góp phần tạo **mảng xơ vữa động mạch**.

> [!ung-dung] Ổ tiếp nhận LDL và bệnh tim mạch
> - **Tăng cholesterol máu gia đình**: đột biến gen ổ tiếp nhận LDL → tế bào không "bắt" được LDL → LDL máu rất cao, xơ vữa và nhồi máu cơ tim từ trẻ. Công trình về ổ tiếp nhận LDL của Brown và Goldstein được **giải Nobel Y học 1985**.
> - **Statin** ức chế enzym **HMG-CoA reductase**, làm tế bào gan giảm tự tổng hợp cholesterol → tế bào "đói" cholesterol nên **tăng số ổ tiếp nhận LDL** → hút LDL khỏi máu. Đây chính là cơ chế tự điều hòa ở bước 6 nhưng theo chiều ngược lại.
> - *(Bổ sung – kiến thức hiện nay)* Protein **PCSK9** do gan tiết ra gắn vào ổ tiếp nhận LDL, khiến ổ tiếp nhận bị đưa vào **tiêu thể phân hủy** thay vì quay lại màng. Thuốc **ức chế PCSK9** (kháng thể evolocumab, alirocumab; hoặc ARN (RNA) can thiệp nhỏ inclisiran) giữ cho ổ tiếp nhận được **tái sử dụng** nhiều lần → LDL máu giảm mạnh. Một ứng dụng trực tiếp của bước 4 ("ổ tiếp nhận được gửi trở lại màng").

> [!cap-nhat] Dynamin, hõm màng và các con đường nhập bào khác (bổ sung – kiến thức hiện nay)
> - Túi áo clathrin được "cắt rời" khỏi màng nhờ protein **dynamin** (thủy phân GTP, thắt cổ túi như thắt nút túi nilon).
> - Ngoài con đường clathrin còn có nhập bào qua **hõm màng (caveolae**, giàu caveolin và cholesterol), và **ẩm bào lớn (macropinocytosis)**. Nhiều virus "mượn" các con đường này để vào tế bào: virus gắn receptor rồi được nhập bào như một "mồi".

> [!bay] Thuật ngữ của giáo trình khác sách nước ngoài
> - Giáo trình dùng **"ẩm thực bào"** làm tên chung cho cả 4 hình thức, và dùng **"nội thực bào" (endocytosis)** để chỉ riêng kiểu **có ổ tiếp nhận**.
> - Sách nước ngoài thường dùng *endocytosis* làm tên chung cho mọi kiểu đưa vào bằng túi (gồm pinocytosis, phagocytosis, receptor-mediated endocytosis). Đi thi dùng cách gọi của giáo trình.

### 2.3. Thực bào (phagocytosis)

- Là sự đưa vào tế bào **vật lớn**: **vi khuẩn**, mảnh tế bào bị vỡ, trong thí nghiệm có thể cả **mảnh chất dẻo nhỏ** ("tế bào ăn").
- Gặp ở **đại thực bào** (một loại bạch cầu) và **động vật nguyên sinh**.
- Khi mồi bám vào màng, màng **tỏa ra** (vươn chân giả) **bao lấy** mồi. Màng còn huy động các **sợi vi thể chứa actin** ngay dưới màng để **gia cố** túi thực bào.
- Túi thực bào sau đó thường hòa với tiêu thể để tiêu hủy mồi.

> [!vi-du] Phân biệt ẩm bào – thực bào bằng hình dạng màng
> Ẩm bào: màng **lõm vào** (hướng vào trong). Thực bào: màng **tỏa ra** (vươn ra ngoài) ôm lấy mồi, cần khung actin. Ẩm bào lấy **dịch**; thực bào lấy **hạt lớn**.

### 2.4. Ngoại tiết bào (exocytosis)

- Các **túi bài tiết** chứa chất thải hoặc chất tiết từ tế bào chất di chuyển đến **áp sát** màng tế bào.
- Màng túi **hòa nhập** vào màng tế bào, túi **mở ra** và thải chất ra ngoài.
- Nhờ vậy màng sinh chất được **bổ sung** thêm màng, bù cho phần màng mất đi khi tạo túi ẩm bào, nội thực bào.

> [!ung-dung] Ngoại tiết bào trong cơ thể và thuốc
> - Tế bào β tụy tiết **insulin**, đầu tận cùng thần kinh giải phóng **chất dẫn truyền thần kinh** (acetylcholin…), tế bào tuyến tiết enzym tiêu hóa — đều bằng ngoại tiết bào.
> - **Độc tố botulinum** (độc tố thịt hộp, pate hỏng) cắt các protein giúp túi hòa màng (nhóm protein **SNARE** — cơ chế vận chuyển và hòa màng của túi được trao **giải Nobel Y học 2013**) → acetylcholin không được giải phóng → **liệt cơ**. Lượng rất nhỏ, tinh chế (Botox) được dùng chữa co cứng cơ và trong thẩm mỹ.

### 2.5. So sánh bốn hình thức ẩm thực bào

| Hình thức | Chiều | Chất được vận chuyển | Đặc hiệu? | Đặc điểm màng |
|---|---|---|---|---|
| **Ẩm bào** | Vào | Dịch ngoại bào và chất tan | **Không** | Lõm vào thành túi |
| **Nội thực bào** | Vào | Chất gắn đặc hiệu (LDL…) | **Có** — cần ổ tiếp nhận | Lõm vào; có thể có **clathrin** (túi áo) |
| **Thực bào** | Vào | Vật lớn (vi khuẩn, mảnh tế bào) | Mồi phải bám vào màng | **Tỏa ra** bao lấy mồi; có **actin** gia cố |
| **Ngoại tiết bào** | **Ra** | Chất tiết, chất thải | — | Túi **hòa vào** màng rồi mở ra |

## 3. Ứng dụng tổng hợp: thuốc tác động lên vận chuyển qua màng

| Thuốc / nhóm | Đích tác động | Kiểu vận chuyển bị ảnh hưởng | Dùng trong |
|---|---|---|---|
| **Digoxin** (glycosid tim) | Bơm Na^+^-K^+^-ATPase | Chủ động | Suy tim, rung nhĩ |
| **Omeprazol** và nhóm ức chế bơm proton | Bơm H^+^/K^+^-ATPase dạ dày | Chủ động | Loét, trào ngược |
| **Furosemid** (lợi tiểu quai) | Đồng vận chuyển Na^+^-K^+^-2Cl^−^ ở nhánh lên quai Henle | Thứ phát (nhờ gradient Na^+^) | Phù, suy tim, tăng huyết áp |
| **Hydroclorothiazid** (lợi tiểu thiazid) | Đồng vận chuyển Na^+^-Cl^−^ ở ống lượn xa | Thứ phát | Tăng huyết áp, phù |
| **Mannitol** (lợi tiểu thẩm thấu) | Được lọc qua cầu thận nhưng không được tái hấp thu, giữ nước lại trong ống thận | Thẩm thấu | Phù não, tăng áp lực nội sọ |
| **Ức chế SGLT2** (dapagliflozin…) | Đồng vận chuyển Na^+^-glucose ở ống thận | Thứ phát | Đái tháo đường type 2, suy tim |
| **Statin** | Ức chế HMG-CoA reductase → tăng số ổ tiếp nhận LDL | Nội thực bào (gián tiếp) | Rối loạn lipid máu |
| **Ức chế PCSK9** (evolocumab, inclisiran) — *bổ sung* | Giữ ổ tiếp nhận LDL khỏi bị phân hủy, cho quay lại màng | Nội thực bào qua ổ tiếp nhận | Tăng cholesterol máu |
| **Điều biến CFTR** (elexacaftor/tezacaftor/ivacaftor) — *bổ sung* | Sửa gấp nếp và tăng mở kênh Cl^−^ CFTR | Kênh (khuếch tán qua kênh) | Bệnh xơ nang |

> [!bay]
> Lợi tiểu quai và thiazid **làm mất K^+^** qua nước tiểu → **hạ K^+^ máu**. Nếu bệnh nhân đang dùng **digoxin**, hạ K^+^ làm **tăng độc tính digoxin**. Đây là một tình huống lâm sàng hay gặp và hay ra thi ở các năm sau.

## Tóm tắt

| Kiểu | Protein? | ATP? | Theo/ngược gradient | Chiều | Ví dụ |
|---|---|---|---|---|---|
| Thụ động (khuếch tán đơn thuần) | Không | Không | Theo | 2 chiều | O~2~, CO~2~, ethanol, urê |
| Có trung gian | Có (permease) | Không | Theo | 2 chiều | Glucose vào hồng cầu; band3 (Cl^−^/HCO~3~^−^ 1:1) |
| Chủ động | Có (bơm) | **Có** | **Ngược được** | **1 chiều** | Na^+^-K^+^ (3 Na ra/2 K vào/1 ATP), Ca^2+^ (cần Mg^2+^), H^+^ (tiêu thể) |
| Ẩm bào | — | — | — | Vào | Dịch ngoại bào, không đặc hiệu |
| Nội thực bào | Ổ tiếp nhận | — | — | Vào | LDL qua túi áo clathrin → tiêu thể |
| Thực bào | — | — | — | Vào | Đại thực bào ăn vi khuẩn; màng tỏa ra, actin gia cố |
| Ngoại tiết bào | — | — | — | Ra | Túi tiết hòa màng, thải chất ra |

- **Yếu tố ảnh hưởng khuếch tán**: kích thước, độ tan trong lipid, gradient nồng độ, mức ion hóa, nhiệt độ (+10 °C → ×1,4), nhu cầu hoạt động, tác động qua lại giữa các chất.
- **Nhược trương** → tế bào động vật trương, tan bào; **ưu trương** → teo bào (thực vật: co nguyên sinh); **đẳng trương** = môi trường sinh lý (NaCl 0,9%, glucose 5%).
