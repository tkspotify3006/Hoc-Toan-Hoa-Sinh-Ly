---
title: Chuyển động trong cơ thể sống
thoi-gian: 120 phút (nên chia 3 buổi)
muc-tieu:
- Giải thích được các hiện tượng do lực tương tác và chuyển động nhiệt của phân tử gây ra: áp suất chất khí, sức căng mặt ngoài, mao dẫn.
- Phân biệt được khuếch tán, thẩm thấu, lọc – siêu lọc và các cơ chế vận chuyển vật chất qua màng tế bào (thụ động, chủ động, thực bào – ẩm bào).
- Dùng các định luật về chất lỏng (liên tục, Bernoulli, độ nhớt, Poiseuille) để giải thích sự chuyển động của máu; dùng các định luật về chất khí (Dalton, Henry) để giải thích sự trao đổi khí.
- Phân tích được hệ xương – cơ như các đòn bẩy và tính được lực, công của cơ.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Phân tử luôn **chuyển động nhiệt hỗn loạn** (E~đ~ = 3/2·kT). Từ đó sinh ra áp suất khí (Dalton: p = Σp~i~), **khuếch tán** (Fick: đi từ nồng độ cao xuống thấp) và **thẩm thấu** (van't Hoff: p = iCRT).
> 2. Lực hút giữa các phân tử ở mặt thoáng tạo **sức căng mặt ngoài** σ. Mặt cong gây áp suất phụ **Δp = 2σ/R** (Laplace), là cơ sở của **mao dẫn** và của **chất hoạt diện phổi**.
> 3. Qua màng có 3 kiểu: **thụ động** (theo gradien, không tốn năng lượng), **chủ động** (ngược gradien, tốn ATP — bơm Na^+^–K^+^: 3 Na^+^ ra, 2 K^+^ vào) và **thực bào – ẩm bào**.
> 4. Máu chảy theo **S·v = const**, **Bernoulli** và **Poiseuille: Q = πR⁴Δp/(8ηL)**. Lưu lượng tỷ lệ với **R⁴**, nên mạch hẹp một nửa thì lưu lượng giảm 16 lần. Áp suất giảm mạnh nhất ở **tiểu động mạch và mao mạch**.
> 5. Khí đi từ nơi **phân áp cao xuống thấp** (O~2~: phế nang 100 → máu → mô 20–40 mmHg; CO~2~ ngược lại). Xương – cơ hoạt động như **3 loại đòn bẩy**; gấp cẳng tay là đòn loại 3 (thiệt lực, lợi về vận tốc).

Bài này rất dài (giáo trình tr. 55–109). Nên học theo 3 phần: **Phần A** (mục 1: phân tử, khuếch tán, thẩm thấu, màng), **Phần B** (mục 2: máu), **Phần C** (mục 3–4: khí, cơ học).

## 1. Chuyển động phân tử và các hiện tượng vận chuyển

### 1.1. Phân tử luôn chuyển động — ba trạng thái của vật chất

Vật chất gồm nguyên tử, phân tử. Chúng luôn **chuyển động hỗn loạn**. Bằng chứng là hai chất khí, hai chất lỏng (thậm chí hai vật rắn áp sát lâu ngày) tự **trộn lẫn** vào nhau. Brown là người đầu tiên quan sát thấy hạt nhỏ lơ lửng chuyển động hỗn loạn do bị phân tử nước va đập; vì thế gọi là **chuyển động Brown**.

Giữa các phân tử có **lực tương tác**, chỉ đáng kể trong phạm vi rất ngắn (cỡ kích thước phân tử, ≈ 10⁻⁸ cm). Khi phân tử ở xa nhau thì lực là **lực hút**, khi quá gần thì là **lực đẩy** (giáo trình tr. 55).

| Trạng thái | Lực tương tác | Chuyển động của phân tử | Hệ quả |
|---|---|---|---|
| **Khí** | Rất yếu | Hoàn toàn hỗn loạn | Không có hình dạng, thể tích riêng |
| **Lỏng** | Mạnh hơn | Dao động quanh vị trí cân bằng, vị trí này lại di chuyển được | Có thể tích, không có hình dạng riêng |
| **Rắn** | Mạnh | Chỉ dao động quanh vị trí cân bằng cố định | Có hình dạng xác định |

Khí và lỏng gọi chung là **chất lưu** (chất chảy được).

### 1.2. Thuyết động học phân tử chất khí

#### a) Khí lý tưởng và phương trình trạng thái

**Khí lý tưởng** là mô hình trong đó: các phân tử chuyển động hỗn loạn, không có phương nào được ưu tiên; thể tích riêng của phân tử không đáng kể so với thể tích bình; lực tương tác giữa các phân tử coi như bằng 0 (chỉ va chạm đàn hồi).

Phương trình trạng thái cho 1 mol khí:

=> p·V~μ~ = R·T

- p: áp suất (Pa); V~μ~: thể tích 1 mol (m³); T: nhiệt độ tuyệt đối (K).
- R: hằng số khí, R ≈ 8,31 J/(mol·K) (giáo trình ghi 8,317·10³ J/(kmol·K), tr. 56).

Với khối khí bất kỳ có khối lượng m (kg), khối lượng mol μ (kg/mol), ta có **phương trình Clapeyron – Mendeleev**:

=> p·V = (m/μ)·R·T

#### b) Phương trình cơ bản của thuyết động học phân tử

Áp suất chất khí do các phân tử **va chạm vào thành bình** gây ra. Áp suất càng lớn khi có càng nhiều phân tử trong một đơn vị thể tích (mật độ n) và mỗi phân tử va càng mạnh (động năng trung bình Ē~đ~):

=> p = (2/3)·n·Ē~đ~

- n: mật độ phân tử (số phân tử/m³); Ē~đ~: động năng tịnh tiến trung bình của một phân tử (J).

Từ phương trình này rút ra 3 hệ quả quan trọng (giáo trình tr. 56–57):

**Hệ quả 1 — nhiệt độ là thước đo chuyển động phân tử.**

=> Ē~đ~ = (3/2)·k·T

- k = R/N~A~ ≈ 1,38·10⁻²³ J/K: **hằng số Boltzmann**.
- Động năng trung bình **không phụ thuộc loại khí**, chỉ tỷ lệ với T. Vì thế chuyển động hỗn loạn của phân tử còn gọi là **chuyển động nhiệt**.
- Vì phân tử luôn chuyển động (Ē~đ~ > 0) nên **không thể đạt tới độ không tuyệt đối** (0 K).

**Hệ quả 2 — định luật Dalton.** Trong hỗn hợp khí cùng nhiệt độ, mỗi khí gây áp suất như thể nó chiếm một mình cả bình:

=> p = p~1~ + p~2~ + … + p~k~

p~i~ gọi là **áp suất riêng phần (phân áp)** của khí thứ i. Đây là cơ sở để hiểu trao đổi khí ở phổi (mục 4).

**Hệ quả 3 — mật độ phân tử.**

=> n = p/(k·T)

Ở **cùng áp suất và nhiệt độ, mọi chất khí có cùng mật độ phân tử**. Ở điều kiện tiêu chuẩn (1 atm = 1,013·10⁵ Pa; 273 K), 1 m³ khí chứa n~0~ ≈ 2,687·10²⁵ phân tử.

> [!vi-du] Tính nhanh
> Động năng trung bình của một phân tử khí ở 37 °C (T = 310 K):
> Ē~đ~ = 1,5 × 1,38·10⁻²³ × 310 ≈ 6,4·10⁻²¹ J.
> Bẫy hay gặp: quên đổi °C sang K (dùng 37 thay vì 310 thì kết quả nhỏ đi gần 8,4 lần).

### 1.3. Sức căng mặt ngoài và hiện tượng mao dẫn

#### a) Vì sao có sức căng mặt ngoài?

Mỗi phân tử chất lỏng chỉ hút những phân tử nằm trong một hình cầu bán kính r~0~ ≈ 10⁻⁹ m quanh nó (**hình cầu tác dụng phân tử**).

- Phân tử **ở sâu bên trong**: bị hút đều về mọi phía nên các lực bù trừ nhau.
- Phân tử **ở lớp mặt ngoài** (dày < 10⁻⁹ m): phía trên là không khí, nên lực hút **không bù trừ**. Hợp lực hướng **vào trong** lòng chất lỏng.

Kết quả là mặt chất lỏng luôn có xu hướng **co lại cho diện tích nhỏ nhất**, giống như một màng cao su bị căng. Lực kéo căng tác dụng dọc theo mặt thoáng, vuông góc với đường ranh giới, gọi là **sức căng mặt ngoài**:

=> ΔF = σ·Δl

- ΔF: sức căng mặt ngoài (N); Δl: độ dài đường ranh giới (m).
- σ: **hệ số căng mặt ngoài** (N/m), bằng lực tác dụng lên 1 m đường ranh giới.

Phân tử ở lớp mặt ngoài có thế năng lớn hơn phân tử bên trong. Muốn tăng diện tích mặt ngoài thêm ΔS phải tốn công, và công này chính là **năng lượng mặt ngoài**:

=> ΔW = σ·ΔS   (ΔW tính bằng J, ΔS tính bằng m²; vì thế σ cũng có đơn vị J/m²)

Một hệ cân bằng bền khi thế năng nhỏ nhất. Do đó giọt chất lỏng không chịu tác dụng của trọng lực sẽ có **dạng hình cầu** (hình có diện tích nhỏ nhất với cùng thể tích). Thí nghiệm: giọt dầu lơ lửng trong hỗn hợp nước – rượu có cùng khối lượng riêng sẽ tròn như quả cầu (giáo trình tr. 59).

#### b) Làm ướt và không làm ướt

Ở chỗ chất lỏng tiếp xúc thành bình, phân tử chất lỏng chịu hai lực: lực hút của các phân tử chất lỏng (F~1~) và lực hút của phân tử thành bình (F~2~). Gọi θ là **góc tiếp xúc** (góc giữa tiếp tuyến mặt thoáng và thành bình phía dưới chất lỏng).

| | **Làm ướt** | **Không làm ướt** |
|---|---|---|
| So sánh lực | F~2~ > F~1~ (thành bình hút mạnh hơn) | F~2~ < F~1~ |
| Góc tiếp xúc | θ < 90° | θ > 90° |
| Mặt thoáng trong ống hẹp | **Lõm** | **Lồi** |
| Ví dụ | Nước – thủy tinh; dầu hỏa – thủy tinh | Thủy ngân – thủy tinh; nước – paraphin |

#### c) Áp suất phụ dưới mặt cong — công thức Laplace

Mặt thoáng cong giống như một màng căng. Sức căng mặt ngoài trên chu vi mặt cong có thành phần **ép vào phía lõm** của mặt cong. Kết quả là chất lỏng chịu thêm một **áp suất phụ**:

=> Δp = 2σ/R

- R: bán kính cong của mặt thoáng (m); Δp tính bằng Pa.
- Mặt **lồi**: Δp hướng xuống (cộng thêm vào áp suất chất lỏng). Mặt **lõm**: Δp hướng lên (Δp mang dấu âm).
- Mặt cong bất kỳ (Laplace): Δp = σ·(1/R~1~ + 1/R~2~), với R~1~, R~2~ là bán kính cong theo hai phương vuông góc.

Điều cần nhớ: **R càng nhỏ thì Δp càng lớn.**

#### d) Hiện tượng mao dẫn

Nhúng ống nhỏ vào chất lỏng: nếu chất lỏng **làm ướt** ống thì mặt lõm, chất lỏng **dâng lên**; nếu **không làm ướt** thì mặt lồi, chất lỏng **tụt xuống**. Đó là **hiện tượng mao dẫn**. Cột chất lỏng dừng lại khi áp suất thủy tĩnh cân bằng với áp suất phụ: 2σ/R = ρgh. Vì vậy:

=> h = 2σ·cosα/(r·ρ·g)   ≈ 2σ/(r·ρ·g) khi làm ướt hoàn toàn (α = 0)

- h: độ cao cột chất lỏng (m); r: bán kính ống (m); ρ: khối lượng riêng (kg/m³); g ≈ 9,8 m/s²; α: góc giữa thành ống và tiếp tuyến mặt thoáng.
- Đo h, r thì tính được σ = h·r·ρ·g/2. Đây là một cách **đo hệ số căng mặt ngoài**.
- **h tỷ lệ nghịch với r**: ống càng nhỏ, nước càng dâng cao.

> [!vi-du] Tính độ dâng mao dẫn
> Nước (σ = 0,073 N/m; ρ = 1000 kg/m³) trong ống thủy tinh bán kính r = 0,1 mm = 10⁻⁴ m:
> h = 2 × 0,073 / (10⁻⁴ × 1000 × 9,8) ≈ 0,15 m = 15 cm.
> Lỗi hay gặp: dùng đường kính thay cho bán kính (kết quả nhỏ đi một nửa), hoặc quên đổi mm sang m.

Mao dẫn có mặt khắp nơi: vật xốp hút nước (bông đã tẩy mỡ thấm nước rất tốt, bông thô còn mỡ thì không); lông thú, lông chim có chất nhờn nên không bị ướt; bôi dầu mỡ lên kim loại để nước không len vào lỗ nhỏ. Ở thực vật, ống dẫn nhựa có đường kính vài phần trăm milimét nên nhựa leo được vài mét nhờ mao dẫn; với cây cao hàng chục mét còn cần thêm **sức thẩm thấu** của tế bào sống (giáo trình tr. 62).

> [!ung-dung] Chất hoạt diện phổi (surfactant) — Laplace trong phế nang
> - Mỗi phế nang giống một bọt khí nhỏ phủ lớp dịch mỏng. Theo Δp = 2σ/R, **phế nang càng nhỏ thì áp suất co xẹp càng lớn**. Nếu σ của lớp dịch giống nước, phế nang nhỏ sẽ xẹp và đẩy khí sang phế nang lớn.
> - Tế bào phế nang type II tiết **surfactant** (chủ yếu là phospholipid). Chất này làm **giảm mạnh σ**, và giảm càng nhiều khi phế nang càng nhỏ lại. Nhờ đó các phế nang to nhỏ vẫn ổn định và phổi nở ra dễ hơn.
> - **Trẻ sinh non** chưa đủ surfactant nên phổi khó nở, phế nang xẹp, gây **hội chứng suy hô hấp sơ sinh (bệnh màng trong)**. Phòng và điều trị: tiêm corticoid cho mẹ dọa sinh non để thúc phổi thai trưởng thành, bơm surfactant vào khí quản trẻ.
> - Ví dụ số: phế nang R = 0,1 mm, nếu σ = 0,05 N/m thì Δp = 2 × 0,05/10⁻⁴ = 1000 Pa ≈ 7,5 mmHg. Đây là một áp suất xẹp đáng kể so với áp suất thở bình thường chỉ vài mmHg.

### 1.4. Khuếch tán

#### a) Bản chất

Đặt hai tập hợp phân tử cạnh nhau, chúng **tự xuyên vào nhau** do chuyển động nhiệt. Nếu nồng độ không đồng đều, phân tử sẽ dịch chuyển **từ nơi nồng độ cao đến nơi nồng độ thấp** cho tới khi nồng độ bằng nhau ở mọi điểm. Đó là **khuếch tán**.

Vì sao? Chuyển động nhiệt không có phương ưu tiên. Nhưng ở vùng đặc có nhiều phân tử hơn để "đi sang" vùng loãng, nên **dòng thực** luôn hướng từ đặc sang loãng. Trạng thái cuối cùng (nồng độ đồng đều) là trạng thái có **xác suất nhiệt động lớn nhất, entropi cực đại**.

Thí nghiệm của giáo trình: đổ nhẹ nước lên trên siro đặc có màu. Lúc đầu có mặt phân cách rõ, sau một thời gian ranh giới mờ dần thành một vùng chuyển tiếp màu nhạt dần (giáo trình tr. 62–63).

#### b) Định luật Fick

=> dn = −D·S·(dC/dx)·dt

- dn: số phân tử (hoặc số mol) khuếch tán qua diện tích S (m²) trong thời gian dt (s).
- dC/dx: **gradien nồng độ** (độ biến thiên nồng độ theo khoảng cách).
- D: **hệ số khuếch tán** (m²/s). Dấu "−" cho biết phân tử đi **ngược chiều tăng nồng độ**, tức từ cao xuống thấp.

Mật độ dòng khuếch tán (số phân tử qua 1 m² trong 1 s): Φ = −D·ΔC/Δx.

**D phụ thuộc vào:** khối lượng và hình dạng phân tử; độ nhớt dung môi; nhiệt độ. Einstein đã lập hệ thức:

=> D = k·T/(6π·r·η)

- r: bán kính phân tử (coi như hình cầu, m); η: độ nhớt dung môi (Pa·s); T: nhiệt độ tuyệt đối (K).
- Biểu diễn theo khối lượng phân tử μ: D = A/∛μ (A là hằng số phụ thuộc nhiệt độ và dung môi).

Kết luận: **khuếch tán nhanh hơn khi nhiệt độ cao; chậm hơn khi phân tử to và dung môi nhớt.**

| Chất (trong nước, 20 °C) | Phân tử lượng μ | D (cm²/ngày) |
|---|---|---|
| Urê | 60 | 0,81 |
| Manitol | 182 | 0,40 |
| Saccarose | 342 | 0,31 |
| Hemoglobin | 63 000 | 0,059 |
| Albumin huyết thanh | 69 000 | 0,060 |

*(Bảng 3.1, giáo trình tr. 64.)* Phân tử lượng tăng hơn 1000 lần nhưng D chỉ giảm khoảng 14 lần, đúng như quan hệ D ∝ 1/∛μ.

> [!bay]
> - Khuếch tán xảy ra với **cả chất tan lẫn dung môi**. Dung môi khuếch tán **ngược chiều** chất tan: từ nơi có nhiều dung môi (dung dịch loãng) sang nơi ít dung môi (dung dịch đặc).
> - Định luật Fick là định luật **thực nghiệm**.
> - D tăng theo **nhiệt độ**, giảm khi **phân tử lượng** và **độ nhớt** tăng. Đề hay hỏi "D không phụ thuộc yếu tố nào".

#### c) Khuếch tán qua màng xốp thấm tự do

**Màng xốp thấm tự do** có lỗ rất lớn so với phân tử. Khuếch tán qua màng giống như không có màng nhưng **chậm hơn**, vì phân tử chỉ đi qua được phần diện tích các lỗ. Nếu hai bên màng giữ nồng độ C~1~ và C~2~ không đổi, màng dày l:

=> Δn = −D·(S/l)·(C~2~ − C~1~)·Δt

S/l gọi là **hằng số màng**, xác định được bằng thực nghiệm. Theo thời gian, chênh lệch nồng độ hai bên giảm dần cho đến **cân bằng khuếch tán**: số phân tử đi theo hai chiều bằng nhau (giáo trình tr. 64–65).

### 1.5. Thẩm thấu

#### a) Màng bán thấm và thí nghiệm thẩm thấu

**Màng bán thấm** chỉ cho một hoặc vài loại phân tử đi qua (ví dụ cho nước qua, giữ đường lại). Hầu hết màng trong cơ thể là màng bán thấm.

**Thẩm thấu** là sự vận chuyển **dung môi** qua màng bán thấm ngăn cách hai dung dịch khác nhau, khi không có ngoại lực tác dụng (trọng lực, lực điện, lực đẩy piston…).

![Hình 1. Thẩm thấu: thí nghiệm thẩm thấu kế và hồng cầu trong ba loại dung dịch](tham-thau.svg)

Thí nghiệm (giáo trình tr. 65–66): ống chứa nước đường, đáy bịt màng bán thấm, nhúng vào chậu nước cất. Mực nước đường trong ống dâng lên rồi dừng ở độ cao h. Nước ở chậu không có đường.

**Vì sao nước đi vào?** Phía nước cất, mọi phân tử va vào màng đều là phân tử nước. Phía dung dịch, một phần mặt màng bị phân tử đường chiếm chỗ. Vì vậy số phân tử nước đi vào ống nhiều hơn số đi ra. Mực trong ống dâng lên, tạo áp suất thủy tĩnh đẩy nước quay lại. Khi hai dòng bằng nhau thì đạt **cân bằng thẩm thấu**. Áp suất thủy tĩnh ρgh lúc đó bằng **áp suất thẩm thấu** của dung dịch.

> [!ghi-nho] Định nghĩa
> **Áp suất thẩm thấu** là áp suất cần đặt lên dung dịch để **ngừng** sự thẩm thấu của dung môi vào dung dịch đó qua màng bán thấm. Nó do **chất tan** gây ra. Nước luôn đi về phía dung dịch có áp suất thẩm thấu **cao hơn** (đặc hơn).

#### b) Định luật van't Hoff

Với dung dịch loãng, chất **không điện ly**, van't Hoff thấy chất tan cư xử giống khí lý tưởng:

=> p = C·R·T

- p: áp suất thẩm thấu (Pa); C: nồng độ mol (mol/m³; nhớ 1 mol/L = 1000 mol/m³); R = 8,31 J/(mol·K); T: nhiệt độ tuyệt đối (K).
- Viết theo khối lượng: p = m·R·T/(μ·V), nên với cùng khối lượng chất tan, **chất có phân tử lượng nhỏ gây áp suất thẩm thấu lớn hơn**.

Với **dung dịch chất điện ly**, mỗi phân tử phân ly thành nhiều ion, làm tăng số tiểu phân. Gọi a là độ điện ly (tỷ lệ phân tử bị phân ly) và n là số ion tạo ra từ một phân tử:

=> p = i·C·R·T, với i = 1 + a·(n − 1)

i gọi là **hệ số đẳng thấm** (hệ số van't Hoff). Ví dụ NaCl phân ly hoàn toàn (a = 1, n = 2) nên i = 2.

> [!vi-du] Vì sao NaCl 0,9% là "nước muối sinh lý"?
> - C = 9 g/L ÷ 58,5 g/mol ≈ 0,154 mol/L = 154 mol/m³; i = 2.
> - p = 2 × 154 × 8,31 × 310 ≈ 7,9·10⁵ Pa ≈ 7,8 atm. Giá trị này gần bằng áp suất thẩm thấu của máu (**7,7 atm ở 37 °C**, theo giáo trình tr. 69).
> - Thực tế NaCl không phân ly "lý tưởng" hoàn toàn trong nước, nên hệ số hiệu dụng ≈ 1,86. Do đó NaCl 0,9% có độ thẩm thấu ≈ 286 mOsm/L, rất gần huyết tương (≈ 275–295 mOsm/kg; xem hs-15, hs-19).
> - Glucose 5%: 50 g/L ÷ 180 ≈ 0,278 mol/L → p ≈ 278 × 8,31 × 310 ≈ 7,2·10⁵ Pa ≈ 7,1 atm, cũng gần đẳng trương.

#### c) Cân bằng Donnan

Trong tế bào có **ion đại phân tử** (protein mang điện, ký hiệu R^−^) không qua được màng, còn ion nhỏ (Na^+^, Cl^−^) thì qua được. Xét phần I chứa R^−^Na^+^ (nồng độ C~1~), phần II chứa Na^+^Cl^−^ (nồng độ C~2~).

- Na^+^ không thể qua màng **một mình** (sẽ làm một bên tích điện dương, tạo điện trường cản lại). Na^+^ và Cl^−^ đi qua **từng cặp** thì dễ dàng.
- Khi cân bằng (sau khi x mol/L NaCl đã chuyển từ II sang I): [Na^+^]~I~·[Cl^−^]~I~ = [Na^+^]~II~·[Cl^−^]~II~, đồng thời mỗi bên trung hòa điện. Giải ra:

=> x = C~2~²/(C~1~ + 2C~2~)

| Trường hợp | Lượng NaCl đi vào phần I |
|---|---|
| C~1~ ≪ C~2~ (ít protein) | x ≈ C~2~/2: một nửa |
| C~1~ = C~2~ | x = C~2~/3: một phần ba |
| C~1~ ≫ C~2~ (rất nhiều protein) | x ≈ 0: NaCl hầu như không vào |

**Ý nghĩa** (giáo trình tr. 69): tế bào chứa protein luôn hút thêm một lượng chất điện ly từ môi trường. Vì vậy áp suất thẩm thấu trong tế bào luôn **lớn hơn** môi trường một chút, đây là động lực đưa nước về phía tế bào sống.

#### d) Ý nghĩa sinh học của áp suất thẩm thấu

- Giá trị p~tt~ khác nhau giữa các loài, các cơ quan: dịch cơ thể ếch có p~tt~ nhỏ hơn người; sinh vật sống ở nước biển có p~tt~ lớn. Thực vật hút nước từ đất nhờ p~tt~ = 5–20 atm; có cây sa mạc tới 170 atm. Tế bào lá và ngọn có p~tt~ lớn hơn ở thân và rễ.
- Ở người, máu, bạch huyết, dịch mô có **p~tt~ ≈ 7,7 atm** (37 °C). Chỉ cần thay đổi nhỏ cũng gây rối loạn:
  - p~tt~ **giảm** (đưa vào nhiều nước, mất muối): có thể gây **co giật, nôn**.
  - p~tt~ **tăng** (ăn nhiều muối): nước phân bố lại, có thể gây **phù nề**; mất nước ở niêm mạc gây **khát**, rối loạn thần kinh.
- **Thận** đóng vai trò chính trong điều chỉnh áp suất thẩm thấu.

| Dung dịch so với dung dịch chuẩn (huyết tương) | Tên gọi | Tế bào (hồng cầu) đặt vào sẽ |
|---|---|---|
| p~tt~ bằng | **Đẳng trương** | Giữ nguyên hình dạng |
| p~tt~ lớn hơn | **Ưu trương** | Mất nước, **teo lại** (nhăn) |
| p~tt~ nhỏ hơn | **Nhược trương** | Hút nước, phồng lên rồi **vỡ** (tan máu) |

> [!ung-dung] Dịch truyền và thẩm thấu
> - **NaCl 0,9%, Ringer lactat** gần đẳng trương nên dùng để bù dịch, rửa hồng cầu, pha thuốc.
> - **Không bao giờ truyền nước cất vào tĩnh mạch**, vì nước cất nhược trương rất mạnh, gây tan máu.
> - **Mannitol 20%** là dịch ưu trương: kéo nước từ mô ra lòng mạch, dùng để giảm áp lực nội sọ (phù não). NaCl 3% cũng ưu trương, dùng khi hạ natri máu nặng có triệu chứng.
> - **Glucose 5%** đẳng trương khi ở trong chai. Nhưng sau khi vào cơ thể, glucose bị tế bào sử dụng hết, chỉ còn lại nước tự do. Vì vậy về mặt sinh lý, glucose 5% tác động như **dịch nhược trương**, không dùng để bù dịch cho người bị phù não.

### 1.6. Lọc và siêu lọc

**Lọc** là hiện tượng dung dịch chảy thành dòng qua các lỗ của màng nhờ **chênh lệch áp suất thủy tĩnh** (đẩy hoặc hút). Coi mỗi lỗ là một ống trụ nhỏ, áp dụng Poiseuille (mục 2.3):

=> J~V~ = ΔV/Δt = π·r⁴·N·Δp/(8·η·l) = L·Δp

- J~V~: thể tích dung dịch qua 1 m² màng trong 1 s; r: bán kính lỗ; N: số lỗ trên 1 m² màng; η: độ nhớt; l: chiều dài lỗ (độ dày màng); Δp: hiệu áp suất hai đầu lỗ; L: **hệ số lọc**.
- Tốc độ lọc phụ thuộc **Δp, độ nhớt, kích thước và số lỗ**. Chất có kích thước lớn hơn lỗ không qua được.

**Siêu lọc** là lọc qua màng mà trong đó: màng **giữ lại các đại phân tử** (protein) có phân tử lượng lớn hơn một giới hạn; các phân tử và ion nhỏ qua được và tuân theo cân bằng Donnan; đồng thời có cả **gradien áp suất thủy tĩnh** làm thay đổi lưu lượng, thậm chí đổi chiều dòng.

#### a) Trao đổi dịch ở mao mạch (cân bằng Starling)

Trao đổi nước ở thành mao mạch là một hiện tượng siêu lọc. Có hai lực ngược chiều:

- **Áp suất thủy tĩnh (huyết áp)** đẩy nước **ra** khỏi lòng mạch.
- **Áp suất thẩm thấu keo** (do protein huyết tương, chủ yếu albumin, không qua được thành mạch) kéo nước **vào** lòng mạch.

Số liệu của giáo trình (tr. 71):

| | Đầu mao động mạch | Đầu mao tĩnh mạch |
|---|---|---|
| Huyết áp trong mạch | 4 kPa | 2 kPa |
| Áp suất thủy tĩnh dịch mô | 0,8 kPa | 0,8 kPa |
| → Áp suất thủy tĩnh thực (đẩy ra) | 3,2 kPa | 1,2 kPa |
| Chênh áp keo (máu 3,3 − dịch mô 1,3, kéo vào) | 2 kPa | 2 kPa |
| **Kết quả** | **+1,2 kPa: nước ra mô** | **−0,8 kPa: nước về mạch** |

(1 kPa ≈ 7,5 mmHg.) Phần dịch dư còn lại ở mô được hệ **bạch huyết** đưa về tuần hoàn.

> [!ung-dung] Phù — khi cân bằng Starling bị phá vỡ
> Phù là ứ dịch ở khoảng gian bào. Bốn cơ chế, mỗi cơ chế ứng với một "lực":
> - **Tăng áp suất thủy tĩnh mao mạch**: suy tim (phù chân, phù phổi), suy van tĩnh mạch, đứng lâu.
> - **Giảm áp suất keo** do giảm albumin máu: xơ gan, hội chứng thận hư, suy dinh dưỡng.
> - **Tăng tính thấm thành mạch** (protein lọt ra ngoài): viêm, dị ứng, bỏng.
> - **Tắc bạch huyết**: sau nạo vét hạch, giun chỉ.

#### b) Siêu lọc ở cầu thận

Màng lọc cầu thận gồm thành mao mạch cầu thận và thành bọc Bowman. Màng này xốp hơn mao mạch thường khoảng **25 lần**. Ba áp suất quyết định (giáo trình tr. 72):

- Huyết áp mao mạch cầu thận p~h~ = 70 mmHg (đẩy dịch vào bọc Bowman).
- Áp suất keo huyết tương p~k~ = 32 mmHg (giữ lại).
- Áp suất thủy tĩnh trong bọc Bowman p~b~ = 14 mmHg (cản lại).

=> Áp suất lọc p~e~ = p~h~ − (p~k~ + p~b~) = 70 − (32 + 14) = 24 mmHg

Dịch lọc **không có hồng cầu** và rất ít protein. Các ion nhỏ phân bố theo cân bằng Donnan.

> [!ung-dung] Ứng dụng của áp suất lọc
> - Khi **tụt huyết áp nặng** (sốc), p~h~ giảm. Nếu p~h~ < 46 mmHg thì áp suất lọc gần bằng 0, thận ngừng tạo nước tiểu (thiểu niệu, vô niệu).
> - **Thẩm phân máu (chạy thận nhân tạo)**: máu từ động mạch chảy qua một bên màng, phía bên kia là **dịch thẩm phân** có nồng độ muối khoáng, glucose phù hợp. Chất cần loại bỏ (urê, ion dư thừa K^+^, phosphat…) **khuếch tán** qua màng từ máu sang dịch thẩm phân, sau đó máu được trả về tĩnh mạch. Mỗi lần lọc kéo dài 2–4 giờ. Màng đóng vai trò như một cái sàng, dùng cho suy thận hoặc ngộ độc.

### 1.7. Vận chuyển vật chất qua màng tế bào

#### a) Màng tế bào

Về mặt vật lý, tế bào là một **hệ nhiệt động mở**: luôn trao đổi chất và năng lượng với môi trường. Sự ổn định của nó là **cân bằng động**, không phải cân bằng tĩnh.

Màng tế bào có **3 vai trò**: bao bọc, phân định ranh giới và bảo vệ tế bào; tiếp nhận, xử lý thông tin (nhận diện tế bào quen – lạ, đáp ứng với thuốc, hormon…); trao đổi chất và năng lượng với môi trường.

Số liệu cấu trúc (giáo trình tr. 73):

- Dày **50–120 Å** (5–12 nm).
- Có lỗ đường kính **7–8 Å**, khoảng 10¹⁰ lỗ/cm², nhưng tổng diện tích lỗ chỉ ≈ **0,06%** bề mặt.
- Tính chất chung: **lưỡng chiết quang, sức căng mặt ngoài nhỏ, điện trở lớn, cấu trúc không đồng nhất**.
- Thành phần: giữa là **hai lớp phospholipid** (cản ion và chất tan trong nước); hai bên là protein dạng sợi (tạo tính đàn hồi, sức căng mặt ngoài nhỏ); ngoài cùng là protein dạng cầu, glycolipid (nhóm COOH làm mặt ngoài màng **tích điện âm**).

**Bốn loại màng sinh vật** theo khả năng cho chất đi qua:

1. Gần như bán thấm lý tưởng: chỉ cho **nước** qua.
2. Cho nước và một số phân tử có cấu tạo tinh thể qua → phần lớn **màng tế bào**.
3. Cho mọi chất hòa tan qua, **trừ chất keo** → **thành mao mạch**.
4. Trạng thái "rây": cho cả keo đi qua. Loại này rất hiếm, chỉ gặp khi tổn thương, ví dụ thành mao mạch khi **thiếu oxy** để lọt protein.

**Hai con đường** vào tế bào:

- **Hòa tan vào lớp lipid**: chất hữu cơ không tan trong nước, chất có nhóm không phân cực (CH~3~, C~2~H~5~, C~6~H~5~).
- **Đi qua lỗ màng**: ion, chất tan trong nước, chất có nhóm phân cực (OH, COOH, NH~2~). Hạt mang điện trái dấu với lỗ thì dễ vào, hạt cùng dấu bị đẩy ra. H^+^ và OH^−^ tuy nhỏ nhưng thực tế không tự vào được. Vì vậy màng **không thấm acid, base mạnh** (phân ly hoàn toàn thành ion), nhưng **thấm dễ acid, base yếu** (còn dạng phân tử không mang điện).

> [!ung-dung] Thuốc qua màng
> Phần lớn thuốc qua màng bằng cách **khuếch tán thụ động qua lớp lipid**, ở **dạng không ion hóa**. Đó là lý do pH ảnh hưởng đến hấp thu: aspirin (acid yếu) ở dạ dày có pH thấp phần lớn ở dạng không ion hóa nên được hấp thu một phần ngay tại dạ dày. Kiềm hóa nước tiểu làm thuốc acid yếu (ví dụ salicylat, phenobarbital) bị ion hóa, không tái hấp thu được, nên thải nhanh hơn khi ngộ độc.

#### b) Ba loại vận chuyển

| | **Thụ động** | **Chủ động (tích cực)** | **Thực bào – ẩm bào** |
|---|---|---|---|
| Chiều | **Theo** gradien | **Ngược** gradien nồng độ / điện hóa | Bao gói vật liệu |
| Năng lượng | Không cần năng lượng của tế bào (dùng năng lượng sẵn có của gradien) | Cần (ATP, phân hủy glycogen, hô hấp) | Cần (ATP) |
| Chất mang | Không cần (đơn giản) hoặc có (liên hợp, trao đổi) | Luôn cần chất mang | Không |
| Ví dụ | Nước, anion; glucose, acid amin (amino acid) (liên hợp) | Bơm Na^+^–K^+^, bơm H^+^ dạ dày | Bạch cầu nuốt vi khuẩn; tế bào hấp thu protein |

#### c) Vận chuyển thụ động

Động lực là các **gradien** ở hai bên màng. Chiều vận chuyển do **tổng các vectơ gradien** quyết định. Năm loại gradien:

- **Gradien nồng độ**: chênh lệch nồng độ một chất trong và ngoài tế bào.
- **Gradien thẩm thấu**: chênh lệch áp suất thẩm thấu. Ở tế bào sống, chênh lệch áp suất thẩm thấu **keo** rất quan trọng.
- **Gradien màng**: do màng bán thấm cho phân tử nhỏ qua dễ, đại phân tử khó.
- **Gradien độ hòa tan**: ở ranh giới hai pha không trộn lẫn, chất tan phân bố theo **định luật phân bố Nernst**: k = C~2~/C~1~ = hằng số (k là **hệ số phân bố**).
- **Gradien điện hóa**: do chênh lệch thế điện hóa. Ion có thể bị đẩy ngược gradien nồng độ nếu gradien điện mạnh hơn.

Vì có nhiều gradien cùng lúc, vận chuyển không chỉ phụ thuộc chênh lệch nồng độ. Ví dụ nồng độ **K^+^ trong tế bào gấp 30–50 lần** trong huyết thanh. Khi tế bào sắp chết, tính thấm tăng không thuận nghịch và tế bào **mất khả năng vận chuyển chọn lọc**.

Cơ chế chính của vận chuyển thụ động là khuếch tán, gồm ba dạng:

**Khuếch tán đơn giản.** Chất đi theo gradien nồng độ, không cần chất mang (nước, các anion). Qua màng dày l:

=> Φ = −(P/k)·ΔC, với P = k·D/l là **hệ số thấm** của màng

(Viết theo giáo trình tr. 76. Cách viết thường gặp hiện nay: nếu ΔC là chênh nồng độ của dung dịch **hai bên** màng và k là hệ số phân bố màng/nước thì Φ = −P·ΔC; chất càng tan trong lipid (k lớn) thì thấm càng nhanh.)

Với chất điện ly, D phụ thuộc độ linh động của ion dương (u^+^) và ion âm (u^−^): D = (2RT/F²)·u^+^u^−^/(u^+^ + u^−^), F là hằng số Faraday. Tốc độ khuếch tán đơn giản phụ thuộc **độ tan trong lipid** và **kích thước phân tử**: chất tan trong nước có phân tử **> 8 Å** (lớn hơn lỗ) thường không qua. Ion thường bị **hydrat hóa** (bọc vỏ nước) nên "to" hơn và khuếch tán chậm hơn. Lỗ màng tích điện dương nên **cation** đi qua khó khăn và chậm chạp.

**Khuếch tán liên hợp (có chất mang, "khuếch tán được tạo thuận").** Vẫn đi theo gradien nồng độ, nhưng phân tử chỉ qua được khi gắn với **chất mang** M: M + C ⇌ MC. Glucose, glycerin, acid amin vận chuyển theo cách này. Đặc điểm:

- **Động học bão hòa**: nồng độ thấp thì tốc độ tỷ lệ với nồng độ; nồng độ cao thì tốc độ đạt giới hạn vì chất mang đã "no".
- **Đặc hiệu và cạnh tranh**: chất mang chỉ gắn với một loại hoặc các chất có cấu trúc rất giống nhau, ví dụ các đường giống nhau tranh nhau chất mang.

**Khuếch tán trao đổi.** Chất mang đi vòng: đưa một phân tử ra ngoài rồi gắn ngay một phân tử cùng loại ở ngoài đưa vào trong. Ví dụ: dùng Na^+^ đánh dấu phóng xạ thấy Na^+^ hồng cầu đổi chỗ rất nhanh với Na^+^ huyết thanh, trong khi nồng độ hai bên không đổi.

#### d) Vận chuyển chủ động

Hai đặc trưng: **(1) ngược gradien** nồng độ hoặc điện hóa; **(2) luôn cần năng lượng** (thủy phân ATP, phân hủy glycogen, hô hấp). Chiều vào tế bào gọi là **tích tụ**, chiều ra gọi là **xuất tiết**.

Ba cơ chế:

- **Chuyển dịch nhóm**: cơ chất bị biến đổi hóa học (tạo liên kết cộng hóa trị mới) trong khi vận chuyển.
- **Tích cực tiên phát (nguyên phát)**: năng lượng dùng trực tiếp để thay đổi hình dạng chất mang. Ví dụ: **bơm Na^+^–K^+^**.
- **Tích cực thứ phát**: Na^+^ được bơm ra trước, tạo gradien điện hóa; gradien này kéo theo chất thứ hai như **đường, acid amin** (đồng vận chuyển).

**Bơm Na^+^–K^+^** (giáo trình tr. 79–80):

- Chỉ hoạt động khi có **ATP và Mg^2+^**. Enzym thủy phân ATP là **Na^+^,K^+^-ATPase**, chỉ hoạt động tối đa khi có mặt cả Na^+^ và K^+^.
- Tỷ lệ: **1 ATP → 3 Na^+^ ra ngoài, 2 K^+^ vào trong**. Hodgkin tính rằng năng lượng 1 mol ATP đủ để chuyển 1 mol ion ngược gradien điện hóa. Tỷ lệ "1 ATP : 1 ion" như vậy chỉ đúng với bơm H^+^ ở dạ dày.
- Cơ chế 6 giai đoạn: Na^+^ gắn vào chất mang M~1~ ở mặt trong, được phosphoryl hóa (phức hợp NaM~1~–P); chất mang đổi dạng thành M~2~ (ái lực với Na^+^ yếu) và thả Na^+^ ra ngoài; M~2~ gắn K^+^ ở mặt ngoài, mang vào trong rồi đổi lại thành M~1~ (ái lực với K^+^ yếu) và thả K^+^ ở mặt trong.
- Nếu hai bên màng có phân bố K^+^, Na^+^ không đều thì nhất thiết trong màng phải có ATPase này.

> [!ung-dung] Bơm ion và thuốc
> - **Digoxin** (glycosid tim, chiết từ lá cây mao địa hoàng) ức chế Na^+^,K^+^-ATPase ở cơ tim, gián tiếp làm tăng Ca^2+^ trong tế bào, giúp tim co bóp mạnh hơn.
> - **Thuốc ức chế bơm proton** (omeprazol…) ức chế bơm H^+^/K^+^-ATPase của tế bào thành dạ dày, dùng điều trị loét dạ dày – tá tràng, trào ngược.
> - **Dung dịch bù nước uống (ORS)** chứa glucose và Na^+^ đúng tỷ lệ để tận dụng **đồng vận chuyển Na^+^–glucose** (tích cực thứ phát) ở ruột. Nước được kéo theo, nên ORS hiệu quả khi tiêu chảy.

#### e) Thực bào và ẩm bào

Màng tế bào **lõm vào, bao lấy** vật liệu bên ngoài rồi khép lại thành **không bào** đi vào trong tế bào chất, mà màng vẫn nguyên vẹn.

- **Thực bào** ("tế bào ăn"): không bào lớn chứa phần tử có hình dạng (vi khuẩn, mảnh tế bào). Gặp ở vi sinh vật, **bạch cầu hạt**, tế bào **hệ võng mạc nội mô** (đại thực bào).
- **Ẩm bào** ("tế bào uống"): không bào rất nhỏ chứa chất hòa tan (protein, acid amin…). Protein tập trung trên màng với nồng độ có thể gấp 50 lần môi trường, sau đó màng lõm vào.
- Cả hai đều **cần ATP** và **có chọn lọc**. Đây là con đường cho các phân tử lớn (protein, acid nucleic) vào tế bào. Tế bào có thể hấp thu cả **chất độc**. Vật liệu được tiêu hóa bằng enzym của **lysosom**.
- Quá trình ngược lại (không bào dính vào màng và đổ chất ra ngoài, rõ nhất ở tế bào tiết) gọi là **bài xuất** (xuất bào).

> [!bay]
> - **Khuếch tán liên hợp vẫn là vận chuyển thụ động**, tuy có chất mang. Điểm phân biệt với vận chuyển chủ động là **chiều** (theo hay ngược gradien) và **có tiêu tốn năng lượng tế bào hay không**.
> - Bơm Na^+^–K^+^ là **tích cực tiên phát**. Hấp thu glucose cùng Na^+^ ở ruột là **tích cực thứ phát**.
> - Bơm Na^+^–K^+^: **3 Na^+^ ra – 2 K^+^ vào**. Không nhầm ngược chiều.

> [!yhct] Ngâm và sắc thuốc: mao dẫn và khuếch tán
> Đây là các quá trình vật lý đã được chứng minh, giải thích được nhiều quy tắc bào chế:
> - **Ngâm trước khi sắc**: dược liệu khô hút nước chủ yếu nhờ **mao dẫn** (mạch, khe nhỏ) và sự **trương nở** của thành tế bào, tinh bột, chất nhầy khi ngấm nước. Tế bào dược liệu khô đã chết, màng không còn là màng bán thấm đúng nghĩa, nên vai trò của thẩm thấu ở đây chỉ là phụ. Mô trương nở, hoạt chất hòa tan, sau đó **khuếch tán ra** dịch sắc.
> - Theo Fick, tốc độ chiết tăng khi: **gradien nồng độ lớn** (đủ nước, sắc nhiều lần, chia nước thứ nhất – thứ hai); **quãng đường khuếch tán ngắn** (thái mỏng, giã dập hạt cứng, "đập vụn" khoáng vật); **D lớn** do nhiệt độ cao (D ∝ T/η, nước nóng còn kém nhớt hơn).
> - Phân tử lớn (polysaccharid, protein) có D nhỏ nên cần thời gian dài hơn. Đây **có thể** là một phần lý do của kinh nghiệm sắc lâu vị bổ; còn sắc nhanh vị giải biểu có tinh dầu là vì tinh dầu **dễ bay hơi** theo hơi nước. Thời gian sắc tối ưu cho từng vị vẫn cần nghiên cứu định lượng (nhiệt độ cao kéo dài cũng có thể phân hủy một số hoạt chất).
> - Quan niệm YHCT về "khí vị", "quy kinh" của thang thuốc nằm ngoài phạm vi vật lý. Khuếch tán chỉ giải thích **lượng hoạt chất chiết ra được**, không giải thích tác dụng.

## 2. Chuyển động của chất lỏng và sự vận chuyển máu

### 2.1. Dung dịch trong cơ thể

Phân tử và ion trong cơ thể có ba vai trò: **cấu trúc**, **dự trữ – vận chuyển**, và **giải phóng năng lượng**. Một số phân tử (ADN/DNA) mang **thông tin di truyền**.

Cơ thể có hai dung môi chính là **nước và lipid**. Có 4 loại dung dịch (giáo trình tr. 81–82):

| Loại | Đặc điểm |
|---|---|
| Dung dịch **không điện ly** | Hệ đồng nhất, chất tan không phân ly thành ion. Mọi tính chất phụ thuộc **nồng độ**. |
| Dung dịch **điện ly** | Chất tan phân ly thành ion. Độ điện ly phụ thuộc dung môi, nhiệt độ, nồng độ. Hai loại trên gọi chung là **dung dịch thực**. |
| Dung dịch **keo** | Hệ phân tán **dị thể**; hạt keo kích thước **1–100 nm**. Môi trường là nước thì gọi là **sol nước**, là chất lỏng hữu cơ thì gọi là sol hữu cơ. Sol lỏng gồm **keo thân dịch** và **keo sơ dịch**. |
| Dung dịch **đại phân tử** | Phân tử lượng từ hàng chục nghìn đến hàng chục triệu Dalton (protein, polymer). Có tính chất chung của dung dịch keo. |

### 2.2. Phương trình liên tục và định luật Bernoulli

**Chất lỏng lý tưởng** là chất lỏng **tuyệt đối không nén được và không có ma sát trong**. Ở áp suất và nhiệt độ thường, có thể coi gần đúng chất lỏng là lý tưởng.

**Phương trình liên tục (bảo toàn thể tích).** Chất lỏng không nén được, nên thể tích chảy qua mọi tiết diện trong 1 giây là như nhau:

=> S~1~·v~1~ = S~2~·v~2~ = Q (lưu lượng, m³/s)

S: tiết diện (m²); v: tốc độ chảy (m/s). **Nơi tiết diện nhỏ chất lỏng chảy nhanh, nơi tiết diện lớn chảy chậm.**

**Định luật Bernoulli (bảo toàn năng lượng cho chất lỏng lý tưởng).**

=> p + ρ·g·h + ρ·v²/2 = hằng số

- p: áp suất tĩnh (Pa); ρgh: áp suất do độ cao (thế năng, Pa); ρv²/2: áp suất động (động năng, Pa).
- Ống nằm ngang (h không đổi): p + ρv²/2 = const. **Chỗ chảy nhanh thì áp suất giảm, chỗ chảy chậm thì áp suất tăng.**

> [!ung-dung] Bernoulli, phương trình liên tục và mạch hẹp
> - Tại **chỗ hẹp** của động mạch (mảng xơ vữa), tiết diện nhỏ nên máu chảy nhanh hơn (phương trình liên tục). **Siêu âm Doppler** đo tốc độ tăng vọt này để đánh giá mức độ hẹp van tim, hẹp động mạch cảnh.
> - Theo Bernoulli, áp suất tĩnh ngay tại chỗ hẹp **giảm**. Ở động mạch có thành mềm, áp suất bên giảm có thể làm mạch xẹp thêm từng lúc, góp phần gây rung thành mạch và **tiếng thổi**.
> - Trong siêu âm tim, chênh áp qua van hẹp được ước tính từ tốc độ dòng phụt bằng **phương trình Bernoulli giản lược**: Δp (mmHg) ≈ 4·v² (v tính bằng m/s).

### 2.3. Độ nhớt và công thức Poiseuille

#### a) Nội ma sát — độ nhớt

Chất lỏng **thực** có ma sát trong và nén được một chút. Dòng chảy có hai dạng: **chảy thành lớp (chảy tầng)** — các phần tử chuyển động song song với trục ống; và **chảy xoáy (chảy rối)**. Chảy thành lớp chỉ có khi tốc độ không lớn lắm và tiết diện ống nhỏ.

Khi chảy thành lớp, lớp sát thành ống có **v = 0**; càng vào trục thì càng nhanh. Hai lớp kề nhau trượt lên nhau: lớp nhanh kéo lớp chậm, lớp chậm kìm lớp nhanh. Lực đó là **lực nội ma sát** (định luật Newton về độ nhớt):

=> F = η·S·(dv/dx)

- F: lực nội ma sát (N); S: diện tích tiếp xúc giữa hai lớp (m²); dv/dx: **gradien vận tốc** (s⁻¹).
- η: **hệ số nhớt (độ nhớt)**. Đơn vị SI: **N·s/m² = Pa·s** (giáo trình gọi là *poiseuille*, đọc "poadơi"). Đơn vị cũ: **poise (P)**, với 1 P = 0,1 Pa·s = 1 dyn·s/cm².
- Ý nghĩa: η bằng lực ma sát giữa hai lớp có diện tích 1 m² khi gradien vận tốc bằng 1 s⁻¹.

η phụ thuộc **nhiệt độ** (chất lỏng nóng thì loãng hơn), áp suất và chất tan:

- Dung dịch: η = η~0~·A^m^ (η~0~: độ nhớt dung môi; m: nồng độ phân tử chất tan; A: hằng số).
- Dung dịch chứa hạt nhỏ (công thức Einstein): **η = η~0~·(1 + 2,5·V)**, với V là tổng thể tích các hạt trong một đơn vị thể tích dung dịch.

Với máu, các "hạt" là **tế bào máu**. Vì vậy **hematocrit càng cao, máu càng nhớt**. Một hạt cầu bán kính r chuyển động với vận tốc v trong chất lỏng nhớt chịu lực cản **Z = 6π·η·r·v** (định luật Stokes). Từ đó có thể đánh giá độ nhớt máu gián tiếp qua **tốc độ lắng hồng cầu**.

> [!ung-dung] Độ nhớt máu trong lâm sàng
> - **Đa hồng cầu** (hematocrit tăng cao) làm máu nhớt, dòng chảy chậm, dễ tắc mạch. Người **mất nước** cũng bị cô máu.
> - **Thiếu máu** làm máu loãng hơn, giảm sức cản, tim tăng lưu lượng (có thể nghe tiếng thổi cơ năng).
> - **Tốc độ lắng máu (VS)** tăng trong viêm, nhiễm trùng, đa u tủy, vì fibrinogen và globulin tăng làm hồng cầu kết chuỗi, hạt "to" ra và lắng nhanh hơn.

#### b) Công thức Poiseuille

Poiseuille nghiên cứu dòng chất lỏng nhớt chảy **thành lớp** trong ống trụ hẹp, **nằm ngang**, mục đích là hiểu dòng máu trong mạch.

![Hình 2. Định luật Poiseuille: profile vận tốc parabol và ảnh hưởng của bán kính](poiseuille.svg)

- Tốc độ lớn nhất ở **trục ống**, giảm dần ra ngoài, bằng **0 ở thành ống**. Đầu mút các vectơ vận tốc tạo thành đường **parabol**.
- Lưu lượng qua ống (thể tích chảy qua trong 1 s):

=> Q = π·R⁴·Δp/(8·η·L)

- Q: lưu lượng (m³/s); R: bán kính ống (m); Δp: chênh áp hai đầu ống (Pa); η: độ nhớt (Pa·s); L: chiều dài ống (m).
- Đại lượng **R~c~ = 8ηL/(πR⁴)** gọi là **sức cản thủy động (sức cản thủy lực)**. Khi đó Q = Δp/R~c~, giống định luật Ohm I = U/R.

> [!bay] Công thức vận tốc lớp chất lỏng
> - Giáo trình tr. 85 in công thức v = Δp(R − r)²/(8ηL). Biểu thức đúng (giải được từ định luật Newton về độ nhớt) là **v(r) = Δp·(R² − r²)/(4·η·L)**, với r là khoảng cách từ trục ống. Tốc độ ở trục (r = 0) là v~max~ = ΔpR²/(4ηL), **gấp đôi tốc độ trung bình**. Ở thành ống (r = R) thì v = 0. Biểu thức in trong sách không cho ra parabol đối xứng có đỉnh ở trục, nên có lẽ là lỗi in.
> - Poiseuille chỉ áp dụng cho ống **nằm ngang**, **hẹp**, **chảy thành lớp**, chất lỏng **Newton**. Ống không nằm ngang phải tính thêm trọng lực: tim bơm máu lên đầu khó hơn bơm xuống chi dưới khi đứng.
> - **Lưu lượng tỷ lệ với R⁴, không phải R²**. Đây là câu tính toán hay ra.

> [!ung-dung] Hẹp mạch và quy luật "mũ 4"
> - Bán kính lòng mạch giảm **một nửa** (Δp không đổi) thì lưu lượng giảm **2⁴ = 16 lần**; muốn giữ lưu lượng thì chênh áp phải tăng 16 lần.
> - Bán kính giảm chỉ **10%** thì lưu lượng còn 0,9⁴ ≈ 0,66, tức giảm khoảng **1/3**.
> - Vì vậy cơ thể điều hòa lưu lượng máu đến từng cơ quan chủ yếu bằng cách **co – giãn tiểu động mạch**: thay đổi bán kính một chút là lưu lượng thay đổi rất nhiều. Thuốc **giãn mạch** (nitrat, chẹn kênh calci) hạ huyết áp, giảm đau thắt ngực cũng dựa trên nguyên lý này.
> - Mảng xơ vữa ở động mạch vành, động mạch cảnh gây **thiếu máu cục bộ** (đau thắt ngực, nhồi máu cơ tim, đột quỵ). Đặt **stent**, nong mạch là khôi phục bán kính lòng mạch.
> - Ở hẹp rất khít, dòng chảy còn thành xoáy và sức cản tăng còn nhiều hơn mức Poiseuille dự đoán.

#### c) Chảy tầng, chảy xoáy và số Reynolds (bổ sung)

Giáo trình chỉ nêu định tính: chảy thành lớp khi tốc độ nhỏ, ống hẹp. Tiêu chí định lượng là **số Reynolds**:

=> Re = ρ·v·D/η

- ρ: khối lượng riêng (kg/m³); v: tốc độ trung bình (m/s); D: đường kính ống (m); η: độ nhớt (Pa·s). Re không có đơn vị.
- Re < ≈ 2000: **chảy tầng**, êm, không có tiếng. Re > ≈ 3000: **chảy xoáy (rối)**, năng lượng tiêu hao nhiều, dòng chảy **phát ra tiếng**.
- Máu bình thường chảy tầng ở hầu hết hệ mạch. Ở gốc động mạch chủ, lúc đỉnh tống máu, Re có thể vượt 2000 trong thời gian ngắn, nhưng vì dòng chảy theo nhịp (tăng tốc rồi giảm tốc rất nhanh) nên thường chưa kịp thành rối hẳn. Dòng dễ thành xoáy khi **tốc độ tăng** (gắng sức, hẹp mạch), **độ nhớt giảm** (thiếu máu) hoặc **đường kính đột ngột thay đổi**.
- Ứng dụng: **tiếng thổi ở tim** (hẹp, hở van), **tiếng thổi ở động mạch cảnh** khi hẹp, và **tiếng Korotkoff** khi đo huyết áp (mục 2.6).

### 2.4. Sự vận chuyển máu: tim, thành mạch, hệ mạch

#### a) Hệ tuần hoàn — tim như cái bơm

Có hai vòng tuần hoàn kín: **vòng tiểu tuần hoàn** (tim phải → phổi → tim trái) và **vòng đại tuần hoàn** (tim trái → động mạch → mao mạch các cơ quan → tĩnh mạch → tim phải). Máu chảy **một chiều** nhờ ba yếu tố: tim co bóp, thành mạch đàn hồi và hệ thống van (trong tim và trong lòng tĩnh mạch).

Số liệu của giáo trình (tr. 86–87):

- Khi thất trái co, áp suất trong thất lên tới **120–150 mmHg**.
- Mỗi lần co tim đẩy ra **40–70 ml** máu (thể tích nhát bóp), tương ứng **4–6 lít/phút** (cung lượng tim).
- Lực toàn phần của cơ tim: **89 N ở đầu tâm thu**, **67 N ở cuối tâm thu**. Lực F = P·S (P: áp suất trong buồng tim, S: diện tích mặt trong buồng tim). Lực lớn nhất khi buồng tim chứa nhiều máu nhất (S lớn nhất).
- Sợi cơ tim được kéo dài do máu đổ đầy cuối tâm trương. Cơ tim chỉ co khi kích thích vượt **ngưỡng**, và khi đó co ngay tối đa.

#### b) Tính đàn hồi của thành mạch — "bình hơi" của động mạch

- Thành **động mạch lớn** có ít cơ trơn, **nhiều sợi đàn hồi**. Thành **động mạch nhỏ** có nhiều cơ trơn hơn. Cơ trơn giữ một trương lực, quyết định tiết diện lòng mạch, do thần kinh thực vật và nội tiết tố điều khiển.
- Biến dạng đàn hồi tuân theo định luật Hooke: Δl/l = k·F/S, với **E = 1/k là môđun đàn hồi (Young)**. Lực đàn hồi F = E·S·Δl/l.
- Thế năng đàn hồi tích trong thành mạch:

=> E~t~ = (1/2)·(E·S/l)·(Δl)²

Thế năng **tỷ lệ với bình phương độ giãn**. Khi tim co (tâm thu), động mạch giãn ra, tích thế năng. Khi tim nghỉ (tâm trương), thành mạch co lại, trả năng lượng để đẩy máu đi tiếp. Nhờ vậy **dòng máu liên tục và điều hòa** dù tim chỉ bơm từng đợt.

> [!ung-dung] Xơ cứng động mạch ở người già
> Thành động mạch xơ cứng mất tính đàn hồi nên không còn hoạt động như "bình hơi". Máu phụt vào hệ mạch cứng làm **huyết áp tâm thu tăng cao**, còn tâm trương lại thấp: hiệu áp rộng. Đây là kiểu **tăng huyết áp tâm thu đơn độc** hay gặp ở người cao tuổi.

#### c) Sức cản ngoại vi

Do ma sát giữa máu và thành mạch, áp suất giảm dần khi máu đi xa tim. Giống định luật Ohm:

=> Δp = R·Q   hay   R = Δp/Q

- Δp: chênh áp giữa hai đầu đoạn mạch (mmHg); Q: lưu lượng máu (ml/s); R: **sức cản** (mmHg·s/ml, giáo trình chỉ ghi "đơn vị").
- Toàn hệ đại tuần hoàn: áp suất đầu (thất trái) ≈ 130 mmHg, cuối (nhĩ phải) ≈ 5 mmHg, lưu lượng ≈ 5 lít/phút = 83 ml/s, nên **R = (130 − 5)/83 ≈ 1,5 đơn vị**.
- **Gắng sức**: lưu lượng tăng gấp 3 (áp suất động mạch chủ có thể lên 150 mmHg). Giáo trình tính R = (130 − 5)/(83 × 3) ≈ **0,5 đơn vị**: sức cản giảm còn 1/3 do mạch ở cơ giãn ra.
- **Tăng huyết áp**: áp suất động mạch chủ có thể lên tới 200 mmHg nhưng lưu lượng không tăng, vì sức cản ngoại vi tăng tới **2,3 đơn vị**. Tim phải làm việc nặng hơn nhiều.
- Áp dụng Poiseuille: **R = 8ηl/(πr⁴)**. Sức cản phụ thuộc vào **yếu tố hình học (r, l)** của hệ mạch và **độ nhớt máu**, trong đó r là quyết định.

### 2.5. Áp suất và tốc độ máu trong các đoạn mạch

#### a) Áp suất giảm dần — giảm mạnh nhất ở tiểu động mạch

Tổng chiều dài mạch máu của người bình thường là hơn **100 000 km**. Áp suất giảm liên tục từ tim ra (giáo trình tr. 89–90):

| Đoạn mạch | Áp suất (mmHg) |
|---|---|
| Động mạch chủ | 130–150 (tâm thu) |
| Động mạch nhỏ | 70–80 |
| Mao mạch | 20–30 |
| Tĩnh mạch | 8–15 |
| Tĩnh mạch chủ, trước khi đổ vào tim | **Âm** so với áp suất khí quyển |

Tỷ lệ đóng góp vào tổng sức cản (coi tổng là 100%):

- Động mạch chủ → động mạch nhỏ: **20%** (15–25%).
- **Động mạch nhỏ và mao mạch: 70%** (60–80%), trong đó riêng mao mạch chiếm 20%.
- Hệ tĩnh mạch: **10%** (5–15%).

Ở động mạch lớn, áp suất **dao động mạnh** giữa tâm thu và tâm trương. Dao động này nhỏ dần và **gần như mất hẳn ở mao mạch**, nơi áp suất gần như ổn định.

#### b) Tốc độ chảy — chậm nhất ở mao mạch

Theo phương trình liên tục, lưu lượng qua mỗi "tầng" mạch là như nhau, nên **tốc độ tỷ lệ nghịch với TỔNG tiết diện** của tầng đó. Một tiểu động mạch có tiết diện nhỏ, nhưng vì phân nhánh rất nhiều nên tổng tiết diện tăng dần từ động mạch chủ đến mao mạch rồi lại giảm dần đến tĩnh mạch chủ. **Tổng tiết diện mao mạch gấp 400–800 lần tiết diện động mạch chủ** và gấp 200–400 lần tổng tiết diện các tĩnh mạch nhỏ.

Kết quả: **máu chảy nhanh ở động mạch lớn, chậm nhất ở mao mạch, rồi nhanh dần ở tĩnh mạch**. Máu chảy chậm ở mao mạch giúp có đủ thời gian **trao đổi chất** với mô.

> [!cap-nhat] Số liệu tốc độ máu
> - **Giáo trình ghi** (tr. 90): động mạch chủ 10–20 m/s, động mạch cổ 5,2 m/s, mao mạch 5 mm/s, tĩnh mạch đùi 4,5 cm/s, tĩnh mạch cổ 14,7 cm/s.
> - **Số liệu sinh lý hiện nay**: tốc độ trung bình của máu trong **động mạch chủ ≈ 0,2–0,3 m/s** (đỉnh tâm thu ≈ 1 m/s); trong **mao mạch ≈ 0,3–1 mm/s**. Con số "vài m/s" gần với **tốc độ lan truyền sóng mạch** (≈ 4–10 m/s), không phải tốc độ của bản thân dòng máu. Cách kiểm tra: tổng tiết diện mao mạch gấp 400–800 lần động mạch chủ, nên tốc độ ở mao mạch phải nhỏ hơn 400–800 lần (0,25 m/s ÷ 600 ≈ 0,4 mm/s).
> - Đi thi: nhớ **thứ tự** (động mạch nhanh > tĩnh mạch > mao mạch chậm nhất) và lý do (tổng tiết diện). Nếu đề hỏi đúng con số của sách thì trả lời theo sách.

> [!bay]
> - Giáo trình viết rằng ở mao mạch "theo định luật Bernoulli áp suất thủy lực tăng lên vì tốc độ chảy giảm". Đừng suy diễn rằng áp suất ở mao mạch cao. Chính bảng số liệu cho thấy áp suất mao mạch (20–30 mmHg) thấp hơn nhiều so với động mạch. Vì máu là chất lỏng **nhớt**, phần lớn năng lượng áp suất đã tiêu hao để thắng **sức cản** ở tiểu động mạch. Bernoulli chỉ đúng cho chất lỏng lý tưởng (không ma sát).
> - **Áp suất giảm mạnh nhất** ở tiểu động mạch – mao mạch (sức cản lớn nhất), còn **tốc độ chậm nhất** ở mao mạch (tổng tiết diện lớn nhất). Hai ý này khác nhau.

### 2.6. Các yếu tố ảnh hưởng đến tuần hoàn — đo huyết áp

**Hoạt động cơ bắp.** Cơ vân chiếm tới **40% trọng lượng cơ thể**. Khi lao động, nhu cầu oxy tăng **8–10 lần** so với lúc nghỉ; tim đáp ứng bằng cách tăng số lần co bóp.

**Trọng trường.** Khi đứng, máu dễ dồn xuống bụng và chi dưới. Khi đứng dậy, nhịp tim tăng nhẹ để giữ cung lượng; lượng máu mỗi nhát bóp ở tư thế đứng ít hơn khi nằm. Theo định luật **Starling**, sức co của tim phụ thuộc độ giãn sợi cơ tim, tức là lượng máu tĩnh mạch đổ về. Các phản xạ thích nghi hình thành trong điều kiện trọng trường Trái Đất, vì vậy trong vũ trụ (mất trọng lượng) tuần hoàn sớm bị rối loạn.

**Nhiệt độ môi trường.** Nóng làm giãn mao mạch da để tỏa nhiệt (thí nghiệm trên thỏ: ở 45 °C lưu lượng máu tối đa tăng 6–7 lần so với 20 °C). Cơ thể bù bằng co mạch nội tạng. Khi điều hòa rối loạn, nóng đột ngột có thể gây **hạ huyết áp** tạm thời. Tương tự, sau ăn (máu dồn về tiêu hóa) hoặc khi lao động trí óc (máu lên não), lưu lượng ở các vùng khác bị ảnh hưởng.

Áp suất thủy tĩnh do trọng lực làm huyết áp đo được phụ thuộc vào **độ cao** so với tim. Với máu (ρ ≈ 1060 kg/m³), mỗi 10 cm chênh độ cao ứng với ρgh ≈ 1060 × 9,8 × 0,1 ≈ 1040 Pa ≈ **7,8 mmHg**. Vì vậy khi đo huyết áp phải đặt băng quấn **ngang tim**.

![Hình 3. Nguyên lý đo huyết áp bằng phương pháp nghe (Korotkoff)](huyet-ap.svg)

> [!ung-dung] Đo huyết áp — vật lý của tiếng Korotkoff
> Phương pháp nghe (Korotkoff) dùng băng quấn có túi hơi, áp kế và ống nghe đặt trên động mạch cánh tay:
> 1. Bơm túi hơi tới áp suất **cao hơn huyết áp tâm thu**: động mạch bị ép kín, không có dòng chảy, **không có tiếng**.
> 2. Xả hơi từ từ (2–3 mmHg mỗi nhịp tim). Khi áp suất băng vừa **thấp hơn huyết áp tâm thu**, ở đỉnh mỗi nhịp máu phụt qua chỗ mạch bị ép hẹp với **tốc độ rất lớn**, Re vượt ngưỡng nên dòng chảy **xoáy**; cùng với sự bật mở đột ngột của thành mạch, điều này phát ra **tiếng đập đầu tiên** (cơ chế tạo tiếng Korotkoff được giải thích là phối hợp dòng xoáy và rung thành mạch). Áp suất lúc này là **huyết áp tâm thu**.
> 3. Tiếp tục xả: trong mỗi nhịp, mạch mở lâu hơn, vẫn có tiếng.
> 4. Khi áp suất băng **thấp hơn huyết áp tâm trương**, động mạch mở suốt chu kỳ, dòng chảy trở lại **thành lớp**, **tiếng mất hẳn**. Áp suất lúc này là **huyết áp tâm trương**.
>
> Các lỗi vật lý thường gặp: **băng quá nhỏ** so với cánh tay to thì cần áp suất cao hơn mới ép được động mạch, nên kết quả **cao giả**. **Tay đặt thấp hơn tim** thì cộng thêm cột máu, kết quả **cao giả**; đặt cao hơn tim thì thấp giả.
>
> Theo Hội Tim mạch Việt Nam và Hội Tim mạch châu Âu (ESC), tăng huyết áp được chẩn đoán khi đo tại phòng khám **≥ 140/90 mmHg** (đo nhiều lần, nhiều thời điểm). Hướng dẫn của Mỹ (ACC/AHA) dùng ngưỡng thấp hơn là 130/80 mmHg.

## 3. Khí và sự vận chuyển khí trong cơ thể

### 3.1. Hoạt động hô hấp

Đơn vị cấu trúc cơ bản của phổi là **phế nang**: túi nhỏ, thành là lớp tế bào mỏng, bao quanh bởi lưới mao mạch dày đặc. Theo giáo trình (tr. 92):

- Mỗi lần thở bình thường trao đổi khoảng **500 ml** không khí (khí lưu thông). Người luyện tập hoặc khi hít sâu thì lượng này lớn hơn.
- Trong phổi luôn còn một lượng khí dự trữ để phổi không xẹp, giáo trình ghi khoảng **1000 ml**.

Có ba áp suất (hình 3.20 của giáo trình): **P~a~** là áp suất khí quyển và trong phế nang; **P~op~** là áp suất khoang màng phổi (giữa lá thành và lá tạng); **P~p~** là áp suất co lại do tính đàn hồi của phổi. Khi cân bằng:

=> P~a~ = P~op~ + P~p~

Do đó áp suất khoang màng phổi **nhỏ hơn** áp suất khí quyển một lượng đúng bằng P~p~. Nếu lấy áp suất khí quyển làm mốc 0 thì **áp suất khoang màng phổi là âm**. Chính áp suất âm này giữ phổi luôn căng, bám theo lồng ngực.

#### a) Hít vào — chủ động

Các cơ hít vào nâng xương sườn và **hạ cơ hoành**. Cơ hoành đảm bảo khoảng **2/3** thông khí. Thể tích lồng ngực tăng làm áp suất khoang màng phổi giảm thêm, phổi giãn ra. Theo định luật **Boyle – Mariotte** (pV = const ở nhiệt độ không đổi), V phế nang tăng thì p phế nang giảm xuống dưới áp suất khí quyển, và không khí đi vào. Lưu lượng khí:

=> Q = Δp/R

Δp là hiệu áp suất khí quyển – phế nang; R là **sức cản động học** của đường thở, phụ thuộc chiều dài, **bán kính** đường dẫn khí và độ nhớt của khí.

#### b) Thở ra — chủ yếu thụ động

Cơ hít vào giãn ra. Lực đàn hồi của lồng ngực và phổi, cùng trọng lượng lồng ngực, làm thể tích lồng ngực giảm. Áp suất phế nang tăng cao hơn áp suất khí quyển, nên khí đi ra. Thở ra bình thường **không đòi hỏi gắng sức**. Khi thở ra gắng sức thì có thêm cơ liên sườn trong và cơ bụng.

> [!ung-dung] Tràn khí màng phổi, hen và Poiseuille
> - **Tràn khí màng phổi** (vết thương ngực hở, vỡ bóng khí): khí lọt vào khoang màng phổi, **áp suất âm mất đi**. Phổi co xẹp theo tính đàn hồi của chính nó, không khí đi qua lỗ thủng thay vì qua đường thở. Điều trị là dẫn lưu khí ra để phục hồi áp suất âm.
> - **Hen phế quản**: phế quản co thắt làm bán kính giảm. Sức cản đường thở tăng rất mạnh (tỷ lệ với 1/r⁴, như Poiseuille), nhất là ở thì thở ra. Thuốc **giãn phế quản** (salbutamol) chỉ cần tăng bán kính một chút cũng giảm được nhiều sức cản.

#### c) Công hô hấp

Công hô hấp là công để thắng mọi lực cản khi thông khí. Không đo trực tiếp được, nên tính gián tiếp từ đường cong áp suất – thể tích (đo bằng **phế dung kế**):

=> A = ∫p·dV

Ở trạng thái nghỉ (thông khí dưới 10 lít/phút), công hô hấp khoảng **0,1–0,59 J/lít** khí, hay **0,98–4,9 J/phút**. Khi thông khí tăng, công tăng nhanh hơn tỷ lệ vì sức cản động học tăng. Phối hợp hợp lý giữa **độ sâu và tần số thở** giúp công cho mỗi lít khí là nhỏ nhất. Đó là kết quả của hệ điều khiển tự nhiên và tập luyện.

### 3.2. Các quy luật khuếch tán khí

**Định luật Henry**: lượng khí hòa tan vào chất lỏng **tỷ lệ với áp suất riêng phần** của khí đó trên bề mặt chất lỏng. Hệ số hòa tan (giáo trình gọi là hệ số khuếch tán) phụ thuộc bản chất từng khí.

**Định luật Dalton**: áp suất hỗn hợp khí bằng tổng các phân áp (mục 1.2). Mỗi khí khuếch tán **độc lập** theo phân áp của riêng nó.

**Định luật Cetrenov (Sechenov)**: lượng khí hòa tan vào dung dịch **giảm** khi nồng độ muối và các chất tan khác (protein, lipid…) tăng:

=> lg(S~0~/S) = k·C

S~0~: lượng khí tan trong nước nguyên chất; S: lượng khí tan trong dung dịch có chất điện ly nồng độ C; k: hằng số.

Hệ số hòa tan (giáo trình gọi là hệ số khuếch tán) của các khí, giáo trình tr. 95:

| Dung dịch | CO~2~ | O~2~ | N~2~ |
|---|---|---|---|
| Nước nguyên chất | 0,545 | 0,023 | 0,013 |
| Huyết thanh | 0,510 | 0,021 | 0,012 |
| Máu | 0,470 | 0,023 | 0,013 |
| Hồng cầu | 0,440 | 0,026 | 0,015 |

**CO~2~ tan tốt hơn O~2~ khoảng 20 lần.** Vì vậy dù chênh phân áp CO~2~ giữa máu và phế nang chỉ vài mmHg, CO~2~ vẫn thải ra dễ dàng.

Thể tích khí tan vào 1 ml máu theo khuếch tán đơn thuần: V = k·p~n~/p (k: hệ số trong bảng; p~n~: phân áp của khí; p: áp suất khí quyển).

**Phân áp các khí trong cơ thể** (mmHg, bảng 3.3, giáo trình tr. 96):

| Khí | Phế nang | Máu động mạch chủ | Máu đến phổi (tĩnh mạch) | Ở mô |
|---|---|---|---|---|
| O~2~ | 99,8 | 99 | 38 | 20–40 |
| CO~2~ | 39 | 39,6 | 45–48 | 53–76 |
| N~2~ | 575 | 550 | 550 | — |

Chiều trao đổi khí luôn **từ phân áp cao xuống phân áp thấp**:

- **Ở phổi**: O~2~ từ phế nang (≈ 100 mmHg) vào máu mao mạch phổi (38 mmHg); CO~2~ từ máu (45–48 mmHg) ra phế nang (39 mmHg).
- **Ở mô**: O~2~ từ máu động mạch (99 mmHg) vào dịch gian bào (20–40 mmHg); CO~2~ từ mô (53–76 mmHg) vào máu.

> [!vi-du] Dalton với không khí hít vào
> Không khí khô chứa ≈ 21% O~2~. Khi vào đường thở, khí bão hòa hơi nước (phân áp hơi nước ở 37 °C ≈ 47 mmHg). Phân áp O~2~ của khí hít vào: p~O2~ = 0,21 × (760 − 47) ≈ 150 mmHg. Ở phế nang, O~2~ liên tục đi vào máu và CO~2~ đi ra, nên p~O2~ phế nang chỉ còn ≈ 100 mmHg.
> Lên độ cao 5500 m (áp suất khí quyển ≈ 380 mmHg): p~O2~ hít vào chỉ còn 0,21 × (380 − 47) ≈ 70 mmHg. Tỷ lệ 21% không đổi, nhưng phân áp giảm một nửa, nên gây **thiếu oxy**.

### 3.3. Sự vận chuyển khí — vai trò của hồng cầu

Nếu chỉ có hòa tan vật lý (Henry), phân áp O~2~ 100 mmHg chỉ cho **0,003–0,004 ml O~2~ trong 1 ml huyết tương** (0,3–0,4%). Thực tế máu động mạch chứa **0,19–0,20 ml O~2~/ml** (19–20%), tức gấp khoảng 50–60 lần. Muốn đạt hàm lượng này chỉ bằng hòa tan, in vitro phải dùng phân áp O~2~ tới **6–7 atm** (và 300 mmHg đối với CO~2~). Như vậy, ngoài khuếch tán còn có cơ chế bổ sung: **hồng cầu (hemoglobin)** đóng vai trò quyết định trong vận chuyển O~2~ và CO~2~ (giáo trình tr. 96).

> [!ung-dung] Ngộ độc CO và oxy cao áp
> - CO gắn hemoglobin mạnh hơn O~2~ khoảng 200–250 lần, chiếm chỗ O~2~. Lúc đó O~2~ hòa tan trong huyết tương trở nên quan trọng.
> - Thở **oxy 100% ở áp suất cao** (buồng oxy cao áp, thường 2–3 atm tuyệt đối): theo Henry, O~2~ hòa tan tăng hơn 10 lần so với thở khí trời. Lượng O~2~ hòa tan có thể đạt ≈ 6 ml/100 ml máu, gần đủ nhu cầu của mô ngay cả khi không dùng hemoglobin. Áp suất cao còn giúp đẩy CO ra khỏi hemoglobin nhanh hơn.
> - Chỉ định đã được công nhận của oxy cao áp: **bệnh giảm áp, tắc mạch do khí**; ngoài ra dùng cho **ngộ độc CO nặng** (lợi ích lâu dài về thần kinh vẫn còn tranh luận), một số vết thương khó lành, hoại thư sinh hơi. Không phải bệnh nào "thiếu oxy" cũng có chỉ định oxy cao áp.

### 3.4. Các yếu tố ảnh hưởng đến trao đổi khí

**Yếu tố bên trong:** mọi yếu tố ảnh hưởng đến hoạt động thở, thông khí, phế nang; khối lượng và chất lượng máu (hồng cầu, huyết tương); tốc độ chuyển hóa ở mô. Toàn bộ được điều khiển qua hệ thần kinh, nội tiết, enzym.

**Yếu tố bên ngoài:**

- **Trọng trường**: khi hít vào, trọng lượng lồng ngực là lực cản; khi thở ra, nó lại giúp giảm thể tích lồng ngực. Ở tư thế đứng, nội tạng ổ bụng kéo cơ hoành xuống, thuận lợi cho hít vào, cản trở thở ra.
- **Tỷ lệ khí thành phần**: cơ thể thích nghi với p~O2~ khoảng 100 mmHg. CO~2~ là chất **kích thích hô hấp**. Cơ thể chịu được không khí có tới **50% O~2~**, nhưng thở **O~2~ nguyên chất** (kéo dài) gây rối loạn nghiêm trọng. Động vật thí nghiệm đều chết khi nhốt trong lồng kín có O~2~ với phân áp **trên 2 atm**.
- **Áp suất khí quyển**: lên cao, phân áp các khí giảm, gây thiếu oxy. **Thay đổi áp suất đột ngột** có thể gây biến chứng chết người, nên phải **giảm áp từ từ**.

> [!cap-nhat] Độc tính oxy
> Giáo trình ghi động vật chết khi phân áp O~2~ trên 2 atm. Hiện nay biết rõ **độc tính oxy phụ thuộc cả phân áp lẫn thời gian tiếp xúc**: oxy cao áp 2–3 atm được dùng an toàn trong **từng đợt ngắn** (khoảng 1,5–2 giờ) dưới giám sát. Tiếp xúc kéo dài gây độc cho phổi và thần kinh trung ương (co giật). Với trẻ sinh non, thở oxy nồng độ cao kéo dài còn gây **bệnh võng mạc** ở trẻ đẻ non. Vì vậy oxy là thuốc, phải dùng đúng liều.

> [!ung-dung] Bệnh giảm áp (bệnh của thợ lặn) — định luật Henry
> - Lặn sâu 10 m thì áp suất tăng thêm ≈ 1 atm. Thợ lặn thở khí nén ở áp suất cao nên theo Henry, **N~2~ hòa tan vào máu và mô nhiều hơn** (N~2~ tan nhiều trong mỡ).
> - **Nổi lên quá nhanh**: áp suất giảm đột ngột, N~2~ không kịp thải qua phổi mà tạo **bọt khí** trong mạch máu, khớp, thần kinh (giống mở nắp chai nước ngọt). Hậu quả: đau khớp, liệt, khó thở, có thể tử vong.
> - Phòng bệnh: **giảm áp từ từ** theo bảng (dừng ở các độ sâu). Điều trị: đưa vào **buồng oxy cao áp** để nén bọt khí lại và đẩy N~2~ ra.

## 4. Chuyển động cơ học trên cơ thể sống

### 4.1. Đại cương về chuyển động cơ học

#### a) Các định luật Newton

- **Định luật I (quán tính)**: vật giữ nguyên trạng thái đứng yên hoặc chuyển động thẳng đều nếu không có vật khác tác dụng làm thay đổi trạng thái đó. **Khối lượng** (kg) là thước đo mức quán tính. Khi vận tốc thay đổi đột ngột, các cơ quan trong cơ thể có quán tính khác nhau nên bị xô lệch, ảnh hưởng đến chức năng (ví dụ chấn thương khi phanh gấp).
- **Định luật II**: gia tốc tỷ lệ thuận với lực, tỷ lệ nghịch với khối lượng, cùng chiều với lực:

=> F = m·a   (F: N; m: kg; a: m/s²). Nhiều lực: F = F~1~ + F~2~ + … (tổng vectơ)

- Trọng lực: P = m·g. **Định luật vạn vật hấp dẫn**: F = γ·m~1~·m~2~/r². Từ đó g = γ·M~đ~/(R~đ~ + h)²: lên càng cao, g càng giảm; tại mặt đất g ≈ 9,8 m/s².
- **Khối lượng quán tính và khối lượng hấp dẫn trùng nhau** với độ chính xác rất cao: đó là hai mặt của cùng một tính chất (lượng vật chất). Hệ thức Einstein E = mc² cho thấy khối lượng và năng lượng liên quan chặt chẽ.

#### b) Cân bằng

Vật **cân bằng** khi tổng các lực và tổng các mômen lực tác dụng lên nó bằng 0. Có ba trạng thái cân bằng:

| Trạng thái | Khi bị đẩy lệch nhẹ | Thế năng E~p~ = mgh |
|---|---|---|
| **Bền** | Tự trở về vị trí cũ | Cực tiểu |
| **Không bền** | Tiếp tục rời xa vị trí cũ | Cực đại |
| **Phiếm định** (giáo trình gọi là *ổn định*) | Dừng ở vị trí mới, vẫn cân bằng | Không đổi |

Vật có **chân đế** (hay hệ có hình chân đế) cân bằng khi **đường thẳng đứng qua trọng tâm rơi vào trong chân đế**. Chân đế càng rộng, trọng tâm càng thấp thì càng vững.

**Trọng tâm (khối tâm)** là điểm đặt của trọng lực toàn vật. Vật phẳng đồng chất có trọng tâm trùng tâm hình học. Với hình dạng đặc biệt (vòng, hình cong) hoặc khối lượng phân bố không đều, **trọng tâm có thể nằm ngoài vật**.

#### c) Chuyển động quay của vật rắn

Mọi chuyển động của vật rắn đều phân tích được thành **tịnh tiến** và **quay**. Khi quay quanh một trục cố định, mọi điểm có **cùng vận tốc góc ω và gia tốc góc β**, nhưng vận tốc dài khác nhau.

**Mômen lực** đặc trưng cho tác dụng làm quay:

=> M = r·F·sinα = F·d

- M: mômen lực (N·m); F: lực (N); r: khoảng cách từ trục đến điểm đặt lực (m); α: góc giữa r và F.
- **d = r·sinα là cánh tay đòn**: khoảng cách từ trục quay đến **giá (phương) của lực**.
- Mômen là một vectơ nằm dọc trục quay, chiều xác định theo **quy tắc cái vặn nút chai**.

**Mômen quán tính** cho biết vật "khó quay" đến mức nào. Nó phụ thuộc khối lượng **và cách phân bố khối lượng so với trục**:

=> J = Σ m~i~·r~i~²   (kg·m²)

- Trụ đặc đồng chất (trục là trục hình trụ): J = m·r²/2.
- Quả cầu đặc đồng chất (trục qua tâm): J = (2/5)·m·r².
- Thí nghiệm của giáo trình (tr. 101): hai bánh xe cùng khối lượng, cùng mômen lực; bánh có khối lượng **tập trung gần trục** quay nhanh hơn (J nhỏ hơn).

**Phương trình cơ bản của chuyển động quay** (định luật II Newton cho vật quay):

=> M = J·β

β: gia tốc góc (rad/s²). Tổng mômen bằng 0 thì vật không có gia tốc góc (đứng yên hoặc quay đều).

### 4.2. Đòn bẩy và hệ xương – cơ

#### a) Đòn bẩy

Đòn bẩy là vật rắn có **một điểm tựa (trục quay)** và chịu hai lực: **lực phát động F** và **lực cản P**. Điều kiện cân bằng là tổng mômen bằng 0:

=> P·L~P~ = F·L~F~   (giáo trình viết dạng đại số M~P~ + M~F~ = 0, L~P~/L~F~ = −F/P)

L~P~, L~F~: cánh tay đòn của lực cản và lực phát động. **Cánh tay đòn của lực nào dài hơn thì lực đó nhỏ hơn.**

Trong cơ thể: **xương là tay đòn, khớp là điểm tựa, cơ tạo lực phát động**, lực cản phần lớn là trọng lực của bộ phận cơ thể và vật nặng.

![Hình 4. Ba loại đòn bẩy trên cơ thể người](don-bay.svg)

| Loại | Vị trí | Ví dụ trên cơ thể | Đặc điểm |
|---|---|---|---|
| **Loại 1** | **Điểm tựa ở giữa** F và P | **Giữ đầu thăng bằng** trên cột sống: điểm tựa là khớp giữa lồi cầu xương chẩm và đốt sống cổ thứ nhất; F là lực cơ gáy; P là trọng lượng đầu (có xu hướng gục ra trước) | Như cái bập bênh |
| **Loại 2** | **Lực cản ở giữa** | **Nhón gót** (đứng một chân, kiễng gót): điểm tựa là đầu các xương bàn chân; P là trọng lượng cơ thể truyền qua xương cẳng chân; F là lực cơ dép và cơ sinh đôi qua **gân Achille (gân gót)** bám vào xương gót | **Đòn lợi về lực** (đòn sức): F < P |
| **Loại 3** | **Lực phát động ở giữa** | **Gấp cẳng tay**: điểm tựa ở khớp khuỷu; F là lực cơ nhị đầu và cơ cánh tay trước; P là trọng lượng cẳng tay, bàn tay và vật cầm | **Đòn lợi về vận tốc**: F > P nhưng đầu tay di chuyển nhanh, xa. **Phổ biến nhất** trong cơ thể |

> [!vi-du] Tính lực cơ nhị đầu (đòn loại 3)
> Cơ nhị đầu bám vào cẳng tay cách khớp khuỷu một khoảng a, vật nặng Q trong lòng bàn tay cách khớp khoảng b. Thường **a/b = 1/12** (giáo trình tr. 105). Cân bằng mômen: F·a = Q·b, suy ra **F = 12·Q**.
> Cầm vật 5 kg (Q ≈ 49 N) thì cơ phải sinh lực ≈ 12 × 49 ≈ 590 N (chưa tính trọng lượng cẳng tay). Đổi lại, cơ chỉ cần **co ngắn rất ít** mà bàn tay đi được quãng đường lớn, nhanh.
> Lỗi hay gặp: viết F = Q/12 (nhầm sang đòn loại 2).

**Vai trò của các đầu xương và cơ đối kháng.**

- Các đầu xương **phình to** đưa chỗ bám của cơ ra xa điểm tựa, làm tăng cánh tay đòn của lực phát động. Nếu cơ bám sát ngay điểm tựa thì mômen gần bằng 0 và không gấp tay được.
- Khi lực không vuông góc với tay đòn, chỉ **thành phần vuông góc** của lực mới tạo mômen.
- Mỗi động tác cần nhiều cơ phối hợp: cơ chủ vận co, **cơ đối kháng** giãn ra. Khi động tác nhanh mạnh sắp kết thúc, cơ đối kháng co lại để "phanh", giảm vận tốc.

#### b) Hoạt động co cơ

Cơ thể có ba loại cơ: **cơ vân** (bám xương), **cơ trơn** (thành mạch, nội tạng) và **cơ tim**. Giáo trình ghi hệ cơ vân có "gần 300 cơ" (theo giải phẫu học hiện nay là hơn 600 cơ). Cơ giữ tư thế, thăng bằng, vận động, thở, ăn, lao động.

Hoạt động co cơ được đặc trưng bởi: **tính đàn hồi, lực co, độ co ngắn và công**.

- Chiều dài cơ thay đổi từ l~0~ (lúc nghỉ) đến l~min~ (co tối đa). **Độ co** của cơ: Δl = l~0~ − l.
- Muốn kéo một cơ đang co dài ra đến l~x~, phải dùng trọng lượng P~2~ lớn hơn trọng lượng P~1~ cần cho cơ đang nghỉ. Hiệu số chính là lực co của cơ: **F = P~2~ − P~1~**.
- Độ co biến thiên theo thời gian trong một chu kỳ co T:

=> Δl = Δl~max~·sin(π·t/(2T))

- t = T/6: Δl = Δl~max~·sin(π/12) ≈ **0,26·Δl~max~**.
- t = T/2: Δl = Δl~max~·sin(π/4) ≈ **0,71·Δl~max~** (giáo trình làm tròn "đạt 3/4 giá trị cực đại").
- Ý nghĩa: **giai đoạn đầu co cơ, tốc độ co rất lớn**.

**Lực co tuyệt đối** của cơ là lực lớn nhất khi co tối đa. Đo bằng trọng lượng nhỏ nhất làm cơ không co được dù đã kích thích tối đa. Lực này tỷ lệ với số sợi cơ, tức **tiết diện ngang** của cơ. Do đó dùng **hệ số lực co P = F/S** (lực trên một đơn vị tiết diện) để so sánh cơ của các loài. Giáo trình ghi lực trên tiết diện ngang khi co là **6 kg trên 10⁻⁴ m²** (tức 6 kG/cm² ≈ 0,6 MPa); mỗi sợi cơ cho lực 0,1–0,3 g.

**Hai kiểu co cơ** (giáo trình tr. 108):

| | **Co đẳng trương (isotonic)** | **Co đẳng trường (isometric)** |
|---|---|---|
| Chiều dài cơ | Ngắn lại (có thể tới 50–60%) | **Không đổi** |
| Lực | Thắng được lực ngoài | Lực căng tăng, nhưng không thắng lực ngoài, hoặc cố ý giữ tĩnh |
| Công cơ học | **Có** (công dương) | **Bằng 0** (năng lượng thành nhiệt) |
| Ví dụ | Nâng tạ lên | Đẩy vào tường, giữ tạ đứng yên |

Khi cơ **bị kéo dài trong lúc vẫn co** (hạ từ từ vật nặng xuống), cơ sinh **công âm**, hoạt động như cái hãm; năng lượng chuyển thành nhiệt.

> [!bay] Thuật ngữ "isometric"
> Giáo trình gọi co isometric là trạng thái "không trương lực". Thực ra trong co **đẳng trường** (isometric), **chiều dài không đổi nhưng lực căng của cơ tăng lên rõ rệt**. Cái "không có" là sự co ngắn và công cơ học bên ngoài, không phải trương lực. Còn co **đẳng trương** (isotonic) là co ngắn với lực căng gần như không đổi.

#### c) Công và năng lượng của cơ

**Công cơ học.** Công càng lớn thì mệt mỏi càng sớm (giáo trình tr. 106):

- Người đạp xe: 120 kGm/phút trong nhiều giờ; 1800 kGm/phút trong 1 giờ đầu; tới 2400 kGm/phút trong những giây đầu. Tương ứng, tốc độ 30 km/h chỉ giữ được trong 30 giây đầu; 15–18 km/h giữ được 1–2 giờ.
- Người có thể sinh công suất tới **1,5 mã lực** (≈ 110 kGm/s ≈ 1,1 kW) trong vài giây đầu. Một ngày đêm, công thể lực không vượt quá **100 000–200 000 kGm**.
- Đổi đơn vị: 1 kGm = 9,81 J; 1 mã lực ≈ 75 kGm/s ≈ 736 W.
- Năng lượng cơ dùng không chỉ để sinh công mà còn để duy trì sự căng của cơ và một phần chuyển thành nhiệt (lúc nghỉ ≈ 1,6·10⁻² J/(kg·s); khi co tăng lên nhiều lần).

**Nguồn năng lượng co cơ** (giáo trình tr. 107) theo thứ tự huy động:

1. **ATP có sẵn** trong cơ: chỉ đủ cho dưới **1 giây**.
2. **Phosphocreatin**: phosphocreatin + ADP → ATP + creatin. Đủ cho **vài giây**.
3. **Đường phân yếm khí** từ glycogen/glucose, tạo **lactat**. Cung cấp năng lượng khi mạch máu chưa kịp đưa đủ oxy. Lactat tích tụ kìm hãm quá trình tổng hợp ATP.
4. **Chuyển hóa hiếu khí** (acid pyruvic → chu trình Krebs → CO~2~ + H~2~O): cho năng lượng **lớn hơn nhiều lần** quá trình yếm khí. Năng lượng này dùng để bù lại ATP và phosphocreatin đã tiêu hao.

=> glucose + 2 ADP + 2 P~i~ → 2 lactat + 2 ATP + 2 H~2~O   (giáo trình in "3 H~3~PO~4~"; cân bằng đúng là 2 phosphat)

> [!vi-du] Ví dụ của giáo trình — chạy nước rút 7 m
> - Người 60 kg đi 7 m trong 10 giây: các cơ chân thực hiện công ≈ **420 kGm** (≈ 4,1 kJ ≈ 1 kcal).
> - Hiệu suất cơ chỉ ≈ **25%**, nên cơ cần ≈ **4 kcal**.
> - 1 lít O~2~ cho ≈ **4,8 kcal**, nên cần ≈ 800 ml O~2~ trong 10 giây, tức ≈ **80 ml/s**. Lúc nghỉ chỉ dùng ≈ **3,5 ml O~2~/s**.
> - Tim và phổi không thể tăng cung cấp oxy từ 3,5 lên 80 ml/s trong vài giây. Vì vậy giai đoạn đầu cơ phải dùng **năng lượng yếm khí** (ATP, phosphocreatin, đường phân), sau đó trả "nợ oxy".

#### d) Tính đàn hồi của các mô

Mọi mô đều bị biến dạng đàn hồi (ép, kéo, gập, xoắn). Nhờ sụn sườn đàn hồi, lồng ngực trở về vị trí cũ sau khi thở ra; nhờ đĩa đệm, cột sống giữ được tư thế thẳng đứng; nhờ thành mạch đàn hồi, máu chảy liên tục. Tính đàn hồi của xương do **tổ chức liên kết**; độ vững chắc do **muối vô cơ** (phospho, calci). Xương dạng **ống** chịu lực tốt nhất với cùng lượng vật chất, tốt hơn dạng đặc.

Môđun đàn hồi E và giới hạn bền Q (bảng 3.4, giáo trình tr. 108; 1 kG/mm² = 9,81·10⁶ N/m²):

| Mô | Giới hạn bền Q (kG/mm²) | Môđun E (kG/mm²) |
|---|---|---|
| Xương người trẻ | 9,2–12,4 | 2200–2700 |
| Xương người già | 6,4–7,7 | 1800–2200 |
| Cơ bắp | 0,038 | 0,95 |
| Động mạch | 0,14 | 0,05 |
| Tĩnh mạch | 0,18 | 0,85 |
| Thần kinh | 1,35 | 10–30 |

Xương người già có **Q và E đều nhỏ hơn**: kém bền, dễ gãy (loãng xương). Động mạch có E rất nhỏ nên **rất dễ giãn**, phù hợp chức năng "bình hơi".

#### e) Sự thăng bằng của cơ thể

- **Đầu** có trọng tâm hơi **phía trước** cột sống, nên tạo mômen làm gục đầu. **Cơ gáy** phải căng liên tục để giữ đầu (đòn loại 1). Khi ngủ ngồi, cơ gáy giãn và đầu gục về phía trước: đó là **ngủ gật**.
- Khi đứng, thăng bằng phụ thuộc vào **diện tích chân đế** (gồm cả phần giữa hai bàn chân). **Đứng dạng chân vững hơn chụm chân, vững hơn nhiều so với đứng một chân.**
- Khi có ngoại lực (gió, xô đẩy, mang vật nặng), cơ thể tự điều chỉnh để **hợp lực vẫn rơi vào chân đế**. Ví dụ: cúi người về trước khi đi ngược gió hoặc khi đeo vật nặng sau lưng; nghiêng vào phía tâm khi đi đường vòng.
- **Đi bộ**: luôn có lúc cả hai chân cùng chạm đất. **Chạy**: không có lúc nào như vậy, mà có lúc cả hai chân đều rời mặt đất.

> [!ung-dung] Đòn bẩy, thăng bằng và lâm sàng
> - **Người cao tuổi dễ ngã**: chân đế hẹp, phản xạ chậm, cơ yếu. Dùng **gậy hoặc khung tập đi** là để **mở rộng chân đế**. Xương già giòn (Q nhỏ) nên ngã dễ gãy cổ xương đùi.
> - **Nâng vật nặng đúng tư thế**: giữ vật **sát người** và gập gối thay vì cúi lưng. Cách này làm giảm cánh tay đòn của vật so với cột sống thắt lưng, nên giảm lực mà cơ lưng và đĩa đệm phải chịu. Đây là cơ sở phòng thoát vị đĩa đệm.
> - **Phục hồi chức năng**: tập co cơ **đẳng trường** (không cử động khớp) dùng sớm sau chấn thương, bó bột để giữ sức cơ mà không làm di lệch khớp.

> [!yhct] Giác hơi — áp suất âm
> - **Phần vật lý đã chứng minh**: khi đốt lửa trong ống giác (hoặc dùng bơm hút), không khí trong ống bị nung nóng hoặc hút bớt. Úp lên da rồi để nguội, theo pV/T = const, áp suất trong ống **thấp hơn áp suất khí quyển**. Hiệu áp suất này hút da và mô dưới da vào ống, làm giãn mao mạch tại chỗ, gây **xung huyết**, có khi vỡ mao mạch nhỏ để lại vết bầm. Hiệu ứng tại chỗ này nhìn thấy và đo được.
> - **Phần quan niệm YHCT**: giác hơi để "hành khí hoạt huyết, khu phong tán hàn". Đây là cách diễn đạt theo lý luận YHCT, chưa phải cơ chế đã chứng minh.
> - **Bằng chứng lâm sàng**: một số thử nghiệm cho thấy giác hơi có thể giảm đau cơ – xương (đau cổ, đau lưng) trong ngắn hạn, nhưng chất lượng nghiên cứu còn hạn chế. **Không giác** trên vùng da tổn thương, người có rối loạn đông máu hoặc đang dùng thuốc chống đông. Cẩn thận bỏng khi dùng lửa.

## Tóm tắt

| Chủ đề | Công thức / Ý chính | Ứng dụng y học |
|---|---|---|
| Khí lý tưởng | pV = (m/μ)RT; p = (2/3)nĒ~đ~; Ē~đ~ = (3/2)kT | Nhiệt độ = thước đo chuyển động phân tử |
| Dalton | p = Σp~i~ | Phân áp O~2~, CO~2~ trong phổi, máu, mô |
| Sức căng mặt ngoài | F = σl; ΔW = σΔS; Δp = 2σ/R | Chất hoạt diện phổi, suy hô hấp sơ sinh |
| Mao dẫn | h = 2σ/(rρg): ống càng nhỏ càng dâng cao | Vật xốp hút nước, ngâm dược liệu |
| Khuếch tán (Fick) | dn = −DS(dC/dx)dt; D = kT/(6πrη) | Trao đổi chất qua màng, thẩm phân máu |
| Thẩm thấu (van't Hoff) | p = iCRT; máu ≈ 7,7 atm | NaCl 0,9%, ưu/nhược trương, mannitol |
| Donnan | x = C~2~²/(C~1~ + 2C~2~) | Tế bào luôn hơi ưu trương so với môi trường |
| Lọc (Starling) | Thủy tĩnh đẩy ra – keo kéo vào; cầu thận p~lọc~ = 70 − (32 + 14) = 24 mmHg | Phù, thiểu niệu khi sốc |
| Qua màng | Thụ động (đơn giản, liên hợp, trao đổi) – Chủ động (Na^+^–K^+^-ATPase: 3 Na^+^ ra, 2 K^+^ vào) – Thực bào, ẩm bào | Digoxin, ức chế bơm proton, ORS |
| Liên tục, Bernoulli | Sv = const; p + ρgh + ρv²/2 = const | Doppler, chỗ hẹp máu chảy nhanh |
| Độ nhớt | F = ηS·dv/dx; η = η~0~(1 + 2,5V); Pa·s | Hematocrit, tốc độ lắng máu |
| Poiseuille | Q = πR⁴Δp/(8ηL); R~c~ = 8ηL/(πR⁴) | Hẹp mạch: r giảm 1/2 → Q giảm 16 lần |
| Reynolds (bổ sung) | Re = ρvD/η; > ≈ 2000–3000 là xoáy | Tiếng thổi, tiếng Korotkoff |
| Hệ mạch | Áp suất giảm mạnh nhất ở tiểu động mạch – mao mạch; tốc độ chậm nhất ở mao mạch | Đo HA ngang tim, tăng HA do tăng sức cản |
| Hô hấp | P~a~ = P~op~ + P~p~ (khoang màng phổi áp suất âm); A = ∫pdV | Tràn khí màng phổi, hen |
| Henry, Sechenov | Khí hòa tan ∝ phân áp; CO~2~ tan gấp ≈ 20 lần O~2~ | Bệnh giảm áp, oxy cao áp, ngộ độc CO |
| Đòn bẩy | P·L~P~ = F·L~F~; loại 1 (đầu), 2 (nhón gót), 3 (gấp tay, phổ biến nhất) | Cơ nhị đầu F = 12Q; tư thế nâng vật |
| Co cơ | Δl = Δl~max~sin(πt/2T); đẳng trương (có công) – đẳng trường (công = 0) | Phục hồi chức năng |
| Năng lượng cơ | ATP (< 1 s) → phosphocreatin (vài giây) → yếm khí (lactat) → hiếu khí | Nợ oxy, mỏi cơ |
