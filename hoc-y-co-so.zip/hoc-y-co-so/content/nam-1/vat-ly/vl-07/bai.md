---
title: Bản chất của ánh sáng — laser
thoi-gian: 120 phút
muc-tieu:
- Trình bày được nội dung chính của hai thuyết về bản chất ánh sáng — thuyết sóng điện từ (giao thoa, nhiễu xạ, phân cực) và thuyết lượng tử (hiệu ứng quang điện, thuyết photon của Einstein).
- Giải thích được sự hấp thụ ánh sáng và sự phát sáng (huỳnh quang, lân quang) dựa trên các mức năng lượng của tập hợp điện tử.
- Nêu được bản chất, cấu tạo máy phát, tính chất và ứng dụng y học của laser.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. **Ánh sáng là sóng điện từ** (Maxwell, 1865): E ⊥ H ⊥ phương truyền; chỉ **vectơ E** gây cảm giác sáng ("vectơ sáng"). Bằng chứng tính sóng: **giao thoa, nhiễu xạ, phân cực**.
> 2. **Giao thoa** cần hai **sóng kết hợp** (cùng chu kỳ, hiệu pha không đổi, cùng phương dao động). Sáng khi hiệu quang lộ Δ = kλ; tối khi Δ = (2k + 1)λ/2. Khe Young: **khoảng vân i = λD/d**.
> 3. **Ánh sáng là dòng photon** (Einstein, 1905): mỗi photon mang **ε = hf = hc/λ**. Giải thích được hiệu ứng quang điện: chỉ xảy ra khi **λ < λ~0~ = hc/A**, động năng cực đại **E~đmax~ = hf − A** không phụ thuộc cường độ sáng.
> 4. Nguyên tử hấp thụ/phát photon khi điện tử chuyển mức: **hf = W~cao~ − W~thấp~**. **Huỳnh quang** (từ singlet, tắt sau ≈10^−9^–10^−8^ s) và **lân quang** (qua triplet, kéo dài 10^−4^ s đến vài giây); ánh sáng phát quang luôn có **bước sóng dài hơn** ánh sáng kích thích (Stokes).
> 5. **Laser** = khuếch đại ánh sáng bằng **phát xạ cảm ứng**; cần môi trường hoạt tính được **bơm năng lượng** và **hai gương**. Chùm tia **kết hợp, đơn sắc, rất song song, hội tụ được thành điểm có mật độ năng lượng rất lớn** → dao mổ, hàn võng mạc, quang động lực…

Giáo trình mở bài bằng câu hỏi "ánh sáng là gì?" và đưa ra **hai thuyết bổ sung cho nhau**. Thuyết sóng giải thích tốt sự lan truyền (giao thoa, nhiễu xạ, phân cực). Thuyết lượng tử giải thích tốt sự trao đổi năng lượng giữa ánh sáng và vật chất (quang điện, hấp thụ, phát sáng). Ánh sáng có **lưỡng tính sóng – hạt** (Giáo trình tr. 235, 252).

## 1. Thuyết sóng điện từ về bản chất ánh sáng

### 1.1. Ánh sáng là sóng điện từ

Năm 1865, Maxwell kết luận ánh sáng là **sóng điện từ**; thực nghiệm sau đó xác nhận (Giáo trình tr. 235).

Tại mỗi điểm ánh sáng truyền tới có hai vectơ dao động: **cường độ điện trường E** và **cường độ từ trường H**. Hai vectơ này vuông góc với nhau và vuông góc với phương truyền (sóng ngang). Trường hợp đơn giản nhất, tại điểm M cách nguồn O một khoảng x:

=> E = E~0~·cos[ω(t − x/v) + α];  H = H~0~·cos[ω(t − x/v) + α]

- E~0~, H~0~: biên độ; ω = 2πf: tần số góc (rad/s); α: pha ban đầu; v: tốc độ ánh sáng trong môi trường (m/s).
- Khi tới mắt, **chỉ thành phần điện trường gây cảm giác sáng**; khi xét tương tác ánh sáng – nguyên tử cũng chỉ cần xét E. Vì vậy E được gọi là **vectơ sáng** (tr. 236).

**Bước sóng, tần số, chiết suất**

=> λ·f = v  (trong môi trường);  λ~0~·f = c  (trong chân không)

- λ: bước sóng (m); f: tần số (Hz); c ≈ 3·10^8^ m/s (giáo trình ghi 300 000 km/s).
- Tần số càng lớn thì bước sóng càng nhỏ.
- Khi đi từ chân không vào môi trường, **tần số giữ nguyên**, tốc độ và bước sóng cùng giảm n lần:

=> n = c/v = λ~0~/λ  (n: chiết suất, không đơn vị)

Đây là ý nghĩa vật lý của chiết suất. Từ nay, khi nói "bước sóng" mà không nói gì thêm, ta hiểu là bước sóng trong chân không (tr. 236).

=> c = 1/√(ε~0~·μ~0~)

- ε~0~ ≈ 8,85·10^−12^ F/m: hằng số điện (giáo trình ghi 8,84·10^−12^ SI); μ~0~ ≈ 1,26·10^−6^ H/m: độ từ thẩm của chân không.

**Cường độ sáng** (năng lượng sóng truyền qua một đơn vị diện tích trong một đơn vị thời gian):

=> I = ½·ε~0~·c·E~0~²  (W/m²)

Điểm cần nhớ: **cường độ tỷ lệ với bình phương biên độ** (I ∝ E~0~²) (tr. 237).

> [!bay]
> - Sang môi trường khác, **màu (tần số) không đổi**; chỉ λ và v thay đổi. Màu do f quyết định, không do λ trong môi trường.
> - Giáo trình in "λ = 5895 Å = 598,5 nm" là **lỗi in**: 5895 Å = **589,5 nm** = 0,5895 µm (vạch vàng natri).

**Đơn vị đo** (tr. 237): 1 µm = 10^−6^ m; 1 nm = 10^−9^ m; 1 Å (angstrom) = 10^−10^ m = 0,1 nm. Tần số đo bằng Hz; giáo trình còn dùng đơn vị Fresnel: 1 Fr = 10^12^ Hz. Trong quang phổ hồng ngoại dùng **số sóng** (wavenumber) = 1/λ (thường tính bằng cm^−1^).

> [!cap-nhat] Đơn vị và hằng số
> Giáo trình ghi đơn vị Fresnel và angstrom. Hiện nay dùng đơn vị SI: **THz** (1 THz = 10^12^ Hz, đúng bằng 1 "Fresnel") và **nm**. Các hằng số chính xác hơn: ε~0~ = 8,854·10^−12^ F/m; h = 6,626·10^−34^ J·s (từ 2019 là giá trị định nghĩa đúng 6,62607015·10^−34^ J·s). Đi thi dùng số của giáo trình nếu đề cho.

**Thang sóng điện từ** (bước sóng trong chân không, Giáo trình tr. 237):

| Loại sóng | λ |
|---|---|
| Sóng vô tuyến điện | 3·10^6^ cm → 10^−1^ cm |
| Tia hồng ngoại | 10^−1^ cm → 0,76 µm |
| **Ánh sáng nhìn thấy** | **0,76 µm → 0,39 µm** |
| Tia tử ngoại | 0,39 µm → 10^−2^ µm |
| Tia Rơnghen (X) | 10^−2^ µm → 10^−5^ µm |
| Tia gamma | 10^−5^ µm trở xuống |

**Màu đơn sắc** (tr. 238), λ tính bằng µm: đỏ 0,76–0,63; da cam 0,63–0,60; vàng 0,60–0,57; lục 0,57–0,50; lam 0,50–0,45; chàm 0,45–0,43; tím 0,43–0,39. Mỗi màu ứng với **một dải bước sóng hẹp**, không phải một giá trị duy nhất.

Tính sóng của ánh sáng thể hiện rõ nhất qua ba hiện tượng: **giao thoa, nhiễu xạ, phân cực** (tr. 238).

### 1.2. Giao thoa ánh sáng

#### a) Thí nghiệm Young (1802)

Nguồn sáng điểm S chiếu vào màn chắn P có hai lỗ nhỏ S~1~, S~2~ đặt gần nhau; sau P là màn ảnh Q (tr. 238).

- Lỗ **lớn**: trên Q chỉ có hai vệt sáng nằm trên đường thẳng SS~1~, SS~2~ — ánh sáng truyền thẳng như quang hình học dự đoán.
- Lỗ **rất nhỏ** (cỡ vài phần nghìn khoảng cách tới màn): trên Q xuất hiện các **vân sáng, vân tối xen kẽ**, đối xứng qua vân sáng giữa. Đó là **giao thoa**.

**Vì sao?** Quang hình học (tia sáng) không giải thích được. Theo **nguyên lý Huygens – Fresnel**, S~1~ và S~2~ nhận sóng từ S nên trở thành hai **nguồn thứ cấp**. Tại mỗi điểm trên Q, hai sóng chồng chất: cùng pha thì tăng cường (sáng), ngược pha thì triệt tiêu (tối) (tr. 239).

![Hình 1. Thí nghiệm khe Young — hiệu quang lộ và vị trí vân](giao-thoa-young.svg)

#### b) Điều kiện để có giao thoa

Tổng hợp hai dao động sáng cùng chu kỳ, cùng phương tại một điểm (tr. 239):

=> I = E~0~² = E~01~² + E~02~² + 2·E~01~·E~02~·cos(α~1~ − α~2~)

- Nếu **hiệu pha (α~1~ − α~2~) không đổi theo thời gian**: cường độ tại mỗi điểm có giá trị xác định, có chỗ sáng hơn, chỗ tối hơn → **có giao thoa**.
- Nếu hiệu pha **thay đổi hỗn loạn**: trung bình cos(α~1~ − α~2~) = 0, nên I = E~01~² + E~02~² ở mọi điểm → cường độ đều nhau, **không có giao thoa** (tr. 240).

Kết luận: hai sóng phải là **sóng kết hợp** — cùng chu kỳ (tần số), hiệu pha ban đầu không đổi theo thời gian — và **cùng phương dao động**. Nguồn phát ra chúng gọi là **nguồn kết hợp**.

> [!bay] Vì sao hai bóng đèn không cho vân giao thoa?
> Mỗi nguyên tử phát những đoàn sóng ngắn, pha thay đổi ngẫu nhiên. Hai nguồn độc lập vì thế **không kết hợp**. Thí nghiệm Young tạo được nguồn kết hợp bằng cách **tách từ cùng một nguồn S**. Laser là nguồn kết hợp tự nhiên nên giao thoa rất dễ quan sát (mục 4.3).

#### c) Điều kiện cực đại, cực tiểu

**Quang lộ** L của một đoạn đường là quãng đường ánh sáng đi được **trong chân không** trong cùng thời gian: L = c·t. Gọi L~1~, L~2~ là quang lộ của hai tia tới M, **Δ = L~2~ − L~1~** là hiệu quang lộ. Với α~1~ = α~2~ và hai biên độ bằng nhau E~0~ (tr. 241):

=> I = 4E~0~²·cos²(πΔ/λ~0~);  hiệu pha δ = 2πΔ/λ~0~

| | Điều kiện | Cường độ |
|---|---|---|
| **Cực đại** (vân sáng) | δ = 2kπ ⇔ **Δ = k·λ~0~** | I~max~ = 4E~0~² |
| **Cực tiểu** (vân tối) | δ = (2k + 1)π ⇔ **Δ = (2k + 1)·λ~0~/2** | I~min~ = 0 |

k = 0, ±1, ±2… gọi là **bậc giao thoa** (tr. 242).

Nếu hai biên độ khác nhau (E~01~ ≠ E~02~): cực đại I = (E~01~ + E~02~)², cực tiểu I = (E~01~ − E~02~)² ≠ 0 — vân tối không tối hẳn.

> [!bay]
> - Cường độ cực đại là **4E~0~²**, gấp 4 lần (không phải 2 lần) cường độ một sóng. Năng lượng không "sinh ra thêm": nó chỉ **phân bố lại** từ chỗ tối sang chỗ sáng.
> - Giáo trình (tr. 242) in cả hai trường hợp là "I~max~"; trường hợp Δ = (2k + 1)λ~0~/2 thực chất là **I~min~** = (E~01~ − E~02~)².

#### d) Hình dạng và vị trí vân

Tập hợp điểm có hiệu khoảng cách tới S~1~, S~2~ không đổi là các **mặt hyperboloid** tròn xoay nhận S~1~, S~2~ làm tiêu điểm. Màn Q cắt các mặt này theo các đường hyperbol. Vì S~1~S~2~ ≈ 1 mm rất nhỏ so với khoảng cách tới màn, trong vùng hẹp quan sát các vân gần như **những đoạn thẳng song song**, vuông góc với mặt phẳng S~1~S~2~O (tr. 243).

**Vị trí vân** — đặt d = S~1~S~2~, D = khoảng cách hai màn (D ≫ d), x = khoảng cách từ M tới vân giữa O~2~ (tr. 244):

=> L~2~ − L~1~ ≈ d·x/D

=> Vân sáng: x~max~ = k·λ~0~·D/d;  vân tối: x~min~ = (2k + 1)·λ~0~·D/(2d)

=> Khoảng vân: i = λ~0~·D/d

- i (m): khoảng cách giữa hai vân sáng (hoặc hai vân tối) liên tiếp — **không phụ thuộc k**, tỷ lệ thuận với λ.
- k = 0 → x = 0: **vân sáng giữa** tại O~2~.
- **Ánh sáng trắng**: mỗi màu cho một hệ vân với i khác nhau. Các vân cùng bậc k hợp thành vân nhiều màu; riêng **vân giữa vẫn trắng** vì mọi màu đều có cực đại tại đó.

> [!vi-du] Tính khoảng vân
> d = 1 mm, D = 2 m, λ = 600 nm: i = 600·10^−9^ × 2 / 10^−3^ = 1,2·10^−3^ m = **1,2 mm**. Đổi màu sang ánh sáng tím (λ ≈ 400 nm) thì i = 0,8 mm — vân sít lại. Đo i, d, D cho phép **đo bước sóng**.

### 1.3. Nhiễu xạ ánh sáng

#### a) Thí nghiệm Fresnel và định nghĩa

Ánh sáng từ nguồn điểm S đi qua **lỗ tròn** trên màn P (tr. 244–245):

- Lỗ lớn: trên Q có vệt sáng tròn đúng kích thước hình học — truyền thẳng.
- Thu nhỏ lỗ (cỡ vài phần nghìn khoảng cách tới nguồn): xuất hiện **các vòng sáng tối đồng tâm**, kể cả **trong vùng bóng tối hình học**. Tâm có thể sáng hoặc tối tùy kích thước lỗ và vị trí màn.

**Nhiễu xạ ánh sáng** là hiện tượng tia sáng **bị lệch khỏi phương truyền thẳng** trong môi trường đồng tính khi đi gần mép vật chướng ngại, tạo nên vân sáng tối kể cả trong vùng bóng tối hình học. Vật cản có thể là khe hẹp, lỗ tròn nhỏ, sợi dây mảnh (tr. 245).

**Vì sao?** Lại là nguyên lý Huygens – Fresnel: mỗi điểm của lỗ là một nguồn thứ cấp; dao động tại M là tổng hợp của chúng. Nhiễu xạ thực chất là **giao thoa của vô số nguồn thứ cấp**.

Khi nguồn ở rất xa (sóng phẳng, chùm song song) và quan sát ở xa vật cản, ta có **nhiễu xạ Fraunhofer** (nhiễu xạ ở vô cực).

#### b) Nhiễu xạ qua một khe hẹp

Chùm song song chiếu vuông góc vào khe bề rộng b; sau khe đặt thấu kính hội tụ L~2~, màn Q ở mặt phẳng tiêu. Các tia lệch cùng góc φ hội tụ tại cùng một điểm M (tr. 246).

Chia mặt khe thành các **đới Fresnel** (dải phẳng) sao cho hai đới kề nhau gửi tới M hai dao động lệch nhau nửa bước sóng. Số đới:

=> n = 2b·sin φ/λ~0~

- **n chẵn** (= 2k): các đới triệt tiêu từng cặp → **cực tiểu**: sin φ = k·λ~0~/b (k = ±1, ±2…).
- **n lẻ** (= 2k + 1): dư một đới → **cực đại phụ**: sin φ ≈ (2k + 1)·λ~0~/(2b).
- φ = 0: mọi tia cùng pha → **cực đại giữa** (sáng nhất) tại M~0~ (tr. 247).

Phân bố cường độ (tr. 247): cực đại giữa I~0~; cực đại thứ nhất chỉ còn **0,047 I~0~**, thứ hai **0,016 I~0~**. **Cực đại giữa rộng gấp đôi** các cực đại khác. Vì vậy thực tế thường chỉ quan tâm cực đại giữa.

Nhiều khe song song cách đều (cách tử): ngoài nhiễu xạ ở từng khe còn có giao thoa giữa các khe. Số khe càng nhiều, **cực đại chính càng mảnh và sắc**, cực đại phụ biến mất, ảnh chỉ còn những vạch sáng nổi bật trên nền tối (tr. 248).

> [!bay]
> Với khe hẹp, công thức **sin φ = kλ/b là vị trí vân TỐI** (k ≠ 0) — ngược với giao thoa khe Young, nơi "k·λ" là vân SÁNG. Khe càng hẹp (b nhỏ), φ càng lớn → vân nhiễu xạ **càng loe rộng**.

#### c) Nhiễu xạ qua lỗ tròn

Thay khe bằng lỗ tròn bán kính R: ảnh là **vân sáng trung tâm** (đĩa sáng) bao quanh bởi các vòng tối, sáng đồng tâm. Vòng sáng thứ nhất chỉ còn I~1~ = 0,0174 I~max~ (tr. 248). Vân tối đầu tiên ứng với góc:

=> sin φ~1~ = 0,61·λ/R

=> Bán kính ảnh nhiễu xạ (vân sáng trung tâm): ρ = 0,61·λ·f/R

(f: tiêu cự thấu kính L~2~). Như vậy ảnh của **một điểm** qua một lỗ tròn (con ngươi, vật kính) **không bao giờ là một điểm** mà là một đĩa sáng có bán kính ρ.

> [!ung-dung] Nhiễu xạ giới hạn khả năng phân biệt chi tiết
> Vì mỗi điểm sáng cho một đĩa nhiễu xạ, hai điểm quá gần nhau sẽ có hai đĩa chồng lên nhau và không phân biệt được. Đây là giới hạn **năng suất phân ly** của kính hiển vi quang học và của mắt (công thức chi tiết học ở bài quang học mắt – kính hiển vi). Dùng λ ngắn hơn hoặc khẩu độ lớn hơn thì ảnh nét hơn — vì vậy kính hiển vi điện tử (bước sóng của electron rất nhỏ) thấy được chi tiết nhỏ hơn nhiều.

### 1.4. Phân cực ánh sáng

**Ánh sáng tự nhiên.** Mỗi nguyên tử phát những đoàn sóng có E dao động theo một phương xác định. Nhưng chuyển động nhiệt hỗn loạn làm phương đó thay đổi từ đoàn sóng này sang đoàn sóng khác, và nguồn gồm rất nhiều nguyên tử. Kết quả: trong ánh sáng tự nhiên, vectơ E dao động **đều đặn theo mọi phương** vuông góc với tia sáng (tr. 249).

**Ánh sáng phân cực.** Cho ánh sáng tự nhiên qua **môi trường bất đẳng hướng** (tinh thể tourmalin, thạch anh…), trong điều kiện nhất định:

- E chỉ còn dao động theo **một phương xác định** → **phân cực thẳng** (phân cực toàn phần).
- E vẫn dao động theo mọi phương nhưng có **phương mạnh, phương yếu** → **phân cực một phần**.

**Hiện tượng phân cực** là sự biến ánh sáng tự nhiên thành ánh sáng phân cực toàn phần hay một phần (tr. 249).

> [!bay] Vì sao phân cực chứng minh ánh sáng là sóng NGANG?
> Chỉ sóng ngang mới có "phương dao động" vuông góc với phương truyền để mà chọn lọc. Sóng dọc (như âm) dao động dọc theo phương truyền nên **không thể phân cực**. Giao thoa và nhiễu xạ chỉ chứng minh ánh sáng là sóng; **phân cực** chứng minh thêm nó là sóng **ngang**.

> [!ung-dung] Phân cực trong đời sống và y học
> - **Kính râm phân cực**: ánh sáng phản xạ trên mặt nước, mặt đường bị phân cực một phần theo phương ngang. Kính chỉ cho qua phương dọc nên cắt bớt ánh chói — dễ chịu cho người lái xe, người sau mổ mắt.
> - **Kính hiển vi phân cực**: tìm **tinh thể urat** (hình kim) trong dịch khớp để chẩn đoán gút; tinh thể này làm thay đổi trạng thái phân cực nên sáng lên trên nền tối.
> - **Phân cực kế**: đo góc quay mặt phẳng phân cực của dung dịch đường (glucose, saccharose — đã học ở môn Hóa) để định lượng.
> - Màn hình tinh thể lỏng (LCD) của máy theo dõi bệnh nhân, điện thoại cũng hoạt động nhờ kính phân cực.

## 2. Thuyết lượng tử về bản chất ánh sáng

### 2.1. Hiệu ứng quang điện ngoài

**Định nghĩa.** Hiệu ứng quang điện ngoài là hiện tượng **electron bị bứt ra khỏi mặt kim loại** khi chiếu vào đó một chùm ánh sáng thích hợp (tr. 250).

#### a) Thí nghiệm

Bóng đèn chân không (áp suất ≈10^−6^ mmHg) có anốt A và catốt K làm bằng kim loại cần nghiên cứu; cửa sổ bằng **thạch anh** để tia tử ngoại lọt qua (thủy tinh thường chặn tử ngoại). Hai nguồn điện mắc ngược nhau và biến trở R cho phép thay đổi cả độ lớn lẫn dấu của hiệu điện thế U~AK~; điện kế G đo dòng (tr. 250).

Khi chưa chiếu sáng: G không chỉ. Chiếu tử ngoại vào K: G lệch — có **dòng quang điện**. Vì trong bóng gần như chân không, điện tích chỉ có thể đến từ catốt: tia tử ngoại đã giải phóng electron (gọi là **quang electron**) khỏi K. Nhận xét (tr. 250–251):

- Tia **tử ngoại** gây hiệu ứng hiệu quả nhất.
- Cường độ dòng quang điện **tăng tỷ lệ với cường độ chùm sáng**.
- Chỉ vật **tích điện âm** mới mất điện tích khi bị chiếu sáng → hạt bứt ra mang điện âm.
- Hiệu ứng xảy ra **tức thời** (chỉ ≈10^−9^ s sau khi chiếu).

#### b) Đường đặc trưng vôn – ampe

Đồ thị I~a~ = f(U~AK~) (tr. 251):

- U~AK~ tăng thì I~a~ tăng; khi U~AK~ > U~1~ thì I~a~ không tăng nữa — **dòng bão hòa I~bh~**: mọi electron bứt ra đều đã về anốt; tăng U chỉ làm chúng đi nhanh hơn chứ không thêm số lượng.
- U~AK~ = 0 vẫn có dòng I~0~ (vì electron bứt ra đã có sẵn động năng).
- Dòng chỉ triệt tiêu khi U~AK~ = −U~2~; **U~2~ là hiệu điện thế hãm (dừng)**, phụ thuộc bản chất kim loại và bước sóng chiếu tới. Ở thế hãm: e·U~2~ = E~đmax~.

#### c) Ba định luật quang điện

1. **Giới hạn quang điện**: với mỗi kim loại, hiệu ứng chỉ xảy ra khi **λ < λ~0~**. λ~0~ phụ thuộc bản chất và trạng thái bề mặt kim loại. Nếu λ > λ~0~ thì **dù cường độ rất mạnh cũng không có** hiệu ứng.
2. **Dòng bão hòa**: I~bh~ tỷ lệ với cường độ chùm sáng đơn sắc chiếu tới.
3. **Động năng ban đầu cực đại** của quang electron tăng theo tần số ánh sáng và **không phụ thuộc cường độ** chùm sáng (tr. 252).

**Thuyết sóng thất bại ở đâu?** Theo thuyết sóng, năng lượng truyền liên tục; ánh sáng nào đủ mạnh cũng phải bứt được electron (mâu thuẫn định luật 1); ánh sáng mạnh hơn phải cho electron động năng lớn hơn (mâu thuẫn định luật 3); electron phải "tích" năng lượng **vài chục phút** mới bứt ra được, trong khi thực tế chỉ ≈10^−9^ s (tr. 252).

### 2.2. Thuyết lượng tử ánh sáng của Einstein (1905)

Dựa vào thuyết lượng tử năng lượng của Planck, Einstein đề xuất (tr. 252) — ông **vẫn thừa nhận** thuyết điện từ:

- Ánh sáng gồm những hạt rất nhỏ gọi là **photon** (lượng tử ánh sáng). Mỗi photon mang năng lượng xác định:

=> ε = h·f = h·c/λ

- ε: năng lượng photon (J); h = 6,625·10^−34^ J·s: **hằng số Planck**; f: tần số (Hz); λ: bước sóng (m).
- Trong chân không photon luôn bay với tốc độ c = 3·10^8^ m/s.
- Photon có **động lượng**:

=> p = h·f/c = h/λ  (kg·m/s)

p đặc trưng cho tính **hạt**, λ đặc trưng cho tính **sóng** — một công thức nối hai mặt của ánh sáng (tr. 252).

- **Cường độ chùm sáng tỷ lệ với số photon** phát ra trong một đơn vị thời gian (tr. 253).

> [!cap-nhat] Photon có "khối lượng" không?
> Giáo trình viết photon "không có khối lượng tĩnh" nhưng có "khối lượng động" m = ε/c². Vật lý hiện đại **không dùng khái niệm khối lượng động** nữa: photon có **khối lượng bằng 0**, nhưng vẫn mang năng lượng ε = hf và động lượng p = h/λ (công thức p = h/λ vẫn đúng). Đi thi trả lời theo giáo trình nếu được hỏi.

> [!ghi-nho] Mẹo tính nhanh
> - hc ≈ 1,99·10^−25^ J·m ≈ **1240 eV·nm**, với 1 eV = 1,6·10^−19^ J.
> - Do đó: **ε (eV) ≈ 1240 / λ (nm)**.
> - Ví dụ: λ = 620 nm (đỏ) → 2,0 eV; 400 nm (tím) → 3,1 eV; 200 nm (tử ngoại) → 6,2 eV. **Bước sóng càng ngắn, photon càng "mạnh"** — đó là lý do tử ngoại, tia X nguy hiểm hơn ánh sáng đỏ, hồng ngoại.

### 2.3. Giải thích các định luật quang điện

**Định luật 1.** Mỗi electron hấp thụ **trọn một photon**. Chỉ khi năng lượng photon ≥ **công thoát A** (năng lượng tối thiểu để bứt electron khỏi kim loại) thì electron mới thoát ra (tr. 253):

=> ε = h·f ≥ A  ⇔  λ ≤ λ~0~ = h·c/A

λ~0~ chỉ phụ thuộc A, tức bản chất kim loại. Ánh sáng mạnh nhưng λ > λ~0~ chỉ là "nhiều photon yếu" — không photon nào đủ sức, nên không có hiệu ứng.

**Định luật 2.** Mỗi photon bị hấp thụ giải phóng tối đa một electron. Số quang electron ∝ số photon ∝ cường độ sáng → I~bh~ ∝ cường độ.

**Định luật 3 — phương trình Einstein.** Năng lượng photon dùng để: (1) thắng công thoát A; (2) phần còn lại thành động năng. Electron ở sát mặt kim loại mất ít năng lượng nhất trên đường ra nên có động năng **cực đại**:

=> E~đmax~ = ½·m·v~max~² = h·f − A

E~đmax~ chỉ phụ thuộc **tần số** ánh sáng (và kim loại), không phụ thuộc cường độ (tr. 253–254).

> [!bay]
> - Giáo trình phát biểu "động năng cực đại **tăng tỷ lệ** với tần số" (tr. 252). Chính xác hơn: E~đmax~ là **hàm bậc nhất** của f (E~đmax~ = hf − A), không tỷ lệ thuận — f tăng gấp đôi thì E~đmax~ tăng **hơn** gấp đôi.
> - **Tăng cường độ** → tăng **số** electron (dòng bão hòa), **không** tăng động năng từng electron. **Tăng tần số** → tăng **động năng**, không tăng số electron.

### 2.4. Ứng dụng hiệu ứng quang điện — tế bào quang điện

| Loại | Nguyên lý | Độ nhạy (giáo trình) |
|---|---|---|
| Tế bào quang điện **chân không** | Quang điện ngoài; catốt phủ Cs, Na, K, Ag…; bóng ≈10^−6^ mmHg | 10–15 µA/lm (rất nhỏ) |
| Tế bào quang điện **có khí** | Thêm khí trơ (Ar) 0,01–1 mmHg: electron ion hóa khí tạo electron thứ cấp; dòng **không bão hòa** | tới 100 µA/lm |
| Tế bào **nhân quang điện** một tầng | Electron đập vào dương cực phụ A~1~, bật ra electron thứ cấp | 500–1000 µA/lm |
| **Ống nhân quang điện** (photomultiplier) | Nhiều dương cực phụ A~1~, A~2~, A~3~… ở thế tăng dần → nhân electron nhiều lần | dòng rất lớn |
| **Quang điện trở** | **Quang điện trong**: ánh sáng giải phóng electron bên trong chất bán dẫn → độ dẫn điện tăng (PbS, Bi~2~S~3~, CdS) | nhạy hơn tế bào chân không 100–1000 lần; dùng từ hồng ngoại đến tia X, γ; phụ thuộc nhiều vào nhiệt độ |
| **Pin quang điện** | Quang điện ở **lớp chặn p – n**: tạo suất điện động, biến **trực tiếp** quang năng thành điện năng, không cần nguồn ngoài | tới 1000 µA/lm |

(Giáo trình tr. 254–256.) **Độ nhạy** = dòng bão hòa / quang thông chiếu vào, đơn vị µA/lm.

> [!ung-dung] Đầu thu ánh sáng trong máy y tế
> - **Máy đo SpO~2~** (pulse oximeter): đèn LED đỏ và hồng ngoại chiếu qua ngón tay, một **photodiode** (pin quang điện bán dẫn) đo phần ánh sáng xuyên qua để tính tỷ lệ hemoglobin gắn oxy.
> - **Ống nhân quang điện** là "tai nghe" của máy đếm nhấp nháy, gamma camera (y học hạt nhân), máy đo huỳnh quang, máy đếm tế bào dòng chảy.
> - Máy quang phổ, máy sinh hóa tự động dùng tế bào quang điện để đo độ hấp thụ của mẫu xét nghiệm.

## 3. Các mức năng lượng của tập hợp điện tử

### 3.1. Mức năng lượng của tập hợp điện tử

**Các định đề Bohr** (dựa trên thuyết lượng tử của Planck, tr. 257):

- Điện tử chỉ quay trên các **quỹ đạo xác định**, ứng với những giá trị năng lượng nhất định (gián đoạn) của nguyên tử. Trên các quỹ đạo này điện tử **không bức xạ**, nguyên tử ở **trạng thái dừng**.
- Khi chuyển quỹ đạo, nguyên tử phát hoặc hấp thụ đúng một lượng tử bằng hiệu hai mức năng lượng:

=> ε = E~1~ − E~2~ = h·f

Nhảy từ quỹ đạo xa về gần nhân → **phát** photon; hấp thụ photon → nhảy ra xa → nguyên tử ở **trạng thái kích thích**.

**Bốn số lượng tử** mô tả trạng thái điện tử (tr. 257):

| Số lượng tử | Giá trị | Ý nghĩa |
|---|---|---|
| Chính n | 1, 2, 3… | Năng lượng (lớp) |
| Phụ ℓ | 0 → n − 1 | Mômen động lượng quỹ đạo |
| Từ m | −ℓ … 0 … +ℓ | Mômen từ quỹ đạo |
| Spin s | +½ hoặc −½ | Tự quay; hai điện tử spin ngược tạo **cặp spin đối song song** |

Điện tử luôn chiếm trạng thái có **năng lượng thấp nhất** còn trống, và **không có hai điện tử nào trong một nguyên tử có cả 4 số lượng tử giống nhau** (nguyên lý Pauli).

**Năng lượng của phân tử** gồm ba phần (tr. 258):

=> E~TP~ = E~e~ + E~dd~ + E~q~

- E~e~: năng lượng của tập hợp điện tử; E~dd~: dao động của các nguyên tử quanh vị trí cân bằng; E~q~: quay của phân tử quanh trục.
- Thực tế **ΔE~e~ ≫ ΔE~dd~ ≫ ΔE~q~**. Chuyển mức **điện tử** cho phổ **tử ngoại – nhìn thấy**; chuyển mức **dao động, quay** cho phổ **hồng ngoại**.

**Ý nghĩa sinh học** (tr. 258): mọi phản ứng hóa học, hóa sinh đều là sự **phân bố lại điện tử**. Enzym giúp điện tử lên mức năng lượng cao hơn (trạng thái kích thích, tạm thời tăng thế năng), sau phản ứng phần dư thải ra dạng nhiệt. Nếu năng lượng hấp thụ đủ lớn để bứt điện tử khỏi nguyên tử thì tạo thành **ion dương, gốc tự do**; thường thì điện tử chỉ lên mức cao hơn.

### 3.2. Hấp thụ ánh sáng và phát sáng

Khi chùm photon gặp vật chất, có thể xảy ra: **phản xạ, khúc xạ, tán xạ, xuyên qua, bị hấp thụ**. Tùy năng lượng photon, kết quả có thể là: tác dụng **nhiệt**, **kích thích** nguyên tử, **ion hóa** (qua ba hiệu ứng: quang điện, Compton, tạo cặp) (tr. 259).

#### a) Sự hấp thụ ánh sáng

Hấp thụ photon, điện tử chuyển từ mức thấp (**trạng thái cơ bản**) lên mức cao (**trạng thái kích thích**). Photon chỉ bị hấp thụ khi năng lượng của nó **khớp** với một bước chuyển mức của phân tử; nếu không khớp, vật **trong suốt** với photon đó (tr. 259).

**Vì sao vật có màu?** Chất hấp thụ trong vùng nhìn thấy sẽ có màu của phần ánh sáng **không bị hấp thụ**:

- **Hemoglobin** hấp thụ mạnh vùng lam – lục, gần như không hấp thụ đỏ → máu màu **đỏ**.
- **Diệp lục** có hai cực đại hấp thụ ở đỏ và lam → lá màu **xanh lục**.
- Một số chất hấp thụ cực đại trong vùng **tử ngoại**: **acid nucleic ở 260 nm**, **protein ở 280 nm**, một số chất chiết từ khối u ác tính ở 340 nm (tr. 259).

Dựa vào **phổ hấp thụ** (cường độ hấp thụ theo λ) có thể biết bước sóng hấp thụ cực đại, màu của chất, và vì λ tỷ lệ nghịch với năng lượng nên suy ra được các mức năng lượng trong phân tử.

**Định luật hấp thụ** cho chùm song song (tr. 260):

=> I(x) = I~0~·e^−μx^

- I~0~: cường độ chùm tới; I(x): cường độ ló ra sau lớp dày x (m); μ (m^−1^): **hệ số hấp thụ**, phụ thuộc bản chất, mật độ chất hấp thụ và tần số ánh sáng.
- Số photon bị hấp thụ tỷ lệ với số "va chạm" với phân tử, nên phụ thuộc số photon tới, năng lượng photon, bản chất và bề dày lớp vật chất.

> [!ung-dung] Quang phổ hấp thụ trong xét nghiệm
> - Máy sinh hóa đo nồng độ glucose, creatinin, bilirubin… bằng cách đo độ hấp thụ của mẫu ở một bước sóng chọn sẵn (định luật Beer – Lambert, dạng mở rộng của I = I~0~·e^−μx^ với μ tỷ lệ nồng độ).
> - Đo **A260/A280** để đánh giá độ tinh sạch DNA (ADN) (acid nucleic hấp thụ ở 260 nm, protein ở 280 nm).
> - **Vàng da sơ sinh** điều trị bằng **đèn xanh lam** (≈460 nm): bilirubin hấp thụ mạnh ánh sáng này và chuyển thành dạng tan trong nước, dễ thải ra ngoài.

#### b) Cơ chế hấp thụ ánh sáng và phát sáng

Năng lượng của các phản ứng hóa sinh gắn với các **điện tử lớp ngoài cùng** (liên kết yếu nhất với hạt nhân). Các bước chuyển của chúng ứng với tử ngoại hoặc ánh sáng nhìn thấy, năng lượng khoảng **3,1–6,2 eV** (tr. 260).

Trạng thái kích thích **không bền**: phân tử chỉ ở đó **không quá ≈10^−8^ s** rồi trở về trạng thái cơ bản, giải phóng năng lượng dưới dạng **nhiệt** (bước chuyển không phát quang), dạng **photon** (phát quang) hoặc dùng cho **phản ứng quang hóa**.

**Singlet và triplet** (tr. 260):

- **Singlet (S)**: mọi điện tử đều ghép cặp, mômen spin tổng bằng 0. S~0~ là trạng thái cơ bản; S~1~\*, S~2~\*, S~3~\* là các trạng thái kích thích singlet.
- **Triplet (T)**: có hai điện tử không ghép cặp (spin song song), hình chiếu mômen spin tổng nhận +1, 0, −1. Đây là **mức "cấm"**: điện tử **không thể nhảy thẳng** từ S~0~ lên T, mà chỉ tới được T từ S\* qua một bước chuyển không phát sáng (tr. 260–261).

![Hình 2. Ba quá trình cơ bản giữa hai mức năng lượng W₁ và W₂ — cơ sở để hiểu hấp thụ, phát sáng và laser](muc-nang-luong.svg)

#### c) Hai dạng phát quang

| | **Huỳnh quang** | **Lân quang** |
|---|---|---|
| Bước chuyển | S~1~\* → S~0~ (singlet → cơ bản) | T → S~0~ (triplet → cơ bản) |
| Đường đi | Trực tiếp | S~0~ → S\* → T → S~0~ |
| Thời gian tồn tại | **10^−9^ – 10^−8^ s**: tắt ngay khi ngừng chiếu | **10^−4^ s đến vài giây**, có thể lâu hơn: còn sáng sau khi ngừng chiếu |

(Giáo trình tr. 261–262.)

**Định luật Stokes** (giáo trình ghi "Stock"): năng lượng photon kích thích luôn **lớn hơn** năng lượng photon phát quang; nói cách khác **bước sóng phát quang luôn dài hơn** bước sóng kích thích (tr. 261):

=> h·f~ht~ = h·f~pq~ + ΔE

ΔE: phần năng lượng mất cho các quá trình không quang học (nhiệt, phản ứng hóa học…). Trên đồ thị, đỉnh phổ phát quang (B) nằm lệch về phía **sóng dài** so với đỉnh phổ hấp thụ (A).

Phát quang **luôn bắt đầu từ phân mức kích thích thấp nhất** (S~1~\*): dù kích thích bằng ánh sáng lam (năng lượng lớn) hay đỏ (năng lượng nhỏ hơn) thì màu phát quang của một chất **vẫn như nhau**, không phụ thuộc bước sóng kích thích (tr. 261).

Ngoài ra còn có **phát quang hóa học** (năng lượng từ phản ứng hóa học, cho photon hồng ngoại, nhìn thấy hoặc tử ngoại) và **phát quang sinh học** (bản chất là quá trình enzym, như đom đóm) (tr. 262).

> [!bay]
> - Phát quang **không bao giờ** cho photon năng lượng lớn hơn photon kích thích (Stokes). Chiếu tử ngoại → phát ra ánh sáng xanh, vàng: hợp lý; chiếu đỏ → phát ra tím: **không** xảy ra.
> - Phân biệt theo **thời gian** và **trạng thái trung gian**: huỳnh quang tắt gần như tức thời; lân quang kéo dài nhờ "kẹt" ở mức triplet.

> [!ung-dung] Huỳnh quang trong xét nghiệm và chẩn đoán
> - **Miễn dịch huỳnh quang**: gắn chất phát huỳnh quang (vd. FITC) vào kháng thể; dưới kính hiển vi huỳnh quang, nơi có kháng nguyên sẽ sáng lên. Kính lọc chỉ cho qua ánh sáng phát quang (bước sóng dài hơn) nên nền tối, tín hiệu rõ — chính là ứng dụng của định luật Stokes.
> - **Máy đếm tế bào dòng chảy** (flow cytometry), **FISH** (lai huỳnh quang tại chỗ) phát hiện bất thường nhiễm sắc thể, **PCR thời gian thực** đều dùng tín hiệu huỳnh quang.
> - **Chụp mạch huỳnh quang** (fluorescein) đáy mắt trong nhãn khoa; **đèn Wood** (tử ngoại) làm vài loại nấm da phát huỳnh quang.

## 4. Laser

### 4.1. Bức xạ cảm ứng

Một tập hợp hạt vi mô ở các mức năng lượng gián đoạn W~1~, W~2~, W~3~… Có ba kiểu chuyển mức (tr. 262–263; Hình 2):

1. **Phát xạ tự phát (tự động)**: hạt ở mức cao tự rơi xuống mức thấp, phát photon hf = W~cao~ − W~thấp~. Xác suất chuyển **không phụ thuộc thời gian và nhiệt độ**; photon phát ra theo hướng, pha **ngẫu nhiên** — đây là cách đèn thường phát sáng.
2. **Hấp thụ**: photon tần số f với hf = W~2~ − W~1~ tới, hạt ở W~1~ hấp thụ nó và lên W~2~.
3. **Phát xạ cảm ứng (cưỡng bức)** — giả thuyết của **Einstein năm 1917**: nếu một photon có tần số **cộng hưởng** với bước chuyển W~cao~ → W~thấp~ đi qua một hạt đang ở mức cao, nó có xác suất **kích hoạt** hạt đó rơi xuống và phát thêm một photon. Photon mới **giống hệt** photon tới (cùng tần số, pha, phương truyền, phân cực). Một photon vào → hai photon ra.

Đây là **một trong ba cơ sở** của nguyên tắc tạo tia laser (tr. 263).

Khi hệ ở **cân bằng nhiệt**, số hạt hấp thụ và số hạt phát xạ bằng nhau, nên không có khuếch đại (tr. 262).

### 4.2. Đảo mật độ và môi trường hoạt tính

**Vì sao đèn thường không phát laser?** Ở trạng thái bình thường, số hạt ở mức thấp **nhiều hơn** ở mức cao. Photon đi qua sẽ bị **hấp thụ** nhiều hơn là gây phát xạ cảm ứng → ánh sáng yếu đi, không được khuếch đại.

Muốn khuếch đại phải có **đảo mật độ** (đảo ngược mật độ cư trú, population inversion): số hạt ở mức trên của bước chuyển laser **nhiều hơn** ở mức dưới. Môi trường đạt được đảo mật độ gọi là **môi trường hoạt tính** (môi trường laser). Phần giải thích "đảo mật độ" là bổ sung để hiểu sơ đồ của giáo trình (Hình 7.24).

**Sơ đồ mức năng lượng của môi trường laser** (tr. 263):

- Bơm năng lượng đưa hạt từ W~1~ lên các mức cao W~3~, W~4~ (**bơm năng lượng**).
- Hạt chuyển W~4~ → W~3~ → W~2~ **không phát sáng**, dồn lại ở **W~2~** (mức tồn tại tương đối lâu).
- Bước **W~2~ → W~1~** là **bước chuyển phát tia laser**.

### 4.3. Laser và máy phát laser

**LASER** = **L**ight **A**mplification by **S**timulated **E**mission of **R**adiation — **khuếch đại ánh sáng nhờ phát xạ cảm ứng**. Tia laser là ánh sáng phát ra do cảm ứng (tr. 263).

![Hình 3. Sơ đồ nguyên lý máy phát laser](may-laser.svg)

**Ba bộ phận chính** (tr. 263–264):

| Bộ phận | Vai trò | Ví dụ trong giáo trình |
|---|---|---|
| **Môi trường hoạt tính** (môi trường laser) | Nơi xảy ra phát xạ cảm ứng; quyết định bước sóng | Rắn: thanh **rubi** (hồng ngọc); khí: hỗn hợp **He – Ne**; bán dẫn: hai lớp **p – n** tiếp xúc |
| **Nguồn bơm năng lượng** | Tạo đảo mật độ | **Đèn xenon** xoắn quanh thanh rubi; **máy phát cao tần** + điện cực phóng điện (laser khí — He nhường năng lượng cho Ne); **dòng điện** mật độ tới hàng nghìn A/cm² (laser bán dẫn) |
| **Hai gương** (buồng cộng hưởng) | Một gương **phản xạ toàn phần**, một gương **phản xạ một phần** (lối ra) | Photon phản xạ đi lại nhiều lần, mỗi lượt gây thêm phát xạ cảm ứng |

**Hoạt động:** vài photon phát tự phát đầu tiên đi dọc trục, phản xạ qua lại giữa hai gương, mỗi lượt kích thích thêm hàng loạt photon giống hệt — "thác" photon. Một phần chui qua gương bán phản xạ thành **chùm laser**. Laser có thể phát **liên tục** hoặc **xung** (tr. 264).

> [!ghi-nho] Ba điều kiện để có laser
> 1. **Phát xạ cảm ứng** (cơ chế tạo photon giống hệt nhau).
> 2. **Đảo mật độ** trong môi trường hoạt tính, nhờ **bơm năng lượng**.
> 3. **Buồng cộng hưởng** (hai gương) để giữ photon lại, khuếch đại nhiều lần và chọn lọc phương truyền.

### 4.4. Tính chất của chùm tia laser

Bản chất laser vẫn là **ánh sáng**, nên có đủ tính chất của ánh sáng: giao thoa, nhiễu xạ, phản xạ, khúc xạ… Bước sóng laser rubi λ = **0,694 µm** (đỏ); các môi trường khác cho λ từ tử ngoại, nhìn thấy, hồng ngoại tới vi sóng (tr. 265). Đặc điểm riêng:

| Tính chất | Nguyên nhân | Hệ quả |
|---|---|---|
| **Tính kết hợp (cùng pha)** | Các nguyên tử phát gần như đồng thời, theo cảm ứng | Giao thoa dễ dàng — dùng chụp ảnh toàn ký |
| **Đơn sắc rất cao** (Δf/f ≈ 10^−12^) | Mọi nguyên tử cùng loại, cùng một bước chuyển | Hầu như không tán sắc; chọn được λ hợp với mô cần tác động |
| **Rất song song** (góc phân kỳ chỉ vài phút góc) | Buồng cộng hưởng chỉ giữ photon đi dọc trục | Đi xa không loe; chiếu chính xác |
| **Hội tụ được vào điểm rất nhỏ**, mật độ năng lượng cực lớn | Đơn sắc → không có sắc sai; song song → hội tụ gần đúng tại tiêu điểm | Cắt, đốt, hàn mô ở kích thước dưới tế bào |
| **Mang thông tin** | Xung laser dễ điều biến | Truyền trong cáp quang, dễ khuếch đại và phân tích |

> [!bay] Dễ nhầm
> - Laser **không phải tia ion hóa** như tia X. Phần lớn laser y tế có photon năng lượng thấp (nhìn thấy, hồng ngoại); tác dụng đến từ **mật độ năng lượng lớn** (nhiệt, quang cơ, quang hóa), không phải từ năng lượng của từng photon.
> - Giáo trình ghi mật độ dòng năng lượng ở tiêu điểm "tới 50 W/cm²". Con số này thấp hơn nhiều so với thực tế của laser phẫu thuật (khi hội tụ có thể đạt hàng chục kW/cm² trở lên). Khi thi, nhớ ý chính: **mật độ năng lượng rất lớn trên diện tích rất nhỏ**.

### 4.5. Ứng dụng của laser

**Kỹ thuật, đời sống** (tr. 265): thông tin liên lạc, in ấn, đĩa nhạc, đĩa máy tính; kính hiển vi dùng nguồn laser để quan sát từng phần nhỏ của tế bào.

**Y học** (tr. 265):

- **Dao mổ laser** trong vi phẫu thuật (tim, não, mắt): chùm tia nhỏ, mật độ năng lượng lớn **đốt cháy tế bào, cắt mô và đồng thời hàn kín ngay mạch máu nhỏ** — giống dao điện nhưng hiệu quả hơn, ít chảy máu.
- **Nhãn khoa**: chùm laser đi qua các môi trường trong suốt của mắt tới **võng mạc** để **hàn võng mạc bị bong** khỏi màng mạch.
- **Laser công suất thấp**: tác dụng kích thích dinh dưỡng, vận mạch — nghiên cứu điều trị vết loét, lỗ rò, chống đau và **châm cứu**.
- **Liệu pháp quang động lực** (Photodynamic Therapy – PDT): đưa trước vào cơ thể một chất nhạy sáng, sau đó chiếu laser bước sóng thích hợp để hoạt hóa chất này tại mô đích; nó trở thành chất **diệt hoặc kìm hãm tế bào** — hướng điều trị ung thư.
- **Ảnh toàn ký** (hologram): chùm laser chia đôi qua gương bán phản xạ; một chùm chiếu tới vật rồi phản xạ, gặp chùm kia tại phim tạo **ảnh mẫu giao thoa**. Chiếu laser vào phim đã tráng, người xem thấy **ảnh ảo ba chiều** (tr. 266).

> [!ung-dung] Laser trong nhãn khoa và phẫu thuật hiện nay
> - **LASIK** (mổ cận thị, viễn thị, loạn thị): **laser excimer** tử ngoại (193 nm) bóc bay từng lớp cực mỏng nhu mô giác mạc để **thay đổi độ cong giác mạc**, tức thay đổi công suất khúc xạ của mắt. Vạt giác mạc thường được tạo bằng **laser femto giây**. Photon tử ngoại bị giác mạc hấp thụ ngay ở bề mặt nên không đi sâu vào trong mắt.
> - **Quang đông võng mạc** (laser xanh lục ≈532 nm) trong bệnh võng mạc đái tháo đường, rách võng mạc; **laser Nd:YAG** (1064 nm) mở bao sau đục sau mổ thể thủy tinh.
> - **Laser CO~2~** (10,6 µm, nước hấp thụ rất mạnh) cắt và bốc hơi mô nông; laser trong tán sỏi niệu, cầm máu nội soi, da liễu (xóa xăm, mạch máu).
> Nguyên tắc chung: **chọn bước sóng theo chất hấp thụ** (nước, hemoglobin, melanin) của mô đích — đúng tinh thần mục 3.2.

> [!cap-nhat] Quang động lực và an toàn laser
> - Giáo trình ghi PDT là phương pháp "đang tập trung nghiên cứu". Hiện nay PDT **đã được dùng trong lâm sàng** cho một số chỉ định như dày sừng ánh sáng, ung thư da tế bào đáy nông, một số ung thư thực quản – phế quản giai đoạn sớm; phạm vi vẫn còn hạn chế.
> - **Phân loại an toàn laser** theo tiêu chuẩn quốc tế IEC 60825-1: **Class 1, 1M, 2, 2M, 3R, 3B, 4** (càng cao càng nguy hiểm; laser phẫu thuật là Class 4).

> [!ung-dung] An toàn laser
> - **Mắt là cơ quan dễ tổn thương nhất.** Laser nhìn thấy và hồng ngoại gần (khoảng 400–1400 nm) đi qua giác mạc, thể thủy tinh và được **hội tụ lên võng mạc** → mật độ năng lượng (độ rọi) tăng tới khoảng 10^5^ lần → bỏng võng mạc, có thể mất thị lực vĩnh viễn, nhiều khi không kịp chớp mắt. Tử ngoại và hồng ngoại xa gây tổn thương giác mạc, thể thủy tinh.
> - Mọi người trong phòng phải đeo **kính bảo hộ đúng bước sóng** của máy (kính cho laser này không bảo vệ được laser khác); không nhìn thẳng vào chùm tia hay tia phản xạ từ dụng cụ kim loại bóng.
> - Laser công suất lớn có thể **gây cháy** (gạc, khí oxy, ống nội khí quản); khói mô bốc hơi cần được hút.

> [!yhct] Laser châm — đâu là vật lý, đâu là quan niệm
> - **Laser châm** dùng laser **công suất thấp** (thường laser He – Ne đỏ 632,8 nm hoặc laser bán dẫn hồng ngoại gần, công suất cỡ vài đến vài chục mW) chiếu lên **huyệt** thay cho kim. Ưu điểm thực tế: **không xuyên da, không đau**, không lây nhiễm qua kim — hợp với trẻ em, người sợ kim. Giáo trình cũng nêu "châm cứu" trong số ứng dụng đang được nghiên cứu (tr. 265).
> - **Phần vật lý đã rõ**: ánh sáng đỏ – hồng ngoại gần xuyên mô sâu hơn ánh sáng xanh (ít bị hemoglobin, melanin hấp thụ); ở công suất này **không đủ gây bỏng hay ion hóa**. Tác dụng sinh học của laser công suất thấp ("quang điều biến sinh học", photobiomodulation) được giải thích bằng việc photon bị các chất trong ty thể hấp thụ — đây vẫn là **giả thuyết được ủng hộ chủ yếu bởi thí nghiệm trên tế bào, động vật**.
> - **Mức bằng chứng lâm sàng**: các tổng quan hệ thống cho kết quả **không nhất quán**; một số nghiên cứu thấy giảm đau ngắn hạn, nhưng nhiều thử nghiệm nhỏ, chất lượng thấp, khó làm mù. Chưa thể khẳng định laser châm tương đương châm kim.
> - **"Huyệt", "kinh lạc", "đắc khí"** là khái niệm của YHCT, **chưa có cấu trúc vật lý tương ứng được chứng minh**. Vẫn phải đeo **kính bảo hộ** cho cả người bệnh và thầy thuốc khi chiếu laser, nhất là vùng mặt.

## Tóm tắt

| Chủ đề | Điểm then chốt |
|---|---|
| Sóng điện từ | E ⊥ H ⊥ phương truyền; E là vectơ sáng; λf = v; n = c/v = λ~0~/λ; I ∝ E~0~²; nhìn thấy 0,39–0,76 µm |
| Giao thoa | Sóng kết hợp; sáng Δ = kλ, tối Δ = (2k + 1)λ/2; I~max~ = 4E~0~²; khe Young **i = λD/d** |
| Nhiễu xạ | Lệch khỏi truyền thẳng gần mép vật cản (Huygens – Fresnel); khe hẹp: tối khi sin φ = kλ/b, cực đại giữa rộng gấp đôi, I~1~ = 0,047 I~0~; lỗ tròn: sin φ~1~ = 0,61 λ/R |
| Phân cực | Tự nhiên → phân cực thẳng / một phần qua môi trường bất đẳng hướng; chứng minh ánh sáng là **sóng ngang** |
| Quang điện | λ < λ~0~ = hc/A; I~bh~ ∝ cường độ; **E~đmax~ = hf − A** không phụ thuộc cường độ; tức thời ≈10^−9^ s |
| Photon | ε = hf = hc/λ; p = h/λ; h = 6,625·10^−34^ J·s; ε(eV) ≈ 1240/λ(nm) |
| Tế bào quang điện | Chân không 10–15 µA/lm; có khí 100; nhân quang điện 500–1000; quang điện trở (quang điện trong); pin p – n tới 1000 µA/lm |
| Mức năng lượng | Bohr: ε = E~1~ − E~2~ = hf; 4 số lượng tử, Pauli; ΔE~e~ ≫ ΔE~dd~ ≫ ΔE~q~ |
| Hấp thụ | I = I~0~·e^−μx^; acid nucleic 260 nm, protein 280 nm; trạng thái kích thích ≤ 10^−8^ s |
| Phát quang | Huỳnh quang S\*→S~0~, 10^−9^–10^−8^ s; lân quang qua triplet, 10^−4^ s → vài s; Stokes: λ phát quang > λ kích thích |
| Laser | Phát xạ cảm ứng (Einstein 1917) + đảo mật độ (bơm) + buồng cộng hưởng; rubi 0,694 µm; kết hợp, đơn sắc (Δf/f ≈ 10^−12^), song song, hội tụ mạnh |
| Ứng dụng laser | Dao mổ (cắt + cầm máu), hàn võng mạc, LASIK, laser công suất thấp, PDT, ảnh toàn ký; an toàn mắt là ưu tiên số 1 |
