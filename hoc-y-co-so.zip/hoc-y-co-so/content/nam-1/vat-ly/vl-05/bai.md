---
title: Điện và sự sống
thoi-gian: 60 phút
muc-tieu:
- Trình bày được điện thế nghỉ, điện thế hoạt động và sự lan truyền xung điện trên tế bào sống — cơ chế hình thành và đặc điểm của chúng.
- Mô tả được cơ chế điện điều khiển nhịp tim, bản chất điện thế hoạt động của tim; trình bày được cách ghi điện tim (ECG) và điện thế của một số tổ chức khác (EEG, EMG) dùng trong y khoa.
- Nêu được các quy luật chính về tác dụng của dòng điện lên cơ thể sống (định luật tất cả hoặc không, đường cong cường độ – thời gian, rheobase, chronaxie).
- Kể được các ứng dụng của dòng điện trong điều trị (Galvani, điện di, dòng xung, khử rung, cao tần, dao điện) và các kiến thức cần thiết về an toàn điện, đặc biệt trong bệnh viện.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. **Điện thế nghỉ** E~M~ = V~trong~ − V~ngoài~ luôn **âm** (khoảng −50 đến −94 mV), sinh ra do chênh lệch nồng độ ion (K^+^ trong gấp ≈30 lần) và màng **thấm K^+^, Cl^−^ nhiều, thấm Na^+^ rất ít**; bơm Na^+^–K^+^ (3 Na^+^ ra, 2 K^+^ vào, tốn ATP) giữ chênh lệch đó.
> 2. **Điện thế hoạt động**: vượt **ngưỡng** → kênh Na^+^ mở, Na^+^ vào (**khử cực**, đảo cực tới ≈+50 mV) → kênh K^+^ mở, K^+^ ra (**tái phân cực**) → **phân cực vượt mức**. Biên độ không phụ thuộc cường độ kích thích; có **thời kỳ trơ**.
> 3. Xung lan truyền nhờ **dòng điện tại chỗ**, không suy giảm, 1–100 m/s; sợi có **myelin** dẫn truyền **nhảy cóc** qua eo Ranvier → nhanh và tiết kiệm năng lượng.
> 4. Tim tự phát nhịp từ **nút xoang (SA)** → nút nhĩ–thất (AV) → bó His → sợi Purkinje. **ECG**: P (nhĩ khử cực), QRS (thất khử cực), T (thất trở về nghỉ); 3 chuyển đạo chuẩn D~I~, D~II~, D~III~ theo tam giác Einthoven.
> 5. Kích thích điện tuân **đường cong cường độ – thời gian** (rheobase b, chronaxie ứng với 2b). Nguy hiểm điện do **cường độ dòng** quyết định; 50–60 Hz nguy hiểm nhất; tử vong chủ yếu do **rung thất**; bệnh nhân có dây dẫn vào tim nhạy cảm gấp ≈1000 lần.

**Mở đầu.** Năm 1791, Luigi Galvani (bác sĩ kiêm nhà vật lý người Ý) lần đầu phát hiện có hiệu điện thế giữa tế bào sống và môi trường. Các điện thế sinh học thường **không quá 0,1 V**, nhưng cá điện có thể phóng xung tới khoảng **600 V**. Dẫn truyền thần kinh thực chất là dẫn truyền xung điện. Vì vậy ghi các tín hiệu điện (điện tâm đồ, điện não đồ…) là cơ sở của nhiều phương pháp chẩn đoán, còn máy tạo nhịp tim là ví dụ thiết bị điện thay thế điện thế sinh vật (Giáo trình tr. 170).

## 1. Điện thế sinh vật ở tế bào sống

### 1.1. Điện thế nghỉ — khái niệm và cách đo

**Điện thế màng** là hiệu điện thế giữa mặt trong và mặt ngoài màng tế bào, quy ước:

=> E~M~ = V~TR~ − V~NG~   (V~TR~: điện thế mặt trong; V~NG~: điện thế mặt ngoài; đơn vị mV)

Khi tế bào ở trạng thái bình thường ("tĩnh"), E~M~ ổn định và mang **dấu âm**, gọi là **điện thế nghỉ** (resting potential). Giá trị khác nhau tùy loại tế bào, khoảng **−50 mV đến −94 mV** (Giáo trình tr. 171).

**Cách đo — vi điện cực nội bào (microelectrode):**

- Vi điện cực là ống pipet thủy tinh kéo từ ống mao quản, đầu nhọn chỉ **0,1–0,5 µm**, chứa đầy dung dịch muối (thường là **KCl**). Một điện cực kim loại nhúng vào dung dịch này và nối với máy đo.
- Thí nghiệm kinh điển dùng **sợi trục (axon) khổng lồ của con mực** vì nó rất to.
- Kết quả:
  - Hai điện cực cùng đặt **ngoài** bề mặt sợi → **không** có hiệu điện thế.
  - Một điện cực **chọc vào trong**, một điện cực ở ngoài → **có** hiệu điện thế.
  - Cả hai điện cực cùng **trong** tế bào → **không** có hiệu điện thế.
- Vì đầu điện cực rất nhỏ nên màng gần như không bị tổn thương. Tế bào giữ được điện thế nghỉ trong nhiều giờ. Khi chức năng tế bào suy giảm, điện thế nghỉ nhỏ dần (Giáo trình tr. 171–172).

> [!bay]
> - Điện thế nghỉ là hiệu điện thế **giữa hai mặt của màng**, không phải giữa hai điểm trên bề mặt tế bào. Hai điện cực cùng ở ngoài (hoặc cùng ở trong) thì đo được **0**.
> - Dấu âm nghĩa là **mặt trong âm hơn mặt ngoài** (ngoài tích điện dương, trong tích điện âm).

### 1.2. Cơ chế hình thành điện thế nghỉ

**Ba loại ion vô cơ quyết định:** Na^+^, K^+^, Cl^−^. Các phân tử hữu cơ lớn bị ion hóa cũng mang điện nhưng **không linh động**, nên không tham gia tạo dòng.

Nồng độ ion hai bên màng chênh lệch rất lớn (ở người, theo giáo trình):

| Ion | Bên nào cao hơn | Chênh lệch |
|---|---|---|
| K^+^ | **trong** tế bào | ≈ 30 lần |
| Na^+^ | **ngoài** tế bào | ≈ 13 lần |
| Cl^−^ | **ngoài** tế bào | ≈ 25 lần |

Chênh lệch này được tạo ra và duy trì bởi **vận chuyển chủ động** ("bơm ion", bơm K^+^–Na^+^) (Giáo trình tr. 172).

**Ba yếu tố chi phối sự vận chuyển ion qua màng:**

1. **Khuếch tán** theo gradient nồng độ (từ nơi đặc sang nơi loãng).
2. **Lực điện trường** tác dụng lên hạt mang điện.
3. **Sức cản của màng** — thường nói theo nghĩa ngược lại là **tính thấm** của màng với từng ion.

**Diễn biến — vì sao mặt trong âm?**

- Ở trạng thái nghỉ, màng **thấm K^+^ và Cl^−^ nhiều**, nhưng **gần như không cho Na^+^ qua**. Vì vậy tạm bỏ qua Na^+^.
- K^+^ khuếch tán **từ trong ra ngoài**, Cl^−^ khuếch tán **từ ngoài vào trong**. Cả hai đều làm **mặt ngoài dương dần, mặt trong âm dần**.
- Hiệu điện thế tăng lên sinh ra một điện trường hướng **từ ngoài vào trong**. Điện trường này **cản** K^+^ đi ra và **cản** Cl^−^ đi vào.
- Hiệu điện thế càng lớn, lực cản càng mạnh. Đến khi lực điện trường **cân bằng** với xu thế khuếch tán thì E~M~ ổn định. Đó là **trạng thái cân bằng động**: trong một đơn vị thời gian, điện tích khuếch tán ra bằng điện tích bị điện trường đẩy vào (Giáo trình tr. 172–173).

> [!vi-du] Ví von dễ nhớ
> Hãy hình dung K^+^ "muốn" đi ra vì bên ngoài ít K^+^. Nhưng mỗi K^+^ đi ra lại mang theo một điện tích dương, để lại bên trong một điện tích âm "kéo nó về". Chỉ cần một lượng ion **rất nhỏ** đi qua là đủ tạo ra hiệu điện thế cân bằng. Vì vậy nồng độ hai bên hầu như không đổi.

### 1.3. Phương trình Nernst và phương trình Goldmann

**Phương trình Nernst** (kiến thức bổ sung, hay dùng trong Sinh lý học) cho **điện thế cân bằng của một loại ion** — điện thế mà tại đó ion ấy không còn đi qua màng theo một chiều thực:

=> E~ion~ = (R·T / z·F) · ln([ion]~ngoài~ / [ion]~trong~)

- R = 8,314 J/(mol·K): hằng số khí; T: nhiệt độ tuyệt đối (K); F = 96 485 C/mol: hằng số Faraday; z: hóa trị của ion (K^+^, Na^+^: +1; Cl^−^: −1); E tính bằng V.
- Ở 37 °C (T = 310 K), đổi sang log thập phân:

=> E~ion~ ≈ (61,5 / z) · log([ion]~ngoài~ / [ion]~trong~)   (mV)

> [!vi-du] Tính nhanh điện thế cân bằng (37 °C)
> - **K^+^**: trong gấp 30 lần ngoài → E~K~ = 61,5 · log(1/30) = 61,5 · (−1,48) ≈ **−91 mV**.
> - **Na^+^**: ngoài gấp 13 lần trong → E~Na~ = 61,5 · log 13 ≈ **+68 mV**.
> - **Cl^−^** (z = −1): ngoài gấp 25 lần → E~Cl~ = −61,5 · log 25 ≈ **−86 mV**.
>
> Điện thế nghỉ thực tế (khoảng −60 đến −90 mV) **gần E~K~ và E~Cl~**, xa E~Na~. Lý do: lúc nghỉ màng thấm K^+^, Cl^−^ nhiều, thấm Na^+^ rất ít. Còn đỉnh điện thế hoạt động (+50 mV) lại **tiến về E~Na~**, vì lúc đó màng thấm Na^+^ mạnh.

**Phương trình Goldmann** xét **đồng thời cả ba ion**. Điều kiện cân bằng là tổng các mật độ dòng ion qua màng bằng 0:

=> J~K~ + J~Na~ − J~Cl~ + I~K~ + I~Na~ − I~Cl~ = 0   (5.1)

- **J**: mật độ dòng khuếch tán theo gradient nồng độ; **I**: mật độ dòng ion do lực điện trường. Đây là các đại lượng vectơ vuông góc với màng.
- Điều kiện của phương trình: **chỉ tính vận chuyển thụ động** (chưa tính bơm), và **bỏ qua các ion khác** như Ca^2+^ (Giáo trình tr. 173).

Biến đổi toán học cho phương trình Goldmann (5.2). Viết theo quy ước E = V~TR~ − V~NG~:

=> E~0~ = (R·T/F) · ln[(P~K~[K^+^]~NG~ + P~Na~[Na^+^]~NG~ + P~Cl~[Cl^−^]~TR~) / (P~K~[K^+^]~TR~ + P~Na~[Na^+^]~TR~ + P~Cl~[Cl^−^]~NG~)]

- P~K~, P~Na~, P~Cl~: **hệ số thấm** của màng với từng ion. Hệ số thấm tỷ lệ thuận với hệ số khuếch tán D và tỷ lệ nghịch với bề dày màng.
- Hệ số thấm **không cố định**: nó phụ thuộc trạng thái sinh lý và sự có mặt của hóa chất, dược chất. Vì vậy điện thế nghỉ cũng thay đổi, nhưng thay đổi tương đối ít. Khi có kích thích, hệ số thấm thay đổi mạnh nên điện thế màng thay đổi theo (Giáo trình tr. 174).

> [!bay] Thứ tự tử số – mẫu số
> - Với **cation** (K^+^, Na^+^): nồng độ **ngoài** ở tử số. Với **anion** Cl^−^: đảo lại, nồng độ **trong** ở tử số. Lý do: Cl^−^ mang điện âm.
> - Giáo trình (tr. 174) in phân số theo chiều ngược lại: nồng độ cation **trong** ở tử số. Viết như thế thì phải thêm **dấu trừ** trước R·T/F mới ra điện thế nghỉ âm. Khi làm bài, hãy kiểm tra dấu: E~0~ phải **âm**.

**Kiểm chứng trên axon mực** (Giáo trình tr. 174–175):

| Ion | Trong tế bào (mmol/kg H~2~O) | Ngoài tế bào (mmol/kg H~2~O) |
|---|---|---|
| K^+^ | 340 | 10 |
| Na^+^ | 49 | 463 |
| Cl^−^ | 114 | 562 |

- Tỷ lệ hệ số thấm lúc nghỉ: **P~K~ : P~Na~ : P~Cl~ = 1 : 0,04 : 0,45**.
- P~Na~ rất nhỏ nên bỏ qua các số hạng của Na. Tính ra **E~0~ ≈ −59,7 mV**, rất gần giá trị đo được **−60 mV**.
- Kết luận của sách: **sự cân bằng vận chuyển điện tích của dòng K^+^ và Cl^−^** qua màng là nguyên nhân chính tạo điện thế nghỉ.

### 1.4. Bơm Na^+^–K^+^

- Cả gradient nồng độ lẫn điện trường đều đẩy Na^+^ **vào** trong. Màng thấm Na^+^ rất ít nhưng vẫn có Na^+^ rò vào liên tục.
- **Bơm Na^+^–K^+^** (bơm Natri) là cơ chế **vận chuyển chủ động**. Nó đẩy Na^+^ ra ngoài **ngược** lực điện trường và gradient nồng độ, đồng thời thu K^+^ vào để bù phần đã khuếch tán ra.
- Năng lượng lấy từ **ATP**: mỗi lần phân cắt một ATP, bơm đẩy **3 Na^+^ ra** và thu **2 K^+^ vào** (Giáo trình tr. 175).

**Nhận xét của giáo trình:**

- Điện thế nghỉ là **đặc trưng của tế bào sống**. Tế bào sống dự trữ thế năng dưới dạng điện; tế bào chết thì không tạo được điện thế này.
- Điện thế nghỉ có được nhờ hai điều: (1) chênh lệch nồng độ K^+^, Na^+^, Cl^−^ và (2) tính **bán thấm** của màng. Chênh lệch nồng độ do các bơm ion duy trì. Hoạt động của bơm ion là biểu hiện "**sức sống**" của tế bào.

> [!ung-dung] Kali máu và tim
> Điện thế nghỉ phụ thuộc mạnh vào tỷ lệ [K^+^]~ngoài~/[K^+^]~trong~ (xem phương trình Nernst). Vì vậy **tăng hoặc hạ kali máu** làm thay đổi điện thế nghỉ của tế bào cơ tim, gây rối loạn nhịp nguy hiểm. Đây là lý do phải theo dõi điện giải đồ ở bệnh nhân suy thận hoặc đang dùng thuốc lợi tiểu. **Digoxin** ức chế bơm Na^+^–K^+^-ATPase của tế bào cơ tim.

### 1.5. Điện thế hoạt động

**Khái niệm.** Khi bị kích thích đủ mạnh, điện thế màng biến đổi **đột ngột**, **đổi dấu** so với điện thế nghỉ, rồi trở lại trong thời gian rất ngắn. Xung điện thế đó gọi là **điện thế hoạt động** (action potential), còn gọi là **xung điện động**. Ở axon mực: từ khoảng −60 mV, sau chỉ khoảng **1 ms** đã lên tới khoảng **+50 mV**, rồi vài ms sau trở lại gần như ban đầu (Giáo trình tr. 175–176).

**Hai kỹ thuật ghi:**

- **Ghi ngoại bào**: hai điện cực đặt **trên bề mặt** tế bào. Kích thích gần điện cực thứ nhất thì điện cực này có điện thế thấp hơn trước. Sau đó hiệu điện thế về 0, rồi đến lượt điện cực xa hơn có điện thế thấp hơn.
- **Ghi nội bào**: dùng vi điện cực chọc qua màng, nối với dao động ký. Cách này thấy rõ từng pha theo thời gian.

![Hình 1. Điện thế hoạt động: các pha và hoạt động của kênh ion (số liệu theo axon mực, chỉ có tính minh họa)](dien-the-hoat-dong.svg)

**Các pha:**

| Pha | Diễn biến điện thế | Cơ chế ion |
|---|---|---|
| **Khử cực** (depolarisation) | Từ E~0~ lên ngưỡng E~T~ rồi tăng vọt, vượt 0 → **đảo phân cực** (trong dương) tới đỉnh E~P~ | Tại E~T~, **kênh Na^+^** (bản chất protein) mở → Na^+^ tràn **vào** ồ ạt |
| **Tái phân cực** (repolarisation) | Từ E~P~ giảm nhanh về E~0~ | Tại E~P~, dòng Na^+^ vào = dòng K^+^ ra. Sau đó kênh Na^+^ đóng, **kênh K^+^ mở** → K^+^ đi **ra** mạnh |
| **Phân cực vượt mức** (hyperpolarisation) | E~M~ âm hơn E~0~ một lúc, rồi mới ổn định | K^+^ tiếp tục đi ra |

- Thời gian của phần xung nhọn: **0,5–3 ms** (Giáo trình tr. 177).
- **Vì sao pha khử cực diễn ra "tự lực"?** Màng giống hai bản tụ điện tích điện trái dấu. Mở kênh Na^+^ giống như nối hai bản tụ bằng dây dẫn: điện tích trung hòa rất nhanh. Na^+^ được **cả** gradient nồng độ **lẫn** điện trường đẩy vào. Vì vậy, sau khi điện thế hai bên cân bằng, Na^+^ vẫn tiếp tục tràn vào nhờ gradient nồng độ, làm mặt trong trở thành dương.
- **Pha tái phân cực**: lúc này mặt trong dương, nên **cả** gradient nồng độ **lẫn** điện trường đều đẩy K^+^ ra. Thêm vào đó tính thấm với K^+^ tăng mạnh.
- **Sau mỗi xung**: một lượng Na^+^ đã vào và K^+^ đã ra. Bơm Natri phải hoạt động mạnh để khôi phục chênh lệch nồng độ. Vì vậy điện thế hoạt động **tiêu hao nhiều năng lượng** (Giáo trình tr. 178).

> [!bay]
> - Khử cực = **Na^+^ đi vào**; tái phân cực = **K^+^ đi ra**. Không có chuyện "Na^+^ đi ra để tái phân cực". Bơm Na^+^–K^+^ chỉ khôi phục nồng độ **sau** xung, không tạo ra pha tái phân cực.
> - Ở pha khử cực, P~Na~ tăng **trước và nhanh**; P~K~ tăng **chậm hơn** và kéo dài hơn (hình 5.5 của sách).

### 1.6. Đặc điểm của điện thế hoạt động

1. **Biên độ và dạng đường cong gần như không phụ thuộc** cường độ hay bản chất tác nhân kích thích. Chúng chỉ phụ thuộc tính chất của tế bào bị kích thích.
2. Chỉ cần đạt **ngưỡng khử cực**. Sau đó xung diễn ra "tự lực", không dừng lại được: chắc chắn sinh ra một xung đặc trưng.
3. **Thời kỳ trơ**: không thể phát sinh xung mới trước khi kết thúc pha tái phân cực. Trong thời gian xung nhọn, màng gần như không đáp ứng với kích thích dù mạnh đến đâu. Nhờ vậy, khi kích thích mạnh kéo dài, tế bào phát được **vài trăm xung giống hệt nhau mỗi giây**.
4. **Tính tại chỗ**: kênh Na^+^ chỉ mở ở vùng chịu kích thích; các vùng khác tạm thời vẫn ở trạng thái nghỉ (Giáo trình tr. 178–179).

### 1.7. Sự lan truyền điện thế hoạt động

**Cơ chế — dòng điện tại chỗ.** Khi một vùng màng bị đảo cực (trong dương, ngoài âm), giữa vùng đó và vùng nghỉ bên cạnh xuất hiện chênh lệch điện thế ở **cả hai phía** màng. Chênh lệch này sinh ra các **dòng điện tại chỗ** chạy trong dịch nội bào và ngoại bào. Dòng tại chỗ khử cực vùng màng lân cận tới ngưỡng, vùng này lại phát xung, và cứ thế tiếp tục. Vùng **vừa** bị kích hoạt đang ở **thời kỳ trơ** nên không bị kích thích lại. Vì vậy xung chỉ đi **tiến ra xa** điểm khởi phát (Giáo trình tr. 179).

**Lan truyền theo sợi thần kinh — đặc điểm:**

- Một xung hay chuỗi xung tại điểm khởi phát gọi là **sóng hưng phấn**. Khi lan truyền, sóng **không thay đổi dạng và biên độ** (không bị yếu đi). Lý do: nó lấy năng lượng từ chính thế năng điện của màng tại từng điểm.
- Trong điều kiện sinh lý không đổi, **tốc độ truyền của một sợi là không đổi**.
- Sợi **không có myelin**: tốc độ gần như **tỷ lệ thuận với căn bậc hai bán kính sợi** (v ∝ √r).
- Cùng đường kính thì sợi **có myelin** dẫn truyền **nhanh hơn**.
- Tốc độ dẫn truyền thần kinh: **1–100 m/s**. Nhanh nhất ở các tế bào thần kinh lớn (như trong tủy sống), chậm nhất ở sợi bé nhất.
- Phân biệt với **dòng điện** trong môi trường dẫn điện của cơ thể: dòng điện lan truyền nhanh **gần bằng tốc độ ánh sáng**. Xung thần kinh là **sự kích hoạt nối tiếp** từng vùng màng nên chậm hơn rất nhiều (Giáo trình tr. 180).

**Axon có bao myelin:**

- Bao myelin có điện trở suất lớn, dày **1–3 µm**, gần như là lớp cách điện. Xen giữa là các **eo Ranvier** dài vài µm, nơi không có myelin.
- Vùng có myelin không trao đổi ion nên **không phát sinh** điện thế hoạt động. Xung **nhảy** từ eo Ranvier này sang eo kế tiếp nhờ dòng điện tại chỗ (**dẫn truyền nhảy cóc**).
- Lợi ích: **tăng tốc độ** và **tiết kiệm năng lượng**, vì chỉ có trao đổi ion ở eo.
- Thực nghiệm cho thấy **dòng điện ở môi trường điện ly ngoài bao myelin** mới là yếu tố quyết định. Nếu không có môi trường đó, xung không lan truyền được.
- Tổn thương bao myelin làm rối loạn dẫn truyền và gây nhiều bệnh thần kinh nặng (Giáo trình tr. 180–181).

> [!ung-dung] Myelin, thuốc tê và đo dẫn truyền thần kinh
> - **Xơ cứng rải rác** (bệnh xơ cứng nhiều chỗ — multiple sclerosis) và **hội chứng Guillain–Barré** là các bệnh **mất myelin**. Xung bị chậm hoặc bị chặn, gây yếu cơ, tê bì, rối loạn thị giác.
> - **Thuốc tê** (lidocain, procain) **chặn kênh Na^+^**. Pha khử cực không xảy ra nên xung đau không truyền lên não.
> - **Đo tốc độ dẫn truyền thần kinh** (thường làm kèm EMG): kích thích dây thần kinh ở hai điểm, đo hiệu thời gian xuất hiện đáp ứng, suy ra vận tốc (v = quãng đường / thời gian). Dẫn truyền chậm gợi ý tổn thương myelin.

## 2. Điện thế hoạt động của tổ chức sống

Cơ thể **không phải** một môi trường đẳng thế. Giữa các vùng trên cơ thể có những hiệu điện thế nhỏ nhưng ổn định và có tính chu kỳ rõ. Chúng **không** đến từ bên ngoài mà do các tổ chức sống sinh ra khi hoạt động chức năng. Vì vậy gọi là **điện thế hoạt động của tổ chức sống**.

- Đó là kết quả của **điện trường tổng hợp** do cả tổ chức (tim, não, cơ…) tạo ra khi hoạt động.
- Khái niệm này **khác hẳn** điện thế hoạt động của một tế bào, dù nó bắt nguồn từ các xung của từng tế bào và sự lan truyền của chúng.
- Điện sinh vật có thể là **nguyên nhân** của hiện tượng sinh lý (xung thần kinh làm cơ co), cũng có thể là **kết quả** (cơ co thì sinh ra dòng điện cơ).
- Đã ghi được điện thế của tim, não, cơ, ruột, dạ con, đáy mắt. Điện não rất yếu; điện tim tương đối mạnh (Giáo trình tr. 181).

### 2.1. Điện thế hoạt động của tim

Điện tim là hiệu điện thế **lớn nhất** đo được trên cơ thể (có thể hơn 1 mV) và quan trọng nhất trong y khoa.

#### a) Cơ chế lý sinh điều khiển nhịp tim

**Hệ thần kinh trung ương không điều khiển trực tiếp** nhịp co bóp của tim. Tim có một hệ mô cơ "đặc biệt" tự phát và dẫn truyền xung (Giáo trình tr. 181–183):

| Thành phần | Vị trí – vai trò |
|---|---|
| **Nút xoang (SA, sinoatrial)** | Thành tâm nhĩ phải, chỗ đổ vào của tĩnh mạch chủ trên. Tự phát xung đều đặn, là "**nhạc trưởng**" của nhịp tim |
| **Nút nhĩ–thất (AV, atrio-ventricular)** | Đáy tâm nhĩ phải. Nhận xung từ nhĩ, chuyển xuống thất |
| **Bó His** | Xuất phát từ nút AV, chia hai nhánh đi về hai tâm thất |
| **Sợi Purkinje** | Tách từ các nhánh bó His, tỏa tới toàn bộ cơ thất |

- Xung từ nút SA lan khắp cơ nhĩ (nhĩ phải trước, nhĩ trái sau), làm nhĩ co. Giáo trình ghi cần **120–220 ms** để xung đi từ nút SA tới nút AV. (Thực ra xung tới nút AV chỉ mất vài chục ms; con số 120–220 ms ứng với cả **khoảng PR**, trong đó phần lớn là thời gian xung bị "giữ chậm" tại nút AV để nhĩ kịp co xong trước thất.)
- Từ nút AV, xung chạy theo bó His và sợi Purkinje với tốc độ **nhanh gấp khoảng 10 lần** so với trong cơ tim thường. Nhờ vậy **toàn bộ cơ thất được kích hoạt gần như đồng thời**, nên thất co mạnh và hiệu quả.
- Nút SA nhận thông tin từ cơ thể (nhu cầu máu, O~2~…) qua **hệ thần kinh thực vật**, và chịu ảnh hưởng của **hormon** (ví dụ khi xúc động). Khi không có các thông tin này, nút SA phát theo nhịp riêng của nó.
- **Tính tự động theo bậc**: nút SA, nút AV, bó His và lưới Purkinje đều tự phát xung được. Nếu nút SA ngừng hoạt động, nút AV thay thế nhưng phát xung chậm hơn. Một miếng cơ tim cắt rời, ngâm trong môi trường dinh dưỡng vẫn co bóp được một thời gian nhờ sợi Purkinje tự kích hoạt.

#### b) Mô hình điện đơn giản của tim

- Dịch gian bào giữa các tế bào tim là một **môi trường dẫn điện thống nhất**. Khi mọi tế bào đều nghỉ, mọi điểm trong đó **đẳng thế**. Vùng nào bị kích hoạt thì **âm** so với vùng khác, do hệ quả của đảo cực.
- Xét lúc **tâm thất thu**: cả vùng thất hưng phấn (âm), trong khi vùng nhĩ đã trở về nghỉ. Hai vùng tích điện trái dấu, nên tim có một **sức điện động** đáng kể.
- Toàn bộ cơ thể quanh tim (dịch điện ly, mạch máu…) là một mạch dẫn điện. Vì vậy có thể coi tim như:
  - một **máy phát điện** công suất rất nhỏ, sức điện động thay đổi, hai cực là **nhĩ** và **thất**; hoặc
  - một **lưỡng cực điện** tạo ra điện trường biến thiên trong môi trường xung quanh.
- Theo mô hình nào thì **mọi điểm trên cơ thể cũng có một điện thế xác định** tại mỗi thời điểm. Đó là cơ sở để ghi điện tim từ da (Giáo trình tr. 183–184).

#### c) Điện tâm đồ (ECG)

**Định nghĩa.** Điện tâm đồ (electrocardiogram — ECG) là **đồ thị biểu diễn hiệu điện thế giữa hai điểm chọn trên cơ thể theo thời gian** (Giáo trình tr. 184).

![Hình 2. Một chu kỳ điện tâm đồ bình thường và các khoảng thời gian chính](dien-tam-do.svg)

| Thành phần | Ý nghĩa (theo giáo trình) | Thời gian |
|---|---|---|
| **Sóng P** | Phát xung ở nút SA và kích hoạt toàn bộ tâm nhĩ | 0,08–0,1 s |
| **Đoạn đẳng điện P–Q** | Xung truyền từ nút SA tới nút AV | 0,12–0,22 s |
| **Phức bộ QRS** | Kích hoạt nút AV và lan truyền xung tới cơ thất (thất khử cực). Q âm, R dương, S âm | ≈ 0,12 s |
| **Đoạn đẳng điện S–T** | Thất đang hưng phấn đồng đều | ≈ 0,12 s |
| **Sóng T** | Tâm thất **trở về trạng thái nghỉ** | — |
| **Đoạn T–P** (tới chu kỳ sau) | Toàn bộ tim nghỉ | — |

- Sóng P, T, U (U hiếm gặp) có thể âm hoặc dương; ở tim khỏe thì **dương**.
- Gợi ý bệnh lý theo sách: **P** ở vận động viên lúc nghỉ thấp hơn người thường; P cao bất thường gợi ý rối loạn kích thích tâm nhĩ. **R quá lớn** gợi ý **phì đại thất**. Trong **rung thất**, sóng R **không rõ ràng**. **T tăng biên độ** phản ánh trao đổi chất tăng ở cơ tim (Giáo trình tr. 185).

> [!cap-nhat] Cách đọc ECG hiện hành
> - Giáo trình ghi QRS phản ánh "sự kích hoạt nút AV và lan truyền xung tới cơ thất", kéo dài khoảng 0,12 s. Hiện nay: hoạt động điện của nút AV quá nhỏ, **không thấy** trên ECG bề mặt; nó nằm "ẩn" trong khoảng PR. **QRS = khử cực tâm thất**. QRS bình thường **dưới 0,12 s** (thường 0,06–0,10 s); QRS ≥ 0,12 s gợi ý **block nhánh**.
> - Giá trị 0,12–0,22 s mà giáo trình gán cho "đoạn đẳng điện P–Q" thực ra là **khoảng PR (PQ)**: tính từ **đầu sóng P** đến **đầu QRS** (như Hình 2). Khoảng PR bình thường **0,12–0,20 s**; PR **> 0,20 s** gợi ý **block nhĩ–thất độ I**.
> - Sóng **tái cực nhĩ** bị phức bộ QRS che lấp nên không thấy riêng.
> - Đi thi lý sinh vẫn trả lời theo số liệu của giáo trình.

> [!vi-du] Tính tần số tim từ ECG
> Khoảng cách giữa hai đỉnh R liên tiếp (khoảng RR) là một chu kỳ tim.
>
> => Tần số tim (lần/phút) = 60 / RR (giây)
>
> Ví dụ RR = 0,8 s → 60/0,8 = **75 lần/phút**. Trên giấy ECG chuẩn chạy 25 mm/s, mỗi ô nhỏ 1 mm = 0,04 s.

#### d) Phương pháp ghi điện tim — chuyển đạo

- Thường dùng **điện cực đặt trên da**. Khi tim co bóp, điện thế mọi điểm trên bề mặt cơ thể đều thay đổi.
- Tại thời điểm sức điện động của tim lớn nhất (đỉnh R), các **đường đẳng thế** phân bố trên cơ thể như hình 5.10 của sách. Đường MN là **trục điện tim**, tức hướng của sức điện động; bình thường nó **song song với trục giải phẫu** của tim. Đường vuông góc với trục điện tim tại một điểm nhất định có điện thế bằng 0. Phía dưới đường này điện thế dương, phía trên âm.
- Chọn hai điểm có **hiệu điện thế lớn nhất** để ghi. Điện cực đặt **trên ngực** cho tín hiệu lớn hơn và ít bị nhiễu bởi điện sinh vật khác.
- Phổ biến nhất: 3 điện cực ở **hai tay và chân trái**, tạo thành **tam giác Einthoven** (Giáo trình tr. 185–186).

**Chuyển đạo** (đạo trình) là hiệu điện thế ghi giữa hai điểm của cơ thể. Ba chuyển đạo chuẩn:

| Chuyển đạo | Ghi hiệu điện thế giữa |
|---|---|
| **D~I~** | tay trái – tay phải |
| **D~II~** | tay phải – chân trái |
| **D~III~** | tay trái – chân trái |

Cần nhiều chuyển đạo để xác định **hình chiếu vectơ sức điện động tim** lên mặt phẳng trước của cơ thể, một dữ liệu dùng trong chẩn đoán.

> [!bay]
> - D~II~ là **tay phải – chân trái** (đường chéo qua tim, thường cho sóng R cao nhất). Không nhầm với D~III~ (tay trái – chân trái).
> - Chân **phải** không thuộc tam giác Einthoven. Trên máy ECG, điện cực chân phải chỉ dùng làm điện cực trung tính/nối đất để giảm nhiễu.

> [!cap-nhat] ECG 12 chuyển đạo
> Giáo trình chỉ trình bày 3 chuyển đạo của tam giác Einthoven. Hiện nay ECG chuẩn có **12 chuyển đạo**: 3 chuyển đạo song cực chi (D~I~, D~II~, D~III~), 3 chuyển đạo đơn cực chi tăng cường (aVR, aVL, aVF) và 6 chuyển đạo trước ngực (V~1~–V~6~).

#### e) Máy tạo nhịp tim (pacemaker)

- Nút SA là "máy tạo nhịp tự nhiên". Khi nó không phát huy chức năng, hoặc xung bị "**kẹt**" trên đường dẫn truyền xuống thất (nguyên nhân phổ biến nhất), nhịp tim bị phá vỡ. Lúc đó nhĩ vẫn co theo nút SA, còn thất co theo nhịp riêng chậm hơn, khoảng **30–40 nhịp/phút**.
- Máy tạo nhịp chạy bằng **pin**, phát xung kích thích theo nhịp định trước. Theo giáo trình: biên độ xung **≈10 mV**, độ rộng xung **vài ms**, tần số **60–70 xung/phút**; điện cực gắn vào cơ tim.
- Loại hiện đại làm việc ở chế độ "**trực chiến**" (standby, theo yêu cầu): chỉ phát xung khi nhịp tim tự nhiên xuống dưới mức đặt trước.
- Máy rất nhỏ, cấy dưới da (giáo trình ghi vùng bụng hoặc ngực). Pin đặc biệt dùng được **10–20 năm**; hết pin thì cần một tiểu phẫu để thay (Giáo trình tr. 186).

> [!cap-nhat] Máy tạo nhịp hiện nay
> - Giáo trình ghi biên độ xung "≈10 mV". Trên thực tế, xung kích thích của máy tạo nhịp có biên độ cỡ **vôn**: thường đặt khoảng **2,5–5 V**, độ rộng **khoảng 0,4–1 ms**. Lý do: phải đủ khử cực vùng cơ tim quanh điện cực tới ngưỡng.
> - Máy thường được cấy ở **vùng ngực dưới xương đòn**. Dây điện cực luồn **theo tĩnh mạch** vào buồng tim nên không cần mổ ngực. Đã có **máy tạo nhịp không dây** (leadless) đặt thẳng trong buồng thất qua ống thông.
> - Người mang máy tạo nhịp cần tránh nguồn điện từ trường mạnh (MRI không tương thích, dao điện đặt gần máy…).

### 2.2. Các điện thế hoạt động khác dùng trong chẩn đoán

#### a) Điện não đồ (EEG)

- Não có khoảng **10^10^ tế bào thần kinh** (nơron), mỗi tế bào như một nguồn điện tí hon. Các nơron liên hệ chặt chẽ nên nhiều tế bào có thể hoạt động **đồng bộ** (synchronized), tạo ra **sóng điện não**. Sóng này truyền được qua xương sọ và da đầu.
- Điện não đồ (electroencephalogram — EEG) được phân tích chủ yếu dựa vào **tần số** (Giáo trình tr. 187).

| Sóng | Tần số | Đặc điểm (theo giáo trình) |
|---|---|---|
| **Delta (δ)** | 0,5–3 Hz | Ngủ sâu; bệnh lý như hôn mê; thường ghi ở phần sau của não |
| **Theta (θ)** | 4–7 Hz | Thường gặp ở trẻ em; giảm nhiều sau 10 tuổi; biên độ 20–50 µV |
| **Alpha (α)** | 8–13 Hz | Người lớn khỏe, **thư giãn** giác quan và tinh thần; biên độ 20–100 µV |
| **Beta (β)** | 14–30 Hz | Chiếm tỷ lệ nhỏ ở người khỏe; biên độ 3–5 µV; đặc trưng vùng trán, trung tâm |
| **Gamma (γ)** | 30–50 Hz | — |

**Cách ghi:** đối tượng đội một mũ có điện cực kim loại nhỏ, tiếp xúc với da đầu qua sáp dẫn điện.

- **Chuyển đạo đơn cực**: một **điện cực hoạt động** đặt ở vùng có hoạt động điện não; **điện cực trung hòa** đặt xa (dái tai hoặc mũi).
- **Chuyển đạo lưỡng cực**: cả hai điện cực đều là điện cực hoạt động, đặt trên vùng hoạt động của não. Điện thế thu được là **tổng đại số** điện thế của hai điện cực.
- **Hệ thống phân bố điện cực quốc tế**: đặt điện cực theo tỷ lệ khoảng cách và trình tự thống nhất (hệ "10–20"). Mục đích là để kết quả của các tác giả so sánh được và theo dõi bệnh nhân được nhất quán.
- **Ứng dụng**: chẩn đoán **động kinh**, khối u, một số dạng nghiện ma túy và các bệnh khác của não (Giáo trình tr. 188).

> [!bay]
> Thứ tự tần số tăng dần: **δ < θ < α < β < γ** ("Đừng Thấy Anh Bỏ Gấp"). Sóng chậm nhất (δ) gặp khi ngủ sâu, hôn mê; α gặp khi **thức, nhắm mắt thư giãn**.

#### b) Điện cơ đồ (EMG)

- **Đơn vị vận động** = một tế bào thần kinh vận động + nhóm sợi cơ do nó chi phối. Lúc nghỉ, điện thế màng sợi cơ người trung bình khoảng **80 mV** (về độ lớn; mặt trong âm).
- Xung từ dây thần kinh tới sợi cơ làm sóng khử cực lan dọc sợi cơ; ta ghi được **điện cơ**. Dạng điện thế phụ thuộc cấu trúc đơn vị vận động, loại điện cực và vị trí điện cực (cắm kim vào cơ hay dán bề mặt).
- Dùng **điện cực kim** khi cơ co chủ động: ghi được điện thế của **một đơn vị vận động**. Đó là một chuỗi xung giống nhau về dạng và biên độ.
- Cơ co **yếu**: chỉ vài đơn vị vận động hoạt động, các xung **thưa thớt**. Cơ co **mạnh**: nhiều đơn vị cùng hoạt động, xung dày đặc, không phân biệt được từng đơn vị nữa. Đó là **điện cơ đồ giao thoa**.
- **Ứng dụng** (electromyogram — EMG): chẩn đoán rối loạn **thần kinh – cơ**, theo dõi phục hồi dây thần kinh sau tổn thương (Giáo trình tr. 188–189).

## 3. Tác dụng của dòng điện lên cơ thể

### 3.1. Phản ứng của cơ và thần kinh với kích thích điện

Có thể kích thích cơ và thần kinh bằng tác nhân cơ, nhiệt, điện, hóa. Thực nghiệm thường chọn **dòng điện** vì hai lý do:

1. Tế bào cơ và thần kinh **nhạy cảm nhất** với kích thích điện.
2. **Cường độ và thời gian** tác động của kích thích điện **đo được và dễ điều chỉnh**. Dạng hay dùng là **xung vuông** (Giáo trình tr. 189).

#### a) Định luật "tất cả hoặc không"

- Kích thích có thời gian xác định nhưng **cường độ nhỏ** chỉ gây **phản ứng tại chỗ**: một biến đổi điện thế nhỏ ở nơi đặt điện cực, biên độ **tăng dần theo cường độ** kích thích, **không lan truyền**.
- Khi cường độ **vượt ngưỡng kích thích**, tế bào hưng phấn: sinh ra **điện thế hoạt động**, lan dọc tế bào với **biên độ không đổi**.
- Kích thích trên ngưỡng mạnh đến đâu cũng chỉ tạo ra **xung giống nhau** (Giáo trình tr. 189–190).

#### b) Đường cong cường độ – thời gian (Lapicque)

Nhà sinh lý học Pháp **L. Lapicque** đề xuất mô tả mỗi kích thích bằng hai thông số: **cường độ I** và **thời gian kéo dài t**. Mỗi kích thích là một điểm trên mặt phẳng (I, t). **Đường cong ngưỡng** dạng **hyperbol** chia mặt phẳng thành:

- **Miền trên ngưỡng**: mọi kích thích trong miền này đều gây hưng phấn.
- **Miền dưới ngưỡng**: không gây hưng phấn.

Ý nghĩa: **cường độ càng nhỏ thì thời gian kích thích cần càng dài**, và ngược lại (Giáo trình tr. 190).

![Hình 3. Đường cong cường độ – thời gian: rheobase b, ngưỡng thời gian C và chronaxie](cuong-do-thoi-gian.svg)

| Đại lượng | Định nghĩa | Ý nghĩa |
|---|---|---|
| **Ngưỡng thời gian C** | Thời gian **ngắn nhất** mà xung phải kéo dài để gây hưng phấn | Xung ngắn hơn C thì mạnh đến đâu cũng không gây hưng phấn. Với tế bào thần kinh động vật có xương sống, C cỡ µs |
| **Rheobase b** (ngưỡng kích thích, *rêôbazơ*) | Cường độ **nhỏ nhất** phải đạt để gây hưng phấn; là tiệm cận ngang (t → ∞ thì I → b) | Dưới b thì kéo dài bao lâu cũng không gây hưng phấn. **b càng nhỏ → mô càng dễ hưng phấn** |
| **Chronaxie** (thời trị, *crô-nắc-xi*) | Thời gian ngắn nhất mà xung có cường độ **gấp đôi rheobase (2b)** phải kéo dài để gây hưng phấn | **Chronaxie càng ngắn → hưng phấn xuất hiện càng nhanh** |

- Thời trị được đo bằng **thời trị kế** (chronaximeter). Dùng phổ biến trong thực nghiệm và lâm sàng, ví dụ đánh giá **mức độ tổn thương dây thần kinh vận động** (Giáo trình tr. 191).
- **Hợp các kích thích (cộng kích thích dưới ngưỡng).** Hai kích thích dưới ngưỡng có thể gây hưng phấn nếu:
  - tác dụng vào **cùng một vị trí**, cách nhau một khoảng thời gian **đủ ngắn**; hoặc
  - tác dụng **đồng thời** vào **hai vị trí đủ gần nhau** của tế bào (Giáo trình tr. 191–192).

> [!bay]
> - Chronaxie đo ở cường độ **2b** (gấp đôi rheobase), **không** phải ở cường độ b. Ở cường độ đúng bằng b thì phải kéo dài "vô hạn".
> - Rheobase là một **cường độ** (mA); chronaxie và C là **thời gian** (ms, µs).
> - Rheobase nhỏ = dễ hưng phấn; chronaxie ngắn = hưng phấn nhanh. Cả hai đều là dấu hiệu mô "nhạy".

> [!vi-du] Công thức Weiss–Lapicque (bổ sung)
> Đường cong ngưỡng thường được mô tả gần đúng bằng công thức:
>
> => I = b · (1 + t~ch~ / t)
>
> - I: cường độ ngưỡng (mA) ứng với xung dài t; b: rheobase (mA); t~ch~: chronaxie (ms).
> - Kiểm tra: t = t~ch~ → I = 2b, đúng định nghĩa. t → ∞ → I → b.
> - Ví dụ: b = 2 mA, t~ch~ = 0,5 ms. Xung dài 0,25 ms cần I = 2 · (1 + 2) = **6 mA**.
>
> Công thức này không có trong giáo trình. Nó cũng không thể hiện ngưỡng thời gian C (đường cong của nó tiệm cận trục I tại t = 0).

> [!ung-dung] Điện chẩn đoán thần kinh – cơ
> Cơ **mất chi phối thần kinh** (ví dụ liệt dây thần kinh ngoại biên) khó hưng phấn hơn: **rheobase tăng, chronaxie kéo dài rõ**. So sánh đường cong cường độ – thời gian theo thời gian giúp theo dõi dây thần kinh có đang hồi phục hay không.

### 3.2. Các thông số điện của cơ thể

Nghiên cứu thông số điện của tế bào và mô có hai mục đích: hiểu đặc tính vật lý của vật chất sống, và theo dõi **trạng thái chức năng**, vì các thông số này tương đối cố định trong điều kiện bình thường (Giáo trình tr. 192).

#### a) Độ dẫn điện với dòng không đổi

=> L = 1 / R   (L: độ dẫn điện, đơn vị S — siemens; R: điện trở, Ω)

=> R = ρ · l / S   (ρ: điện trở suất, Ω·m; l: chiều dài, m; S: tiết diện ngang, m²)

**Vì sao khó đo điện trở suất của mô sống?** Thứ nhất, mô **không đồng nhất, nhiều pha**. Thứ hai, mỗi tế bào có lớp vỏ chất lỏng dẫn điện rất tốt, không tách ra được (tách ra thì tế bào chết). Với dòng một chiều, dòng điện chủ yếu đi qua **khoảng gian bào** (giàu ion). Mà khoảng gian bào lại thay đổi khi tế bào trương hoặc teo.

Giá trị theo giáo trình:

| Mô | Điện trở suất ρ |
|---|---|
| Dịch cơ thể (máu, dịch tủy sống) | ≈ 1 Ω·m — dẫn điện **tốt nhất** |
| Mô mỡ, mô cơ | ≈ 10 Ω·m |
| **Da khô, xương** | ≈ 10^6^ Ω·m — dẫn điện **kém nhất** |

- Độ dẫn điện phụ thuộc trạng thái hoạt động nên dùng được trong chẩn đoán. Ví dụ khi **viêm**: tế bào **trương lên**, khoảng gian bào **hẹp lại**, độ dẫn điện **giảm** (Giáo trình tr. 192).

> [!cap-nhat] Mỡ và cơ không dẫn điện như nhau
> - Giáo trình xếp mô mỡ và mô cơ chung một mức (≈10 Ω·m). Các số liệu đo hiện nay cho thấy **mô mỡ dẫn điện kém hơn cơ** nhiều lần, vì mỡ ít nước và ít điện giải, còn cơ giàu nước.
> - Đây chính là nguyên lý của **cân phân tích thành phần cơ thể bằng trở kháng sinh học** (BIA): cho một dòng xoay chiều rất nhỏ qua người, tổng trở càng cao thì tỷ lệ mỡ ước tính càng lớn. Kết quả dao động theo tình trạng nước (vừa uống nước, vừa tập, mất nước…).

#### b) Tổng trở (impedance) của tế bào và mô

- Màng sinh học giống **tụ điện**: gần như không cho dòng một chiều qua, nhưng cho dòng xoay chiều qua. Vì vậy điện trở của mô với dòng một chiều **rất lớn**. Với dòng xoay chiều, ngoài điện trở thuần còn có **dung kháng**. Điện trở của mô là **tổng trở** Z (Giáo trình tr. 193).
- Bằng chứng có thành phần điện dung: **lệch pha** giữa dòng và thế.

=> U = U~max~ · cos ωt  →  I = I~max~ · cos(ωt − φ)

- **φ ≠ 0** nói lên tính chất "sống" của mô; **mô chết thì φ = 0**.
- Góc lệch pha ở hệ sinh vật **rất lớn**. Ở tần số 10^3^ Hz: thần kinh ếch 64°, cơ thỏ 65°, da ếch 55°, da người 55°.
- **Điện dung phân cực**: tổng trở và góc lệch pha của mô sống **khá ổn định trong một vùng tần số rộng**. Lý do: điện dung của mô không phải điện dung tĩnh (C = const, dung kháng X~C~ = 1/(C·ω) giảm khi tần số tăng). Đó là **điện dung phân cực**, dung kháng của nó gần như không đổi trong một khoảng tần số.
- Đồ thị Z theo lg ω: mô **sống** có Z giảm dần theo tần số (đường cong). Mô **chết** có Z không đổi (đường thẳng), vì các "tụ điện sống" (màng) đã bị phá hủy, chỉ còn điện trở thuần. Ứng dụng: đánh giá **sức sống của mô, cơ quan ghép**.
- **Sơ đồ tương đương** (hình 5.17): R~1~ (điện trở **nội bào**) nối tiếp với C (điện dung phân cực của màng), cả nhánh này mắc **song song** với R~2~ (điện trở **gian bào**) (Giáo trình tr. 193–194).

> [!bay]
> Dòng **một chiều** (và tần số thấp) chủ yếu đi qua **gian bào** (R~2~), vì màng như tụ điện chặn dòng. Dòng **tần số cao** đi được **qua màng** vào nội bào (qua nhánh R~1~–C).

### 3.3. Nguy hiểm do điện

#### a) Các yếu tố quyết định

Mức độ tổn thương phụ thuộc chủ yếu vào **cường độ**, **thời gian** và **đường đi** của dòng điện trong cơ thể. Trong đó **cường độ dòng điện là yếu tố quyết định** (Giáo trình tr. 194).

- **Đường đi**: trên chó, dòng qua vùng tim làm chết nhanh hơn dòng qua trung khu thần kinh. Ở người, tai nạn nặng hơn khi dòng nối **hai chi khác phía đi qua lồng ngực** (ví dụ tay phải → chân trái).
- Không thể nói "bao nhiêu vôn thì nguy hiểm", vì cường độ còn phụ thuộc **điện trở cơ thể** và vật trung gian (giày dép, quần áo):

=> I = U / R   (I: A; U: V; R: Ω)

- Khi điện cực tiếp xúc trực tiếp da, cường độ chủ yếu do **điện trở của da** quyết định. Điện trở da lại phụ thuộc mạnh vào **độ ẩm**: điện trở tay – tay từ khoảng **10^6^ Ω** (da rất khô) xuống **1000 Ω** (da ướt), tức thay đổi **hàng nghìn lần**.
- Bên trong cơ thể, dòng điện đi chủ yếu theo mạch máu, mạch bạch huyết, cơ và bao các dây thần kinh (Giáo trình tr. 194).

#### b) Hiệu ứng sinh lý theo cường độ (dòng 60 Hz, qua thân người, trong 1 giây, điện cực trên da)

| Cường độ | Hiệu ứng sinh lý | U cần với R = 10 000 Ω | U cần với R = 1000 Ω |
|---|---|---|---|
| 1 mA | Ngưỡng cảm giác | 10 V | 1 V |
| 5 mA | Mức "vô hại" cao nhất | 50 V | 5 V |
| 10–20 mA | Bắt đầu **co cứng cơ** (ngưỡng "**không buông**") | 100–200 V | 10–20 V |
| 50 mA | Đau, có thể ngất, kiệt sức; tim, phổi vẫn hoạt động | 500 V | 50 V |
| 100–300 mA | **Rung thất**, tử vong nếu kéo dài; hô hấp vẫn còn | 1000–3000 V | 100–300 V |
| 6 A | Co cứng cơ tâm thất, sau đó tim đập lại bình thường; liệt hô hấp tạm thời; có thể bỏng | 60 000 V | 6000 V |

(Giáo trình tr. 194–195)

- **Ngưỡng "không buông"** (let-go): trên mức này, cơ gấp bàn tay co cứng, nạn nhân **không tự duỗi tay ra được**. Họ bị giữ chặt vào vật dẫn điện, làm hậu quả nặng thêm. Dòng điện trên ngưỡng này được coi là **nguy hiểm**.
- **Tần số**: dòng xoay chiều **50–60 Hz** (điện dân dụng) có ngưỡng nguy hiểm **thấp nhất**, tức là **nguy hiểm nhất**. Dòng trên **10 000 Hz** phải rất lớn mới nguy hiểm (vì không kích thích được cơ, thần kinh), nhưng tần số rất cao lại có xu hướng **gây bỏng**.
- **Dòng một chiều** chỉ gây kích thích cơ, thần kinh lúc **đóng và ngắt mạch** có cường độ cao. Trong tai nạn điện một chiều hàng chục ampe, nạn nhân bị đau đột ngột, choáng, có thể ngất dù não chưa bị kích thích trực tiếp (Giáo trình tr. 195–196).

#### c) Cơ chế tử vong và tác dụng nhiệt

- Tử vong vì điện thường xảy ra **đột ngột**: nạn nhân ngã xuống không kịp kêu, chết sau vài giây (ít khi vài phút). Khám nghiệm thấy tăng áp lực đột ngột trong đường hô hấp (có thể vỡ phế nang), phổi xung huyết dày đặc, đôi khi phù phổi.
- Trước kia người ta cho rằng nguyên nhân chính là liệt hô hấp. **Quan điểm hiện nay: nguyên nhân tử vong phổ biến là rung thất.** Tim đặc biệt nhạy cảm vì nhịp bơm máu do xung điện sinh vật điều khiển; xung điện từ ngoài làm đảo lộn sự điều khiển này.
- **Tác dụng nhiệt**: nhiệt lượng tỏa ra ở mỗi đoạn cơ thể phụ thuộc cường độ dòng và tổng trở của đoạn đó. Vì vậy có thể bỏng ở đoạn này mà không bỏng ở đoạn khác (Giáo trình tr. 196).

> [!vi-du] Vì sao tay ướt nguy hiểm hơn nhiều?
> Chạm vào dây điện 220 V:
> - Da rất khô, R ≈ 10^6^ Ω → I = 220 / 10^6^ = 0,22 mA: dưới ngưỡng cảm giác.
> - Da ướt, R ≈ 1000 Ω → I = 220 / 1000 = 0,22 A = **220 mA**: nằm trong vùng **rung thất**.
>
> Cùng hiệu điện thế nhưng cường độ chênh nhau 1000 lần. Đó là lý do quy tắc an toàn luôn nhấn mạnh "tay khô, chân cách điện".

### 3.4. Đề phòng tai nạn do điện

#### a) Nguyên nhân bị giật điện

- Điều kiện bắt buộc: **hai điểm có chênh lệch điện thế cùng tiếp xúc với cơ thể**.
- Ví dụ: chim đậu trên dây cao thế không bị giật vì hai chân **cùng điện thế**. Ngồi trong ô tô bị dây cao thế rơi vào cũng không sao vì lốp cách điện xe với đất.
- Thuật ngữ: dây "**nóng**" (dây pha) có điện thế khác 0; dây "**nguội**" (dây trung hòa) thường được nối đất; "**đất**" có điện thế bằng 0.
- Đa số tai nạn xảy ra khi nạn nhân **chạm dây nóng đồng thời tiếp xúc với đất**, ví dụ chân trần đứng trên đất, tay vô ý chạm dây nóng (Giáo trình tr. 196).

#### b) An toàn điện trong sinh hoạt và làm việc

- **Không vô tình tạo mạch "dây nóng – cơ thể – đất"**: không chân trần trên nền đất, sàn ẩm. Giày dép bằng da cũng dẫn điện, nhất là khi ẩm hoặc có đinh kim loại; giày dép cao su an toàn hơn. Tường ẩm có thể đóng vai trò "đất" hoặc "dây nóng" khi rò điện.
- **Không cùng lúc chạm hai tay** (hai phần cơ thể) vào vỏ kim loại của một hoặc hai thiết bị. Khi làm việc với thiết bị điện, không chạm vật kim loại xung quanh. Tay ướt dẫn điện tốt, tay khô vẫn dẫn điện nhưng kém hơn. Dùng dụng cụ bọc cách điện, găng cao su vừa phải (quá mỏng dễ rách, quá dày giảm độ chính xác khi thao tác).
- **Nối đất tốt cho thiết bị và có cầu chì**: nếu điện rò ra vỏ kim loại thì dòng xuống đất, cầu chì hoặc bộ phận tự ngắt sẽ cắt điện.
- **Cách ly chỗ nguy hiểm** bằng vật cách điện hoặc lưới kim loại nối đất.
- **Giáo dục, tuyên truyền**, đặt biển báo nguy hiểm, kiểm tra nhắc nhở thường xuyên (Giáo trình tr. 196–197).

> [!ung-dung] Sơ cứu người bị điện giật
> 1. **Cắt nguồn điện trước** (ngắt cầu dao, aptomat). Nếu không cắt được, dùng vật **khô, cách điện** (gậy gỗ khô, nhựa) tách nạn nhân khỏi nguồn. Tuyệt đối không chạm tay trần vào nạn nhân khi còn dòng điện.
> 2. Nạn nhân ngừng thở, ngừng tim (thường do **rung thất**): ép tim – thổi ngạt ngay và dùng **máy khử rung tự động (AED)** nếu có. Rung thất chỉ chấm dứt được bằng sốc điện.
> 3. Đưa đi viện kể cả khi tỉnh: bỏng điện có thể sâu hơn vẻ ngoài. Dòng qua cơ thể có thể gây tổn thương cơ, rối loạn nhịp muộn.

#### c) An toàn điện trong bệnh viện

**Điểm đặc thù — "điện giật vi mô" (microshock).** Các ngưỡng ở mục 3.3 áp dụng cho dòng đi **qua da** và tỏa rộng trong cơ thể. Nếu có **vật dẫn đi thẳng tới tim**, ngưỡng nguy hiểm **nhỏ hơn khoảng 1000 lần**. Trên chó, chỉ **20 µA** đã đủ gây rung thất (Giáo trình tr. 197).

**Nhóm "đặc biệt nhạy cảm" với điện**: bệnh nhân có vật dẫn cắm vào người như **ống thông (catheter)**, **kim truyền dịch**, và nhất là bệnh nhân **đặt máy tạo nhịp tim**. Bệnh viện lại thường xuyên ghi đo, chiếu chụp và điều trị bằng điện (ECG, X quang, điện trị liệu), nên an toàn điện càng phải coi trọng.

**Quy tắc an toàn trong cơ sở khám chữa bệnh** (Giáo trình tr. 197–198):

1. **Mọi thiết bị điện phải được nối đất** (vỏ động cơ, máy X quang, máy điện trị liệu, máy ghi điện tim, điện não…). Phích cắm ba chân có dây nối đất. Phải kiểm tra dây nối đất thường xuyên, vì thiết bị **vẫn chạy bình thường khi dây nối đất bị hở**.
2. Bệnh nhân **không được tiếp xúc với đất**: dây dẫn và vật kim loại trên người bệnh không được chạm đất; giường sắt phải có chân hoặc bánh xe cao su cách điện.
3. Vỏ kim loại trần của thiết bị phải để **xa tầm với** của bệnh nhân.
4. Khi đo điện hoặc điều trị bằng điện, các dây tiếp xúc bệnh nhân phải **cách điện rất tốt với nguồn**.

**Biện pháp 1 là quan trọng nhất**, vì ba biện pháp sau dễ bị vi phạm do bất cẩn.

Với nhóm bệnh nhân đặc biệt nhạy cảm, nhân viên y tế cần thêm:

5. **Không một tay chạm vật dẫn cắm vào người bệnh, tay kia chạm vật kim loại khác.** Một dòng rất nhỏ (≈**50 µA**) có thể qua người bạn vào tim bệnh nhân. Bạn không cảm thấy gì (dưới ngưỡng cảm giác 1 mA) nhưng bệnh nhân có thể **rung thất**.
6. Đặt toàn bộ thiết bị điện liên quan tới bệnh nhân này trong hộp chứa hoặc trên đế cách điện. Bệnh viện hiện đại có giường chuyên dụng với bảng điện riêng; đây là **biện pháp tối ưu**.

> [!bay]
> - 50 µA = 0,05 mA, nhỏ hơn ngưỡng cảm giác qua da (1 mA) **20 lần**, nhưng lại đủ gây rung thất nếu đi **thẳng vào tim** qua catheter.
> - Biện pháp an toàn **quan trọng nhất** trong bệnh viện theo giáo trình: **nối đất mọi thiết bị**. Biện pháp **tối ưu** cho bệnh nhân đặc biệt nhạy cảm: thiết bị trong hộp/đế cách điện, giường chuyên dụng có bảng điện riêng.

> [!cap-nhat] Tiêu chuẩn hiện hành
> - Thiết bị y tế ngày nay được chế tạo theo bộ tiêu chuẩn quốc tế **IEC 60601-1**. Bộ phận tiếp xúc trực tiếp với tim (loại **CF**, ví dụ catheter đo áp lực, dây điện cực ECG trong buồng tim) chỉ được phép có dòng rò qua bệnh nhân khoảng **10 µA** ở điều kiện bình thường (**50 µA** khi có một lỗi). Mức này thấp hơn các ngưỡng nguy hiểm đã nêu.
> - Mạng điện nên có **thiết bị chống dòng rò** (RCD, cầu dao chống giật). Nó tự ngắt khi dòng rò xuống đất vượt khoảng **30 mA**, bổ sung cho biện pháp nối đất.

### 3.5. Tác dụng tích cực của dòng điện và ứng dụng trong y khoa

Dùng ở **mức độ thích hợp**, có theo dõi và điều chỉnh thận trọng, điện cũng như các yếu tố vật lý khác mang lại tác dụng có lợi (Giáo trình tr. 198).

#### a) Hiệu ứng lý – hóa – sinh của dòng một chiều trong mô

- Dịch sinh lý chứa nhiều ion (Na^+^, K^+^, Cl^−^…). Trong điện trường, các ion chuyển động có hướng với tốc độ khác nhau. Các phân tử hữu cơ có cấu trúc **lưỡng cực điện** sắp xếp lại theo hướng điện trường.
- Có nhiều **màng ngăn** (màng tế bào, màng cơ, vách giữa cơ quan) nên ion không đi tự do. Điện tích dồn lại cạnh màng, tạo **điện trường phân cực** ở vùng chịu tác dụng.
- Sự phân bố lại điện tích làm **thay đổi điện thế màng và tính thấm** của màng: ảnh hưởng tới khuếch tán, thẩm thấu. Nhiều chất bình thường không qua được màng nay qua dễ dàng; trao đổi chất mạnh hơn.
- **Phản ứng điện phân tại điện cực** đặt trên da (Giáo trình tr. 198):

=> Tại cực âm: Na^+^ + H~2~O + e → NaOH + ½H~2~↑

=> Tại cực dương: 2Cl^−^ + H~2~O − 2e → 2HCl + ½O~2~↑

> [!bay]
> Dưới **cực âm** sinh ra **kiềm** (NaOH); dưới **cực dương** sinh ra **acid** (HCl). Vì vậy điện cực một chiều đặt trực tiếp lên da có thể gây **bỏng hóa học**. Trong điều trị luôn phải lót **tấm đệm thấm nước** dày giữa điện cực và da. (Giáo trình viết phương trình thứ hai với "− e"; cân bằng điện tích đúng là **−2e**.)

#### b) Dòng một chiều không đổi trong vật lý trị liệu

**Liệu pháp Galvani** (galvanisation): cho dòng một chiều đều đi qua vùng cần điều trị.

- Tác dụng cục bộ: **giãn mao mạch**, tăng tính thấm của màng tế bào và thành mao mạch → tăng trao đổi chất; giảm trương lực cơ; tăng tuần hoàn máu và bạch huyết; tăng tiết dịch ở tuyến; giảm tính phản ứng của thần kinh cảm giác.
- Chỉ định: chống viêm, **giảm đau**, giãn mạch, thúc đẩy tái tạo, điều hòa tiết dịch, tăng dinh dưỡng, thư giãn cơ.
- Thông số: hiệu điện thế khoảng **60–80 V**, nhưng phải tuân thủ cường độ tối đa theo vùng: **chi 20–30 mA**; **mặt 3–5 mA**; **niêm mạc mũi, miệng 2–3 mA**. Thời gian kéo dài **nhiều phút** (Giáo trình tr. 199).

**Điện di dược chất** (electrophoresis, còn gọi điện di ion thuốc):

- Thuốc trong dung dịch phân ly thành ion. Dòng một chiều đẩy các ion này đi qua da và niêm mạc vào cơ thể.
- Tẩm dung dịch thuốc vào lớp bọc của **điện cực cùng dấu với ion có tác dụng**. Ion dương đặt ở cực dương, ion âm ở cực âm, để chúng bị **đẩy** vào cơ thể.
- **Thí nghiệm Leduc**: hai thỏ T~1~, T~2~ cạo lông hai bên sườn, giữa hai thỏ đặt khối bông C tẩm thuốc; hai điện cực rộng ở hai sườn còn lại (T~1~ phía cực dương, T~2~ phía cực âm). Cho dòng **50–100 mA** trong vài phút:
  - Bông tẩm **strychnin sulfat**: gốc strychnin là **ion dương**, đi về **cực âm** → **T~2~** co giật chết, T~1~ không sao.
  - Bông tẩm **KCN**: gốc cyanid là **ion âm**, đi về **cực dương** → **T~1~** chết, T~2~ không sao.
- Ưu điểm: kết hợp được tác dụng của dòng Galvani và của thuốc. Thuốc **thấm sâu hơn, tác dụng lâu hơn và mạnh hơn** (Giáo trình tr. 199–200).

#### c) Dòng xung điện

- **Xung điện**: dòng điện hoặc hiệu điện thế tồn tại trong thời gian rất ngắn. **Dòng xung điện**: chuỗi xung giống nhau nối tiếp.
- Các thông số:
  - **Độ rộng xung τ**: thời gian kéo dài của một xung.
  - **Chu kỳ T**: từ lúc bắt đầu một xung đến lúc bắt đầu xung kế tiếp.
  - **Tần số**: f = 1/T (Hz).
  - **Biên độ** (cường độ) xung: giá trị cực đại (mA, µA hoặc mV, µV).
  - **Dạng xung**: vuông, răng cưa, hình thang, hàm mũ, hình chuông… (Giáo trình tr. 200).

=> f = 1 / T   (f: Hz; T: s)

- Dòng xung một chiều dùng tương tự liệu pháp Galvani, thêm các tác dụng: **an thần, gây ngủ, chống co thắt, kích thích cơ và thần kinh** (phục hồi chức năng). Giáo trình nêu dòng xung còn được **kết hợp với châm cứu trong điện châm** và cho kết quả tốt (Giáo trình tr. 200).

> [!bay]
> Tần số tính theo **chu kỳ T**, không theo độ rộng xung τ. Xung rộng 1 ms lặp lại mỗi 20 ms có f = 1/0,02 s = **50 Hz**, không phải 1000 Hz.

> [!yhct] Điện châm — kim châm làm điện cực
> - **Cơ chế vật lý đã chứng minh**: máy điện châm đưa **dòng xung** qua kim châm vào mô. Dòng này kích thích sợi thần kinh và cơ quanh kim theo đúng các quy luật đã học: phải vượt **ngưỡng** (rheobase, chronaxie), cường độ được điều chỉnh tới mức người bệnh thấy tê tức hoặc cơ giật nhẹ.
> - Vì sao máy điện châm hiện đại dùng **xung hai pha** (đảo chiều, trung bình bằng 0) chứ không dùng dòng một chiều? Dòng một chiều qua đầu kim nhỏ gây **điện phân** (mục 3.5a): ăn mòn kim, sinh acid/kiềm tại chỗ, có thể gây bỏng mô.
> - **An toàn**: không đặt cặp điện cực sao cho dòng **đi ngang qua tim** (ví dụ hai bên ngực). Thận trọng hoặc tránh điện châm ở người **mang máy tạo nhịp**. Tăng cường độ từ từ và kiểm tra máy trước khi bật.
> - **Mức bằng chứng**: giả thuyết opioid nội sinh và vai trò của tần số xung (2 Hz / 100 Hz) đã trình bày ở bài *Dao động và sóng — âm và siêu âm* (mã vl-04, khung YHCT mục 3.5); bằng chứng chủ yếu từ thực nghiệm trên động vật. Việc chọn huyệt theo kinh lạc và các tác dụng "bổ – tả" là **quan niệm của YHCT**, chưa được giải thích bằng vật lý.

#### d) Máy khử rung (máy sốc điện)

- Dòng **nhỏ** qua tim có thể gây rung thất. Dòng **lớn hơn nhiều** lại làm **toàn bộ** cơ thất co cứng cùng lúc. Khi dòng kết thúc, mọi tế bào đồng loạt ở cùng trạng thái, hoạt động hỗn loạn bị chặn lại, và nút SA lấy lại quyền điều khiển. Biện pháp này cũng được dùng khi cấp cứu ngừng tim.
- **Cấu tạo** (hình 5.21): máy biến thế nâng điện xoay chiều lên cao thế → **diode** chỉ cho dòng đi một chiều → nạp vào **tụ điện lớn** tới khoảng **7500 V** (đôi khi tới **10 000 V**) → khóa đóng mạch → hai **điện cực phẳng, rộng (8–12 cm đường kính)** áp lên ngực. Điện cực rộng để phân tán dòng rất lớn, **tránh bỏng**.
- **Cách dùng**: bôi **gel dẫn điện** lên hai vùng ngực, áp điện cực, đóng mạch cho tụ phóng điện. Dòng rất lớn nhưng chỉ kéo dài **vài ms**. Sau đó tụ cần **vài giây** để nạp lại.
- Bệnh nhân **không được** tiếp xúc vật nối đất (giường sắt) hay người khác.
- **Chế độ đồng bộ** (synchronized): máy kết hợp với ECG. Bấm nút thì máy chưa phóng ngay mà **chờ tới pha xuống của sóng R**. Không dùng được khi **không có sóng R** trên ECG (Giáo trình tr. 201–202).

=> W = ½ · C · U²   (W: năng lượng tích trong tụ, J; C: điện dung, F; U: hiệu điện thế, V)

> [!cap-nhat] Khử rung hiện nay
> - Liều sốc được đặt theo **năng lượng (J)**, không theo vôn. Máy hiện đại dùng **dạng sóng hai pha**, thường **120–200 J** (máy một pha cũ: 360 J), hiệu quả hơn ở năng lượng thấp hơn.
> - **Rung thất** (không có QRS rõ): sốc **không đồng bộ**, càng sớm càng tốt. **Sốc đồng bộ** (chuyển nhịp) dùng cho rối loạn nhịp **còn sóng R** như rung nhĩ, nhịp nhanh thất còn mạch. Máy hẹn giờ phóng điện theo sóng R để tránh rơi vào sóng T (giai đoạn dễ gây rung thất).
> - **Máy khử rung tự động ngoài (AED)** đặt ở nơi công cộng: máy tự phân tích ECG và hướng dẫn bằng giọng nói, người không chuyên cũng dùng được.

#### e) Dòng điện xoay chiều trong vật lý trị liệu

=> I = I~max~ · cos ωt ;  f = ω / 2π   (ω: tần số góc, rad/s; f: tần số, Hz)

| Loại | Tần số | Tác dụng chính |
|---|---|---|
| **Hạ tần** | < 1000 Hz | Kích thích cơ co, mệt nhanh → **tập luyện cơ**, tăng lực cơ. Rõ nhất ở xung ngắn, **40–180 Hz**. Dùng **chống teo cơ** trong bệnh thoái hóa thần kinh vận động (điều trị nhiều tháng); cơ co giật làm tăng tuần hoàn và dinh dưỡng cơ |
| **Trung tần** | 1000–300 000 Hz | Kích thích vận động yếu hơn nên cần cường độ cao hơn. Từ khoảng **5000 Hz** trở lên, tác dụng **vận động rõ hơn cảm giác**: cơ co mà không đau |
| **Cao tần** | > 300 000 Hz | **Không** điện phân, **không** kích thích cơ, thần kinh. Năng lượng biến thành **nhiệt** (định luật Joule) |

(Giáo trình tr. 202–203)

**Dòng cao tần** được đặc trưng thêm bằng bước sóng:

=> λ = v / f   (λ: bước sóng, m; v = 3·10^8^ m/s: tốc độ lan truyền; f: tần số, Hz)

| Loại | Bước sóng | Tần số | Tỷ lệ nhiệt mỡ / cơ |
|---|---|---|---|
| Sóng ngắn | ≈ 10 m | ≈ 30 MHz | **9/1** — nóng chủ yếu ở mỡ |
| Sóng siêu ngắn | ≈ 70 cm | ≈ 400 MHz | 1/4 hoặc 1/3 — nhiệt sâu hơn nhưng chưa tới màng xương |
| Sóng cực ngắn (vi sóng) | ≈ 10 cm | ≈ 2500 MHz | 1/1 — phải **bảo vệ mắt** |

- Năng lượng cao tần truyền được qua không gian dưới dạng sóng điện từ, **không cần dây dẫn** nối trực tiếp. Vì vậy trong vật lý trị liệu không phân biệt "dòng cao tần", "sóng cao tần" hay "điện từ trường cao tần".
- Thực chất là đặt bệnh nhân trong **điện trường mạnh** biến thiên trên 300 kHz, gần giống đặt thức ăn vào lò vi sóng. Đây là phương pháp điều trị bằng điện **có từ sớm nhất** (Giáo trình tr. 203).

#### f) Phẫu thuật điện và đốt cắt điện (dao điện)

- Dụng cụ phẫu thuật điện tạo **dòng cao tần** với hiệu điện thế tới **15 000 V**, dùng để cắt và "hàn" mô.
- Ở tần số rất cao, ngưỡng nguy hiểm của dòng điện rất lớn. Bệnh nhân **không cảm nhận** được dòng điện; hiệu ứng chủ yếu là **nhiệt**.
- **Nguyên lý mật độ dòng**:
  - **Điện cực hoạt động rất mảnh, nhọn**: dòng tập trung ở vùng rất hẹp, mật độ dòng cực lớn, làm "cháy" mô → cắt hoặc đốt.
  - **Điện cực trung tính rất rộng**: thường là **tấm dẫn điện lót áp đều dưới người bệnh**, phân tán dòng để tránh bỏng.
  - (Dòng là xoay chiều nên gọi "đi vào", "đi ra" chỉ để dễ hình dung.)
- **Tần số**: khoảng **500–600 kHz** hiệu quả cho **cắt**; khoảng **2–4 MHz** hiệu quả hơn cho **làm đông** (nối mô, cầm máu) và đốt (Giáo trình tr. 203).

> [!ung-dung] Bỏng do dao điện
> Nếu tấm điện cực trung tính bị **bong một phần**, diện tiếp xúc nhỏ lại, mật độ dòng tăng, và bệnh nhân bị **bỏng ở chỗ dán tấm**. Nếu người bệnh chạm vật kim loại nối đất (khung bàn mổ), dòng có thể "tìm đường" qua điểm tiếp xúc nhỏ đó và gây bỏng. Vì vậy phải kiểm tra tấm dán và cách điện người bệnh với bàn mổ.

> [!yhct] Máy dò huyệt — đo điện trở da
> - **Nguyên lý vật lý**: máy đặt một hiệu điện thế nhỏ giữa đầu dò và một điện cực cầm tay, rồi đo dòng qua da, tức là đo **điện trở (độ dẫn điện) của da**. Theo mục 3.3, điện trở da biến đổi rất mạnh (tới hàng nghìn lần) theo **độ ẩm, mồ hôi**.
> - **Quan niệm**: một số tác giả cho rằng tại huyệt, điện trở da **thấp hơn** vùng xung quanh. Máy dò huyệt và các phương pháp như Ryodoraku dựa trên giả thuyết này.
> - **Bằng chứng còn tranh cãi**: các tổng quan hệ thống chưa kết luận chắc chắn. Kết quả đo bị ảnh hưởng mạnh bởi **lực ấn đầu dò**, thời gian tiếp xúc, kích thước điện cực, độ ẩm và mồ hôi, và cả việc đã ấn tại chỗ đó trước đó. Vì vậy máy dò huyệt chỉ nên coi là **công cụ hỗ trợ**. Không dùng nó để "chứng minh" sự tồn tại của huyệt và kinh lạc, và không thay được việc xác định huyệt theo mốc giải phẫu.

## Tóm tắt

| Chủ đề | Điểm cốt lõi |
|---|---|
| Điện thế nghỉ | E~M~ = V~TR~ − V~NG~ < 0 (−50 đến −94 mV). Do K^+^ (trong ×30), Cl^−^ (ngoài ×25) khuếch tán, cân bằng với điện trường; màng hầu như không thấm Na^+^. Goldmann: axon mực P~K~ : P~Na~ : P~Cl~ = 1 : 0,04 : 0,45 → −59,7 mV (đo −60 mV) |
| Nernst (bổ sung) | E = (61,5/z)·log(C~ngoài~/C~trong~) mV ở 37 °C; E~K~ ≈ −91 mV, E~Na~ ≈ +68 mV |
| Bơm Na^+^–K^+^ | 3 Na^+^ ra, 2 K^+^ vào, mỗi ATP; duy trì chênh lệch nồng độ, biểu hiện "sức sống" |
| Điện thế hoạt động | Ngưỡng E~T~ → Na^+^ vào (khử cực, đảo cực ≈+50 mV) → K^+^ ra (tái phân cực) → phân cực vượt mức; xung 0,5–3 ms; biên độ không phụ thuộc kích thích; có thời kỳ trơ; vài trăm xung/s |
| Lan truyền | Dòng điện tại chỗ; không suy giảm; 1–100 m/s; sợi trơn v ∝ √r; myelin (1–3 µm) → nhảy cóc qua eo Ranvier, nhanh và tiết kiệm |
| Tim | SA → AV (120–220 ms) → His → Purkinje (nhanh gấp 10). Block → thất 30–40 nhịp/phút. Tim = máy phát/lưỡng cực điện |
| ECG | P 0,08–0,1 s; PQ 0,12–0,22 s; QRS ≈ 0,12 s (sách); ST ≈ 0,12 s; T = thất về nghỉ. D~I~: TT–TP; D~II~: TP–CT; D~III~: TT–CT |
| Máy tạo nhịp | Pin 10–20 năm; 60–70 xung/phút; chế độ trực chiến |
| EEG | δ 0,5–3; θ 4–7; α 8–13; β 14–30; γ 30–50 Hz; chuyển đạo đơn cực/lưỡng cực; động kinh, u não |
| EMG | Điện cực kim → điện thế đơn vị vận động; co mạnh → điện cơ đồ giao thoa |
| Kích thích điện | Tất cả hoặc không; Lapicque I–t (hyperbol); C, rheobase b, chronaxie (ở 2b); cộng kích thích dưới ngưỡng |
| Thông số điện | ρ: dịch ≈1, mỡ/cơ ≈10 (sách), da khô/xương ≈10^6^ Ω·m; viêm → dẫn điện giảm; φ ≠ 0 ở mô sống (55–65° ở 1 kHz), mô chết φ = 0 |
| Nguy hiểm điện | Cường độ quyết định; 1 mA cảm giác, 10–20 mA không buông, 100–300 mA rung thất; 50–60 Hz nguy hiểm nhất; da khô 10^6^ → ướt 10^3^ Ω; chết do rung thất |
| Bệnh viện | Dây dẫn tới tim: ngưỡng thấp ≈1000 lần (20 µA trên chó; ≈50 µA qua tay nhân viên). Quan trọng nhất: nối đất. Tối ưu: giường, bảng điện riêng, đế cách điện |
| Điện trị liệu | Galvani 60–80 V (chi 20–30 mA, mặt 3–5, niêm mạc 2–3 mA); điện di (thuốc ở cực cùng dấu); dòng xung (τ, T, f = 1/T); hạ tần < 1 kHz, trung tần 1–300 kHz, cao tần > 300 kHz (nhiệt) |
| Khử rung | Tụ ≈7500–10 000 V, điện cực 8–12 cm, vài ms; đồng bộ theo sóng R; W = ½CU² |
| Dao điện | Tới 15 000 V; 500–600 kHz cắt; 2–4 MHz đông; điện cực hoạt động nhọn + tấm trung tính rộng |
