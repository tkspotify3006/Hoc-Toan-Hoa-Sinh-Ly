---
title: Sự biến đổi năng lượng ở cơ thể sống
thoi-gian: 45 phút
muc-tieu:
- Kể được các dạng năng lượng có trong cơ thể sống; định nghĩa đúng nhiệt lượng, nội năng, entropi, năng lượng tự do.
- Phát biểu và viết được biểu thức của nguyên lý thứ nhất và nguyên lý thứ hai nhiệt động lực học; nêu được định luật Hess.
- Giải thích được cách cơ thể biến đổi năng lượng thức ăn (ATP, nhiệt sơ cấp – thứ cấp, phương trình cân bằng năng lượng) và nhu cầu năng lượng của cơ thể.
- Trình bày được trạng thái dừng của hệ mở, sự biến đổi entropi ở cơ thể sống và vì sao phải bảo vệ môi trường sống.
- Vận dụng để hiểu thân nhiệt, các con đường mất nhiệt và một số tình huống lâm sàng (sốt, sốc nhiệt, hạ thân nhiệt).
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Cơ thể là **hệ mở**: luôn trao đổi cả vật chất lẫn năng lượng với môi trường. Nó là **máy chuyển hóa**, không phải máy nhiệt.
> 2. **Nguyên lý I** (bảo toàn năng lượng): δQ = dU + δA. Hệ quả: định luật **Hess**, dùng để tính năng lượng của thức ăn.
> 3. Khoảng 50% năng lượng oxy hóa thức ăn được giữ trong **ATP**; phần còn lại thành **nhiệt sơ cấp Q~1~**. ATP sinh công rồi cũng thành **nhiệt thứ cấp Q~2~**.
> 4. **Nguyên lý II**: trong hệ cô lập, entropi chỉ tăng (ΔS ≥ 0); quá trình tự nhiên đi theo hướng **giảm gradien, giảm năng lượng tự do**.
> 5. Cơ thể sống ở **trạng thái dừng**: dS = dS~e~ + dS~i~ = 0. Nó lấy vào vật chất entropi thấp và thải ra entropi cao, nên cần **môi trường sạch**.

## 1. Các dạng năng lượng trong cơ thể sống

Năng lượng là **số đo chung của chuyển động vật chất**. Mỗi hình thức chuyển động ứng với một dạng năng lượng. Cơ thể được tạo từ nguyên tử, phân tử luôn chuyển động, nên có đủ các dạng năng lượng (Giáo trình tr. 24–26).

| Dạng | Bản chất | Gặp ở đâu trong cơ thể |
|---|---|---|
| **Cơ năng** | Động năng (do vận tốc) + thế năng (do vị trí, cấu hình trong trường lực) | Cơ thể di chuyển; máu chảy trong mạch; khí trong hô hấp; thức ăn trong ống tiêu hóa |
| **Điện năng** | Gắn với điện trường và sự chuyển động của hạt mang điện | Dòng ion qua màng tế bào, dẫn truyền hưng phấn; tế bào phát sóng điện từ ra ngoài |
| **Hóa năng** | Năng lượng giữ các nguyên tử trong phân tử; giải phóng khi liên kết bị phá | Chất tạo hình, chất dự trữ (glycogen, lipid, protid), hợp chất giàu năng lượng (ATP) |
| **Quang năng** | Năng lượng ánh sáng (lượng tử sáng) | Phản ứng quang hóa: thị giác, tổng hợp vitamin D ở da… |
| **Nhiệt năng** | Năng lượng chuyển động **hỗn loạn** của phân tử (năng lượng chuyển động nhiệt) | Toàn cơ thể; giữ nhiệt độ cần cho phản ứng chuyển hóa |
| **Năng lượng hạt nhân** | Dự trữ trong hạt nhân, giải phóng khi hạt nhân bị phá vỡ | Khi xét tương tác của bức xạ hạt nhân, tia vũ trụ với cơ thể |

Để giữ thăng bằng nhiệt, cơ thể luôn có **hai quá trình song song**: tạo ra nhiệt năng cần thiết và thải bớt một phần nhiệt năng ra ngoài (Giáo trình tr. 25–26). Mục 6 sẽ nói kỹ phần "thải nhiệt".

## 2. Biến đổi năng lượng và nguyên lý thứ nhất

### 2.1. Cơ thể biến đổi năng lượng như thế nào?

Cơ thể sống **không phải máy nhiệt** mà là **máy chuyển hóa**. Nó biến năng lượng lấy từ môi trường (chủ yếu là thức ăn) thành nhiệt năng, cơ năng, năng lượng thẩm thấu… mà nó dùng được (Giáo trình tr. 26).

Theo dòng năng lượng, chia làm 3 phần:

- **Năng lượng vào**: chủ yếu là **hóa năng của thức ăn** từ 3 nhóm chất: protid, lipid, glucid. Ngoài ra có nhiệt năng, năng lượng sóng điện từ.
- **Chuyển hóa trong cơ thể**: không có "nhà máy năng lượng chung". Chất hấp thu được đưa tới **từng tế bào** và chuyển hóa qua 3 bước, ở 3 khu vực: **bào tương, ty lạp thể** và các bào quan khác. Phản ứng nào cũng có một phần năng lượng biến thành **nhiệt**.
- **Năng lượng ra**: hóa năng của chất bài tiết, động năng, điện năng và nhiệt năng.

Nhu cầu tiêu hao năng lượng chia 3 loại lớn: **duy trì sự sống** (chuyển hóa cơ sở, vận cơ, điều nhiệt, tiêu hóa), **phát triển cơ thể**, **sinh sản**.

### 2.2. Hệ nhiệt động — ba loại hệ

Hệ nhiệt động là tập hợp **rất nhiều** phần tử. Vì thế nhiệt độ, áp suất chỉ có nghĩa với cả tập hợp, không có nghĩa với một phân tử riêng lẻ. Nhiệt động học cho biết một quá trình **có xảy ra được không và theo chiều nào** về mặt năng lượng; nó **không** giải thích cơ chế (Giáo trình tr. 27).

| Hệ | Trao đổi năng lượng | Trao đổi vật chất | Ví dụ |
|---|---|---|---|
| **Cô lập** | Không | Không | Bình cách nhiệt kín lý tưởng |
| **Kín** | Có | Không (khối lượng không đổi) | Bình kín không cách nhiệt |
| **Mở** | Có | Có | **Cơ thể sống** |

Cơ thể sống là hệ mở đặc biệt: tạo bởi protid và các chất khác, **tự tái tạo** và **tự phát triển** được.

**Thông số trạng thái**: T, p, V, nội năng U, entropi S, nồng độ C… Chỉ cần một thông số đổi là hệ đã thực hiện một **quá trình nhiệt động**. Quá trình mà hệ quay về đúng trạng thái đầu gọi là **chu trình**.

### 2.3. Nhiệt lượng và nhiệt dung riêng

Cho hai vật nóng – lạnh tiếp xúc trong hệ cô lập, không có phản ứng hóa học. Vật nóng nguội đi, vật lạnh nóng lên đến khi cùng nhiệt độ t. Thực nghiệm cho:

=> c~1~m~1~(t − t~1~) = c~2~m~2~(t~2~ − t)  (nhiệt lượng thu = nhiệt lượng tỏa)

Từ đó định nghĩa **nhiệt lượng**:

=> ΔQ = m·c·Δt

- ΔQ: nhiệt lượng (cal hoặc J); m: khối lượng (g hoặc kg); Δt: độ biến thiên nhiệt độ (°C, bằng ΔT tính theo K); c: **nhiệt dung riêng** (tỷ nhiệt).
- **1 calo (cal)** = nhiệt lượng làm 1 g nước nóng từ 14,5 °C lên 15,5 °C.
- **Nhiệt dung riêng** c = ΔQ/(m·Δt): nhiệt lượng cần để 1 đơn vị khối lượng chất nóng thêm 1 °C. Đơn vị theo sách: cal/g·độ. Ở nhiệt độ phòng coi như không đổi.
- **Nhiệt dung** của một vật = m·c (cal/độ).
- Dụng cụ đo nhiệt lượng: **nhiệt lượng kế** (đơn giản nhất là nhiệt lượng kế nước).

| Đối tượng (Giáo trình tr. 29) | Nhiệt dung riêng |
|---|---|
| Nước | 1 cal/g·độ |
| **Cơ thể người (trung bình)** | **0,8 cal/g·độ** |
| Máu | 0,93 cal/g·độ |
| Xương đặc | 0,3–0,4 cal/g·độ |

**Vì sao cơ thể gần bằng nước?** Nước chiếm ≈ 60% khối lượng người trưởng thành (trẻ sơ sinh ≈ 75–80%; xem hs-15). Mô càng nhiều nước thì c càng gần 1 (máu); mô ít nước thì c thấp (xương).

> [!ung-dung] Nhiệt dung lớn giúp thân nhiệt ổn định
> Người 60 kg có nhiệt dung khoảng 60 000 g × 0,8 = 48 000 cal/độ = **48 kcal/độ**. Muốn thân nhiệt tăng 1 °C, cơ thể phải "giữ lại" khoảng 48 kcal. Vì thế thân nhiệt không dao động mạnh theo từng bữa ăn hay từng đợt vận động ngắn. Ngược lại, khi đã sốt cao hay hạ thân nhiệt, phải lấy ra hoặc cấp vào một lượng nhiệt **lớn** mới đưa thân nhiệt về bình thường.

> [!cap-nhat] Đơn vị SI
> Giáo trình dùng calo. Đơn vị SI của nhiệt lượng là **joule (J)**; nhiệt dung riêng là **J/(kg·K)**.
> - 1 cal ≈ 4,18 J; 1 kcal ≈ 4,18 kJ. Chính xác: calo theo định nghĩa của sách (nước từ 14,5 lên 15,5 °C) ≈ 4,186 J; calo "nhiệt hóa học" dùng trong dinh dưỡng = 4,184 J (bài trước dùng giá trị này). Chênh lệch không đáng kể khi tính toán.
> - Nước: c ≈ 4 186 J/(kg·K); cơ thể: c ≈ 0,8 × 4 186 ≈ 3 350 J/(kg·K) theo số liệu sách (tài liệu sinh lý hiện nay hay dùng ≈ 3 500 J/(kg·K)).
> - "Calo" trên nhãn thực phẩm thực chất là **kcal** (còn gọi Calorie viết hoa). Nhãn hiện nay thường ghi cả kcal và kJ.

### 2.4. Công — liên hệ giữa công và nhiệt

**Công cơ học** đặc trưng cho sự trao đổi năng lượng khi có lực làm vật dịch chuyển:

=> dA = F·ds·cos α

(F: lực, N; ds: quãng đường dịch chuyển, m; α: góc giữa lực và hướng dịch chuyển; A: J).

Với khối khí trong xi lanh bị pít-tông nén hoặc giãn (áp suất p, thể tích V):

=> dA = −p·dV ;  từ V~1~ đến V~2~: A = −∫p·dV

Công bằng **diện tích dưới đường cong** p–V (sách minh họa bằng quá trình đẳng nhiệt, nhưng biểu thức đúng cho mọi quá trình biến đổi chậm, cân bằng). Theo quy ước ở đoạn này của sách: khí **bị nén** thì nhận năng lượng (dA > 0), **giãn** thì mất năng lượng (dA < 0).

**Công và nhiệt** đều là hai **hình thức truyền năng lượng**:

- Truyền **nhiệt**: năng lượng trao đổi trực tiếp giữa các phần tử chuyển động **hỗn loạn**.
- Thực hiện **công**: năng lượng truyền qua chuyển dời **có hướng** của cả vật (hoặc một phần vật).
- Hai thứ chuyển hóa lẫn nhau: ma sát biến công thành nhiệt; đốt nóng làm vật giãn nở, một phần nhiệt thành công.

Thí nghiệm Joule (thế kỷ 19) cho:

=> Đương lượng công của nhiệt: J = A/Q = 4,18 J/cal

=> Đương lượng nhiệt của công: J' = Q/A = 0,24 cal/J

> [!bay] Công và nhiệt **không phải** là dạng năng lượng
> Chúng là **số đo mức trao đổi** năng lượng. Ở một trạng thái, hệ **có** năng lượng (nội năng) xác định, nhưng **không "có" công hay nhiệt**. Công và nhiệt phụ thuộc vào **con đường** đi từ trạng thái này sang trạng thái kia: chúng là **hàm quá trình**, không phải hàm trạng thái.

### 2.5. Nội năng

**Nội năng U** là năng lượng dự trữ toàn phần của **mọi dạng chuyển động và tương tác của các phần tử bên trong hệ**: chuyển động nhiệt, dao động phân tử, năng lượng điện tử, năng lượng hạt nhân…

- **Không** tính vào nội năng: động năng của cả hệ chuyển động tập thể, và thế năng của hệ trong trường lực ngoài.
- Không đo được trị tuyệt đối của U, chỉ đo được **độ biến thiên** dU.
- U là **hàm trạng thái**: ΔU = U~2~ − U~1~, không phụ thuộc đường đi. Sau một chu trình: ΔU = 0.

### 2.6. Nguyên lý thứ nhất nhiệt động lực học

Nhiệt lượng δQ hệ nhận được dùng để tăng nội năng dU, phần còn lại biến thành công δA **hệ thực hiện** lên môi trường:

=> δQ = dU + δA

- dU: biến thiên nội năng (hàm trạng thái);
- δQ: nhiệt lượng hệ **nhận** (hàm quá trình);
- δA: công hệ **sinh ra** (hàm quá trình). Đơn vị đều là J (hoặc cal).

Phát biểu (Giáo trình tr. 32): nhiệt truyền cho hệ dùng để làm tăng nội năng của hệ và biến thành công mà hệ thực hiện lên môi trường ngoài. Đây chính là **định luật bảo toàn và biến đổi năng lượng** viết cho các quá trình nhiệt động: năng lượng không tự sinh ra, không tự mất đi, chỉ biến từ dạng này sang dạng khác.

**Hệ quả**

| Điều kiện | Kết quả | Ý nghĩa |
|---|---|---|
| δQ = 0 | δA = −dU | Không nhận nhiệt mà muốn sinh công thì **phải giảm nội năng** |
| δQ = 0 và chu trình (dU = 0) | δA = 0 | **Không có động cơ vĩnh cửu loại một** (sinh công mà không cần năng lượng) |
| Hệ cô lập: δQ = δA = 0 | dU = 0, U~2~ = U~1~ | **Nội năng của hệ cô lập được bảo toàn** |

> [!bay] Quy ước dấu của công
> - Trong mục công (tr. 29) sách viết dA = −p·dV, tức coi công **hệ nhận** là dương. Trong nguyên lý I (tr. 31) thì δA là công **hệ sinh ra**. Hai chỗ dùng hai quy ước ngược nhau. Khi làm bài, cứ hỏi lại: "A là công hệ **nhận** hay hệ **sinh**?".
> - Sách Hóa học hiện nay thường viết ΔU = Q + W với W là công hệ **nhận**. Nội dung vật lý giống nhau, chỉ khác dấu. Đi thi môn này: dùng **δQ = dU + δA** theo giáo trình.

### 2.7. Định luật Hess — đo năng lượng của thức ăn

> Năng lượng sinh ra trong một quá trình hóa học phức tạp **chỉ phụ thuộc trạng thái đầu và trạng thái cuối**, không phụ thuộc các giai đoạn trung gian (Giáo trình tr. 32).

Đi từ chất đầu A đến sản phẩm cuối B theo đường trực tiếp (E), qua chất trung gian C (E~1~, E~2~), hay qua M rồi N (E~3~, E~4~, E~5~) thì tổng năng lượng như nhau:

=> E = E~1~ + E~2~ = E~3~ + E~4~ + E~5~

**Vì sao?** Năng lượng của hệ là hàm trạng thái (hệ quả của nguyên lý I). Định luật Hess vì thế là một **hệ quả của nguyên lý I**.

> [!ung-dung] Đốt thức ăn trong bom nhiệt lượng kế
> Trong cơ thể, glucose bị oxy hóa qua hàng chục bước (đường phân, chu trình Krebs, chuỗi hô hấp). Ngoài phòng thí nghiệm, ta đốt cháy nó một lần thành CO~2~ và H~2~O. Theo Hess, **hai con đường cho cùng một năng lượng**, vì đầu và cuối như nhau. Nhờ vậy người ta đo được **giá trị năng lượng của thức ăn** bằng cách đốt trong nhiệt lượng kế. Số liệu dinh dưỡng thường dùng: glucid ≈ 4 kcal/g, protid ≈ 4 kcal/g, lipid ≈ 9 kcal/g.
>
> Riêng protid: trong cơ thể nó chỉ bị oxy hóa đến **urê** (không đến N~2~), nên năng lượng thu được thấp hơn khi đốt cháy hoàn toàn. Đó không phải ngoại lệ của định luật Hess, mà vì **trạng thái cuối khác nhau**.

> [!bay] Nguyên lý I không cho biết chiều diễn biến
> Nguyên lý I chỉ nói các dạng năng lượng **tương đương về lượng**. Nó không cho biết một dạng có biến **hoàn toàn** thành dạng khác được không, và quá trình tự xảy ra theo chiều nào. Đó là việc của nguyên lý II (mục 4).

## 3. Áp dụng nguyên lý I cho cơ thể sống

### 3.1. Bốn dạng công trong cơ thể

| Dạng công | Là gì | Ví dụ |
|---|---|---|
| **Công hóa học** | Tổng hợp chất phân tử lượng **cao** từ chất phân tử lượng thấp; các phản ứng cần năng lượng | Tổng hợp protid, acid nucleic, đa đường |
| **Công cơ học** | Dịch chuyển cơ thể, cơ quan, bộ phận nhờ lực cơ học; do **cơ co** thực hiện | Đi lại, tim bóp, hô hấp |
| **Công thẩm thấu** | Vận chuyển chất qua màng từ nơi nồng độ **thấp** đến nơi nồng độ **cao** (**vận chuyển tích cực**, ngược khuếch tán) | Bơm Na^+^–K^+^, tái hấp thu ở thận |
| **Công điện** | Vận chuyển ion trong điện trường, tạo hiệu điện thế và dòng điện | Điện thế màng, dẫn truyền xung thần kinh |

### 3.2. ATP — "nhiên liệu vạn năng" của tế bào

Năng lượng thức ăn (và năng lượng mặt trời mà thực vật dự trữ qua quang hợp) **không** được dùng trực tiếp để sinh công. Trước hết nó được chuyển vào các liên kết giàu năng lượng, chủ yếu là **ATP** (adenosin triphosphat). Sau đó ATP bị thủy phân ở đúng nơi cần, cung cấp năng lượng cho cả 4 loại công. Vì vậy ATP được gọi là **nhiên liệu vạn năng** của tế bào (Giáo trình tr. 33–34).

=> ATP + H~2~O → ADP + H~3~PO~4~ + (7,0 ÷ 8,5) kcal/mol

![Hình 1. Dòng năng lượng trong cơ thể: thức ăn → ATP → công → nhiệt (theo ý Giáo trình tr. 33–35)](dong-nang-luong.svg)

### 3.3. Hai loại nhiệt lượng: sơ cấp Q~1~ và thứ cấp Q~2~

| | **Nhiệt sơ cấp Q~1~** (nhiệt cơ bản) | **Nhiệt thứ cấp Q~2~** (nhiệt tích cực) |
|---|---|---|
| Nguồn gốc | Năng lượng **tán xạ tất yếu** dưới dạng nhiệt vì phản ứng hóa sinh **không thuận nghịch**, hiệu suất < 100% | Năng lượng tỏa ra khi **liên kết giàu năng lượng (ATP) bị cắt** để sinh công, rồi rốt cuộc thành nhiệt |
| Khi nào | Xuất hiện **ngay** khi cơ thể hấp thu O~2~ và thức ăn | Sau khi ATP được dùng cho hoạt động chủ động |
| Tỷ lệ | ≈ 50% năng lượng oxy hóa thức ăn (bình thường) | ≈ 50% còn lại, được dự trữ trong ATP rồi mới thành nhiệt |
| Phụ thuộc | Tỷ lệ thuận cường độ trao đổi chất, tỷ lệ nghịch hiệu suất | Mức hoạt động chủ động của cơ thể |

Bình thường hai loại nhiệt **cân bằng**: Q~1~ giảm thì Q~2~ tăng và ngược lại. Khi **bệnh lý**, khả năng tạo liên kết giàu năng lượng giảm, nên **Q~1~ chiếm phần lớn**.

> [!vi-du] Chống lạnh bằng cách nào?
> Khi cường độ tỏa nhiệt tăng (trời lạnh), cơ thể phải tăng sinh nhiệt để giữ thân nhiệt. Thường đó là **nhiệt loại hai**: tăng phản ứng động lực, như **co cơ (run)**, dùng ATP dự trữ. Cũng có thể tăng sinh nhiệt không qua co cơ. Ví dụ động vật ngủ đông giữ thân nhiệt bằng cách đốt dần **mỡ dự trữ** (Giáo trình tr. 35).

### 3.4. Phương trình cân bằng năng lượng của cơ thể

Thí nghiệm trên người và động vật: khi **không sinh công ra ngoài**, tổng nhiệt cơ thể tỏa ra **gần bằng** nhiệt lượng thu được khi đốt cháy thức ăn đến CO~2~ và H~2~O. Đây là bằng chứng rằng **nguyên lý I đúng với cơ thể sống**.

=> ΔQ = ΔE + ΔA + ΔM

- ΔQ: nhiệt lượng sinh ra do đồng hóa thức ăn;
- ΔE: năng lượng mất ra môi trường xung quanh;
- ΔA: công cơ thể thực hiện để chống lại lực của môi trường ngoài;
- ΔM: năng lượng dự trữ dưới dạng hóa năng.

**Kết quả đo trong một ngày đêm** (Giáo trình tr. 35–36):

| Năng lượng vào | | Năng lượng ra | |
|---|---|---|---|
| Protein 56,8 g | 237 kcal | Tỏa ra xung quanh | 1 374 kcal |
| Lipid 140,0 g | 1 307 kcal | Bốc hơi qua **da** | 227 kcal |
| Glucid 79,98 g | 335 kcal | Bốc hơi qua **hô hấp** | 181 kcal |
| | | Khí thải | 43 kcal |
| | | Phân và nước tiểu | 23 kcal |
| | | Dạng khác | 31 kcal |
| **Cộng** | **1 879 kcal** | **Cộng** | **1 879 kcal** |

Vào = ra: đúng **bảo toàn năng lượng**. Ăn thiếu thì gầy yếu, rét, không đủ sức lao động; ăn thừa thì năng lượng dư thành ΔM (mỡ), dẫn tới béo phì. Với trẻ em phải tránh cả suy dinh dưỡng lẫn thừa cân.

> [!vi-du] Tự kiểm tra số liệu
> - Chia năng lượng cho khối lượng: protein 237/56,8 ≈ 4,2 kcal/g; glucid 335/80 ≈ 4,2 kcal/g; lipid 1 307/140 ≈ 9,3 kcal/g. Lipid cho năng lượng gấp đôi.
> - Mất nhiệt do **bay hơi** (da + hô hấp) = 408/1 879 ≈ **22%** tổng năng lượng ra. Con số này khớp với tài liệu sinh lý (mục 6).

### 3.5. Năng lượng ở hệ tim mạch

- **Công suất cơ học của tim** ≈ **1,3–1,4 W**, rất nhỏ so với **chuyển hóa cơ sở** của toàn cơ thể ≈ **100 W**.
- Cơ tim còn phải giữ **trương lực** (giống tì tay lên ghế: không dịch chuyển nhưng vẫn mỏi). Tính cả trương lực, tổng công suất của cơ ≈ **13 W**, tức ≈ 13% chuyển hóa cơ sở.
- Cơ tim lấy năng lượng chủ yếu từ **oxy hóa lipid** (sách ghi "phospholipid"), không chủ yếu từ phân ly glucose. Khi thiếu ATP, tim tăng phân ly glucose, sinh **acid lactic** có hại. Thiếu O~2~ cho cơ tim gây thiếu ATP, làm tim yếu.

> [!cap-nhat] Nhiên liệu của cơ tim
> Giáo trình ghi cơ tim oxy hóa "phospholipid". Hiện nay biết rõ: lúc nghỉ, khoảng **60–90% ATP** của cơ tim đến từ oxy hóa **acid béo tự do** (lấy từ máu), phần còn lại từ glucose, lactat, thể ceton. Ý chính của sách (tim dùng lipid là chủ yếu; thiếu O~2~ thì chuyển sang đường phân yếm khí, tích acid lactic) vẫn đúng.
- **Hiệu suất cơ tim** biến năng lượng thành công cơ học lên tới **20–30%** khi lao động nặng. Sách so sánh: máy hơi nước 3,5%, máy nổ 7,5%.
- **Mạch máu đàn hồi**: tâm thu, máu đẩy vào làm thành mạch giãn, một phần động năng thành **thế năng đàn hồi**. Tâm trương, thành mạch co lại, trả năng lượng cho dòng máu. Nhờ vậy tim bóp **từng nhịp** mà máu vẫn chảy **liên tục**.
- **Sóng mạch** truyền dọc thành mạch: ở động mạch chủ **4–5 m/s**, **không** phải là tốc độ dòng máu. Người lớn tuổi thành mạch kém đàn hồi nên **sóng mạch truyền nhanh hơn**.
- Ma sát trong máu và với thành mạch làm năng lượng tiêu hao dần, nên áp suất và tốc độ máu giảm dần dọc theo hệ mạch.

> [!ung-dung] Vận tốc sóng mạch và xơ cứng động mạch
> Đo **vận tốc sóng mạch** (PWV, ví dụ giữa động mạch cảnh và động mạch đùi) là cách không xâm nhập để đánh giá **độ cứng động mạch**. PWV càng cao thì mạch càng cứng, nguy cơ tim mạch càng lớn. Đây chính là điều sách nói: thành mạch mất đàn hồi thì sóng mạch nhanh lên.

## 4. Nguyên lý thứ hai nhiệt động lực học

### 4.1. Gradien

Với một hàm vô hướng f(x, y, z), **gradien** grad f là một **vectơ** gồm các đạo hàm riêng ∂f/∂x, ∂f/∂y, ∂f/∂z. Nếu f chỉ phụ thuộc x thì grad f = df/dx.

Gradien cho biết **f thay đổi nhanh đến đâu và theo hướng nào** trong không gian.

**Tế bào sống có rất nhiều gradien**, tế bào chết thì không còn:

- gradien **thẩm thấu** (giữ sức trương của tế bào);
- gradien **nồng độ** do các chất phân bố không đều trong – ngoài tế bào;
- gradien **điện** ở màng do ion phân bố không đều (cơ sở của xung thần kinh).

Gradien chính là **khả năng sinh công** của tế bào sống.

### 4.2. Entropi

**Ví dụ của sách** (tr. 38–39): bình chia hai ngăn A, B; có 6 phân tử khác nhau, ban đầu cả 6 ở ngăn A. Bỏ vách ngăn, các phân tử khuếch tán tự do.

| Ngăn A – ngăn B | 6–0 | 5–1 | 4–2 | **3–3** | 2–4 | 1–5 | 0–6 | Tổng |
|---|---|---|---|---|---|---|---|---|
| Số cách phân bố W | 1 | 6 | 15 | **20** | 15 | 6 | 1 | 64 |
| Xác suất toán học p | 1/64 | 6/64 | 15/64 | **20/64** | 15/64 | 6/64 | 1/64 | 1 |

- **Xác suất nhiệt động W** = số cách thực hiện một phân bố. W **≥ 1**, khác xác suất toán học p (0 ≤ p ≤ 1).
- Hệ tự chuyển từ trạng thái **ít cách** phân bố (W nhỏ, "trật tự") sang trạng thái **nhiều cách** (W lớn, "hỗn loạn"). W = C(6, k), ví dụ C(6, 3) = 20.

**Định nghĩa 1 (Boltzmann):**

=> S = k·ln W

(S: entropi, J/K; k = 1,38·10^−23^ J/K: hằng số Boltzmann; W: xác suất nhiệt động). Dùng ln W vì nó đồng biến với W mà gọn hơn nhiều.

**Định nghĩa 2 (theo nhiệt):**

=> dS = δQ/T ;  nhiều phần có nhiệt độ khác nhau: dS = Σ δQ~i~/T~i~

(T: nhiệt độ **tuyệt đối**, K; δQ: nhiệt lượng hệ trao đổi.)

**Tính chất của entropi:**

- Là **hàm trạng thái** (chỉ phụ thuộc trạng thái đầu và cuối).
- Có tính **cộng** được: entropi của hệ phức tạp = tổng entropi các phần.
- Chỉ xác định sai khác một hằng số cộng, nên ta làm việc với ΔS.
- Hệ **nhận nhiệt** (δQ > 0) thì S **tăng**; tỏa nhiệt thì S giảm.
- Entropi là **số đo mức độ hỗn loạn** của hệ.

**Vì sao nhiệt chỉ tự truyền từ nóng sang lạnh?** Trong hệ cô lập có hai phần T~1~ < T~2~, phần lạnh nhận δQ, phần nóng mất δQ:

=> dS = δQ/T~1~ − δQ/T~2~ > 0  (vì T~1~ < T~2~)

Truyền nhiệt từ nóng sang lạnh làm **entropi toàn hệ tăng**, nên nó tự xảy ra.

### 4.3. Năng lượng tự do

Thay δQ = T·dS vào nguyên lý I:

=> δA = T·dS − dU = −d(U − T·S) = −dF  ⇒  U = F + T·S

- **F = U − T·S**: **năng lượng tự do**. Đây là phần nội năng **có thể biến thành công**; nó đặc trưng cho **khả năng sinh công** của hệ.
- **T·S**: **năng lượng liên kết**, phần nội năng **không** biến thành công được.
- Năng lượng tự do không phải dạng năng lượng mới, chỉ là tên gọi một **phần** của nội năng.

**Trạng thái cân bằng nhiệt động**: các thông số có giá trị xác định và không đổi khi không có tác động ngoài; không còn truyền nhiệt, không còn phản ứng hóa học.

Với **hệ cô lập**: U không đổi, S chỉ giữ nguyên hoặc tăng. Vì vậy T·S tăng, F giảm. Khi cân bằng: **S đạt cực đại, F đạt cực tiểu**.

### 4.4. Quá trình thuận nghịch và không thuận nghịch

| | **Thuận nghịch** | **Không thuận nghịch** |
|---|---|---|
| Đi ngược lại | Qua đúng các trạng thái trung gian của chiều thuận | **Không** qua lại các trạng thái trung gian cũ |
| Trạng thái trung gian | Toàn là trạng thái cân bằng (quá trình cân bằng) | Trạng thái không cân bằng |
| Sau khi về trạng thái đầu | Môi trường **không bị biến đổi** | Môi trường **bị biến đổi** |
| Ví dụ | Con lắc dao động không ma sát (lý tưởng) | Người lớn lên rồi chết; trứng rơi vỡ; nước hoa khuếch tán; ma sát sinh nhiệt; nhiệt truyền nóng → lạnh |

Mọi quá trình **thực** trong tự nhiên đều không thuận nghịch. Sách đưa 3 ví dụ:

1. **Khuếch tán khí**: hai ngăn chứa cùng loại khí với mật độ n~A~ > n~B~. Bỏ vách, khí tự khuếch tán đến khi mật độ đều. Công có thể thu được:

=> A = R·T·ln(n~A~/n~B~)

(R: hằng số khí, 8,31 J/(mol·K); T: nhiệt độ tuyệt đối). Khi n~A~ = n~B~ thì ln 1 = 0, A = 0: **hết gradien thì hết khả năng sinh công**.

2. **Truyền nhiệt**: hai vật nóng – lạnh tiếp xúc, nhiệt chỉ tự đi từ nóng sang lạnh.

3. **Hai bình nước có nắp**: bình A rất nhiều nước nhưng nhiệt độ gần bằng môi trường; bình B ít nước nhưng nóng hơn hẳn. Hơi nước ở **B đẩy bật nắp được**, ở A thì không, dù A dự trữ nhiều nhiệt hơn.

**Rút ra:**

- Chênh lệch nhiệt độ giữa hệ và môi trường **càng lớn** thì nhiệt năng **càng dễ dùng** để sinh công.
- Đánh giá một hệ phải dựa vào **khả năng sinh công**, không chỉ dựa vào tổng năng lượng dự trữ.
- Các dạng năng lượng khác có thể biến **hoàn toàn** thành nhiệt; nhiệt **không** biến hoàn toàn thành dạng khác.
- Quá trình tự nhiên luôn đi kèm **giảm gradien** và **giảm trật tự** của hệ cô lập. Muốn đi ngược lại (bơm chân không, máy lạnh) phải **tốn công từ bên ngoài**.

### 4.5. Phát biểu nguyên lý thứ hai

Các cách phát biểu tương đương (Giáo trình tr. 44):

- Tính trật tự của một hệ cô lập chỉ có thể giữ nguyên hoặc giảm dần.
- Không có chu trình nào mà kết quả **duy nhất** là biến nhiệt thành công.
- **Không thể có động cơ vĩnh cửu loại hai** (lấy nhiệt từ **một** nguồn rồi biến hết thành công).
- Theo entropi: **trong hệ cô lập, chỉ những quá trình làm entropi tăng mới tự diễn biến; giới hạn là trạng thái entropi cực đại.**

=> ΔS ≥ 0 (hệ cô lập) ;  khi cân bằng: dS/dt = 0, S = S~max~

**Ý nghĩa và giới hạn:**

- Nguyên lý II mang tính **thống kê**: đúng với số đông phần tử. Trạng thái xác suất thấp vẫn **có thể** xảy ra, chỉ là rất hiếm.
- **Không** áp dụng cho toàn vũ trụ (coi như hệ cô lập), cũng **không** áp dụng cho thế giới hạt cơ bản.
- Nguyên lý II **độc lập** với nguyên lý I: nguyên lý I cho biết **lượng**, nguyên lý II cho biết **chiều** và **khả năng sinh công**.

### 4.6. Entanpi, hiệu suất và năng lượng trong phản ứng hóa sinh

**Entanpi** (hàm chứa nhiệt):

=> H = U + p·V ;  đẳng áp: ΔH = ΔU + p·ΔV = ΔQ

Nhờ entanpi, dễ tính năng lượng của phản ứng hóa học. Khi đốt chất trong bom nhiệt lượng kế: ΔH = −ΔQ (phản ứng tỏa nhiệt thì ΔH < 0).

**Hiệu suất của cơ chế sinh học.** Cơ thể chỉ dùng được **năng lượng tự do** để sinh công:

=> η = ΔA/ΔF

(ΔA: công sinh ra; ΔF: phần năng lượng tự do bị giảm đi). Thức ăn và O~2~ đưa vào cơ thể là nguồn **năng lượng tự do**; năng lượng này được chuyển thành các **gradien** khác nhau.

**Phản ứng hóa sinh** diễn ra ở **p và T không đổi**, nên dùng **thế nhiệt động** Z (ngày nay gọi là năng lượng tự do **Gibbs**, ký hiệu G):

=> ΔF = ΔU − T·ΔS  (V, T không đổi)

=> ΔZ = ΔH − T·ΔS  (p, T không đổi)

- Phản ứng thuận nghịch: năng lượng tự do giảm bằng **công cực đại**. Phản ứng không thuận nghịch: một phần tán thành nhiệt, công thu được **nhỏ hơn**.
- Sách cho các liên hệ với hằng số cân bằng K: F = −R·T·ln K (2.16) và ΔZ = ΔZ~o~ + R·T·ln K (2.20). ΔZ~o~ là **năng lượng tự do chuẩn** (chất ở 25 °C, hoạt độ bằng 1).

> [!bay] Đọc công thức (2.20) cho đúng
> Dạng chuẩn hiện nay: **ΔG = ΔG° + R·T·ln Q**, với Q là tỉ số nồng độ sản phẩm/chất phản ứng **tại thời điểm xét**. Khi cân bằng, ΔG = 0 và Q = K, nên **ΔG° = −R·T·ln K**. Quy tắc dùng được ngay: **ΔG < 0 thì phản ứng tự xảy ra**, ΔG > 0 thì cần cấp năng lượng, ΔG = 0 là cân bằng.

**Năng lượng liên kết trung bình** (Bảng 2.2 của sách, kcal/mol, trích): C–C 58,6; C–H 87,3; O–H 110,2; C=C 100,0; C≡C 123,0; C=O 142,0; N–N 20,0. Liên kết **hydro** yếu nhất: **4–8 kcal/mol**.

> [!bay] Bảng 2.2
> Dòng ghi "H – H: 4 ÷ 8" trong sách thực chất là **liên kết hydro** (sách cũng kết luận "liên kết hydro là yếu nhất"). Liên kết cộng hóa trị H–H trong phân tử H~2~ rất bền, khoảng 104 kcal/mol.

### 4.7. "Liên kết giàu năng lượng" của ATP — hiểu cho đúng

- Năng lượng của liên kết giàu năng lượng là **năng lượng tự do** giải phóng khi **thủy phân**, tức khi nhóm phosphat được **chuyển sang nước**. Nó **không** phải năng lượng để **cắt đứt** liên kết P–O.
- Muốn **cắt đứt** liên kết phosphat cuối của ATP thì phải **tốn** 50–100 kcal/mol. ATP thực ra là phân tử **khá bền**, không "nổ" như thuốc nổ.
- **Glucose-6-phosphat** cũng có năng lượng liên kết phosphat 50–100 kcal/mol, nhưng khi thủy phân chỉ cho khoảng **3 kcal/mol** năng lượng tự do. Vì thế nó **không** phải hợp chất giàu năng lượng.
- ATP là dạng năng lượng **đã "nạp"**; ADP là dạng **đã "phóng"**.

> [!cap-nhat] Năng lượng thủy phân ATP
> Giáo trình ghi 7,0–8,5 kcal/mol. Giá trị chuẩn hiện dùng (pH 7, 25 °C) là **ΔG°' ≈ −30,5 kJ/mol (≈ −7,3 kcal/mol)**, nằm trong khoảng của sách. Trong tế bào thật, do nồng độ ATP cao hơn nhiều so với ADP và P~i~, năng lượng tự do thực tế lớn hơn, khoảng **−50 đến −60 kJ/mol** (≈ −12 đến −14 kcal/mol). Đi thi: trả lời theo sách.

## 5. Áp dụng nguyên lý II cho cơ thể sống

### 5.1. Trạng thái dừng

**Mô hình hệ kín** (hình 2.8 của sách): hai bình I và II nối qua khóa K. Mở khóa, chất lỏng chảy đến khi hai mức bằng nhau rồi dừng. Đây là hình ảnh **cân bằng nhiệt động**: hết dòng, hết khả năng sinh công.

**Mô hình hệ mở** (hình 2.9): thêm khóa K~1~ cho chất lỏng **vào** bình I và khóa K~3~ cho chất lỏng **ra** khỏi bình II; K~2~ điều chỉnh dòng từ I sang II. Chỉnh ba khóa hợp lý thì sau một thời gian **mức chất lỏng ở hai bình đứng yên dù dòng vẫn chảy qua**. Đó là **trạng thái dừng**.

> [!ghi-nho] Định nghĩa
> **Trạng thái dừng** là trạng thái của **hệ mở**, trong đó các **thông số trạng thái không đổi theo thời gian**, nhưng **vẫn có dòng vật chất và năng lượng** đi vào và đi ra khỏi hệ.

| | **Cân bằng nhiệt động (hóa học)** | **Trạng thái dừng** |
|---|---|---|
| Hệ | Kín (hoặc cô lập); không có dòng vật chất | **Mở**; chất đổi vào và sản phẩm thải ra liên tục |
| Tốc độ phản ứng | v~1~ (thuận) = v~2~ (nghịch) | v~1~ > v~2~ (chất mới luôn vào, sản phẩm luôn ra) |
| Phụ thuộc nồng độ | Phụ thuộc nồng độ ban đầu | Không phụ thuộc nồng độ ban đầu; nồng độ dừng được giữ nhờ dòng chất |
| Năng lượng tự do | F = 0 (không còn khả năng sinh công) | F = hằng số ≠ 0 (giữ khả năng sinh công) |
| Entropi | **Cực đại** | Không đổi nhưng **không** cực đại |
| Chất xúc tác | Không làm đổi tỷ lệ chất | **Làm đổi nồng độ dừng**, ảnh hưởng tốc độ quá trình |

**Giống nhau**: cả hai đều **không đổi theo thời gian**.
**Khác nhau cơ bản**: hệ dừng **vẫn trao đổi** vật chất và năng lượng với bên ngoài, và **còn khả năng sinh công**. Hệ cân bằng nhiệt động là hệ đã "kém phẩm chất", không còn sinh công được.

> [!bay] "F = 0" ở trạng thái cân bằng
> Bảng so sánh của sách ghi F = 0. Hiểu là: ở cân bằng, **không còn năng lượng tự do khả dụng để sinh công** (ΔF = 0, F đã ở **cực tiểu**). Mục 4.3 nói "F đạt cực tiểu"; hai cách nói cùng một ý.

### 5.2. Chuyển trạng thái dừng

Khi điều kiện thay đổi (nghỉ ngơi → lao động, lớn lên, thay đổi nơi ở…), cơ thể chuyển sang một **mức dừng mới**. Mức mới **không** đạt ngay, mà qua một **bước chuyển**. Ví dụ: huyết áp động mạch dao động lúc bắt đầu và sau khi vận động tay chân. Trong mô hình, đổi khóa K~2~ giống như đổi lượng **chất xúc tác (enzym)**.

| Dạng bước chuyển | Đặc điểm | Gặp ở |
|---|---|---|
| **I. Có lệch thừa** | Vượt quá mức mới (dạng "đỉnh sóng") rồi mới tự điều chỉnh về | **Người trẻ**; phản ứng điển hình khi tế bào **hưng phấn** |
| **II. Gần hàm mũ** | Tăng dần đều lên mức mới; **tiết kiệm** năng lượng nhất | **Người đứng tuổi** |
| **III. "Mức xuất phát giả tạo"** | **Giảm trước** rồi mới tăng; năng lượng dùng **kém hiệu quả nhất** | Khi cơ thể/tế bào **bị thương tổn** |

Becton quan sát được cả ba dạng ở **tim ếch cô lập** khi đổi thành phần hóa học và nhiệt độ của dịch nuôi.

- Tiến hóa hướng tới trạng thái dừng có **tốc độ cao hơn mà vẫn ổn định**. Tốc độ cao nhờ **enzym** hoạt động ở nhiệt độ thấp; ổn định nhờ **liên hệ ngược** (cân bằng nội môi).
- Vì khoảng nhiệt độ hoạt động của enzym **khá hẹp**, sinh vật máu nóng có **hệ điều chỉnh thân nhiệt tự động** luôn hoạt động (mục 6).
- **Ung thư**: một giả thuyết cho rằng tế bào ung thư chuyển sang trạng thái dừng mới có **tốc độ oxy hóa thấp hơn nhưng ổn định hơn** (do tỉ lệ chất xúc tác và chất ức chế). Vì vậy nó bền vững hơn và sinh sản nhanh hơn tế bào thường.

> [!cap-nhat] Chuyển hóa của tế bào ung thư
> Giáo trình trình bày theo quan điểm trạng thái dừng. Hiện nay đã rõ nhiều tế bào ung thư **tăng mạnh đường phân** kể cả khi đủ O~2~ (**hiệu ứng Warburg**): chúng hấp thu rất nhiều glucose. Đây là cơ sở của chụp **PET với ^18^F-FDG** (glucose đánh dấu) để phát hiện khối u. Ung thư được hiểu là bệnh do **đột biến gen** tích lũy; giả thuyết trong sách chỉ mang tính lịch sử.

### 5.3. Nguyên lý II có "mâu thuẫn" với sự sống không?

Thoạt nhìn có vẻ mâu thuẫn: theo nguyên lý II, trật tự của hệ cô lập phải giảm. Nhưng cơ thể lại xây dựng từ phân tử nhỏ (thức ăn, khí thở) những **cấu trúc ngày càng trật tự** (protein, acid nucleic). Như vậy entropi của cơ thể đã giảm tương đối.

**Lời giải**: nguyên lý II nói về **hệ cô lập**, còn cơ thể là **hệ mở**. Do vật chất và năng lượng ra vào liên tục, cơ thể **không bao giờ** ở cân bằng nhiệt động. Sách nói: **tồn tại ở trạng thái không cân bằng là điều kiện sống của cơ thể**. Đó không phải trạng thái không cân bằng bất kỳ, mà là **trạng thái dừng**: pH, gradien ion… được giữ trong một khoảng không đổi.

**Cơ thể không phải máy nhiệt.** Hiệu suất máy nhiệt:

=> η = (T~1~ − T~2~)/T~1~

(T~1~: nhiệt độ tuyệt đối nguồn nóng; T~2~: nhiệt độ tuyệt đối nguồn lạnh, đều tính bằng K.)

Nếu cơ hoạt động như máy nhiệt với η = 33% = 1/3, nguồn lạnh là không khí 25 °C = 298 K:

=> 1/3 = (T~1~ − 298)/T~1~  ⇒  T~1~ = 447 K ≈ **174 °C**

Cơ phải nóng đến 174 °C. Điều đó không thể, vì protein cơ bị phân hủy ngay từ 40–60 °C. Vậy công của cơ thể sinh ra **không** do dòng nhiệt, mà do **biến đổi nội năng nhờ các quá trình hóa sinh** (hoặc do thay đổi entropi).

### 5.4. Biến đổi entropi ở hệ sống

Chia sự thay đổi entropi của hệ mở làm hai phần:

=> dS = dS~e~ + dS~i~ ;  tốc độ: dS/dt = dS~i~/dt + dS~e~/dt

- **dS~i~** (internal): do quá trình **bên trong** hệ. Theo nguyên lý II: **dS~i~ ≥ 0**. Bằng 0 nếu thuận nghịch; > 0 nếu không thuận nghịch. Ở cơ thể (oxy hóa, phân hủy thức ăn, tổng hợp chất cao năng) luôn **dS~i~ > 0**.
- **dS~e~** (external): do **trao đổi** vật chất và năng lượng với môi trường. dS~e~ có thể **dương, âm hoặc bằng 0**. Cơ thể nhận vào **dòng vật chất giàu năng lượng tự do, entropi thấp** và thải ra **dòng vật chất nghèo năng lượng tự do, entropi cao** (sản phẩm thoái hóa, nhiệt). Kết quả là dS~e~ **âm**.

| Trường hợp | dS | Ý nghĩa |
|---|---|---|
| dS~e~ = 0 | dS = dS~i~ > 0 | Như hệ cô lập: entropi tăng |
| dS~e~ > 0 | dS > 0 chắc chắn | Entropi tăng |
| dS~e~ < 0, \|dS~e~\| < dS~i~ | dS > 0 | Entropi của hệ vẫn tăng |
| dS~e~ < 0, \|dS~e~\| > dS~i~ | **dS < 0** | Trật tự **tăng**: giai đoạn **phát triển, lớn lên** |
| dS~e~ < 0, \|dS~e~\| = dS~i~ | **dS = 0** | **Trạng thái dừng** |

Điểm khác nhau giữa cân bằng nhiệt động và cân bằng dừng là cân bằng dừng có thêm các **thông số động học** (tốc độ, dòng).

### 5.5. Vì sao cần môi trường sạch, entropi thấp?

1. **Hệ sống bị cô lập** khỏi môi trường thì S tăng, F giảm đến cực tiểu: khả năng sinh công suy giảm, hệ tiến tới **cân bằng nhiệt động**, tức là chết. Vậy **môi trường xung quanh là cần thiết**.
2. Ở trạng thái dừng:

=> dS/dt = dS~i~/dt + dS~e~/dt = 0  ⇒  dS~i~/dt = −dS~e~/dt ≠ 0

Entropi sinh ra bên trong phải được **"xuất khẩu"** ra môi trường với cùng tốc độ. Muốn dS~e~ âm, dòng vào phải có **entropi thấp** (thức ăn, nước, không khí **sạch**), và môi trường phải **nhận được** dòng ra entropi cao. Môi trường bị ô nhiễm làm mất điều kiện này. **Giữ môi trường sống sạch, entropi thấp là điều kiện cần để cơ thể tồn tại, phát triển và sinh công.**

![Hình 2. Cân bằng entropi ở cơ thể (hệ mở): dS = dS~e~ + dS~i~](entropi-he-mo.svg)

## 6. Mở rộng: thân nhiệt và các con đường trao đổi nhiệt

> [!ghi-nho] Phần mở rộng
> Giáo trình chỉ nêu cân bằng năng lượng (tr. 35–36) và hệ điều chỉnh thân nhiệt ở sinh vật máu nóng (tr. 51). Mục này bổ sung kiến thức vật lý – sinh lý cơ bản để hiểu lâm sàng. Đây **không** phải nội dung chính của bài thi.

### 6.1. Bốn con đường mất nhiệt

Nhiệt sinh ra ở các cơ quan sâu được **máu** mang ra da. Từ da và đường hô hấp, nhiệt đi ra môi trường theo 4 cách:

| Con đường | Cơ chế vật lý | Công thức (dạng đơn giản) | Phụ thuộc |
|---|---|---|---|
| **Bức xạ** | Da phát **tia hồng ngoại**; không cần môi trường truyền | P = ε·σ·A·(T~da~^4^ − T~mt~^4^) | Nhiệt độ **tuyệt đối** của da và các vật xung quanh |
| **Dẫn nhiệt** | Va chạm phân tử ở chỗ tiếp xúc trực tiếp | P = k·A·ΔT/d | Hệ số dẫn nhiệt k của vật tiếp xúc |
| **Đối lưu** | Lớp không khí (nước) sát da nóng lên, bị dòng khí mới thay thế | P = h·A·ΔT | Tốc độ gió, dòng nước |
| **Bay hơi** | Nước (mồ hôi, hơi thở) chuyển thành hơi, lấy đi **nhiệt hóa hơi** | P = L·(m/t) | Độ ẩm không khí; **còn hoạt động khi T~mt~ > T~da~** |

Ký hiệu: P là công suất mất nhiệt (W); A là diện tích da (m²); ΔT là chênh lệch nhiệt độ (K); ε là hệ số phát xạ của da (≈ 0,97 với hồng ngoại); σ = 5,67·10^−8^ W/(m²·K^4^) là hằng số Stefan–Boltzmann; d là bề dày lớp dẫn (m); h là hệ số đối lưu; L ≈ 2,4 kJ/g (≈ 0,58 kcal/g) là nhiệt hóa hơi của mồ hôi ở nhiệt độ da; m/t là tốc độ bay hơi (g/s).

![Hình 3. Các con đường mất nhiệt của cơ thể khi nghỉ ở nhiệt độ phòng](mat-nhiet.svg)

**Tỷ lệ khi nghỉ, ở nhiệt độ phòng** (số liệu kinh điển của sách Sinh lý học Guyton): bức xạ ≈ 60%, bay hơi ≈ 22%, dẫn nhiệt vào không khí và đối lưu ≈ 15%, dẫn nhiệt vào vật tiếp xúc ≈ 3%. Con số bay hơi 22% **khớp** với bảng của giáo trình: (227 + 181)/1 879 ≈ 22%.

> [!vi-du] Ước tính mất nhiệt do bức xạ
> Da 34 °C (307 K), tường phòng 25 °C (298 K), diện tích da 1,8 m², ε = 0,97:
>
> => P = 0,97 × 5,67·10^−8^ × 1,8 × (307^4^ − 298^4^) ≈ 0,97 × 5,67·10^−8^ × 1,8 × 1,0·10^9^ ≈ 99 W
>
> Con số này ngang với chuyển hóa cơ sở (≈ 100 W). Quần áo giảm phần lớn lượng này. Lưu ý: phải dùng **kelvin**; nếu thay °C vào công thức T^4^ thì kết quả sai hoàn toàn.

> [!bay] Khi trời nóng hơn da
> Khi nhiệt độ môi trường **cao hơn** nhiệt độ da, bức xạ, dẫn nhiệt và đối lưu **đổi chiều**: cơ thể **nhận** nhiệt. Lúc đó **bay hơi mồ hôi là con đường thải nhiệt duy nhất**. Nếu không khí lại **ẩm** (khó bay hơi) thì cơ thể rất dễ tích nhiệt.

### 6.2. Điều hòa thân nhiệt

- **Trung tâm điều nhiệt** ở **vùng dưới đồi** so sánh nhiệt độ máu với một "điểm đặt" (set-point) khoảng 37 °C. Đây là một vòng **liên hệ ngược âm**, đúng tinh thần "trạng thái dừng" của mục 5.
- **Khi nóng**: giãn mạch da (đưa máu, tức nhiệt, ra da); tăng tiết mồ hôi; giảm sinh nhiệt.
- **Khi lạnh**: co mạch da (giữ nhiệt ở lõi); **run cơ** (tăng nhiệt thứ cấp Q~2~, mục 3.3); tăng chuyển hóa; nổi da gà.
- **Chuyển hóa cơ sở** (≈ 100 W theo sách, khoảng 1 400–2 000 kcal/ngày tùy người) là năng lượng tối thiểu để duy trì sống khi nghỉ hoàn toàn, nhịn đói, ở nhiệt độ dễ chịu. Toàn bộ năng lượng này cuối cùng thành **nhiệt**.

> [!ung-dung] Sốt, sốc nhiệt, hạ thân nhiệt
> - **Sốt**: chất gây sốt (pyrogen) làm **điểm đặt tăng**. Cơ thể "thấy lạnh" so với điểm đặt mới nên **rét run, co mạch** để tăng thân nhiệt. Khi hết sốt, điểm đặt trở lại: cơ thể **vã mồ hôi, giãn mạch**. Hạ sốt hỗ trợ: thuốc hạ sốt (hạ điểm đặt), mặc thoáng, lau người bằng **nước ấm** (tăng bay hơi). **Không** dùng nước đá hay cồn: nước lạnh làm co mạch, run cơ, có thể làm thân nhiệt lõi tăng thêm; cồn bôi da có thể gây ngộ độc ở trẻ nhỏ.
> - **Sốc nhiệt (say nắng nặng)**: điểm đặt **không** đổi, nhưng sinh nhiệt và nhận nhiệt **vượt** khả năng thải nhiệt (nắng nóng, ẩm, lao động nặng). Thân nhiệt lõi thường **trên 40 °C** kèm rối loạn thần kinh (lú lẫn, hôn mê). Đây là **cấp cứu**: phải **làm mát nhanh** (ngâm nước mát hoặc phun nước kết hợp quạt để tăng bay hơi và đối lưu) và chuyển viện. Protein, enzym bị biến tính: đúng như sách nói enzym chỉ hoạt động trong khoảng nhiệt độ hẹp.
> - **Hạ thân nhiệt**: thân nhiệt lõi **dưới 35 °C**. Hay gặp khi ngâm nước lạnh (nước dẫn nhiệt tốt hơn không khí khoảng 25 lần), mặc ướt trong gió (bay hơi + đối lưu), người già, trẻ sơ sinh (diện tích da lớn so với khối lượng). Xử trí: đưa ra khỏi lạnh, **cởi đồ ướt**, ủ ấm, làm ấm từ từ.

> [!yhct] Cứu ngải và chườm nóng/lạnh — phần nào là vật lý?
> - **Cứu ngải** (đốt điếu hoặc mồi ngải cứu gần huyệt): **cơ chế vật lý đã rõ** là truyền nhiệt vào da chủ yếu bằng **bức xạ hồng ngoại** (cứu cách da) và **dẫn nhiệt** (cứu có vật lót như gừng, muối). Da nóng lên tại chỗ, gây **giãn mạch, tăng lưu lượng máu** tại chỗ. Khái niệm "ôn thông kinh lạc, tán hàn" là **quan niệm YHCT**. Hiệu quả lâm sàng của cứu với từng bệnh hiện **còn hạn chế về bằng chứng**, kết quả nghiên cứu chưa thống nhất. Cần chú ý nguy cơ **bỏng**, nhất là ở người giảm cảm giác (đái tháo đường, liệt).
> - **Chườm nóng** (túi muối rang, ngải rang, khăn nóng): truyền nhiệt bằng **dẫn nhiệt**. Muối hoặc cát rang giữ nhiệt lâu vì có nhiệt dung đủ lớn và tỏa nhiệt từ từ. Tác dụng: giãn mạch, giảm co cứng cơ, giảm đau mạn tính.
> - **Chườm lạnh**: dẫn nhiệt **từ da ra túi lạnh**, làm mát mô và gây co mạch tại chỗ; dùng để **giảm đau** trong **chấn thương cấp** (24–48 giờ đầu). Tác dụng giảm phù nề ở người còn ít bằng chứng chắc chắn. Không chườm đá trực tiếp lên da quá lâu (bỏng lạnh).

## Tóm tắt

| Chủ đề | Điểm cốt lõi |
|---|---|
| Dạng năng lượng | Cơ, điện, hóa, quang, nhiệt, hạt nhân |
| Hệ nhiệt động | Cô lập (không trao đổi gì) – kín (chỉ năng lượng) – **mở** (cả hai; cơ thể sống) |
| Nhiệt lượng | ΔQ = m·c·Δt; 1 cal làm 1 g nước nóng từ 14,5 lên 15,5 °C; c cơ thể ≈ 0,8, máu 0,93, xương 0,3–0,4 cal/g·độ |
| Joule | 1 cal = 4,18 J; 1 J = 0,24 cal; công và nhiệt là **hàm quá trình** |
| Nội năng | Hàm trạng thái; chỉ đo được ΔU; chu trình thì ΔU = 0 |
| Nguyên lý I | δQ = dU + δA; không có động cơ vĩnh cửu loại một; U hệ cô lập bảo toàn |
| Định luật Hess | Năng lượng chỉ phụ thuộc trạng thái đầu – cuối; đo năng lượng thức ăn |
| 4 dạng công | Hóa học, cơ học, thẩm thấu, điện; tất cả dùng **ATP** |
| Nhiệt Q~1~ / Q~2~ | Sơ cấp ≈ 50% (tán xạ tất yếu); thứ cấp từ ATP sau khi sinh công; bệnh lý thì Q~1~ tăng |
| Cân bằng năng lượng | ΔQ = ΔE + ΔA + ΔM; ví dụ 1 879 kcal vào = 1 879 kcal ra |
| Tim mạch | Tim 1,3–1,4 W; chuyển hóa cơ sở ≈ 100 W; hiệu suất cơ tim 20–30%; sóng mạch động mạch chủ 4–5 m/s |
| Entropi | S = k·ln W; dS = δQ/T; số đo hỗn loạn; hàm trạng thái |
| Năng lượng tự do | F = U − T·S; ΔZ (ΔG) = ΔH − T·ΔS; cân bằng hệ cô lập: S max, F min |
| Nguyên lý II | Hệ cô lập: ΔS ≥ 0; không có động cơ vĩnh cửu loại hai; mang tính thống kê |
| Trạng thái dừng | Hệ mở, thông số không đổi, vẫn có dòng vào – ra; F = const ≠ 0; 3 dạng bước chuyển I, II, III |
| Entropi hệ sống | dS = dS~e~ + dS~i~; dS~i~ > 0; dS~e~ < 0; dừng khi \|dS~e~\| = dS~i~; cần môi trường sạch |
| Máy nhiệt? | η = 33% thì cơ phải nóng 174 °C → cơ thể là **máy chuyển hóa** |
| Mất nhiệt (mở rộng) | Bức xạ ≈ 60%, bay hơi ≈ 22%, đối lưu + dẫn ≈ 18%; trời nóng hơn da thì chỉ còn bay hơi |
