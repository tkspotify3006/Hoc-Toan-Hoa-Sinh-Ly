---
title: Một số ứng dụng phổ biến của vật lý kỹ thuật trong ngành Y
thoi-gian: 150 phút
muc-tieu:
- Vẽ được đường đi của tia sáng tạo ảnh một vật nhỏ qua kính hiển vi quang học trường sáng; tính được độ phóng đại, nêu được giới hạn phân ly và các cách tăng khả năng phân ly.
- Trình bày được nguyên lý phân tích định tính và định lượng các chất bằng quang phổ hấp thụ phân tử (định luật Bouguer – Lambert – Beer, λmax, đồ thị chuẩn).
- Giải thích được cách tạo tia X, phổ phát xạ, quy luật hấp thụ tia X và cách tạo ảnh X quang, chụp cắt lớp vi tính (CT).
- Giải thích được nguyên lý cộng hưởng từ hạt nhân và cách tạo ảnh cắt lớp cộng hưởng từ (MRI).
- Trình bày được nguyên lý ứng dụng đồng vị phóng xạ trong y học: đánh dấu phóng xạ, RIA/IRMA, ghi hình phóng xạ, nguồn chiếu xạ trong chẩn đoán, điều trị và các mục đích khác.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. **Kính hiển vi** = vật kính cho ảnh **thật, ngược, phóng đại** + thị kính dùng như **kính lúp** cho ảnh ảo. Độ phóng đại **K = K~V~·K~T~ = Δ·l~0~/(f~1~·f~2~)**.
> 2. Kính chỉ phân biệt được hai điểm cách nhau ít nhất **l~min~ = 0,61·λ/(n·sinθ)**. Muốn "nhìn rõ hơn" phải **giảm λ** (tử ngoại, electron) hoặc **tăng n·sinθ** (vật kính dầu) — phóng to thêm không giúp gì.
> 3. **Beer – Lambert**: **D = lg(I~0~/I) = ε·C·l** — mật độ quang tỉ lệ thuận nồng độ (dung dịch loãng). λmax cho biết **chất gì** (định tính), D tại λmax cho biết **bao nhiêu** (định lượng).
> 4. **Tia X**: electron tăng tốc đập vào bia anode → phổ **liên tục (bức xạ hãm) + vạch đặc tính**; bị hấp thụ theo **I = I~0~·e^−μx^**, μ tăng theo Z và mật độ → xương trắng, phổi đen. **CT** đo μ theo nhiều góc, máy tính dựng lại lát cắt, thang **Hounsfield**. **MRI** dùng **proton (H)** trong từ trường B~0~ + sóng radio cộng hưởng (42,58 MHz ở 1 T), tín hiệu theo **mật độ proton, T~1~, T~2~** — không có bức xạ ion hóa.
> 5. **Phóng xạ**: đồng vị phóng xạ hoạt động sinh học **như đồng vị bền** nhưng **ghi đo được** → đánh dấu, RIA/IRMA, xạ hình (SPECT, PET); bức xạ ion hóa **diệt tế bào** → xạ trị chiếu ngoài, áp sát, nguồn hở; ngoài ra tiệt trùng, bảo quản, tạo giống.

Bài này gom bốn "công cụ" vật lý mà người thầy thuốc dùng hằng ngày: **kính hiển vi** (nhìn cái quá nhỏ), **quang phổ hấp thụ** (đo nồng độ chất – nền của máy xét nghiệm sinh hóa), **X quang – CT – MRI** (nhìn vào trong cơ thể) và **đồng vị phóng xạ** (đánh dấu, ghi hình, điều trị) (Giáo trình tr. 337).

## 1. Phương pháp hiển vi

### 1.1. Nguyên lý phóng đại ảnh vật. Kính lúp

**Vì sao cần phóng đại?** Mắt bình thường có **góc phân ly tối thiểu α~min~ = 1 phút** (1′). Ở khoảng nhìn rõ ngắn nhất (khoảng nhìn thuận lợi) **l~0~ = 25 cm**, góc này ứng với hai điểm cách nhau khoảng **d = 7,5·10^−5^ m** (75 µm). Hai điểm gần hơn thế thì ảnh của chúng rơi vào **cùng một tế bào thị giác** → mắt thấy thành một điểm (tr. 337–338).

=> d ≈ l~0~·α~min~ = 0,25 m × 2,9·10^−4^ rad ≈ 7,3·10^−5^ m  (giáo trình làm tròn 7,5·10^−5^ m)

Ta không thể đưa vật sát mắt hơn l~0~ (mắt không điều tiết được). Vậy dụng cụ phóng đại thực chất làm **tăng góc nhìn**: mắt nhìn ảnh của vật dưới góc lớn hơn.

**Kính lúp** là một thấu kính hội tụ tiêu cự f nhỏ. Đặt vật AB **trong khoảng tiêu cự** (giữa F và thấu kính), mắt sát kính sẽ thấy **ảnh ảo, cùng chiều, lớn hơn** dưới góc α > α~0~. Khi AB tiến dần tới F, ảnh lùi ra xa vô cực và to dần, nhưng góc nhìn α gần như **không đổi**. Vì thế, với kính lúp, tỉ số "chiều dài ảnh/chiều dài vật" **không có ý nghĩa**; người ta dùng **độ phóng đại góc** (tr. 338):

=> k = tgα / tgα~0~ = l~0~ / f    (10.1)

- **k**: độ phóng đại (độ bội giác) của kính lúp, không đơn vị (ghi "×").
- **l~0~** = 25 cm: khoảng nhìn rõ ngắn nhất; **f**: tiêu cự kính lúp (cùng đơn vị với l~0~).

> [!vi-du] Tính nhanh
> Kính lúp f = 5 cm ⇒ k = 25/5 = **5×**. Kính lúp f = 2,5 cm ⇒ k = **10×**. Tiêu cự càng ngắn, phóng đại càng lớn.

### 1.2. Kính hiển vi quang học trường sáng (KHVQHTS)

#### a) Cấu tạo

Hai bộ phận chính là **vật kính** và **thị kính**. Mỗi bộ phận gồm nhiều thấu kính (đã khử quang sai) nhưng về tác dụng thì tương đương **một thấu kính hội tụ tiêu cự nhỏ**. Chúng gắn ở hai đầu ống kính, cách nhau một khoảng d **cố định**, rất lớn so với tiêu cự (tr. 338).

- **Lăng kính phản xạ toàn phần** giữa vật kính và thị kính: làm lệch trục để người xem ngồi thoải mái.
- **Bộ phận tụ quang** (đơn giản nhất là gương cầu lõm) tập trung ánh sáng từ **nguồn sáng S** chiếu vào vật.
- Trong y học dùng phổ biến kính **trường sáng**: nguồn phát ánh sáng trắng, vật hiện tối trên nền sáng (tr. 339).

#### b) Tạo ảnh

Dựng ảnh bằng các định luật quang hình (truyền thẳng, khúc xạ qua thấu kính). Hai điều kiện bắt buộc (tr. 339–340):

1. Vật AB đặt **ngoài tiêu cự F~1~ của vật kính, sát F~1~** → vật kính cho **ảnh thật A~1~B~1~ ngược chiều, lớn hơn vật nhiều**.
2. A~1~B~1~ phải rơi **trong khoảng tiêu cự của thị kính** → thị kính (đóng vai kính lúp) cho **ảnh ảo A~2~B~2~** mà mắt đặt sát thị kính nhìn thấy được.

![Hình 1. Đường đi tia sáng trong kính hiển vi quang học trường sáng](kinh-hien-vi.svg)

Để mắt **khỏi mỏi** (không điều tiết), người ta di chuyển mâm kính cho A~1~B~1~ rơi **gần đúng tiêu điểm F~2~** của thị kính; khi đó A~2~B~2~ ở xa vô cực (tr. 340).

> [!bay]
> - Ảnh cuối cùng qua kính hiển vi là **ảnh ảo, ngược chiều** so với vật (vật kính đã lật ngược; thị kính giữ nguyên chiều của A~1~B~1~). Vì vậy đẩy tiêu bản sang phải thì hình trong kính chạy sang **trái**.
> - Vật kính cho ảnh **thật**; thị kính cho ảnh **ảo**. Đừng đảo lại.

### 1.3. Độ phóng đại. Khả năng phân ly

#### a) Độ phóng đại

Gọi **Δ = F′~1~F~2~** là **độ dài quang học** của kính (khoảng cách tiêu điểm ảnh của vật kính đến tiêu điểm vật của thị kính). Vì Δ ≫ f~1~, f~2~ nên O~1~A~1~ ≈ Δ và O~1~A ≈ f~1~ (tr. 340).

- **Độ phóng đại dài của vật kính**:

=> K~V~ = A~1~B~1~/AB = O~1~A~1~/O~1~A ≈ Δ/f~1~

- **Độ bội giác của thị kính** (như kính lúp, công thức 10.1):

=> K~T~ = l~0~/f~2~

- **Độ phóng đại của kính hiển vi** (còn gọi số bội giác G), tr. 341:

=> K = tgα/tgα~0~ = K~V~·K~T~    (10.2)

=> K = (Δ/f~1~)·(l~0~/f~2~) = Δ·l~0~/(f~1~·f~2~)    (10.3)

Trong đó Δ, l~0~ (25 cm), f~1~, f~2~ dùng **cùng đơn vị** (thường là cm).

f~1~, f~2~ càng nhỏ thì K càng lớn. Nhưng nếu quá nhỏ thì **nhiễu xạ** mạnh, khả năng phân ly lại giảm. Một kính thường có nhiều vật kính và thị kính để tổ hợp. Ví dụ của sách: vật kính 8×, 40×, 90× và thị kính 7×, 10×, 15× cho số bội giác **từ 56× (8×7) đến 1350× (90×15)**; trường hợp đặc biệt đạt 3500× (tr. 341).

> [!vi-du] Tính độ phóng đại
> Kính có Δ = 16 cm, f~1~ = 0,4 cm, f~2~ = 2,5 cm:
> K~V~ = 16/0,4 = 40×; K~T~ = 25/2,5 = 10× ⇒ **K = 400×**.
> Thực hành: chỉ cần **nhân hai con số khắc trên vật kính và thị kính** (40× · 10× = 400×).

#### b) Khả năng phân ly

Ảnh của một điểm sáng qua hệ quang học **không phải là một điểm** mà là một **vân nhiễu xạ** (một đốm sáng có vành). Hai điểm còn phân biệt được khi khoảng cách giữa hai cực đại trung tâm **lớn hơn bán kính vân sáng trung tâm** (d > ρ); nếu d < ρ, hai ảnh "hòa" vào nhau (tr. 341–342).

**Giới hạn phân giải** (khoảng cách nhỏ nhất giữa hai điểm còn phân biệt được):

=> l~min~ = 0,61·λ/(n·sinθ)    (10.4)

- **λ**: bước sóng ánh sáng chiếu (m hoặc µm).
- **n**: chiết suất môi trường giữa vật và vật kính.
- **2θ**: góc mở — góc nhìn vật kính từ vật (coi vật là một điểm). Tích **n·sinθ** gọi là **khẩu độ số** (numerical aperture, NA).

**Khả năng phân ly** là nghịch đảo của giới hạn phân giải:

=> S = 1/l~min~

l~min~ càng nhỏ thì khả năng phân ly càng cao.

> [!vi-du] Giới hạn của kính hiển vi quang học
> λ = 0,55 µm (ánh sáng lục), vật kính dầu n·sinθ = 1,4:
> l~min~ = 0,61 × 0,55/1,4 ≈ **0,24 µm**.
> Vậy kính quang học thấy được vi khuẩn (≈ 1 µm) nhưng **không thấy được virus** (thường 20–300 nm) — muốn thấy virus phải dùng kính hiển vi điện tử.

#### c) Cách tăng khả năng phân ly (tr. 342–343)

Từ (10.4), muốn giảm l~min~ có ba cách:

| Cách | Làm thế nào | Giới hạn |
|---|---|---|
| **Tăng góc mở 2θ** (tăng sinθ) | Vật kính đặt rất gần vật | θ quá lớn sinh **quang sai** |
| **Tăng chiết suất n** | **Vật kính chìm (vật kính dầu)**: nhỏ dầu bá hương (n ≈ 1,5, bằng chiết suất thủy tinh) giữa tiêu bản và vật kính | Góc mở gần 90°, n·sinθ ≈ 1,4 |
| **Giảm bước sóng λ** | Dùng ánh sáng có λ ngắn, tử ngoại | Mắt chỉ thấy 0,39–0,76 µm; tử ngoại phải **chụp ảnh** |

Vật kính dầu còn **khắc phục quang sai** và hiện tượng **phản xạ toàn phần** ở mặt phân cách thủy tinh – không khí: các tia xiên từ vật không bị "mất" mà vẫn lọt vào vật kính.

> [!bay] Số liệu cần đọc kỹ
> - Giáo trình ghi chiết suất dầu bá hương là 1,4 ở một chỗ và 1,5 ở chỗ khác; con số **n·sinθ ≈ 1,4** là khẩu độ số của vật kính dầu.
> - Giáo trình viết vật kính dầu tăng khả năng phân giải "tới 4,5 lần". Tính theo (10.4): vật kính khô có n·sinθ tối đa ≈ 0,95, vật kính dầu ≈ 1,4, nên chỉ tăng khoảng **1,5 lần**. Khi thi, nhớ ý chính: **dầu làm tăng n → tăng khả năng phân ly**.
> - **Độ phóng đại ≠ khả năng phân ly.** Phóng to ảnh mãi mà không tăng NA hay giảm λ chỉ được "ảnh to nhưng nhòe" (phóng đại rỗng).

**Độ tương phản.** Là sự khác nhau về cường độ sáng giữa ảnh vật và nền (hoặc giữa các phần của vật). Nhân và bào tương hấp thụ ánh sáng khác nhau nên có tương phản. Khi đối tượng hấp thụ gần giống môi trường, người ta **nhuộm** tiêu bản — nhưng nhuộm làm **chết tế bào**, không quan sát được hoạt động sống (tr. 343).

### 1.4. Các loại kính hiển vi khác

Nguyên lý chung: dùng "thấu kính" làm đổi hướng tia sáng hay chùm electron. Với ánh sáng nhìn thấy, thấu kính làm bằng thủy tinh **Flin, Crao**; với tử ngoại dùng **thạch anh**; với chùm electron dùng **"thấu kính" từ**. Kính hiển vi quang học phóng đại tới **1 500 – 2 500 lần**; kính hiển vi điện tử tới **600 000 lần** (tr. 343).

| Loại | Điểm khác kính trường sáng | Ưu điểm | Dùng để |
|---|---|---|---|
| **Tử ngoại** (tr. 343–344) | Đèn thủy ngân; thấu kính **thạch anh** (thủy tinh hấp thụ mạnh tử ngoại); bộ lọc đơn sắc (lăng kính, khe); **phải chụp ảnh** (mắt không thấy, tử ngoại hại mắt) | λ ngắn → phân ly tăng **gấp đôi**; protein, acid nucleic **hấp thụ mạnh** tử ngoại → tương phản tốt | Cấu trúc tế bào chứa protein, acid nucleic |
| **Huỳnh quang** (tr. 344) | Tử ngoại kích thích vật **phát ánh sáng huỳnh quang**; thêm bộ phận **chặn tia tử ngoại** để ảnh chỉ do ánh sáng huỳnh quang tạo nên | Thấy rõ chất phát quang (ví dụ diệp lục phát đỏ tươi) | Chất không tự phát quang (protein, acid nucleic) phải **nhuộm chất phát quang** |
| **Trường tối** (tr. 344–345) | **Màn chắn** dưới tụ quang chặn tia gần trục; chỉ tia xiên đi qua; ánh sáng **tán xạ** trên hạt lạ mới lọt vào vật kính | **Tăng tương phản**: hạt lạ là chấm sáng trên nền tối | Quan sát **di chuyển, hoạt động** của đối tượng sống; **không** dùng nghiên cứu cấu trúc (phân ly giảm) |

Kính trường tối dựa trên hiện tượng **tán xạ** (giống hiệu ứng Tyndall). Cường độ ánh sáng tán xạ phụ thuộc kích thước hạt, bước sóng λ, góc lệch θ, số hạt N và thể tích hạt V. Với θ nhỏ, cường độ gần như chỉ phụ thuộc λ theo **định luật Rayleigh** (tr. 344):

=> I~tán xạ~ ∝ 1/λ^4^

> [!ung-dung] Kính hiển vi trong phòng xét nghiệm
> - **Vật kính dầu 100×** là vật kính dùng soi **vi khuẩn** (nhuộm Gram, nhuộm Ziehl–Neelsen tìm trực khuẩn lao), **ký sinh trùng sốt rét** trên lam máu, công thức bạch cầu.
> - **Kính hiển vi nền đen (trường tối)**: soi tươi tìm **xoắn khuẩn giang mai** (*Treponema pallidum*) — vi khuẩn mảnh, khó nhuộm, nhưng hiện thành sợi sáng di động trên nền tối.
> - **Kính hiển vi huỳnh quang**: nhuộm huỳnh quang tìm vi khuẩn lao, kỹ thuật **miễn dịch huỳnh quang** (gắn kháng thể với chất phát quang) trong chẩn đoán bệnh tự miễn, virus.

#### Kính hiển vi điện tử

Vì l~min~ ≈ λ, vật nhỏ hơn bước sóng ánh sáng thì kính quang học tinh xảo đến đâu cũng không phân giải được. Electron có **bước sóng liên kết de Broglie** rất nhỏ (tr. 345):

=> λ = h/(m·v)    (10.5)

Electron được tăng tốc bởi hiệu điện thế U: e·U = ½·m·v², nên:

=> λ~e~ = h/√(2·m·e·U)    (10.6)

- **h** = 6,63·10^−34^ J·s (hằng số Planck); **m** = 9,1·10^−31^ kg; **e** = 1,6·10^−19^ C; **U**: hiệu điện thế tăng tốc (V).
- Tăng U thì λ~e~ giảm → độ phóng đại lên đến **hàng triệu lần** (tr. 346).

> [!vi-du] Bước sóng electron ở U = 60 kV
> λ~e~ = 6,63·10^−34^ / √(2 × 9,1·10^−31^ × 1,6·10^−19^ × 6·10^4^) ≈ **5·10^−12^ m = 0,005 nm** — ngắn hơn ánh sáng nhìn thấy khoảng 10^5^ lần.

**Cấu tạo và tạo ảnh** (tr. 346–347):

- **Nguồn electron**: sợi đốt kim loại. Electron được tăng tốc trong vùng F bởi điện trường **U = 60 kV**.
- **Thấu kính từ 1** (vai trò tụ quang) hội tụ chùm electron chiếu vào mẫu.
- **Thấu kính từ 2** (vai trò vật kính) cho ảnh thứ nhất đã phóng đại; **thấu kính từ 3** (vai trò thấu kính chiếu) phóng to thêm một lần nữa.
- Ảnh cuối ghi trên **màn huỳnh quang** (hoặc phim).
- Toàn bộ trong **chân không** (bơm khuếch tán, bơm phân tử) để electron **không bị tán xạ** bởi không khí; mẫu đưa vào qua một cửa đặc biệt. Chỉ electron nhiễu xạ với **góc bé** mới vào được vật kính để tạo ảnh.

**Vai trò**: nghiên cứu vi mô **ở mức phân tử** — acid nucleic, acid amin (amino acid), protein; cấu tạo **collagen**, **actin, myosin** trong tế bào cơ, một số **virus**. Kết hợp với **tự chụp hình phóng xạ** (autoradiography) để khảo sát liên quan cấu trúc – chức năng (tr. 347).

> [!cap-nhat] Vượt "giới hạn" của giáo trình
> - Giáo trình viết kính hiển vi quang học không phân giải được vật nhỏ hơn cỡ λ. Hiện nay có **kính hiển vi huỳnh quang siêu phân giải** (STED, PALM…) vượt giới hạn nhiễu xạ, được trao giải Nobel Hóa học 2014.
> - **Kính hiển vi điện tử nhiệt độ thấp (cryo-EM)** cho phép xác định cấu trúc protein, virus gần mức nguyên tử mà không cần nhuộm kim loại (Nobel Hóa học 2017).
> - Khi thi vẫn trả lời theo giáo trình: l~min~ ∝ λ.

#### Phương pháp chiếu và chụp bằng kính hiển vi (tr. 347)

Muốn chiếu hay chụp thì quang hệ phải cho **ảnh thật**. Người ta bố trí sao cho ảnh qua vật kính nằm **ngoài tiêu điểm chính thứ nhất của "thị kính"** (lúc này nó là một thấu kính chiếu, không đặt mắt nhìn). Đặt màn ảnh, máy ảnh hay máy quay phim đúng vị trí ảnh thật là thu được hình.

### 1.5. Đo kích thước vật nhỏ bằng kính hiển vi

Dùng kính hiển vi trường sáng có thêm **thước trắc vi** (tr. 347–349).

| Thước | Đặc điểm |
|---|---|
| **Thước trắc vi thị kính cố định (TVTK)** | Vạch trên tấm kính phẳng K~1~, chia 8 vạch (0–8); đặt **trùng mặt phẳng ảnh thật** của vật qua vật kính (≈ mặt phẳng tiêu của thị kính) → luôn thấy rõ cùng ảnh vật. **Giá trị một độ chia chưa biết**, phải chuẩn trước. |
| **Thước trắc vi vật kính (TVVK)** | Dài **1 mm** chia **100 phần** → mỗi độ chia **10 µm**; vạch trên tấm kính 26 × 76 mm; đặt trên mâm kính như một **vật mẫu** để chuẩn TVTK. |
| **Thước trắc vi thị kính di động** | Trên tấm K~2~ sát K~1~: 2 vạch song song + 2 đường giao nhau; dịch bằng **núm ốc** chia 100 phần. Quay 1 vòng (100 vạch) thì thước dịch đúng **1 vạch TVTK** → đọc tới **phần trăm vạch**. |

**Bước 1 – Chuẩn giá trị độ chia TVTK.** Đặt TVVK lên mâm kính, chỉnh cho hai hệ vạch song song, gần trùng nhau. Tìm hai vị trí vạch trùng nhau, đếm số khoảng giữa chúng trên mỗi thước:

=> S = 10·(n/N) µm

- **S**: giá trị một độ chia TVTK (µm); **n**: số khoảng trên **TVVK**; **N**: số khoảng trên **TVTK**.

**Bước 2 – Đo vật.** Thay TVVK bằng tiêu bản (không đổi vật kính, không đổi độ phóng đại). Dịch thước di động cho giao điểm hai đường đi từ mép này đến mép kia của vật:

=> l = S·(N + d/100) µm

- **N**: số vạch nguyên của TVTK (đọc trên thị trường); **d**: phần bách phân của vạch (đọc trên núm ốc).

> [!vi-du] Đo một hạt tinh bột
> Chuẩn: 30 khoảng TVVK trùng 60 khoảng TVTK ⇒ S = 10 × 30/60 = **5 µm/vạch**.
> Đo: N = 4 vạch, núm ốc chỉ 40 ⇒ l = 5 × (4 + 40/100) = **22 µm**.

> [!bay]
> - Giá trị độ chia TVTK **phụ thuộc vật kính đang dùng** → đổi vật kính phải chuẩn lại.
> - Trong S = 10·n/N, **n thuộc TVVK** (thước có giá trị biết trước 10 µm), **N thuộc TVTK**. Đảo n và N là lỗi hay gặp.

> [!yhct] Soi bột và vi phẫu — kiểm nghiệm dược liệu bằng kính hiển vi
> Dược điển Việt Nam quy định kiểm nghiệm nhiều dược liệu bằng **vi phẫu** (cắt lát mỏng, nhuộm, xem cấu trúc mô) và **soi bột** (xem các "mảnh" đặc trưng: hạt tinh bột, tinh thể calci oxalat hình kim, hình khối, hình cầu gai, lông che chở, lông tiết, mảnh mạch, sợi, bào tử…). Hình dạng và **kích thước đo bằng thước trắc vi** (như mục 1.5) giúp **định danh** dược liệu, phát hiện **nhầm lẫn, giả mạo**, nhất là khi dược liệu đã tán bột hay thái phiến.
> - Tinh thể calci oxalat và hạt tinh bột có tính **lưỡng chiết**, nên sáng rõ dưới **kính hiển vi phân cực**. Nhiều dược liệu còn được nhận dạng bằng **màu huỳnh quang** dưới đèn tử ngoại (365 nm).
> - Đây là phương pháp **hình thái học có cơ sở vững chắc**, nhưng chỉ cho biết dược liệu **đúng loài, đúng bộ phận**; nó **không** cho biết hàm lượng hoạt chất hay tác dụng — phần đó cần định lượng (mục 2) và nghiên cứu dược lý.

## 2. Phương pháp quang phổ hấp thụ phân tử

### 2.1. Sự hấp thụ ánh sáng của môi trường vật chất

**Hấp thụ ánh sáng** là hiện tượng một lớp vật chất giữ lại một phần năng lượng chùm sáng đi qua nó → cường độ yếu đi. Nguyên nhân: năng lượng của một phần photon **biến đổi thành dạng năng lượng khác** (tr. 349).

#### a) Định luật Bouguer

Chiếu chùm sáng **đơn sắc** vuông góc vào lớp vật chất đồng nhất. Xét một lớp mỏng dx tại độ sâu x: phần cường độ bị lớp này hấp thụ tỉ lệ thuận với **cường độ tới I(x)** và **bề dày dx** (tr. 349–350):

=> dI(x) = −μ·I(x)·dx    (10.7)

Tích phân từ 0 đến l (I từ I~0~ đến I):

=> I = I~0~·e^−μl^    (10.8)

- **I~0~, I**: cường độ chùm sáng trước và sau lớp vật chất.
- **l**: bề dày lớp vật chất (cm).
- **μ**: **hệ số hấp thụ** (cm^−1^), phụ thuộc **bản chất và mật độ** môi trường, **không phụ thuộc cường độ sáng** (trong giới hạn nhất định), và phụ thuộc bước sóng: μ = f(λ).

**Vì sao là hàm mũ?** Mỗi lớp mỏng chỉ "lấy đi" một **tỉ lệ cố định** của ánh sáng đến nó (không phải một lượng cố định). Lớp sau nhận ít hơn nên mất ít hơn → cường độ giảm theo hàm mũ.

Thường viết theo cơ số 10:

=> I = I~0~·10^−kl^    (10.9)

- **k**: **hệ số tắt**, k = 0,43·μ (vì lg e ≈ 0,43). Nếu I~0~/I = 10 thì k = 1/l: hệ số tắt bằng **nghịch đảo bề dày làm cường độ giảm 10 lần**.

#### b) Định luật Bouguer – Lambert – Beer

Với **dung dịch loãng** nồng độ C, hệ số tắt tỉ lệ thuận nồng độ: k = ε·C (tr. 350):

=> I = I~0~·10^−εCl^    (10.10)

- **ε**: **hệ số tắt của dung dịch** (hệ số hấp thụ phân tử). Đơn vị phụ thuộc đơn vị nồng độ; với C (mol/L), l (cm) thì ε có đơn vị L·mol^−1^·cm^−1^.
- Ý nghĩa: hấp thụ tỉ lệ với **số phân tử chất hấp thụ trên đường đi** của chùm sáng.

**Điều kiện đúng:** dung dịch **loãng**. Khi đặc, các phân tử gần nhau, **tương tác** đáng kể → định luật không còn chính xác. Ngoài ra ε còn phụ thuộc dung môi, nhất là khi dung môi **không "trong suốt"** (tr. 350).

#### c) Các đại lượng đặc trưng (tr. 351)

- **Hệ số truyền qua** (transmittance), thường tính bằng %:

=> T = I/I~0~

- **Mật độ quang học D** (optical density) — còn gọi **độ hấp thụ A** (absorbance), hoàn toàn tương đương:

=> D = lg(1/T) = lg(I~0~/I) = ε·C·l    (10.11)

- Nếu T tính bằng %:

=> D = lg(100/T) = 2 − lg T

Mọi đại lượng μ, ε, T, D (A) **đều phụ thuộc bước sóng λ**.

![Hình 2. Định luật Bouguer – Lambert – Beer và đồ thị chuẩn](beer-lambert.svg)

> [!vi-du] Bảng quy đổi nên thuộc
> | T | 100% | 50% | 10% | 1% | 0,1% |
> |---|---|---|---|---|---|
> | D | 0 | 0,30 | 1 | 2 | 3 |
> Mỗi khi D tăng thêm 1, ánh sáng truyền qua giảm **10 lần**. D **tỉ lệ thuận** với C; T thì **không** (T giảm theo hàm mũ).

> [!bay]
> - **D tỉ lệ thuận với C và l; T không tỉ lệ với C.** Đồ thị chuẩn phải vẽ **D theo C** mới là đường thẳng.
> - Công thức (10.12) ở tr. 353 của giáo trình in **T = I~0~/I = i~0~/i** — đây là lỗi in, vì chính giáo trình định nghĩa T = I/I~0~ ở tr. 351. Đúng là **T = I/I~0~ = i/i~0~** và **D = lg(I~0~/I) = lg i~0~ − lg i**.
> - Định luật chỉ áp dụng cho ánh sáng **đơn sắc** và dung dịch **loãng**.

### 2.2. Phổ hấp thụ phân tử

**Phổ hấp thụ** là đường cong biểu diễn một trong các đại lượng μ, ε, T, D (A) **theo bước sóng λ** (tr. 351).

- Thường có một cực đại hấp thụ rõ rệt tại **λmax**; một chất có thể có **vài λmax** (độ cao không bằng nhau).
- **Dải hấp thụ**: miền phổ quanh một λmax, từ λ~1~ đến λ~2~, trong đó hấp thụ chuyển qua cực đại (tr. 352).

**Màu của vật** là do nó hấp thụ mạnh một vài vùng phổ. Máu đỏ vì **hemoglobin hấp thụ mạnh ánh sáng xanh lam và xanh lá**, chỉ để lọt vùng đỏ. Lá cây xanh vì **hấp thụ mạnh vùng đỏ và xanh lam** (tr. 352).

### 2.3. Ứng dụng của quang phổ hấp thụ phân tử

Dùng để nghiên cứu **thành phần và cấu trúc** các chất. Ưu điểm: **nhạy, nhanh, chính xác**, đặc biệt **không cần tách riêng** các thành phần khỏi hỗn hợp, **không làm hỏng mẫu**. Thực hiện được cả **định tính** và **định lượng** (tr. 352).

#### a) Máy quang phổ hấp thụ tử ngoại – nhìn thấy (UV-Vis)

**Nguyên tắc:** đo cường độ chùm sáng **gián tiếp** qua **dòng quang điện tới hạn (bão hòa)** của **tế bào quang điện** (hiệu ứng quang điện ngoài, nhạy tới λ ≈ 1000 nm). Dòng quang điện bão hòa **tỉ lệ bậc nhất** với cường độ chùm sáng tới (tr. 352–353):

=> T = I/I~0~ = i/i~0~

=> D = lg(I~0~/I) = lg i~0~ − lg i    (10.12)

- **i~0~, i**: dòng quang điện bão hòa khi chùm sáng **không bị** và **có bị** lớp dung dịch chắn.

**Sơ đồ máy** (hình 10.14 của sách): (1) đèn → (2) gương phản xạ → (3) khe vào → (4) hệ lọc đơn sắc (cách tử nhiễu xạ hoặc lăng kính) → (5) chắn sáng điều chỉnh độ rộng chùm và độ đơn sắc → (6) **cuvet** đựng dung dịch → (7) **tế bào quang điện** → (8) khuếch đại → (9) bộ ghi (tr. 353).

| Nguồn sáng | Miền phổ |
|---|---|
| Đèn dây tóc **tungsten** | Nhìn thấy – hồng ngoại gần: **340–1000 nm** |
| Đèn phóng điện khí **hydro deuterium** | Tử ngoại: **220–340 nm** |

Hệ cách tử chọn được bước sóng chính xác tới **0,1 nm**; máy hiện đại hiển thị λ, T, D… trên màn hình.

#### b) Phân tích định tính

Mỗi phân tử có các **mức năng lượng xác định** của electron. Khi hấp thụ photon, electron nhảy từ mức E~n~ lên mức kích thích E~m~. **λmax** ứng với bước chuyển có **xác suất lớn nhất** (tr. 353–354):

=> E~m~ − E~n~ = ΔE~max~ = h·c/λmax    (10.13)

- **h**: hằng số Planck; **c** = 3·10^8^ m/s; ΔE~max~ (J).

Cấu trúc khác nhau → mức năng lượng khác nhau → **λmax khác nhau** ⇒ dựa vào vị trí cực đại để **nhận biết chất** (hay thành phần của hỗn hợp).

- Đa số nhóm chức hữu cơ có cực đại hấp thụ trong miền **200–500 nm**; miền này **không đổi** dù nhóm chức nằm trong chất nào (ví dụ của sách: nhóm CH~3~ hấp thụ đặc trưng ở 377,7 nm và 348,2 nm — số liệu này khó kiểm chứng, vì nhóm CH~3~ no thực tế không hấp thụ trong vùng UV-Vis; chỉ cần nhớ ý chính: **mỗi nhóm chức có dải hấp thụ đặc trưng**).
- **Ví dụ tế bào lympho** (tr. 354): phổ có cực đại ở **260 nm** → thành phần chính là **acid nucleic** (base purin, pyrimidin). Dải hấp thụ rộng hơn bình thường, kéo tới **280 nm** = cực đại của **acid amin thơm** (tryptophan, tyrosin). Tỉ số **η = D~280~/D~260~ = 0,8**, lớn hơn bình thường → trong tế bào còn **nhiều protein**.
- **Hormon sinh dục nữ** (tr. 355): estron, estriol, estradiol có thành phần gần giống nhau, khó phân biệt bằng hóa học. Cho tác dụng với H~2~SO~4~ thì sản phẩm có cực đại khác nhau: estron 300 nm; estriol 300 và 460 nm; estradiol 370 và 430 nm (sách ghi tên "ostron, ostrion, ostradion").
- **Nhóm carbonyl** (bảng tr. 355, tính bằng **số sóng** k = 1/λ, cm^−1^ — thực chất là vùng **hồng ngoại**): acid **bị ion hóa** hấp thụ ở **1300–1420 cm^−1^**, acid **không bị ion hóa** ở **1710–1730 cm^−1^**; các β-lactam ở 1730–1780 cm^−1^. Nhờ đó phân biệt được dạng ion hóa (đã mất H^+^) và dạng phân tử.

Độ rộng, hình dạng dải hấp thụ còn phụ thuộc **độ phức tạp cấu tạo phân tử** và **môi trường xung quanh** (tr. 355).

> [!ung-dung] Đo độ tinh khiết DNA (ADN), RNA (ARN)
> Phòng xét nghiệm sinh học phân tử đo A~260~ (acid nucleic) và A~280~ (protein) của dịch chiết. Thường dùng tỉ số ngược với sách: **A~260~/A~280~ ≈ 1,8** với DNA sạch, **≈ 2,0** với RNA sạch; tỉ số thấp hơn → **lẫn protein**. Cùng nguyên lý với ví dụ tế bào lympho ở trên.

#### c) Phân tích định lượng (dung dịch loãng)

**Cách 1 – Áp dụng trực tiếp định luật** (tr. 355–356). Đo D~A~ của dung dịch tại **λmax** đặc trưng của chất A:

=> D~A~ = ε·C~A~·l    (10.14)

Biết ε (từ dữ liệu chuẩn) và l → tính C~A~ = D~A~/(ε·l).

**Hỗn hợp hai chất A, B** có cực đại ở λ~1~ và λ~2~: đo mật độ quang hỗn hợp D~1~ (tại λ~1~) và D~2~ (tại λ~2~). **Mật độ quang có tính cộng**:

=> D~1~ = ε~A~·C~A~·l + ε~B~·C~B~·l

=> D~2~ = ε′~A~·C~A~·l + ε′~B~·C~B~·l

Giải hệ hai phương trình bậc nhất hai ẩn (với l = 1 cm) được C~A~, C~B~ (công thức 10.15). ε~A~, ε~B~ là hệ số tắt tại λ~1~; ε′~A~, ε′~B~ là hệ số tắt tại λ~2~ — tra bảng hoặc xác định bằng đồ thị với từng chất riêng.

**Cách 2 – Đồ thị chuẩn** (tr. 356):

1. Pha dãy dung dịch chuẩn của chất A nồng độ **C~1~, C~2~, …, C~n~**.
2. Đo D~1~, D~2~, …, D~n~.
3. Vẽ **đồ thị D theo C**.
4. Đo **D~x~** của dung dịch cần định lượng.
5. Từ đồ thị suy ra **C~x~**.

**Dung dịch đặc** (tr. 357): D không còn tỉ lệ thuận với C, ε cũng thay đổi → **pha loãng** nhiều lần, định lượng dung dịch loãng rồi **nhân ngược hệ số pha loãng**.

> [!vi-du] Bài tính Beer – Lambert
> NADH có ε = 6220 L·mol^−1^·cm^−1^ ở 340 nm. Cuvet l = 1 cm, đo được D = 0,311.
> C = D/(ε·l) = 0,311/6220 = **5·10^−5^ mol/L = 50 µmol/L**.
> Nếu dùng cuvet 0,5 cm cho cùng dung dịch thì D = 0,156 (D tỉ lệ thuận l).

> [!ung-dung] Máy xét nghiệm sinh hóa và máy đo SpO₂
> - **Máy sinh hóa** (bán tự động, tự động) chính là **máy quang phổ**: mẫu huyết thanh + thuốc thử → sản phẩm có màu (hoặc NADH) → đo D ở bước sóng thích hợp → so với **chất chuẩn**: C~x~ = C~chuẩn~ × D~x~/D~chuẩn~. Ví dụ glucose (phương pháp glucose oxidase) đo ở khoảng 500 nm; nhiều xét nghiệm enzym (ALT, AST…) theo dõi sự giảm D của NADH ở **340 nm** theo thời gian. Mẫu quá đặc (D vượt khoảng tuyến tính) máy báo và **pha loãng** — đúng như mục dung dịch đặc ở trên.
> - **Máy đo oxy mạch nảy (SpO~2~)** kẹp đầu ngón tay có hai đèn: **đỏ (≈ 660 nm)** và **hồng ngoại (≈ 940 nm)**. HbO~2~ và Hb khử có phổ hấp thụ khác nhau ở hai bước sóng này → giống bài toán **hỗn hợp hai chất đo ở hai λ**. Máy chỉ lấy phần hấp thụ **dao động theo mạch đập** (máu động mạch), loại bỏ phần cố định của da, xương, máu tĩnh mạch. SpO~2~ bình thường khoảng **95–100%**.
> - **Giới hạn của SpO~2~**: ngộ độc **CO** cho kết quả **cao giả** (COHb hấp thụ ánh sáng đỏ gần giống HbO~2~); tay lạnh, tưới máu kém, cử động, sơn móng tối màu làm sai số; máy có thể **đánh giá cao hơn thực tế** ở người da sẫm màu.

> [!yhct] Định lượng hoạt chất dược liệu bằng quang phổ và sắc ký
> - **Đo quang UV-Vis** được dùng để định lượng **nhóm hoạt chất** trong dược liệu, cao thuốc: ví dụ **flavonoid toàn phần** (tạo phức màu với AlCl~3~, quy về rutin hay quercetin), **polyphenol toàn phần** (thuốc thử Folin–Ciocalteu). Nguyên lý vẫn là **đồ thị chuẩn D theo C**.
> - **Sắc ký lỏng hiệu năng cao (HPLC)** tách riêng từng hoạt chất rồi đo bằng **đầu dò UV** (cũng theo Beer – Lambert). Dược điển Việt Nam dùng HPLC hoặc đo quang để định lượng **hoạt chất chỉ điểm** của nhiều dược liệu, giúp đánh giá **chất lượng và độ đồng đều** giữa các lô.
> - Mức bằng chứng: đây là phép đo hóa lý đã chuẩn hóa. Nhưng **hàm lượng một chất chỉ điểm cao không đồng nghĩa** vị thuốc hay bài thuốc có tác dụng mạnh hơn theo lý luận YHCT; tác dụng lâm sàng cần nghiên cứu riêng.

## 3. Tạo ảnh bằng tia X và cộng hưởng từ hạt nhân

### 3.1. Thiết bị tạo tia X

Năm **1895**, **Rơnghen** (Wilhelm Conrad Röntgen) phát hiện khi nghiên cứu phóng điện trong khí kém một loại tia **đâm xuyên** được lớp vật chất mỏng, **làm đen kính ảnh**, mắt không thấy được — gọi là **tia X** (tia Rơnghen). Trong y sinh học, tia X được khai thác theo hai hướng: **tác dụng lên sự sống** (xạ trị) và **phản ánh cấu trúc vật chất** khi xuyên qua (chẩn đoán hình ảnh) (tr. 357).

#### a) Sơ đồ máy phát tia X

Máy đơn giản nhất gồm **hai khối** (tr. 358–359).

**Khối 1 – Bóng Rơnghen**: bóng thủy tinh kín, chân không cao (áp suất khí chỉ còn ≈ **10^−7^ mmHg**).

- **Cathode**: sợi dây **vonfram (W)** đốt nóng bằng dòng hạ thế **3–5 A**, nóng tới **≈ 2000 °C** → phát **nhiệt điện tử** (phát xạ nhiệt electron). Gần sợi có **lưới kim loại** tích lũy electron khi chưa đặt cao thế.
- **Anode**: thanh kim loại, mặt **nghiêng** gắn "**bia**" kim loại nặng (thường **tungsten** = vonfram; giáo trình ghi nóng chảy ≈ 3350 °C, giá trị chuẩn là **3422 °C**). Electron đập vào làm bia nóng rất nhanh → phải **làm nguội anode**.

**Khối 2 – Nguồn điện**: biến thế **hạ áp 6–12 V** đốt nóng cathode; biến thế **tăng áp** cho **cao thế một chiều** (dưới 100 kV) giữa anode và cathode; các thiết bị điều khiển điện thế và dòng điện.

![Hình 3. Sơ đồ bóng phát tia X (bóng Rơnghen)](ong-tia-x.svg)

**Vì sao phải tích lũy electron trước?** Để tăng hiệu suất và **giảm thời gian trễ**: khi bật cao thế, đã có sẵn nhiều electron để tăng tốc ngay. Electron được gia tốc cực mạnh, đập vào bia và **dừng lại đột ngột** → phát tia X theo mọi hướng; người ta định hướng chùm tia bằng góc nghiêng bia, vỏ bọc chì có cửa sổ…

**Dòng điện qua bóng chỉ theo một chiều** (electron từ cathode sang anode): bản thân bóng là một **đèn điện tử hai cực**. Có thể dùng thêm hệ **chỉnh lưu cao thế** bên ngoài (tr. 359).

#### b) Phổ phát xạ của tia X

Tia X là **sóng điện từ**. Đồ thị cường độ Φ theo λ (tr. 359) gồm hai phần:

| | **Bức xạ hãm** (phổ liên tục) | **Bức xạ đặc tính** (phổ vạch) |
|---|---|---|
| Hình dạng phổ | Cường độ thay đổi **liên tục** theo λ | Các **đỉnh nhọn** tại λ~1~, λ~2~… |
| Cơ chế | Electron bị **hãm đột ngột** (gia tốc rất lớn) → theo điện động lực học cổ điển, hạt mang điện chuyển động có gia tốc thì phát sóng điện từ. Mỗi electron bị hãm khác nhau → phổ liên tục. | Electron tới **bứt electron lớp K** của nguyên tử bia → electron lớp L, M… nhảy vào chỗ trống, phát photon có năng lượng xác định |
| Phụ thuộc | Điện thế tăng tốc | **Bản chất nguyên tố làm bia** (đặc trưng cho nguyên tố) |

Với bức xạ đặc tính (tr. 359):

=> ε = h·f = h·c/λ = E~L,M…~ − E~K~    (10.16)

- **ε**: năng lượng photon; **E~K~, E~L~, E~M~**: mức năng lượng electron ở lớp K, L, M.
- Chuyển **L → K**: vạch **K~α~**; chuyển **M → K**: vạch **K~β~** (năng lượng lớn hơn, λ ngắn hơn K~α~).
- Chỗ trống ở lớp L cũng được lấp → **dãy L**, năng lượng nhỏ hơn nên **λ dài hơn** dãy K. Ví dụ đồng: dãy L ≈ 13 Å, dãy K ≈ 1,4 Å (tr. 360).

> [!vi-du] Bước sóng ngắn nhất của tia X (bổ sung)
> Một electron có động năng e·U, nếu biến **toàn bộ** thành một photon thì cho photon năng lượng lớn nhất, tức λ ngắn nhất:
> λ~min~ = h·c/(e·U) ≈ 1,24/U(kV) nm.
> U = 100 kV ⇒ λ~min~ ≈ **0,0124 nm**. Tăng điện thế → tia X "cứng" hơn, đâm xuyên hơn. Phần lớn động năng electron (≈ 99%) thành **nhiệt** ở anode.

#### c) Định luật hấp thụ tia X. Lọc tia X

Chùm tia X song song cường độ I~0~ qua lớp vật chất dày x (tr. 360):

=> I = I~0~·e^−μx^    (10.17)

- **μ**: **hệ số hấp thụ bậc nhất** (cm^−1^); **x**: bề dày (cm).
- x càng lớn hoặc μ càng lớn → tia X bị hấp thụ càng nhiều.

**Ba hiệu ứng hấp thụ** tia X: **hiệu ứng Compton**, **hiệu ứng quang điện**, **hiệu ứng tạo cặp**. Hiệu ứng quang điện dễ xảy ra với photon năng lượng thấp; photon **chỉ bị hấp thụ khi năng lượng lớn hơn năng lượng liên kết** của electron. Vì vậy bức xạ K~α~ của đồng **khó bị chính đồng hấp thụ** (không đủ năng lượng bứt electron lớp K của đồng; lớp L đã đầy) (tr. 360).

**μ phụ thuộc** (tr. 360–361):

- **Khối lượng riêng ρ** của chất làm vật cản càng lớn → μ càng lớn.
- **Số thứ tự Z** càng lớn → μ càng lớn.
- **Bước sóng**: đường cong μ theo λ gọi là **phổ hấp thụ**. Tại một số λ, μ **thay đổi đột ngột** — gọi là **biên hấp thụ**. Photon có λ ở **bên trái biên K** (λ ngắn, năng lượng lớn) đủ sức bứt electron lớp K → bị hấp thụ mạnh; bên phải biên thì không.

**Lọc tia X để được chùm gần đơn sắc**: biên K của **niken** ở **1,48 Å** → tấm lọc Ni cho qua vạch K~α~ của đồng nhưng hấp thụ mạnh vạch K~β~. Nguyên tố kế tiếp, **coban**, có biên K ở 1,60 Å → hấp thụ **cả** K~α~ lẫn K~β~ của đồng. Chọn kim loại và bề dày tấm lọc thích hợp sẽ chỉ để lại vạch K~α~ (tr. 361).

> [!vi-du] Bề dày làm giảm một nửa (bổ sung)
> Từ I = I~0~·e^−μx^, bề dày làm cường độ giảm còn một nửa là x~½~ = ln2/μ = 0,693/μ.
> μ = 0,693 cm^−1^ ⇒ x~½~ = 1 cm; qua 3 cm thì I = I~0~/2³ = **I~0~/8**.

### 3.2. Tạo ảnh bằng tia X trong chẩn đoán

Chẩn đoán dựa trên **hai tính chất** của tia X (tr. 361):

1. **Đâm xuyên sâu** hơn hẳn ánh sáng và nhiều bức xạ ion hóa khác.
2. **Hấp thụ khác nhau** tùy bản chất và mật độ vật chất (công thức 10.17). Phần mềm cấu tạo từ nguyên tố nhẹ **C, H, O, N**; xương chứa nguyên tố **Z lớn: P, Ca**. Mật độ cũng khác: **khí** (phổi), **nước** (tim, mạch), **rắn** (xương). Chùm tia ló có cường độ khác nhau → ảnh **đậm nhạt** khác nhau.

> [!bay] Trắng hay đen?
> Trên **phim X quang**, chỗ tia X **bị hấp thụ nhiều** (xương, chất cản quang) thì ít tia tới phim → phim ít đen → **trắng (cản quang)**. Phổi chứa khí hấp thụ ít → phim đen. Trên **màn huỳnh quang** thì ngược lại: chỗ nhiều tia tới thì sáng.

#### a) Mô hình tạo ảnh

Gồm 3 phần: **máy phát tia X + bàn điều khiển**, **đối tượng** (cơ thể), **bộ phận hiện hình**. Mắt không thấy tia X nên cần (tr. 362):

- **Màn huỳnh quang**: kính phủ lớp **muối sulfua kẽm**; tia X tới làm phát ánh sáng huỳnh quang ≈ **500 nm** → gọi là **chiếu X quang** (chiếu điện, radioscopie). Trước dùng nhiều trong chiếu phổi, nay **ít dùng** vì **liều chiếu lớn** không cần thiết. Nhờ **X quang tăng sáng**, ngày nay vẫn chiếu được để thăm khám nhiều tạng với liều thấp.
- **Phim ảnh** để chụp.
- **Chất cản quang** (contrast substances): khi các tạng chồng lên nhau và hấp thụ như nhau thì khó phân biệt → **bơm hơi** hoặc đưa chất **hấp thụ mạnh (có iod)** để tăng tương phản. Từ đó có các kỹ thuật X quang can thiệp: **chụp mạch, chụp đường tiết niệu**…

#### b) Cách làm rõ ảnh

**Quan hệ kích thước ảnh và vật.** Nguồn tia X nhỏ nhưng chùm tia **phân kỳ** nên ảnh bị phóng đại (tr. 362–363):

- **Bóng càng xa** vật thì ảnh càng **ít bị lớn lên** (hình 10.25).
- **Vật càng gần phim** thì ảnh càng **ít bị lớn lên** (hình 10.26) → chụp tạng nào thì cho tạng đó **sát phim**.
- Ví dụ của sách: vật cách phim 10 cm, bóng cách **từ 2 m** trở lên thì ảnh lớn lên **không đáng kể**.
- Nhưng bóng càng xa, cường độ chùm tia tới càng **giảm** → phải **tăng thời gian chụp** → dễ **mờ do rung động** (cử động của bệnh nhân, nhịp tim, nhịp thở).

**Chất lượng hình ảnh** — các nguyên nhân làm mờ, méo (tr. 363):

- Tiêu điểm (đối âm cực) **không phải điểm** mà là một mặt phẳng nhỏ → ảnh của một điểm bị nhòe.
- **Tia thứ cấp** (tán xạ, năng lượng thấp, λ lớn hơn) làm ảnh một điểm trải thành đoạn → cần kỹ thuật loại bớt.
- **Vật di động** (tim, phổi, dạ dày, ruột…), bệnh nhân cử động (bất tỉnh, trẻ em).
- **Méo hình** do vật nằm xa tia trung tâm (tia xiên).
- **Chồng hình** (gan đè phổi, tim chồng phổi…) → chọn **tư thế chụp** thích hợp (chụp sọ não, chụp chuyên khoa tai mũi họng…).

> [!ung-dung] Phim phổi thẳng chụp xa 1,8 m
> Phim X quang ngực thẳng thường chụp **tư thế sau – trước (PA)**, bóng cách phim khoảng **1,8 m**, ngực áp sát phim. Hai điều kiện này giúp **bóng tim ít bị phóng đại**, nên đo được **chỉ số tim – ngực** (bình thường dưới 0,5). Bệnh nhân nín thở để tránh mờ do cử động.

#### c) Chụp cắt lớp

**Cắt lớp cổ điển** (tomographie, tr. 363–364): **bóng X và phim chuyển động đều, ngược chiều nhau** quanh một trục quay nằm trong mặt phẳng cần xem. Điểm thuộc mặt phẳng đó luôn chiếu cố định lên phim nên **rõ**; điểm ở trước hay sau thì **mờ** đi (càng xa càng mờ). Hay dùng cho phổi, trung thất.

**Chụp cắt lớp vi tính (CT – Computed Tomography)** theo nguyên lý khác hẳn (tr. 364–366):

- Vẫn dùng bóng phát tia X (có **ống chuẩn trực** — collimator — tạo chùm tia **mỏng, dẹt hình rẻ quạt**), nhưng thu tia ló bằng **bộ cảm biến điện tử** (detector) nhạy hơn phim **hàng trăm lần**, xếp thành **vòng tròn** thu tín hiệu từ 360°.
- Hệ thu nhận dữ kiện (**DAS**) mã hóa tín hiệu và truyền vào máy tính. Ở mỗi vị trí, một **mã số độ giảm tuyến tính** (linear attenuation) được ghi vào bộ nhớ.
- Một lần hấp thụ **không đủ** để dựng cấu trúc → tia X phải **quay vòng quanh** bệnh nhân. Từ rất nhiều số đo ở nhiều góc, máy tính **tái tạo** hình lớp cắt, **khử bỏ** (subtraction) thông tin của các mặt phẳng trên và dưới.

**Nguyên lý tạo ảnh theo ma trận** (tr. 365):

- Lớp cắt chia thành các ô thể tích cơ bản — **voxel** (volume element); chiều dày voxel = **chiều dày lớp cắt (1–10 mm)**. Mỗi voxel cho một ô ảnh — **pixel** (picture element).
- Mỗi voxel có **tỷ trọng quang tuyến** (radiologic density) riêng, tức hấp thụ tia X nhiều hay ít → pixel đậm nhạt khác nhau. Người Pháp gọi kỹ thuật là chụp cắt lớp theo tỷ trọng (tomodensitométrie). **Tỷ trọng đo bằng đơn vị Hounsfield (HU)**.
- Ma trận thường dùng: 256 × 256 (sách in 252 × 252), 340 × 340, 512 × 512; thế hệ 4 có **1024 × 1024** (≈ 1 048 576 ô). Ma trận càng lớn, ảnh càng chi tiết. Khám thường ngày dùng 340 × 340 là đủ; xem chi tiết nhỏ (tai, não) cần ma trận lớn hơn.

**Quan sát ảnh – kỹ thuật "cửa sổ"** (tr. 365–366): máy tính phân biệt được **2000–4000 mức** tỷ trọng (từ khí đến xương), nhưng **mắt người chỉ phân biệt được ít bậc xám**. Vì vậy người ta **mở cửa sổ**:

- **Điểm giữa cửa sổ** (center, level) đặt bằng tỷ trọng trung bình của cấu trúc cần xem.
- **Độ rộng cửa sổ** (width): khoảng tỷ trọng được trải ra trên toàn thang xám. Giá trị **cao hơn** giới hạn trên → **trắng**; **thấp hơn** giới hạn dưới → **đen**.
- Mở cửa sổ hết cỡ thì xương trắng, phổi đen, dịch xám — giống phim X quang thường. Chọn cửa sổ hẹp quanh tỷ trọng của mô cần xem thì thấy được những khác biệt rất nhỏ. Đó là ý nghĩa lớn của thang Hounsfield: **toàn bộ thông tin tỷ trọng được lưu trong máy**, còn phim X quang thường chỉ có độ đen cố định.

**Các mặt cắt**: thường chụp **mặt cắt ngang** (vuông góc cột sống); máy tính ráp lại thành mặt **đứng dọc** (sagittal) hay **đứng ngang** (frontal), nhưng các mặt này thường kém nét hơn. Độ phân giải phụ thuộc chiều dày và khoảng cách các lát cắt (tức ma trận). Máy **xoắn ốc** (helical, spiral): bóng và detector quay **liên tục**, bàn bệnh nhân **dịch dần** vào → quỹ đạo quét là **đường xoắn ốc**, độ phân giải cao hơn (tr. 366).

**Lịch sử**: giáo trình ghi CT do **A. M. Cormack** phát minh năm 1971; **Cormack và Hounsfield** nhận giải **Nobel Y học 1979**. Máy đầu tiên mất tới **hai ngày** cho một ảnh; máy hiện đại chỉ **1/10 – 3/10 giây** (tr. 366).

> [!ung-dung] Đơn vị Hounsfield trên lâm sàng
> Thang HU lấy **nước = 0** và **không khí = −1000**:
> HU = 1000 × (μ − μ~nước~)/μ~nước~
> | Mô | HU (gần đúng) |
> |---|---|
> | Không khí, phổi | −1000 (phổi ≈ −700 đến −900) |
> | Mỡ | ≈ −100 |
> | Nước, dịch trong | 0 |
> | Mô mềm, máu | +20 đến +60 |
> | **Máu tụ mới** | +50 đến +80 (tăng tỷ trọng — "trắng" trên CT sọ) |
> | Xương đặc | +700 đến trên +1000 |
> - **CT sọ không tiêm thuốc** là xét nghiệm đầu tay khi nghi **đột quỵ**: máu tụ mới tăng tỷ trọng thấy ngay, giúp phân biệt **xuất huyết não** với **nhồi máu não** trước khi dùng thuốc tiêu sợi huyết.
> - Cùng một lần chụp, bác sĩ xem bằng "cửa sổ não", "cửa sổ phổi", "cửa sổ xương" — chính là chỉnh level/width.

> [!cap-nhat] CT ngày nay và liều chiếu
> - Giáo trình ghi Cormack "người Anh" phát minh CT năm 1971. Thực tế **Godfrey Hounsfield** (kỹ sư người Anh) chế tạo máy CT đầu tiên (chụp người bệnh đầu tiên năm 1971); **Allan Cormack** (nhà vật lý gốc Nam Phi, làm việc ở Mỹ) xây dựng **cơ sở toán học** cho việc tái tạo ảnh. Cả hai cùng nhận Nobel 1979.
> - Máy CT hiện nay là **CT đa dãy đầu thu** (nhiều chục đến vài trăm dãy), quét cả lồng ngực trong vài giây.
> - CT cho liều chiếu **cao hơn nhiều** X quang thường: một phim phổi thẳng chỉ cỡ **0,02–0,1 mSv**, còn một lần CT bụng có thể **vài đến khoảng 10 mSv**. Vì vậy chỉ định CT phải có lý do chính đáng và tối ưu liều (nguyên tắc **ALARA**), nhất là ở **trẻ em** và **phụ nữ có thai**.

### 3.3. Chụp hình bằng cộng hưởng từ hạt nhân (MRI)

#### a) Mômen từ hạt nhân

Hạt nhân gồm **proton** và **neutron** (tr. 366–367):

- **Proton** mang điện dương (bằng điện tích electron về độ lớn), khối lượng gấp **gần 2000 lần** electron; tự quay như một hạt mang điện → có **mômen từ**.
- **Neutron** trung hòa điện nhưng cũng có **spin** và mômen từ (có thể coi như quả cầu có điện tích phân bố, tổng bằng 0).
- Mômen từ proton và neutron cỡ **10^−27^ A·m²**. Mômen từ hạt nhân là tổng hợp (theo quy tắc lượng tử) của các proton và neutron: có hạt nhân mômen từ lớn, nhỏ, hoặc bằng 0. Nói chung chỉ cỡ **phần nghìn** mômen từ của vỏ electron → điều kiện cộng hưởng từ hạt nhân rất khác cộng hưởng từ electron.

Bảng của sách liệt kê ^1^H (1p, 0n), ^12^C (6p, 6n), ^13^C (6p, 7n), ^14^N (7p, 7n), ^23^Na (11p, 12n), ^31^P (15p, 16n), ^39^K (19p, 20n).

**Vì sao chọn hạt nhân hydro?** Hydro là một trong hai nguyên tố cấu tạo **nước** — có ở mọi nơi trong cơ thể — và cho **tín hiệu cộng hưởng rất mạnh**. Hạt nhân hydro chỉ là **một proton**, nên mômen từ của nó chính là mômen từ proton (tr. 367).

#### b) Cộng hưởng từ hạt nhân

Hạt nhân có mômen từ **μ** đặt trong từ trường **B~0~** sẽ **tuế sai** (chuyển động **Larmor**): đầu mút vectơ μ vạch đường tròn quanh phương B~0~, giống con quay nghiêng quay quanh phương thẳng đứng (tr. 367–368). Tần số Larmor:

=> f~0~ = g~p~·μ~p~·B~0~

- Với proton: **B~0~ = 1 T → f~0~ = 42,58 MHz** (vùng sóng radio). f~0~ **tỉ lệ thuận** với B~0~.

Như vậy hạt nhân trong B~0~ là một **hệ dao động có tần số riêng f~0~**. Chiếu thêm sóng radio tạo từ trường **B~1~ vuông góc B~0~, quay quanh B~0~** với tần số góc ω. Khi **ω = ω~0~** → **cộng hưởng**: mômen từ vẫn quay với tần số cũ nhưng biên độ lớn hơn, **nghiêng xa** phương B~0~ (về phía vuông góc) (tr. 368).

> [!vi-du] Tính tần số cộng hưởng
> Máy MRI 1,5 T: f~0~ = 42,58 × 1,5 ≈ **63,9 MHz**. Máy 3 T: f~0~ ≈ **127,7 MHz**.
> Đổi máy mạnh gấp đôi thì phải đổi tần số sóng radio **gấp đôi**.

#### c) Mômen từ của tập hợp hạt nhân

Thực tế ta không cộng hưởng từng hạt nhân mà cả tập hợp trong một thể tích (ví dụ 1 mm³ vỏ não). Theo quy luật lượng tử, trong B~0~ phần lớn hạt nhân có μ **song song cùng chiều** B~0~ (N~1~ hạt), một số **đối song** (N~2~ hạt), N~1~ > N~2~ (tr. 368–369):

=> ΔN/N = (N~1~ − N~2~)/N ≈ μ·B~0~/(k·T)

- **k**: hằng số Boltzmann; **T**: nhiệt độ tuyệt đối (K).
- Ở 25 °C, B~0~ = 1 T, với hydro: **ΔN/N cỡ 10^−6^** — chỉ khoảng **một phần triệu** hạt nhân "dư" theo chiều B~0~ là đóng góp vào mômen từ tổng.

=> M = ΔN·μ = N·μ²·B~0~/(k·T)

**Vì sao tín hiệu MRI yếu và cần từ trường mạnh?** Vì chỉ một phần triệu proton đóng góp; tăng B~0~ (hoặc giảm T) thì ΔN tăng, M tăng, tín hiệu mạnh hơn.

#### d) Cộng hưởng trong một thể tích nhiều hạt nhân

Phân tích μ thành thành phần **song song** B~0~ (μ~//~) và **vuông góc** B~0~ (μ~⊥~) (tr. 369–371):

| Trạng thái | Từ hóa dọc M~//~ = Σμ~//~ | Từ hóa ngang M~⊥~ = Σμ~⊥~ | Vì sao |
|---|---|---|---|
| **Chỉ có B~0~** | **Cực đại** (≈ ΔN·μ) | **Bằng 0** | Các μ~⊥~ quay cùng tần số nhưng **không đồng pha**, hướng lộn xộn → triệt tiêu |
| **Cộng hưởng** (chiếu sóng radio f~0~) | **Bằng 0** | **Cực đại** | B~1~ làm các μ nghiêng về phía B~1~ và quay **đồng pha**; hạt nhân hấp thụ năng lượng → N~2~ tăng, N~1~ giảm, ΔN giảm |

**Quá trình hồi phục** khi tắt sóng radio (tr. 371):

- M~//~ tăng từ 0 về cực đại → **thời gian hồi phục dọc T~1~**.
- M~⊥~ giảm từ cực đại về 0 → **thời gian hồi phục ngang T~2~**.
- Đầu mút vectơ M vạch **đường xoắn ốc nhỏ dần** (hình 10.33).
- Nói chung **T~1~ > T~2~**.

| | T~1~ (dọc) | T~2~ (ngang) |
|---|---|---|
| Giá trị trong mô sinh học | **300 – 2000 ms** | **30 – 150 ms** |
| Phụ thuộc môi trường quanh hạt nhân | Quanh là **phân tử nhỏ** (nước) → truyền năng lượng ra **lâu hơn** → T~1~ dài; quanh là phân tử lớn, cồng kềnh (mỡ) → T~1~ ngắn | Lớn khi quanh là **nước**; nhỏ khi là **chất mỡ** hoặc dịch có nhiều phân tử lớn |
| Ghi chú | | **Nhạy hơn** với cấu trúc sinh học |

**Tín hiệu FID** (free induction decay — tín hiệu cảm ứng suy giảm tự do): khi M biến thiên theo đường xoắn ốc, từ thông qua cuộn dây (anten) đặt gần biến đổi → sinh **dòng điện cảm ứng**. Độ lớn FID phụ thuộc độ lớn M, tức **mật độ proton**; phân tích dạng FID cho biết T~1~, T~2~ (tr. 371–372).

Chia cơ thể thành các phần tử thể tích nhỏ có tọa độ x, y, z, cho từng phần tử cộng hưởng và thu tín hiệu → máy tính gán độ đậm nhạt (hay màu) cho từng điểm → **ảnh cắt lớp hai chiều hoặc ba chiều**, biết đâu là nước, chất mỡ, máu, xương (tr. 372).

#### e) Chụp ảnh cắt lớp cộng hưởng từ

**Máy cộng hưởng từ ở phòng thí nghiệm** (tr. 372–373): nam châm vĩnh cửu tạo B~0~ đều giữa hai cực; mẫu đặt trong ống có **cuộn dây RF** tạo B~1~ ⊥ B~0~. Điều khiển tần số B~1~; khi cộng hưởng, **công suất máy phát tăng vọt** → biết tần số cộng hưởng của mẫu. Biến thiên của M sinh dòng cảm ứng trong cuộn dây → đo được thời gian hồi phục dọc và ngang.

**Giải pháp then chốt — gradient từ trường** (**Lauterbur, 1973**; tr. 373–374):

- Cuộn dây **siêu dẫn** tạo B~0~ rất mạnh và rất đều. Thêm một cuộn tạo từ trường yếu B~z~ song song B~0~ nhưng **biến thiên đều theo z**:

=> B~0~ + B~z~ = (1 + α + βz)·B~0~

- Trong hình trụ, từ trường chia thành các **lớp mỏng** vuông góc trục z, mỗi lớp có từ trường gần như không đổi: …0,98 T; 0,99 T; 1 T; 1,01 T; 1,02 T…
- Chiếu sóng 42,58 MHz thì **chỉ lớp có B = 1 T** cộng hưởng → **chọn được lát cắt**. Bề dày lớp phụ thuộc từ trường biến thiên nhanh hay chậm (độ dốc gradient).
- Dịch vị trí lớp cắt bằng hai cách: **giữ tần số sóng radio, dịch gradient**; hoặc **giữ gradient, đổi tần số sóng radio**.
- Máy có **ba cuộn gradient** theo x, y, z → cộng hưởng được từng phần tử thể tích tọa độ (x, y, z), quét toàn bộ lớp cắt, rồi dựng ảnh ba chiều.

**Tín hiệu tạo ảnh**: mật độ proton, nhưng thường dùng tín hiệu liên quan **T~1~, T~2~** vì chúng rất phụ thuộc thể tích chứa chất gì (nước, dịch, não tủy, ung thư…). Ảnh T~1~, T~2~ cho thấy rõ máu, mỡ, não; phân biệt **máu đang chảy trong mạch** với máu chảy ngấm ra ngoài khi mạch vỡ (tr. 374). Hình 10.36 của sách so sánh mật độ proton: xương thấp nhất, rồi da, gan, chất trắng, cơ bắp, chất xám.

#### f) Ưu điểm và an toàn

So với CT và chụp cắt lớp phóng xạ, MRI **không đưa vào cơ thể bức xạ ion hóa nào**. Cơ thể chỉ chịu **ba tác dụng vật lý**: **từ trường tĩnh B~0~**, **gradient từ trường** và **sóng radio** (tr. 374–376):

- **B~0~** thường cỡ **1 T** trở lên, mạnh gấp **20 000 lần** từ trường Trái Đất; theo giáo trình, tới **2,5 T** vẫn chưa thấy hại.
- **Gradient** biến thiên chỉ gây dòng cảm ứng mật độ cỡ **1 µA/cm²** — quá nhỏ, không hại.
- **Sóng radio**: cơ thể hấp thụ khoảng **0,7 W** → nhiệt độ tăng chỉ **0,1–0,2 °C**.
- Tín hiệu rất nhạy với cấu tạo mô: thấy rõ **mạch máu rạn nứt, máu rỉ ra ngoài, khối u nhỏ chèn dây thần kinh**.

**Hạn chế**: trong cơ thể **không được có mảnh kim loại, vật liệu từ** (mảnh bom, đạn): từ trường mạnh sẽ **hút và làm nóng** chúng. Đặc biệt người mang **máy trợ tim** (máy tạo nhịp): máy bị hỏng ngay, người bệnh khó tránh tử vong (tr. 376).

> [!ung-dung] Hỏi kỹ trước khi cho bệnh nhân vào phòng MRI
> **Chống chỉ định / cần thận trọng**: máy tạo nhịp, máy khử rung cấy (ICD) loại không tương thích MRI; **ốc tai điện tử**; **kẹp phình mạch** não bằng kim loại sắt từ; **dị vật kim loại trong mắt** (thợ hàn, thợ mài — có thể chụp X quang hốc mắt để loại trừ); bơm thuốc cấy; mảnh đạn gần mạch máu, thần kinh.
> - Vật sắt từ mang theo (bình oxy, xe đẩy, kéo, bút) có thể **bị hút bay vào máy** như "viên đạn" — tai nạn đã từng gây tử vong.
> - MRI **không** dùng tia X → an toàn hơn CT về bức xạ, thích hợp cho trẻ em, khảo sát não – tủy sống, khớp, mô mềm; nhưng chụp **lâu**, ồn, người **sợ không gian kín** có thể cần an thần.
> - CT tốt hơn MRI khi cần **nhanh** (chấn thương, đột quỵ cấp) và để xem **xương, phổi**.

> [!cap-nhat] MRI hiện nay
> - Máy lâm sàng thông dụng hiện nay là **1,5 T và 3 T**; máy **7 T** đã được cấp phép dùng trên người (Mỹ, 2017). Giáo trình ghi "tới 2,5 T chưa có tác hại" — số liệu đã cũ.
> - Đã có **máy tạo nhịp, ICD "tương thích MRI có điều kiện"** (MR-conditional): chụp được nếu tuân thủ quy trình (kiểm tra thiết bị, lập trình chế độ an toàn, theo dõi). Máy đời cũ hoặc không rõ loại thì vẫn **chống chỉ định**.
> - Giải Nobel Y học **2003** trao cho **Paul Lauterbur** và **Peter Mansfield** vì phát minh tạo ảnh MRI.
> - Thuốc đối quang từ chứa **gadolinium** giúp tăng tương phản; cần thận trọng ở người **suy thận nặng**.

## 4. Phương pháp phóng xạ

Đồng vị phóng xạ (đvpx) dùng trong y học **không chỉ để diệt tế bào bệnh** mà còn để **đánh dấu** trong mọi chuyên khoa, tạo ra chuyên khoa **y học hạt nhân** (yhhn). Kết quả ghi đo thể hiện bằng **số xung, đồ thị, hình ảnh** để đánh giá cấu trúc, chức năng và chẩn đoán (tr. 376).

### 4.1. Phương pháp đánh dấu phóng xạ

#### a) Cơ sở

Kỹ thuật đánh dấu dựa trên các đặc điểm (tr. 376–377):

- **Đồng vị phóng xạ và đồng vị bền chịu mọi quá trình sinh lý, sinh hóa như nhau.** Cơ thể (từ phân tử đến quần thể sinh vật) **không phân biệt** được chúng — nhưng ta **ghi đo** được đvpx nhờ bức xạ nó phát ra.
- **Khối lượng chất đánh dấu rất nhỏ**, không ảnh hưởng hoạt động sống.
- Kỹ thuật thường **không gây thương tổn** (non-invasive): cao nhất chỉ là **tiêm tĩnh mạch**.

**Chất đánh dấu (tracer) lý tưởng** (tr. 377):

1. Tính chất **hoàn toàn giống** đối tượng cần khảo sát.
2. Được hấp thụ **hoàn toàn, nhanh** và **chỉ riêng** tại cơ quan, mô khảo sát (target organ).
3. Nồng độ **ít thay đổi** tại chỗ trong suốt quá trình khảo sát.
4. Khảo sát xong, **thải nhanh và hoàn toàn** khỏi cơ thể.
5. Bức xạ phát ra **dễ ghi đo** bằng phương tiện sẵn có (loại tia, năng lượng tia).
6. Tạo ra **liều hấp thụ thấp nhất**.

**Vì sao đvpx "đánh dấu" tốt?** Hóa học của một nguyên tố do **lớp vỏ electron** quyết định, mà đồng vị chỉ khác nhau ở **số neutron** trong hạt nhân → tính chất hóa học, sinh học gần như giống hệt, nhưng hạt nhân phóng xạ "tự báo vị trí" bằng tia phát ra.

#### b) Các ứng dụng

**Thăm dò chức năng** tế bào, mô, cơ quan (tr. 377):

- Chức năng **hấp thu, chuyển hóa, đào thải**…
- **Động học** các quá trình như tuần hoàn, tiết niệu.
- **Hàm lượng, nồng độ**: chất điện giải, thể tích các dịch, **thể tích máu, khối lượng hồng cầu**, nồng độ enzym, hormon…
- Đo **in vitro** (mẫu rời, ở từng thời điểm) hoặc **in vivo** (đo ngay trên người bệnh); đếm xung hoặc đo hoạt tính tổng cộng; so sánh đối chiếu hoặc tính giá trị tuyệt đối.

**Định lượng miễn dịch phóng xạ RIA và IRMA** (tr. 377–379): RIA (Radio Immuno Assay) khởi đầu năm **1960** bởi **Yalow và Berson** với **insulin**. Kỹ thuật định lượng được tới **nanogram (10^−9^ g)** và **picogram (10^−12^ g)** nhờ **tính đặc hiệu rất cao** của phản ứng miễn dịch, lại tự động hóa được để xét nghiệm hàng loạt.

| | **RIA** | **IRMA** |
|---|---|---|
| Chất đánh dấu | **Kháng nguyên** (Ag*) | **Kháng thể** (Ab*) |
| Nguyên lý | **Cạnh tranh**: Ag* và Ag (cần định lượng) tranh nhau gắn **lượng kháng thể hạn chế** | **Không cạnh tranh**: cho **Ab* dư thừa**, Ag gắn với Ab* |
| Khi Ag trong mẫu tăng | Phức hợp gắn **Ag*Ab (B) giảm**, phần tự do (F) tăng → **B/F giảm** | Hoạt tính phần gắn **Ab*Ag tăng — tỉ lệ thuận** nồng độ Ag |
| Ra đời | 1960 (Yalow, Berson) | Đề xuất 1968 (Miles và Hales), dùng rộng rãi từ khoảng 1980 |
| Ghi chú | Dùng đồ thị chuẩn: trục tung B/F (hoặc B/T, B/B~0~), trục hoành nồng độ | Dùng được **kháng thể đơn dòng** → **đặc hiệu, chính xác hơn** RIA |

- Trong RIA: **B** (bound) = phức hợp gắn Ag*Ab; **F** (free) = Ag* tự do; **T** = tổng hoạt tính mẫu (B + F); **B~0~** = phần gắn ở điểm 0 của đồ thị (nồng độ 0).
- Muốn làm RIA, IRMA cần: **chất đánh dấu phóng xạ** (Ag* hoặc Ab*); **chất gắn đặc hiệu** (Ab); **hệ thống tách riêng B và F**; **chất chuẩn** để lập đồ thị chuẩn. Hai khâu quan trọng nhất là tự tạo được Ab* hoặc Ag* và kháng thể đặc hiệu.

> [!bay] RIA: nồng độ càng cao, tín hiệu gắn càng thấp
> Trong **RIA**, đồ thị chuẩn **đi xuống**: Ag trong mẫu càng nhiều thì chiếm chỗ của Ag* càng nhiều → hoạt tính phần gắn (B) **giảm**. Trong **IRMA** thì ngược lại, hoạt tính phần gắn **tăng** theo nồng độ. Đây là câu hay bị hỏi đảo.

> [!cap-nhat] Về RIA
> - Giáo trình viết tên "Yellow và Berson" và "họ được giải Nobel". Đúng là **Rosalyn Yalow**; giải **Nobel Y học 1977** chỉ trao cho **Yalow**, vì **Solomon Berson đã mất năm 1972** (giải Nobel không trao cho người đã mất).
> - Hiện nay phần lớn xét nghiệm hormon, chất chỉ điểm khối u ở bệnh viện dùng **miễn dịch không phóng xạ** (ELISA, **hóa phát quang** CLIA/ECLIA) — cùng nguyên lý cạnh tranh hay "sandwich" như RIA/IRMA nhưng đánh dấu bằng enzym hoặc chất phát quang, tránh được chất thải phóng xạ.

**Ghi hình phóng xạ** (xạ hình, tr. 379): ghi lại bức xạ phát ra từ mô, tạng, tổn thương để đánh giá **sự phân bố** của dược chất phóng xạ. Các kỹ thuật: **ghi hình vạch thẳng** (scanner), **chụp nhấp nháy (gamma camera)**, **chụp cắt lớp bằng đơn photon (SPECT)**, **chụp cắt lớp bằng positron (PET)**. Ví dụ của sách:

- **Xạ hình tuyến giáp**: vùng **không bắt iod phóng xạ** (ở đáy và giữa thùy phải) — **"nhân lạnh"** do nang tuyến giáp.
- **Xạ hình toàn thân xương** với **MDP đánh dấu Tc-99m** ở bệnh nhân ung thư xương đã di căn vào phổi.

> [!ung-dung] SPECT và PET
> - **Tc-99m** là đồng vị dùng nhiều nhất trong xạ hình: phát gamma **140 keV** (dễ ghi đo), chu kỳ bán rã **≈ 6 giờ** (đủ để chụp, thải nhanh) — đáp ứng tốt các tiêu chí "tracer lý tưởng".
> - **PET**: dược chất phát **positron**, phổ biến nhất là **^18^F-FDG** (đường glucose gắn fluor-18). Positron gặp electron → **hủy cặp**, phát **hai photon 511 keV bay ngược chiều nhau**; vòng đầu dò ghi **cặp trùng phùng** để dựng ảnh. Tế bào ung thư **tiêu thụ glucose mạnh** → bắt FDG nhiều → "điểm nóng". Ứng dụng: đánh giá giai đoạn, theo dõi đáp ứng điều trị ung thư. Ngày nay thường ghép **PET/CT** để vừa có chức năng chuyển hóa vừa có giải phẫu.

### 4.2. Phương pháp dùng nguồn chiếu xạ

#### a) Dùng nguồn chiếu để chẩn đoán — phân tích kích hoạt neutron (tr. 379–380)

Bắn **neutron** vào hạt nhân **đồng vị bền** → biến thành **đồng vị phóng xạ**; đo phóng xạ của đồng vị mới để biết **hàm lượng** đồng vị bền ban đầu. Ví dụ:

=> ^55^Mn (n,γ) ^56^Mn

=> ^16^O (n,p) ^16^N

- ^55^Mn, ^16^O: đồng vị bền (đồng vị **mẹ**); ^56^Mn, ^16^N: đồng vị phóng xạ (đồng vị **con**).
- Hoạt tính thu được phụ thuộc: **nồng độ đồng vị mẹ** trong mẫu; **thông lượng và đặc điểm chùm neutron**; **tiết diện của hiệu ứng**; **thời gian chiếu**.
- Có thể tạo nhiều đồng vị con → cần tách, tinh sạch. Phương pháp xác định rất chính xác các **nguyên tố vi lượng** (Fe, Zn, Mn, Cr, Co, Cu, As, Br…) hay đa lượng (C, O, N, Ca…) trong **máu, da, tóc** → chẩn đoán rối loạn chuyển hóa, hấp thu, tim mạch, tiêu hóa, tâm thần…

#### b) Dùng nguồn chiếu trong điều trị (tr. 380–381)

Dựa trên **tác dụng sinh học của bức xạ ion hóa**: **diệt tế bào** (vi khuẩn, tế bào bệnh). Hiểu càng sâu về cơ chế truyền năng lượng, cơ chế diệt bào, đặc điểm vật lý của bức xạ và yếu tố môi trường (nhiệt độ, nồng độ oxy…) thì kỹ thuật xạ trị càng cải tiến.

| Hình thức | Nội dung theo giáo trình |
|---|---|
| **Chiếu ngoài** (teletherapy) | Tia X, **tia gamma cứng**, **máy gia tốc** chiếu từ ngoài cơ thể diệt tế bào ung thư |
| **Áp sát** (brachytherapy) | **Nguồn kín** (kim, hạt) và nguồn đặt qua dụng cụ (applicator) phát **tia beta cứng hoặc gamma mềm**: từ điều trị bệnh ngoài da đến đưa nguồn ^90^Y vào u tuyến yên, đặt nguồn vào các hốc tự nhiên. Cải tiến: **nạp nguồn sau** (afterloading), **lập kế hoạch theo kích thước khối u** (ba chiều). Đồng vị cổ điển: radi, ^60^Co, ^90^Y; mới hơn: palladium, samarium-145, americium-241, ytterbium-169 |
| **Nguồn hở** | Đưa đvpx dạng **hở** (dung dịch, khí) vào cơ thể; nó tự đến **mô đích** nhờ hoạt tính chuyển hóa bình thường (tuyến giáp hấp thụ iod) hay thay đổi bệnh lý (khối u hấp thụ phân tử đặc hiệu); hoặc nhờ cơ học: **thông khí** vào phế quản – phổi, **nuốt** vào dạ dày, **tuần hoàn máu** đến tế bào máu. Điều trị: bệnh **tuyến giáp**, bệnh máu, cơ xương khớp, tắc mạch vành, nhiều ung thư di căn |

> [!bay] Thuật ngữ và lỗi in trong mục này
> - Giáo trình gọi điều trị bằng nguồn hở là "**Curietherapy**"; trong tiếng Pháp *curiethérapie* thường chỉ **xạ trị áp sát**. Thuật ngữ quốc tế cho điều trị bằng nguồn hở là **điều trị bằng dược chất phóng xạ** (xạ trị chuyển hóa). Khi thi, nhớ nội dung: **nguồn hở → đi theo đường chuyển hóa đến mô đích**.
> - Giáo trình xếp **dao gamma (Gamma Knife)** vào nhóm áp sát. Thực ra Gamma Knife là **xạ phẫu định vị**: khoảng 200 chùm gamma từ các nguồn ^60^Co **bên ngoài** đầu hội tụ vào một điểm trong sọ — tức là một dạng **chiếu ngoài** chính xác cao (dùng cho dị dạng mạch máu não, u nhỏ trong sọ).
> - Một số lỗi in: "²²²Ra" nên là **^226^Ra** (radi); "⁵⁰Co" ở tr. 382 là **^60^Co**; trong xạ trị áp sát, đồng vị palladium dùng thực tế là **^103^Pd** (sách in Pd-107).

> [!ung-dung] Xạ trị và iod phóng xạ trong thực hành
> - **Iod-131** (phát beta + gamma, chu kỳ bán rã ≈ **8 ngày**) uống dạng dung dịch/viên: tuyến giáp **tự bắt iod** → tia beta phá hủy mô giáp tại chỗ. Dùng điều trị **Basedow** (cường giáp) và **ung thư tuyến giáp** biệt hóa sau mổ. Đây là ví dụ điển hình của **nguồn hở**.
> - **Máy gia tốc tuyến tính (LINAC)** là thiết bị xạ trị chiếu ngoài chủ yếu hiện nay, thay dần máy ^60^Co.
> - **Áp sát nạp nguồn sau** (thường dùng ^192^Ir): đặt dụng cụ rỗng vào khối u (ví dụ ung thư cổ tử cung), rồi máy mới đẩy nguồn vào → nhân viên không bị chiếu xạ. **Cấy hạt ^125^I** vào tuyến tiền liệt.

#### c) Một số mục đích khác của chiếu xạ (tr. 381–382)

**Tiêu diệt nấm, mốc, vi sinh vật gây hại** — bảo quản lương thực, thực phẩm:

- Hao hụt lương thực do bảo quản thường là **5%**, có khi tới **60%**, nhất là vùng nhiệt đới. Xử lý nhiệt với khối lượng lớn không phải lúc nào cũng làm được; hóa chất có khi không hiệu quả và có thể gây hại cho người dùng.
- Liều cần **rất lớn**: **5 000 – 15 000 R** hạn chế sinh trưởng của sâu; **20 000 R** giết trứng sâu. Phải xem xét hậu quả: chất dinh dưỡng có bị phân hủy, có sinh chất độc hại hay không.
- **7 000 – 10 000 R**: **khoai tây không nảy mầm** khi bảo quản lâu, không hại cho người dùng. Vì sao? Khoai tây nảy mầm nhờ **tổng hợp acid nhân ở điểm sinh trưởng**; chiếu xạ làm chậm quá trình này.
- Côn trùng: tạo **đột biến di truyền bất lợi** như vô sinh rồi thả vào môi trường; liều khoảng **8 000 R** làm con đực mất khả năng sinh sản → trứng không nở → quần thể bị diệt dần.

**Tiệt trùng dụng cụ y tế**: khử trùng bằng hóa chất (thuốc sát trùng, cồn…) hay nhiệt (luộc, hấp, sấy, đốt…) không phải lúc nào cũng dùng được và có thể hỏng sản phẩm. Sau **Chiến tranh thế giới lần thứ hai**, bức xạ ion hóa được dùng rộng rãi để diệt vi sinh vật ở **chỉ khâu, thuốc, găng tay phẫu thuật, dụng cụ tiêm truyền, dụng cụ phẫu thuật** — sản phẩm được chiếu xạ sau khi đã đóng gói kín. Kiểm tra "vô trùng": lấy mẫu **ủ ở nhiệt độ thuận lợi** cho vi khuẩn (30 °C, 37 °C và 55 °C), nuôi cấy tiếp; không thấy vi khuẩn mọc thì coi là vô trùng.

**Kích thích cây trồng, hạt giống; gây đột biến có lợi để tạo giống mới**: liều nhỏ chiếu vào hạt giống có thể kích thích sinh trưởng, chống bệnh, rút ngắn thời gian thu hoạch (do bức xạ tác động lên sự phân chia tế bào). Nguồn lớn thường dùng: **^60^Co và ^137^Cs**. Bức xạ ion hóa gây **biến đổi ADN, ARN** → đột biến; chọn lọc cá thể có lợi qua nhiều thế hệ (công việc kéo dài hàng chục năm). Ví dụ: cải dầu Regina (Thụy Điển 1953, năng suất cao); lúa mạch mùa đông Jutta (Đức 1953, chịu rét); yến mạch Florad (Florida 1960, kháng bệnh); lúa mạch mùa xuân Mari (Thụy Điển 1960, chín sớm); lúa mì NP 836 (Ấn Độ 1960, chịu hạn).

> [!cap-nhat] Đơn vị và giới hạn liều
> - **Roentgen (R)** là đơn vị **chiếu xạ** cũ (đo ion hóa trong không khí, 1 R = 2,58·10^−4^ C/kg). Ngày nay liều chiếu xạ thực phẩm, dụng cụ y tế tính bằng **gray (Gy) – kilogray (kGy)**; 1 R tương ứng khoảng 0,01 Gy trong mô mềm. Ví dụ 7 000–10 000 R chống nảy mầm khoai tây ≈ **0,07–0,1 kGy**; tiệt trùng dụng cụ y tế thường dùng **khoảng 25 kGy**.
> - Giới hạn liều theo ICRP (Việt Nam áp dụng tương tự): **nhân viên bức xạ 20 mSv/năm** (trung bình 5 năm); **công chúng 1 mSv/năm**. Mọi chỉ định chiếu xạ phải **chính đáng** và giữ liều **thấp nhất có thể đạt được (ALARA)**.

## Tóm tắt

| Chủ đề | Điều phải nhớ |
|---|---|
| Kính lúp | k = l~0~/f (l~0~ = 25 cm); vật trong tiêu cự → ảnh ảo, cùng chiều |
| Kính hiển vi | Vật ngoài, sát F~1~ → A~1~B~1~ thật, ngược; A~1~B~1~ trong tiêu cự thị kính → A~2~B~2~ ảo. **K = Δ·l~0~/(f~1~·f~2~) = K~V~·K~T~** |
| Phân ly | **l~min~ = 0,61·λ/(n·sinθ)**, S = 1/l~min~; tăng bằng vật kính dầu (n), tăng góc mở, giảm λ (tử ngoại, electron) |
| Kính khác | Tử ngoại (thạch anh, chụp ảnh, phân ly ×2); huỳnh quang (UV kích thích, chặn UV); trường tối (tán xạ, hạt sáng trên nền tối, xem chuyển động); điện tử (λ~e~ = h/√(2meU), thấu kính từ, chân không) |
| Đo kích thước | S = 10·n/N µm (n: TVVK, N: TVTK); l = S·(N + d/100) |
| Hấp thụ ánh sáng | I = I~0~e^−μl^ = I~0~·10^−kl^ (k = 0,43μ); **I = I~0~·10^−εCl^** (dung dịch loãng) |
| Đại lượng | T = I/I~0~; **D = A = lg(I~0~/I) = εCl = 2 − lg T(%)**; tất cả phụ thuộc λ |
| Định tính – định lượng | λmax: ΔE = hc/λmax → nhận biết chất; D tại λmax → nồng độ (trực tiếp, hỗn hợp 2 chất, đồ thị chuẩn; đặc thì pha loãng) |
| Bóng tia X | Cathode W ≈ 2000 °C (6–12 V, 3–5 A); anode bia W (≈ 3350 °C); cao thế < 100 kV; chân không 10^−7^ mmHg |
| Phổ tia X | Liên tục (bức xạ hãm) + vạch đặc tính (K~α~: L→K, K~β~: M→K; hf = E~L,M~ − E~K~) |
| Hấp thụ tia X | I = I~0~e^−μx^; Compton, quang điện, tạo cặp; μ tăng theo ρ, Z; biên hấp thụ → lọc (Ni lọc K~β~ của Cu) |
| X quang | Đâm xuyên + hấp thụ khác nhau; bóng xa, vật sát phim → ảnh ít phóng đại; chất cản quang (iod) |
| CT | Detector điện tử quay 360°, máy tính tái tạo; voxel → pixel; **Hounsfield**; cửa sổ (level, width); Cormack – Hounsfield, Nobel 1979 |
| MRI | Proton H; Larmor **42,58 MHz ở 1 T**; ΔN/N ≈ μB~0~/kT cỡ 10^−6^; cộng hưởng: M~⊥~ cực đại, M~//~ = 0; T~1~ 300–2000 ms > T~2~ 30–150 ms; gradient (Lauterbur 1973); không bức xạ ion hóa; cấm kim loại, máy tạo nhịp |
| Đánh dấu phóng xạ | Đvpx = đồng vị bền về sinh học nhưng ghi đo được; 6 tiêu chuẩn tracer; thăm dò chức năng in vitro / in vivo |
| RIA / IRMA | RIA: Ag*, cạnh tranh, B/F giảm khi Ag tăng (Yalow – Berson 1960, insulin); IRMA: Ab* dư, không cạnh tranh, kháng thể đơn dòng |
| Ghi hình | Scanner, gamma camera, SPECT, PET; nhân lạnh tuyến giáp; Tc-99m MDP xạ hình xương |
| Nguồn chiếu | Kích hoạt neutron (^55^Mn(n,γ)^56^Mn); xạ trị chiếu ngoài, áp sát, nguồn hở; bảo quản thực phẩm, tiệt trùng dụng cụ, tạo giống (^60^Co, ^137^Cs) |
