---
title: Bức xạ ion hóa và cơ thể sống
thoi-gian: 80 phút
muc-tieu:
- Nêu được cấu tạo hạt nhân, hiện tượng phóng xạ, bản chất các tia α, β, γ và định luật phân rã phóng xạ (chu kỳ bán rã, hoạt độ).
- Trình bày được cơ chế tương tác của hạt tích điện, photon năng lượng cao (quang điện, Compton, tạo cặp) và neutron với vật chất; quy luật suy giảm cường độ chùm tia.
- Phân biệt được các loại liều lượng bức xạ (chiếu, hấp thụ, tương đương, hiệu dụng) và đơn vị của chúng.
- Giải thích được nguyên tắc hoạt động của một số dụng cụ ghi đo bức xạ (phim, ống nhấp nháy, buồng ion hóa, ống đếm G-M, liều kế nhiệt huỳnh quang).
- Phân biệt được cơ chế tác dụng trực tiếp và gián tiếp của bức xạ lên cơ thể sống; các mức tổn thương và các yếu tố ảnh hưởng.
- Trình bày được các nguyên tắc kiểm soát và an toàn bức xạ cho nhân viên, bệnh nhân và môi trường.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Phóng xạ là hạt nhân **tự biến đổi** và phát tia: **α** (hạt nhân He, A giảm 4, Z giảm 2), **β^−^/β^+^** (Z tăng/giảm 1, A giữ nguyên), **γ** (photon, chỉ giảm năng lượng hạt nhân).
> 2. **N = N~0~·e^−λt^**; chu kỳ bán rã **T = 0,693/λ**; hoạt độ **q = λN**, đơn vị **Bq** (1 Ci = 3,7·10^10^ Bq). Mật độ tia từ nguồn điểm giảm theo **1/R²**.
> 3. Hạt tích điện ion hóa **trực tiếp** (α có LET lớn nhất, xuyên kém nhất); photon ion hóa **gián tiếp** qua **quang điện – Compton – tạo cặp (≥ 1,02 MeV)**, suy giảm theo **I = I~0~·e^−μx^** (HVL = 0,693/μ); neutron tương tác với **hạt nhân**, làm chậm tốt nhất bằng chất giàu H.
> 4. Liều: **chiếu** (C/kg, R) → **hấp thụ** (Gy = J/kg) → **tương đương** = D × Q (Sv) → **hiệu dụng** = H × W (Sv).
> 5. Tác dụng sinh học qua cơ chế **trực tiếp** và **gián tiếp** (gốc tự do từ nước, tăng khi nhiều O~2~); tế bào phân chia mạnh, kém biệt hóa nhạy nhất (Bergonié–Tribondeau). An toàn chiếu ngoài: **thời gian – khoảng cách – che chắn**; giới hạn **20 mSv/năm** (nghề nghiệp), **1 mSv/năm** (công chúng).

**Mở đầu.** Bức xạ ion hóa là bức xạ có năng lượng đủ lớn để **bứt electron** khỏi nguyên tử, phân tử của vật chất mà nó đi qua. Đó là tia X, tia γ và các chùm hạt (α, β, proton, neutron…). Trong y học, nó vừa là công cụ (X-quang, CT, y học hạt nhân, xạ trị) vừa là mối nguy cần kiểm soát. Bài này đi từ gốc (hạt nhân, phóng xạ) → tương tác với vật chất → liều lượng và đo lường → tác dụng sinh học → an toàn bức xạ (Giáo trình tr. 292–336).

## 1. Khái niệm và nguồn gốc của bức xạ ion hóa

### 1.1. Cấu tạo hạt nhân nguyên tử

Năm 1932, Ivanenko và Heisenberg đề xuất: mọi hạt nhân đều gồm hai loại hạt (gọi chung là **nucleon**):

| Hạt | Điện tích | Khối lượng |
|---|---|---|
| **Proton** (p) | +1,6·10^−19^ C (một điện tích nguyên tố dương) | ≈ 1,007 đvklnt — chính là hạt nhân hydro nhẹ |
| **Neutron** (n) | 0 (trung hòa) | ≈ 1,009 đvklnt — lớn hơn proton một chút |

1 đvklnt (đơn vị khối lượng nguyên tử, u) = 1,66·10^−24^ g (Giáo trình tr. 292).

- **Z** = số proton = số thứ tự trong bảng tuần hoàn = điện tích hạt nhân (tính bằng điện tích nguyên tố).
- **A** = số khối = tổng số nucleon; số neutron **N = A − Z**.
- Ký hiệu: ^A^~Z~X. Ví dụ ^4^~2~He (Z = 2, A = 4), ^7^~3~Li (Z = 3, A = 7).

**Đồng vị**: các hạt nhân cùng Z nhưng khác N, nên cùng vị trí (cùng ô) trong bảng tuần hoàn. Ví dụ hydro có 3 đồng vị: ^1^H, deuteri ^2^H (D), triti ^3^H (T). Theo giáo trình, đã biết hơn 300 đồng vị tự nhiên và gần 1000 đồng vị phóng xạ nhân tạo.

**Hạt nhân là một hệ lượng tử.** Các nucleon chỉ có những mức năng lượng xác định: thấp nhất là **trạng thái cơ bản** E~0~, cao hơn là các **trạng thái kích thích** E~i~ > E~0~. Khi hạt nhân chuyển từ mức cao về mức thấp, nó phát ra một photon có năng lượng đúng bằng hiệu hai mức. Đây chính là nguồn gốc của tia γ (Giáo trình tr. 293).

### 1.2. Hiện tượng phóng xạ

#### a) Định nghĩa

Becquerel phát hiện muối urani tự phát ra những tia không nhìn thấy, có sức đâm xuyên mạnh. Các nghiên cứu ngay sau đó (Rutherford, Villard) cho thấy đặt chùm tia trong điện trường thì nó tách thành 3 thành phần: **α** (mang điện dương), **β** (mang điện âm) và **γ** (không mang điện, giống tia X). Marie và Pierre Curie chứng minh tia này phát ra **từ hạt nhân**, không phải từ lớp vỏ electron, và là tính chất chung của nhiều nguyên tố.

**Hiện tượng phóng xạ** là hiện tượng hạt nhân nguyên tử **tự biến đổi** thành hạt nhân của nguyên tố khác, hoặc từ trạng thái năng lượng cao về trạng thái thấp hơn, đồng thời phát ra các tia không nhìn thấy có năng lượng cao (tia phóng xạ, bức xạ hạt nhân). Nguyên tố có tính phóng xạ gọi là **đồng vị phóng xạ**; nếu do con người tạo ra thì gọi là **đồng vị phóng xạ nhân tạo** (Giáo trình tr. 293).

> [!cap-nhat] Mốc lịch sử
> Giáo trình ghi Becquerel quan sát hiện tượng này năm 1892. Mốc được ghi nhận rộng rãi là **năm 1896**.

**Sơ đồ phân rã** dùng các vạch ngang để biểu diễn mức năng lượng của hạt nhân trước và sau phân rã. Trên sơ đồ có ghi chu kỳ bán rã và tỉ lệ phần trăm của từng nhánh phân rã. Quy ước mũi tên:

- Mũi tên chéo **sang phải**: hạt nhân con có điện tích **lớn hơn** (β^−^).
- Mũi tên chéo **sang trái**: hạt nhân con có điện tích **nhỏ hơn** (β^+^, α).
- Mũi tên **hình sóng thẳng đứng**: điện tích không đổi (γ).

Một hạt nhân có thể trải qua một hay nhiều lần biến đổi, nối tiếp hoặc song song, với những xác suất nhất định. Mỗi lần biến đổi gọi là một **phân rã** (Giáo trình tr. 293–294).

#### b) Các dạng phân rã

| Dạng | Bản chất trong hạt nhân | Phương trình | Thay đổi | Ví dụ (giáo trình) |
|---|---|---|---|---|
| **β^−^** (negatron) | n → p + β^−^ (+ phản neutrino) | ^A^~Z~X → ^A^~Z+1~Y + β^−^ + Q | Z **+1**, A giữ nguyên | ^32^P (≈ 14,3 ngày, β^−^ thuần túy, 1,71 MeV) → ^32^S |
| **β^+^** (positron) | p → n + β^+^ + neutrino | ^A^~Z~X → ^A^~Z−1~Y + β^+^ + Q | Z **−1**, A giữ nguyên | ^13^N (10 phút, 1,20 MeV) → ^13^C |
| **α** | Phát ra hạt nhân He (2p + 2n) | ^A^~Z~X → ^A−4^~Z−2~Y + ^4^~2~He + Q | Z **−2**, A **−4** | ^226^Ra → ^222^Rn (α 4,79 MeV 93,5%; α 4,61 MeV 6,5% kèm γ 0,18 MeV) |
| **γ** | Hạt nhân kích thích về mức thấp hơn | X* → X + γ | Không đổi Z, A | ^60^Co (5,2 năm): β^−^ rồi γ 1,17 và 1,33 MeV |

Một số điểm cần nắm:

- **Electron β^−^ sinh ra ngay trong hạt nhân**, không liên quan gì tới electron quỹ đạo, dù bản chất hai loại hạt là như nhau.
- **Positron** có khối lượng bằng electron, điện tích bằng điện tích electron nhưng **dương** (e^+^).
- **Phổ năng lượng β là liên tục** (từ gần 0 đến E~max~). Để giải thích, Pauli (giáo trình viết Paoli) giả thuyết có thêm một hạt không mang điện, khối lượng nghỉ gần bằng 0 là **neutrino (ν)**, chia sẻ năng lượng với hạt β. Neutrino được ghi nhận bằng thực nghiệm vào thập niên 1950 (Giáo trình tr. 295–296).
- **Chùm α đơn năng**: các hạt α phát ra từ cùng một loại hạt nhân có năng lượng như nhau. Phân rã α chỉ xảy ra ở hạt nhân **nặng**.
- **Tia γ** là sóng điện từ bước sóng cực ngắn. Phát γ không làm đổi thành phần hạt nhân, chỉ giảm năng lượng của nó. Sau phân rã β, α… hạt nhân con thường còn ở trạng thái kích thích, nên **thường kèm theo tia γ** (Giáo trình tr. 296–297).

> [!bay]
> - β^−^: **Z tăng 1**; β^+^: **Z giảm 1**; cả hai đều **giữ nguyên A**. α: Z giảm 2, **A giảm 4**. γ: không đổi gì.
> - Giáo trình viết n → p + β^−^ + ν. Chính xác hơn, phân rã β^−^ phát ra **phản neutrino** (ν̄), còn phân rã β^+^ phát ra **neutrino** (ν). Khi thi, nhớ ý chính: có thêm hạt trung hòa mang đi một phần năng lượng, nên phổ β liên tục.
> - "Electron β" không phải electron quỹ đạo bị bứt ra.

#### c) Phân loại bức xạ ion hóa

Giáo trình chia làm 2 nhóm (Giáo trình tr. 297–298):

1. **Hạt vi mô có khối lượng nghỉ**, mang điện hoặc không:
   - **Electron**: khối lượng bằng 1/1840 hạt nhân hydro, điện tích −1. Có thể là electron quỹ đạo, electron tự do, hoặc phát ra từ hạt nhân (β^−^).
   - **Proton**: khối lượng ≈ 1 u, điện tích +1.
   - **Hạt α**: khối lượng (4 u) và điện tích (+2) lớn nhất trong các hạt kể trên.
   - **Neutron**: khối lượng ≈ 1 u, **không mang điện**, nên có cách tương tác riêng.
   - Ngoài ra còn deuteri, meson… ít dùng trong y sinh học.
2. **Photon năng lượng cao**: sóng điện từ, không có khối lượng nghỉ, không mang điện, gồm **tia γ và tia X** (tia Rơnghen). Năng lượng photon:

=> E = h·f = h·c/λ   (h: hằng số Planck 6,625·10^−34^ J·s; f: tần số, Hz; c: tốc độ ánh sáng, m/s; λ: bước sóng, m)

Photon bước sóng càng ngắn thì năng lượng càng lớn.

### 1.3. Định luật phân rã phóng xạ

Trong một nguồn, các hạt nhân không phân rã cùng lúc mà **ngẫu nhiên**. Trong khoảng thời gian dt, số hạt nhân giảm đi tỉ lệ với số hạt nhân đang có N~t~ và với dt:

=> −dN~t~ = λ·N~t~·dt   (9.1)

**λ** là **hằng số phân rã** (đơn vị s^−1^, h^−1^…). Đó là **xác suất một hạt nhân phân rã trong một đơn vị thời gian**, chỉ phụ thuộc vào bản chất hạt nhân. Tích phân với điều kiện ban đầu N = N~0~ tại t = 0:

=> N~t~ = N~0~·e^−λt^   (9.3)   (N~0~, N~t~: số hạt nhân phóng xạ lúc đầu và lúc t)

**Vì sao là hàm mũ?** Vì mỗi hạt nhân có cùng một xác suất phân rã λ, không "già đi". Số phân rã mỗi giây luôn tỉ lệ với số hạt nhân còn lại, nên lượng mất đi luôn là một **tỉ lệ cố định** của lượng đang có.

Giáo trình ví dụ: λ của ^132^I là 0,307 h^−1^, của ^131^I là 0,0036 h^−1^, nên ^132^I phân rã nhanh hơn ^131^I nhiều lần (Giáo trình tr. 298).

![Hình 1. Đường cong phân rã phóng xạ: sau mỗi chu kỳ bán rã T, số hạt nhân còn một nửa](phan-ra.svg)

#### a) Chu kỳ bán rã (thời gian bán rã) T

**Chu kỳ bán rã T** là thời gian để số hạt nhân phóng xạ của nguồn giảm còn **một nửa**. Thay N~t~ = N~0~/2 vào (9.3):

=> T = ln2/λ = 0,693/λ   (T và 1/λ cùng đơn vị thời gian)

T chỉ phụ thuộc bản chất hạt nhân, nên **đặc trưng cho từng đồng vị phóng xạ** (Giáo trình tr. 299). Sau n chu kỳ bán rã:

=> N = N~0~/2^n^   (n = t/T)

> [!vi-du] Tính nhanh với chu kỳ bán rã
> - ^131^I có λ = 0,0036 h^−1^ ⇒ T = 0,693/0,0036 ≈ 192 h ≈ **8 ngày**.
> - Một lọ ^32^P (T ≈ 14,3 ngày) có hoạt độ 80 MBq. Sau ≈ 43 ngày (3T) còn 80/2^3^ = **10 MBq**.
> - Quy tắc nhớ: sau **10 chu kỳ bán rã**, còn khoảng 1/1024 ≈ **0,1%**. Vì vậy chất thải phóng xạ đời ngắn thường được lưu giữ chờ phân rã đến mức an toàn.

#### b) Hoạt độ phóng xạ q

**Hoạt độ** (tốc độ phân rã) là số hạt nhân phân rã trong một đơn vị thời gian:

=> q = |dN~t~/dt| = λ·N~t~   (q: Bq; λ: s^−1^; N~t~: số hạt nhân)

- Hoạt độ phụ thuộc **cả** bản chất hạt nhân (λ) **lẫn** số hạt nhân đang có (N~t~), nên phải xét ở từng thời điểm. Hoạt độ cũng giảm theo cùng quy luật: q = q~0~·e^−λt^.
- Đơn vị SI: **becquerel (Bq)** = 1 phân rã/giây. Đơn vị cũ: **curie (Ci)**, 1 Ci = 3,7·10^10^ Bq; hay dùng mCi, µCi (Giáo trình tr. 299).
- **q không phải là số tia phát ra mỗi giây**: một lần phân rã có thể phát ra nhiều tia (ví dụ ^60^Co: một β và hai γ).

> [!cap-nhat] Đổi đơn vị hoạt độ
> 1 mCi = 3,7·10^7^ Bq = **37 MBq**; 1 µCi = 37 kBq. Ngược lại 1 GBq ≈ 27 mCi. Trong y học hạt nhân hiện nay, liều dược chất phóng xạ thường ghi bằng **MBq** (có thể kèm mCi).

#### c) Mật độ và cường độ bức xạ

**Mật độ bức xạ J** tại một điểm là số tia đi qua một đơn vị diện tích đặt vuông góc với phương truyền, trong một đơn vị thời gian. Với **nguồn điểm** phát n tia mỗi giây đều theo mọi hướng (bỏ qua hấp thụ của môi trường), số tia này trải đều trên mặt cầu bán kính R:

=> J = n/S = n/(4πR²)   (J: tia/(m²·s); R: khoảng cách đến nguồn, m)

Vậy **mật độ bức xạ tỉ lệ nghịch với bình phương khoảng cách** đến nguồn. Đây là cơ sở của biện pháp bảo vệ bằng khoảng cách (mục 5.3).

**Cường độ bức xạ I** là năng lượng do tia truyền qua một đơn vị diện tích vuông góc trong một đơn vị thời gian:

=> I = J·E   (E: năng lượng mỗi tia; nếu các tia khác năng lượng thì I = ΣE~i~); đơn vị W/m² (Giáo trình tr. 299–300)

## 2. Tương tác của bức xạ ion hóa với vật chất

Mọi bức xạ ion hóa đều mang năng lượng. Khi đi qua vật chất, năng lượng đó được truyền cho nguyên tử, phân tử. Hiểu cơ chế này giúp hiểu cả **tác dụng sinh học** lẫn **cách ghi đo**. Giáo trình chia hai nhóm: photon (γ, X) và hạt có khối lượng nghỉ (electron, proton, α…). Cách chia chỉ có tính tương đối vì vật chất luôn có **lưỡng tính sóng – hạt** (Giáo trình tr. 300).

**Hai cách truyền năng lượng cơ bản** (Giáo trình tr. 306):

- **Kích thích**: electron được nâng lên mức năng lượng cao hơn nhưng **không bị bứt ra**. Nguyên tử nhanh chóng trở về trạng thái đầu bằng cách phát photon, nhiệt, hoặc qua phản ứng hóa học.
- **Ion hóa**: electron bị **bứt hẳn ra**, tạo một **cặp ion** gồm ion âm (hoặc electron tự do) và ion dương.

### 2.1. Tương tác của hạt vi mô tích điện

Hạt tích điện tương tác với electron và hạt nhân của vật chất qua **lực Coulomb**:

=> F = k·q·q'/d²   (q, q': điện tích, C; d: khoảng cách, m; k = 9·10^9^ N·m²/C²)

Xác suất tương tác phụ thuộc vào mật độ, kích thước, điện tích của **hạt tới** và của **các thành phần vật chất**.

#### a) Với electron quỹ đạo — ion hóa trực tiếp

- Mỗi lần va chạm, hạt tới chỉ mất **một phần** năng lượng và lệch hướng ít nhiều. Phần năng lượng mất đi dùng để kích thích hoặc bứt electron, cho electron đó thêm động năng. Electron bứt ra lại có thể ion hóa tiếp (**ion hóa thứ cấp**).
- Trên đường đi, hạt va chạm rất nhiều lần, tạo ra **rất nhiều cặp ion**, năng lượng giảm dần. Cuối đường đi, hạt dừng lại và trở thành nguyên tử trung hòa hoặc chuyển động nhiệt. Quá trình này gọi là **ion hóa trực tiếp**.

**Độ ion hóa tuyến tính** = số cặp ion tạo ra trên **một đơn vị chiều dài** đường đi. Nó **tăng** khi điện tích và khối lượng hạt lớn, còn **tốc độ hạt nhỏ**. Vì vậy:

- Ở **cuối quỹ đạo**, hạt chậm lại nên số cặp ion trên mỗi đoạn đường **nhiều hơn** ở đầu quỹ đạo.
- Độ ion hóa tuyến tính của **α lớn hơn nhiều** so với electron.

**Quãng chạy R** (khả năng đâm xuyên):

- **Hạt α**: nặng, ít lệch hướng, quỹ đạo gần **thẳng**. Chùm α đơn năng nên các hạt có quãng chạy gần như nhau. Theo giáo trình, R của α thường **không quá 10 cm trong không khí, 0,1 mm trong nước, 0,06 mm trong nhôm** ⇒ che chắn α rất dễ (Giáo trình tr. 301).
- **Hạt β**: nhẹ, bị lệch hướng nhiều, quỹ đạo **gấp khúc**. Quãng chạy được tính bằng **bề dày cực đại** của lớp vật chất mà β xuyên qua được. Phổ β đa năng, nên người ta dùng **quãng chạy trung bình**.

**LET** (linear energy transfer — sự truyền năng lượng tuyến tính) là năng lượng mà hạt hoặc photon truyền cho vật chất trên một đơn vị chiều dài quỹ đạo:

=> LET = ΔE/Δx   (ΔE: năng lượng truyền cho vật chất; Δx: đoạn đường; đơn vị J/m hoặc keV/µm)   (9.4)

LET dùng được cho **mọi loại bức xạ**, kể cả photon, và tỉ lệ với độ ion hóa tuyến tính. LET của α > β > γ. LET ở **cuối quỹ đạo** lớn hơn ở đầu (Giáo trình tr. 302).

> [!ung-dung] Đỉnh Bragg và xạ trị bằng proton
> Hạt tích điện nặng (proton, ion carbon) truyền **nhiều năng lượng nhất ở cuối quãng chạy**, ngay trước khi dừng (đỉnh Bragg). Chỉnh năng lượng chùm hạt để đỉnh này rơi đúng vào khối u, thì mô lành phía trước nhận ít liều hơn và mô phía sau gần như không nhận liều. Đây là nguyên lý của **xạ trị proton**.

#### b) Với hạt nhân nguyên tử

- **Phản ứng hạt nhân** (rất hiếm): ví dụ ^27^~13~Al(α, n)^30^~15~P, tức hạt α bắn vào Al tạo ra neutron và ^30^P.
- **Bức xạ hãm** (Bremsstrahlung, braking radiation): khi hạt tích điện bay gần hạt nhân, lực Coulomb làm nó **đổi hướng và đổi vận tốc**, tức là có gia tốc. Hạt tích điện chuyển động có gia tốc thì phát ra **photon**. Hiện tượng này quan trọng nhất với **electron** vì electron nhẹ. Năng lượng bức xạ hãm **tăng theo Z** của vật chất; phổ của nó **liên tục**.
- **Va chạm đàn hồi**: hạt đổi hướng, giảm năng lượng, còn hạt nhân hầu như không đổi.
- **Hủy cặp**: positron sinh ra từ phân rã β^+^ không tồn tại lâu. Nó gặp electron tự do, cả hai **biến mất** và tạo thành **2 photon γ, mỗi photon ≈ 0,511 MeV, bay ngược chiều nhau** (Giáo trình tr. 302–303).

> [!bay] Che chắn tia β: dùng vật liệu Z thấp
> Vì bức xạ hãm tăng theo Z, nên **không** dùng chì để che trực tiếp nguồn β mạnh (vd ^32^P, 1,71 MeV). Electron hãm trong chì sẽ sinh ra tia X đâm xuyên hơn. Người ta dùng vật liệu **Z thấp** như thủy tinh hữu cơ (plexiglas), nhôm, chất dẻo (Giáo trình tr. 303, 332).

> [!cap-nhat] Hai chi tiết lịch sử
> - Giáo trình gán phản ứng ^27^Al(α, n)^30^P cho thí nghiệm của Rutherford năm 1919. Thực ra Rutherford năm 1919 dùng α bắn vào **nitơ** (^14^N(α, p)^17^O). Phản ứng với nhôm là thí nghiệm của **Irène và Frédéric Joliot-Curie năm 1934**, khám phá ra phóng xạ nhân tạo.
> - Đi thi chỉ cần nhớ: hạt tích điện có thể gây phản ứng hạt nhân nhưng rất hiếm.

> [!ung-dung] PET — chụp cắt lớp phát positron
> Máy PET dùng dược chất đánh dấu đồng vị phát β^+^ (vd ^18^F-FDG; giáo trình nêu ^13^N là đồng vị β^+^ đơn thuần). Mỗi positron hủy cặp tạo **2 photon 511 keV bay ngược chiều**. Vòng đầu dò ghi **trùng phùng** hai photon, nên xác định được đường thẳng chứa điểm phát. Từ đó dựng ảnh phân bố chuyển hóa của khối u, não, tim.

### 2.2. Tương tác của photon năng lượng cao (γ, X)

Khác hạt tích điện, photon truyền **hết năng lượng (hoặc phần lớn) trong một lần tương tác**, sinh ra electron, positron năng lượng lớn. Chính các hạt này ion hóa vật chất tiếp theo. Vì vậy photon **ion hóa gián tiếp**, thông qua 3 hiệu ứng (Giáo trình tr. 303).

#### a) Hiệu ứng quang điện

Photon tương tác với **electron liên kết** ở lớp trong và **trao toàn bộ năng lượng**. Photon **biến mất**, electron bị bứt ra:

=> h·f = W + E~đ~   (W: công ion hóa, năng lượng liên kết của electron; E~đ~: động năng quang electron)

- Điều kiện: h·f > W. W chỉ chiếm phần nhỏ, phần lớn năng lượng thành động năng của electron.
- Chỗ trống ở lớp trong được electron lớp ngoài nhảy vào lấp, phát ra photon thứ cấp có năng lượng xác định theo nguyên tử, gọi là **bức xạ X đặc trưng**:

=> h·f' = E~L~ − E~K~   (E~L~, E~K~: năng lượng của electron ở lớp L và lớp K)

- Xác suất quang điện **tăng theo Z** của vật chất và **giảm khi năng lượng photon tăng**. Giáo trình ghi quang điện thường gặp với photon năng lượng nhỏ hơn 1,02 MeV. Trên đồ thị xác suất (hình 9.9 của sách), quang điện chiếm ưu thế ở vùng **năng lượng thấp (dưới khoảng 0,1 MeV)** (Giáo trình tr. 303–304).

#### b) Hiệu ứng Compton (tán xạ Compton)

Photon (giáo trình ghi khoảng 0,1–2 MeV) gặp **electron tự do** hoặc liên kết yếu. Nó **trao một phần năng lượng** cho electron (electron lùi, electron Compton) rồi **tiếp tục đi theo hướng khác với năng lượng thấp hơn** (photon tán xạ):

=> h·f = h·f' + E~đ~   (hf: photon tới; hf': photon tán xạ, f' < f; E~đ~: động năng electron lùi)

Electron lùi tiếp tục ion hóa vật chất (Giáo trình tr. 304).

#### c) Hiệu ứng tạo cặp

Photon có năng lượng **≥ 1,02 MeV** đến gần hạt nhân (Z lớn), tương tác với trường hạt nhân rồi **biến mất**. Thay vào đó xuất hiện **một cặp electron – positron**:

=> h·f = E~đ~^+^ + E~đ~^−^ + 1,02 MeV   (1,02 MeV = 2 × 0,51 MeV, năng lượng tương đương khối lượng nghỉ của e^+^ và e^−^ theo E = m·c²)

Xác suất tạo cặp **tăng theo năng lượng** photon và **tỉ lệ với Z²** (Giáo trình tr. 305). Positron sinh ra sau đó sẽ hủy cặp (mục 2.1b).

| | Quang điện | Compton | Tạo cặp |
|---|---|---|---|
| Đối tượng tương tác | Electron liên kết (lớp trong) | Electron tự do / liên kết yếu | Trường của hạt nhân |
| Số phận photon | Biến mất | Còn, đổi hướng, năng lượng giảm | Biến mất |
| Sản phẩm | Quang electron + tia X đặc trưng | Electron lùi + photon tán xạ | Cặp e^−^ + e^+^ (→ hủy cặp: 2γ 0,511 MeV) |
| Vùng năng lượng ưu thế (hình 9.9) | Thấp (< 0,1 MeV) | Trung bình (≈ 0,1 – 10 MeV) | Cao; ngưỡng **1,02 MeV**, ưu thế khi > 10 MeV |
| Phụ thuộc Z | Tăng mạnh theo Z | Ít phụ thuộc Z (theo mật độ electron) | ∝ Z² |

> [!ung-dung] Vì sao xương "trắng" trên phim X-quang?
> Chụp X-quang chẩn đoán dùng photon năng lượng thấp (vài chục keV), vùng mà **quang điện** chiếm ưu thế. Quang điện tăng rất mạnh theo Z, nên xương (giàu Ca, Z = 20) hấp thụ tia X nhiều hơn hẳn mô mềm (chủ yếu H, C, O). Đó là nguồn gốc độ tương phản. **Chì** (Z = 82) và **barit** (BaSO~4~, Ba có Z = 56) hấp thụ mạnh, nên dùng làm áo chì và thuốc cản quang đường tiêu hóa. Ở xạ trị bằng photon MeV, **Compton** chiếm ưu thế, nên hấp thụ ít phụ thuộc Z: xương và mô mềm nhận liều gần như nhau.

### 2.3. Tương tác của neutron với vật chất

**Nguồn neutron** (neutron do Chadwick phát hiện năm 1932; ký hiệu ^1^~0~n):

- **Lò phản ứng phân hạch**: ^235^U (hoặc ^239^Pu) bắt một neutron, vỡ thành hai mảnh và giải phóng 2–3 neutron mới cùng năng lượng lớn. Ví dụ của giáo trình: ^235^~92~U + n → ^90^~38~Sr + ^144^~54~Xe + 2n + γ + 200 MeV. Neutron mới lại gây phân hạch tiếp, tạo ra **phản ứng dây chuyền**.
- **Nguồn α – beryli**: ^9^Be(α, n)^12^C, với α phát ra từ ^241^Am hoặc ^226^Ra. Phổ neutron không đơn năng, có đỉnh ở khoảng 3 và 6 MeV, chủ yếu là **neutron nhanh**.
- **Nguồn γ – neutron**: (γ, n), ví dụ hỗn hợp antimon – beryli (γ của ^124^Sb bắn phá Be). Neutron tạo ra gần như **đơn năng** (Giáo trình tr. 306).

**Tương tác:** neutron **không mang điện**, nên không tương tác với lớp vỏ electron và **không trực tiếp ion hóa**. Nó chỉ tương tác khi **va chạm với hạt nhân** (Giáo trình tr. 307–308):

| Quá trình | Diễn biến | Ghi chú |
|---|---|---|
| **Tán xạ đàn hồi** | Như hai viên bi-a va nhau; neutron mất dần năng lượng, truyền cho hạt nhân bia | Hạt nhân **nhẹ** làm chậm neutron tốt nhất ⇒ dùng vật liệu giàu **hydro** (paraffin, nước, bê tông) |
| **Tán xạ không đàn hồi** | Neutron truyền một phần năng lượng, kích thích hạt nhân bia; hạt nhân này phát **γ** khi trở về cơ bản | Chủ yếu với hạt nhân **nặng** |
| **Bắt neutron** | n + ^A^X → ^A+1^X, rồi phát hạt hoặc photon | Vd ^58^Fe(n, γ)^59^Fe phát γ đâm xuyên ⇒ che chắn phải tính cả γ thứ cấp |

**Hạt nhân giật lùi** (vd proton trong mô giàu nước) và các sản phẩm phản ứng mới là những hạt **ion hóa**. Vì vậy neutron gây hiệu ứng sinh học cao. Che chắn neutron **phức tạp** vì dải năng lượng rộng, đâm xuyên lớn: cần chất giàu H để làm chậm, chất bắt neutron, và chất Z cao để chặn γ thứ cấp.

> [!cap-nhat] Phản ứng bắt neutron quan trọng: boron-10, không phải "Bery-10"
> Giáo trình viết phản ứng ^10^Be(n, α)^7^Li. Đúng ra đây là **^10^B(n, α)^7^Li** (boron-10, Z = 5): bắt neutron rồi phát α. Vì α bị hấp thụ ngay, nên **boron** (và cadimi) được đưa vào vật liệu che chắn neutron. Phản ứng này còn là cơ sở của **liệu pháp bắt neutron bằng boron (BNCT)** đang được nghiên cứu cho một số ung thư.

## 3. Hấp thụ năng lượng bức xạ — Liều lượng bức xạ

### 3.1. Sự suy giảm cường độ chùm tia

Khi đi qua vật chất, năng lượng, mật độ và cường độ chùm tia giảm dần. Quy luật giảm khác nhau tùy loại tia.

**Tia α** — quỹ đạo thẳng, quãng chạy R như nhau:

=> J = J~0~ nếu x < R;   J = 0 nếu x ≥ R   (J~0~, J: mật độ chùm tia trước và sau lớp vật chất dày x)   (9.5)

Nghĩa là trước quãng chạy R, số hạt α gần như không đổi; quá R thì **tất cả** dừng lại (Giáo trình tr. 308).

**Tia γ, X (và gần đúng cho β)** — tương tác theo xác suất, nên suy giảm theo **hàm mũ**:

=> I = I~0~·exp(−μ~x~·x)   (I~0~, I: cường độ trước/sau bản; x: bề dày, cm; μ~x~: hệ số suy giảm tuyến tính, cm^−1^)   (9.6)

Vật liệu càng đặc thì giảm càng mạnh. Để so sánh các vật liệu, người ta dùng **bề dày khối** d = x·ρ (g/cm²) và **hệ số suy giảm khối** μ = μ~x~/ρ (cm²/g):

=> I = I~0~·e^−μ·d^   (9.7)

Với γ và X, hệ số hấp thụ khối toàn phần là tổng ba thành phần ứng với ba hiệu ứng:

=> μ = τ + σ + χ   (τ: quang điện; σ: tán xạ Compton; χ: tạo cặp)

Với β, sự suy giảm do hạt bị lệch hướng và dừng lại; μ phụ thuộc năng lượng cực đại của chùm β (Giáo trình tr. 309).

**Bề dày hấp thụ một nửa (HVL, half value layer), d~1/2~**, là bề dày lớp vật chất làm cường độ chùm tia giảm **còn một nửa**:

=> d~1/2~ = 0,693/μ   (9.8)

- Theo hàm mũ thì **không bao giờ chặn được hoàn toàn** chùm γ: 1 HVL còn 1/2, 2 HVL còn 1/4, 3 HVL còn 1/8… Chỉ có thể giảm đến mức **chấp nhận được**.
- Chùm β thì thực tế chặn hết được, vì khả năng tương tác của nó lớn, đâm xuyên kém (Giáo trình tr. 310).

> [!bay]
> - α giảm kiểu **"tất cả hoặc không"** theo quãng chạy; γ, X giảm theo **hàm mũ**, không về 0.
> - Công thức HVL **giống hệt** công thức chu kỳ bán rã (0,693/λ), chỉ thay thời gian bằng bề dày. Đừng nhầm λ (hằng số phân rã) với μ (hệ số suy giảm).

![Hình 2. Khả năng đâm xuyên của α, β, γ: α dừng ở tờ giấy, β dừng trong vài mm nhôm, γ chỉ yếu đi qua chì](do-xuyen.svg)

### 3.2. Liều lượng bức xạ

**Liều lượng bức xạ** là đại lượng đánh giá tác dụng của chùm tia lên vật chất nói chung và cơ thể sống nói riêng. Có 4 loại (Giáo trình tr. 310–312):

#### a) Liều chiếu (liều ion hóa, liều biểu kiến)

Chỉ dùng cho **tia X và γ trong không khí**: tổng điện tích các ion cùng dấu tạo ra trong một đơn vị khối lượng không khí (ở điều kiện tiêu chuẩn).

=> D~c~ = ΔQ/Δm   (ΔQ: điện tích, C; Δm: khối lượng không khí, kg; đơn vị **C/kg**)   (9.9)

Đơn vị cũ: **Rơnghen (R)**:

=> 1 R = 2,58·10^−4^ C/kg   hay   1 C/kg ≈ 3876 R

1 R là liều chiếu tạo ra trong 1 cm³ không khí (1,293 mg) một lượng ion có tổng điện tích một dấu bằng một đơn vị điện tích (CGS), tức khoảng 2,09·10^9^ cặp ion.

#### b) Liều hấp thụ D

Năng lượng bức xạ mà vật hấp thụ trên một đơn vị khối lượng. Áp dụng cho **mọi loại bức xạ, mọi vật chất**:

=> D = ΔE/Δm   (ΔE: năng lượng hấp thụ, J; Δm: khối lượng, kg; đơn vị **Gray: 1 Gy = 1 J/kg**)   (9.10)

Đơn vị cũ: **rad**; 1 rad = 0,01 Gy, 1 Gy = 100 rad.

#### c) Liều tương đương H

Cùng một liều hấp thụ nhưng các loại bức xạ khác nhau gây tổn thương khác nhau. Do đó người ta nhân thêm **hệ số chất lượng Q** của tia:

=> H = D × Q   (D: Gy; Q: không thứ nguyên; đơn vị H: **Sievert (Sv)**, mSv, µSv; đơn vị cũ **rem**)

| Loại bức xạ (giáo trình) | Q |
|---|---|
| Tia X, γ, electron | 1 |
| Neutron nhiệt | 5 |
| Proton và neutron nhanh | 20 |
| Hạt α | 20 |

#### d) Liều hiệu dụng E

Cùng một liều tương đương, các mô khác nhau chịu hậu quả khác nhau, vì độ nhạy cảm phóng xạ khác nhau. Do đó người ta nhân thêm **trọng số mô W**:

=> E = H × W   (đơn vị vẫn là **Sv**; khi chiếu nhiều mô: E = Σ H~T~·W~T~)

Giáo trình nêu một vài giá trị W: "thận" 0,20; phổi 0,12; gan 0,05; da 0,01.

> [!bay] Phân biệt 4 loại liều
> | Liều | Định nghĩa | Đơn vị SI | Đơn vị cũ | Dùng cho |
> |---|---|---|---|---|
> | Chiếu | Điện tích ion/khối lượng **không khí** | C/kg | R | **Chỉ X, γ** |
> | Hấp thụ | Năng lượng/khối lượng | **Gy** (J/kg) | rad | Mọi tia, mọi vật |
> | Tương đương | D × Q (loại tia) | **Sv** | rem | Mô sống |
> | Hiệu dụng | H × W (loại mô) | **Sv** | rem | Toàn cơ thể, đánh giá nguy cơ |
>
> - **Gy là đại lượng vật lý** (năng lượng); **Sv đã tính đến hiệu quả sinh học**. Với X, γ (Q = 1) thì 1 Gy tương ứng 1 Sv; với α thì 1 Gy tương ứng 20 Sv.
> - Liều tương đương và liều hiệu dụng **cùng đơn vị Sv** nhưng khác ý nghĩa.

> [!cap-nhat] Quy đổi và trọng số theo ICRP 103 (2007)
> - Quy đổi: **1 rad = 0,01 Gy = 10 mGy**; **1 rem = 0,01 Sv = 10 mSv**; **1 Ci = 3,7·10^10^ Bq**; **1 R = 2,58·10^−4^ C/kg**. Với tia X, γ trong mô mềm, 1 R ứng với liều hấp thụ khoảng 0,01 Gy (gần đúng). Ngày nay liều chiếu ít dùng, thay bằng **kerma không khí** (Gy).
> - Hệ số Q nay gọi là **trọng số bức xạ w~R~**. Theo ICRP 103: photon, electron = 1; **proton = 2** (giáo trình ghi 20); α = 20; neutron là một **hàm liên tục theo năng lượng** (khoảng 2,5–20), không còn chia bậc.
> - Trọng số mô w~T~ theo ICRP 103: tủy xương đỏ, đại tràng, phổi, dạ dày, vú **0,12**; tuyến sinh dục **0,08**; bàng quang, gan, thực quản, tuyến giáp **0,04**; da, bề mặt xương **0,01**… Tổng các w~T~ bằng 1. Giá trị "0,20" giáo trình ghi cho "thận" thực ra là trọng số của **tuyến sinh dục** trong khuyến cáo cũ ICRP 60 (1990).
> - Đi thi: trả lời theo bảng Q và W của giáo trình.

> [!ung-dung] Liều hiệu dụng của một số thăm dò (giá trị gần đúng)
> | Nguồn | Liều hiệu dụng |
> |---|---|
> | Phông bức xạ tự nhiên (trung bình thế giới) | ≈ 2,4 mSv/năm |
> | X-quang ngực thẳng | ≈ 0,02–0,1 mSv |
> | CT sọ não | ≈ 2 mSv |
> | CT ổ bụng | ≈ 8–10 mSv |
>
> Liều của một lần CT có thể gấp hàng trăm lần một phim X-quang ngực. Vì vậy cần **chỉ định đúng**, nhất là ở trẻ em và phụ nữ có thai.

### 3.3. Nguyên lý và thiết bị ghi đo bức xạ ion hóa

Cơ sở ghi đo là các **hiệu ứng vật lý** (kích thích, ion hóa) hoặc **hiệu ứng hóa học** mà bức xạ gây ra trong vật chất hấp thụ. Khi khảo sát một hệ ghi đo, cần chú ý 3 yếu tố (Giáo trình tr. 312):

1. Dạng vật chất hấp thụ: rắn, lỏng hay khí.
2. Hiệu ứng vật lý được khai thác: kích thích hay ion hóa.
3. Cách thể hiện kết quả: nếu là xung điện thì biên độ xung **cố định** hay **tỉ lệ** với năng lượng hấp thụ.

#### a) Phim ảnh và nhũ tương (biến đổi hóa học)

- Bức xạ bứt electron trong tinh thể **muối halogen bạc**. Electron tập trung tại một điểm, hút ion Ag^+^ đến và biến nó thành **nguyên tử Ag**. Khi tráng (hiện ảnh) bằng chất khử mạnh như hydroquinol, metol, chỉ những tinh thể có sẵn nguyên tử Ag mới bị khử thành bạc đen. Độ đen phụ thuộc số nguyên tử Ag, tức phụ thuộc mật độ chùm tia; đo bằng dụng cụ đo mật độ quang học.
- **Phim ảnh**: lớp nhũ tương dày khoảng 10 µm, tinh thể 0,5–3 µm; dùng cho tia X, γ.
- **Nhũ tương hạt nhân**: lớp 5–10 µm, tinh thể 0,1–0,4 µm, mật độ cao; hiệu suất cao với α, β, γ mềm.
- Phương pháp này kém nhạy, nhưng vẫn dùng làm **liều kế phim cá nhân** và trong **kỹ thuật phóng xạ tự chụp** (autoradiography) (Giáo trình tr. 312–313).

#### b) Ống đếm nhấp nháy (phát quang)

- Một số tinh thể hoặc dung dịch **phát quang** khi hấp thụ bức xạ: ZnS (với X, γ); anthracen (với β); dung dịch **PPO + POPOP** trong toluen/dioxan (với β mềm của ^3^H, ^14^C, dùng trong kỹ thuật **nhấp nháy lỏng**); **NaI(Tl)**, KI(Tl), CsI(Tl), LiI.
- Quan trọng nhất là tinh thể **NaI hoạt hóa bằng Tali**, dùng ghi γ.
- Số photon phát quang **tỉ lệ với năng lượng** bức xạ đã hấp thụ: trung bình cứ **30–50 eV** cho 1 photon. Vì vậy một tia γ 0,5 MeV tạo ra khoảng 10^4^ photon.
- Ánh sáng này rất yếu, nên phải khuếch đại bằng **ống nhân quang**. Photon đập vào **photocathod** làm bật electron; electron được tăng tốc qua **10–14 điện cực** (dynod), mỗi lần nhân thêm, tổng hệ số khuếch đại 10^6^–10^9^ lần.
- Hiệu suất đếm: **20–30% với γ**, gần **100% với hạt vi mô**. Thời gian chết rất ngắn (vài µs).
- Vì biên độ xung tỉ lệ với năng lượng, ống nhấp nháy còn đo được **phổ năng lượng** (cần thêm máy phân tích biên độ). Đây là cơ sở của các máy đo trong **y học hạt nhân** như máy đo độ tập trung iod ở tuyến giáp, máy đếm toàn thân, gamma camera (Giáo trình tr. 313–314).

#### c) Ghi đo dựa vào sự ion hóa chất khí

Chất khí trở nên dẫn điện khi bị bức xạ ion hóa. Đặt hiệu điện thế V giữa hai điện cực trong buồng khí, cường độ dòng (hay số xung) thay đổi theo V qua **4 vùng** (hình 9.12 của sách):

| Vùng | Hiện tượng | Thiết bị |
|---|---|---|
| I, II | Các ion sinh ra được thu hết, chưa có ion hóa thứ cấp (vùng II là vùng bão hòa) | **Buồng ion hóa** |
| III | Ion hóa thứ cấp; biên độ xung **tỉ lệ** với năng lượng tia | **Ống đếm tỉ lệ** |
| IV | Thác ion hóa lan khắp ống; xung **lớn như nhau**, không phụ thuộc năng lượng tia | **Ống đếm Geiger–Müller (G-M)** |

**Buồng ion hóa**: buồng chứa không khí khô ở áp suất thường, nối với nguồn pin, acquy hoặc điện lưới, làm việc ở vùng II. Kết quả đọc bằng tĩnh điện kế, thường theo đơn vị R/h hoặc mR/s. Có nhiều dạng: loại lớn ở phòng thí nghiệm, loại xách tay, loại **bút đo liều cá nhân**. Một dạng quan trọng là **buồng chuẩn liều** (dose calibrator), dùng đo hoạt độ liều dược chất phóng xạ trước khi tiêm cho bệnh nhân (Giáo trình tr. 314–315).

**Ống đếm G-M**:

- **Cấu tạo**: cực dương là sợi **vonfram** mảnh (≈ 0,1 mm) ở trục ống; cực âm là lá đồng cuộn hoặc ống thép không gỉ. Đáy ống là **cửa sổ mica mỏng** để β yếu lọt vào. Ống chứa khí trơ (Ar) áp suất thấp, cộng thêm **khí dập tắt**: khí hữu cơ (hơi rượu etylic, isopentan…) hoặc halogen (Br, Cl).
- Khí dập tắt **hấp thụ bớt năng lượng**, làm tắt thác ion hóa, tạo ra các **xung ngắn**.
- **Thời gian chết**: sau mỗi lần phóng điện, các ion dương nặng di chuyển chậm, tạo thành "màn chắn" quanh cực dương làm yếu điện trường. Trong lúc đó, tia mới lọt vào không được ghi nhận. Thời gian chết khoảng **100–300 µs**.
- **Hiệu suất đếm**: gần **100% với β**, nhưng chỉ khoảng **1% với γ**, vì γ rất ít khi ion hóa trực tiếp phân tử khí (Giáo trình tr. 315–316).

#### d) Liều kế nhiệt huỳnh quang (TLD)

Một số tinh thể như **LiF**, **CaSO~4~(Mn)**, **CaF~2~(Mn)**, liti borat có các khuyết tật trong mạng tinh thể. Bức xạ làm electron bị "bẫy" lại tại những vị trí này. Khi **nung nóng**, electron thoát ra và tinh thể phát quang. Cường độ ánh sáng phát ra **tỉ lệ với liều hấp thụ**. TLD nhỏ, bền, đo được khoảng 0,1 mSv – 100 mSv, nên rất hay dùng làm **liều kế cá nhân** (Giáo trình tr. 317, 334).

> [!bay]
> - **Buồng ion hóa**: vùng II, chưa có khuếch đại khí, dùng **đo liều**. **G-M**: vùng IV, xung đều nhau, nên **không phân biệt được năng lượng**, chỉ **đếm**; nhạy với β, kém với γ.
> - Muốn đo **phổ năng lượng γ** thì dùng ống **nhấp nháy NaI(Tl)** (hoặc ống đếm tỉ lệ), không dùng G-M.

## 4. Tác dụng của bức xạ ion hóa lên vật chất sống

Quá trình đi từ hấp thụ năng lượng đến hậu quả sinh học trải qua nhiều thang thời gian (sơ đồ của giáo trình, tr. 318):

| Thời gian | Giai đoạn |
|---|---|
| ≈ 10^−16^ s | Hấp thụ năng lượng → kích thích, ion hóa (giai đoạn vật lý) |
| ≈ 10^−5^ s | Biến đổi phân tử, trực tiếp hoặc qua gốc tự do (giai đoạn hóa lý – hóa học) |
| Giây → giờ | Tổn thương sinh lý, hóa sinh |
| Phút → giờ | Tổn thương cấu trúc vi mô |
| Giờ → năm | Tổn thương cấu trúc vĩ mô, đột biến di truyền, tế bào chết, cơ thể chết |

### 4.1. Cơ chế tác dụng

#### a) Cơ chế trực tiếp

Năng lượng bức xạ truyền **thẳng** cho các **đại phân tử hữu cơ** (protein, enzym, acid nucleic), gây kích thích hoặc ion hóa chính chúng. Hai giai đoạn này diễn ra rất nhanh (phần nghìn mili giây).

- **Kích thích**: AB → (AB)*. Phân tử kích thích có thể trả lại năng lượng (AB + hν), phản ứng với phân tử khác, hoặc **phân ly** thành các mảnh kích thích A*, B*.
- **Ion hóa**: AB → (AB)^+^ + e, hoặc AB + e → (AB)^−^. Các ion này phân ly thành A^+^, B^−^… và các mảnh nhỏ; các sản phẩm này gây phản ứng hóa học mới (Giáo trình tr. 317–319).

**Thuyết trực tiếp chưa đủ.** Giáo trình nêu hai lý do:

1. Liều chiếu toàn thân 500–1000 R đã có thể gây tử vong ở người. Theo tính toán, mỗi tế bào (≈ 500 µm³, ≈ 10^12^ phân tử hữu cơ) khi hấp thụ 1 rad chỉ có khoảng **1000 phân tử** bị tổn thương trực tiếp, tức tỉ lệ 10^3^/10^12^ = 1/10^9^. Con số này **quá nhỏ** so với hậu quả thực tế.
2. Tác dụng sinh học còn phụ thuộc vào **độ linh động của phân tử, hàm lượng nước, nồng độ oxy** của mô (Giáo trình tr. 319).

#### b) Cơ chế gián tiếp — qua phân tử nước

Nước chiếm **70–90%** tổ chức sống. Bức xạ tác dụng lên nước sinh ra các sản phẩm rất hoạt động; chính chúng tấn công các phân tử hữu cơ. Lee là người đầu tiên chứng minh cơ chế này bằng thực nghiệm (Giáo trình tr. 319–320).

**Phóng xạ phân giải nước:**

=> H~2~O → H~2~O* → H• + OH•   (kích thích)

=> H~2~O → (H~2~O)^+^ + e → H^+^ + OH•   (ion hóa)

=> e + H~2~O → (H~2~O)^−^ → OH^−^ + H•   (bắt electron)

**Các gốc tự do kết hợp** tạo sản phẩm mới, trong đó **H~2~O~2~** là chất oxy hóa rất mạnh:

=> H• + H• → H~2~;   OH• + OH• → H~2~O~2~

**Khi có nhiều O~2~**, lượng peroxyd sinh ra **càng nhiều**:

=> H• + O~2~ → HO~2~•;   HO~2~• + HO~2~• → H~2~O~2~ + O~2~

**Tấn công phân tử hữu cơ RH và phản ứng dây chuyền:**

=> RH + OH• → R• + H~2~O;   R• + O~2~ → RO~2~•;   RO~2~• + RH → ROOH + R•

Gốc R• mới sinh lại tiếp tục phản ứng. Vì vậy một sự kiện ion hóa có thể làm tổn thương **rất nhiều** phân tử.

Thuyết gián tiếp giải thích được tác dụng **lan xa**, tác dụng **kéo dài** sau khi ngừng chiếu, và ảnh hưởng của **nước và oxy**. Hai cơ chế trực tiếp và gián tiếp **bổ sung cho nhau**; tùy điều kiện mà cơ chế này hay cơ chế kia trội hơn (Giáo trình tr. 321).

> [!bay]
> - Trực tiếp: bức xạ "bắn" **thẳng** vào đại phân tử. Gián tiếp: bức xạ tác dụng lên **nước**, sinh **gốc tự do** (OH•, H•, HO~2~•) và **H~2~O~2~**, rồi các chất này tấn công đại phân tử.
> - **Oxy làm tăng** tổn thương vì tạo thêm HO~2~•, H~2~O~2~ và gốc peroxyd hữu cơ.
> - Bức xạ LET thấp (X, γ) gây tổn thương **chủ yếu qua cơ chế gián tiếp**; bức xạ LET cao (α, neutron) ion hóa dày đặc nên cơ chế trực tiếp trội hơn.

> [!yhct] Chiếu xạ khử khuẩn dược liệu và "chất chống phóng xạ" từ thực vật
> - Tia γ của nguồn ^60^Co hoặc chùm electron được dùng để **khử khuẩn, diệt côn trùng** trong thực phẩm, gia vị và một số dược liệu khô. Cơ chế giống mục 4.1: bức xạ làm hỏng DNA (ADN) của vi sinh vật. Năng lượng γ của ^60^Co (1,17 và 1,33 MeV) quá thấp để gây phản ứng hạt nhân, nên **dược liệu không trở thành chất phóng xạ**. Tuy vậy, chiếu xạ có thể làm biến đổi một phần hoạt chất (tinh dầu, vitamin…). Vì vậy liều chiếu và loại dược liệu được phép chiếu xạ phải theo quy định.
> - Giáo trình nhắc đến các **chất bảo vệ phóng xạ** có nguồn gốc thực vật (mục 4.3.4). Nhiều dược liệu giàu chất chống oxy hóa (polyphenol, flavonoid…) được nghiên cứu về khả năng "dọn" gốc tự do, nhưng bằng chứng hiện **chủ yếu là thực nghiệm** trên động vật hoặc tế bào. Chúng **không thay thế** các biện pháp an toàn bức xạ.

### 4.2. Các tổn thương do bức xạ ion hóa

#### a) Mức phân tử

Tổn thương ở đại phân tử hữu cơ là cơ sở đầu tiên của tổn thương tế bào, mô và toàn cơ thể. Biểu hiện (Giáo trình tr. 321):

- **Giảm hàm lượng** một số chất (enzym, protein đặc hiệu, acid nucleic…), do tổng hợp bị ức chế hoặc bị phân hủy. Các nhóm chức như –NH~2~, –COOH, –SH bị tách ra.
- **Giảm hoặc mất hoạt tính sinh học**, vì cấu trúc phân tử quyết định chức năng.
- **Tăng hoặc xuất hiện chất lạ, độc** như H~2~O~2~, histamin…
- **Tổn thương DNA** là quan trọng nhất: base purin, pyrimidin, nhóm –NH~2~, gốc đường bị tách hoặc phá hủy; các mảnh nối lại sai lạc, tạo DNA bất thường. Điều này ảnh hưởng trực tiếp đến hoạt động di truyền của tế bào.

#### b) Mức tế bào — độ nhạy cảm phóng xạ

**Tổn thương chức năng** (Giáo trình tr. 322):

- Oxy-phosphoryl hóa ở ty lạp thể giảm ngay khoảng 1 giờ sau chiếu. Hô hấp, chuyển hóa, miễn dịch của tế bào đều giảm.
- Chức năng dễ bị ảnh hưởng nhất là **phân chia để sinh sản**, do tổn thương DNA gây **đột biến gen**. Theo giáo trình, với liều 1 R, xác suất đột biến gen là 10^−8^; liều **50–100 R làm tỉ lệ đột biến tăng gấp đôi** tỉ lệ tự nhiên. Đột biến ở **tế bào sinh dục** gây hậu quả cho **các thế hệ sau**.

**Tổn thương cấu trúc** (Giáo trình tr. 322–323):

- **Màng tế bào**: tổn thương **sớm và tinh vi**. Tính thấm chọn lọc và các gradient bị rối loạn; liều lớn làm thủng, rách màng.
- **Bào tương**: quánh lại như khi bị đun nóng. Liều lớn phá hủy ty lạp thể, lysosom, ribosom, giải phóng enzym gây hại. Tổn thương nhẹ ở bào tương **dễ hồi phục hơn** ở nhân và màng.
- **Nhân**: **nhạy cảm nhất**. Nhân trương, nứt, vỡ thành mảnh. **Nhiễm sắc thể** bị đứt đoạn, gãy, gắn sai (NST hai tâm, NST khổng lồ). Sai lạc NST là một **chỉ số theo dõi** tác dụng của bức xạ.

**Số phận tế bào bị chiếu**: chết do tổn thương nặng; không chết nhưng không phân chia được nữa; không phân chia nhưng NST vẫn nhân đôi, thành tế bào khổng lồ; hoặc vẫn phân chia nhưng rối loạn di truyền. "Cái chết" của tế bào có thể không xảy ra ngay mà ở **các thế hệ sau** khi phân chia.

**Đường cong sống sót và thuyết bia.** Biểu diễn tỉ lệ tế bào sống sót N theo liều D. Với hệ đơn bào (vi sinh vật), đồ thị có dạng đơn giản nhất (hình 9.15 của sách):

- Nếu mọi tia đều "trúng đích" thì số tế bào sống giảm **tuyến tính** và hết ở liều D~0~ (đường lý thuyết A). Thực tế thu được **đường cong** B: có những tia trúng vào vùng không quan trọng, hoặc trúng vào tế bào đã chết rồi.
- **Thuyết bia** (thuyết tâm nhạy) của Lacassagne và Holweck: mỗi tế bào có một vùng rất nhỏ (≈ 1 µm³, có lẽ trong nhân) tập trung các cấu trúc quan trọng, gọi là **tâm nhạy**. Tâm nhạy hấp thụ đủ năng lượng thì tế bào chết; hấp thụ ít hơn thì tổn thương nhẹ, ảnh hưởng chủ yếu đến khả năng sinh sản. Tia trúng ngoài tâm nhạy thì tổn thương tùy mức độ liên quan với tâm nhạy. Tế bào đơn bội có 1 tâm nhạy; tế bào lưỡng bội, đa bội có 2, 3… tâm nhạy nên đồ thị phức tạp hơn.
- **D~0~ = D~37~**: tại liều D~0~ (lý thuyết), trên đường thực nghiệm vẫn còn khoảng **37%** (= 1/e) tế bào sống. D~37~ càng lớn thì tế bào càng **khó** bị diệt, tức **độ nhạy cảm phóng xạ càng thấp**. Độ nhạy cảm và sức đề kháng phóng xạ là **nghịch đảo** của nhau (Giáo trình tr. 323–324).

**Định luật Bergonié – Tribondeau** (1906): tia X tác dụng càng mạnh lên những tế bào:

1. có khả năng **phân chia càng mạnh**;
2. càng **xa giai đoạn cuối** của quá trình phân bào;
3. có cấu trúc và chức năng **càng chưa biệt hóa**.

Vì vậy mô **ung thư** (sinh sản mạnh, nhiều tế bào non, cấu trúc bất thường) nhạy cảm phóng xạ hơn mô lành. Đây là **cơ sở của xạ trị** (Giáo trình tr. 325).

| Độ nhạy cảm phóng xạ | Mô (theo giáo trình) |
|---|---|
| **Cao nhất** | Mô tạo máu trong **tủy xương**, mô **sinh dục** |
| Cao | **Niêm mạc**, **da**, **thủy tinh thể** |
| Trung bình | Mô liên kết (sụn xương, mạch máu) |
| Thấp hơn | Tế bào đã biệt hóa của phủ tạng, tuyến nội tiết |
| **Thấp nhất** | **Cơ, xương, thần kinh** |

> [!vi-du] Ứng dụng định luật Bergonié – Tribondeau
> - **Lymphoma, u tinh hoàn (seminoma)** rất nhạy với xạ trị; mô thần kinh trưởng thành thì ít nhạy.
> - **Xạ trị chia liều**: tổng liều được chia thành nhiều buổi nhỏ (vd 2 Gy/buổi). Mô lành có thời gian sửa chữa giữa các buổi, còn tế bào u (sửa chữa kém, phân chia liên tục) bị tích lũy tổn thương (xem mục 4.3).
> - Bào thai, trẻ em có nhiều tế bào đang phân chia, nên **nhạy hơn người lớn**.

#### c) Tổn thương ở một số mô

- **Máu và tủy xương**: biểu hiện **sớm nhất** là thay đổi hình ảnh tế bào tạo máu trong tủy xương và số lượng tế bào máu ngoại vi.
  - Ở **máu ngoại vi**, giảm theo thứ tự: **bạch cầu** (trước hết là dòng **lympho**) → … → **hồng cầu** sau cùng.
  - Ở **tủy xương**, suy giảm xảy ra trước hết ở **dòng hồng cầu** rồi mới đến dòng bạch cầu.
  - Hậu quả: suy tủy, thiếu máu, giảm sức đề kháng, dễ xuất huyết.
- **Bào thai**: loại tổn thương phụ thuộc **tuổi thai** khi bị chiếu và liều: thai chết, quái thai, dị tật bẩm sinh, chậm phát triển.
- **Mô sinh dục**: theo giáo trình, liều **5–6 Gy** có thể gây **vô sinh** ở nam; LD~50~ với nang buồng trứng khoảng 0,1 Gy (ước tính hiện nay cho noãn người là LD~50~ < 2 Gy). Ngoài vô sinh còn gây rối loạn hormon, rối loạn kinh nguyệt.
- **Da và niêm mạc**: tổn thương xuất hiện sau thời kỳ tiềm tàng **2–3 tuần**. Hay gặp nhất là **viêm đỏ**; tiếp theo là viêm da khô (teo, bóng, khô vì ít mồ hôi, tăng sắc tố) và **viêm ướt** (loét, nhiễm trùng, hoại tử sâu). Niêm mạc dạ dày, ruột bị tổn thương làm rối loạn bài tiết dịch tiêu hóa; liều lớn gây loét cần điều trị ngoại khoa.
- **Mắt**: viêm loét giác mạc, **đục thủy tinh thể**, có thể dẫn đến mù lòa (Giáo trình tr. 325–326).

> [!bay] Thứ tự giảm tế bào máu
> Trong máu ngoại vi, **bạch cầu lympho giảm sớm nhất**, hồng cầu giảm muộn nhất (hồng cầu trưởng thành sống ≈ 120 ngày và không còn nhân). Đếm **lympho** vài ngày đầu sau chiếu là chỉ số sớm giúp ước lượng liều. Ở trong tủy xương thì giáo trình ghi dòng **hồng cầu** suy giảm trước.

#### d) Tổn thương toàn thân — bệnh phóng xạ

Độ nhạy cảm phóng xạ tăng theo mức độ phức tạp của sinh vật: đơn bào thấp nhất, động vật cao hơn thực vật, **người nhạy cảm nhất**. Trong cùng một loài, lúc **còn non, sinh đẻ, bị bệnh** thì nhạy hơn lúc trưởng thành, khỏe mạnh (Giáo trình tr. 326).

**Bệnh phóng xạ** do chiếu ngoài, nhiễm xạ trong, hoặc cả hai. Có hai thể:

- **Cấp tính**: chiếu toàn thân một liều lớn, hoặc nhiều liều không lớn liên tiếp trong thời gian ngắn. Gặp trong **tai nạn hạt nhân** hoặc **điều trị quá liều**.
- **Mạn tính**: chiếu liều nhỏ trong thời gian dài. Gặp ở người làm nghề tiếp xúc phóng xạ.

**Chẩn đoán**: xác định liều có ý nghĩa quyết định. Ngoài ra dựa vào lâm sàng, huyết học, tiền sử tiếp xúc, tổn thương da, niêm mạc, xét nghiệm máu, tế bào. Với nhiễm xạ trong còn đo hoạt độ trong nước tiểu, phân, máu, mồ hôi, khí thở, tuyến giáp…

**Bảng 9.1 — Các thể lâm sàng của bệnh nhiễm xạ cấp** (Giáo trình tr. 327):

| Thể | Liều (Gy) | Triệu chứng | Hậu quả |
|---|---|---|---|
| Tủy xương nhẹ | 2–4 | Buồn nôn, nôn; giảm nhẹ tế bào máu | Bệnh phát 3 tuần sau chiếu |
| Tủy xương nặng | 4–6 | Suy giảm tế bào máu; nôn mửa, ỉa chảy | Cần điều trị tích cực, kể cả ghép tủy |
| Tiêu hóa | 6–10 | Nôn mửa, ỉa chảy, xuất huyết | Choáng, có thể chết sau vài tuần |
| Thần kinh | > 10 | Viêm da cấp, rối loạn định hướng, choáng | Chết sau vài ngày |

**Ung thư**: có thể xuất hiện sau **một liều lớn**, hoặc sau **nhiều liều nhỏ lặp lại**. Ví dụ của giáo trình: ung thư da ở bác sĩ X-quang thời kỳ đầu; ung thư phổi ở thợ mỏ; ung thư xương ở công nhân vẽ bóng đèn bằng sơn có radi (giáo trình ghi "phospho"); bệnh **bạch cầu** sau vụ Chernobyl và vụ ném bom nguyên tử ở Nhật Bản. Có hai giả thuyết về cơ chế: **đột biến gen** và **virus**. Liều gây ung thư khó xác định. Ung thư có **giai đoạn tiềm tàng** có thể kéo dài tới **30 năm**; bệnh bạch cầu thì tiềm tàng ngắn hơn (Giáo trình tr. 327).

> [!cap-nhat] Hiệu ứng tất định và hiệu ứng ngẫu nhiên
> Hiện nay (ICRP 103) tác dụng của bức xạ được chia làm hai nhóm:
> - **Hiệu ứng tất định** (phản ứng mô): có **ngưỡng liều**; trên ngưỡng, **mức độ nặng tăng theo liều**. Ví dụ: bỏng da, đục thủy tinh thể, vô sinh, hội chứng nhiễm xạ cấp (bảng 9.1).
> - **Hiệu ứng ngẫu nhiên**: **ung thư** và **hiệu ứng di truyền**. Để bảo vệ, người ta giả định **không có ngưỡng**: liều càng cao thì **xác suất** mắc càng tăng (mô hình tuyến tính không ngưỡng), còn mức độ nặng không phụ thuộc liều.
> - Mục đích của an toàn bức xạ: **tránh hoàn toàn** hiệu ứng tất định và **hạn chế đến mức hợp lý** xác suất hiệu ứng ngẫu nhiên.
> - Ngưỡng gây đục thủy tinh thể nay được ICRP đánh giá **thấp hơn trước nhiều, khoảng 0,5 Gy**. Đó là lý do giới hạn liều cho thủy tinh thể được hạ xuống (mục 5.2).

### 4.3. Các yếu tố ảnh hưởng đến hiệu ứng sinh học

#### a) Bản chất và năng lượng của tia

Tác dụng sinh học tùy thuộc số cặp ion tạo ra trong mô, được biểu diễn bằng **LET**. LET càng lớn thì tác dụng sinh học càng mạnh (Giáo trình tr. 327):

| Loại tia (bảng 9.2) | LET (keV/µm) | Tác dụng sinh học |
|---|---|---|
| Gamma của ^60^Co | 0,3 | Thấp |
| Beta (năng lượng thấp) | 5,5 | ↓ |
| Neutron | 45 | ↓ |
| Alpha | 110 | Cao |

Về độ sâu tác dụng: tia **γ và X** tác dụng được vào mô **sâu**; **β và α** chỉ tác dụng ở mô **nông**. Riêng nguồn α hoặc β **nằm trong cơ thể** (nhiễm xạ trong) thì lại rất nguy hiểm, vì toàn bộ năng lượng được trao trong một thể tích mô nhỏ.

> [!bay] Năng lượng tia và LET
> Giáo trình (tr. 328) viết: "năng lượng tia càng lớn thì xuyên sâu càng nhiều và LET càng lớn". Vế đầu đúng. Vế sau thì **ngược** với chính mục 2.1: **với cùng một loại hạt tích điện, hạt càng nhanh (năng lượng càng cao) thì LET càng nhỏ**. LET lớn nhất ở **cuối quãng chạy**, khi hạt đã chậm lại. Khác biệt LET lớn chủ yếu là giữa **các loại tia** (α ≫ β > γ).

#### b) Liều lượng, suất liều và yếu tố thời gian

- **Liều** là yếu tố quan trọng nhất: liều càng lớn, tổn thương càng nặng và càng xuất hiện sớm.
- **Suất liều** (liều trong một đơn vị thời gian) và **thời gian**: cùng một tổng liều, **chia nhỏ và rải ra** thì tác dụng giảm. Thời gian giữa các lần chiếu cho mô cơ hội **hồi phục**.

Thí nghiệm trên chuột của giáo trình (tr. 328):

| Cách chiếu toàn thân chuột | Kết quả |
|---|---|
| 1 lần 25 R | Không thấy tổn thương |
| 25 R/lần × 10 ngày liên tiếp | Triệu chứng **như chiếu 1 lần 250 R** (tích lũy liều) |
| 5 R/lần | Phải sau **60 lần** mới thấy tổn thương |
| 3 R/lần hoặc 1 R/lần | **Không thấy** tổn thương dù tổng liều tới 250–300 R |

Vậy **cùng liều hấp thụ, thời gian chiếu càng kéo dài thì hiệu ứng sinh học càng giảm**. Khi suất liều nhỏ, tốc độ tổn thương cân bằng với tốc độ hồi phục. Trong **xạ trị**, phải có **tổng liều đủ lớn** với suất liều thích hợp nếu kéo dài thời gian chiếu.

#### c) Môi trường chiếu

- **Diện tích chiếu**: chiếu **toàn thân** nguy hiểm hơn nhiều so với **cục bộ**. Ví dụ: **6 Gy** chiếu cục bộ chỉ làm **đỏ da**, nhưng chiếu toàn thân thì đó là liều **LD~50/30~** (liều làm chết 50% số cá thể trong 30 ngày). Lý do: tổn thương nhẹ ở nhiều cơ quan cộng hưởng với nhau thành hội chứng nhiễm xạ cấp. (Lưu ý: chính Bảng 9.3 của giáo trình lại ghi tử vong 50% ở **3–5 Gy**. Số liệu hiện nay: LD~50/60~ ở người khoảng **3,5–4,5 Gy** nếu không điều trị, có thể tới 6–7 Gy nếu được hồi sức tích cực — xem bảng dưới.)
- **Nhiệt độ**: **hạ nhiệt độ làm giảm** tác dụng của bức xạ, vì gốc tự do di chuyển chậm hơn, giảm cơ chế gián tiếp. Bảo quản chế phẩm sinh học có gắn phóng xạ ở nhiệt độ đông băng cũng dựa trên nguyên lý này.
- **Hiệu ứng oxy**: độ nhạy cảm **tăng theo nồng độ O~2~**, do tạo nhiều HO~2~•, H~2~O~2~. Hiệu ứng tăng dần đến mức O~2~ bình thường của không khí (21%), sau đó không tăng thêm. Hiệu ứng oxy **rõ với bức xạ LET thấp**; với α, proton (LET cao) thì rất ít hoặc không có.
- **Hàm lượng nước**: càng nhiều nước thì càng nhiều gốc tự do, nên hiệu ứng càng tăng (Giáo trình tr. 329).

> [!ung-dung] Hiệu ứng oxy trong xạ trị
> Vùng trung tâm khối u lớn thường **thiếu oxy**, nên kháng tia X và γ hơn vùng ngoại vi. Đây là một lý do để **chia liều**: giữa các buổi chiếu, u co nhỏ lại, vùng thiếu oxy được cung cấp oxy trở lại (tái oxy hóa) và nhạy hơn ở buổi sau. Bức xạ LET cao (neutron, ion nặng) ít phụ thuộc oxy hơn.

**Bảng 9.3 — Đáp ứng liều sau chiếu toàn thân** (Giáo trình tr. 329):

| Liều | Hiệu ứng |
|---|---|
| 0,1 Gy | Không có dấu hiệu lâm sàng; có thể phát hiện tăng sai lạc nhiễm sắc thể |
| 1 Gy | Bệnh nhiễm xạ ở 5–7% số người bị chiếu |
| 2–3 Gy | Rụng lông tóc, đục thủy tinh thể, giảm bạch cầu, ban đỏ da; bệnh nhiễm xạ ở hầu hết; tử vong 10–30% |
| 3–5 Gy | Giảm bạch cầu nặng, ban xuất huyết, xuất huyết, nhiễm khuẩn, rụng lông tóc; **tử vong 50%** |
| 6 Gy | Vô sinh lâu dài ở cả nam và nữ; tử vong > 50% kể cả khi được điều trị tốt nhất |

#### d) Các chất bảo vệ

Một số chất đưa vào cơ thể **trước khi chiếu** làm giảm hiệu ứng của bức xạ. Năm 1942, Deili (theo cách viết của giáo trình) lần đầu thấy **thiourê** có tác dụng chống phóng xạ. Sau đó có thêm **cystein**, **MEA** (mercaptoethylamin) và nhiều chất từ động vật, thực vật. Cơ chế tác dụng chưa được giải thích đầy đủ (Giáo trình tr. 330). Nhiều chất có nhóm –SH, có lẽ do chúng "bắt" gốc tự do và bị oxy hóa thay cho phân tử sinh học.

> [!ung-dung] Thuốc bảo vệ phóng xạ hiện dùng
> **Amifostin** (một hợp chất thiol) được dùng trong xạ trị vùng đầu cổ để giảm khô miệng. **Kali iodid** (KI) uống **trước hoặc ngay sau** khi có nguy cơ nhiễm iod phóng xạ (sự cố hạt nhân). KI làm tuyến giáp bão hòa iod bền, nên ^131^I không được tuyến giáp hấp thu. KI không bảo vệ được các cơ quan khác.

## 5. Nguyên tắc kiểm soát và an toàn bức xạ

Phần này tương ứng mục 4.4 của giáo trình (tr. 330–336).

### 5.1. Nguồn chiếu xạ ảnh hưởng đến con người

- **Chiếu ngoài**: do các tia đâm xuyên mạnh như X, γ, neutron, β cứng.
- **Chiếu trong**: chất phóng xạ lọt vào cơ thể qua **hô hấp, tiêu hóa, da**, trở thành nguồn chiếu ngay trong cơ thể.
- **Nguồn tự nhiên** và **nguồn nhân tạo**. Nguồn nhân tạo gồm: tia X trong y tế và công nghiệp; nguồn phóng xạ hở như ^131^I; nguồn kín như ^60^Co; cặn bã của các vụ nổ hạt nhân thử nghiệm như ^137^Cs, ^90^Sr, ^89^Sr (Giáo trình tr. 330).

### 5.2. Liều giới hạn

Giáo trình dẫn khuyến cáo của **Ủy ban Quốc tế về An toàn bức xạ (ICRP) năm 1990**, và cho biết quy định của Việt Nam cũng như vậy (Giáo trình tr. 330–331):

| Đối tượng | Giới hạn (theo giáo trình) |
|---|---|
| **Nhân viên bức xạ** | **20 mSv/năm** (gồm cả chiếu ngoài và chiếu trong). Một năm bất kỳ có thể tới **50 mSv**, nhưng trung bình 5 năm liên tiếp phải ≤ 20 mSv/năm |
| Cứu chữa khẩn cấp, hạn chế tai nạn | Tới **500 mSv**, chỉ **một lần** trong suốt đời nghề nghiệp |
| Phụ nữ có thai hoặc đang cho con bú | Không tiếp xúc nguồn hở; khi có thai: giới hạn **2 mSv** cho suốt thời gian mang thai |
| **Dân chúng** | **1 mSv/năm**. Trường hợp đặc biệt có thể cao hơn trong một năm, nhưng trung bình 5 năm vẫn phải ≤ 1 mSv/năm |

- Giới hạn liều **không khác nhau** giữa nam và nữ.
- Các giới hạn trên là cho **chiếu ngoài**. Với nguy cơ chiếu trong, còn có **tiêu chuẩn thứ cấp**: **nồng độ tối đa cho phép** (NĐTĐCP). Để tính NĐTĐCP phải biết nguồn xạ, đường xâm nhập và đặc trưng của cơ thể hoặc cơ quan đích.
- Giới hạn liều **không áp dụng cho bệnh nhân** được chẩn đoán, điều trị. Với bệnh nhân, nguyên tắc là **chỉ định đúng và tối ưu hóa liều** (mục 5.3e).

> [!cap-nhat] Khuyến cáo hiện hành: ICRP 103 (2007) và cập nhật 2011
> - Giáo trình gọi khuyến cáo năm 1990 (ICRP 60) là "mới nhất". Khuyến cáo hiện hành là **ICRP 103 (2007)**, **giữ nguyên** các giới hạn chính: nghề nghiệp **20 mSv/năm lấy trung bình 5 năm** (tức 100 mSv/5 năm), không năm nào quá **50 mSv**; công chúng **1 mSv/năm**.
> - **Thủy tinh thể**: từ năm **2011**, ICRP hạ giới hạn nghề nghiệp từ 150 mSv/năm xuống **20 mSv/năm** (trung bình 5 năm, không năm nào quá 50 mSv). Điều này rất quan trọng với bác sĩ **can thiệp mạch, tim mạch can thiệp** dưới màn huỳnh quang: cần kính chì, tấm chắn treo trần.
> - **Phụ nữ mang thai** (ICRP 103): sau khi đã khai báo có thai, liều cho **phôi thai** không quá khoảng **1 mSv** trong thời gian còn lại của thai kỳ (giáo trình ghi 2 mSv).
> - Ba nguyên tắc nền tảng của ICRP: **biện minh** (lợi ích phải lớn hơn tác hại), **tối ưu hóa** (ALARA: *As Low As Reasonably Achievable*, thấp đến mức hợp lý có thể đạt được), **giới hạn liều**.
> - Đi thi: trả lời theo giáo trình.

### 5.3. Các biện pháp bảo đảm an toàn bức xạ

#### a) Với nguồn kín — chống chiếu ngoài

**Nguồn kín** là nguồn có vỏ bọc kín, chắc chắn, chất phóng xạ không lọt ra ngoài khi dùng, bảo quản hay vận chuyển. Ví dụ: máy X-quang, nguồn ^60^Co, ^137^Cs, kim radi điều trị u. Nhân viên làm việc với nguồn kín **chỉ bị chiếu ngoài**, nên dùng **3 biện pháp** (Giáo trình tr. 331–332):

![Hình 3. Ba nguyên tắc bảo vệ chống chiếu ngoài: thời gian – khoảng cách – che chắn](che-chan.svg)

1. **Rút ngắn thời gian**: liều tích lũy = suất liều × thời gian. Thời gian giảm một nửa thì liều giảm một nửa. Cần **thạo nghề**: tập trước trên mô hình không phóng xạ, chuẩn bị kỹ trước khi làm. Trong phòng X-quang, phòng **thật tối** và thầy thuốc ngồi trong tối đủ lâu để mắt thích nghi giúp rút ngắn thời gian chiếu. Chất thải phóng xạ đời ngắn thì **lưu giữ chờ phân rã** rồi mới xử lý.
2. **Tăng khoảng cách**: đơn giản, đáng tin cậy. Với nguồn điểm, suất liều giảm theo **bình phương khoảng cách** (mục 1.3c). Dùng **kẹp cán dài**, thao tác từ xa; với nguồn hoạt độ cao dùng **người máy**, thiết bị điều khiển tự động.

=> I~1~/I~2~ = (R~2~/R~1~)²   (I: suất liều; R: khoảng cách đến nguồn điểm)

3. **Che chắn**: đặt vật liệu hấp thụ giữa nguồn và người. Có 5 loại tấm chắn:
   - **bình chứa**: bảo quản, vận chuyển; cửa sổ mở bằng điều khiển từ xa;
   - **hộp kín** (glove box, tủ hút) bao toàn bộ nguồn khi làm việc;
   - **tấm chắn di động** (ví dụ tấm chắn của bác sĩ X-quang);
   - **tấm chắn là bộ phận công trình**: tường, trần, cửa;
   - **phương tiện bảo hộ cá nhân**: áo, kính, găng tay, ủng pha chì.

**Chọn vật liệu che chắn:**

| Loại tia | Vật liệu |
|---|---|
| X, γ | **Chì** (tốt nhất); rẻ hơn: gang, bê tông, bê tông trộn barit, bê tông cốt thép; cả nước và gạch |
| β | Thủy tinh thường, **thủy tinh hữu cơ**, chất dẻo, **nhôm** (Z thấp, ít bức xạ hãm) |
| Neutron | Chất chứa **nhiều H** (bê tông, nước), hoặc **bor**, **cadimi**; kết hợp chì và bê tông |

Khi chọn chiều dày và vật liệu, phải cân nhắc 3 yếu tố: **công nghệ, an toàn, giá cả**.

> [!vi-du] Bài tính thường gặp
> - **Khoảng cách**: suất liều ở 1 m là 90 µSv/h. Lùi ra 3 m thì suất liều còn 90/3² = **10 µSv/h**. Tiến lại 0,5 m thì tăng lên 90 × 2² = **360 µSv/h**.
> - **Che chắn**: muốn giảm suất liều γ còn 1/16, cần 4 HVL (vì 2^4^ = 16). Nếu μ = 0,693 cm^−1^ thì HVL = 1 cm, nên cần 4 cm.
> - **Thời gian**: làm việc ở nơi có suất liều 50 µSv/h thì sau **20 giờ** sẽ nhận 1 mSv.

#### b) Với nguồn hở — chống cả chiếu ngoài và chiếu trong

**Nguồn hở** là nguồn có chất phóng xạ có thể làm **ô nhiễm môi trường** khi sử dụng, ví dụ dung dịch ^131^I, ^99m^Tc trong y học hạt nhân. Ngoài 3 biện pháp trên, còn phải chống **nhiễm bẩn và chiếu trong** (Giáo trình tr. 332–334):

- **Phân vùng làm việc**: tách khu vực tiếp xúc phóng xạ khỏi khu chức năng khác. Bố trí sao cho mức phóng xạ **giảm dần từ trong ra ngoài**, hoặc **từ dưới lên trên** nếu cơ sở có nhiều tầng.
- **Thông khí**: luồng khí đi từ nơi hoạt tính **thấp** đến nơi hoạt tính **cao**, không bao giờ ngược lại. Kết hợp lọc bụi, lọc khí phóng xạ; dùng **tủ hút** trong phòng thí nghiệm.
- **Kiểm tra ô nhiễm thường xuyên**:
  - **Bề mặt**: dùng máy G-M, nhấp nháy, buồng ion hóa. Với α, đầu dò cách bề mặt **≤ 5 mm**, di chuyển ≤ 15 cm/s. Với β, cách **2,5–5 cm**, tốc độ 10–15 cm/s.
  - **Nhiễm xạ ngoài** cơ thể: rà máy trên quần áo, da.
  - **Nhiễm xạ trong**: **trực tiếp** bằng máy đếm toàn thân; **gián tiếp** bằng đo hoạt tính máu, nước tiểu, mồ hôi, nước mũi, đờm, khí thở.
- **Xử lý chất thải phóng xạ**:
  - **Chất thải rắn** (bơm kim tiêm, đồ thủy tinh vỡ, giấy, bông thấm): gom vào bao chất dẻo, đưa vào **bể thải** riêng có che chắn, **chờ phân rã** đến mức quy định rồi thải như rác thường.
  - **Chất thải lỏng** (dung dịch thừa, nước rửa dụng cụ, chất thải và chất nôn của bệnh nhân, nước giặt đồ nhiễm xạ): theo giáo trình, liều chẩn đoán, điều trị tới **15 mCi** có thể đổ vào hệ thống cống thải thành phố. Liều đặc biệt cao như khi **điều trị ung thư giáp bằng ^131^I** thì phải dùng **hố xí có cấu trúc đặc biệt** để xử lý riêng.

#### c) Với nhân viên bức xạ

- Thực hiện đầy đủ vệ sinh cá nhân; dùng **phương tiện phòng hộ** (quần áo, mũ, găng tay, áo chì, tạp dề chì).
- Tuân thủ quy định an toàn. **Không hút pipet bằng miệng**. **Không hút thuốc, ăn uống, trang điểm** trong phòng có chất phóng xạ.
- Trước khi ra khỏi nơi làm việc, kiểm tra nhiễm bẩn ở tay, quần áo; ai bị nhiễm bẩn phải tẩy xạ theo quy định.
- **Theo dõi liều cá nhân** hằng tháng hoặc hằng quý, cộng dồn theo năm và suốt đời làm nghề. Các loại liều kế:
  - **liều kế phim**: khoảng đo 0,1 mSv – 10 Sv;
  - **bút đo liều** (buồng ion hóa nhỏ có sợi thạch anh tích điện trước; độ dịch chuyển của sợi tỉ lệ với liều): các loại 0–2 mGy, 0–50 mGy, 0–100 mGy;
  - **liều kế nhiệt huỳnh quang** (TLD): 0,1 mSv – 100 mSv.
- **Khám sức khỏe** khi tuyển chọn và **định kỳ**, để không đưa người không đủ sức khỏe vào làm việc với phóng xạ và để phòng tai nạn (Giáo trình tr. 334–335).

#### d) An toàn cho bệnh nhân

Mục tiêu: tránh chiếu xạ **không cần thiết** và hạn chế liều **ở mức thấp nhất** mà vẫn đạt yêu cầu chẩn đoán, điều trị. Ba nguyên tắc (Giáo trình tr. 335):

1. **Chỉ định đúng**:
   - Mọi chỉ định dùng bức xạ phải do thầy thuốc cân nhắc **lợi ích so với thiệt hại**. Nếu hai phương pháp cho kết quả như nhau thì **không chọn phương pháp dùng phóng xạ** (ví dụ ưu tiên siêu âm, MRI khi phù hợp).
   - Tham khảo kết quả các lần khám trước, tránh chụp lặp lại không cần thiết.
   - **Tránh dùng chất phóng xạ cho phụ nữ có thai, nghi có thai, đang cho con bú**, trừ khi bắt buộc; nếu phải dùng thì giảm tối đa liều cho thai nhi.
   - Với **trẻ em**: chỉ dùng khi không có phương pháp thay thế, và hoạt độ phải **giảm theo quy định**.
2. **Tận giảm liều chiếu**:
   - máy móc đạt chuẩn kỹ thuật; máy thế hệ mới cho ảnh tốt hơn với liều thấp hơn;
   - bảo đảm chất lượng phim, tránh phải chụp lại;
   - **khu trú trường chiếu** ở mức tối thiểu cần thiết.

> [!ung-dung] Bệnh nhân điều trị ^131^I
> Sau khi uống liều điều trị ^131^I (cường giáp, ung thư tuyến giáp), bệnh nhân trở thành **nguồn phóng xạ hở**: phát γ và β, thải qua nước tiểu, mồ hôi, nước bọt. Họ được **cách ly** ở phòng riêng có che chắn và nhà vệ sinh riêng. Khi về nhà cần tránh tiếp xúc gần, kéo dài với trẻ nhỏ và phụ nữ có thai trong một thời gian theo hướng dẫn. Ở đây áp dụng đủ cả ba nguyên tắc: **thời gian, khoảng cách**, và **chờ phân rã** (T ≈ 8 ngày).

#### e) Bảo vệ môi trường

- **Nguồn ô nhiễm**:
  - **thử vũ khí hạt nhân**: sản phẩm phân hạch và kích hoạt có T từ vài phút đến hàng nghìn năm; tro bụi phóng xạ tung lên khí quyển rồi rơi xuống sau vài chục năm;
  - **cơ sở khai thác, chế biến nhiên liệu hạt nhân**: mỏ urani, nhà máy làm sạch, làm giàu;
  - **bệnh viện, phòng thí nghiệm, xí nghiệp** dùng đồng vị phóng xạ, với chất thải dạng khí, lỏng, rắn.
- **Biện pháp**: công nghệ hiện đại để tạo **ít chất thải nhất** và hạn chế thấm ra môi trường; **làm vô hại** bằng cách tập trung, bảo quản, xử lý đúng chất thải; thực hiện tổ chức, vệ sinh, phân vùng làm việc (Giáo trình tr. 335–336).

> [!bay] Nguồn kín và nguồn hở
> - **Nguồn kín** (máy X-quang, nguồn ^60^Co xạ trị): chỉ có nguy cơ **chiếu ngoài**, nên bảo vệ bằng **thời gian – khoảng cách – che chắn**.
> - **Nguồn hở** (^131^I, ^99m^Tc dạng dung dịch): có nguy cơ **chiếu ngoài + chiếu trong** (qua hô hấp, tiêu hóa, da), nên phải thêm **phân vùng, thông khí, kiểm tra nhiễm bẩn, xử lý chất thải, phòng hộ cá nhân**.
> - Tắt máy X-quang thì **hết phát tia**; nguồn đồng vị thì **luôn phát tia**, không "tắt" được.
> - Với nguồn α nằm **ngoài** cơ thể thì gần như vô hại (lớp sừng của da đã chặn được α). Nhưng nếu nuốt hoặc hít vào thì α là **nguy hiểm nhất**, vì LET và hệ số Q cao.

## Tóm tắt

| Chủ đề | Điểm cốt lõi |
|---|---|
| Hạt nhân | ^A^~Z~X; A = Z + N; đồng vị: cùng Z, khác N; hạt nhân là hệ lượng tử → phát γ |
| Phân rã | β^−^: n → p (Z+1); β^+^: p → n (Z−1); α: Z−2, A−4; γ: chỉ giảm năng lượng; phổ β liên tục (neutrino); α đơn năng |
| Định luật | N = N~0~·e^−λt^; T = 0,693/λ; sau n·T còn 1/2^n^; q = λN (Bq; 1 Ci = 3,7·10^10^ Bq); J = n/4πR² |
| Hạt tích điện | Ion hóa trực tiếp; LET α > β > γ; LET lớn ở cuối quỹ đạo; α đi được ≤ 10 cm không khí, 0,1 mm nước; bức xạ hãm ↑ theo Z → che β bằng Z thấp |
| Photon | Ion hóa gián tiếp; quang điện (năng lượng thấp, ↑ mạnh theo Z), Compton (trung bình), tạo cặp (≥ 1,02 MeV, ∝ Z²); hủy cặp → 2γ 0,511 MeV |
| Neutron | Không ion hóa trực tiếp; tán xạ đàn hồi (làm chậm bằng chất giàu H), không đàn hồi, bắt neutron (phát γ) |
| Suy giảm | α: J = J~0~ (x < R), 0 (x ≥ R); γ: I = I~0~·e^−μx^, HVL = 0,693/μ; μ = τ + σ + χ |
| Liều | Chiếu C/kg (R = 2,58·10^−4^ C/kg); hấp thụ Gy (100 rad); tương đương = D·Q, Sv (100 rem); hiệu dụng = H·W, Sv |
| Ghi đo | Phim; nhấp nháy NaI(Tl) + ống nhân quang (đo phổ); buồng ion hóa (vùng II, đo liều, chuẩn liều); G-M (vùng IV, β ≈ 100%, γ ≈ 1%, thời gian chết 100–300 µs); TLD |
| Cơ chế | Trực tiếp (đại phân tử) + gián tiếp (gốc tự do từ nước, H~2~O~2~; tăng khi có O~2~, nước) |
| Tổn thương | DNA quan trọng nhất; nhân nhạy nhất; D~37~ lớn = kém nhạy; Bergonié–Tribondeau; tủy xương, sinh dục nhạy nhất; cơ, xương, thần kinh ít nhạy nhất |
| Toàn thân | Nhiễm xạ cấp: tủy 2–6 Gy, tiêu hóa 6–10 Gy, thần kinh > 10 Gy; LD~50~ ≈ 3–5 Gy (giáo trình; hiện nay ≈ 3,5–4,5 Gy nếu không điều trị); ung thư tiềm tàng tới 30 năm |
| Yếu tố | LET ↑ → tác dụng ↑; chia liều, giảm suất liều → tác dụng ↓; toàn thân > cục bộ; lạnh ↓; O~2~ ↑ (với LET thấp); nước ↑; chất bảo vệ (–SH) ↓ |
| An toàn | Nghề nghiệp 20 mSv/năm (≤ 50 mSv/năm đơn lẻ, TB 5 năm); dân chúng 1 mSv/năm; khẩn cấp 500 mSv một lần; nguồn kín: thời gian – khoảng cách – che chắn; nguồn hở: thêm chống nhiễm bẩn; bệnh nhân: chỉ định đúng + tận giảm liều |
