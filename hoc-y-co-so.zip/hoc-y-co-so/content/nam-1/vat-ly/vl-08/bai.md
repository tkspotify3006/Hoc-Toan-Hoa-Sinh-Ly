---
title: Tác dụng của ánh sáng lên cơ thể sống
thoi-gian: 90 phút
muc-tieu:
- Nêu được các giai đoạn của một quá trình quang sinh và phân loại các quá trình quang sinh dựa trên hiệu ứng sinh học (phá hủy biến tính / sinh lý chức năng).
- Trình bày được các đặc điểm của quá trình quang sinh: hiệu suất lượng tử, phổ tác dụng, nhu cầu năng lượng, di chuyển năng lượng (cộng hưởng, exiton).
- Trình bày được cơ sở vật lý của quang hợp, quang tổng hợp vitamin D và tác dụng của tia tử ngoại.
- Trình bày được khái niệm, điều kiện, cơ chế và các biểu hiện của tác dụng quang động lực; liên hệ được với liệu pháp quang động và phản ứng nhạy cảm ánh sáng do thuốc, dược liệu.
- Trình bày được cơ sở phân tử của sự thụ cảm ánh sáng ở mắt (chu trình rodopsin), ngưỡng nhìn và độ nhạy của mắt.
- Giải thích được sơ lược cảm giác màu sắc (thuyết ba thành phần), thị giác hai mắt, sự lưu hình và các dạng loạn sắc.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. **Phản ứng quang sinh** = phản ứng trong cơ thể sống có sự tham gia của ánh sáng. Trình tự: **hấp thụ photon → trạng thái kích thích → khử kích thích (quang lý hoặc quang hóa) → phản ứng tối → hiệu ứng sinh vật**.
> 2. Theo hiệu ứng sinh vật chia 2 nhóm: **phá hủy biến tính** (gây bệnh lý, gây đột biến, gây tử vong) và **sinh lý chức năng** (tạo năng lượng – quang hợp; thông tin – thị giác; sinh tổng hợp – vitamin D, sắc tố).
> 3. Đặc điểm: **hiệu suất lượng tử φ** = số phân tử bị kích hoạt / số phân tử đã hấp thụ ánh sáng; **phổ tác dụng** (hiệu ứng theo λ) so với phổ hấp thụ để tìm chất hấp thụ; năng lượng có thể **di chuyển** giữa các phân tử (cộng hưởng, exiton).
> 4. **Tác dụng quang động lực** = tổn thương không hồi phục do **ánh sáng + O~2~ + chất màu (chất cảm quang)**, đi qua **trạng thái triplet** của chất màu. Cơ sở của liệu pháp quang động (PDT) và phản ứng nhạy cảm ánh sáng do thuốc.
> 5. **Thị giác**: photon phân hủy **rodopsin** (tế bào que) → opxin + retinal → xung thần kinh. Ngưỡng nhìn chỉ **1–2 photon**; thị giác ngày nhạy nhất ở **555 nm**, thị giác tối ở **510 nm**; cảm giác màu giải thích bằng **3 loại tế bào nón** (Young – Helmholtz).

Để tồn tại, sinh vật thu năng lượng từ ánh sáng Mặt Trời rồi chuyển sang các dạng năng lượng khác qua những phản ứng đặc hiệu. Giáo trình gọi **những phản ứng xảy ra trong cơ thể sống có sự tham gia của ánh sáng là phản ứng quang sinh** (Giáo trình tr. 267). Phần lớn phản ứng này xảy ra ở mức phân tử, nguyên tử, nên muốn hiểu chúng phải dùng cơ học lượng tử và hóa lượng tử.

Khi ánh sáng gặp cơ thể sống, có hai loại hệ quả:

- **Về phía chùm tia**: cường độ, bước sóng, hướng truyền… bị thay đổi (hấp thụ, tán xạ, phản xạ).
- **Về phía cơ thể**: xảy ra **quá trình quang sinh** gồm nhiều giai đoạn nối tiếp.

## 1. Đại cương về quá trình quang sinh

### 1.1. Các giai đoạn chính của một quá trình quang sinh

Giáo trình nêu 4 giai đoạn (tr. 267–268):

1. **Hấp thụ ánh sáng** bởi sắc tố hoặc các chất khác → phân tử chuyển lên **trạng thái kích thích**, tức là tích lũy năng lượng bên trong phân tử.
2. **Khử trạng thái kích thích**, theo một trong hai đường:
   - giải phóng năng lượng kích thích bằng các **quá trình quang lý** (tỏa nhiệt, phát quang, chuyển năng lượng sang phân tử khác);
   - hoặc qua **phản ứng quang hóa**, tạo ra các **sản phẩm quang hóa không bền** đầu tiên.
3. **Phản ứng tối**: các sản phẩm không bền tiếp tục phản ứng để thành **sản phẩm quang hóa bền vững**. Gọi là "tối" vì lúc này lượng tử ánh sáng **không còn tham gia trực tiếp**.
4. **Hiệu ứng sinh vật**: biểu hiện cuối cùng ở tế bào, mô, cơ thể.

![Hình 1. Các giai đoạn của một quá trình quang sinh](giai-doan-quang-sinh.svg)

> [!bay]
> - "Phản ứng tối" **không có nghĩa** là phản ứng chỉ xảy ra trong bóng tối. Nó vẫn xảy ra lúc đang chiếu sáng; chỉ là ánh sáng **không trực tiếp** tham gia nữa.
> - Không phải phân tử nào hấp thụ photon cũng đi đến phản ứng quang hóa: nhiều phân tử "trả lại" năng lượng bằng đường quang lý (nhiệt, phát quang). Đó là lý do hiệu suất lượng tử thường < 1 (mục 1.3).

> [!vi-du] Hai định luật cơ bản của quang hóa (bổ sung, không có trong giáo trình)
> - **Định luật Grotthuss – Draper**: chỉ ánh sáng **bị hấp thụ** mới gây được biến đổi quang hóa. Ánh sáng đi xuyên qua mà không bị hấp thụ thì không có tác dụng. Giáo trình diễn đạt ý này: "để gây hiệu ứng sinh vật thì đối tượng phải hấp thụ photon" (tr. 268).
> - **Định luật Stark – Einstein**: mỗi phân tử bị kích thích ở giai đoạn đầu là do hấp thụ **một** photon. Đây là cơ sở để định nghĩa hiệu suất lượng tử.

### 1.2. Phân loại các quá trình quang sinh

Xét theo **hiệu ứng sinh vật**, có hai nhóm lớn (tr. 268):

| Nhóm | Bản chất | Các nhóm nhỏ – ví dụ |
|---|---|---|
| **Phá hủy biến tính** | Ánh sáng làm hỏng cấu trúc phân tử, tế bào | 1. Gây **bệnh lý** (bỏng nắng, tác dụng quang động lực…); 2. Gây **đột biến di truyền** (tử ngoại làm tổn thương ADN/DNA); 3. Gây **tử vong** (tử ngoại diệt khuẩn) |
| **Sinh lý chức năng** | Lượng tử ánh sáng tạo ra sản phẩm cần cho tế bào hoặc giúp tế bào thực hiện chức năng bình thường | 1. **Tạo năng lượng**: quang hợp, quang phosphoryl hóa; 2. **Thông tin**: thị giác ở động vật, **hướng quang**, quang hình thái ở thực vật, động vật, người; 3. **Sinh tổng hợp**: vitamin D, diệp lục, sắc tố |

- Ở phản ứng **thông tin**, năng lượng photon rất nhỏ, nhưng sản phẩm quang hóa kích thích những **cơ quan khuếch đại** đặc biệt (như võng mạc), nhờ vậy cơ thể nhận được thông tin về môi trường.
- Ở phản ứng **sinh tổng hợp**, chuỗi phản ứng tạo phân tử hữu cơ có **một vài giai đoạn quang hóa**, chỉ xảy ra khi có photon. Ánh sáng còn có thể **hoạt hóa hệ enzym** của quá trình tổng hợp sắc tố.

> [!bay]
> Cùng là tử ngoại nhưng có thể thuộc **cả hai nhóm**: tạo vitamin D (sinh lý chức năng – sinh tổng hợp) và diệt khuẩn, gây đột biến (phá hủy biến tính). Phân loại dựa trên **hiệu ứng**, không dựa trên loại bức xạ.

### 1.3. Một số đặc điểm của quá trình quang sinh

#### a) Hiệu suất lượng tử

Phân tử hấp thụ photon chưa chắc đã chuyển sang trạng thái kích thích và đi vào phản ứng quang hóa. Vì vậy người ta định nghĩa (công thức 8.1, tr. 268):

=> φ = (số phân tử bị kích hoạt) / (số phân tử đã hấp thụ ánh sáng)

- **φ** (không có đơn vị) cho biết **hiệu suất sử dụng năng lượng** của quá trình quang sinh.
- Thường φ ≤ 1. (Với phản ứng dây chuyền, sản phẩm cuối tính theo một photon có thể > 1, nhưng giáo trình xét số phân tử *bị kích hoạt* trực tiếp.)

> [!vi-du] Tính nhanh
> Một mẫu hấp thụ 2·10^18^ photon, có 5·10^17^ phân tử bị kích hoạt và tham gia phản ứng.
> => φ = 5·10^17^ / 2·10^18^ = 0,25

#### b) Phổ tác dụng

**Phổ tác dụng** là đường cong biểu diễn **hiệu ứng sinh vật theo bước sóng** của ánh sáng chiếu tới (Hình 8.1, tr. 269). Cực đại của đường cong ứng với bước sóng λ~m~ gây hiệu ứng mạnh nhất.

Thí nghiệm mẫu của sách: 10 ống nghiệm giống hệt nhau, cùng thể tích dịch vi khuẩn, cùng mật độ; chiếu cùng thời gian, cùng cường độ, **chỉ khác bước sóng** λ~1~, λ~2~… λ~10~. Đo tỷ lệ vi khuẩn bị khử hoạt tính ở mỗi ống rồi vẽ theo λ.

So **phổ tác dụng** với **phổ hấp thụ** của các chất trong đối tượng:

- **Hai phổ giống và trùng nhau** → tìm ra được **một loại phân tử duy nhất** đã hấp thụ ánh sáng và quyết định quá trình quang sinh.
- **Hai phổ không trùng nhau** → hiệu ứng do **hai loại phân tử trở lên**, và có thể có **di chuyển năng lượng** từ phân tử này sang phân tử khác.

> [!ung-dung] Phổ tác dụng trong y học
> - Phổ tác dụng **diệt khuẩn** của tử ngoại có đỉnh quanh **260 nm**, trùng với đỉnh hấp thụ của **acid nucleic**. Đó là bằng chứng ADN là "đích" chính. Vì vậy đèn diệt khuẩn dùng thủy ngân áp suất thấp phát vạch **253,7 nm**.
> - Phổ tác dụng của **chiếu đèn trị vàng da sơ sinh** trùng với phổ hấp thụ của **bilirubin** (đỉnh khoảng 460 nm, ánh sáng xanh lam). Vì vậy dùng đèn xanh lam, không dùng tử ngoại (xem mục 3).

#### c) Nhu cầu năng lượng

Bảng 8.1 của sách (tr. 269) nêu năng lượng hoặc số photon cần cho một số quá trình. Một vài con số đáng nhớ:

| Quá trình | Năng lượng (J/m²) | Số photon bị hấp thụ |
|---|---|---|
| Thị giác | 10^−13^ | – |
| Quang hợp tạo 1 phân tử O~2~ | – | 10 |
| Quang hợp tạo 1 g hydrat carbon | – | 10^23^ |
| Tạo sắc tố da (rám nắng) | 3·10^2^ | – |
| Phân hủy hồng cầu | – | 10^10^ |
| Khử hoạt tính vi khuẩn (khối lượng ≈ 10^−15^ g) | 10 | 10^8^ |
| Khử hoạt tính virus (≈ 10^−19^ g) | 10 | 10^4^ |
| Khử hoạt tính men (≈ 10^−22^ g) | 10^4^ | 10^2^ |
| Phân ly carboxymyoglobin (≈ 3·10^−23^ g) | – | 1 |

Rút ra (tr. 270):

- Quá trình **thay đổi chức năng** (khử hoạt tính, gây hoạt tính) cần **ít năng lượng hơn hẳn** quá trình **phá hủy** (như phá hủy hồng cầu).
- **Đối tượng càng nhỏ, số photon cần hấp thụ càng ít** (vi khuẩn 10^8^ → virus 10^4^ → men 10^2^).
- Nhưng **năng lượng chiếu tới** thì ngược lại: men cần cỡ **hàng nghìn – vạn J/m²**, còn virus và vi khuẩn chỉ **khoảng 10 J/m²**. Lý do: xác suất một phân tử protein hấp thụ một photon chỉ khoảng **0,0001**; tiết diện hấp thụ tỷ lệ với khối lượng phân tử, nên phân tử men nhỏ "hứng" được rất ít photon. Muốn khử một phân tử men, chùm tia phải đạt khoảng **10^5^ photon trên tiết diện phân tử**. Tuy vậy, với men thì **hiệu suất của ánh sáng đã hấp thụ lại cao hơn đáng kể**.
- Kết luận thực hành: **chọn công suất nguồn chiếu phải tính theo đặc tính của đối tượng sinh vật**.

Năng lượng ánh sáng bị hấp thụ được tiêu tán theo 3 cách:

1. Biến thành **nhiệt** hoặc bức xạ (**phát quang**).
2. Kích thích **chuỗi phản ứng phức tạp** (quang hợp).
3. **Phá hủy cấu trúc phân tử** (tử ngoại khử hoạt tính tế bào, virus, men).

#### d) Sự di chuyển năng lượng trong hệ sinh vật

Năng lượng vào cơ thể không chỉ qua thức ăn mà còn qua **lượng tử ánh sáng** và **bức xạ ion hóa**. Chúng tạo ra những trạng thái kích thích có năng lượng **lớn hơn nhiều lần** năng lượng của các phản ứng chuyển hóa thông thường. Năng lượng này có thể bị thải ra (phát quang) hoặc **di chuyển** từ phân tử này sang phân tử khác, qua khoảng cách **gấp bội kích thước tế bào** (tr. 270). Trước kia người ta tưởng năng lượng chỉ "đi" bằng cách khuếch tán các hợp chất giàu năng lượng.

**Thí nghiệm chứng minh**: hệ có 2 loại phân tử A và B. Chiếu sáng → **phổ hấp thụ của hệ trùng với phổ hấp thụ của A**, nhưng **phổ phát quang của hệ trùng với phổ phát quang của B**. Tắt nguồn sáng thì hệ hết phát quang. Vậy A hấp thụ, năng lượng chuyển sang B, rồi B phát quang.

Hai cơ chế được chú ý:

**Cơ chế cộng hưởng** (tr. 271)

- Năng lượng chuyển từ phân tử bị kích thích (A) sang phân tử khác (B) ở khá xa (so với khoảng cách giữa các nguyên tử), **không phát quang, không hao phí thành nhiệt, không va chạm** giữa hai phân tử.
- Bản chất: mỗi phân tử kích thích như **một lưỡng cực dao động** với tần số xác định. Nếu mức năng lượng của B trùng hoặc thấp hơn một chút mức của A thì hai lưỡng cực **cộng hưởng**, năng lượng của A chuyển gần hết cho B.

=> A + B + hf → A* + B → A + B*

- Hệ quả: thời gian A ở trạng thái kích thích **giảm**, phát quang của A **yếu đi**.
- **Không có sự phân chia điện tích** (điện tử không bị tách ra). Thường xảy ra trong dung dịch.
- **Điều kiện**: (1) phân tử cho phải **phát quang được**; (2) **phổ phát quang** của chất cho và **phổ hấp thụ** của chất nhận phải **chồng lên nhau** — vùng giao càng lớn, hiệu suất càng cao; (3) hai phân tử phải **đủ gần** (theo sách: ở 10 Å hiệu suất đạt 50%).
- Hiệu suất dao động từ 100% đến < 1%: ở protein chỉ vài %, ở acid nucleic tới 30%, ở hệ có mật độ chất nhận sắc cao có thể tới 100%.
- Với các biến đổi năng lượng nhỏ (0–12 kcal/mol, như trong chuyển hóa oxy hóa – khử) thì cơ chế cộng hưởng không có giá trị, vì năng lượng này nhỏ hơn nhiều so với mức kích thích điện tử. Năng lượng đó được tích trong **liên kết giàu năng lượng** (như ATP).

> [!cap-nhat] Cơ chế cộng hưởng = FRET
> Giáo trình viết hiệu suất "tỉ lệ nghịch với khoảng cách". Hiện nay cơ chế này được gọi là **truyền năng lượng cộng hưởng Förster (FRET)**, và hiệu suất giảm rất nhanh, **theo lũy thừa bậc 6** của khoảng cách (∝ 1/r^6^), có hiệu lực trong khoảng vài nm. Nhờ đặc điểm này, FRET được dùng như "thước đo phân tử" trong nghiên cứu sinh học. Khi thi, trả lời theo giáo trình.

**Thuyết exiton** (tr. 272)

- Trong chất có cấu trúc **giống tinh thể**, điện tử được ánh sáng đưa lên mức cao rồi **chuyển từ phân tử này sang phân tử khác vẫn ở mức năng lượng ấy**, để lại một **lỗ trống** đi theo sát nó.
- Cặp **điện tử – lỗ trống** di chuyển cùng nhau gọi là **exiton**.
- Khi điện tử rơi vào một "**bẫy**" (mức năng lượng ổn định) thì một phần năng lượng thành nhiệt; cặp điện tử – lỗ trống có thể bị phá vỡ.
- Exiton mang năng lượng đi được **khoảng cách lớn**. Thuyết này dùng để giải thích di chuyển năng lượng trong hệ chứa **sắc tố** như **rodopsin, diệp lục**. Có giả định rằng trong quang hợp, **diệp lục hoạt động như chất bán dẫn**: tạo điện tử khu trú và lỗ trống dương, rồi chúng đi vào các môi trường khác nhau để tạo phản ứng oxy hóa – khử.

| | Cộng hưởng | Exiton |
|---|---|---|
| Cái gì di chuyển | Năng lượng kích thích (không có điện tích tách ra) | Cặp điện tử – lỗ trống |
| Môi trường điển hình | Dung dịch | Cấu trúc giống tinh thể (màng sắc tố) |
| Điều kiện | Chất cho phát quang; phổ chồng nhau; đủ gần | Cấu trúc trật tự; có "bẫy" |
| Ví dụ | Hệ A → B phát quang | Diệp lục, rodopsin |

## 2. Quang hợp

Quang hợp là ví dụ điển hình của **phản ứng sinh lý chức năng loại tạo và tích lũy năng lượng** (tr. 272). Đó là hiệu ứng do ánh sáng gây ra, trong đó **CO~2~ bị khử** tạo **hydrat carbon** và **giải phóng O~2~**. Gồm hai chuỗi phản ứng nối tiếp:

- **Phản ứng sáng**: xảy ra nhanh, cần ánh sáng.
- **Phản ứng tối**: chậm hơn, **không phụ thuộc** ánh sáng.

Sơ đồ tổng quát ở lục lạp (công thức 8.2):

=> CO~2~ + 2H~2~O + n·hf → (CH~2~O) + O~2~ + H~2~O

- **(CH~2~O)**: đơn vị hydrat carbon tạo thành; **n·hf**: n photon, mỗi photon năng lượng hf.
- Vế trái có **2 phân tử nước** để cho thấy **O~2~ giải phóng lấy từ nước**, không phải từ CO~2~. Thí nghiệm dùng nước đánh dấu bằng **oxy phóng xạ** (đồng vị) đã chứng minh điều này.

**Quang hợp là quá trình truyền điện tử.** Phản ứng cơ bản là chuyển nguyên tử H từ H~2~O sang CO~2~. Việc chuyển H (H → H^+^ + e^−^) gồm 2 bước: chuyển **điện tử** trước, rồi chuyển **proton**. Bước chuyển điện tử tốn năng lượng; còn proton thì trong tế bào luôn sẵn. Tốc độ hấp thụ CO~2~ (bằng tốc độ thải O~2~) phụ thuộc cường độ ánh sáng.

**Cần tối thiểu bao nhiêu photon?** (tr. 273)

- Năng lượng khử 1 phân tử CO~2~ đến hydrat carbon: khoảng **112 kcal/mol ≈ 4,9 eV/phân tử**.
- Quang hợp đặc biệt hiệu quả với ánh sáng đỏ **λ = 7000 Å = 700 nm**. Năng lượng 1 photon:

=> ε = hc/λ = 1240 eV·nm / 700 nm ≈ 1,77 eV

=> số photon tối thiểu = 4,9 / 1,77 ≈ 2,8 → thực tế **không ít hơn 3 photon**

- Hiệu suất lượng tử thực đo được của quang hợp khoảng **1/8 đến 1/4**, tức quang hợp sử dụng năng lượng **khá hiệu quả**. Xác định chính xác rất khó vì phải đo đúng thành phần, lượng khí hấp thụ và thải ra.

> [!bay] Mẹo đổi đơn vị
> - 1 Å = 10^−10^ m = 0,1 nm ⇒ 7000 Å = 700 nm = 0,7 µm.
> - ε (eV) ≈ **1240 / λ (nm)**. Ví dụ λ = 500 nm → ε ≈ 2,48 eV.
> - 1 eV = 1,6·10^−19^ J.

**Vai trò của diệp lục** (chlorophyll):

- Qua **phổ tác dụng** của quang hợp, biết được **diệp lục là sắc tố cơ bản, không thể thiếu**; các sắc tố khác có thể tham gia phụ.
- Diệp lục nằm trong **hạt lục lạp**; theo sách mỗi hạt chứa khoảng 100 phân tử diệp lục. Sự **sắp xếp tương hỗ** giữa diệp lục, protein, lipid trong hạt quyết định hiệu quả quang hợp.
- Đặc điểm cấu tạo quan trọng nhất: **hệ liên kết đôi liên hợp** (**chất mang màu**). Hệ này tạo một **đám mây điện tử chung**, nhờ đó sắc tố hấp thụ được photon có bước sóng xác định, dự trữ năng lượng và **truyền** năng lượng tới các nguyên tử gần nhau. Phản ứng oxy hóa – khử là do **toàn bộ hệ liên hợp**, không phải từng nguyên tử riêng.
- Về năng lượng: quang hợp **tăng năng lượng tự do, giảm entropi** của hệ. Điều này không trái định luật 2 nhiệt động học vì cây là **hệ mở**, trao đổi vật chất và năng lượng với môi trường (xem bài nhiệt động học).

> [!cap-nhat] Số photon thật sự của quang hợp
> Ngày nay biết quang hợp ở thực vật dùng **hai hệ quang hóa** (PS II và PS I) mắc nối tiếp. Giải phóng 1 phân tử O~2~ (cố định 1 CO~2~) cần **khoảng 8–10 photon**. Con số này khớp với hiệu suất lượng tử 1/8 của sách và với dòng "10 photon/phân tử O~2~" trong Bảng 8.1. Con số "3 photon" chỉ là **giới hạn lý thuyết tối thiểu** tính từ năng lượng.

## 3. Sinh tổng hợp sắc tố và vitamin D

Trong chuỗi phản ứng sinh tổng hợp nhiều **sắc tố** và **vitamin**, có những bước **quang hóa**. Thiếu lượng tử ánh sáng thì các chất này **không tổng hợp được** (tr. 274).

- Khác với quang hợp, ở đây năng lượng ánh sáng **cung cấp năng lượng cho phản ứng**, chứ **không được dự trữ** trong sản phẩm.
- Giai đoạn quang hóa thường nằm **ở giữa hoặc ở cuối** chuỗi tổng hợp.
- Ánh sáng còn có thể **cảm ứng tổng hợp (tăng tính nhạy cảm) các enzym** của chuỗi.

**Ví dụ của sách: tổng hợp vitamin D~2~** (tr. 274)

- Giai đoạn cuối có bản chất quang hóa: **provitamin D → vitamin D**. Phản ứng **không cần chất mang protein**, xảy ra hiệu quả ngay trong dung dịch provitamin.
- Các chất trong sơ đồ: **E – ergosterol** (provitamin D~2~), **P – preergocalciferol**, **D – ergocalciferol** (vitamin D~2~), **L – lumisterol**, **T – tachysterol**, X – sản phẩm không đồng nhất. Mỗi mũi tên có một hiệu suất lượng tử riêng (ví dụ E → P: 0,26; T → L: 0,33; L → P: 0,41).
- Chiếu bất kỳ tiền chất nào (E, L, T, P) cũng dẫn tới vitamin D~2~; giữa các chất có **trạng thái dừng** (cân bằng).
- Bản chất phản ứng quang hóa chính: **tia tử ngoại cắt liên kết C9 – C10** trong vòng của ergosterol (và lumisterol), mở vòng để tạo previtamin.

> [!bay]
> - Giáo trình viết "vòng benzol". Thật ra vòng B của sterol **không phải vòng benzen** (không thơm); chỉ cần nhớ: **UV cắt liên kết C9 – C10, mở vòng B**.
> - Giáo trình có câu "trong dung dịch provitamin D~2~ là ergocalciferol" dễ gây nhầm. **Provitamin D~2~ là ergosterol**; ergocalciferol là **vitamin D~2~** (sản phẩm).

> [!cap-nhat] Vitamin D ở người
> - Da người tổng hợp **vitamin D~3~ (cholecalciferol)** từ **7-dehydrocholesterol** dưới tác dụng của **UVB** (khoảng 290–315 nm): UVB mở vòng → **previtamin D~3~** → đồng phân hóa do nhiệt (thân nhiệt) → vitamin D~3~. Vitamin D~2~ (từ ergosterol) có ở **nấm, men**.
> - Vitamin D~3~ sau đó được hydroxyl hóa ở **gan** (25-OH-D) rồi ở **thận** (1,25-(OH)~2~-D, dạng hoạt động), giúp **hấp thu calci, phospho** ở ruột.
> - Vì phản ứng cần UVB, nên: kem chống nắng, kính cửa sổ (chặn gần hết UVB), da sẫm màu, người cao tuổi, mùa đông/vĩ độ cao đều làm **giảm** tổng hợp vitamin D. Phơi nắng quá lâu **không** gây ngộ độc vitamin D vì previtamin D~3~ thừa bị chính ánh sáng chuyển thành **lumisterol, tachysterol** không hoạt tính — đúng các chất có trong sơ đồ của sách.

> [!ung-dung] Chiếu đèn trị vàng da sơ sinh — một phản ứng quang hóa có ích
> Trẻ sơ sinh dễ tăng **bilirubin** tự do (không tan trong nước) do gan chưa liên hợp kịp. Chiếu **ánh sáng xanh lam (khoảng 460–490 nm)** — đúng đỉnh hấp thụ của bilirubin trong da — gây ra **đồng phân hóa quang học** (tạo đồng phân cấu hình và **lumirubin**). Sản phẩm **tan trong nước**, thải qua mật và nước tiểu **không cần gan liên hợp**. Khi chiếu: che mắt trẻ, bộc lộ da tối đa, theo dõi thân nhiệt và bù nước. Đây là ví dụ thực tế của "phổ tác dụng phải trùng phổ hấp thụ" (mục 1.3).

> [!vi-du] Nấm phơi nắng giàu vitamin D~2~
> Nấm chứa nhiều **ergosterol** — chính là chất E trong sơ đồ của sách. Nấm tươi phơi nắng hoặc chiếu UV một thời gian ngắn thì hàm lượng **vitamin D~2~ tăng rõ rệt**. Đây là minh họa trực tiếp của phản ứng quang hóa provitamin D → vitamin D.

## 4. Tác dụng quang động lực (TDQĐL)

### 4.1. Khái niệm và điều kiện

**Định nghĩa** (tr. 275): tác dụng quang động lực là **tổn thương không hồi phục** một số chức năng sinh lý và cấu trúc của đối tượng sinh vật **dưới tác dụng của ánh sáng, khi có mặt O~2~ và chất hoạt hóa**. Đây là ví dụ của nhóm **phá hủy biến tính**.

- Tác dụng của ánh sáng ở đây là **gián tiếp**: ánh sáng kích thích chất hoạt hóa, chất hoạt hóa đóng vai trò **chất xúc tác không thể thiếu**.
- **Ba yếu tố cùng có mặt**: **chất màu + ánh sáng + O~2~** là điều kiện cần (tuy đôi khi phản ứng xảy ra không cần O~2~).

**Chất hoạt hóa (chất màu, chất cảm quang)** có đặc điểm chung:

- **Ái lực hóa học lớn với O~2~**, nhỏ với chất khử.
- Cấu trúc **vòng**, có **liên kết đôi**.
- Có khả năng **lân quang**: giữ năng lượng hấp thụ khá lâu (**không nhỏ hơn 10^−9^ s**). Nhờ đó gọi là chất màu.
- Ví dụ trong sách: **eozin, erythrosin, methylen xanh, benzoflavin, porphyrin**.

Đặc điểm của TDQĐL:

- **Mọi sinh vật** (động vật có hoặc không xương sống, thực vật thấp đến cao) đều nhạy cảm. **Chức năng nào cũng có thể bị tổn thương**: phân bào, quang hợp, hô hấp, phosphoryl hóa, cấu trúc enzym và acid nucleic, tính thấm màng, nhiệt độ, huyết áp…
- Ban đầu chỉ một hay vài chức năng **nhạy nhất** ("chỗ yếu") bị tổn thương, rồi kéo theo phá hủy hàng loạt, có thể đến **chết tế bào hoặc cơ thể**. Cấu trúc nào bị trước tiên phụ thuộc **bản chất chất màu** và **đặc điểm đối tượng**.
- Điều quyết định là **chất màu thâm nhập vào tế bào**. Do đó **phổ tác dụng của TDQĐL khá trùng với phổ hấp thụ của chất màu** (đã được chứng minh).

### 4.2. Cơ chế — vai trò của trạng thái triplet

Chuỗi sự kiện bắt đầu bằng **kích thích chất màu**. Tham gia trực tiếp vào phản ứng quang hóa thứ cấp **không phải trạng thái singlet mà là trạng thái triplet** (T~1~) — trạng thái sống lâu hơn, đủ thời gian gặp cơ chất hoặc O~2~.

Ký hiệu: S~0~ – chất màu ở trạng thái cơ bản; S~1~\* – singlet kích thích; T~1~ – triplet; RH~2~ – cơ chất (chất nền); P – cơ chất bị oxy hóa; O~2~\* – oxy kích thích (thường là oxy singlet).

| Cơ chế | Điểm mấu chốt | Sơ đồ rút gọn |
|---|---|---|
| 1 | T~1~ chuyển năng lượng cho **cơ chất**; cơ chất kích thích bị O~2~ oxy hóa | T~1~ + RH~2~ → S~0~ + RH~2~\*; RH~2~\* + O~2~ → P |
| 2 | T~1~ lấy H của cơ chất (**chất màu bị khử**), rồi chất màu khử bị O~2~ oxy hóa, sinh **H~2~O~2~** | T~1~ + RH~2~ → S~0~H~2~ + R; S~0~H~2~ + O~2~ → S~0~ + H~2~O~2~ |
| 3 | T~1~ chuyển năng lượng cho **O~2~** → **oxy singlet** oxy hóa cơ chất | T~1~ + O~2~ → S~0~ + O~2~\*; RH~2~ + O~2~\* → P |
| 4 | T~1~ kết hợp O~2~ thành **phức chất màu – O~2~** (S~0~OO), phức này oxy hóa cơ chất | T~1~ + O~2~ → S~0~OO; RH~2~ + S~0~OO → P + S~0~ |
| 5 | Chất màu **gắn với cơ chất trước** (phức S~0~RH~2~), phức được kích thích lên triplet rồi phản ứng với O~2~ | S~0~ + RH~2~ → S~0~RH~2~; T~1~RH~2~ + O~2~ → S~0~ + P |

Bước đầu của cả 5 cơ chế giống nhau:

=> S~0~ + hf → S~1~\* → T~1~

Nhận xét của sách (tr. 276–277):

- Chất màu đóng vai trò **xúc tác quang hóa ở trạng thái triplet** và **được tái tạo** (trở về S~0~) ở cuối phản ứng.
- Trong các sơ đồ, **O~2~ là bắt buộc**: phản ứng với cơ chất kích thích (do di chuyển năng lượng), với chất màu triplet, hoặc oxy bị kích thích phản ứng với cơ chất.
- Phản ứng sơ cấp dẫn tới **biến đổi oxy hóa – khử**, thường qua trung gian **gốc tự do**. In vitro, hầu hết acid hữu cơ, indol, ceton, amin, ester, phenol, acid amin (amino acid) thơm (tryptophan, tyrosin, cystein, methionin…), pyrimidin, purin, nucleotid, hormon, acid nucleic và protein đều bị oxy hóa theo đường này.

**Sơ đồ tổng quát** (tr. 278):

=> Ánh sáng → chất cảm ứng → triplet của chất cảm ứng → oxy hóa cơ chất (thường cần O~2~) → quang sản phẩm → biến đổi cấu trúc vi mô → hiệu ứng sinh vật

> [!bay]
> - Trạng thái tham gia phản ứng là **triplet**, không phải singlet. Singlet sống quá ngắn.
> - Chất màu là **xúc tác**: nó **không bị tiêu hao** sau một chu trình (được tái tạo về S~0~), nên một lượng nhỏ chất màu gây được tổn thương lớn.
> - Phổ tác dụng của TDQĐL trùng với phổ hấp thụ **của chất màu**, không phải của protein hay ADN.

### 4.3. Các biểu hiện của TDQĐL

**Lên protein và acid nucleic** (tr. 277)

- Làm **giảm hoạt tính enzym**, ức chế **tính kháng nguyên**, do thay đổi **mạch bên** của acid amin. Ví dụ: **methylen xanh** + ánh sáng làm giảm hoạt tính **trypsin** do oxy hóa mạch bên của **histidin**.
- Làm **giảm độ hòa tan, tăng độ nhớt** của protein máu và sắc tố globulin.
- Actomyosin + **erythrosin** + ánh sáng → chuyển sang **trạng thái gel**; khuấy lên lại lỏng. ATP + erythrosin cũng tương tự.
- Acid nucleic: **giảm độ nhớt và khả năng lắng**, do phá hủy cấu trúc **guanin** (khử polyme), thay đổi nhiệt độ phân hủy ADN. Ví dụ: ADN virus khảm thuốc lá **mất khả năng nhiễm độc**. Hướng chế **vaccin** bằng TDQĐL còn khó vì chất màu khó qua vỏ protein của virus.

**Lên dược chất** (tr. 277)

- **Sulfonamid**: một tác dụng phụ là **tăng porphyrin trong máu**; khi da bị chiếu sáng có thể gây **rối loạn thần kinh**.
- **Barbiturat** (thuốc ngủ, an thần như sevenal, luminal) và một số **kháng histamin**: bệnh nhân **phải kiêng ra nắng**, vì porphyrin trong máu dưới ánh nắng gây rối loạn enzym, triệu chứng giống **nhiễm độc chì**, rối loạn da và thần kinh.

**Lên cơ và thần kinh** (tr. 277–278)

- Năm **1917, Viale**: phủ **eozin** hoặc **benzoflavin** lên mặt ngoài tim ếch rồi chiếu sáng → **tăng biên độ và tần số** co bóp. Năm **1959, Santa Maria**: kết quả tương tự với tim chuột nhắt dưới chất hoạt hóa + ánh sáng nhìn thấy.
- Tim ếch ngâm **Ringer không có K^+^** sẽ ngừng ở giai đoạn tâm trương; nhỏ eozin (nồng độ **10^−6^ – 10^−5^ g/ml**) và chiếu sáng thì sau vài phút **tim lại co bóp**.
- Dây thần kinh đùi ếch phủ eozin: trong lúc chiếu sáng, **một xung kích thích** có thể gây ra **cả một dãy** điện thế hoạt động.

**Lên cơ thể sinh vật** (tr. 278)

- Tế bào và mô nuôi cấy: thay đổi tốc độ phân chia, rối loạn trao đổi chất, **chết tế bào**.
- Thực vật: rối loạn trước hết là **quang hợp**, có thể chết tế bào.
- **Gia súc** (ngựa, lợn rừng, dê…) ăn phải **cây có chất hoạt hóa** → **xạm hoặc loét da, rụng lông**.
- Nhiều chất hoạt hóa có khả năng **gây ung thư**: chiếu ánh sáng mạnh vào chuột đã tiêm **porphyrin** hoặc **eozin** → **ung thư da**. Ở người già, **porphyrin** (sản phẩm của quá trình tạo hồng cầu và hemoglobin) không bị phân hủy hết mà tích lại dưới da, nên tỷ lệ ung thư da ở người già cao hơn (theo giáo trình).

> [!ung-dung] Từ TDQĐL đến liệu pháp quang động (PDT) và nhạy cảm ánh sáng do thuốc
> - **Liệu pháp quang động (Photodynamic therapy – PDT)** dùng đúng ba yếu tố của TDQĐL một cách có chủ đích: đưa **chất cảm quang** (dẫn xuất porphyrin, hoặc **acid 5-aminolevulinic (5-ALA)** để tế bào tự tạo protoporphyrin IX) tích tụ chọn lọc ở mô bệnh, rồi chiếu ánh sáng **đúng phổ hấp thụ** của chất đó. Chất cảm quang ở trạng thái triplet tạo **oxy singlet** (cơ chế 3) và gốc tự do, tiêu diệt tế bào đích. Dùng trong **dày sừng quang hóa, ung thư biểu mô tế bào đáy nông** ở da, một số ung thư thực quản, phế quản; **verteporfin** từng dùng cho thoái hóa hoàng điểm thể ướt.
> - Sau PDT bằng chất cảm quang toàn thân, người bệnh phải **tránh ánh sáng mạnh** nhiều ngày (có thể đến vài tuần), vì da cũng chứa chất cảm quang.
> - **Nhạy cảm ánh sáng do thuốc** (phản ứng quang độc): **tetracyclin (nhất là doxycyclin), fluoroquinolon, sulfonamid, thiazid, amiodaron, phenothiazin**, một số NSAID… Biểu hiện như **bỏng nắng nặng** ở vùng da hở. Dặn người bệnh **che chắn, dùng kem chống nắng phổ rộng**.
> - Bệnh **porphyria** (rối loạn tổng hợp hem): porphyrin ứ đọng trong da gây **phỏng nước, sẹo ở vùng da hở** khi ra nắng — một TDQĐL "nội sinh".

> [!yhct] Dược liệu chứa furocoumarin — gây nhạy cảm ánh sáng
> - **Furocoumarin** (psoralen và dẫn xuất) là chất cảm quang thực vật, hấp thụ mạnh **UVA**. Khi được kích thích, chúng gắn vào ADN (tạo cầu nối với base pyrimidin) và tạo gốc tự do, gây **viêm da quang độc**: đỏ, phỏng nước, sau đó **tăng sắc tố** kéo dài. Một phần cơ chế **không cần O~2~** — đúng như giáo trình lưu ý TDQĐL "đôi khi không cần O~2~".
> - Có trong: **Bạch chỉ** (*Angelica dahurica*; imperatorin, isoimperatorin…), **Bổ cốt chỉ** (*Psoralea corylifolia*; psoralen, isopsoralen), các cây họ Hoa tán (Apiaceae) như **Độc hoạt, Xà sàng tử**, và vỏ quả **chanh, bưởi** (viêm da khi vắt chanh rồi ra nắng). Mức furocoumarin trong từng vị khác nhau và chưa chuẩn hóa.
> - Về y học hiện đại: **methoxsalen (8-MOP)** + **UVA** (**PUVA**) là phương pháp đã chứng minh hiệu quả cho **bạch biến, vảy nến**. Bổ cốt chỉ được dùng trong dân gian bôi trị bạch biến dựa trên cùng cơ chế; nhưng bôi/uống dược liệu **không chuẩn liều** rồi phơi nắng dễ gây **bỏng nặng**. Thực hành an toàn: người đang dùng các vị này liều cao (uống hoặc bôi) nên **tránh nắng gắt**, nhất là khi đang dùng thêm thuốc gây nhạy cảm ánh sáng.
> - Còn công dụng "khu phong, chỉ thống" của Bạch chỉ hay "bổ thận dương" của Bổ cốt chỉ là **quan niệm YHCT**, không liên quan cơ chế quang động.

## 5. Tác dụng của tia tử ngoại lên các hệ thống sống

Tia tử ngoại (UV) của Mặt Trời ảnh hưởng tới hầu hết quá trình trao đổi chất và chức năng sinh lý của sinh vật (tr. 278).

### 5.1. Ba vùng tử ngoại theo giáo trình

| Vùng (giáo trình) | Bước sóng | Tác dụng chính theo sách |
|---|---|---|
| **Sóng ngắn** | 100 – 275 nm | Thay đổi cấu trúc protein, lipid; **diệt trùng** |
| **Sóng trung** | 275 – 320 nm | **Chống còi xương**, **tạo sắc tố**, thúc đẩy tạo biểu mô, tái sinh tốt hơn |
| **Sóng dài** | 320 – 400 nm | Tác dụng sinh vật **yếu**; gây **phát quang** một số chất hữu cơ |

![Hình 2. Các vùng tử ngoại và độ xuyên qua da](uv-xuyen-da.svg)

> [!cap-nhat] Cách chia UVA – UVB – UVC hiện hành
> Giáo trình chia 100–275 / 275–320 / 320–400 nm. Hiện nay theo quy ước quốc tế (CIE, WHO):
>
> | Vùng | Bước sóng | Đi tới mặt đất? | Xuyên da | Tác dụng nổi bật |
> |---|---|---|---|---|
> | **UVC** | 100 – 280 nm | **Không** (tầng ozon hấp thụ hết) | Lớp sừng, thượng bì nông | Diệt khuẩn (đèn 254 nm); hại mắt, da khi tiếp xúc nguồn nhân tạo |
> | **UVB** | 280 – 315 nm | Một phần (≈ 5% UV tới mặt đất) | **Thượng bì** | **Bỏng nắng**, tổng hợp **vitamin D**, tổn thương ADN trực tiếp, ung thư da |
> | **UVA** | 315 – 400 nm | Phần lớn (≈ 95%) | Tới **trung bì** | **Lão hóa da**, sạm da tức thì, gốc tự do, góp phần ung thư da; xuyên qua kính cửa sổ |
>
> Đi thi: dùng mốc của giáo trình.

### 5.2. Cơ chế tác dụng lên acid nucleic và protein

Tử ngoại gây phản ứng quang sinh **phá hủy acid nucleic và protein** (tr. 279):

- Một phần do **phản ứng thứ cấp**: enzym của tế bào phá vỡ protein đã biến tính, tích tụ các sản phẩm phân hủy, trong đó có **histamin**. Chúng kích thích đầu dây thần kinh, gây phản xạ phức tạp (đây là cơ sở của **ban đỏ** sau phơi nắng).
- Với **acid nucleic**: UV đủ mạnh gây **nhị trùng (dimer) các gốc thymin** và **hydrat hóa các gốc cytosin**.
- Với **protein**: UV phá hủy **acid amin thơm (tyrosin, tryptophan)** → protein biến tính, enzym mất hoạt tính, qua 4 giai đoạn:

| Giai đoạn | Diễn biến | Phương trình |
|---|---|---|
| 1. **Tích cực** (kích thích) | Acid amin hấp thụ photon lên trạng thái kích thích; có thể trở về bằng cách phát sáng với tần số thấp hơn | AH + hf~1~ → AH*; AH* → AH + hf~2~ (f~2~ < f~1~) |
| 2. **Quang ion hóa** | Phân tử kích thích mất điện tử → gốc ion dương; điện tử bị nước bao quanh (**solvat hóa**); ion phân hủy thành gốc tự do + proton | AH* → AH^+^ + e~s~^−^; AH^+^ → A• + H^+^ |
| 3. **Phản ứng của gốc tự do và điện tử solvat** | Gốc tự do + O~2~ → gốc peroxid; điện tử solvat phản ứng với nhóm bên, giải phóng NH~3~ (sự **tăng nhạy**) | A• + O~2~ → AOO• |
| 4. **Phá hủy acid amin** | Các gốc oxid của acid amin thơm tạo sản phẩm độc; protein đổi cấu hình, **enzym mất hoạt tính** | — |

- Giai đoạn 1–2 xảy ra **rất nhanh**, chỉ nghiên cứu được bằng **quang phân tạo xung** hoặc ở **nhiệt độ thấp**.
- Ion dương có thể **tái hợp** với điện tử solvat (do ánh sáng hoặc nhiệt) tạo lại phân tử kích thích, rồi phát sáng: do ánh sáng gọi là **phát quang cảm ứng**, do nhiệt gọi là **nhiệt phát quang**.

=> AH^+^ + e~s~^−^ → AH* → AH + hf~1~

### 5.3. Ý nghĩa sinh học và ứng dụng theo giáo trình

- **Diệt khuẩn**: UV liều lớn khống chế khả năng sinh sản của vi khuẩn, chủ yếu do **tổn thương ADN** của virus và vi khuẩn.
- Giáo trình nhấn mạnh tác dụng "chủ yếu" của UV là **nâng cao tính phản ứng miễn dịch** (tr. 280).
- Giá trị đặc biệt: **tạo vitamin D**. Thiếu vitamin D → rối loạn trao đổi **phospho, calci**. Vì thế chiếu UV dùng trong điều trị **còi xương**, giúp **vết thương chóng liền sẹo**, **xương gãy chóng liền**.

> [!cap-nhat] UV, miễn dịch và ung thư da
> - Hiện nay đã rõ UV (đặc biệt UVB) **ức chế miễn dịch tại da** chứ không "nâng cao miễn dịch" một cách đơn giản. Chính tác dụng ức chế miễn dịch này được dùng trong **quang trị liệu UVB dải hẹp (311 nm)** cho **vảy nến, chàm, bạch biến**.
> - Cơ quan Nghiên cứu Ung thư Quốc tế (IARC/WHO) xếp **bức xạ tử ngoại** (Mặt Trời và giường nhuộm da) vào **nhóm 1 – chắc chắn gây ung thư ở người**. UVB gây **dimer pyrimidin** (đúng "nhị trùng thymin" của sách); nếu không được sửa chữa, đột biến tích lũy (ví dụ ở gen p53) → **ung thư biểu mô tế bào đáy, tế bào vảy, u hắc tố (melanoma)**.
> - Nắng gắt nhất khoảng 10 h – 16 h; theo dõi **chỉ số UV**: từ 3 trở lên nên che chắn, từ 8 trở lên hạn chế ra ngoài.

> [!ung-dung] Kem chống nắng và đèn UV diệt khuẩn
> - **SPF** đo khả năng chống **UVB** (chống bỏng nắng). Dùng đủ lượng chuẩn khoảng 2 mg/cm², SPF 30 chặn khoảng **97%** UVB, SPF 50 khoảng **98%** — SPF tăng gấp đôi không có nghĩa là chặn gấp đôi.
> - Chống **UVA** ghi bằng **PA+ … PA++++** hoặc nhãn "**phổ rộng**" (broad-spectrum). Muốn phòng lão hóa và ung thư da phải chọn kem **phổ rộng**, thoa lại sau 2 giờ hoặc sau khi ra mồ hôi, bơi.
> - Hai cơ chế lọc: **vô cơ** (ZnO, TiO~2~ — phản xạ, tán xạ và hấp thụ) và **hữu cơ** (hấp thụ UV, đổi thành nhiệt).
> - **Đèn UV diệt khuẩn** (UVC 254 nm) dùng khử khuẩn không khí, bề mặt phòng mổ, tủ an toàn sinh học, nước. Chỉ diệt được nơi **tia chiếu thẳng tới** (bóng che, bụi làm giảm hiệu quả). **Tuyệt đối không bật khi có người**: UVC gây **viêm giác mạc quang** (đau, cộm như cát vào mắt sau vài giờ) và bỏng da. Mắt cũng bị như vậy khi **hàn điện không đeo kính** hoặc đi tuyết ("mù tuyết").

> [!yhct] Phơi dược liệu: UV và nhiệt tác động lên hoạt chất
> - Cơ chế vật lý đã rõ: phơi nắng là tác dụng đồng thời của **nhiệt** (bức xạ hồng ngoại, làm nóng, bay hơi nước) và **tử ngoại**. Năng lượng photon UV (3–4,4 eV với UVA/UVB) đủ để **phá liên kết đôi liên hợp** — chính là hệ "chất mang màu" đã học ở mục 2. Vì vậy các **sắc tố** (diệp lục, carotenoid, anthocyanin, một số flavonoid) dễ bị **phai màu, phân hủy quang hóa**; nhiều thành phần **tinh dầu** (terpen có liên kết đôi) bị **oxy hóa quang hóa** và **bay hơi** nhanh khi nóng.
> - Đó là cơ sở của quy tắc trong bào chế: các vị **giàu tinh dầu** (như **Bạc hà, Kinh giới, Tía tô, Hương nhu**) và nhiều loại **hoa** (như **Kim ngân hoa**) thường được **phơi âm can** (phơi trong râm, nơi thoáng gió) hoặc **sấy ở nhiệt độ thấp** để giữ mùi, giữ màu và hoạt chất. Bảo quản trong **bao bì kín, tránh ánh sáng** (lọ màu hổ phách, túi tối màu) cũng cùng lý do.
> - Mặt có lợi: nắng giúp **khô nhanh, hạn chế nấm mốc**, và UV có tác dụng diệt khuẩn bề mặt — phù hợp với các vị **ít tinh dầu, nhiều xơ** (rễ, thân gỗ).
> - Mức độ hao hụt cụ thể phụ thuộc từng vị và từng hoạt chất; nhiều quy định phơi sấy dựa trên **kinh nghiệm bào chế** và một phần nghiên cứu định lượng, nên cần tuân theo **Dược điển** và quy trình chế biến của từng vị.

## 6. Thông tin thụ cảm ánh sáng — thị giác

Ánh sáng mang thông tin về môi trường tới sinh vật: hoa hướng dương quay theo Mặt Trời, nhiều loài hoa nở theo giờ, vi khuẩn phản ứng khi chiếu sáng… **Mắt** là cơ quan hoàn chỉnh nhất để thu nhận ánh sáng, phân tích thành phần (cường độ, bước sóng) và tạo xung thần kinh lên não. **Phản ứng quang hóa phân hủy sắc tố thị giác, sinh xung thần kinh lên dây thần kinh thị giác để tạo cảm giác sáng, là một phản ứng thông tin** (tr. 280).

### 6.1. Cơ sở phân tử của sự thụ cảm ánh sáng

**Sắc tố thị giác**

| Tế bào | Sắc tố | Cấu tạo |
|---|---|---|
| **Que** | **Rodopsin** | Retinal + protein **scotopxin** |
| **Nón** | **Iodopsin** | Retinal + protein **fotopxin** |

=> Rodopsin ⇌ Scotopxin + Retinal

=> Iodopsin ⇌ Fotopxin + Retinal

- Rodopsin là phức chất protein, **phân tử lượng khoảng 40 000**.
- **Retinal là aldehyd của vitamin A~1~**. Vitamin A~1~ gồm một **vòng** và **mạch bên 9 carbon**, đánh số C1 → C15; loại cấu trúc này thuộc nhóm **carotenoid** (có nhiều trong cà rốt). Vitamin A~1~ có nhóm **–CH~2~OH** (rượu) ở C15; retinal có nhóm **–CHO** ở C15.
- Theo sách: scotopxin và fotopxin có nhóm **sulfhydryl (–SH)**; C15 của retinal gắn với 2 nguyên tử S của scotopxin tạo rodopsin, giải phóng 1 phân tử nước (Hình 8.4, tr. 281).

**Chu trình rodopsin** (Hình 8.5, tr. 282)

1. Ánh sáng chiếu vào → rodopsin **phân ly** thành scotopxin và retinal. **Một photon** ánh sáng nhìn thấy đủ phân hủy **một** phân tử rodopsin.
2. Sản phẩm đầu tiên là **lumirodopxin** (không bền ở nhiệt độ thường) → **metarodopxin I** → **metarodopxin II** (màu da cam) → cuối cùng thủy phân thành **opxin + trans-retinal (màu vàng)**.
3. Trans-retinal và opxin có thể chuyển thành retinal và opxin, hoặc thành **vitamin A** ở dạng tự do hay dạng ester, dự trữ ở **lớp tế bào sắc tố biểu mô**.
4. **Trong tối**, rodopsin được **tổng hợp lại** khá nhanh nhờ năng lượng hóa sinh; retinal mới từ vitamin A và ester của nó ở tế bào sắc tố biểu mô chuyển vào tế bào que.

- Trong quá trình phân tích, **quang năng → hóa năng**. Phản ứng quang hóa làm xuất hiện **điện thế hoạt động**, thay đổi điện trở, tính thấm màng; ghi được **dòng điện võng mạc** (điện võng mạc đồ).
- Kính hiển vi điện tử cho thấy rodopsin tập trung trong tế bào que, xếp thành các **đĩa** đều đặn. Có giả thuyết các đĩa này hoạt động như **lớp bán dẫn**, biến quang năng thành điện năng.

> [!ung-dung] Vitamin A và quáng gà
> Tái tạo rodopsin cần retinal từ **vitamin A**. Khi **thiếu vitamin A** (ăn thiếu, kém hấp thu chất béo, bệnh gan) hoặc bệnh võng mạc làm tế bào que mất tiếp xúc với lớp sắc tố biểu mô, lượng rodopsin giảm → **quáng gà** (nhìn kém lúc chạng vạng, trong tối). Thiếu nặng → khô mắt, **khô giác mạc**, loét giác mạc, có thể mù. Việt Nam đã có chương trình **bổ sung vitamin A** liều cao cho trẻ nhỏ để phòng bệnh này.

> [!cap-nhat] Cơ chế thụ cảm ánh sáng hiện nay
> - Giáo trình mô tả retinal gắn với 2 nhóm –SH. Hiện nay biết **11-cis-retinal** gắn với một gốc **lysin** của opsin qua **liên kết base Schiff**.
> - Bước quang hóa duy nhất là **đồng phân hóa 11-cis → all-trans-retinal** (xảy ra trong khoảng 200 femto giây). Phần còn lại (lumi-, meta-rodopsin) là các phản ứng tối.
> - **Metarodopsin II** hoạt hóa protein G **transducin** → hoạt hóa **phosphodiesterase** → giảm **cGMP** → **đóng kênh Na^+^** → tế bào que **ưu phân cực** (không phải khử cực). Một rodopsin hoạt hóa có thể làm thủy phân hàng chục nghìn phân tử cGMP: đây chính là "**cơ quan khuếch đại**" mà giáo trình nhắc ở mục 1.2.
> - Đĩa của tế bào que có đường kính khoảng 1–2 µm; mỗi tế bào que có cỡ 1000 đĩa.

### 6.2. Ngưỡng nhìn

**Ngưỡng thị giác (ngưỡng nhìn)** = **số photon tối thiểu** tế bào que phải hấp thụ để gây ra **cảm giác sáng** (tr. 283).

Ngưỡng nhìn phụ thuộc: **bước sóng**, **kích thước vật sáng**, **đường kính đồng tử**, **thời gian chiếu**…

**Phép đo cổ điển** (giáo trình ghi tên nhà sinh lý học **Hess**): dùng bước sóng mắt nhạy nhất, vật sáng nhỏ, mắt đã thích ứng tối, chiếu thời gian ngắn. Khoảng **4/5 số photon bị mất** trên đường từ giác mạc đến tế bào que (phản xạ, hấp thụ ở môi trường trong suốt, không trúng sắc tố):

=> ngưỡng nhìn = 150 − 150 × 4/5 = 30 photon

Các phép đo về sau (20–30 năm) và đo trực tiếp trên **mắt cua** (một sợi thần kinh nối với một "yếu tố cảm sáng") cho kết quả **ngưỡng nhìn chỉ khoảng 1–2 photon**.

Năng lượng của 1 photon ở λ = 0,5 µm:

=> ε = h·c/λ = (6,62·10^−34^ J·s × 3·10^8^ m/s) / (5·10^−7^ m) ≈ 4·10^−19^ J ≈ 2,5 eV

- h: hằng số Planck (J·s); c: tốc độ ánh sáng (m/s); λ: bước sóng (m).
- Năng lượng này đủ **cắt các liên kết yếu**, làm đổi cấu trúc rodopsin, khởi phát xung thần kinh.

> [!cap-nhat] "Hess" hay "Hecht"?
> Thí nghiệm kinh điển đo ngưỡng nhìn là của **Hecht, Shlaer và Pirenne (1942)**: khoảng 54–148 photon tới giác mạc, chỉ khoảng 5–14 photon được tế bào que hấp thụ, và **một tế bào que đáp ứng được với 1 photon**. Giáo trình ghi "Hess" và con số 150 → 30. Đi thi dùng con số của sách.

**Thị giác ngày và thị giác tối**

| | **Thị giác ngày (Photo)** | **Thị giác tối (Scoto, hoàng hôn)** |
|---|---|---|
| Độ rọi | Lớn | Nhỏ |
| Tế bào tham gia | **Que và nón** | **Chỉ que** |
| Ngưỡng nhìn | Cao hơn (nón kém nhạy) | **Thấp** (que rất nhạy) |
| Cực đại độ nhạy | **555 nm** (xanh lá mạ) | **510 nm** |
| Phân biệt màu | Có | **Không** |
| Trùng phổ hấp thụ của | **Iodopsin** | **Rodopsin** |

**Thích ứng sáng – tối** (tr. 284–285): rodopsin ở cân bằng động **phân tích ⇌ tổng hợp**.

- **Độ rọi tăng** → phân tích nhiều hơn tổng hợp → **lượng rodopsin giảm** → mắt nhìn được ở độ rọi lớn mà không bị "quá tải".
- **Độ rọi giảm** → tổng hợp nhiều hơn phân tích → rodopsin tăng dần → nhìn được ở độ rọi nhỏ.
- Tổng hợp lại rodopsin **chậm**: đi từ chỗ sáng vào chỗ tối phải mất **hàng chục phút** mới thích ứng đủ, trong khi **giãn đồng tử** chỉ mất **10–30 giây**.
- Phạm vi quang thông mắt dùng được rất rộng: mắt thích ứng tối thấy được khoảng **2·10^−10^ erg/s** tới đồng tử; thị giác ngày chịu được khoảng **200 erg/s** mà không chói hại — gấp khoảng **10^12^ lần** (1 erg = 10^−7^ J).

> [!bay]
> - Mắt **thích ứng tối chậm** (hàng chục phút, do phải tổng hợp lại rodopsin), nhưng **đồng tử giãn nhanh** (10–30 s). Đừng nhầm hai thời gian này.
> - Cực đại độ nhạy: **ngày 555 nm, tối 510 nm** — đường cong thị giác tối **dịch về phía sóng ngắn**.

### 6.3. Độ nhạy của mắt

Độ nhạy **E** của mắt là **nghịch đảo của ngưỡng nhìn ε** (công thức 8.3, tr. 285):

=> E = 1/ε

- Ngưỡng nhìn **càng nhỏ** → mắt **càng nhạy**. E cũng phụ thuộc bước sóng, kích thước vật, đường kính đồng tử, thời gian chiếu, trạng thái thích nghi.
- Quy ước lấy độ nhạy ở bước sóng nhạy nhất λ~0~ làm đơn vị: E~max~(λ~0~) = 1. Khi đó E được gọi là **độ nhạy tương đối**, và đồ thị E theo λ là **đường cong nhạy sáng tương đối**.
- Thị giác Photo: E~max~(0,555 µm) = 1. Ngoài khoảng **0,39 – 0,76 µm**, E ≈ 0: mắt không thấy tử ngoại và hồng ngoại. Đó là **miền khả kiến**.
- Đường cong Photo đo khi vật nhỏ (góc nhìn **< 2°**), ảnh rơi đúng **điểm vàng** (đường kính khoảng **1,5 mm**, **chỉ có tế bào nón**).

![Hình 3. Đường cong nhạy sáng tương đối của thị giác ngày (Photo) và thị giác tối (Scoto)](do-nhay-mat.svg)

> [!vi-du] Vì sao biển báo, áo phản quang, đèn khẩn cấp hay dùng màu vàng – xanh lá?
> Màu nằm gần **555 nm** cho cảm giác sáng nhất với cùng một công suất. Trong bóng tối, đỉnh dịch về **510 nm** (xanh lục – lam), nên vật màu xanh trông sáng hơn vật màu đỏ (hiện tượng Purkinje, mục 6.6). Phòng đọc phim X-quang, buồng lái, tàu ngầm thường dùng **đèn đỏ**: tế bào que gần như không nhạy với đỏ nên **giữ được trạng thái thích ứng tối**.

### 6.4. Thị giác hai mắt và cảm giác thấy nổi

Nhìn bằng hai mắt cho phép **thấy nổi**, rõ chi tiết, cảm nhận **chiều sâu**, xác định **khoảng cách**. Một vật tạo **hai ảnh** trên hai võng mạc nhưng ta chỉ có **một ấn tượng thị giác**. Giáo trình giải thích (tr. 286–287):

1. **Sự thay đổi trường nhìn (thị trường)**: ở mỗi thời điểm chỉ một trong hai thị trường hoạt động; quá trình thay đổi liên tục, luân phiên giữa hai mắt. Nhờ hưng phấn và phục hồi luân phiên, **nhìn hai mắt ít mỏi hơn một mắt**. Hiện tượng này cũng giải thích cơ chế pha trộn màu.
2. **Thuyết điểm tương ứng**: ảnh in vào những **điểm tương ứng** trên hai võng mạc (chồng hai võng mạc sao cho điểm vàng và các trục trùng nhau thì các điểm đó trùng nhau). Mỗi cặp điểm tương ứng nối về **cùng một điểm hưng phấn** ở trung ương. Tập hợp các điểm trong không gian cho ảnh rơi vào điểm tương ứng nằm trên **vòng đơn thị** (Fechner gọi là điểm tương ứng, Hering gọi là điểm chập, Müller gọi là điểm đồng nhất). Đây là thuyết được thừa nhận rộng rãi.
3. **Cảm giác thấy nổi** đến từ "**kinh nghiệm**": chi tiết gần che chi tiết xa, vật xa mờ hơn vật gần, bóng đổ theo một chiều; cùng với yếu tố quang hình học như **góc phân ly**, **sự điều tiết**, **độ quy tụ** của hai nhãn cầu. Những chi tiết không rơi vào điểm tương ứng cũng góp phần tạo cảm giác nổi.

### 6.5. Sự lưu hình (lưu ảnh)

Cảm giác sáng **không mất ngay** khi ngừng kích thích (tr. 287). Ví dụ: quơ que đỏ trong đêm thấy thành vòng sáng; vệt đỏ của viên đạn đi trong đêm; chiếu phim, truyền hình.

- Theo **Helmholtz**, thời gian lưu hình của vật sáng trên võng mạc khoảng **1/48 giây**; phụ thuộc cường độ chiếu và ấn tượng trước đó.
- Cơ chế: rodopsin → lumirodopsin **nhanh**, nhưng lumirodopsin → metarodopsin **chậm**. Khi ánh sáng đã tắt, vẫn còn lumirodopsin tiếp tục phân hủy và tạo cảm giác ảnh cũ. Lưu ảnh là thời gian cần để sản phẩm phân hủy biến đi và rodopsin được phục hồi.

> [!ung-dung] Lưu hình trong đời sống và y học
> Phim chiếu 24 hình/giây (mỗi hình chiếu 2 lần = 48 lần/giây), màn hình 50–60 Hz trở lên, cho cảm giác chuyển động liên tục vì khoảng cách giữa hai hình **ngắn hơn thời gian lưu hình**. Ngược lại, đèn nhấp nháy tần số thấp (khoảng 15–25 Hz) có thể khởi phát cơn ở người **động kinh nhạy cảm ánh sáng**; đây cũng là nguyên lý của nghiệm pháp **kích thích ánh sáng nhấp nháy** khi ghi điện não.

### 6.6. Cảm giác màu sắc

**Vì sao chỉ 0,40 – 0,76 µm gây cảm giác sáng?** (tr. 287–288)

- Phổ hấp thụ của các sắc tố thị giác nằm trong vùng này.
- Bước sóng **< 0,4 µm** không tới võng mạc: **thủy tinh thể** hấp thụ mạnh quanh **0,38 µm**, **giác mạc** hấp thụ mạnh dưới **0,30 µm** — giác mạc bảo vệ nhãn cầu khỏi tử ngoại, nhưng UV mạnh có thể làm **bỏng, loét giác mạc**.
- Bước sóng **> 1,2 µm**: nước trong thủy dịch, thủy tinh dịch, giác mạc, thủy tinh thể hấp thụ mạnh.
- Vùng **0,76 – 1,2 µm** (hồng ngoại gần) **tới được võng mạc** nhưng **không kích thích** tế bào cảm thụ, vì nằm ngoài phổ hấp thụ của sắc tố thị giác.
- Giải sóng tác dụng hẹp giúp **giảm sắc sai**; đồng tử hẹp chỉ cho chùm tia hẹp (gần trục) vào mắt → **giảm quang sai**, ảnh sắc nét hơn.

> [!bay] Hồng ngoại gần nguy hiểm vì "không thấy"
> Vùng 0,76–1,2 µm tới được võng mạc nhưng không gây cảm giác sáng, nên mắt **không có phản xạ chớp, co đồng tử** để tự bảo vệ. Vì vậy **laser hồng ngoại** (Nd:YAG 1064 nm) hoặc nhìn thẳng Mặt Trời khi nhật thực có thể gây **bỏng võng mạc** mà không thấy chói. Luôn đeo kính bảo hộ đúng bước sóng khi làm việc với laser.

**Màu là gì?** Cảm giác màu là **ấn tượng chủ quan**. Có hai nhóm màu:

- **Màu sặc sỡ** (đỏ, xanh…) và **màu không sặc sỡ** (trắng, xám, đen). Vật không hấp thụ chọn lọc ánh sáng nào là **vật không màu**.
- Ánh sáng Mặt Trời có đủ bước sóng 0,40–0,76 µm (thành phần phổ trùng với đường cong nhạy sáng Photo) → cảm giác **màu trắng**.
- Ánh sáng có Δλ đủ hẹp gọi là **đơn sắc**, cho **màu quang phổ** (màu tinh khiết). Nhưng có nhiều màu **không có trong phổ** (nâu, hồng, đỏ thẫm…): bảng màu mẫu có hàng trăm màu. Vì vậy **không thể nói mỗi màu ứng với một khoảng bước sóng**.
- Cảm giác màu còn phụ thuộc kích thước vật, độ chiếu sáng, màu xung quanh (vật xanh trên nền xanh lá trông "xanh hơn" và ngược lại).
- Một bước sóng xác định luôn cho màu tinh khiết, nhưng **ngược lại không đúng**: màu tinh khiết cũng có thể tạo từ hỗn hợp bước sóng. Ví dụ: bỏ dải **0,55–0,65 µm** (vùng tạo màu vàng) khỏi ánh sáng trắng, phần còn lại cho màu **tím xanh**; bỏ đỏ → còn xanh – xanh lá cây; bỏ vàng → xanh; bỏ vàng – xanh lá cây → tím.
- **Màu phụ nhau** = cặp màu trộn với nhau cho **màu trắng**: đỏ ↔ xanh lá cây – xanh (lục lam), vàng ↔ tím – xanh, da cam ↔ xanh. **Đỏ thẫm** (không có trong phổ, là kết hợp đỏ + tím) là màu phụ của xanh lá cây.
- Xếp các màu tinh khiết theo thứ tự phổ thành **vòng màu**, thêm đỏ thẫm cho kín vòng; **màu phụ nhau nằm đối diện** trên vòng.

**Ba đặc trưng của cảm giác màu**: **sắc màu** (do bước sóng), **cường độ (độ chói)** — phụ thuộc quang thông, và **độ bão hòa** — mức độ phân biệt màu sặc sỡ với màu không sặc sỡ (trắng, xám, đen) cùng cường độ. Thêm màu trắng vào một màu (ví dụ đỏ) thì độ chói của màu đó giảm, nhận thấy màu hồng; thêm trắng mãi thì chuyển dần sang trắng — **độ bão hòa giảm**.

**Thuyết ba thành phần Young – Helmholtz** (tr. 289–290)

Pha ba màu **đỏ, xanh lá cây, xanh (lam)** tạo được mọi cảm giác màu. Do đó giả thiết võng mạc có **3 loại tế bào nón**:

| Loại nón | Cực đại hấp thụ | Đáp ứng trong khoảng |
|---|---|---|
| "Tế bào đỏ" | **0,60 µm** | 0,475 – 0,760 µm |
| "Tế bào xanh lá cây" | **0,55 µm** | 0,425 – 0,650 µm |
| "Tế bào xanh – tím" | **0,45 µm** | 0,40 – 0,55 µm |

Ba phổ hấp thụ **lệch nhau và chồng nhau một phần**. Một bước sóng kích thích 3 loại nón **ở mức khác nhau**; **tỷ lệ kích thích** quyết định cảm giác màu:

- **0,42 µm** → chỉ nón xanh – tím bị kích thích → **tím**.
- **0,70 µm** → chỉ nón đỏ → **đỏ**.
- **0,52 µm** → cả ba bị kích thích, nón xanh lá mạnh nhất (ac > ab > ad) → **xanh lá cây**.
- **0,58 µm** → nón đỏ và nón xanh lá đáp ứng **gần bằng nhau** → **vàng**.

![Hình 4. Phổ hấp thụ của 3 loại tế bào nón theo thuyết ba thành phần](te-bao-non.svg)

**Hiện tượng Purkinje** (giáo trình viết "Purkinger"): cảm giác màu còn phụ thuộc cường độ. Cường độ quá thấp hoặc quá cao → cảm giác "trắng". Đổi cường độ với **màu đỏ** thì cảm giác màu thay đổi **nhanh hơn** so với màu xanh. Hai tờ giấy đỏ và xanh sáng như nhau ở một độ rọi; **giảm độ rọi** thì tờ **đỏ tối hơn** tờ xanh; **tăng độ rọi** thì ngược lại, tờ đỏ sáng hơn (Hình 8.8). Giải thích: khi tối, thị giác chuyển sang tế bào que, nhạy với sóng ngắn hơn (510 nm).

**Rối loạn thị giác màu (loạn sắc)** (tr. 290–291)

| Loại | Đặc điểm |
|---|---|
| **Trichromat** (bình thường) | Đủ 3 loại nón, phổ như Hình 8.7 → phân biệt màu bình thường |
| **Trichromat không bình thường** | Phổ hấp thụ dịch khỏi 0,60 / 0,55 / 0,45 µm → vẫn tổ hợp đủ màu nhưng cảm giác màu không đúng lắm |
| **Dichromat** | Chỉ nhận biết **2 màu cơ bản** |
| **Monochromat** | Chỉ nhận **1 màu**; rất hiếm; thấy mọi vật màu xanh tím |
| **Achromat** | Không nhận màu nào, mọi thứ **xám**. Thường do võng mạc **chỉ có que, không có nón**: ban ngày nhìn rất kém, ban đêm nhìn tốt hơn |

Bốn loại dichromat hay gặp (**Daltonism** — mù màu):

- **Protanop**: chỉ phân biệt **xanh lam và vàng**; thấy đỏ và xanh – xanh lá như xám; **nhạy rất thấp ở miền đỏ**.
- **Deuteranop**: chỉ phân biệt **xanh lam và vàng**; thấy xanh lá và đỏ thẫm như xám; **độ nhạy miền đỏ bình thường**.
- **Tritanop**: phân biệt được xanh lá cây và đỏ, **không** phân biệt được xanh lam; thấy tím – xanh lam và vàng như xám.
- **Tetartanop**: phân biệt được xanh lá cây và đỏ, **không** phân biệt xanh lam; thấy mọi màu xanh lam và vàng như xám.

Các chứng này thường **di truyền** và **hay gặp ở nam giới**. Trường hợp **achromat chỉ có que** chứng minh: **phân biệt màu là do tế bào nón**, **thị giác tối là do tế bào que**.

> [!bay]
> - **Protanop** và **deuteranop** đều chỉ phân biệt xanh lam – vàng; khác nhau ở **độ nhạy miền đỏ**: protanop **rất thấp**, deuteranop **bình thường**.
> - Achromat (không thấy màu, nhìn xám) ≠ monochromat (thấy 1 màu).

> [!cap-nhat] Nón S – M – L và mù màu đỏ – lục
> - Hiện nay gọi ba loại nón theo bước sóng: **nón S** (đỉnh khoảng **420 nm**), **nón M** (khoảng **530 nm**), **nón L** (khoảng **560 nm**). Đỉnh của "nón đỏ" thật ra nằm ở vùng vàng – lục; cảm giác đỏ sinh ra do nón L bị kích thích **trội hơn** nón M. Đi thi dùng số của giáo trình (0,60 / 0,55 / 0,45 µm).
> - Rối loạn **đỏ – lục** (protan, deutan) di truyền **lặn liên kết nhiễm sắc thể X** → gặp ở khoảng **8% nam**, **0,5% nữ** (người gốc châu Âu; người châu Á thấp hơn, khoảng 4–5% nam). Tritan rất hiếm và di truyền trên nhiễm sắc thể thường. "Tetartanop" là khái niệm cũ, hiếm được dùng.
> - Sàng lọc bằng **bảng Ishihara** (khám sức khỏe lái xe, tuyển nghề cần phân biệt màu).

Kết luận của giáo trình: **lý sinh thị giác** không chỉ là quang hình học mà còn là sinh học phân tử, điện sinh vật… Hiểu kỹ cơ chế thị giác giúp đi sâu vào y học, phòng và chữa bệnh mắt.

## Tóm tắt

| Chủ đề | Ý chính cần nhớ |
|---|---|
| Phản ứng quang sinh | Phản ứng trong cơ thể sống có ánh sáng tham gia. 4 giai đoạn: **hấp thụ → khử kích thích (quang lý / quang hóa) → phản ứng tối → hiệu ứng sinh vật** |
| Phân loại | **Phá hủy biến tính** (bệnh lý, đột biến, tử vong) / **Sinh lý chức năng** (năng lượng, thông tin, sinh tổng hợp) |
| Hiệu suất lượng tử | φ = phân tử bị kích hoạt / phân tử hấp thụ ánh sáng |
| Phổ tác dụng | Hiệu ứng theo λ; trùng phổ hấp thụ → tìm ra **một** chất hấp thụ; không trùng → ≥ 2 chất, có di chuyển năng lượng |
| Nhu cầu năng lượng | Đổi chức năng cần ít năng lượng hơn phá hủy; đối tượng nhỏ → ít photon (vi khuẩn 10^8^, virus 10^4^, men 10^2^) nhưng men cần năng lượng chiếu tới lớn nhất |
| Di chuyển năng lượng | **Cộng hưởng** (lưỡng cực dao động; chất cho phát quang, phổ chồng nhau, đủ gần; ≈ 50% ở 10 Å) và **exiton** (cặp điện tử – lỗ trống; diệp lục, rodopsin) |
| Quang hợp | CO~2~ + 2H~2~O + nhf → (CH~2~O) + O~2~ + H~2~O; O~2~ từ nước; ≥ 3 photon (4,9 eV / 1,77 eV); φ ≈ 1/8–1/4; diệp lục – hệ liên kết đôi liên hợp |
| Vitamin D | Provitamin (ergosterol) → vitamin D~2~; UV cắt liên kết **C9–C10**; ánh sáng cấp năng lượng, không dự trữ |
| Quang động lực | Tổn thương không hồi phục do **chất màu + ánh sáng + O~2~**; qua **triplet**; 5 cơ chế; chất màu là xúc tác. Ứng dụng: PDT; tác dụng phụ: sulfonamid, barbiturat, kháng histamin, porphyrin |
| Tử ngoại (sách) | 100–275 diệt trùng; 275–320 chống còi xương, tạo sắc tố; 320–400 yếu, gây phát quang. Nhị trùng thymin, hydrat hóa cytosin; 4 giai đoạn phá hủy acid amin thơm |
| Thụ cảm ánh sáng | Que – rodopsin (scotopxin + retinal); nón – iodopsin (fotopxin + retinal); retinal = aldehyd vitamin A~1~; 1 photon phân hủy 1 rodopsin; tái tạo trong tối cần vitamin A |
| Ngưỡng nhìn, độ nhạy | Hess: 150 − 4/5·150 = 30 photon; hiện nay 1–2 photon; ε(500 nm) ≈ 4·10^−19^ J; **E = 1/ε**; Photo 555 nm, Scoto 510 nm; khả kiến 0,39(0,40)–0,76 µm |
| Lưu hình | ≈ 1/48 s (Helmholtz); do lumirodopsin phân hủy chậm |
| Màu sắc | 3 đặc trưng: sắc màu, độ chói, độ bão hòa; Young – Helmholtz: nón đỏ 0,60, xanh lá 0,55, xanh tím 0,45 µm; Purkinje; loạn sắc: trichromat, dichromat (protanop, deuteranop, tritanop, tetartanop), monochromat, achromat |
