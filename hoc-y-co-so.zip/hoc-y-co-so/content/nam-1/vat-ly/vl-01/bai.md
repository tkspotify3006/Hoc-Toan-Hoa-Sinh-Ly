---
title: Đơn vị đo lường. Một số quy luật cơ bản
thoi-gian: 35 phút
muc-tieu:
- Trình bày được vai trò của vật lý đối với các khoa học khác, nhất là với nghiên cứu y học và bảo vệ sức khỏe cộng đồng.
- Sử dụng đúng các đơn vị đo lường hợp pháp (hệ SI): đơn vị cơ bản, đơn vị dẫn xuất, tiền tố, thứ nguyên; quy đổi được các đơn vị ngoài SI hay gặp trong y học.
- Phân biệt được đại lượng vô hướng và đại lượng vectơ.
- Nêu được các đặc điểm mang tính quy luật của hiện tượng lý sinh: thống kê, hàm mũ, liên hệ ngược, chi phí năng lượng tối thiểu, ngưỡng, đối xứng.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Vật lý là **cơ sở của mọi khoa học tự nhiên**. Trong thế giới sống, **tương tác điện từ** đóng vai trò chủ yếu (trong 4 loại tương tác).
> 2. Đo một đại lượng = **so sánh với đơn vị**. Hệ SI có các **đơn vị cơ bản** (m, kg, s, A, K, mol, cd); mọi đơn vị khác là **dẫn xuất** (vd 1 W = 1 kg·m²/s³).
> 3. **Thứ nguyên** (L, M, T…) cho biết đơn vị phụ thuộc đơn vị cơ bản ra sao; hai vế một công thức phải **cùng thứ nguyên**.
> 4. Đại lượng **vô hướng** chỉ cần một trị số; đại lượng **vectơ** cần cả độ lớn và hướng.
> 5. Hiện tượng lý sinh có 6 đặc điểm quy luật: **thống kê, hàm mũ, liên hệ ngược, chi phí năng lượng tối thiểu, ngưỡng, đối xứng**.

## 1. Vật lý, lý sinh và y học

### 1.1. Vì sao vật lý là "cơ sở" của y học

Các phát minh lớn của vật lý (định luật bảo toàn, tính chất lượng tử…) nói về bản chất chung của vật chất. Chúng đúng cho cả vật sống lẫn vật không sống. Vì vậy vật lý được coi là cơ sở của mọi khoa học tự nhiên (Giáo trình tr. 11).

**Lý sinh** là vật lý của sự sống. Vật lý – lý sinh gắn chặt với y học hiện đại vì **ba lý do**:

| Lý do | Ý nghĩa | Ví dụ |
|---|---|---|
| Ứng dụng **quy luật** vật lý | Hiểu và giải thích các quá trình sống trong cơ thể và quần thể | Dòng máu tuân theo định luật thủy động học; điện thế màng tuân theo quy luật điện học |
| Ứng dụng **phương pháp, máy móc** vật lý | Chẩn đoán, điều trị, bảo vệ sức khỏe cộng đồng, bảo vệ môi trường | Máy đo huyết áp, điện tim, siêu âm, X-quang, laser, xạ trị |
| Ứng dụng **phương pháp tư duy** của vật lý | Xây dựng thế giới quan khoa học cho người thầy thuốc | Suy luận dựa trên đo đạc, thí nghiệm, kiểm chứng |

**Phương pháp mô hình.** Khi nghiên cứu một hiện tượng, người ta thường dựng một thí nghiệm hoặc một **mô hình** giống hiện tượng thật, rồi hoàn chỉnh dần các thông số. Ví dụ: để nghiên cứu tim và tuần hoàn, có thể dùng một hệ ống kín có thành đàn hồi (như mạch máu) nối với một máy bơm chạy liên tục với công suất xác định (như tim).

### 1.2. Bốn loại tương tác

Đến nay, mọi hiện tượng vật lý được giải thích bằng **4 loại tương tác** (Giáo trình tr. 11–12):

| Tương tác | Định luật cơ bản / đặc điểm | Vai trò |
|---|---|---|
| **Hấp dẫn** | Định luật vạn vật hấp dẫn Newton: lực hút tỉ lệ thuận với tích khối lượng, tỉ lệ nghịch với **bình phương** khoảng cách | Trọng lực, chuyển động thiên thể |
| **Điện từ** | Định luật Coulomb, dạng giống định luật hấp dẫn nhưng với điện tích; có thể hút **hoặc đẩy** | **Chủ yếu trong thế giới sống**: liên kết hóa học, điện thế màng, dẫn truyền thần kinh |
| **Hạt nhân mạnh** | Rất mạnh nhưng chỉ đáng kể trong phạm vi **≈ 10^−15^ m** (cỡ hạt nhân) | Giữ cho hạt nhân nguyên tử tồn tại |
| **Hạt nhân yếu** | Gắn với **phát xạ hạt β** của hạt nhân | Phân rã phóng xạ β |

=> F = G·m~1~·m~2~/r²

F: lực hấp dẫn (N); m~1~, m~2~: khối lượng (kg); r: khoảng cách (m); G = 6,672·10^−11^ m³·kg^−1^·s^−2^.

=> F = K·q~1~·q~2~/r²

F: lực Coulomb (N); q~1~, q~2~: điện tích (C); K = 9·10^9^ N·m²·C^−2^.

**Vì sao tương tác điện từ quan trọng nhất với sự sống?** Hấp dẫn quá yếu ở quy mô phân tử. Hai lực hạt nhân chỉ tác dụng trong lòng hạt nhân. Còn mọi liên kết giữa các nguyên tử, phân tử, mọi dòng ion qua màng tế bào đều là tương tác giữa các điện tích. Tương tác điện từ gắn liền với **trường điện từ**.

> [!bay] "Trường sinh học"
> Giáo trình nhắc đến ý kiến về một "trường sinh học", nhưng ghi rõ: **bản chất của trường sinh học chưa được minh chứng** rõ ràng. Khi thi, đáp án "tương tác chủ yếu trong thế giới sống" là **tương tác điện từ**.

## 2. Đo lường và đơn vị đo

### 2.1. Đo một đại lượng là gì

Mỗi thuộc tính của một vật được đặc trưng bằng một hay nhiều **đại lượng vật lý**. **Đo** một đại lượng là chọn một đại lượng cùng loại làm **mẫu** (gọi là **đơn vị**), rồi so sánh đại lượng cần đo với mẫu đó (Giáo trình tr. 12).

=> Trị số đo = đại lượng phải đo / đại lượng đơn vị

- **Đơn vị cơ bản**: một số ít đơn vị được chọn trước làm mẫu.
- **Đơn vị dẫn xuất**: suy ra từ đơn vị cơ bản qua các công thức vật lý.
- **Hệ đơn vị** = các đơn vị cơ bản đã chọn + các đơn vị dẫn xuất tương ứng.

Một hệ đơn vị tốt phải tiện cho tính toán, làm cho công thức vật lý có hệ số đơn giản, và được thống nhất giữa các nước để dễ trao đổi số liệu.

| Hệ | Đơn vị cơ bản (cơ học) | Ghi chú |
|---|---|---|
| **CGS** | centimét (cm), gam (g), giây (s) | Hệ cũ |
| **MKS** | mét (m), kilogam (kg), giây (s) | Hệ cũ, là "lõi cơ học" của SI |
| **SI** (*Système international*) | m, kg, s, A, K, mol, cd | Được thông qua năm **1960**; Việt Nam ban hành "Bảng đơn vị đo lường hợp pháp" dựa trên SI năm **1965** |

### 2.2. Các đơn vị cơ bản của hệ SI

![Hình 1. Bảy đơn vị cơ bản của hệ SI hiện hành](don-vi-si.svg)

| Đại lượng | Đơn vị | Ký hiệu |
|---|---|---|
| Chiều dài | mét | m |
| Khối lượng | kilogam | kg |
| Thời gian | giây | s |
| Cường độ dòng điện | ampe | A |
| Nhiệt độ nhiệt động | kelvin | K |
| Lượng chất | mol | mol |
| Cường độ sáng | candela | cd |

> [!bay] Giáo trình chỉ liệt kê 6 đơn vị
> - Giáo trình (tr. 12–13) viết "hệ SI có **6** đơn vị cơ bản": m, kg, s, A, cd và "độ Kelvin (°K)". Danh sách này **thiếu mol** (đơn vị lượng chất), được bổ sung vào SI từ năm 1971.
> - Từ năm 1967, đơn vị nhiệt độ gọi là **kelvin**, ký hiệu **K**, **không** có "độ" và **không** có dấu °. Viết "°K" là sai quy ước. Chỉ độ Celsius mới viết °C.
> - Chữ "kilogam" có tiền tố kilo nhưng chính **kg** (không phải g) mới là đơn vị cơ bản.

> [!cap-nhat] SI định nghĩa lại năm 2019
> Giáo trình định nghĩa đơn vị qua các "mẫu". Từ ngày 20/5/2019, **cả 7 đơn vị cơ bản** được định nghĩa bằng cách **cố định giá trị chính xác** của 7 hằng số tự nhiên. Ví dụ: kilogam được định nghĩa qua **hằng số Planck** h = 6,62607015·10^−34^ J·s (bỏ quả cân mẫu bằng platin–iridi ở Paris); mol được định nghĩa qua **số Avogadro** N~A~ = 6,02214076·10^23^ mol^−1^ (chính xác); kelvin qua **hằng số Boltzmann** k = 1,380649·10^−23^ J/K; ampe qua **điện tích nguyên tố** e = 1,602176634·10^−19^ C. Tên và độ lớn các đơn vị trong thực hành không đổi.

### 2.3. Đơn vị dẫn xuất

Từ đơn vị cơ bản có thể dựng mọi đơn vị khác. Giáo trình lấy ví dụ đơn vị công suất **oát** (W):

=> 1 W = 1 kg·m²/s³ = 1 kg·m²·s^−3^

Vì sao? Công suất = công/thời gian; công = lực × quãng đường; lực = khối lượng × gia tốc (kg·m/s²). Ghép lại: (kg·m/s²)·m/s = kg·m²/s³.

Các đơn vị dẫn xuất có tên riêng hay gặp trong y học (bổ sung, sẽ học ở các bài sau):

| Đại lượng | Đơn vị | Theo đơn vị cơ bản | Gặp ở đâu |
|---|---|---|---|
| Lực | newton (N) | kg·m·s^−2^ | Cơ sinh học |
| Áp suất | pascal (Pa) = N/m² | kg·m^−1^·s^−2^ | Huyết áp, áp suất thẩm thấu |
| Năng lượng, công, nhiệt | joule (J) | kg·m²·s^−2^ | Năng lượng thức ăn, nhiệt trị liệu |
| Công suất | oát (W) = J/s | kg·m²·s^−3^ | Máy điện trị liệu, laser |
| Tần số | hertz (Hz) = s^−1^ | s^−1^ | Siêu âm, ECG |
| Điện tích | coulomb (C) = A·s | A·s | Điện sinh học |
| Hiệu điện thế | vôn (V) = W/A | kg·m²·s^−3^·A^−1^ | Điện thế màng (mV), ECG |
| Liều hấp thụ / liều tương đương | gray (Gy), sievert (Sv) = J/kg | m²·s^−2^ | Xạ trị, an toàn bức xạ |
| Hoạt độ phóng xạ | becquerel (Bq) = s^−1^ | s^−1^ | Y học hạt nhân |

### 2.4. Tiền tố thập phân

Để viết gọn số rất lớn hoặc rất nhỏ, người ta ghép **tiền tố** vào trước đơn vị (Bảng 1.1, Giáo trình tr. 13):

| Tiền tố | Ký hiệu | Thừa số | | Tiền tố | Ký hiệu | Thừa số |
|---|---|---|---|---|---|---|
| đêca | da | 10^1^ | | đêxi | d | 10^−1^ |
| hectô | h | 10^2^ | | xăngti | c | 10^−2^ |
| kilô | k | 10^3^ | | mili | m | 10^−3^ |
| mêga | M | 10^6^ | | micrô | µ | 10^−6^ |
| giga | G | 10^9^ | | nanô | n | 10^−9^ |
| tera | T | 10^12^ | | picô | p | 10^−12^ |

![Hình 2. Thang tiền tố thập phân: mỗi bậc chính cách nhau 10³](thang-tien-to.svg)

> [!bay]
> - Phân biệt chữ hoa – chữ thường: **M** (mêga, 10^6^) khác **m** (mili, 10^−3^). 1 MΩ gấp 10^9^ lần 1 mΩ.
> - Ký hiệu micrô là chữ Hy Lạp **µ** (bản in của giáo trình ở bảng 1.1 bị lỗi thành "à"). Trên đơn thuốc viết tay, "µg" dễ đọc nhầm thành "mg" (gấp 1000 lần), nên trong y khoa người ta khuyến cáo viết rõ **"mcg"** hoặc "microgam".
> - Không ghép hai tiền tố: viết **ng**, không viết "mµg".

**Đơn vị dùng theo thói quen** (Giáo trình tr. 13):

=> 1 Å (ångström) = 10^−10^ m = 10^−8^ cm = 0,1 nm

=> 1 phút = 60 s ;  1 giờ = 60 phút = 3600 s

### 2.5. Đơn vị ngoài SI thường gặp trong y học (bổ sung)

Giáo trình yêu cầu "vận dụng đúng các đơn vị đo lường của nhà nước". Trong bệnh viện, nhiều đơn vị ngoài SI vẫn dùng hằng ngày, nên phải đổi được sang SI.

| Đơn vị | Dùng để đo | Quy đổi |
|---|---|---|
| **mmHg** (milimét thủy ngân) | Huyết áp | 1 mmHg ≈ **133,3 Pa**; 1 kPa ≈ **7,5 mmHg** |
| **cmH~2~O** | Áp lực tĩnh mạch trung tâm, áp lực đường thở | 1 cmH~2~O ≈ 98 Pa ≈ 0,74 mmHg |
| **atm** | Áp suất khí quyển, oxy cao áp | 1 atm = 760 mmHg = 101 325 Pa ≈ 101,3 kPa |
| **cal**, **kcal** | Năng lượng khẩu phần | 1 cal = **4,184 J**; 1 kcal ("Calo" trên nhãn thực phẩm) = 4184 J ≈ 4,2 kJ |
| **°C** | Thân nhiệt | T (K) = t (°C) + 273,15; độ chênh 1 °C = 1 K (°C thực ra là đơn vị **dẫn xuất có tên riêng** của SI, không phải đơn vị cơ bản) |
| **lít** (L) | Thể tích | 1 L = 1 dm³ = 10^−3^ m³; 1 mL = 1 cm³ |
| **eV** | Năng lượng photon, hạt | 1 eV ≈ 1,602·10^−19^ J |
| **mg/dL ↔ mmol/L** | Xét nghiệm sinh hóa | mg/dL = mmol/L × (M/10), với M là khối lượng mol (g/mol) |

**Vì sao 1 mmHg ≈ 133 Pa?** Đó là áp suất của cột thủy ngân cao 1 mm:

=> p = ρ·g·h

=> 13 600 × 9,81 × 0,001 ≈ 133 Pa

(p: áp suất, Pa; ρ: khối lượng riêng của thủy ngân, kg/m³; g: gia tốc trọng trường, m/s²; h: chiều cao cột, m)

**Vì sao glucose "× 18"?** Khối lượng mol glucose là 180 g/mol. 1 mmol/L = 180 mg/L = **18 mg/dL**. Với cholesterol (M ≈ 386,7 g/mol), hệ số là **38,7**. Mỗi chất có hệ số riêng, không dùng chung một hệ số.

> [!ung-dung] Đổi đơn vị trong lâm sàng
> - Huyết áp 120/80 mmHg ≈ **16,0/10,7 kPa**. Ngưỡng tăng huyết áp 140/90 mmHg ≈ 18,7/12,0 kPa.
> - Đường huyết lúc đói 126 mg/dL = 126/18 = **7,0 mmol/L** (ngưỡng chẩn đoán đái tháo đường).
> - Creatinin: 1 mg/dL ≈ 88,4 µmol/L.
> - Khẩu phần 2000 kcal/ngày = 2000 × 4184 J ≈ **8,4 MJ**.
> - Lỗi hay gặp nhất khi đổi đơn vị: nhân thay vì chia, quên tiền tố (mg ↔ µg, mL ↔ L), dùng nhầm hệ số của chất khác.

> [!cap-nhat] Đơn vị phóng xạ cũ
> Sách cũ và một số máy còn dùng đơn vị ngoài SI (sẽ gặp ở bài phóng xạ):
> - 1 rad = 0,01 Gy; 1 rem = 0,01 Sv (5 rem = 50 mSv).
> - 1 Ci (curi) = 3,7·10^10^ Bq.
> - 1 R (rơnghen) = 2,58·10^−4^ C/kg (đơn vị liều chiếu).

### 2.6. Thứ nguyên của đại lượng

**Thứ nguyên** của một đại lượng là quy luật cho biết đơn vị đo của đại lượng đó phụ thuộc vào các đơn vị cơ bản như thế nào (Giáo trình tr. 13).

Ví dụ thể tích: hộp chữ nhật V = a·b·c, hình trụ V = π·R²·h, hình cầu V = (4/3)·π·R³. Bỏ qua các hệ số, lần nào cũng là chiều dài × chiều dài × chiều dài. Vậy:

=> [thể tích] = [chiều dài]³ = L³

Ký hiệu gọn: [chiều dài] = **L**, [khối lượng] = **M**, [thời gian] = **T**.

| Đại lượng | Thứ nguyên | Đơn vị SI |
|---|---|---|
| Thể tích | L³ | m³ |
| Vận tốc | L·T^−1^ | m·s^−1^ |
| Gia tốc | L·T^−2^ | m·s^−2^ |
| Khối lượng riêng | M·L^−3^ | kg·m^−3^ |
| Lực | M·L·T^−2^ | N |
| Áp suất | M·L^−1^·T^−2^ | Pa |
| Năng lượng | M·L²·T^−2^ | J |

**Công dụng: kiểm tra một công thức.** Hai vế của một công thức vật lý **luôn phải cùng thứ nguyên**. Ví dụ chu kỳ con lắc toán học:

=> T = 2π·√(ℓ/g)

T: chu kỳ (s); ℓ: chiều dài dây (m); g: gia tốc trọng trường (m/s²).

Vế trái có thứ nguyên thời gian T. Vế phải: [ℓ/g]^½^ = [L/(L·T^−2^)]^½^ = [T²]^½^ = T. Hai vế khớp, công thức hợp lý về thứ nguyên. Hệ số 2π không có thứ nguyên nên phép kiểm tra này **không** phát hiện được sai hệ số.

> [!vi-du] Tự kiểm tra p = ρ·g·h
> [ρ·g·h] = (M·L^−3^)·(L·T^−2^)·L = M·L^−1^·T^−2^, đúng bằng thứ nguyên áp suất. Vậy công thức áp suất thủy tĩnh dùng để đổi mmHg ra Pa là nhất quán.

### 2.7. Đại lượng vô hướng và đại lượng vectơ

| | **Vô hướng** | **Vectơ** |
|---|---|---|
| Được xác định bởi | Một trị số (kèm đơn vị) duy nhất | Độ lớn (môđun) **và hướng** trong không gian |
| Ví dụ (theo sách) | Khoảng thời gian, năng lượng, nhiệt độ, thể tích | Vận tốc, gia tốc, lực, cường độ điện trường, cường độ từ trường |
| Biểu diễn | Một con số | Mũi tên: hướng mũi tên = hướng; độ dài = độ lớn |

Trong hệ trục vuông góc Oxyz, vectơ **OM** được xác định hoàn toàn bởi ba hình chiếu (thành phần) M~x~, M~y~, M~z~. Đó là ba đại lượng vô hướng (đại số), có thể âm hoặc dương. Độ lớn:

=> |OM| = √(M~x~² + M~y~² + M~z~²)

**Các phép toán với vectơ** (Giáo trình tr. 15–16):

- **Cộng vectơ** theo **quy tắc hình bình hành**: **OA** + **OB** = **OC**, với OC là đường chéo của hình bình hành dựng trên OA, OB. Ngược lại, một vectơ có thể **phân tích** thành hai thành phần.
- **Tích vô hướng** của hai vectơ cho ra một **số** (vô hướng):

=> **OA**·**OB** = |OA|·|OB|·cos α  (α: góc giữa hai vectơ)

- **Tích vectơ** của hai vectơ cho ra một **vectơ** **OC** = **OA** × **OB**:
  - độ lớn |OC| = |OA|·|OB|·sin α;
  - phương **vuông góc** với mặt phẳng chứa OA và OB;
  - chiều theo **quy tắc cái vặn nút chai** (đinh ốc): quay cái vặn từ OA sang OB thì chiều tiến của nó là chiều OC.

> [!bay]
> - Tích **vô hướng** dùng **cos**, ra **số**; tích **vectơ** dùng **sin**, ra **vectơ** vuông góc mặt phẳng. Hai vectơ vuông góc có tích vô hướng = 0; hai vectơ cùng phương có tích vectơ = 0.
> - Giáo trình viết tích vectơ là "OC = OA.OB". Ký hiệu chuẩn là dấu **×** (OA × OB); dấu chấm dành cho tích vô hướng.
> - Năng lượng, nhiệt độ là vô hướng dù có thể âm (nhiệt độ °C) hoặc dương; dấu âm **không** biến một đại lượng thành vectơ.

> [!ung-dung] Vectơ trong y học
> - **Công** của lực là tích vô hướng: A = F·s·cos α. Cơ kéo xương theo hướng xiên thì chỉ thành phần dọc theo hướng chuyển động mới sinh công.
> - Lực của hai bó cơ (ví dụ hai đầu cơ delta) cộng theo quy tắc hình bình hành để ra lực tổng hợp.
> - Hoạt động điện của tim được biểu diễn bằng **vectơ điện tim**; **trục điện tim** trên ECG chính là hướng của vectơ tổng hợp này (học ở bài *Điện và sự sống*, vl-05).

### 2.8. Độ lớn của một số đối tượng và hằng số vật lý

Giáo trình có 4 bảng (tr. 16–17) giúp hình dung "cỡ" của thế giới tự nhiên. Các giá trị chỉ là **bậc độ lớn** (làm tròn theo lũy thừa của 10).

| Đối tượng | Bậc độ lớn (theo sách) |
|---|---|
| Khối lượng điện tử / proton | 0,9·10^−30^ kg / 1,67·10^−27^ kg (proton nặng gấp ≈ 1840 lần) |
| Phân tử ADN (DNA) | 10^−15^ kg |
| Người trưởng thành | 10^2^ kg |
| Kích thước hạt nhân / nguyên tử | 10^−15^ m / 10^−10^ m (nguyên tử lớn gấp ≈ 10^5^ lần hạt nhân) |
| Phân tử lớn | 10^−9^ – 10^−8^ m |
| Chiều cao người | ≈ 1,8 m |
| Chu kỳ dao động nguyên tử / sóng âm | 10^−14^ s / 10^−3^ s |
| Nhịp tim | ≈ 1 s |

**Hằng số vật lý thông dụng** (Bảng 1.5, chọn lọc):

| Hằng số | Ký hiệu | Giá trị |
|---|---|---|
| Tốc độ ánh sáng trong chân không | c | 3·10^8^ m/s |
| Số Avogadro | N~A~ | 6,023·10^23^ mol^−1^ |
| Hằng số Boltzmann | k | 1,381·10^−23^ J/K |
| Điện tích nguyên tố | e | 1,602·10^−19^ C |
| Khối lượng electron | m~e~ | 9,109·10^−31^ kg |
| Khối lượng proton / nơtron | m~p~ / m~n~ | 1,673·10^−27^ / 1,675·10^−27^ kg |
| Hằng số Planck | h | 6,63·10^−34^ J·s |
| Gia tốc trọng trường | g | 9,81 m/s² |
| Hằng số hấp dẫn | G | 6,672·10^−11^ m³·kg^−1^·s^−2^ |
| Hằng số Coulomb | K | 9·10^9^ N·m²·C^−2^ |
| Bán kính Bohr | a~0~ | 5,29·10^−11^ m |
| Hằng số Rydberg | R | 1,097·10^7^ m^−1^ |

> [!cap-nhat] Một vài số liệu đã cũ hoặc làm tròn thô
> - Giáo trình ghi tuổi vũ trụ "khoảng 15 tỷ năm". Hiện nay ước tính là **≈ 13,8 tỷ năm**.
> - Một số bậc độ lớn trong bảng 1.3–1.4 làm tròn khá thô: 1 năm ánh sáng thực tế ≈ 9,5·10^15^ m; khoảng cách Trái Đất – Mặt Trời ≈ 1,5·10^11^ m; 1 năm ≈ 3,2·10^7^ s; phần lớn virus cỡ 20–300 nm (10^−8^ – 10^−7^ m).
> - Số Avogadro hiện là giá trị **chính xác** 6,02214076·10^23^ mol^−1^ (xem mục 2.2).
> - Đi thi: trả lời theo số liệu của giáo trình.

## 3. Các đặc điểm mang tính quy luật của hiện tượng lý sinh

Hiện tượng lý sinh tuân theo các quy luật vật lý, hóa học, sinh học như mọi hiện tượng khác. Giáo trình nêu **6 đặc điểm** nổi bật (tr. 17–23):

| # | Đặc điểm | Ý chính |
|---|---|---|
| 1 | Tính **thống kê** | Kết quả lặp lại giống nhau nhưng không y hệt → phải mô tả bằng trung bình, xác suất, phân phối |
| 2 | Tính quy luật **hàm mũ** | Tốc độ biến đổi tỉ lệ với chính độ lớn của đối tượng |
| 3 | Tính quy luật **liên hệ ngược** | Kết quả quay lại kìm hãm quá trình → hệ tiến tới trạng thái cân bằng, ổn định |
| 4 | **Chi phí năng lượng tối thiểu** | Cơ thể hoạt động sao cho tốn ít năng lượng nhất trong hoàn cảnh cụ thể |
| 5 | **Ngưỡng** | Tác động phải đủ lớn (và không quá lớn) mới gây đáp ứng |
| 6 | Tính quy luật **đối xứng** | Cấu trúc sống có đối xứng gương, trục, điểm |

### 3.1. Tính thống kê

#### a) Vì sao hiện tượng lý sinh mang tính thống kê

Đo chiều cao các nam sinh viên trong một lớp, ta nhận được các giá trị h~1~, h~2~, …, h~n~ khác nhau. Kết quả được đại diện bằng giá trị trung bình:

=> h̄ = (h~1~ + h~2~ + … + h~n~)/n = (1/n)·Σh~i~

Theo giáo trình (tr. 18), tính thống kê đến từ **4 nguyên nhân**:

1. Đối tượng khảo sát là hệ **gồm nhiều phần tử** (hệ vĩ mô), và hiện tượng **lặp đi lặp lại** nhiều lần chứ không chỉ xảy ra một lần.
2. Theo thời gian, bản thân đối tượng **thay đổi**, không giữ nguyên tính chất.
3. Phép đo có **sai số**: sai số ngẫu nhiên (thăng giáng) và sai số hệ thống.
4. Tác động của **môi trường** lên đối tượng mỗi lúc một khác.

#### b) Tần suất và xác suất

Làm N phép thử như nhau, sự kiện A xảy ra N~A~ lần (0 ≤ N~A~ ≤ N).

=> f~A~ = N~A~/N ;  0 ≤ f~A~ ≤ 1

=> P(A) = lim f~A~ (N → ∞) ;  0 ≤ P(A) ≤ 1

f~A~: tần suất của sự kiện A (không thứ nguyên); P(A): xác suất của sự kiện A.

Ví dụ của sách: tung xúc xắc 36 lần, mặt 1 chấm xuất hiện 5 lần thì tần suất f = 5/36 ≈ 0,14. Tung càng nhiều lần, tần suất càng tiến gần **1/6** (nếu xúc xắc cân đối). Giá trị giới hạn 1/6 đó là **xác suất**.

Xác suất cho biết **khả năng** xảy ra sự kiện trong một phép thử. Xác suất nhỏ nghĩa là khó xảy ra, **nhưng không có nghĩa là không thể xảy ra**.

#### c) Giá trị trung bình, sai số, phương sai

Đo đại lượng A tổng cộng N lần, được giá trị A~1~ (N~1~ lần), A~2~ (N~2~ lần)…, A~n~ (N~n~ lần):

=> Ā = (A~1~·N~1~ + … + A~n~·N~n~)/N

=> Ā = A~1~·f~1~ + A~2~·f~2~ + … + A~n~·f~n~

Khi N → ∞, Ā tiến tới giá trị trung bình lý thuyết, gọi là **kỳ vọng toán học**:

=> Ā = Σ A~i~·P(A~i~)

- Sai số của một lần đo: ΔA~i~ = A~i~ − Ā. Trung bình của các sai số này **bằng 0** (sai số dương và âm bù trừ nhau).
- Vì vậy phải dùng **sai số toàn phương trung bình**: s² = Σ(A~i~ − Ā)²·P(A~i~). Khi N → ∞ thì s² → **σ²**, gọi là **phương sai**; σ là **độ lệch chuẩn**.

#### d) Phân phối của các đại lượng

Số đo của các đại lượng vật lý, lý sinh thường tuân theo một quy luật phân phối: **nhị thức**, **Gauss** (phân phối chuẩn, đường cong hình chuông đối xứng quanh giá trị trung bình), **Poisson**… Các thông số của phân phối cho đặc trưng định lượng của đại lượng (học kỹ ở môn Xác suất – Thống kê).

> [!ung-dung] Khoảng tham chiếu của xét nghiệm
> "Giá trị bình thường" của một xét nghiệm không phải một con số mà là một **khoảng**. Với đại lượng phân phối gần chuẩn, khoảng tham chiếu thường lấy **trung bình ± 2 độ lệch chuẩn**, chứa khoảng 95% người khỏe mạnh. Vì vậy khoảng 5% người khỏe vẫn có kết quả "ngoài giới hạn". Một kết quả hơi lệch phải được đánh giá cùng lâm sàng và có thể cần làm lại xét nghiệm.

### 3.2. Tính quy luật hàm mũ

Hàm mũ có dạng y = a^x^ (a > 0): **tăng** khi a > 1, **giảm** khi a < 1.

#### a) Hàm mũ tăng: quần thể tế bào phân chia tự do

Gọi λ là xác suất phân bào của một tế bào trong một đơn vị thời gian (λ = dP/dt), N(t) là số tế bào có khả năng phân bào ở thời điểm t. Sau thời gian dt, số tế bào tăng thêm:

=> dN = N·dP = λ·N·dt  ⇒  dN/N = λ·dt

Tích phân hai vế: ln N = λt + C. Tại t = 0 có N(0) tế bào, nên:

=> N(t) = N(0)·e^λt^

N(t): số tế bào ở thời điểm t; N(0): số tế bào ban đầu; λ: hằng số tốc độ (s^−1^ hoặc h^−1^).

#### b) Hàm mũ giảm: quần thể tế bào bị chiếu xạ

Nếu λ là xác suất một tế bào bị chết trong một đơn vị thời gian chiếu, lập luận tương tự cho:

=> N(t) = N(0)·e^−λt^

#### c) Bản chất chung

=> dN/dt = λ·N  hoặc  dN/dt = −λ·N

**Tốc độ** xảy ra hiện tượng luôn **tỉ lệ với độ lớn** (kích thước) hiện có của đối tượng. Càng nhiều tế bào thì càng nhiều tế bào phân chia trong cùng một khoảng thời gian, nên số lượng "tăng theo cấp số nhân".

Hệ quả hữu ích (bổ sung): mỗi khoảng thời gian bằng nhau, đại lượng nhân với **cùng một tỉ lệ**. Thời gian để giảm còn một nửa (**thời gian bán thải / bán rã**) hay để tăng gấp đôi là:

=> T~½~ = ln2/λ ≈ 0,693/λ

T~½~ có cùng đơn vị thời gian với 1/λ.

| Loại | Ví dụ trong giáo trình (tr. 20) |
|---|---|
| Hàm mũ thuần (không bị khống chế) | Sự tăng trưởng kiến thức (phát minh khoa học) của loài người; sự tăng **bạch cầu trong bệnh máu trắng**; sự **chết của tế bào sau chiếu xạ**; sự **phóng điện của tụ điện** |
| Hàm mũ dẫn tới **trạng thái dừng** | Sự **nạp điện vào tụ**; nạp và tháo chất lỏng khỏi bình chứa; sự kích thích điện tế bào; sự thấm của dung dịch vào cơ thể; vật rơi trong môi trường có lực cản |

Điều kiện để có hàm mũ thuần: quá trình **không bị khống chế** bởi chính một yếu tố của nó. Khi có yếu tố tự hãm (như nguồn tài nguyên hạn chế) thì quá trình sẽ chậm lại và dừng.

![Hình 3. Hàm mũ tăng, hàm mũ giảm và hàm mũ dẫn tới trạng thái dừng](ham-mu.svg)

> [!ung-dung] Dược động học bậc một và phóng xạ
> - Với phần lớn thuốc, tốc độ thải trừ tỉ lệ với nồng độ thuốc trong máu, nên nồng độ giảm theo **hàm mũ**: C(t) = C~0~·e^−kt^. Sau 1, 2, 3, 4, 5 lần thời gian bán thải, lượng thuốc còn lại 50%, 25%, 12,5%, 6,25%, ≈ 3%. Vì vậy người ta coi thuốc gần như thải hết sau khoảng 4–5 T~½~.
> - Phân rã phóng xạ cũng theo quy luật N = N~0~·e^−λt^ (học ở bài phóng xạ). Đường cong sống sót của tế bào sau chiếu xạ là cơ sở của xạ trị.

### 3.3. Tính quy luật liên hệ ngược

Nếu một quá trình cứ tự do diễn biến thì khó đạt trạng thái ổn định. **Liên hệ ngược** là khi kết quả của các trạng thái sau (B, C…) **tác động ngược lại** trạng thái đầu (A), làm cho các phần tử ở A **khó chuyển** sang B, C hơn (ví dụ: giảm tốc độ biến đổi). Nhờ đó quá trình tiến tới một trạng thái **cân bằng (dừng)** và hệ trở nên **ổn định**.

=> A → B → C → …

=> B, C ⟶ tác động ngược lại A

Ba ví dụ của giáo trình (tr. 21):

| Ví dụ | Quá trình | Liên hệ ngược | Trạng thái cuối |
|---|---|---|---|
| Hai quả cầu kim loại nối bằng dây dẫn, A tích nhiều điện âm | Electron chạy từ A sang B | Hiệu điện thế A–B giảm dần → electron chuyển sang ngày càng ít | Điện thế hai quả cầu bằng nhau |
| Ion dương và ion âm khuếch tán qua màng | Ban đầu ion khuếch tán dễ dàng | Sự khuếch tán đã xảy ra làm việc khuếch tán tiếp càng khó | Cân bằng hai bên màng |
| Bệnh nhiễm trùng gây sốt (> 37 °C) | Vi khuẩn phát triển → thân nhiệt tăng | Nhiệt độ cao lại không thuận lợi cho vi khuẩn phát triển | Thân nhiệt khó tăng thêm |

> [!bay]
> Liên hệ ngược mà giáo trình mô tả là kiểu **kìm hãm** (giảm tốc độ biến đổi, đưa hệ về **ổn định**). Ở môn Sinh lý, đây là **điều hòa ngược âm tính** (negative feedback). Cũng có điều hòa ngược **dương tính** (khuếch đại, ví dụ cơn co tử cung khi chuyển dạ, đông máu), nhưng loại đó **không** làm hệ ổn định.

> [!ung-dung] Hằng định nội môi
> Phần lớn cơ chế giữ hằng định nội môi là liên hệ ngược âm: đường huyết tăng → tụy tiết insulin → đường huyết giảm về bình thường; thân nhiệt tăng → giãn mạch da, vã mồ hôi → thân nhiệt giảm. Khi vòng liên hệ ngược bị hỏng (ví dụ thiếu insulin trong đái tháo đường), đại lượng được điều hòa mất ổn định.

### 3.4. Sự chi phí năng lượng tối thiểu

Muốn sống, cơ thể phải tiêu tốn năng lượng. Năng lượng được tích lũy nhờ thức ăn, đồ uống, ánh sáng, nhiệt môi trường… dưới dạng **mỡ, đường, ATP**. Hoạt động sống tuân theo **quy tắc chi phí tối thiểu**, tương ứng với hoàn cảnh và điều kiện lý – hóa của môi trường (Giáo trình tr. 21–22).

Ví dụ của sách:

- Đang ngủ mà trời chuyển lạnh, cơ thể **tự động co người lại**, giảm diện tích tiếp xúc với môi trường, giảm tỏa nhiệt, nhanh chóng điều hòa thân nhiệt mà không cần suy nghĩ.
- Khi lao động chân tay, các bộ phận cơ thể phối hợp **nhịp nhàng, đồng bộ** để tốn ít năng lượng nhất.
- Động vật **ngủ đông** (gấu, ếch nhái…): hạ thân nhiệt, tim đập chậm, giảm tuần hoàn và hô hấp, giảm tỏa nhiệt, để tiết kiệm năng lượng qua mùa đông.
- **Ô nhiễm môi trường** làm cơ thể phải tốn thêm năng lượng để thích ứng. Vì vậy cần chống ô nhiễm, chọn kỹ thuật và vật liệu sản xuất ít gây hại.

### 3.5. Ngưỡng

Mọi tác động của môi trường đều có thể gây phản ứng ở đối tượng. Câu hỏi là: tác động **lớn đến mức nào** thì mới gây phản ứng?

**Định nghĩa** (diễn đạt lại theo tr. 22): **ngưỡng** của một tác động là **giá trị tối thiểu** của đại lượng vật lý đặc trưng cho tác động. Chỉ khi tác động có độ lớn **bằng hoặc lớn hơn** giá trị đó thì đối tượng mới có đáp ứng.

- **Dưới ngưỡng** → không đáp ứng. Ví dụ: cú đấm quá nhẹ không gây đau; ánh sáng quá yếu không nhìn rõ vật; điện thế quá thấp không gây cảm giác; âm quá nhỏ không nghe thấy.
- **Quá lớn** (vượt một giá trị nhất định) → không còn đáp ứng bình thường nữa, đối tượng chuyển sang trạng thái khác. Ví dụ: ánh sáng quá mạnh gây **chói mắt**, âm quá mạnh gây **đau tai**.
- Vậy ngưỡng có **ít nhất hai giới hạn**: đủ lớn để gây đáp ứng, và đủ nhỏ để không phá vỡ trạng thái nhận thức, phản ứng. Ví dụ: **ngưỡng nghe – ngưỡng đau** (âm thanh); **ngưỡng nhìn – ngưỡng chói** (ánh sáng).
- **Thích nghi**: khi tác động thay đổi, bản thân đối tượng cũng điều chỉnh để tránh đáp ứng quá mạnh. Ví dụ: ánh sáng mạnh thì **đồng tử co nhỏ**, giảm ánh sáng vào đáy mắt.
- **Ngưỡng phân biệt**: khi cường độ âm I thay đổi một lượng ΔI, ta chỉ nhận ra độ to thay đổi khi

=> ΔI/I ≥ 0,1

I: cường độ âm ban đầu; ΔI: độ biến thiên cường độ (cùng đơn vị W/m²).

Nghĩa là cái tai cảm nhận **tỉ lệ** thay đổi chứ không cảm nhận lượng thay đổi tuyệt đối. Âm đang nhỏ thì chỉ cần tăng ít đã nhận ra; âm đang to thì phải tăng nhiều hơn.

> [!ung-dung] Ngưỡng trong lâm sàng
> - Đo **thính lực**: tìm ngưỡng nghe ở từng tần số; ngưỡng nghe tăng là dấu hiệu nghe kém.
> - **An toàn điện**: dòng điện nhỏ dưới ngưỡng cảm giác không gây gì; dòng lớn hơn gây co cơ, rồi rung thất. Thiết bị điện trị liệu luôn được tăng cường độ từ từ.
> - Chỉ số **ngưỡng đau** dùng để đánh giá thuốc giảm đau.

> [!yhct] Điện châm và ngưỡng cảm giác
> - **Phần vật lý – sinh lý đã chứng minh:** dòng điện kích thích qua kim châm chỉ gây cảm giác khi vượt **ngưỡng cảm giác**, và gây đau khi vượt **ngưỡng đau**. Khi kích thích kéo dài với cường độ không đổi, cảm giác **giảm dần do thích nghi** của thụ thể và thần kinh. Vì vậy trong thực hành, cường độ điện châm được **tăng từ từ** đến mức người bệnh thấy rõ nhưng vẫn chịu được (giữa hai ngưỡng), và thường phải chỉnh lại sau vài phút.
> - **Phần quan niệm YHCT:** cảm giác căng, tức, tê lan dọc kinh khi châm được gọi là **đắc khí** và được coi là dấu hiệu châm có hiệu quả. Đây là khái niệm truyền thống; mối liên hệ giữa đắc khí và hiệu quả điều trị vẫn đang được nghiên cứu.
> - Tần số xung và cơ chế giảm đau của điện châm: xem khung YHCT ở bài *Dao động và sóng — âm và siêu âm* (mã vl-04); kim châm làm điện cực và an toàn điện: bài *Điện và sự sống* (mã vl-05).

### 3.6. Tính quy luật đối xứng

Cả vật vô sinh lẫn vật hữu sinh đều có thể có tính đối xứng. Ở sinh vật, đối xứng hình thành qua **tiến hóa**, giúp sinh vật tồn tại và phát triển dễ dàng hơn (Giáo trình tr. 23).

- **Đối xứng gương**: từ con sên, con voi, con hổ đến con người đều có các cặp cấu trúc đối xứng gương: tay trái – tay phải, tai trái – tai phải, hai mắt… Đặc điểm: hai phần đối xứng gương có **thể tích bằng nhau** nhưng **không thể lồng khít** vào nhau (thử đeo găng tay trái vào tay phải). Đối xứng gương có từ mức **phân tử** đến **cơ quan**.
- **Đối xứng trục**: quay một bông hoa quanh trục qua tâm hoa một góc nhất định thì bông hoa trùng lại với chính nó.
- **Đối xứng điểm (đối xứng cầu)**.
- Trên cơ thể người có thể tìm thấy nhiều mặt, trục và điểm đối xứng.

> [!ung-dung] Đối xứng gương ở mức phân tử
> Hai phân tử là ảnh gương của nhau (đồng phân quang học, đã học ở môn Hóa) có công thức giống hệt nhưng không chồng khít được, giống như hai bàn tay. Cơ thể chỉ dùng **L-amino acid** và **D-glucose**. Enzym và thụ thể cũng "phân biệt tay trái – tay phải", nên hai đồng phân gương của một thuốc có thể có tác dụng rất khác nhau. Ví dụ kinh điển là **thalidomid**.

## Tóm tắt

| Chủ đề | Điều cần nhớ |
|---|---|
| Vai trò vật lý | Cơ sở của khoa học tự nhiên; 3 lý do gắn với y học: quy luật, phương pháp – máy móc, phương pháp tư duy |
| 4 tương tác | Hấp dẫn, điện từ, hạt nhân mạnh (≈ 10^−15^ m), hạt nhân yếu (phát xạ β); **điện từ** chủ yếu trong thế giới sống |
| Đo lường | Trị số = đại lượng đo / đơn vị; đơn vị cơ bản → dẫn xuất → hệ đơn vị; CGS, MKS → SI (1960); VN 1965 |
| SI | 7 đơn vị cơ bản: m, kg, s, A, K, mol, cd (sách ghi 6, thiếu mol, viết °K); 1 W = 1 kg·m²·s^−3^ |
| Tiền tố | da, h, k, M, G, T (10^1^ → 10^12^); d, c, m, µ, n, p (10^−1^ → 10^−12^); 1 Å = 10^−10^ m |
| Đổi đơn vị y học | 1 mmHg ≈ 133,3 Pa; 1 kPa ≈ 7,5 mmHg; 1 cal = 4,184 J; glucose mmol/L × 18 = mg/dL; T(K) = t(°C) + 273,15 |
| Thứ nguyên | L, M, T; hai vế công thức cùng thứ nguyên; [áp suất] = M·L^−1^·T^−2^ |
| Vô hướng / vectơ | Trị số / độ lớn + hướng; cộng theo hình bình hành; tích vô hướng (cos, ra số), tích vectơ (sin, ra vectơ ⊥, quy tắc vặn nút chai) |
| Thống kê | 4 nguyên nhân; f = N~A~/N; P = lim f; Ā = ΣA~i~P(A~i~); trung bình sai số = 0; σ² phương sai; phân phối nhị thức, Gauss, Poisson |
| Hàm mũ | dN/dt = ±λN → N = N(0)·e^±λt^; tốc độ tỉ lệ với độ lớn; T~½~ = 0,693/λ |
| Liên hệ ngược | Kết quả kìm hãm quá trình → cân bằng, ổn định (quả cầu tích điện, khuếch tán ion, sốt) |
| Năng lượng tối thiểu | Co người khi lạnh, cử động nhịp nhàng, ngủ đông; ô nhiễm làm tăng chi phí |
| Ngưỡng | Giá trị tối thiểu để có đáp ứng; ít nhất 2 giới hạn (nghe – đau, nhìn – chói); thích nghi; ΔI/I ≥ 0,1 |
| Đối xứng | Gương (thể tích bằng nhau, không lồng khít), trục, điểm (cầu) |
