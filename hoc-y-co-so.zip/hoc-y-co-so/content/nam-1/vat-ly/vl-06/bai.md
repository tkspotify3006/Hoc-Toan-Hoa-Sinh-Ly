---
title: Các định luật quang hình cơ bản — mắt
thoi-gian: 120 phút
muc-tieu:
- Phát biểu được các định luật cơ bản của quang hình học (truyền thẳng, tác dụng độc lập, phản xạ, khúc xạ), điều kiện phản xạ toàn phần, và vẽ đúng đường đi của tia sáng qua gương, bản mặt song song, lăng kính, mặt cầu khúc xạ, thấu kính mỏng.
- Vận dụng được công thức mặt cầu khúc xạ, công thức thấu kính mỏng, độ tụ (điốp) và độ phóng đại.
- Mô tả được hệ quang học của mắt (ba lưỡng chất cầu, mắt thu gọn), sự điều tiết, cận điểm, viễn điểm, khả năng phân ly và thị lực.
- Trình bày được nguyên lý chung của việc sửa các tật khúc xạ (cận, viễn, lão thị, loạn thị) bằng kính.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. **Khúc xạ**: n~1~·sin i~1~ = n~2~·sin i~2~. Đi từ môi trường **chiết quang hơn** sang **kém chiết quang hơn** với **i > i~gh~ = arcsin(n~2~/n~1~)** thì **phản xạ toàn phần**. Đây là nguyên lý của **sợi quang trong ống nội soi**.
> 2. **Thấu kính mỏng** (theo quy ước dấu của sách): 1/s′ − 1/s = 1/f′. **Độ tụ Φ = 1/f′**, đơn vị **điốp (D) = 1/m**. Thấu kính hội tụ Φ > 0, phân kỳ Φ < 0.
> 3. **Mắt** = ba lưỡng chất cầu (giác mạc, mặt trước và mặt sau thủy tinh thể). Có thể thay bằng **mắt thu gọn**: R = 5 mm, n = 1,333, f = 20 mm. **Điều tiết** = thủy tinh thể phồng lên để tăng độ tụ. Mắt thường có viễn điểm C~v~ ở vô cực, cận điểm C~c~ chừng 20 cm.
> 4. **Thị lực T = 1/α~min~** (α~min~ tính bằng **phút**). α~min~ = 1′ thì T = 10/10.
> 5. **Cận**: ảnh rơi **trước** võng mạc, sửa bằng kính **phân kỳ** (D ≈ −1/OC~v~). **Viễn**: ảnh rơi **sau** võng mạc, sửa bằng kính **hội tụ**. **Lão thị**: cận điểm lùi xa, đeo kính hội tụ để nhìn gần. **Loạn thị**: độ tụ khác nhau theo các phương, sửa bằng **kính trụ**.

Mở đầu bài, giáo trình nhắc lại: ánh sáng mang thông tin từ môi trường đến cơ thể. Các định luật quang hình học áp dụng khá chính xác để giải thích sự tạo ảnh trên võng mạc (Giáo trình tr. 204).

**Tia sáng chỉ là khái niệm toán học.** Thu hẹp một lỗ để tách lấy "một tia" thì lúc đầu chùm sáng hẹp lại. Nhưng khi lỗ nhỏ tới một mức nào đó, chùm sáng lại **loe rộng ra** do nhiễu xạ. Vì vậy không thể tách riêng một tia bằng thực nghiệm. Trong thực tế, ta coi một **chùm song song đủ hẹp** là một tia sáng. Quang hình học là phương pháp **gần đúng**: coi các tia độc lập với nhau và tuân theo định luật phản xạ, khúc xạ (tr. 204).

## 1. Các định luật cơ bản của quang hình học

### 1.1. Định luật truyền thẳng

Trong môi trường **trong suốt, đồng tính và đẳng hướng**, ánh sáng truyền theo **đường thẳng** (tr. 204).

**Giới hạn**: khi ánh sáng đi qua lỗ rất nhỏ hoặc gặp vật cản có kích thước **cỡ bước sóng**, định luật không còn đúng. Lúc đó xảy ra **nhiễu xạ** (xem mục 4.1).

### 1.2. Định luật về tác dụng độc lập của các chùm tia

Tác dụng của các chùm sáng khác nhau **không phụ thuộc vào nhau**. Chùm này có mặt hay không cũng không làm thay đổi tác dụng của chùm kia (tr. 204–205).

Định luật này cũng chỉ **gần đúng**. Khi lỗ nhỏ, các chùm sáng có thể **giao thoa**, tăng cường hoặc làm yếu nhau. Tuy nhiên các quang cụ thường dùng **chùm rộng**, nên khi tạo ảnh ta vẫn áp dụng được định luật này.

### 1.3. Định luật phản xạ

Khi tia sáng gặp mặt phân giới giữa hai môi trường, nó bị phản xạ toàn bộ hoặc một phần, theo 3 ý (tr. 205):

- Tia tới và tia phản xạ cùng nằm trong **mặt phẳng tới** (mặt phẳng chứa tia tới và pháp tuyến tại điểm tới).
- **Góc phản xạ bằng góc tới**: i′~1~ = i~1~.
- Đường đi của tia sáng có **tính thuận nghịch**.

### 1.4. Định luật khúc xạ

Khi tia sáng truyền sang môi trường thứ hai (tr. 205–206):

- Tia tới và tia khúc xạ cùng nằm trong mặt phẳng tới.
- Tỷ số sin góc tới và sin góc khúc xạ **không đổi** với một cặp môi trường cho trước:

=> sin i~1~ / sin i~2~ = n~21~

- **n~21~**: **chiết suất tỉ đối** của môi trường 2 đối với môi trường 1 (không có đơn vị).
- **Chiết suất tuyệt đối** (gọi tắt là chiết suất) n của một môi trường là chiết suất tỉ đối của nó so với **chân không**.

Giáo trình chứng minh bằng cách đặt một lớp chân không mỏng giữa hai môi trường. Kết quả:

=> n~21~ = n~2~ / n~1~

Từ đó có dạng đối xứng, dễ nhớ và dễ dùng nhất:

=> n~1~·sin i~1~ = n~2~·sin i~2~

Môi trường có chiết suất tuyệt đối **lớn hơn** gọi là môi trường **chiết quang hơn**.

**Vì sao tia sáng bị gãy khúc?** Chiết suất cho biết ánh sáng đi chậm đi bao nhiêu lần so với trong chân không (n = c/v; điều này giáo trình không viết ra). Khi một mặt sóng xiên tới mặt phân cách, phía nào vào môi trường "chậm" trước thì bị hãm trước. Kết quả là cả mặt sóng bị bẻ hướng. Vì vậy đi vào môi trường chiết quang hơn, tia **lệch lại gần pháp tuyến**. Đi ra môi trường kém chiết quang, tia **lệch xa pháp tuyến**.

> [!vi-du] Tính nhanh
> Tia sáng từ không khí (n = 1) tới mặt nước (n = 1,33) với góc tới 60°:
> sin i~2~ = sin 60° / 1,33 = 0,866 / 1,33 ≈ 0,651 ⇒ i~2~ ≈ 40,6°. Tia lệch lại gần pháp tuyến.

### 1.5. Phản xạ toàn phần

Khi tia sáng đi từ môi trường (1) **chiết quang hơn** sang môi trường (2) **kém chiết quang hơn** (n~1~ > n~2~), góc khúc xạ luôn **lớn hơn** góc tới. Tăng dần góc tới thì góc khúc xạ tăng nhanh hơn. Khi góc tới đạt giá trị:

=> i~gh~ = arcsin(n~2~ / n~1~)

thì góc khúc xạ bằng π/2 (90°), tia khúc xạ đi sát mặt phân giới. i~gh~ là **góc giới hạn** (góc tới hạn) (tr. 206).

**Năng lượng được chia thế nào?** Theo định luật bảo toàn năng lượng, năng lượng chùm tới chia cho chùm phản xạ và chùm khúc xạ. Góc tới càng lớn thì chùm phản xạ càng mạnh, chùm khúc xạ càng yếu. Chùm khúc xạ **giảm đến 0** khi i = i~gh~. Khi **i > i~gh~**, ánh sáng không đi vào môi trường 2 nữa. Cường độ chùm phản xạ **bằng** cường độ chùm tới. Đó là **phản xạ toàn phần** (tr. 206–207).

Hai điều kiện để có phản xạ toàn phần:

1. Ánh sáng đi từ môi trường chiết quang **hơn** sang môi trường chiết quang **kém** (n~1~ > n~2~).
2. Góc tới **i ≥ i~gh~**.

![Hình 1. (a) Ba trường hợp tại mặt phân cách thủy tinh – không khí. (b) Tia sáng phản xạ toàn phần liên tiếp trong lõi sợi quang](phan-xa-toan-phan.svg)

> [!bay]
> - Ánh sáng đi từ không khí **vào** nước hay thủy tinh thì **không bao giờ** phản xạ toàn phần, dù góc tới lớn đến đâu.
> - i~gh~ tính bằng **arcsin(n~nhỏ~/n~lớn~)**. Nếu đảo ngược tỷ số sẽ ra sin > 1, vô nghĩa.
> - Hai môi trường có chiết suất **càng gần nhau** thì i~gh~ **càng lớn** (càng gần 90°). Ví dụ thủy tinh/không khí: i~gh~ ≈ 41,8°. Nước/không khí: arcsin(1/1,33) ≈ 48,8°. Lõi 1,50 / vỏ 1,40: i~gh~ ≈ 69°.

> [!ung-dung] Sợi dẫn quang và ống nội soi
> **Sợi dẫn quang** (bằng thủy tinh hoặc polymer) gồm **lõi** chiết suất cao và **vỏ** chiết suất thấp hơn. Ánh sáng vào đầu sợi dưới góc nhỏ sẽ chạm thành lõi với góc tới lớn hơn i~gh~. Nó phản xạ toàn phần liên tiếp và bị "giam" trong lõi, kể cả khi sợi uốn cong. Vì vậy sợi dẫn được ánh sáng đi rất xa mà hao hụt ít (tr. 207).
> - **Nội soi ống mềm** (dạ dày, đại tràng, phế quản…): một bó sợi dẫn ánh sáng đèn **vào** chiếu sáng nội tạng. Một bó sợi khác **xếp đúng thứ tự** dẫn **hình ảnh** ra ngoài cho thầy thuốc quan sát.
> - Trong bưu điện – viễn thông, cáp quang truyền tín hiệu đi xa.
> - Nếu sợi bị **gập quá gắt**, góc tới tại thành lõi có thể nhỏ hơn i~gh~. Khi đó ánh sáng lọt ra ngoài và hình ảnh tối đi hoặc mất điểm. Đây là lý do phải giữ gìn ống soi, không bẻ gập.

> [!cap-nhat] Nội soi hiện nay
> Giáo trình mô tả nội soi dùng bó sợi dẫn hình ảnh. Hiện nay phần lớn ống nội soi tiêu hóa là **ống soi video**: một **cảm biến ảnh (camera) nhỏ ở đầu ống** chuyển hình thành tín hiệu điện. Sợi quang trong ống chủ yếu còn làm nhiệm vụ **dẫn ánh sáng vào**. Bó sợi dẫn hình vẫn dùng trong một số ống soi nhỏ (soi niệu quản, soi khớp…).

### 1.6. Nguyên lý Fermat

Ánh sáng đi từ điểm này đến điểm khác theo con đường đòi hỏi **thời gian ngắn nhất**. Định luật phản xạ và định luật khúc xạ đều có thể **suy ra** từ nguyên lý này (tr. 207).

## 2. Một số dụng cụ quang hình

### 2.1. Gương phẳng

Gương phẳng là một mặt phẳng phản xạ gần như hoàn toàn ánh sáng chiếu tới (tr. 207).

- Chùm tia phân kỳ từ điểm S, sau khi phản xạ, **vẫn phân kỳ**.
- Ảnh S′ là **ảnh ảo**: nó là giao điểm của **đường kéo dài** các tia phản xạ, không phải của chính các tia.
- SS′ **vuông góc** với mặt gương, và S, S′ cách đều gương (a = a′).
- Ảnh **đối xứng** với vật qua gương, nên **lớn bằng vật**.

### 2.2. Gương cầu

**Gương cầu** là một chỏm cầu phản xạ ánh sáng (tr. 208):

- **Gương cầu lõm**: mặt phản xạ quay về phía tâm mặt cầu.
- **Gương cầu lồi**: mặt phản xạ quay ra **phía ngoài**, ngược phía tâm mặt cầu.
- **Tâm gương** C, **đỉnh gương** O; đường thẳng OC là **trục chính**; các đường khác qua C là **trục phụ**. Chỉ xét gương có **góc mở rất nhỏ**.

> [!bay] Lỗi in trong giáo trình
> Trên tr. 208, câu định nghĩa gương cầu lồi in nhầm là "quay về phía tâm của mặt cầu". Đúng ra: gương **lõm** có mặt phản xạ quay **về phía tâm**, gương **lồi** quay **ra xa tâm**.

**Dựng ảnh**: chọn 2 trong 4 tia đặc biệt.

| Tia tới | Tia phản xạ |
|---|---|
| Song song trục chính | Đi qua (hoặc có đường kéo dài qua) **tiêu điểm F**, trung điểm của OC |
| Đi qua F | Song song trục chính |
| Tới đỉnh O | Đối xứng với tia tới qua trục chính |
| Đi qua tâm C | Phản xạ ngược lại theo chính nó |

**Tiêu cự**: OF = FC = R/2, tức **f = R/2**.

**Ảnh thật** là giao điểm của **các tia thật**. **Ảnh ảo** là giao điểm của các **đường kéo dài** của tia thật, về phía mà tia thật không truyền tới.

Công thức gương cầu suy ra từ công thức mặt cầu khúc xạ bằng cách thay n′ = −n (xem 2.5.4):

=> 1/s′ + 1/s = 2/R = 1/f′

Quy ước dấu của sách: **R < 0 với gương lõm, R > 0 với gương lồi**. Cho R → ∞ ta được gương phẳng: s′ = −s (tr. 215).

### 2.3. Bản mặt song song

Bản mặt song song là một bản trong suốt giới hạn bởi hai mặt phẳng song song. Tia ló **song song** với tia tới (góc tới = góc ló), chỉ bị **dịch ngang** một khoảng Δ (tr. 208–209):

=> Δ = d·sin i·[1 − √((1 − sin²i)/(n² − sin²i))]

- **d**: bề dày bản (m); **i**: góc tới; **n**: chiết suất tỉ đối của bản so với môi trường chứa nó.

Vì vậy nhìn qua bản, điểm S có vẻ nằm ở S′ (ảnh ảo), **gần bề mặt bản hơn** một khoảng:

=> Δ′ = Δ/sin i = d·[1 − √((1 − sin²i)/(n² − sin²i))]

Khi **i ≈ 0** (nhìn gần vuông góc):

=> Δ′ ≈ d·(n − 1)/n

Với góc tới nhỏ, chùm tia đồng quy vẫn giữ được tính đồng quy.

> [!vi-du] Lam kính dày 6 mm
> Thủy tinh n = 1,5, nhìn gần vuông góc: Δ′ = 6·(1,5 − 1)/1,5 = 2 mm. Vật dưới tấm kính như được nâng lên 2 mm. Cùng hiện tượng đó khiến đáy chậu nước trông nông hơn thực tế.

### 2.4. Lăng kính

**Lăng kính** là một khối trong suốt, đồng nhất, giới hạn bởi hai mặt phẳng làm với nhau một góc (tr. 209–211):

- Hai mặt đó là **mặt lăng kính**. Góc giữa chúng là **góc chiết quang α**.
- Giao tuyến của hai mặt là **cạnh**. Mặt đối diện cạnh là **đáy**.

Tia sáng khúc xạ hai lần (tại mặt AB và AC) rồi ló ra, bị lệch về phía **đáy** một **góc lệch δ**:

=> δ = i~1~ + i~2~ − α

(i~1~: góc tới ở mặt thứ nhất; i~2~: góc ló ở mặt thứ hai.)

**Góc lệch cực tiểu.** Thay đổi i~1~ đến khi tia tới và tia ló **đối xứng** qua mặt phân giác của góc chiết quang (i~1~ = i~2~ = i, tia trong lăng kính có i′ = α/2). Khi đó δ nhỏ nhất (δ~min~):

=> n·sin(α/2) = sin[(δ~min~ + α)/2]

Ở góc lệch cực tiểu, lăng kính làm sai lệch chùm tia **ít nhất** nên ảnh có chất lượng tốt nhất. Công thức này còn dùng để **đo chiết suất n** của chất làm lăng kính, khi đo α và δ~min~ bằng **giác kế**.

**Lăng kính góc nhỏ (nêm quang học):**

=> δ~min~ = (n − 1)·α

**Ứng dụng của lăng kính** (tr. 210–211):

- **Máy quang phổ**: chiết suất phụ thuộc bước sóng, nên lăng kính tách chùm sáng phức tạp thành các thành phần đơn sắc. Lăng kính phải đặt ở vị trí góc lệch cực tiểu cho phần quang phổ cần nghiên cứu.
- **Lăng kính phản xạ toàn phần** (lăng kính vuông cân, góc tới ở mặt huyền 45° > i~gh~ ≈ 42° của thủy tinh): dùng để **đổi phương tia sáng 90°**, hoặc **lật ngược ảnh** (phản xạ hai lần ở hai mặt bên, hoặc phản xạ ở mặt đáy).

> [!ung-dung] Lăng kính trong nhãn khoa
> Kính có gắn **lăng kính** làm lệch hướng tia sáng tới mắt. Nhờ vậy ảnh rơi đúng vào điểm vàng của mắt bị lệch trục. Kính này dùng để giảm **song thị** (nhìn một hóa hai) ở người lác, liệt cơ vận nhãn. Lăng kính phản xạ toàn phần cũng có trong ống nhòm và nhiều dụng cụ quang học y khoa.

### 2.5. Mặt cầu khúc xạ

#### 2.5.1. Khái niệm

**Mặt cầu khúc xạ** (lưỡng chất cầu) là một phần mặt cầu ngăn cách hai môi trường trong suốt có chiết suất khác nhau. Đây là dạng mặt quan trọng nhất của thấu kính. Khúc xạ qua mặt cầu là hiện tượng cơ bản để các hệ quang học **tạo ảnh**, kể cả **mắt** (tr. 211).

- Bán kính R, tâm C; chiết suất **n bên trái**, **n′ bên phải**.
- **Quang trục chính**: trục đối xứng đi qua tâm C. Giao điểm với mặt cầu là **đỉnh O**. Mọi đường thẳng khác qua C là **quang trục phụ**.
- Nhiều mặt cầu có tâm cùng nằm trên một đường thẳng tạo thành **hệ quang học đồng trục**.
- **Chùm tia gần trục**: các tia làm với trục chính những góc rất nhỏ. Khi đó sin ≈ tg ≈ góc (radian), nên các công thức trở nên đơn giản.

#### 2.5.2. Quy ước dấu (tr. 212)

Chiều dương là **chiều truyền ánh sáng, từ trái sang phải**. Các góc lấy tại đỉnh.

| Đại lượng | Dương (+) khi | Âm (−) khi |
|---|---|---|
| Đoạn thẳng trên trục chính | Cùng chiều truyền ánh sáng | Ngược chiều |
| Độ cao vật, ảnh | Hướng lên trên trục | Hướng xuống |
| Bán kính R | Tâm C ở **bên phải** mặt cầu | Tâm C ở bên trái |
| Độ dày thấu kính, khoảng cách giữa hai mặt | Luôn dương | — |
| Góc giữa tia và trục (hoặc pháp tuyến) | Quay trục tới tia theo **chiều kim đồng hồ** | Ngược chiều kim đồng hồ |

Khi có **phản xạ** thì đổi dấu n′ và khoảng cách từ mặt phản xạ tới mặt tiếp theo.

Vì vật thật đặt bên trái nên theo quy ước này, **vật thật có s âm** (s < 0). Ảnh thật ở bên phải thì s′ > 0.

#### 2.5.3. Công thức mặt cầu khúc xạ

Xét nguồn điểm P trên trục, tia PM tới mặt cầu tại M. Áp dụng định luật khúc xạ cho tia gần trục (n·i = n′·i′) và hình học tam giác, giáo trình suy ra (tr. 212–213):

=> n′/s′ − n/s = (n′ − n)/R

- **s = OP**: vị trí vật; **s′ = OP′**: vị trí ảnh; **R = OC**. Đều là **độ dài đại số** (m).
- Với n, n′, R cho trước, s′ chỉ phụ thuộc s. Vì vậy **mọi tia gần trục** từ P sau khúc xạ đều cắt nhau tại cùng một điểm P′. **P′ là ảnh điểm của P.**
- Công thức đúng cho mặt cầu lồi về phía nào cũng được, miễn là lấy đúng dấu R. Mặt **lồi** về bên trái thì R > 0; mặt **lõm** (lồi về bên phải) thì R < 0.
- Đặt vật ở P′ thì ảnh ở P: tính **thuận nghịch** (tr. 214).

#### 2.5.4. Tiêu cự và độ tụ của mặt cầu khúc xạ

Cho s = −∞ (chùm tới song song trục), ảnh ở **tiêu điểm ảnh F′**. Cho s′ = ∞, vật ở **tiêu điểm vật F** (tr. 214):

=> f′ = n′·R/(n′ − n)  (tiêu cự ảnh, tiêu cự chính thứ hai)

=> f = −n·R/(n′ − n)  (tiêu cự vật, tiêu cự chính thứ nhất)

=> f′/f = −n′/n

Hai tiêu cự tỷ lệ với chiết suất hai môi trường. **Hai tiêu điểm luôn nằm ở hai bên mặt cầu.**

- Chùm tới song song với một **trục phụ** hội tụ ở một **tiêu điểm phụ**.
- Mặt vuông góc với trục chính tại F (F′) là **tiêu diện** thứ nhất (thứ hai).

**Độ tụ** của mặt cầu khúc xạ (tr. 215):

=> Φ = (n′ − n)/R = n′/f′ = −n/f

**Gương cầu** là trường hợp riêng với n′ = −n. Thay vào được 1/s′ + 1/s = 2/R, f = R/2 và 1/s′ + 1/s = 1/f′ (mục 2.2).

> [!bay] Lỗi in nhỏ
> Ở bước trung gian trên tr. 213, sách in n(1/s − 1/R) = n′(1/s′ − 1/**R′**). Đúng phải là **R** (cùng một mặt cầu). Công thức cuối (6.15) vẫn đúng.

#### 2.5.5. Định lý Lagrange – Helmholtz và điều kiện sin Abbe

Xét vật nhỏ AB = y vuông góc với trục, ảnh A′B′ = y′. Gọi u, u′ là góc mở của chùm tia tới và chùm tia ló (tr. 215–217):

=> y·n·u = y′·n′·u′  (bất biến Lagrange – Helmholtz)

- Với hệ nhiều mặt cầu: y~1~n~1~u~1~ = y~2~n~2~u~2~ = … Chỉ đúng với **tia gần trục**.
- Với **chùm tia rộng**, muốn ảnh rõ nét phải thỏa **điều kiện sin Abbe**:

=> y·n·sin u = y′·n′·sin u′

Ý nghĩa: hai hệ thức này **giới hạn** sự biến đổi chùm sáng của mọi hệ quang học. Chúng liên hệ **khẩu độ và kích thước của vật** với **khẩu độ và kích thước của ảnh**. Muốn ảnh **phóng to** (y′ lớn) thì góc mở của chùm ló u′ phải **nhỏ đi**. Đây là cơ sở thiết kế vật kính kính hiển vi.

#### 2.5.6. Độ phóng đại dài

=> β = y′/y = n·u/(n′·u′) = n·s′/(n′·s)

- **β < 0**: ảnh **ngược chiều** vật. Với mặt cầu khúc xạ, vật thật (s < 0) cho ảnh thật (s′ > 0) thì β < 0.
- **β > 0**: ảnh **cùng chiều** (s, s′ cùng dấu: ảnh ảo).
- Gương cầu (n′ = −n): β = −s′/s. Gương phẳng: s′ = −s nên **β = 1**, ảnh ảo, cùng chiều, bằng vật (tr. 217).

### 2.6. Thấu kính mỏng

#### 2.6.1. Khái niệm

**Thấu kính** là một khối trong suốt đồng chất (thủy tinh, thạch anh…) giới hạn bởi hai mặt, trong đó **ít nhất một mặt là mặt cầu**. Mặt kia có thể là mặt cầu hoặc mặt phẳng (tr. 217–218).

- O~1~, O~2~: đỉnh hai mặt cầu (bán kính R~1~, R~2~). **d = O~1~O~2~** là **độ dày** thấu kính.
- d **rất nhỏ** so với R~1~, R~2~ thì thấu kính coi là **mỏng**. Khi đó O~1~ ≡ O~2~ ≡ O, là **quang tâm**.
- Đường thẳng qua quang tâm là **quang trục**. Quang trục đi qua cả hai tâm mặt cầu là **quang trục chính**; các quang trục khác là **quang trục phụ**.

#### 2.6.2. Công thức thấu kính mỏng

**Cách suy ra**: áp dụng công thức mặt cầu khúc xạ lần lượt cho hai mặt. **Ảnh của mặt thứ nhất là vật (ảo) của mặt thứ hai.** Vì thấu kính mỏng nên s~2~ = s′~1~. Cộng hai phương trình được **công thức tổng quát** (n~1~: môi trường bên trái; n~2~: bên phải; n: chất làm kính) (tr. 218–219):

=> n~2~/s′ − n~1~/s = (n − n~1~)/R~1~ + (n~2~ − n)/R~2~

Thấu kính đặt trong **một môi trường đồng tính** (n~1~ = n~2~). Đặt **N = n/n~1~** là chiết suất tỉ đối của chất làm kính so với môi trường:

=> 1/s′ − 1/s = (N − 1)·(1/R~1~ − 1/R~2~)

Trong **không khí** (n~1~ = 1, N = n):

=> 1/s′ − 1/s = (n − 1)·(1/R~1~ − 1/R~2~)

s, s′, R~1~, R~2~ đều tính **từ quang tâm** và theo quy ước dấu ở 2.5.2.

#### 2.6.3. Tiêu cự – độ tụ

Cho s = −∞ được **tiêu cự ảnh f′**; cho s′ = ∞ được **tiêu cự vật f** (tr. 219–220):

=> f′ = 1 / [(N − 1)·(1/R~1~ − 1/R~2~)]

=> f = −f′

Thấu kính trong môi trường đồng tính có **hai tiêu cự bằng nhau về độ lớn, ngược dấu**. Hai tiêu điểm F, F′ nằm **đối xứng** hai bên thấu kính.

> [!bay]
> Ở công thức (6.40) tr. 219, sách in s = f = 1/[(N − 1)(1/R~1~ − 1/R~2~)] mà **thiếu dấu trừ**. Thay s′ = ∞ vào (6.37) sẽ ra **f = −1/[…]**. Điều này khớp với kết luận f = −f′ ngay trang sau.

- Mặt phẳng vuông góc trục chính tại tiêu điểm là **tiêu diện**. Giao điểm của một trục phụ với tiêu diện là **tiêu điểm phụ**.
- **F′ thật** (chùm song song ló ra **hội tụ**): **thấu kính hội tụ** (thấu kính dương), f′ > 0.
- **F′ ảo** (chùm song song ló ra **phân kỳ**): **thấu kính phân kỳ** (thấu kính âm), f′ < 0.

**Công thức Gauss** (s, s′ tính từ quang tâm):

=> 1/s′ − 1/s = 1/f′

**Công thức Newton** (x = FP: vật tính từ F; x′ = F′P′: ảnh tính từ F′):

=> x·x′ = f·f′ = −f′²

**Độ tụ** của thấu kính mỏng (tr. 221):

=> Φ = (N − 1)·(1/R~1~ − 1/R~2~) = 1/f′

Đơn vị là **điốp (D)**: độ tụ của thấu kính mỏng đặt trong không khí có tiêu cự **1 mét**. **1 D = 1 m^−1^.**

> [!bay] Hai cách viết công thức thấu kính
> Ở phổ thông, các em quen viết **1/d + 1/d′ = 1/f**, với d > 0 cho vật thật và d′ > 0 cho ảnh thật. Sách đại học dùng quy ước dấu theo chiều truyền sáng: **s = −d, s′ = d′**. Thay vào 1/s′ − 1/s = 1/f′ sẽ ra đúng công thức phổ thông. Hai cách cho **cùng kết quả**. Chỉ cần nhất quán, đừng trộn dấu của hai cách trong cùng một bài.
>
> Độ tụ phải tính với f **bằng mét**: f = 25 cm ⇒ Φ = 1/0,25 = **+4 D**, không phải 1/25.

> [!vi-du] Tính tiêu cự từ bán kính
> Thấu kính phẳng – lồi bằng thủy tinh n = 1,5, mặt lồi R = 10 cm, đặt trong không khí. Ánh sáng tới mặt lồi trước nên R~1~ = +10 cm, R~2~ = ∞:
>
> => Φ = (1,5 − 1)·(1/0,10 − 0) = 5 D ⇒ f′ = 20 cm

#### 2.6.4. Các dạng thấu kính (tr. 221)

| Hội tụ (**mép mỏng** hơn giữa) | Phân kỳ (**mép dày** hơn giữa) |
|---|---|
| (1) Hai mặt lồi | (4) Hai mặt lõm |
| (2) Phẳng – lồi | (5) Phẳng – lõm |
| (3) Lồi – lõm (mặt lồi cong hơn, dạng "khum hội tụ") | (6) Lồi – lõm (mặt lõm cong hơn, dạng "khum phân kỳ") |

**Vì sao "mép mỏng là hội tụ" chỉ đúng có điều kiện?** Công thức có thừa số (N − 1). Nếu thấu kính đặt trong môi trường có chiết suất **lớn hơn** chất làm kính (n~1~ > n, N < 1) thì độ tụ **đổi dấu**. Lúc đó các dạng 1, 2, 3 trở thành **phân kỳ**, còn 4, 5, 6 trở thành **hội tụ**. Ví dụ một bọt khí hình hai mặt lồi trong nước là thấu kính **phân kỳ**.

#### 2.6.5. Cách dựng ảnh – độ phóng đại

Để dựng ảnh B′ của điểm B, chọn **2 trong 3 tia** (tr. 221–222):

1. Tia tới **song song trục chính** → tia ló đi qua (hoặc có đường kéo dài đi qua) **tiêu điểm ảnh F′**.
2. Tia tới đi qua (hoặc hướng tới) **tiêu điểm vật F** → tia ló **song song trục chính**.
3. Tia tới qua **quang tâm O** → **truyền thẳng**, không bị khúc xạ (khi thấu kính đặt trong môi trường đồng tính).

![Hình 2. Dựng ảnh qua thấu kính hội tụ bằng các tia đặc biệt: (a) ảnh thật; (b) ảnh ảo (kính lúp)](thau-kinh-hoi-tu.svg)

**Độ phóng đại dài** (tr. 222):

=> β = y′/y = −f/x = −x′/f′

=> β = y′/y = s′/s

Dấu của β cho biết chiều của ảnh, độ lớn của β cho biết ảnh lớn hay nhỏ hơn vật. Theo cách viết phổ thông: k = −d′/d.

| Thấu kính hội tụ, vị trí vật (d = −s) | Ảnh |
|---|---|
| d > 2f | Thật, ngược chiều, **nhỏ hơn** vật (ảnh nằm giữa F′ và 2F′) — như ảnh trên võng mạc |
| d = 2f | Thật, ngược chiều, bằng vật |
| f < d < 2f | Thật, ngược chiều, **lớn hơn** vật — như máy chiếu |
| d = f | Ảnh ở vô cực |
| d < f | **Ảo**, cùng chiều, **lớn hơn** vật — **kính lúp** |

Thấu kính phân kỳ với vật thật **luôn** cho ảnh **ảo, cùng chiều, nhỏ hơn vật**, nằm giữa F′ và quang tâm.

> [!vi-du] Bài toán mẫu
> Thấu kính hội tụ f = 10 cm, vật thật cách kính 30 cm.
>
> => 1/d′ = 1/f − 1/d = 1/10 − 1/30 = 2/30 ⇒ d′ = 15 cm
>
> Ảnh thật, cách kính 15 cm. k = −15/30 = −0,5: ảnh ngược chiều, cao bằng nửa vật.
> Theo cách viết của sách: s = −30 cm, 1/s′ = 1/f′ + 1/s = 1/10 − 1/30 ⇒ s′ = +15 cm, β = s′/s = −0,5.

#### 2.6.6. Thấu kính trụ

**Thấu kính trụ** giống như nhiều thấu kính cầu mỏng giống nhau xếp chồng khít lên nhau. Đường thẳng xx′ vuông góc với hai mặt đáy, đi qua quang tâm các lát, là **trục** của thấu kính trụ (tr. 222–223).

- Chùm song song chiếu dọc theo trục (vuông góc mặt đáy) thì **không bị khúc xạ**.
- Chùm song song chiếu **vuông góc với trục** thì khúc xạ. Thấu kính trụ **hội tụ** đưa chùm này hội tụ trên **một đường thẳng song song với trục**. Thấu kính trụ **phân kỳ** làm chùm ló phân kỳ như xuất phát từ một đường thẳng song song trục ở phía trước kính.
- Vì vậy **ảnh của một điểm qua thấu kính trụ là một đoạn thẳng** nằm trên đường tiêu.

**Bản chất**: thấu kính trụ chỉ có độ tụ theo **một phương**, là phương vuông góc với trục. Theo phương dọc trục nó như một tấm phẳng. Đây là "dụng cụ" để sửa **loạn thị** (mục 5.6).

## 3. Quang hình học của mắt

### 3.1. Sơ lược cấu tạo của mắt

Nhãn cầu gần hình cầu. Theo giáo trình, đường kính trước – sau chừng **22 mm**. Sáu bó cơ vận nhãn giúp mắt quay nhiều phía. Vỏ nhãn cầu có 3 lớp, từ ngoài vào trong (tr. 223–224):

| Lớp | Đặc điểm |
|---|---|
| **Củng mạc** | Bao 3/4 phía sau; lớp xơ dày, dai, trắng như sứ, ánh sáng không lọt qua. 1/4 phía trước là **giác mạc** trong suốt, có **bán kính cong nhỏ hơn** củng mạc (cong hơn, lồi ra phía trước) |
| **Màng mạch** (mạch mạc) | Nhiều mạch máu nuôi mắt và nhiều sắc tố đen, biến lòng nhãn cầu thành **buồng tối**. Phía trước rủ xuống thành **mống mắt** (màng chắn đen hoặc nâu). Ở giữa có lỗ tròn là **đồng tử** |
| **Võng mạc** | Lớp trong cùng, chứa **tế bào cảm thụ ánh sáng** nối với dây thần kinh thị giác |

**Đồng tử** tự thay đổi bán kính để điều chỉnh **thông lượng ánh sáng** vào mắt. Ánh sáng mạnh thì đồng tử **co**, ánh sáng yếu thì đồng tử **giãn**. Đồng tử đóng vai trò như **màn chắn (khẩu độ)** của máy ảnh.

**Võng mạc có hai loại tế bào cảm thụ** (tr. 224):

| | Tế bào **nón** | Tế bào **que** |
|---|---|---|
| Số lượng (sách) | Chừng **7 triệu** | Chừng **130 triệu** |
| Phân bố | Tập trung ở **điểm vàng**. Tại **hố trung tâm** chỉ có nón, mật độ khoảng **150 000 tế bào/mm²** | Tăng dần khi ra xa điểm vàng. Vùng ngoại vi chỉ còn que |
| Chức năng | Cảm thụ ánh sáng **mạnh**; phân biệt **hình thể, màu sắc, chi tiết** | Cảm thụ ánh sáng **yếu** (nhạy hơn nón); chỉ cho cảm giác **sáng – tối** |

Khi nhìn một vật, ta hướng mắt để ảnh rơi vào **hố trung tâm**. Ở đó võng mạc mỏng nhất và dày đặc tế bào nón, nên nhìn rõ chi tiết nhất.

**Môi trường trong suốt bên trong nhãn cầu:**

- **Thủy tinh thể**: trong suốt, hai mặt lồi; **mặt trước cong ít hơn** (bán kính lớn hơn) mặt sau. Nhờ sức căng của **dây chằng treo** và tính đàn hồi của chính nó, thủy tinh thể **thay đổi được bán kính cong mặt trước**, nhờ đó độ tụ của mắt thay đổi. Chiết suất khoảng **1,43**, độ tụ khoảng **12–14 D**.
- **Thủy dịch**: dịch trong suốt giữa giác mạc và thủy tinh thể.
- **Thủy tinh dịch** (dịch kính): giữa thủy tinh thể và võng mạc.
- Các dịch luôn lưu thông nên **áp suất trong mắt** giữ ổn định, sách ghi **12–25 mmHg**.

> [!cap-nhat] Nhãn áp và kích thước nhãn cầu
> - Giáo trình ghi áp suất trong mắt 12–25 mmHg. Hiện nay nhãn khoa lấy **nhãn áp bình thường khoảng 10–21 mmHg**. Nhãn áp cao kéo dài làm tổn thương thần kinh thị giác, gọi là **glôcôm** (thiên đầu thống), một nguyên nhân gây mù không hồi phục.
> - Giáo trình ghi đường kính trước – sau ≈ 22 mm. Các số đo hiện nay cho **chiều dài trục nhãn cầu người lớn trung bình khoảng 23–24 mm**.
> - Đi thi trả lời theo số liệu của sách.

### 3.2. Quang hệ của mắt — ba lưỡng chất cầu

Về phương diện quang hình, mắt gồm các môi trường chiết quang ngăn cách nhau bởi các mặt cầu. Chúng tạo thành **ba lưỡng chất cầu** đồng trục (tr. 224–225):

| Lưỡng chất cầu | Ngăn cách | Thông số (sách) | Độ tụ (sách) |
|---|---|---|---|
| **Giác mạc** | Không khí / thủy dịch | Dày ≈ 1 mm; R ≈ 8 mm; n thủy dịch 1,336 | **≈ 45 D** (lớn nhất) |
| **Mặt trước thủy tinh thể** | Thủy dịch / thủy tinh thể | R ≈ 10 mm; n trung bình 1,388 | ≈ 7 D |
| **Mặt sau thủy tinh thể** | Thủy tinh thể / dịch thủy tinh | R ≈ 8 mm; n dịch thủy tinh 1,36 | ≈ 12 D |

Lưu ý: các độ tụ trên là số tròn của sách, không tính thẳng ra được từ R và n trong bảng (ví dụ mặt trước thủy tinh thể: (1,388 − 1,336)/0,010 ≈ 5 D), vì thủy tinh thể có chiết suất **không đồng đều** (lõi cao hơn vỏ). Cả thủy tinh thể trong mắt có độ tụ khoảng 19–20 D; toàn mắt khoảng 60 D. Đi thi dùng số của sách.

**Vì sao giác mạc "gánh" phần lớn độ tụ?** Độ tụ của một lưỡng chất cầu là Φ = (n′ − n)/R. Tại giác mạc, chênh lệch chiết suất **lớn nhất**: từ không khí n = 1 sang khoảng 1,34. Bên trong mắt, các môi trường có chiết suất **gần nhau** (1,34 – 1,39 – 1,36), nên thủy tinh thể đóng góp ít độ tụ hơn, dù nó là "thấu kính" duy nhất điều chỉnh được.

> [!ung-dung] Vì sao lặn mở mắt dưới nước lại nhìn mờ?
> Dưới nước (n ≈ 1,33), chênh lệch chiết suất ở giác mạc gần như **mất hết**, nên mắt mất phần lớn độ tụ và trở nên "viễn" rất nặng. Đeo kính bơi tạo lại lớp **không khí** trước giác mạc, nên ta lại nhìn rõ. Cũng vì giác mạc gánh nhiều độ tụ nhất, các phẫu thuật khúc xạ hiện nay (như **LASIK**) sửa tật bằng cách **gọt lại độ cong giác mạc**.

**Mắt thu gọn (mắt ước lược).** Ba lưỡng chất cầu có cùng trục chính và hợp lại thành một hệ có **một tâm điểm duy nhất**. Vì vậy có thể thay chúng bằng **một lưỡng chất cầu tổng hợp** (tr. 225):

- Mặt cầu lồi về phía trước, **R = 5 mm**. Đỉnh cách giác mạc **2 mm**.
- **Quang tâm** cách giác mạc **7 mm** và cách võng mạc **15 mm**.
- Chiết suất môi trường trong mắt **n = 1,333**; bên ngoài là không khí (n = 1).

Tiêu cự (ảnh) của mắt thu gọn:

=> f = n·R/(n − 1) = 1,333 × 5 / (1,333 − 1) ≈ 20 mm

Đỉnh mặt cầu cách giác mạc 2 mm, cộng tiêu cự 20 mm thì tiêu điểm ở cách giác mạc **22 mm**, đúng bằng chiều dài nhãn cầu. Như vậy **võng mạc nằm đúng trên tiêu diện ảnh** của mắt khi mắt nghỉ.

- **Trục chính**: đường đi qua đỉnh mặt cầu và quang tâm. **Đường nhìn thẳng**: đường đi qua quang tâm và **điểm vàng**. Khi nhìn vật, mắt hướng đường nhìn thẳng vào vật.
- **Thị trường** (một mắt, nhìn cố định): hình nón có góc mở **ngang 160°**, **đứng 130°**. Thực tế thị trường rộng hơn nhờ mắt xoay trong hốc mắt, nhìn bằng hai mắt và quay đầu (tr. 225).

### 3.3. Sự điều tiết — cận điểm, viễn điểm

Mắt bình thường **khi nghỉ** có tiêu điểm nằm **đúng trên võng mạc**. Vật ở vô cực cho ảnh rõ mà **không cần điều tiết** (tr. 225–226).

**Vì sao phải điều tiết?** Đưa vật lại gần, nếu quang hệ không đổi thì ảnh **lùi ra sau võng mạc** và nhìn mờ. Muốn ảnh trở về võng mạc, mắt phải **tăng độ tụ**: thủy tinh thể **phồng lên**, mặt cong hơn, F′ tiến ra trước võng mạc một chút, và ảnh lại rơi đúng võng mạc. Quá trình này gọi là **sự điều tiết**. Nó diễn ra tự động, khá nhanh, và mắt có xu hướng điều tiết vào chỗ sáng nhất của vật.

> [!vi-du] Cơ chế điều tiết theo sinh lý học
> Giáo trình mô tả ngắn: "các cơ giữ thủy tinh thể bóp lại và nén cho thủy tinh thể phồng lên". Mô tả sinh lý đầy đủ (theo Helmholtz) như sau: khi nhìn gần, **cơ thể mi co** làm vòng cơ hẹp lại, **dây chằng Zinn chùng** ra. Thủy tinh thể bớt bị kéo căng nên **tự phồng lên nhờ tính đàn hồi** của nó, chủ yếu ở mặt trước. Khi nhìn xa, cơ thể mi giãn, dây chằng căng, thủy tinh thể dẹt lại.

**Các điểm đặc trưng:**

- **Cận điểm C~c~**: điểm gần nhất mắt còn nhìn rõ khi **điều tiết tối đa** (thủy tinh thể phồng hết mức). **OC~c~ = ℓ~C~** là **khoảng nhìn rõ ngắn nhất**. Mắt thường: **chừng 20 cm** theo sách.
- **Viễn điểm C~v~**: điểm xa nhất mắt nhìn rõ **mà không phải điều tiết**. **OC~v~ = ℓ~V~** là **khoảng nhìn rõ lớn nhất**. Mắt thường: C~v~ ở **vô cực**.
- **Khoảng nhìn rõ**: đoạn từ C~c~ đến C~v~. Đặt vật ở bất kỳ đâu trong đoạn đó, mắt đều nhìn rõ.

**Biên độ điều tiết** là độ tụ mà mắt **tăng thêm được** khi chuyển từ nhìn ở viễn điểm sang nhìn ở cận điểm. Sách viết (tr. 226):

=> R = 1/ℓ~V~ − 1/ℓ~C~ (ℓ đo bằng mét thì R tính ra điốp)

Mắt thường (ℓ~V~ = ∞, ℓ~C~ = 0,2 m) có biên độ điều tiết 5 D. Những người cùng lứa tuổi, sức khỏe bình thường có biên độ điều tiết **xấp xỉ nhau**, **không phân biệt** mắt cận hay viễn.

> [!bay]
> - Viết theo đúng thứ tự của sách thì 1/∞ − 1/0,2 = −5. Sách vẫn ghi kết quả **R = 5 điốp**. Hiểu đúng là lấy **độ lớn**: R = 1/ℓ~C~ − 1/ℓ~V~ (độ tụ tăng thêm). Ví dụ mắt cận có ℓ~V~ = 50 cm, ℓ~C~ = 10 cm: R = 1/0,1 − 1/0,5 = 10 − 2 = **8 D**.
> - Sách lấy cận điểm mắt thường **chừng 20 cm**. Nhiều tài liệu vật lý phổ thông lấy **25 cm** ("khoảng nhìn rõ ngắn nhất" Đ = 25 cm). Đi thi theo số của sách.
> - Thật ra cận điểm **lùi xa dần theo tuổi**: trẻ em có thể chỉ khoảng 7–10 cm, người 45–50 tuổi đã ra tới 30–50 cm (mục 5.5).

## 4. Khả năng phân ly của mắt

### 4.1. Nhiễu xạ của chùm song song qua một lỗ tròn

Thí nghiệm (tr. 226–227): nguồn điểm S đặt ở tiêu điểm thấu kính L~1~ nên ánh sáng ló ra thành chùm song song. Chùm này đi qua lỗ tròn bán kính R trên màn E~1~. Thấu kính L~2~ hội tụ ánh sáng lên màn E~2~ đặt ở tiêu diện của nó.

- **R lớn**: ánh sáng đi thẳng, trên E~2~ chỉ có một chấm sáng.
- **R khá bé**: trên E~2~ là **vân sáng trung tâm** sáng nhất, bao quanh bởi các **vành khăn sáng – tối xen kẽ**. Càng xa tâm, vân càng mờ và càng hẹp. Đây là **ảnh nhiễu xạ**. Nó chứng tỏ ánh sáng qua khe hẹp không hoàn toàn truyền thẳng.

Bán kính vân sáng trung tâm:

=> ρ = 0,61·λ·f/R

- **λ**: bước sóng ánh sáng (m); **f**: tiêu cự L~2~ (m); **R**: bán kính lỗ (m).

**Vì sao quan trọng?** Ảnh của một **điểm** không bao giờ là một điểm. Nó là một **vết nhiễu xạ** có kích thước hữu hạn. Lỗ càng **nhỏ**, vết càng **to**.

### 4.2. Góc phân ly và thị lực

**Áp dụng cho mắt** (tr. 227): đồng tử đóng vai trò lỗ tròn. Lấy λ trung bình = 0,50 µm (ánh sáng trắng từ 0,40 đến 0,76 µm), tiêu cự mắt f = 20 mm, bán kính đồng tử 2,5 mm:

=> ρ = 0,61 × (0,5·10^−6^ × 20·10^−3^) / (2,5·10^−3^) ≈ 2,44·10^−6^ m = 2,44 µm

Ảnh của **mỗi điểm** trên võng mạc là một vết nhiễu xạ bán kính khoảng 2,44 µm.

**Góc phân ly.** Nhìn vật AB, ảnh A′B′ trên võng mạc **ngược chiều và nhỏ hơn** vật nhiều lần. Nhờ có sự tham gia của ý thức, ta vẫn đánh giá đúng kích thước và vị trí vật. **Góc AOB = α** (O là quang tâm) gọi là **góc trông** (góc phân ly) (tr. 228):

- Vật càng **nhỏ** hoặc càng **xa** thì α càng nhỏ, và A′, B′ càng gần nhau.
- Khi A′ và B′ gần tới mức vết nhiễu xạ chồng lên nhau, mắt **không phân biệt được** A với B nữa.
- **Góc phân ly tối thiểu α~min~** là góc trông nhỏ nhất mà mắt còn phân biệt được hai điểm. α~min~ càng nhỏ thì khả năng phân ly càng tốt.

**Thị lực T**:

=> T = 1/α~min~  (α~min~ tính bằng **phút góc**)

Bảng 6.1 (tr. 228):

| α~min~ | 0,1′ | 0,2′ | 0,5′ | 1′ | 2′ | 5′ | 10′ |
|---|---|---|---|---|---|---|---|
| T | 100/10 | 50/10 | 20/10 | **10/10** | 5/10 | 2/10 | 1/10 |

**Tính α~min~ từ kích thước vật.** Vì α~min~ nhỏ nên α~min~ ≈ d/ℓ (radian), với d = AB là khoảng cách hai điểm và ℓ = OH là khoảng cách từ mắt đến vật:

=> α~min~ (phút) = 3438·d/ℓ  ⇒  T = ℓ / (3438·d)

> [!bay] Lỗi số trong giáo trình
> Sách ghi "1 radian = 3394,28 phút" (tr. 229). Đúng là **1 rad = 180°/π ≈ 57,296° ≈ 3437,7 phút** (≈ 3438′). Hệ số trong công thức (6.52) vì vậy là 1/3438, không phải 1/3394,28. Sai số khoảng 1,3%, không đổi kết luận nhưng nên biết khi tính.

**Hai cách đo thị lực** (tr. 229):

1. **Cố định d, thay đổi ℓ**: chính xác, phát hiện được thay đổi nhỏ, nhưng không thuận tiện.
2. **Cố định ℓ, thay đổi d**: nhanh, thuận tiện. Dùng **bảng chữ cái hoặc ký hiệu có kích thước nhỏ dần**, đặt cách mắt cố định **1–5 m**. Đây là cách đo thị lực thường quy.

> [!vi-du] Bảng thị lực đặt cách 5 m
> Muốn chi tiết (nét chữ, khe chữ C) nhìn dưới góc 1′ = 2,91·10^−4^ rad ở khoảng cách 5 m:
>
> => d = α·ℓ = 2,91·10^−4^ × 5 ≈ 1,45·10^−3^ m ≈ 1,5 mm
>
> Người đọc đúng được hàng có nét chữ 1,5 mm ở 5 m thì đạt thị lực 10/10. Nếu chỉ đọc được hàng có nét chữ gấp đôi (góc 2′) thì T = 5/10.

**Giới hạn lý thuyết do nhiễu xạ (Rayleigh).** Hai điểm còn phân biệt được khi khoảng cách hai ảnh A′B′ ≥ ρ. Lấy khoảng cách từ quang tâm đến võng mạc là 15 mm (tr. 229):

=> α~min~ = ρ/OH′ = 2,44·10^−6^ / 15·10^−3^ ≈ 1,6·10^−4^ rad ≈ 33/60 phút  ⇒  T ≈ 18/10

Thực tế, **mắt bình thường** trong điều kiện chiếu sáng trung bình có **α~min~ ≈ 1 phút**, tức **T = 10/10**. Khả năng phân ly còn phụ thuộc trạng thái sinh lý, bệnh lý, tính chất tế bào cảm thụ, độ rọi và bước sóng ánh sáng. **Tế bào nón phân ly tốt hơn tế bào que.** Vì vậy nhìn chi tiết bằng hố trung tâm thì rõ nhất, còn nhìn bằng rìa võng mạc thì mờ.

> [!ung-dung] Vì sao đồng tử quá nhỏ hay quá to đều làm giảm độ nét?
> - Đồng tử **quá nhỏ** (ánh sáng rất mạnh, thuốc co đồng tử như pilocarpin) thì R nhỏ, vết nhiễu xạ ρ **to ra**, ảnh kém nét.
> - Đồng tử **quá to** (trong tối, nhỏ thuốc giãn đồng tử khi soi đáy mắt) thì nhiều tia **xa trục** đi vào và gây **cầu sai** (mục 5.1). Vì vậy sau khi nhỏ giãn đồng tử, người bệnh nhìn mờ và chói. Phải dặn không tự lái xe.

## 5. Các tật quang hình của mắt và dụng cụ bổ trợ

### 5.1. Quang sai

Thấu kính cầu chỉ cho ảnh "hoàn hảo" với **chùm tia gần trục**. Với chùm rộng hoặc ánh sáng trắng sẽ có **sai sót về quang hình** (tr. 229–230):

- **Cầu sai**: chùm song song rộng đi qua thấu kính. Các tia **gần trục** hội tụ ở điểm **xa** quang tâm hơn các tia **ở mép**. Kết quả là ảnh của một điểm thành một vệt nhòe.
- **Sắc sai**: ánh sáng trắng gồm các bước sóng 0,39–0,76 µm, mà chiết suất n = f(λ) phụ thuộc bước sóng (**tán sắc**). Mỗi màu hội tụ ở một điểm khác nhau trên trục. Ánh sáng **tím** (n lớn hơn) hội tụ **gần** thấu kính hơn ánh sáng **đỏ**.
- **Cách khắc phục**: **ghép các thấu kính hội tụ và phân kỳ** cùng trục để các sai số bù trừ nhau. Riêng sắc sai phải ghép các thấu kính làm bằng **các loại vật liệu khác nhau** (chiết suất và độ tán sắc khác nhau).

### 5.2. Tổng quan về tật khúc xạ

Với mắt **bình thường** (chính thị), ảnh luôn hiện rõ đúng trên võng mạc ở vùng điểm vàng, phản ánh đúng kích thước, màu sắc, tính chất của vật. Cấu tạo mắt có thể không bình thường vì nhiều lý do. Có thể do **bẩm sinh**, do chấn thương để lại **sẹo giác mạc**, do bệnh của các lưỡng chất cầu, hoặc do rối loạn điều tiết. Khi đó ảnh không hiện rõ trên võng mạc, gây ra **cận thị, viễn thị, loạn thị** (tr. 230).

Dụng cụ bổ trợ là **thấu kính cầu mỏng** cho cận và viễn, **thấu kính trụ** cho loạn thị.

![Hình 3. Mắt cận, mắt viễn khi không điều tiết và cách sửa bằng kính](mat-can-vien.svg)

### 5.3. Cận thị và cách sửa

**Đặc điểm** (tr. 231):

- Ở trạng thái nghỉ, **tiêu diện nằm trước võng mạc**. Nhìn vật ở xa thì ảnh rơi **trước** võng mạc, nên nhìn **mờ**.
- **Viễn điểm C~v~ gần hơn** mắt thường (ở một khoảng hữu hạn, không còn ở vô cực). Trong khoảng từ viễn điểm đến cận điểm, mắt cận điều tiết như mắt thường.
- Nói gọn: mắt cận có **độ tụ quá lớn** so với chiều dài nhãn cầu.

**Cách sửa**: dùng **thấu kính phân kỳ**. Kính **làm giảm độ tụ** của cả hệ, để ảnh của vật ở xa lùi về đúng võng mạc.

**Nguyên tắc chọn kính.** Kính phải biến vật ở vô cực thành ảnh ảo nằm tại **viễn điểm** của mắt. Như vậy **tiêu điểm ảnh của kính trùng với C~v~**. Với kính đeo **sát mắt**:

=> f~kính~ = −OC~v~  ⇒  D~kính~ = −1/OC~v~ (OC~v~ tính bằng mét)

> [!vi-du] Tính độ kính cận
> Một học sinh có viễn điểm cách mắt 50 cm. Kính đeo sát mắt cần có:
>
> => D = −1/0,5 = −2 D (kính phân kỳ "cận 2 độ")
>
> Nếu kính đeo cách mắt 1–2 cm thì phải tính f = −(OC~v~ − khoảng cách kính – mắt). Với độ cận nhẹ, sai khác này không đáng kể. Với độ cận nặng (trên −4 D), khoảng cách đỉnh kính ảnh hưởng rõ.

### 5.4. Viễn thị và cách sửa

**Đặc điểm** (tr. 231):

- Ở trạng thái nghỉ, **tiêu diện nằm sau võng mạc**. Nhìn vật ở xa mà không điều tiết thì ảnh rơi **sau** võng mạc.
- Nếu tiêu điểm không quá xa võng mạc, mắt **phải điều tiết ngay cả khi nhìn xa** để tăng độ tụ. Mắt viễn vì thế **luôn phải điều tiết** và dễ mỏi.
- **Viễn nặng**: điều tiết hết mức vẫn không nhìn rõ vật ở xa. Vật càng gần thì ảnh càng lùi xa võng mạc. Vì vậy người viễn nặng **nhìn không rõ cả xa lẫn gần**.
- Chùm tia hội tụ có phương thích hợp vẫn hội tụ được trên võng mạc. Đường kéo dài của chùm tia này cắt trục chính tại một điểm **sau võng mạc**, gọi là **viễn điểm ảo**.
- Nói gọn: mắt viễn có **độ tụ quá nhỏ** so với chiều dài nhãn cầu.

**Cách sửa**: dùng **thấu kính hội tụ** để **tăng độ tụ** của mắt. Độ tụ của kính phải thích hợp để **tiêu diện của hệ (kính + mắt) trùng với võng mạc**.

**Nguyên nhân chung của cận và viễn** (tr. 231):

| Yếu tố | Gây cận | Gây viễn |
|---|---|---|
| Trục nhãn cầu | **Dài** hơn bình thường | **Ngắn** hơn bình thường |
| Bán kính cong các lưỡng chất cầu | **Nhỏ** hơn (cong hơn, độ tụ lớn) | **Lớn** hơn (dẹt hơn, độ tụ nhỏ) |
| Chiết suất môi trường | Tăng | Giảm |

> [!ung-dung] Đục thủy tinh thể và mổ thay thủy tinh thể
> - Khi **đục thủy tinh thể mới bắt đầu**, chất liệu thủy tinh thể **đặc lại**, tỉ trọng và chiết suất tăng, độ tụ tăng. Người bệnh bị **cận** thêm. Có người già thấy mình "đọc sách không cần kính nữa", thực ra là dấu hiệu sớm của đục thủy tinh thể.
> - **Sau khi cắt bỏ thủy tinh thể**, mắt mất một phần độ tụ đáng kể nên bị **viễn rất nặng** (tr. 231).

> [!cap-nhat] Phẫu thuật đục thủy tinh thể hiện nay
> Giáo trình chỉ nêu "sau khi cắt bỏ thủy tinh thể, mắt bị viễn rất nặng". Ngày xưa phải đeo kính hội tụ rất dày (khoảng +10 D trở lên). Hiện nay phẫu thuật chuẩn là **tán nhuyễn thủy tinh thể (phaco) và đặt thủy tinh thể nhân tạo (IOL)** vào bao thủy tinh thể. Độ tụ của IOL được tính trước theo chiều dài trục nhãn cầu và độ cong giác mạc, nên sau mổ mắt gần như hết viễn.

> [!ung-dung] Cận thị học đường
> Cận thị ở trẻ em chủ yếu do **trục nhãn cầu dài ra** trong quá trình lớn. Các nghiên cứu cho thấy **thời gian hoạt động ngoài trời** nhiều hơn giúp giảm nguy cơ khởi phát cận thị. Nên khám mắt định kỳ, đọc sách đủ sáng, giữ khoảng cách và nghỉ mắt khi nhìn gần lâu. Cần nhớ: đeo kính đúng độ **không làm** cận nặng lên. Kính chỉ đưa ảnh về đúng võng mạc.

### 5.5. Mắt người già (lão thị)

**Đặc điểm** (tr. 232):

- Khả năng điều tiết **kém đi** nên **cận điểm lùi xa**, và người già nhìn gần không rõ. Ở tuổi **45–50**, khi đọc sách phải để xa mắt **30–50 cm** mới thấy rõ, nhưng như vậy ảnh lại nhỏ đi.
- **Cách sửa**: đeo thêm một **thấu kính cầu hội tụ** khi nhìn gần. Độ tụ tổng cộng **không quá 3,5 D**. Tuổi **45** đeo kính **+1 D** là vừa. Cứ thêm **5 tuổi**, kính tăng thêm **+0,5 D**.
- Từ **60 tuổi trở lên**, thủy tinh thể có bán kính cong lớn. Khi không điều tiết, tiêu diện nằm **sau võng mạc**, giống mắt viễn, nên **nhìn xa cũng kém**. Muốn nhìn xa phải đeo thêm một kính hội tụ **độ tụ nhỏ**.
- Tóm lại, người già cần **hai kính hội tụ**: kính độ tụ **lớn** để nhìn **gần**, kính độ tụ **nhỏ** để nhìn **xa**. Thường độ tụ kính nhìn gần **gấp khoảng 3 lần** kính nhìn xa. Hai loại kính được ghép **trên cùng một khung** (kính hai tròng).

**Lão thị tương tác với cận và viễn sẵn có:**

- **Mắt cận** khi về già: bán kính cong lưỡng chất cầu tăng, độ tụ giảm, nên **cận nhẹ đi**. Ở tuổi 45–50 có người không cần đeo kính nữa.
- **Mắt viễn** càng già càng **nặng hơn**, và **"già" nhanh hơn** mắt bình thường (cần kính đọc sớm hơn).

> [!bay] Lão thị ≠ viễn thị
> - **Viễn thị**: tật **khúc xạ**. Mắt nghỉ có tiêu diện sau võng mạc, do trục ngắn hoặc độ tụ nhỏ. Có thể có từ nhỏ.
> - **Lão thị**: suy giảm **khả năng điều tiết** theo tuổi. Mắt có thể vẫn nhìn xa tốt, chỉ có **cận điểm lùi xa**.
> - Cả hai đều sửa bằng **kính hội tụ**, nhưng người lão thị đơn thuần chỉ cần kính khi **nhìn gần**.

> [!vi-du] Tính kính đọc sách cho người lão thị
> Một người có cận điểm cách mắt 50 cm, muốn đọc sách cách mắt 25 cm (kính đeo sát mắt). Kính phải cho ảnh ảo của trang sách (d = 25 cm) nằm ở cận điểm (d′ = −50 cm):
>
> => 1/f = 1/d + 1/d′ = 1/0,25 − 1/0,5 = 4 − 2 = 2 ⇒ D = +2 D

> [!cap-nhat] Kính đa tròng
> Ngoài kính hai tròng mà giáo trình mô tả, hiện nay phổ biến **kính đa tròng (progressive)**: độ tụ **tăng dần liên tục** từ vùng nhìn xa (phía trên) xuống vùng nhìn gần (phía dưới), không có đường ranh giới. Ngoài ra còn có **kính áp tròng** và **thủy tinh thể nhân tạo đa tiêu**.

### 5.6. Loạn thị

**Định nghĩa**: loạn thị là tật trong đó **độ tụ của mắt không đều theo mọi phương**. Lý do là các mặt cầu khúc xạ trong mắt không hoàn toàn là mặt cầu, nên ảnh trên võng mạc bị **nhòe** (tr. 232).

**Loạn thị không đều.** Độ cong thay đổi **bất kỳ** theo mọi phương. Nguyên nhân là **sẹo giác mạc**, di chứng **đau mắt hột**, chấn thương do dị vật bắn vào. Sách nêu cách sửa: dán vào giác mạc **một lớp chất dẻo trong suốt** có chiết suất như thủy tinh thể. Lớp này lấp chỗ gồ ghề, tạo lại một mặt khúc xạ trơn.

> [!cap-nhat]
> "Lớp chất dẻo dán vào giác mạc" mà giáo trình mô tả, ngày nay chính là **kính áp tròng cứng thấm khí (RGP)**. Lớp nước mắt giữa kính và giác mạc lấp các chỗ không đều. Trường hợp nặng có thể phải **ghép giác mạc**.

**Loạn thị đều.** Độ cong thay đổi **đều** theo các phương. Mặt khúc xạ không phải chỏm cầu mà là một phần **mặt ellipsoid tròn xoay**. Bán kính cong biến đổi đều từ **kinh tuyến AOB** (ngang) đến **kinh tuyến COD** (đứng), vuông góc nhau (tr. 233). Chùm song song qua mắt **không hội tụ tại một điểm**. Nó hội tụ thành **hai đoạn thẳng (hai tiêu tuyến)** vuông góc nhau, ở hai vị trí khác nhau trên trục.

| | **Theo quy tắc** (sách: 85% loạn thị đều) | **Không theo quy tắc** (15%) |
|---|---|---|
| Kinh tuyến cong hơn (theo sách) | **Ngang** AOB có bán kính nhỏ hơn ⇒ độ tụ phương ngang lớn hơn | **Đứng** COD có bán kính nhỏ hơn ⇒ độ tụ phương đứng lớn hơn |
| Tương đương | Lưỡng chất cầu + thấu kính trụ **hội tụ trục ngang** (hoặc trụ **phân kỳ trục đứng**) | Lưỡng chất cầu + trụ **hội tụ trục đứng** (hoặc trụ **phân kỳ trục ngang**) |
| Hai tiêu tuyến | Đoạn **ngang** ở **trước** đoạn đứng | Đoạn **đứng** ở **trước** đoạn ngang |

**Phân loại theo vị trí võng mạc** so với hai tiêu tuyến (tr. 233–234):

| Loại | Vị trí hai tiêu tuyến so với võng mạc |
|---|---|
| **Loạn cận đơn** | Một tiêu tuyến **trên** võng mạc, tiêu tuyến kia **trước** võng mạc |
| **Loạn viễn đơn** | Một tiêu tuyến trên võng mạc, tiêu tuyến kia **sau** võng mạc |
| **Loạn cận kép** | **Cả hai** đều **trước** võng mạc |
| **Loạn viễn kép** | **Cả hai** đều **sau** võng mạc |
| **Loạn hỗn hợp** | Một **trước**, một **sau** võng mạc |

**Cách sửa** (tr. 234): phối hợp **thấu kính cầu** và **thấu kính trụ** thích hợp.

- **Loạn cận đơn theo quy tắc**: đoạn **đứng** ở võng mạc, đoạn **ngang** ở **trước** võng mạc. Phải **giảm độ tụ** theo phương tạo ra đoạn ngang để đoạn này lùi về võng mạc. Sách chỉ định: đeo **thấu kính trụ phân kỳ có trục nằm ngang**.
- **Loạn hỗn hợp không theo quy tắc** (đoạn đứng trước, đoạn ngang sau võng mạc). Có hai cách:
  - Dùng **kính cầu hội tụ** đưa về **loạn cận đơn**, rồi dùng **trụ phân kỳ trục đứng**.
  - Hoặc dùng **kính cầu phân kỳ** đưa về **loạn viễn đơn**, rồi dùng **trụ hội tụ**.
- **Nguyên tắc chung**: mọi loạn hỗn hợp và loạn kép đều dùng **kính cầu** đưa về **loạn đơn**, rồi dùng **kính trụ** sửa tiếp. Thực tế kính cầu và kính trụ được **ghép thành một tròng** (kính cầu – trụ).

> [!cap-nhat] Cách gọi "theo quy tắc" trong nhãn khoa hiện nay
> Nhãn khoa hiện nay gọi **loạn thị theo quy tắc** (with-the-rule) là khi **kinh tuyến đứng cong hơn**, tức độ tụ theo phương **đứng** lớn hơn. Loại này hay gặp ở người trẻ, một phần do áp lực của mi mắt. Nó được sửa bằng **trụ phân kỳ trục ngang (180°)**, trùng với cách sửa giáo trình nêu. Câu mô tả kinh tuyến trên tr. 233 của sách (kinh tuyến **ngang** cong hơn) ngược với cách gọi này, và cũng **mâu thuẫn với chính các ý khác của sách**: "tương đương trụ hội tụ trục ngang", "đoạn ngang ở trước đoạn đứng" và "sửa bằng trụ phân kỳ trục ngang" đều chỉ đúng khi độ tụ theo phương **đứng** lớn hơn (trụ tác dụng vuông góc với trục của nó). Nói cách khác, sách chỉ nhầm ở câu gán kinh tuyến; các phần còn lại khớp với nhãn khoa hiện nay. Khi học, nắm chắc **nguyên tắc**: trụ có tác dụng **vuông góc với trục của nó**, đặt kính trụ để bù đúng phương có độ tụ sai. Đi thi trả lời theo sách.

> [!bay] Trục của thấu kính trụ
> Thấu kính trụ **không có độ tụ dọc theo trục** của nó. Nó chỉ hội tụ (hoặc phân kỳ) ánh sáng theo phương **vuông góc với trục**. Vì vậy "trụ trục ngang" thay đổi độ tụ theo phương **đứng**, và ngược lại. Đây là chỗ rất dễ nhầm.

## Tóm tắt

| Chủ đề | Điểm cốt lõi |
|---|---|
| Định luật cơ bản | Truyền thẳng (môi trường trong suốt, đồng tính, đẳng hướng; sai khi vật cỡ λ); tác dụng độc lập (gần đúng); phản xạ i′ = i; khúc xạ n~1~sin i~1~ = n~2~sin i~2~, n~21~ = n~2~/n~1~; thuận nghịch; Fermat (thời gian ngắn nhất) |
| Phản xạ toàn phần | n~1~ > n~2~ và i ≥ i~gh~ = arcsin(n~2~/n~1~); thủy tinh/không khí ≈ 42°, nước/không khí ≈ 49°; sợi dẫn quang, nội soi, lăng kính phản xạ toàn phần |
| Gương | Phẳng: ảnh ảo, đối xứng, bằng vật (β = 1). Cầu: f = R/2; 1/s′ + 1/s = 2/R; 4 tia đặc biệt |
| Bản mặt song song | Tia ló // tia tới, dịch Δ; i ≈ 0: Δ′ ≈ d(n − 1)/n |
| Lăng kính | δ = i~1~ + i~2~ − α; δ~min~: n·sin(α/2) = sin[(δ~min~ + α)/2]; α nhỏ: δ = (n − 1)α; máy quang phổ |
| Mặt cầu khúc xạ | n′/s′ − n/s = (n′ − n)/R; f′ = n′R/(n′ − n), f = −nR/(n′ − n); Φ = (n′ − n)/R; ynu = y′n′u′; sin Abbe; β = ns′/(n′s) |
| Thấu kính mỏng | 1/s′ − 1/s = (N − 1)(1/R~1~ − 1/R~2~) = 1/f′; f = −f′; Newton xx′ = −f′²; Φ = 1/f′ (D = m^−1^); β = s′/s; mép mỏng = hội tụ (khi N > 1); 3 tia đặc biệt |
| Thấu kính trụ | Chỉ có độ tụ theo phương ⊥ trục; ảnh của điểm là đoạn thẳng |
| Mắt | Nhãn cầu ≈ 22 mm (sách); nón 7 triệu (màu, chi tiết, điểm vàng 150 000/mm²), que 130 triệu (sáng – tối, ánh sáng yếu); thủy tinh thể n ≈ 1,43, 12–14 D; áp suất 12–25 mmHg (sách) |
| Ba lưỡng chất cầu | Giác mạc 45 D; mặt trước TTT 7 D; mặt sau TTT 12 D. Mắt thu gọn: R = 5 mm, n = 1,333, f = 20 mm; quang tâm cách giác mạc 7 mm, võng mạc 15 mm; thị trường 160° × 130° |
| Điều tiết | Thủy tinh thể phồng ⇒ độ tụ tăng; C~c~ ≈ 20 cm, C~v~ = ∞ (mắt thường); biên độ điều tiết 5 D |
| Phân ly – thị lực | ρ = 0,61λf/R ≈ 2,44 µm; α~min~ ≈ d/ℓ; T = 1/α~min~ (phút); mắt thường α~min~ = 1′ ⇒ 10/10; đo ở 1–5 m bằng bảng chữ; nón phân ly tốt hơn que |
| Quang sai | Cầu sai (tia mép hội tụ gần hơn), sắc sai (n phụ thuộc λ); khắc phục bằng ghép thấu kính |
| Cận | Tiêu diện trước võng mạc, C~v~ gần; kính phân kỳ, D = −1/OC~v~; trục dài / R nhỏ / n tăng; đục TTT sớm gây cận |
| Viễn | Tiêu diện sau võng mạc, luôn phải điều tiết, viễn điểm ảo; kính hội tụ; bỏ TTT gây viễn rất nặng |
| Lão thị | Cận điểm lùi xa; 45 tuổi +1 D, +0,5 D mỗi 5 tuổi, tổng ≤ 3,5 D; ≥ 60 tuổi cần thêm kính nhìn xa; kính gần ≈ 3 × kính xa; kính hai tròng |
| Loạn thị | Không đều (sẹo, mắt hột: chất dẻo dán giác mạc, nay là kính áp tròng cứng); đều (ellipsoid): theo quy tắc 85% / không theo quy tắc 15%; loạn cận/viễn đơn, kép, hỗn hợp; sửa bằng kính cầu + trụ |
