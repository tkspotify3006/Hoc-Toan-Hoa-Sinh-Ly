---
title: Dao động và sóng — âm và siêu âm
thoi-gian: 120 phút
muc-tieu:
- Nêu được các đại lượng đặc trưng của dao động cơ học và sóng cơ học (biên độ, tần số, chu kỳ, pha, bước sóng, cường độ, sóng trở).
- Phân biệt được 3 dạng dao động cơ (điều hòa, tắt dần, cưỡng bức – cộng hưởng) và 2 dạng sóng cơ (ngang, dọc); giải thích được hiệu ứng Doppler.
- Trình bày được đặc trưng của dao động điện từ (mạch LC, RLC, cộng hưởng) và sóng điện từ (tốc độ, sóng ngang, năng lượng).
- Giải thích được nguyên lý biến đổi, khuếch đại, ghi tín hiệu và nguyên lý phân tích một dao động phức tạp thành các dao động điều hòa.
- Trình bày được bản chất vật lý của âm, các đặc trưng cảm giác âm (độ cao, âm sắc, độ to – dB, phon), quá trình nghe và cơ sở vật lý của gõ, nghe, siêu âm trong chẩn đoán và điều trị.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. **Dao động điều hòa**: lực kéo về tỷ lệ với độ dời (F = −kx) ⇒ x = A·cos(ωt + α), ω = √(k/m). Có **lực cản** ⇒ **tắt dần** (biên độ giảm theo e^−βt^, chu kỳ dài hơn). Có **ngoại lực tuần hoàn** ⇒ **cưỡng bức**, tần số ngoại lực gần tần số riêng ⇒ **cộng hưởng**.
> 2. **Sóng cơ** = dao động lan truyền trong môi trường đàn hồi, chỉ truyền **năng lượng**, không truyền vật chất. Sóng **ngang** chỉ đi trong chất rắn (và mặt chất lỏng); sóng **dọc** đi được trong rắn, lỏng, khí. λ = v·T = v/f; cường độ I ∝ a²f²; **sóng trở Z = ρ·v**.
> 3. **Sóng điện từ**: E ⊥ H ⊥ phương truyền (sóng ngang), đi được trong **chân không** với c = 3·10^8^ m/s; mạch LC có T~0~ = 2π√(LC).
> 4. **Âm** 16 Hz – 20 000 Hz (sóng dọc); dưới là **hạ âm**, trên là **siêu âm**. Độ cao ↔ **tần số**; âm sắc ↔ **thành phần họa âm**; độ to ↔ **cường độ**, đo bằng **dB = 10·lg(I/I~0~)**, I~0~ = 10^−12^ W/m².
> 5. **Siêu âm chẩn đoán** dựa vào **phản xạ ở mặt phân cách có âm trở khác nhau** (cần **gel** vì không khí phản xạ gần hết) và **hiệu ứng Doppler** (đo dòng máu).

Mở đầu chương, giáo trình nhấn mạnh rằng hiện tượng tuần hoàn có mặt khắp nơi: từ chu kỳ hoạt động của Mặt Trời, tuần trăng, đến điện tim, điện não, âm và siêu âm trong cơ thể. Hầu hết kỹ thuật chẩn đoán hiện đại đều dựa trên **dao động và sóng** (Giáo trình tr. 110).

## 1. Dao động cơ học

**Chuyển động tuần hoàn** là chuyển động lặp lại sau những khoảng thời gian bằng nhau. Nếu vật còn **lệch qua lệch lại quanh một vị trí cân bằng** thì gọi là **dao động** (Giáo trình tr. 110).

### 1.1. Dao động điều hòa

**Khái niệm.** Xét con lắc đơn chiều dài l, kéo lệch một góc nhỏ. Thành phần trọng lực theo phương tiếp tuyến là:

=> P~t~ = −(x/l)·P

Lực này **tỷ lệ với độ dời x** và **luôn hướng về vị trí cân bằng** (dấu trừ). Giáo trình định nghĩa: **dao động điều hòa là dao động sinh ra dưới tác dụng của lực tỷ lệ với độ dịch chuyển và hướng về vị trí cân bằng** (tr. 111).

**Phương trình.** Với lực kéo về F = −k·x (k: hệ số đàn hồi, N/m), định luật Newton 2 cho:

=> m·d²x/dt² + k·x = 0

=> d²x/dt² + ω²x = 0, với ω = √(k/m)

Nghiệm của phương trình vi phân bậc hai này:

=> x = A·cos(ωt + α)

- **x**: li độ (độ dịch chuyển), m.
- **A**: biên độ (li độ cực đại), m — do điều kiện ban đầu quyết định.
- **(ωt + α)**: pha dao động; **α**: pha ban đầu (pha lúc t = 0).
- **ω**: tần số góc, rad/s.

**Chu kỳ và tần số.** Hàm cos lặp lại sau 2π, nên sau thời gian 2π/ω vật trở về trạng thái cũ:

=> T = 2π/ω (s);  f = 1/T (Hz);  ω = 2πf

1 Hz = 1 dao động toàn phần mỗi giây. Ví dụ của sách: máy có tần số 50 Hz thực hiện 50 dao động toàn phần trong 1 s (tr. 112).

**Vận tốc, gia tốc, năng lượng** (tr. 112–113):

=> v = dx/dt = −A·ω·sin(ωt + α)

=> a = d²x/dt² = −ω²·x = −(4π²/T²)·x

- Gia tốc **luôn ngược dấu với li độ**, tức luôn hướng về vị trí cân bằng.
- Ở vị trí cân bằng, tốc độ cực đại |v| = A·ω, toàn bộ năng lượng là động năng:

=> E = ½·m·A²·ω² = 2π²·m·A²·f²

**Vì sao quan trọng?** Năng lượng dao động tỷ lệ với **bình phương biên độ** và **bình phương tần số**. Đây là lý do một sóng tần số cao như siêu âm mang năng lượng lớn dù biên độ dao động của phân tử rất nhỏ.

> [!bay]
> - Tăng gấp đôi biên độ ⇒ năng lượng tăng **4 lần**, không phải 2 lần. Tăng gấp đôi tần số cũng ⇒ năng lượng ×4.
> - Trong dao động điều hòa lý tưởng, **A không đổi nên năng lượng không đổi**. Chu kỳ chỉ phụ thuộc **k và m** (đặc tính của hệ), không phụ thuộc biên độ.

### 1.2. Dao động tắt dần

Trong thực tế, con lắc rồi cũng dừng vì **lực cản của môi trường**. Khi vận tốc nhỏ, lực cản tỷ lệ với vận tốc:

=> F~c~ = −r·dx/dt  (r: hệ số cản, kg/s)

Phương trình dao động trở thành m·d²x/dt² + r·dx/dt + k·x = 0, có nghiệm (tr. 113):

=> x = A·e^−βt^·cos(ω\*·t + α)

=> β = r/(2m)  (hệ số tắt dần, s^−1^)

=> ω\* = √(k/m − β²) = √(k/m − r²/4m²)

- Thừa số **e^−βt^** làm **biên độ giảm theo hàm mũ**; thừa số cos(ω\*t + α) thể hiện vẫn còn dao động.
- **ω\* < ω~0~ ⇒ chu kỳ tắt dần T\* > T**: môi trường "níu" vật lại, mỗi dao động kéo dài hơn.
- Để đo mức tắt dần nhanh hay chậm, dùng **giảm lượng loga** (logarithmic decrement), là logarit nêpe của tỷ số hai biên độ cách nhau một chu kỳ:

=> Δ = ln[A·e^−βt^ / A·e^−β(t+T)^] = β·T

![Hình 1. Dao động tắt dần (trái) và đường cong cộng hưởng của dao động cưỡng bức (phải)](dao-dong-tat-dan-cong-huong.svg)

### 1.3. Dao động cưỡng bức và cộng hưởng

**Dao động cưỡng bức.** Muốn duy trì dao động, phải tác dụng một **ngoại lực tuần hoàn** F = H·cos(p·t) (H: biên độ ngoại lực, p: tần số góc ngoại lực). Lúc đó vật chịu 3 lực: lực kéo về −kx, lực cản −r·dx/dt và ngoại lực (tr. 114–115):

=> m·d²x/dt² = −r·dx/dt − k·x + H·cos(pt)

Sau giai đoạn quá độ, vật dao động theo:

=> x = B·cos(pt + γ)

=> B = (H/m) / √[(ω~0~² − p²)² + 4β²p²]

(ω~0~² = k/m là tần số riêng, β = r/2m.) Từ đó:

- **Tần số dao động cưỡng bức = tần số ngoại lực p** (không phải tần số riêng).
- **Biên độ B** phụ thuộc vào p, ω~0~, H và độ cản β.

**Cộng hưởng** là trường hợp riêng của dao động cưỡng bức khi **biên độ đạt cực đại** ứng với một tần số ngoại lực thích hợp. Tìm cực tiểu của mẫu số được (tr. 115–116):

=> p~CH~ = √(ω~0~² − 2β²)

=> B~max~ = H / [2mβ·√(ω~0~² − β²)]

Khi lực cản không đáng kể (β → 0) thì **p = ω~0~** và B tăng rất lớn.

> [!bay] Lỗi in trong giáo trình
> Công thức (4.15) trên tr. 115 in thiếu bình phương ở mẫu số: đúng phải là **(ω~0~² − p²)²** + 4β²p². Nếu thiếu bình phương, đạo hàm sẽ không cho ra công thức (4.18).

**Ý nghĩa.** Cộng hưởng vừa có hại vừa có lợi. Máy rung có thể làm sàn nhà rung mạnh, truyền vào cơ thể bệnh nhân và gây bệnh chấn động; quạt trần cộng hưởng có thể làm sập trần (tr. 116). Ngược lại, nhờ cộng hưởng mà ta **tách được các thành phần của âm**, và giải thích được vì sao âm phát ra từ cơ thể to lên khi gặp "hộp cộng hưởng" (ống nghe, xoang).

> [!ung-dung] Rung toàn thân trong lao động
> Các cơ quan trong cơ thể có tần số riêng thấp (vài Hz đến vài chục Hz). Lái máy kéo, máy khoan, đầm bê tông… lâu ngày có thể gây **bệnh rung nghề nghiệp**: tổn thương mạch máu đầu chi (hội chứng ngón tay trắng), xương khớp, thần kinh. Phòng bệnh bằng đệm chống rung, giảm thời gian tiếp xúc — tức là **tránh vùng cộng hưởng** và **tăng cản** (tăng β).

### 1.4. Tổng hợp và phân tích dao động

Nếu một chất điểm tham gia đồng thời hai dao động x~1~ và x~2~ thì dao động tổng hợp là x(t) = x~1~(t) + x~2~(t) (tr. 116).

- Tổng hợp hai dao động điều hòa **khác tần số** cho một **dao động phức tạp** (không còn hình sin).
- Tổng hợp hai dao động điều hòa **cùng tần số** cho một dao động điều hòa **cùng tần số đó**:
  - **Cùng pha** (α~1~ = α~2~ + 2kπ): hai dao động **tăng cường** nhau.
  - **Ngược pha** (α~1~ = α~2~ + (2k+1)π): hai dao động **làm yếu** nhau.

**Phân tích** là bài toán ngược. Toán học và thực nghiệm đều chứng minh: **mọi dao động phức tạp tuần hoàn đều phân tích được thành tổng các dao động điều hòa**, mà tần số là **bội số nguyên của một tần số cơ bản** (chuỗi Fourier) (tr. 118).

> [!ung-dung] Phân tích Fourier ở khắp nơi trong y học
> Máy điện não đo phân tích tín hiệu thành các dải tần (sóng δ, θ, α, β); máy siêu âm Doppler phân tích phổ tần của tín hiệu phản xạ để tính vận tốc máu; máy MRI dựng ảnh nhờ biến đổi Fourier. Tai người cũng là một "máy phân tích Fourier" sinh học (mục 5.4).

## 2. Sóng cơ học trong môi trường đàn hồi

### 2.1. Môi trường đàn hồi

Là môi trường gồm các phần tử có **lực liên kết** với nhau. Khi khoảng cách x < x~0~ thì lực là **đẩy**, x > x~0~ thì lực là **hút** (tr. 118). Nếu một phần tử O bị lệch khỏi vị trí cân bằng, các phần tử bên cạnh kéo – đẩy nó, rồi nó lại kéo – đẩy các phần tử kế tiếp. Dao động cứ thế lan đi: đó là **sóng cơ**, O là **nguồn sóng**.

**Vì sao sóng không mang vật chất đi?** Mỗi phần tử chỉ dao động quanh vị trí cân bằng của nó. Thứ được truyền đi là **trạng thái dao động và năng lượng**. Ném hòn đá xuống ao: sóng lan ra xa nhưng chiếc lá trên mặt nước chỉ nhấp nhô tại chỗ.

### 2.2. Sóng ngang và sóng dọc

**Sóng cơ** là dao động cơ học lan truyền trong môi trường đàn hồi (tr. 118).

| | **Sóng ngang** | **Sóng dọc** |
|---|---|---|
| Phương dao động của phần tử | **Vuông góc** với phương truyền | **Song song** (trùng) với phương truyền |
| Điều kiện môi trường | Có lực đàn hồi chống lại **sự lệch giữa các lớp** (biến dạng trượt) | Có lực đàn hồi chống lại **sự nén – dãn** |
| Truyền được trong | **Chất rắn** và **mặt ngoài chất lỏng** | **Rắn, lỏng, khí** |
| Ví dụ | Sóng trên dây đàn, sóng mặt nước | **Âm, siêu âm** trong không khí và mô |

Mô hình 5 phần tử của giáo trình (tr. 119–121) cho thấy: sau đúng một chu kỳ T, dao động từ phần tử 0 truyền tới phần tử 4, và phần tử 4 có trạng thái **y hệt nguồn lúc ban đầu**.

**Tốc độ truyền sóng** phụ thuộc vào tính đàn hồi và mật độ môi trường (tr. 121):

=> v = √(N/ρ)

(N: hệ số đàn hồi của môi trường, Pa; ρ: mật độ, kg/m³.)

### 2.3. Đặc điểm của sóng cơ — phương trình, bước sóng, năng lượng

**Phương trình sóng.** Nguồn O dao động a·cos(ωt + α). Sóng đi với tốc độ v, tới điểm M cách O một đoạn x thì chậm hơn một khoảng x/v. Vậy M lặp lại dao động mà O đã có trước đó x/v giây (tr. 121–122):

=> f~M~(t) = a·cos[ω(t − x/v) + α]

=> f~M~(t) = a·cos(ωt − kx + α)

- **k = ω/v**: số sóng (rad/m).
- **λ** = quãng đường sóng đi trong một chu kỳ = **bước sóng**:

=> λ = v·T = v/f = 2π/k

- Hàm sóng này thỏa mãn **phương trình sóng** ∂²f/∂x² = (1/v²)·∂²f/∂t², trong đó v là tốc độ pha.

> [!bay] Hai "vận tốc" khác nhau
> **Tốc độ truyền sóng v** (ví dụ 1540 m/s trong mô) khác hẳn **tốc độ dao động df/dt của phần tử** (rất nhỏ, đổi chiều liên tục). Phần tử chỉ dao động quanh vị trí cân bằng (tr. 122).

**Năng lượng và cường độ sóng.** Động năng trung bình của phần tử khối lượng m là ¼·m·a²·ω² (tr. 122). **Cường độ sóng** I là công suất sóng truyền qua một đơn vị diện tích đặt vuông góc với phương truyền (W/m²):

=> I = 2π²·ρ·v·f²·a²

- **I ∝ a²** và **I ∝ f²**.
- Đại lượng **Z = ρ·v** gọi là **sóng trở** (kg/m²·s). Với sóng âm, Z gọi là **âm trở** (trở kháng âm, *acoustic impedance*). Công thức I = 2π²·Z·f²·a² tương tự công suất điện P = R·I².

**Phản xạ và khúc xạ ở mặt phân cách** (tr. 123–124). Sóng tới mặt phân cách giữa hai môi trường có sóng trở Z~1~, Z~2~ sẽ tách thành sóng phản xạ và sóng truyền qua (khúc xạ). Góc tới bằng góc phản xạ. Khi sóng tới **vuông góc**:

Tỷ số biên độ phản xạ / tới:

=> a~p~/a~t~ = (Z~1~ − Z~2~)/(Z~1~ + Z~2~)

Tỷ số cường độ phản xạ (I~p~) và truyền qua (I~q~) so với cường độ tới (I~t~):

=> I~p~/I~t~ = [(Z~1~ − Z~2~)/(Z~1~ + Z~2~)]²

=> I~q~/I~t~ = 4Z~1~Z~2~/(Z~1~ + Z~2~)²

=> I~t~ = I~p~ + I~q~

**Ý nghĩa then chốt:** hai môi trường có **Z càng chênh lệch** thì sóng **phản xạ càng nhiều**, truyền qua càng ít. Đây là chìa khóa để hiểu tai giữa (mục 5.4) và siêu âm (mục 5.6).

### 2.4. Hiệu ứng Doppler

Nguồn phát tần số f, sóng truyền với tốc độ v. Nếu nguồn và máy thu **đứng yên** thì máy thu nhận đúng tần số f. Nếu một trong hai (hoặc cả hai) **chuyển động** thì tần số thu được f' ≠ f (tr. 124–125). Ký hiệu θ là góc giữa vận tốc chuyển động và phương truyền sóng từ nguồn tới máy thu:

- Nguồn chuyển động (vận tốc v~n~):

=> f' = f / [1 − (v~n~/v)·cos θ~n~]

- Máy thu chuyển động (vận tốc v~t~):

=> f' = f·[1 − (v~t~/v)·cos θ~t~]

- Cả hai cùng chuyển động:

=> f' = f·[1 − (v~t~/v)·cos θ~t~] / [1 − (v~n~/v)·cos θ~n~]

**Quy tắc nhớ:** nguồn và máy thu **lại gần nhau ⇒ f' > f** (âm nghe "cao" hơn); **ra xa nhau ⇒ f' < f**. Ví dụ quen thuộc: tiếng còi xe cấp cứu cao lên khi xe tiến lại và trầm xuống khi xe đi xa.

> [!vi-du] Từ công thức sách đến công thức máy siêu âm Doppler
> Trong siêu âm Doppler, hồng cầu **vừa là máy thu** (nhận sóng từ đầu dò) **vừa là nguồn phát lại** (phản xạ về đầu dò), nên hiệu ứng xảy ra **hai lần**. Khi tốc độ máu u ≪ c (c ≈ 1540 m/s), ghép hai công thức trên được:
>
> => Δf = f' − f~0~ ≈ 2·f~0~·u·cos θ / c
>
> θ là góc giữa chùm siêu âm và hướng dòng máu. Ví dụ: f~0~ = 4 MHz, u = 0,5 m/s, θ = 60°: Δf = 2 × 4·10^6^ × 0,5 × 0,5 / 1540 ≈ **1,3 kHz**. Độ lệch tần số rơi vào **vùng nghe được**, nên máy có thể phát ra loa tiếng "vù vù" của dòng máu.
> - θ = 90° ⇒ cos θ = 0 ⇒ **không đo được** vận tốc. Vì vậy khi đo, người làm siêu âm phải nghiêng đầu dò, thường giữ θ **≤ 60°**.

![Hình 2. Nguyên lý siêu âm Doppler đo dòng máu](doppler.svg)

## 3. Dao động và sóng điện từ

### 3.1. Mạch dao động LC — định nghĩa dao động điện từ

Mạch gồm tụ điện C nối với cuộn cảm L (tr. 125–126). Nạp điện cho tụ rồi cho tụ phóng qua cuộn dây:

1. Tụ phóng điện, dòng điện tăng dần. Cuộn dây sinh **suất điện động tự cảm** E~tc~ = −L·dI/dt chống lại (định luật Lenz), nên dòng không tăng đột ngột mà tăng dần đến cực đại I~0~, trong khi điện tích q giảm từ Q~0~ về 0.
2. Tụ hết điện, dòng giảm. Dòng tự cảm lại cùng chiều, **nạp ngược** cho tụ đến −Q~0~.
3. Quá trình lặp lại.

Năng lượng chuyển qua lại giữa **điện trường trong tụ** W~E~ = ½·q²/C và **từ trường trong cuộn dây** W~B~ = ½·L·I². Sự biến đổi tuần hoàn của các đại lượng điện và từ (q, I, W~E~, W~B~…) gọi là **dao động điện từ**.

### 3.2. Dao động điện từ điều hòa (không tắt)

Coi R = 0, ta có q/C − L·dI/dt = 0 với I = −dq/dt (tr. 127):

=> d²q/dt² + ω~0~²·q = 0, với ω~0~ = 1/√(LC)

=> q = Q~0~·cos(ω~0~t + φ);  T~0~ = 2π/ω~0~ = 2π·√(L·C)

L tính bằng henry (H), C bằng farad (F) thì T~0~ tính bằng giây.

### 3.3. Tương tự giữa dao động điện và dao động cơ

Hai phương trình có **dạng toán học giống hệt nhau**. Bản chất vật lý khác nhau nhưng quy luật biến đổi như nhau (tr. 128–129):

| Cơ học (con lắc lò xo) | Điện từ (mạch LC) |
|---|---|
| Li độ x | Điện tích q |
| Vận tốc v | Cường độ dòng điện i |
| Khối lượng m | Hệ số tự cảm L |
| Độ cứng k | Nghịch đảo điện dung **1/C** |
| Thế năng ½kx² | Năng lượng điện trường ½q²/C |
| Động năng ½mv² | Năng lượng từ trường ½LI² |
| ω = √(k/m) | ω~0~ = 1/√(LC) |

> [!bay]
> **C tương ứng với 1/k**, không phải với k. Hãy nhớ: lò xo càng "mềm" (k nhỏ) thì giống tụ càng "chứa được nhiều" (C lớn).

### 3.4. Dao động điện từ tắt dần — mạch RLC

Mạch thật luôn có điện trở R. Năng lượng giảm dần vì biến thành nhiệt theo định luật Joule–Lenz: dW/dt = −I²R (tr. 129–131).

=> L·d²q/dt² + R·dq/dt + q/C = 0

=> q = Q~0~·e^−Rt/2L^·cos ω't

=> ω' = √[1/(LC) − (R/2L)²] < ω~0~

- Biên độ giảm theo e^−Rt/2L^: **R càng lớn, L càng nhỏ ⇒ tắt càng nhanh**. Tương ứng với cơ học: r/2m ↔ R/2L.
- Ví dụ của sách: L = 10 mH, C = 1,0 μF, R = 0,1 Ω. Thời gian để biên độ giảm còn một nửa: t = (2L/R)·ln 2 = (2 × 10·10^−3^ / 0,1) × 0,69 ≈ **0,14 s**; ω' ≈ 1,0·10^4^ rad/s. Số hạng (R/2L)² rất nhỏ so với 1/(LC), nên **R ít ảnh hưởng đến tần số**.
- Muốn mạch còn dao động thì phải có 1/(LC) > (R/2L)², tức **R < 2√(L/C)**. Giá trị **R~th~ = 2√(L/C)** gọi là **điện trở tới hạn**.

### 3.5. Dao động điện từ cưỡng bức, cộng hưởng và sóng điện từ

**Cưỡng bức – cộng hưởng.** Đặt vào mạch RLC một nguồn xoay chiều ε = ε~m~·cos ω''t. Biên độ dòng điện là (tr. 132–133):

=> I~m~ = ε~m~ / √[(ω''L − 1/(ω''C))² + R²]

I~m~ cực đại khi ω''L = 1/(ω''C), tức **ω'' = 1/√(LC) = ω~0~**. Khi đó **I~m~ = ε~m~/R**: đó là **cộng hưởng điện**. **R càng nhỏ, đỉnh cộng hưởng càng nhọn**. Độ nhọn được đo bằng **độ rộng một nửa** Δω: giáo trình lấy bề rộng của đường cong tại mức I~m~/2. (Sách vật lý hiện nay thường lấy bề rộng tại mức **công suất** giảm một nửa, tức I~m~/√2; đi thi dùng định nghĩa của giáo trình.) Dao động cưỡng bức thường được tạo bằng đèn điện tử 3 cực hoặc tranzito.

> [!ung-dung] Cộng hưởng điện trong y học
> - **Dò đài, chọn kênh**: xoay tụ để ω~0~ của mạch bằng tần số đài cần nghe.
> - **Máy MRI** dùng sóng vô tuyến đúng **tần số cộng hưởng** của proton hydro trong từ trường (khoảng 64 MHz ở 1,5 T); cuộn thu cũng là mạch cộng hưởng.
> - **Máy điện châm, máy điện xung** là những máy phát dao động điện có tần số chỉnh được.

**Sự tạo thành sóng điện từ** (tr. 134–135).

- **Thí nghiệm Hertz**: nguồn xoay chiều cao tần tạo tia lửa điện giữa hai quả cầu A–B. Dụng cụ đặt quanh đó phát hiện được điện trường E và từ trường H biến thiên. Như vậy **điện từ trường biến thiên đã truyền đi trong không gian**.
- **Luận điểm Maxwell**: điện trường biến thiên sinh ra từ trường xoáy; từ trường biến thiên lại sinh điện trường xoáy… Cặp E, H cứ thế lan ra.
- **Định nghĩa: sóng điện từ là điện từ trường biến thiên theo thời gian, truyền đi trong không gian.**
- Mạch dao động **kín** giữ trường bên trong (từ trường trong cuộn dây, điện trường giữa hai bản tụ). Muốn phát sóng phải dùng **mạch dao động hở**, tức là **ăng ten**.
- Hạt tích điện chuyển động **có gia tốc** đều bức xạ sóng điện từ. Electron bị hãm sinh **bức xạ hãm** (phần liên tục của phổ tia X). Electron chuyển từ mức năng lượng cao xuống thấp cũng phát sóng điện từ: hồng ngoại, ánh sáng, tử ngoại, tia gamma.

**Tốc độ truyền** (tr. 135–136):

=> v = 1/√(ε~0~μ~0~) × 1/√(ε·μ) = c/√(ε·μ)

- ε~0~ ≈ 8,85·10^−12^ F/m (= 10^−9^/36π F/m); μ~0~ = 4π·10^−7^ H/m.
- Trong chân không ε = μ = 1 ⇒ **c = 3·10^8^ m/s**, là tốc độ lớn nhất. Môi trường khác có ε, μ > 1 ⇒ v < c.
- Tốc độ ánh sáng đo được cũng là c, từ đó Maxwell đưa ra **thuyết điện từ về ánh sáng**.

**Sóng điện từ là sóng ngang** (tr. 136–137). Tại mỗi điểm, **E ⊥ H** và cả hai **⊥ phương truyền**. E và H **biến thiên đồng pha**. Sóng điện từ **không cần môi trường vật chất**, nên truyền được trong chân không (khác hẳn sóng cơ).

**Năng lượng** (tr. 137–138). Mật độ năng lượng điện từ trường:

=> w = ½·ε·E² + ½·μ·H²

Mật độ dòng năng lượng bằng v·w. **Vectơ Umov–Poynting** S = E × H có phương, chiều trùng với phương truyền sóng và đặc trưng cho sự tải năng lượng.

**Phương trình sóng phẳng**: E~M~ = E~0~·cos ω~0~(t − x/v); H~M~ = H~0~·cos ω~0~(t − x/v). Sóng tuần hoàn theo thời gian (chu kỳ T~0~) và theo không gian (bước sóng **λ = v·T~0~**).

**Tính phổ biến** (tr. 138–139). Tín hiệu điện từ có mặt khắp nơi. Biên độ, tần số, bước sóng, dạng của sóng cho biết thông tin về đối tượng phát ra hay tương tác với nó: từ vô tuyến, truyền hình, điện thoại đến các kỹ thuật chẩn đoán hình ảnh.

![Hình 3. Phổ sóng điện từ và các ứng dụng y học](pho-song-dien-tu.svg)

> [!yhct] Điện châm và "tần số" của dòng xung
> Máy điện châm là **máy phát dao động điện** tạo các xung có tần số và cường độ chỉnh được, dẫn vào cơ thể qua kim châm.
> - **Bằng chứng thực nghiệm (chủ yếu trên động vật, một số đo dịch não tủy ở người; phần lớn từ nhóm Han Jisheng, Bắc Kinh)**: điện châm **tần số thấp khoảng 2 Hz** liên quan đến tăng giải phóng **enkephalin, β-endorphin**; **tần số cao khoảng 100 Hz** liên quan đến tăng **dynorphin** ở tủy sống. Kiểu xung xen kẽ 2/100 Hz (sóng "thưa – mau") được cho là huy động cả hai cơ chế. Kết quả này chưa được lặp lại rộng rãi bởi nhiều nhóm độc lập, nên chưa thể coi là quy luật đã xác lập trên người.
> - **Trên người**: tác dụng giảm đau có bằng chứng ở một số chứng đau, nhưng chất lượng nghiên cứu không đồng đều.
> - **Là quan niệm YHCT, chưa có tương ứng vật lý xác định**: việc gán tần số hay dạng xung với phép "bổ" hoặc "tả".
> - **An toàn điện** (không cho dòng đi ngang qua tim, thận trọng với người mang máy tạo nhịp, vì sao dùng xung hai pha): xem khung YHCT ở bài *Điện và sự sống* (mã vl-05), mục 3.5c.

## 4. Biến đổi, khuếch đại và ghi giữ tín hiệu

Mọi thiết bị ghi đo y sinh gồm 3 khối: **bộ cảm biến** (*sensor*), **bộ khuếch đại** (*amplifier*) và **bộ hiển thị** (*display*) (tr. 139).

### 4.1. Biến đổi tín hiệu không điện thành điện

Tín hiệu điện dễ khuếch đại, ghi và truyền nhất, nên các đại lượng vật lý (ánh sáng, nhiệt, áp suất…) đều được biến đổi thành điện (tr. 139–141).

| Loại biến đổi | Nguyên lý | Ví dụ, ứng dụng |
|---|---|---|
| **Quang điện** – tế bào quang điện chân không | Hiệu ứng quang điện **ngoài**: ánh sáng làm catốt bật electron. Dòng điện tỷ lệ với cường độ ánh sáng (ở λ xác định) | Máy đo quang, quang kế |
| **Quang điện** – tế bào quang điện selen | Hiệu ứng quang điện **trong**: tự sinh suất điện động, **không cần nguồn phụ** (pin quang điện) | Máy so màu, đo quang trong xét nghiệm |
| **Quang trở** | Lớp mỏng hợp chất Pb, Cd hoặc bán dẫn Ge thay đổi **điện trở** khi được chiếu sáng; rất nhạy với **hồng ngoại** | Cảm biến hồng ngoại |
| **Nhiệt – điện** (cặp nhiệt điện) | Hai kim loại khác nhau tiếp xúc, hai mối hàn ở nhiệt độ khác nhau sinh **suất nhiệt điện động** ε = S·(T − T~0~) (S: độ nhạy, mV/độ) | Nhiệt kế điện tử |
| **Áp điện** | **Hiệu ứng áp điện thuận**: nén hoặc dãn tinh thể (thạch anh, muối Seignette) theo phương đặc biệt sinh điện tích trái dấu trên hai mặt | **Đầu thu siêu âm**, cảm biến áp suất |
| **Điện cảm, điện dung** | Dịch chuyển cơ học làm đổi C của tụ (khoảng cách hai bản) hoặc L của cuộn dây (vị trí lõi sắt) | Đo dịch chuyển nhỏ, nhịp thở, áp lực |

### 4.2. Nguyên lý khuếch đại tín hiệu điện — tranzito

Tín hiệu sinh học thường **rất yếu** (điện tim cỡ mV, điện não cỡ μV), phải khuếch đại mới ghi được (tr. 141–145).

- **Cấu tạo**: 3 lớp bán dẫn, loại **p–n–p** hoặc **n–p–n**. Ba cực: **E** (phát, *emitter*), **B** (gốc, *base*), **C** (góp, *collector*). Có hai lớp chuyển tiếp p–n: B–E và B–C. Lớp gốc **rất mỏng** (khoảng 10–20 μm hoặc nhỏ hơn); đây là điều kiện quan trọng nhất để tranzito hoạt động.
- Hệ thức chung: **I~E~ = I~C~ + I~B~**, trong đó I~B~ rất nhỏ nên **I~E~ ≈ I~C~**.
- **Mắc gốc chung**: không khuếch đại dòng (α = ΔI~C~/ΔI~E~ ≈ 1) nhưng **khuếch đại điện áp và công suất** (k = ΔU~ra~/ΔU~vào~).
- **Mắc phát chung** (phổ biến): **khuếch đại dòng**, hệ số β = ΔI~C~/ΔI~B~.

=> β = α / (1 − α)

Ví dụ của sách: α = 0,95 ⇒ β = 19; α = 0,995 ⇒ β = 199.

- Cần **hai họ đường đặc trưng** mới mô tả đủ quan hệ giữa 4 đại lượng I~B~, U~BE~, I~C~, U~CE~: họ đặc trưng **cực gốc** (I~B~ theo U~BE~) và họ đặc trưng **cực góp** (I~C~ theo U~CE~ khi I~B~ không đổi).
- Trong mạch khuếch đại phát chung: ΔU~vào~ gây ΔI~B~ ⇒ ΔI~C~ = β·ΔI~B~ lớn ⇒ ΔU~ra~ = R~C~·ΔI~C~ lớn hơn nhiều ΔU~vào~. **Tụ C~2~** ở đầu ra lọc bỏ thành phần một chiều, chỉ cho phần biến thiên ΔU~ra~ đi qua; **tụ C~1~** ngăn dòng một chiều của cực gốc đi vào nguồn tín hiệu.
- Ngày nay dùng **vi mạch** (IC), thực chất là vô số tranzito tí hon.

> [!bay] Lỗi in trong giáo trình
> Công thức (4.59) tr. 142 in "I~E~ = I~C~ + I~B~, trong đó **I~E~ ≈ I~B~**". Đúng phải là **I~E~ ≈ I~C~** (vì I~B~ rất nhỏ). Chính các ví dụ α ≈ 1 và β ≫ 1 của sách cũng xác nhận điều này.

### 4.3. Ghi và bảo quản tín hiệu điện

Bộ ghi dựa vào hai tác dụng: **lực từ** lên dây dẫn có dòng điện (quy tắc bàn tay trái) và **lực điện** làm lệch chùm electron (tr. 145–148).

- **Bộ ghi quang học – điện kế gương**: vòng dây D mang gương nằm trong từ trường nam châm. Dòng tín hiệu làm gương quay một góc tỷ lệ với biên độ tín hiệu. Tia sáng phản xạ từ gương vẽ đường cong lên phim chạy đều; các vạch thời gian được kẻ đồng thời trên phim.
- **Ống tia âm cực** (*cathode ray tube*, dao động ký điện tử): súng phóng electron trong ống chân không (10^−7^ – 10^−8^ mmHg). Cặp bản 1 làm lệch chùm theo chiều dọc, tỷ lệ với tín hiệu. Cặp bản 2 nhận **điện áp quét răng cưa** để kéo chùm đều từ trái sang phải rồi quay về tức thì. Kết quả là đồ thị tín hiệu theo thời gian hiện trên màn huỳnh quang. Ưu điểm: **quán tính rất nhỏ**, chính xác, nhạy, theo dõi được quá trình nhanh.
- **Bộ ghi cơ học – bút ghi**: tín hiệu qua cuộn dây B làm cần bút dao động, bút vạch lên băng giấy chạy đều (bút mực hoặc bút nhiệt trên giấy nhiệt). Ưu điểm: có kết quả ngay, không phải rửa phim. Nhược điểm: **quán tính lớn**.
- **Kỹ thuật số**: tín hiệu được **mã hóa dạng số**, dễ lưu giữ và phát lại.

> [!cap-nhat] Thiết bị ghi hiện nay
> Giáo trình mô tả điện kế gương, ống tia âm cực và bút ghi. Hiện nay máy điện tim, điện não, monitor đều **số hóa** tín hiệu (bộ chuyển đổi tương tự – số, ADC), hiển thị trên **màn hình LCD/LED** và lưu dưới dạng tệp. Bút nhiệt trên giấy nhiệt vẫn dùng để in điện tim. Ống tia âm cực gần như không còn dùng. Khi thi, vẫn trả lời nguyên lý theo giáo trình.

## 5. Âm và siêu âm

### 5.1. Bản chất vật lý của âm và siêu âm

**Âm là dao động cơ học của các phần tử môi trường đàn hồi, lan truyền dưới dạng sóng dọc, có tần số 16 Hz – 20 000 Hz** (tr. 148). Dưới ngưỡng đó (giáo trình ghi dưới 15 Hz) là **hạ âm**; trên 20 000 Hz là **siêu âm**.

=> v = λ·f = λ/T

- Âm truyền được trong khí, lỏng, rắn nhưng **không truyền được trong chân không** (không có phần tử để dao động).
- Tốc độ âm phụ thuộc **mật độ và tính đàn hồi** môi trường, do đó phụ thuộc nhiệt độ. Trong không khí: 331,5 m/s ở 0 °C, tăng theo nhiệt độ; giáo trình ghi ở 18 °C là 342 m/s. (Sách ghi "tăng khoảng 0,5 m/s mỗi độ", nhưng với 342 m/s ở 18 °C thì hệ số đúng là khoảng **0,6 m/s mỗi độ**: 331,5 + 0,6 × 18 ≈ 342.) Tốc độ âm **hầu như không phụ thuộc tần số**.

| Môi trường | Tốc độ âm (m/s) | Môi trường | Tốc độ âm (m/s) |
|---|---|---|---|
| Không khí | 331,5 | Thủy tinh | 5600 |
| Nước | 1450 | Gỗ thông | 4800 |
| Đồng | 3800 | Lie | 430–530 |
| Sắt | 4900 | Cao su | 50 |
| | | **Cơ thể người** | **1540** |

(Giáo trình tr. 148, bảng 4.1; sách ghi đo ở 0 °C, riêng giá trị 1540 m/s của mô cơ thể là ở thân nhiệt.)

**Truyền âm** (tr. 148–150):

- Bước sóng âm khá dài (cỡ cm đến m) nên **nhiễu xạ** dễ, âm **vòng qua vật cản** được.
- **Tiếng dội** (phản xạ từ tường, núi): nếu đến tai quá trễ thì làm âm mờ, khó nghe; nếu bố trí tốt thì lại làm tăng cường độ âm.
- **Cường độ âm I** là năng lượng truyền qua một đơn vị diện tích đặt vuông góc với phương truyền trong một đơn vị thời gian, đơn vị **W/m²** (hoặc μW/cm²).
- Cường độ âm giảm khi đi xa nguồn vì 3 lý do: **ma sát** biến năng lượng thành nhiệt; **phản xạ, khúc xạ, nhiễu xạ** ở mặt phân cách; năng lượng **phân bố trên mặt cầu ngày càng rộng** nên ngay trong điều kiện lý tưởng **I tỷ lệ nghịch với bình phương khoảng cách**.
- **Vật dẫn âm tốt**: thép, bê tông; **vật hấp thụ âm**: dạ, nỉ, lie, cao su xốp. Trong cơ thể: **xương dẫn âm tốt, mỡ dẫn âm kém, dịch và mủ làm yếu âm khá nhiều**.
- **Cộng hưởng âm**: hai âm thoa cùng tần số riêng, gõ một chiếc thì chiếc kia cũng rung với biên độ lớn.

### 5.2. Nguồn phát âm và siêu âm

**Nguồn phát âm** (tr. 150–151). Phổ biến nhất là một vật rắn, màng căng hoặc dây căng dao động đàn hồi. Với dây căng:

=> f = (1/2L)·√(P/M)

(L: chiều dài dây, m; P: lực căng, N; M: khối lượng một đơn vị chiều dài dây, kg/m.)

Dây càng **ngắn, căng, nhẹ** thì âm càng **cao**.

**Cơ quan phát âm ở người.** Bộ phận chính là **thanh quản và dây âm thanh** (dây thanh). Có các giả thuyết:

- **Thuyết cơ đàn hồi (thuyết cơ học)**: luồng khí từ phổi đẩy qua khe hẹp giữa hai dây thanh làm dây rung. Thần kinh trung ương điều chỉnh **độ căng** dây, do đó điều chỉnh tần số theo công thức trên. Thuyết này chưa giải thích được nhiều hiện tượng.
- **Giả thuyết luồng thần kinh (Husson; sách ghi "Housson")**: tần số dao động của dây thanh do **nhịp xung thần kinh** từ trung ương (qua **dây thần kinh quặt ngược, nhánh của dây X**) quyết định. Tần số tối đa ước tính theo f~M~ = 1000/(k·c), với c là thời trị (*chronaxie*) của dây thần kinh quặt ngược và k là hệ số tỷ lệ.
- **Quan điểm bổ sung**: niêm mạc dây thanh rất lỏng lẻo, dao động có thể xuất hiện ở từng phần trên, dưới và ngay ở dây thanh.
- **Các xoang cộng hưởng** quyết định **âm sắc** giọng nói. Khi phát nguyên âm a, o, u…, khoang cộng hưởng chia ra hai phần tạo hai tần số cộng hưởng khác nhau. Phụ âm còn do ma sát qua kẽ răng, khe lưỡi – vòm hầu. Giọng ngân nga, nói thầm có vai trò của xoang mũi.

> [!cap-nhat] Cơ chế phát âm
> Giả thuyết "thần kinh – thời trị" của Husson (1950) đã bị **bác bỏ**. Hiện nay đồng thuận là **thuyết cơ đàn hồi – khí động học** (*myoelastic–aerodynamic*): dây thanh rung **thụ động** nhờ áp lực luồng khí và lực đàn hồi của chính dây; thần kinh chỉ điều chỉnh độ căng, độ dày, độ khép của dây. Đi thi vẫn trình bày đủ các thuyết như giáo trình.

**Nguồn phát siêu âm** (tr. 151–152). Loa thường không phát được siêu âm. Lý do: gia tốc của màng loa tỷ lệ với f², ở f > 20 000 Hz cần lực quá lớn mà màng loa đàn hồi kém, không dao động nổi. Phải dùng vật liệu đặc biệt (thạch anh, muối Seignette, niken…) có **biến dạng lớn** dưới tác dụng ngoại lực và **độ đàn hồi lớn**:

| Cách phát | Nguyên lý | Tần số đạt được |
|---|---|---|
| **Hiệu ứng áp điện nghịch** | Đặt hiệu điện thế xoay chiều vào hai mặt bản thạch anh ⇒ bản dày lên mỏng đi theo tần số điện ⇒ phát siêu âm. Mạnh nhất khi tần số điện **bằng tần số riêng** của bản (cộng hưởng) | Đến khoảng 50 MHz |
| **Hiện tượng từ giảo** | Thanh sắt từ (niken) đặt trong cuộn dây có dòng xoay chiều cao tần ⇒ chiều dài thanh co dãn theo tần số dòng điện | Đến khoảng 10^9^ Hz (theo giáo trình) |

**Thu** siêu âm dựa vào **hiệu ứng áp điện thuận** (mục 4.1). Vì vậy **cùng một tinh thể** có thể vừa phát vừa thu.

> [!bay] Thuận hay nghịch?
> - **Phát** siêu âm: điện → cơ = **áp điện nghịch** (hoặc từ giảo).
> - **Thu** siêu âm: cơ → điện = **áp điện thuận**.

### 5.3. Các đặc trưng của cảm giác âm

Giáo trình phân biệt **âm thanh** (mang thông tin) với **tiếng ồn** (âm hỗn hợp từ quá nhiều nguồn, không mang thông tin quan trọng). Cảm giác âm gồm 3 đặc trưng sinh lý: **độ cao, âm sắc, độ to** (tr. 152).

| Đặc trưng sinh lý (cảm giác) | Do đặc trưng vật lý nào quyết định |
|---|---|
| **Độ cao** (trầm – bổng) | **Tần số** (phần nào phụ thuộc cường độ) |
| **Âm sắc** | **Thành phần họa âm** (phổ), tức **dạng đồ thị** dao động |
| **Độ to** | **Cường độ** âm **và tần số** |

#### a) Độ cao

- Tần số cao ⇒ âm **thanh, bổng**; tần số thấp ⇒ âm **trầm, đục**.
- Tai người nghe được 16 – 20 000 Hz nhưng giới hạn này **giảm theo tuổi**: người già có thể chỉ nghe được dưới 6000 Hz. Tai phân biệt rõ độ cao chủ yếu trong khoảng **40 – 4000 Hz**; âm cao hơn chỉ cho cảm giác "rít". Vì vậy nhạc cụ thường phát trong khoảng này.
- Muốn nhận biết độ cao, âm phải tác động ít nhất **1/100 – 1/40 s**. Âm 40 Hz trong 1/40 s thực hiện đúng **1 dao động**; âm 6000 Hz trong thời gian đó thực hiện 150 dao động. Như vậy **ngưỡng để cảm nhận độ cao là một dao động toàn phần**: chưa đủ một dao động thì chưa xác định được chu kỳ.
- Ở một mức nhất định, âm cao nghe **cao hơn** khi cường độ tăng và âm trầm nghe **trầm hơn** khi cường độ giảm (do thay đổi tính đàn hồi của màng nhĩ).

#### b) Âm sắc

- Âm thoa cho âm **đơn** (hình sin): p = p~0~·sin 2πft.
- Đa số âm là **âm phức tạp**: phân tích được (bằng bộ cộng hưởng) thành các âm đơn có tần số **bội số nguyên** của tần số nhỏ nhất. Thành phần có tần số nhỏ nhất là **âm cơ bản**; các thành phần còn lại là **họa âm** (tr. 153).
- Hai nhạc cụ (đàn piano, kèn clarinet) phát **cùng độ cao** (cùng âm cơ bản) nhưng tai vẫn phân biệt được. Lý do: **thành phần họa âm khác nhau**, nên **dạng đồ thị dao động khác nhau** (tr. 154).
- **Thuyết Helmholtz**: các sợi đàn hồi của màng nghe (khác nhau về chiều dài, độ dày, độ căng) **cộng hưởng** với từng thành phần tần số của âm, kích thích các tế bào thần kinh tương ứng, tạo cảm giác độ cao và âm sắc. Nghiên cứu sau này xác nhận: âm khác tần số được tiếp nhận ở **những phần khác nhau** của màng. Đây là kết quả tác động đồng thời của nhiều dao động trong ngoại dịch và biến dạng đàn hồi của màng, không chỉ là cộng hưởng của từng sợi.

#### c) Độ to — ngưỡng nghe, ngưỡng chói, decibel, phon

- **Ngưỡng phân biệt độ to**: tai chỉ nhận ra âm to lên hay nhỏ đi khi **ΔI/I > 0,1** (thay đổi trên 10%) (tr. 155).
- Độ nhạy của tai phụ thuộc tần số. Theo giáo trình, tai **thính nhất ở khoảng 1000 – 5000 Hz** (tr. 155; ở tr. 157 lại ghi 1000 – 2500 Hz). Ở vùng này tai nghe được âm chỉ 10^−11^ W/m²: phân tử khí dao động với biên độ khoảng 10^−5^ μm, áp suất ở màng nhĩ khoảng 10^−5^ N/m².
- **Ngưỡng nghe**: cường độ **nhỏ nhất** gây được cảm giác âm. **Ngưỡng chói** (ngưỡng đau): cường độ **lớn nhất**; vượt quá sẽ gây đau tai. Cả hai ngưỡng **phụ thuộc tần số**. Ở **1000 Hz**, với người "trung bình": **ngưỡng nghe I~0~ = 10^−12^ W/m²**, **ngưỡng chói = 1 W/m²**. Hai ngưỡng chênh nhau **10^12^ lần**.

**Thang decibel.** Vì khoảng chênh lệch quá lớn, người ta dùng thang logarit (tr. 155):

=> L (dB) = 10·lg(I / I~0~),  I~0~ = 10^−12^ W/m²

- Ngưỡng nghe ở 1000 Hz = **0 dB**; ngưỡng chói = 10·lg(10^12^) = **120 dB**.
- Mỗi lần **I tăng 10 lần ⇒ cộng thêm 10 dB**; I tăng **2 lần ⇒ cộng thêm khoảng 3 dB** (lg 2 ≈ 0,3).

**Thang phon (độ to cảm giác).** Theo định luật **Weber – Fechner**: *sự biến thiên của cảm giác tỷ lệ với logarit của tỷ số kích thích* (tr. 156):

=> L~2~ − L~1~ = k·lg(I~2~/I~1~)

- Quy ước tại **1000 Hz**: ngưỡng nghe (10^−12^ W/m², 0 dB) có độ to **0 phon**; ngưỡng chói (1 W/m², 120 dB) có độ to **120 phon** (tức k = 10).
- **Đường cong đồng mức to** (hình 4.38 của sách): mọi điểm trên một đường gây cùng một cảm giác độ to. Đường **0 phon là ngưỡng nghe**, đường **120 phon là ngưỡng chói**; vùng giữa là **miền nghe**. Âm nằm dưới miền nghe thì tai không nghe thấy.
- **Chỉ ở 1000 Hz thì số dB mới bằng số phon.** Ví dụ của sách: âm **60 Hz, 76 dB** nằm trên đường 60 phon, tức nghe to bằng âm **1000 Hz, 60 dB**. Ở tần số thấp tai kém nhạy, nên phải "bơm" thêm cường độ.

![Hình 4. Thang decibel với các mốc độ to điển hình và giới hạn tiếng ồn nghề nghiệp](thang-db.svg)

| Loại âm (bảng 4.2, tr. 157) | Cường độ (μW/cm²) | Tương đương (dB) | Độ to (phon) |
|---|---|---|---|
| Ngưỡng nghe | 10^−10^ | 0 | 0 |
| Tiếng tim (nghe trực tiếp) | 10^−9^ | 10 | 10 |
| Nói thầm | 10^−6^ | 40 | 40 |
| Nói to | 10^−4^ | 60 | 60 |
| Radio mở to trong phòng | 10^−2^ | 80 | 80 |
| Động cơ mô tô | 1 | 100 | 100 |
| Ngưỡng chói | 10^2^ | 120 | 120 |
| Mức gây chết vì âm | 10^8^ | 180 | 180 |

(Đổi đơn vị: 1 μW/cm² = 10^−2^ W/m², nên 10^−10^ μW/cm² = 10^−12^ W/m².)

> [!bay] Các lỗi tính dB hay gặp
> - **Cộng dB không phải cộng số học.** Hai nguồn, mỗi nguồn 60 dB, cùng kêu thì cường độ ×2 ⇒ **63 dB**, không phải 120 dB. Mười nguồn như nhau ⇒ +10 dB.
> - **dB ≠ phon** (trừ ở 1000 Hz). dB là thang của **cường độ vật lý**; phon là thang của **cảm giác**.
> - Cường độ giảm theo **bình phương khoảng cách**: xa gấp đôi ⇒ I còn 1/4 ⇒ giảm khoảng **6 dB**.
> - Đổi μW/cm² sang W/m²: **nhân 10^−2^** (không phải 10^−4^ hay 10^−6^).

> [!ung-dung] Tiếng ồn nghề nghiệp và đo thính lực
> - **Điếc nghề nghiệp do tiếng ồn** là bệnh nghề nghiệp được bảo hiểm ở Việt Nam. Tổn thương ở tế bào lông của ốc tai, **không hồi phục**, thường biểu hiện sớm bằng **khuyết thính lực ở khoảng 4000 Hz** trên thính lực đồ.
> - Giới hạn tiếp xúc nghề nghiệp phổ biến (QCVN 24:2016/BYT): **85 dBA cho 8 giờ** làm việc. Mức càng cao thì thời gian cho phép càng ngắn; cứ **tăng 3 dB thì thời gian giảm một nửa**, vì cường độ đã tăng gấp đôi.
> - **Đo thính lực đơn âm** (*audiometry*): phát các âm đơn 250 – 8000 Hz, tăng dần cường độ đến khi người bệnh vừa nghe thấy. Ngưỡng ghi bằng **dB HL** (so với ngưỡng nghe chuẩn của người trẻ khỏe ở từng tần số). Chính là đo **đường ngưỡng nghe** của từng người.

### 5.4. Sơ lược về quá trình nghe

**Tai ngoài → tai giữa.** Sóng âm làm màng nhĩ rung. Chuỗi **xương con** (búa – đe – bàn đạp) truyền dao động tới **màng cửa sổ bầu dục**, làm dịch trong ốc tai chuyển động (tr. 157).

**Vai trò của hệ xương con.** Hệ xương con vừa **khuếch đại áp lực**, vừa **bảo vệ** tai trong (tr. 157–158):

- **Đòn bẩy**: tỷ số hai cánh tay đòn r~1~/r~2~ = **1,3**, nên lực ở cửa sổ bầu dục F~2~ = 1,3·F~1~.
- **Thu nhỏ diện tích**: diện tích cửa sổ bầu dục **nhỏ hơn màng nhĩ 17 lần**.
- Tổng hợp: áp suất sau cửa sổ bầu dục lớn hơn khoảng **17 × 1,3 ≈ 22 lần**; trừ hao hụt do ma sát vẫn còn gần **20 lần**.

**Vì sao cần khuếch đại? — bài toán âm trở.** Âm trở của không khí khoảng **4,3·10^2^ kg/m²·s**; âm trở ngoại dịch (perilympho) gần bằng nước, **1,5·10^6^ kg/m²·s**. Nếu sóng âm đi thẳng từ không khí vào ngoại dịch thì theo công thức hệ số truyền qua, **99,9% năng lượng bị phản xạ**, chỉ khoảng **0,1%** lọt vào. Hệ xương con đóng vai trò **"phối hợp trở kháng"**, khắc phục sự hao hụt do chênh lệch âm trở.

**Bảo vệ**: các dây chằng giữ hệ xương con (điểm tựa của đòn bẩy) **co giãn để giảm chấn động** khi gặp âm quá mạnh.

**Tai trong — ốc tai** (tr. 159–160):

- Ốc tai dài khoảng **35 mm**, cuộn khoảng **2,75 vòng**.
- Có 3 kênh chứa dịch:
  - **Kênh tiền đình** (bắt đầu từ cửa sổ bầu dục) và **kênh màng nhĩ** (dẫn tới cửa sổ tròn) thông nhau qua một lỗ nhỏ ở đỉnh ốc tai, cùng chứa **ngoại dịch (perilympho)**.
  - **Kênh ốc tai** nằm giữa, **không thông với kênh nào**, chứa **nội dịch (endolympho)**.
- **Màng tiền đình** (Reissner) ngăn kênh ốc tai với kênh tiền đình. **Màng đáy** ngăn kênh ốc tai với kênh màng nhĩ. Trên màng đáy có **cơ quan Corti** chứa các tế bào cảm thụ thính giác; phía trên có **màng phủ**.
- **Thuyết Békésy** (giải Nobel năm 1961): dao động ở cửa sổ bầu dục tạo chuyển động xoáy của ngoại dịch, gây áp lực khác nhau dọc theo chiều dài kênh. Áp lực truyền vào nội dịch rồi tới màng đáy, làm màng đáy **"gợn sóng"** (sóng chạy).
  - Mỗi tần số kích thích **một vị trí xác định** trên màng đáy.
  - **Âm cao** kích thích vùng **gần cửa sổ bầu dục** (đáy ốc tai, nơi màng đáy **hẹp và căng**).
  - **Âm trầm** kích thích vùng **gần đỉnh ốc tai**.
  - Âm phức tạp kích thích nhiều điểm cùng lúc, cho cảm giác âm sắc.
- Xung kích thích được mã hóa thành **điện thế hoạt động** (điện thế âm thanh), quyết định cả tần số và cường độ của âm. Hiệu điện thế giữa **nội dịch và ngoại dịch khoảng 80 mV**.

> [!bay]
> - Âm **cao** ↔ **đáy** ốc tai (gần cửa sổ bầu dục), không phải đỉnh. Mẹo nhớ: điếc do tiếng ồn và do tuổi già thường mất âm cao trước, vì vùng đáy chịu "va đập" của mọi âm đi vào.
> - Kênh tiền đình và kênh màng nhĩ chứa **ngoại dịch**; chỉ **kênh ốc tai** chứa **nội dịch**.

### 5.5. Cơ sở vật lý của phương pháp âm trong chẩn đoán

#### a) Chẩn đoán gõ

Gõ lên thành ngực, thành bụng ở vị trí tương ứng các tạng (tim, phổi, gan…). Tạng dao động và phát ra âm, từ đó suy ra **vị trí, kích thước** và tình trạng bình thường hay bệnh lý (tr. 160–161).

- **Gõ trực tiếp** lên da ít dùng: chấn động tắt nhanh qua da, mỡ, cơ, âm phát ra quá nhỏ. Thường **gõ qua ngón tay** (hoặc thanh gỗ mỏng) đặt sát da.
- **Lực gõ** tùy bệnh nhân: người béo gõ mạnh, trẻ em gõ nhẹ. Gõ vừa phải đủ làm tạng **sâu khoảng 5 cm** dao động, lan trên diện **4 – 6 cm²**. Muốn tìm **ranh giới** một tạng thì **gõ nhẹ**.
- Âm gõ phải phân tích về **cường độ, độ cao, âm sắc, thời gian dư âm**:

| Vùng gõ | Tần số | Âm sắc | Cường độ | Dư âm |
|---|---|---|---|---|
| **Phổi bình thường** (âm **trong**) | Cao | Phong phú (nhiều họa âm) | Lớn | Dài |
| **Tạng đặc; phổi vôi hóa, tràn dịch màng phổi** (âm **đục**) | Thấp | – | Nhỏ | Ngắn |
| **Ổ bụng, dạ dày** (âm **vang**) | Cao | Nghèo nàn (hầu như không có họa âm) | – | – |

#### b) Chẩn đoán nghe

Nghe âm do cơ thể phát ra, như tim và phổi (tr. 161–162).

- Âm cơ thể thường **không quá 1000 Hz**.
- **Âm phổi** do không khí đi qua khí quản, cuống phổi, phế nang. Thở mạnh hay nhẹ quyết định **cường độ**; **độ cao tỷ lệ nghịch với tiết diện** đường dẫn khí. Khi đường thở bị **hẹp** hoặc có **dịch nhầy** thì âm phổi thay đổi; đó là cơ sở chẩn đoán.
- **Âm tim** phụ thuộc tình trạng van tim, vận tốc máu, độ nhớt máu, lỗ van… Phần lớn năng lượng âm tim nằm ở **tần số thấp**:

| Tần số (Hz) | 50–60 | 60–70 | 70–80 | 80–90 | 90–100 | 100–110 |
|---|---|---|---|---|---|---|
| Tỷ lệ năng lượng | 56% | 27% | 10% | 4% | 2% | 1% |

(Giáo trình tr. 161, bảng 4.3.)

**Ống nghe** (*stéthoscope*) gồm hai dây cao su truyền âm nối với một **hộp cộng hưởng**. Hộp là hình trụ dẹt có căng màng mỏng, hoặc loa hình phễu không màng.

- **Màng càng căng thì tần số riêng càng cao** (giáo trình ghi "tỷ lệ thuận với độ căng"; chính xác hơn, giống dây đàn, tần số tăng theo **căn bậc hai** của lực căng). Âm từ cơ thể làm màng **cộng hưởng** mạnh nhất khi tần số âm trùng tần số riêng của màng.
- Nếu dùng **loa phễu**, chỗ da bị loa ép vào trở thành **màng căng**. Thay đổi lực ép là chỉnh được độ căng, tức chỉnh được tần số riêng, để **nghe rõ âm cần nghe** khi nó bị các âm khác che lấp.

> [!ung-dung] Chuông và màng của ống nghe hiện đại
> Áp dụng đúng nguyên lý trên:
> - **Mặt chuông** (phễu) đặt **nhẹ** để nghe **âm trầm**: tiếng T3, T4, rung tâm trương của hẹp van hai lá.
> - **Mặt màng** (hoặc ấn chuông **mạnh** cho da căng lên) làm tần số riêng cao hơn, để nghe **âm cao**: T1, T2, thổi tâm thu, thổi tâm trương của hở van động mạch chủ, ran phổi.

#### c) Phép thử Rinne (giáo trình ghi "Rinner")

Mục đích: xác định tổn thương ở **tai ngoài – tai giữa** hay ở **tai trong – não** (tr. 162).

- Cơ sở: âm có thể truyền **qua xương sọ** thẳng tới tai trong. Dù tai ngoài, tai giữa hỏng, âm theo đường xương vẫn gây được cảm giác.
- Cách làm theo sách: đặt âm thoa đang rung gần tai bệnh nhân (đường khí), sau đó cho bệnh nhân **cắn đuôi âm thoa** (đường xương), với biên độ dao động như lúc trước.
  - Lúc đầu (đường khí) nghe được, lúc sau (đường xương) **không nghe được** ⇒ **Rinne dương**.
  - Ngược lại ⇒ **Rinne âm**.
- **Điếc + Rinne dương** ⇒ tổn thương **tai trong hoặc não** (điếc tiếp nhận). **Rinne âm** ⇒ tổn thương **tai ngoài hoặc tai giữa** (điếc dẫn truyền).

> [!vi-du] Vì sao người bình thường "Rinne dương"?
> Ở tai lành, đường khí có **hệ xương con khuếch đại khoảng 20 lần** (mục 5.4), nên nghe qua không khí tốt hơn qua xương. Khi tai giữa hỏng, mất "bộ khuếch đại" này nên đường xương trội hơn: Rinne âm. Trên lâm sàng hiện nay thường đặt chân âm thoa (512 Hz) lên **xương chũm** cho đến khi hết nghe, rồi đưa ra trước lỗ tai để so sánh. Cách đọc kết quả không đổi.

### 5.6. Ứng dụng siêu âm trong ngành y

#### a) Đặc điểm lan truyền

- Siêu âm **truyền thẳng thành chùm**, mang **năng lượng lớn**, cũng bị hấp thụ, tán xạ, phản xạ như âm (tr. 162).
- Giáo trình ghi y học thường dùng siêu âm tần số **100 000 Hz – 3·10^6^ Hz**.
- **Âm trở Z = ρ·v.** Một số giá trị (tr. 163):

| Môi trường | Âm trở (kg/m²·s) |
|---|---|
| Không khí | 429 |
| Nước | 1,48·10^6^ |
| Mô mềm | 1,6·10^6^ |
| Máu và não | 1,56·10^6^ |
| Mô mỡ | 1,40·10^6^ |
| Mô xương (theo sách) | 1,62·10^6^ |

Lưu ý: giá trị âm trở xương in trong sách (1,62·10^6^) gần bằng mô mềm, mâu thuẫn với chính nhận xét của sách rằng xương – mô mềm phản xạ mạnh. Số liệu đo thường gặp cho xương đặc là khoảng **6 – 8·10^6^ kg/m²·s**, gấp khoảng 4–5 lần mô mềm. Vì vậy sau xương có "bóng cản".

- **Hệ số phản xạ** ở mặt phân cách:

=> R = (Z~1~ − Z~2~)/(Z~1~ + Z~2~)

Giáo trình ghi: giữa **nước (mô mềm) và không khí**, R ≈ 0,99, tức gần như **toàn bộ năng lượng (≈ 99%) bị phản xạ**, chỉ khoảng 1% đi tiếp. (Tính chính xác: R = (1,6·10^6^ − 429)/(1,6·10^6^ + 429) ≈ 0,9995, năng lượng phản xạ R² ≈ 99,9%, chỉ khoảng 0,1% đi tiếp; cùng con số với bài toán tai giữa ở mục 5.4.) R cũng khá lớn giữa **xương và mô mềm**, giữa **phổi và mô**. Sự khác biệt phản xạ ở các mặt phân cách chính là cơ sở để **chẩn đoán**.

- **Hấp thụ**: cường độ giảm theo hàm mũ khi xuyên sâu x:

=> I = I~0~·e^−αx^

Giáo trình ghi hệ số hấp thụ **α tỷ lệ với f²**, với **1/ρ** và với **v³**. Không khí có ρ bé nên α lớn: siêu âm bị hấp thụ nhiều trong khí.

> [!bay] α tỷ lệ với v³ hay 1/v³?
> Công thức hấp thụ cổ điển (Stokes) là α = 2η·ω²/(3ρ·v³), tức α ∝ f²/(ρ·v³): **tỷ lệ nghịch** với v³, không phải tỷ lệ thuận như sách in. Chính ví dụ không khí (ρ nhỏ **và** v nhỏ ⇒ α lớn) phù hợp với 1/v³. Điều chắc chắn và hay thi nhất: **α ∝ f²**.

> [!ung-dung] Vì sao phải bôi gel khi siêu âm?
> Giữa đầu dò và da luôn còn một lớp **không khí** mỏng. Z của không khí (≈ 429) nhỏ hơn mô mềm khoảng **3700 lần**, nên ở mặt phân cách khí – da gần như toàn bộ siêu âm bị dội lại, không vào được cơ thể. **Gel** (chủ yếu là nước) có Z gần bằng mô, **đuổi không khí ra** và "nối" âm trở giữa đầu dò với da. Cũng vì vậy, siêu âm **khó khảo sát phổi chứa khí và ruột nhiều hơi**, và **sau xương** có "bóng cản".

> [!bay] Hệ số phản xạ biên độ hay năng lượng?
> Công thức (4.66) R = (Z~1~ − Z~2~)/(Z~1~ + Z~2~) thực chất là **tỷ số biên độ** (giống 4.30). Tỷ lệ **năng lượng (cường độ)** phản xạ là **R²** (công thức 4.31). Với không khí – mô mềm, R ≈ 0,9995 và R² ≈ 0,999, nên kết luận "gần như toàn bộ phản xạ" vẫn đúng. Với bài toán có Z gần nhau, phải bình phương. Ví dụ mỡ – mô mềm (theo bảng): R ≈ 0,07 nhưng chỉ khoảng 0,4% năng lượng bị phản xạ.

**Bước sóng siêu âm trong mô và độ phân giải.** Từ λ = v/f với v ≈ 1540 m/s:

=> f = 1,54 MHz ⇒ λ = 1 mm

=> f = 5 MHz ⇒ λ ≈ 0,31 mm

=> f = 10 MHz ⇒ λ ≈ 0,15 mm

Chi tiết nhỏ hơn bước sóng khó phân biệt, nên **tần số càng cao, ảnh càng nét**. Nhưng **α ∝ f²** nên tần số cao **bị hấp thụ nhanh, xuyên nông**. Giáo trình kết luận: khám bộ phận **nhỏ và nông** (mắt, tuyến giáp…) dùng tần số cao **4 – 10 MHz** (xuyên ít nhưng chùm tập trung); khám vùng **sâu** dùng tần số thấp hơn (xuyên sâu nhưng phân tán) (tr. 167).

#### b) Tác dụng của siêu âm lên vật chất và cơ thể

Có 3 hiệu ứng (tr. 163–164):

- **Hiệu ứng cơ học**: phần tử môi trường dao động theo, áp suất dao động có thể lên tới **hàng vạn atmotphe**. Liên kết bị đứt gãy, tạo **lỗ vi mô** (*cavitation*). Chùm siêu âm cường độ bé, tần số cao ít khi gây hiện tượng này. Ứng dụng: trộn các chất lỏng không trộn lẫn (nước – dầu, nước – thủy ngân), tạo **nhũ tương**, **khí dung** hạt nhỏ; làm vón bụi độc trong khói thải.
- **Hiệu ứng nhiệt**: phần lớn năng lượng hấp thụ biến thành **nhiệt**, đặc biệt ở **mặt phân cách** giữa hai môi trường khác mật độ (ví dụ mô – xương).
- **Hiệu ứng hóa lý**: xúc tiến phản ứng hóa học, phân ly chất hữu cơ, tăng ion hóa và tạo **gốc tự do**, tăng **thẩm thấu** qua màng bán thấm.

**Tác dụng sinh học:**

- Cường độ **nhỏ và vừa (< 20 kW/m²)**: tăng tính thẩm thấu màng tế bào, tăng dịch chuyển bào tương.
- Cường độ **lớn (≥ 30 kW/m²)**: tạo lỗ vi mô trong bào tương, làm rách màng và biến dạng nhân, có thể **phá hủy tế bào**.
- Với mô: làm đổi pH, điểm đẳng điện, áp suất thẩm thấu, áp suất keo; đổi chuyển hóa và hoạt tính histamin.
- Tác dụng điều trị: **giãn mạch, tăng vận mạch, chống co thắt cơ, chống viêm**, tăng hấp thụ ở ruột.
- Liều lớn có hại: làm mất Ca ở xương, làm nóng mô, phá hủy tế bào máu, tủy xương, gây hoại tử tế bào thần kinh, ảnh hưởng tuyến nội tiết, thị giác. Giáo trình còn ghi "có thể gây ung thư".

#### c) Siêu âm chẩn đoán

Có hai phương pháp (tr. 164–167):

- **Truyền qua**: đo chùm siêu âm ló ra sau khi qua mô; mức hấp thụ cho biết mật độ, kích thước, tính chất của mô.
- **Phản xạ (sóng xung phản xạ)**: dùng nhiều nhất. Đầu dò áp điện **phát xung ngắn** (áp điện nghịch) rồi **thu tiếng vọng** (áp điện thuận). Từ thời gian đi – về t và tốc độ v suy ra độ sâu mặt phản xạ: **d = v·t/2**.

| Kiểu | Hiển thị | Dùng để |
|---|---|---|
| **A** (*Amplitude*) | Mỗi tiếng vọng là một **xung**; biên độ ∝ cường độ phản xạ, vị trí ∝ thời gian truyền | Đo **khoảng cách**, độ sâu (ví dụ đo trục nhãn cầu) |
| **B** (*Brightness*) | Mỗi xung thành một **chấm sáng**, độ sáng ∝ cường độ phản xạ | Nền tảng của ảnh 2D |
| **TM** (*Time Motion*, M-mode) | Các chấm sáng kiểu B ghi **liên tục theo thời gian** | **Tim mạch**: tốc độ đóng mở van, nhịp co bóp |
| **2D** | Tập hợp nhiều **đường quét** kiểu B thành ảnh **mặt cắt** (quét tuyến tính hoặc rẻ quạt) | Ảnh cắt lớp; lớp cắt **nằm trong mặt phẳng chứa hướng chùm tia** (khác X-quang: lớp cắt vuông góc với trục tia) |
| **3D, 4D** | Dựng hình không gian từ nhiều lát 2D; 4D = 3D + thời gian | Khảo sát hình thái thai… |
| **Doppler** | Phân tích độ lệch tần số do dòng máu | Khảo sát **dòng chảy** |

**Các kiểu Doppler** (tr. 165–166):

- **Doppler liên tục**: hai tinh thể (một phát, một thu) hoạt động liên tục. Đo được **vận tốc cao** nhưng **không định vị** được độ sâu, chỉ cho tốc độ trung bình trên đường đi của chùm tia.
- **Doppler xung**: chỉ **một tinh thể** vừa phát vừa thu. Chọn thời điểm thu nên **định vị được vùng cần đo**. Thường kết hợp với ảnh 2D (Duplex).
- **Doppler màu**: mã hóa tín hiệu Doppler thành **màu** chồng lên ảnh 2D ("bản đồ màu dòng chảy"), cho biết **chiều** (so với đầu dò) và **tốc độ** dòng chảy.
- **Doppler năng lượng**: nhạy với **mạch máu nhỏ, dòng chảy chậm** mà Doppler màu không phát hiện được.

**An toàn**: siêu âm chẩn đoán dùng cường độ thấp, theo giáo trình khoảng **2 – 10 mW/cm²**, nên an toàn, không gây nguy hiểm cho bệnh nhân.

> [!cap-nhat] Tần số và an toàn của máy siêu âm hiện nay
> - Giáo trình ghi dải tần y học **0,1 – 3 MHz**. Hiện nay siêu âm **chẩn đoán** dùng phổ biến **2 – 15 MHz** (bụng, sản: 2 – 5 MHz; tuyến giáp, vú, cơ xương khớp, mạch nông: 7 – 15 MHz hoặc cao hơn). Siêu âm **điều trị vật lý trị liệu** dùng **1 MHz** (mô sâu) và **3 MHz** (mô nông).
> - An toàn hiện được theo dõi bằng **chỉ số nhiệt (TI)** và **chỉ số cơ học (MI)** hiển thị trên máy, theo nguyên tắc **ALARA** (thấp nhất có thể mà vẫn đạt mục đích chẩn đoán). Thận trọng nhất với **Doppler xung trên phôi thai 3 tháng đầu**.
> - Chưa có bằng chứng siêu âm chẩn đoán gây ung thư. Câu "có thể gây ung thư" của giáo trình chỉ nói về liều lớn.

#### d) Siêu âm điều trị

Ít dùng hơn chẩn đoán. Cơ chế gồm: dùng năng lượng hấp thụ để **làm nóng tại chỗ**, gây giãn mạch, tăng thẩm thấu màng tế bào; dùng **hiện tượng tạo lỗ vi mô** để diệt tế bào bệnh và vi sinh vật (tr. 167).

- Chỉ định theo giáo trình: **đau thần kinh tọa**, đau lưng, thấp khớp, viêm mô liên kết và thần kinh.
- **Không dùng** siêu âm điều trị cho người **đang có thai, bị lao, bị sốt và trẻ em**.
- Gần đây dùng siêu âm **cường độ rất lớn (khoảng 1,4·10^7^ W/m²)** để **phá hủy tổ chức bệnh ở sâu** như **sỏi thận**, u tuyến.

> [!cap-nhat] Tán sỏi và HIFU
> - **Tán sỏi ngoài cơ thể** (*ESWL*, dùng từ năm 1980) thực chất dùng **sóng xung kích** (*shock wave*), là xung áp suất rất mạnh và rất ngắn tạo bằng điện thủy lực, điện từ hoặc áp điện. Sóng được hội tụ vào sỏi dưới hướng dẫn X-quang hoặc siêu âm. Đây không phải chùm siêu âm liên tục như cách diễn đạt của giáo trình, nhưng **cùng bản chất sóng cơ học** và cùng dựa vào **chênh lệch âm trở** giữa sỏi và mô: năng lượng tập trung ở mặt sỏi làm vỡ sỏi. Mô mềm có Z gần nước nên sóng đi qua ít bị tổn thương. Vẫn có thể gặp đái máu, tụ máu quanh thận.
> - **HIFU** (siêu âm hội tụ cường độ cao) hội tụ siêu âm vào một điểm để **đốt nhiệt** mô u (u xơ tử cung, một số u tuyến tiền liệt…) mà không cần mổ.
> - Ngoài ra: **dao mổ siêu âm**, máy **lấy cao răng** siêu âm, **phaco** tán nhuyễn thể thủy tinh đục, **máy khí dung siêu âm**, rửa dụng cụ bằng **bể siêu âm**. Tất cả đều dựa trên hiệu ứng cơ học và cavitation (tr. 163).

> [!yhct] Siêu âm hỗ trợ chiết xuất dược liệu
> Trong bào chế và nghiên cứu dược liệu, **chiết xuất có hỗ trợ siêu âm** (*ultrasound-assisted extraction*, thường 20 – 40 kHz, bằng bể hoặc đầu siêu âm) đã được dùng rộng rãi.
> - **Cơ chế vật lý đã chứng minh**: đây chính là **hiệu ứng cơ học – cavitation** (tr. 163). Bọt vi mô hình thành rồi vỡ, tạo vi tia và sóng xung kích làm **nứt vỡ thành tế bào thực vật**, khuấy trộn mạnh lớp dung môi sát bề mặt nên **tăng khuếch tán** hoạt chất ra dịch chiết.
> - **Kết quả**: so với ngâm, hầm truyền thống, thường **rút ngắn thời gian, hạ nhiệt độ, giảm dung môi** khi chiết flavonoid, saponin, polysaccharid…
> - **Lưu ý**: cường độ quá cao hoặc chiết quá lâu sẽ sinh nhiệt và **gốc tự do** (hiệu ứng hóa lý), có thể phân hủy hoạt chất kém bền. Thành phần dịch chiết siêu âm **có thể khác thang thuốc sắc**, nên không mặc nhiên thay thế sắc thuốc cổ truyền khi chưa có nghiên cứu so sánh.

## 6. Sóng và sự sống

Môi trường sống đầy ắp sóng: sóng cơ (động đất, sóng nước), sóng âm, sóng vô tuyến, ánh sáng, bức xạ ion hóa (tia X, gamma) (tr. 167).

### 6.1. Tác động của sóng đến sự sống — có lợi hay có hại?

Theo giáo trình (tr. 167–168):

- **Lợi hay hại là tương đối.** Chùm siêu âm đúng chỗ phá vỡ được sỏi thận, nhưng sai chỗ có thể làm vỡ mạch máu. Chùm bức xạ ion hóa diệt được tế bào ung thư nhưng cũng hại tế bào lành lân cận. Sóng biển thường tạo ra điện năng, nhưng sóng thần thì phá hoại khủng khiếp.
- Sóng tác động **từ vi mô đến vĩ mô**: siêu âm "xoa bóp vi mô" đến từng tế bào; xoa bóp tay tác động lên cả bắp cơ.
- Tác động liên quan chặt chẽ đến **năng lượng sóng chở đến**. Tác hại thường xuất hiện khi **vượt ngưỡng**, ví dụ âm quá mạnh phá hoại cơ quan thính giác.
- **Chưa có tiêu chuẩn rõ ràng** chia sóng "độc" và sóng "lành"; phải dựa vào hiệu quả sinh vật để đánh giá. Giáo trình nêu một số quan sát như sống dưới đường dây cao thế dễ nhức đầu, rối loạn thần kinh; người làm việc nhiều năm với sóng cực ngắn (rađa) có thể bị ảnh hưởng một số chức năng sinh lý.
- **Sóng là phương tiện chở thông tin** qua sự biến đổi các thông số vật lý: mật độ năng lượng, biên độ, tần số, dạng phổ.
- Có thể còn những loại sóng mà con người tiếp nhận nhưng chưa rõ bản chất.

> [!cap-nhat] Sóng điện từ không ion hóa và sức khỏe
> Một số ví dụ trong giáo trình (nước để trước màn hình tivi, phụ nữ có thai không nên xem tivi nhiều) **không có cơ sở khoa học** được công nhận. Các tổ chức như WHO và ICNIRP đặt giới hạn phơi nhiễm cho sóng vô tuyến, vi sóng. Dưới giới hạn đó, tác động sinh học **đã được xác lập** chủ yếu là **hiệu ứng nhiệt**. Bức xạ **ion hóa** (tia X, gamma) thì khác hẳn: có hại rõ ràng và phải tuân thủ an toàn bức xạ (học ở bài phóng xạ, tia X).

### 6.2. Sơ lược về nhịp sinh học

**Nhịp sinh học** là mọi quá trình **có tính chu kỳ** xảy ra trên cơ thể sống: nhịp tim, điện tim, điện não, kinh nguyệt… Nhịp sinh học là kết quả tổng hợp tác động của môi trường, vũ trụ lên cơ thể qua quá trình hình thành con người; nó có tính ổn định tương đối và phản ánh trạng thái hoạt động của cơ thể (tr. 168).

Giáo trình nêu 3 chu kỳ "tính từ khi sinh ra", mỗi chu kỳ có dạng hình sin:

| Chu kỳ | Độ dài | Đặc điểm theo giáo trình |
|---|---|---|
| **Thể chất** | **23 ngày** (2 bán chu kỳ khoảng 11,5 ngày) | Nửa đầu: khỏe, chịu đựng tốt, cực đại vào ngày 5 – 6. Nửa sau: dễ mệt, cần nghỉ ngơi. Cực tiểu khoảng ngày 17 |
| **Cảm xúc** | **28 ngày** | Nửa đầu tích cực, lạc quan; thuận lợi nhất ngày 8 – 12. Nửa sau dễ bi quan, lo lắng |
| **Trí tuệ** | **33 ngày** | Nửa đầu tiếp thu, sáng tạo, phản xạ nhanh hơn. Nửa sau giảm đi chút ít |

> [!cap-nhat] "Nhịp sinh học 23 – 28 – 33 ngày" không được khoa học công nhận
> Thuyết ba chu kỳ thể chất – cảm xúc – trí tuệ (*biorhythm*, đầu thế kỷ 20) đã được **kiểm chứng nhiều lần và không tìm thấy giá trị dự báo** nào hơn ngẫu nhiên. Hiện nay xếp vào loại **giả khoa học**.
> Ngành **thời sinh học** (*chronobiology*) thật sự nghiên cứu các nhịp **có cơ sở sinh học đo được**:
> - **Nhịp ngày đêm** (*circadian*, khoảng 24 giờ): điều khiển bởi nhân trên chéo và các **gen đồng hồ** (giải Nobel Y học 2017). Ví dụ: cortisol cao buổi sáng, melatonin tiết về đêm, huyết áp và thân nhiệt dao động trong ngày.
> - **Nhịp ngắn hơn ngày** (nhịp tim, nhịp thở, sóng điện não) và **dài hơn ngày** (chu kỳ kinh nguyệt khoảng 28 ngày).
>
> Khi thi, nhớ con số 23 – 28 – 33 theo giáo trình. Không dùng thuyết này để tư vấn cho người bệnh.

## Tóm tắt

| Chủ đề | Điều cốt lõi |
|---|---|
| Dao động điều hòa | F = −kx; x = A·cos(ωt + α); ω = √(k/m) = 2πf; E = 2π²mA²f² |
| Tắt dần | x = A·e^−βt^·cos(ω\*t + α); β = r/2m; ω\* < ω~0~ (chu kỳ dài hơn); giảm lượng loga Δ = βT |
| Cưỡng bức – cộng hưởng | Tần số = tần số ngoại lực; cộng hưởng khi p = √(ω~0~² − 2β²) (≈ ω~0~ khi cản nhỏ) |
| Tổng hợp – phân tích | Cùng pha tăng cường, ngược pha triệt tiêu; mọi dao động phức tạp = tổng các dao động điều hòa (Fourier) |
| Sóng cơ | Ngang (chỉ rắn, mặt lỏng) / dọc (rắn, lỏng, khí); λ = v/f; I = 2π²ρvf²a²; Z = ρv |
| Phản xạ | Z chênh lệch càng lớn, phản xạ càng nhiều; I~p~/I~t~ = [(Z~1~ − Z~2~)/(Z~1~ + Z~2~)]² |
| Doppler | Lại gần ⇒ f' > f; ra xa ⇒ f' < f; siêu âm: Δf ≈ 2f~0~u·cos θ/c |
| Mạch LC, RLC | T~0~ = 2π√(LC); tắt dần e^−Rt/2L^; R~th~ = 2√(L/C); cộng hưởng ω'' = ω~0~, I~m~ = ε~m~/R |
| Sóng điện từ | Sóng ngang, E ⊥ H ⊥ v; truyền trong chân không; c = 3·10^8^ m/s; v = c/√(εμ); S = E × H |
| Tín hiệu | Cảm biến (quang điện, nhiệt điện, áp điện, L/C) → khuếch đại (tranzito, β = α/(1 − α)) → ghi |
| Âm | 16 – 20 000 Hz, sóng dọc; v trong mô 1540 m/s; I ∝ 1/r² |
| Cảm giác âm | Độ cao ↔ tần số; âm sắc ↔ họa âm; độ to ↔ cường độ + tần số; dB = 10·lg(I/I~0~), I~0~ = 10^−12^ W/m²; 0 – 120 dB; phon = dB chỉ ở 1000 Hz |
| Quá trình nghe | Xương con: đòn bẩy 1,3 × diện tích 17 ≈ 22 lần, phối hợp âm trở (không có thì chỉ 0,1% năng lượng lọt vào); âm cao ↔ đáy ốc tai |
| Gõ, nghe | Phổi lành: âm trong, cao, nhiều họa âm, dư âm dài; tạng đặc, tràn dịch: đục; âm tim chủ yếu 50 – 70 Hz; ống nghe = hộp cộng hưởng |
| Rinne | Dương + điếc ⇒ tai trong hoặc não; âm ⇒ tai ngoài hoặc tai giữa |
| Siêu âm | Phát: áp điện nghịch, từ giảo; thu: áp điện thuận. Cần gel (khí – mô phản xạ trên 99%). α ∝ f². Kiểu A, B, TM, 2D, 3D, Doppler (liên tục, xung, màu, năng lượng) |
| Tác dụng siêu âm | Cơ học (cavitation), nhiệt, hóa lý ⇒ điều trị (giảm đau, giãn mạch), tán sỏi; chống chỉ định: có thai, lao, sốt, trẻ em |
| Nhịp sinh học | Giáo trình: 23 – 28 – 33 ngày; hiện nay: giả khoa học, nhịp ngày đêm mới là nhịp sinh học thật |
