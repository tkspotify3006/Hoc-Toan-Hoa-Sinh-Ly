---
title: Hóa sinh màng tế bào
thoi-gian: 40 phút
muc-tieu:
- Trình bày được thành phần hóa học của màng tế bào (lipid, protein, glucid), sự khác nhau về thành phần giữa các loại màng, và mô hình khảm lỏng của màng bào tương.
- Giải thích được các yếu tố quyết định tính lỏng của màng (độ dài và độ bão hòa của acid béo, cholesterol, nhiệt độ).
- Trình bày được các hình thức vận chuyển trực tiếp qua màng: khuếch tán đơn thuần (định luật Fick), khuếch tán tăng cường (K~m~, V~max~), đơn chuyển – đồng chuyển, vận chuyển tích cực nguyên phát (Na^+^-K^+^-ATPase) và thứ phát (glucose ở ruột, Na^+^/Ca^2+^, Na^+^/H^+^).
- Mô tả được vận chuyển theo cơ chế nhập bào (endocytosis) – xuất bào (exocytosis).
- Liên hệ được với một số bệnh và thuốc: họ GLUT – SGLT và glucose niệu, P-glycoprotein và tương tác thuốc, CFTR và bệnh xơ nang, thụ thể LDL.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Màng = **lớp kép phospholipid** (nền, lỏng) + **protein** (chức năng) + **glucid** ở mặt ngoài (glycocalyx). Tỷ lệ protein/lipid khác nhau tùy chức năng: màng trong ty thể 76% protein, myelin chỉ 18%.
> 2. **Mô hình khảm lỏng** (Singer – Nicolson, đầu thập niên 1970): protein như những "cù lao" trôi trong "biển lipid". Protein **xuyên màng** (70–80%) bám chặt, phải dùng chất tẩy mới tách được; protein **rìa màng** (20–30%) bám lỏng bằng liên kết ion, liên kết yếu.
> 3. **Tính lỏng** tăng khi acid béo **ngắn** và **không bão hòa** (nối đôi cis), khi **nhiệt độ** tăng; **cholesterol** là chất "đệm": chống đông đặc khi lạnh, giảm lỏng khi nóng.
> 4. **Vận chuyển trực tiếp**: khuếch tán **đơn thuần** (tỷ lệ thuận với gradient – định luật Fick, không bão hòa) → khuếch tán **tăng cường** (có permease, đặc hiệu, **bão hòa** theo K~m~, V~max~; vẫn thụ động) → vận chuyển **tích cực** (ngược gradient, tốn năng lượng): **nguyên phát** dùng ATP trực tiếp (Na^+^-K^+^-ATPase: 1 ATP → 3 Na^+^ ra, 2 K^+^ vào), **thứ phát** dùng gradient Na^+^ (glucose – Na^+^ ở ruột, Na^+^/Ca^2+^ ở tim, Na^+^/H^+^).
> 5. Phân tử lớn đi bằng **nhập bào** (qua thụ thể → túi → lysosom) và **xuất bào** (túi hòa màng); màng được tái sinh liên tục.

> [!bay] Đọc kèm bài khác, không học lại
> - Mô tả hình thái màng, **glycophorin, band 3, lưới spectrin – ankyrin**, carbohydrat màng, nhóm máu, sự hình thành màng: bài **Màng tế bào và tế bào chất** (Sinh học, sh-02, mục 1).
> - Ba kiểu vận chuyển thấm theo môn Sinh học, **thẩm thấu và dịch truyền**, các bước của bơm Na-K, **glycosid tim (digoxin, Trúc đào, Thông thiên)**, bơm Ca^2+^, bơm proton, **ORS**, **4 hình thức ẩm thực bào**, túi áo clathrin – LDL, **bảng thuốc tác động lên vận chuyển**: bài **Vận chuyển vật chất qua màng tế bào** (Sinh học, sh-04).
> - Cấu tạo **phospholipid, sphingolipid, gangliosid, cholesterol**: bài **Hóa học lipid** (hs-02). Lipoprotein, statin, thụ thể LDL trong điều hòa cholesterol: bài **Chuyển hóa lipid** (hs-08). Phương trình Michaelis – Menten: bài **Enzym** (hs-05). Điện thế nghỉ, phương trình Nernst: bài **Điện và sự sống** (Vật lý, vl-05).

Mọi màng trong tế bào (màng bào tương, màng lưới nội nguyên sinh, ty thể, Golgi, màng nhân…) đều ngăn một khoang với môi trường xung quanh. Trong đó **màng bào tương** điều hòa nhiều chức phận cơ bản: sinh sản, biệt hóa, nhận diện và vận chuyển các chất. Vì vậy hiểu màng là chìa khóa để hiểu **bệnh sinh** của nhiều bệnh và **cơ chế tác dụng** của nhiều thuốc (Giáo trình tr. 203).

Giáo trình kể 4 nhóm phương pháp nghiên cứu màng: **hóa lý** (nhiễu xạ tia X, cộng hưởng từ điện tử, quang phổ tử ngoại, hồng ngoại…), **siêu cấu trúc**, **hóa sinh**, và **siêu hóa học tế bào điện tử**.

## 1. Cấu trúc của màng tế bào

### 1.1. Thành phần hóa học

Mọi màng đều có hai thành phần chính là **lipid** và **protein**; nhiều màng có thêm **carbohydrat** (glucid). Tỷ lệ lipid/protein thay đổi rất nhiều giữa các màng, phản ánh **chức năng khác nhau** của chúng (Giáo trình tr. 203).

#### a) Lipid màng

**Phospholipid** chính gồm: phosphatidylcholin (**PC**), phosphatidylethanolamin (**PE**), phosphatidylserin (**PS**), phosphatidylinositol (**PI**), sphingomyelin (**SM**). Ngoài ra còn phosphatidylglycerol (PG), **diphosphatidylglycerol (DPG) = cardiolipin**, và acid phosphatidic (PA). **Cardiolipin là phospholipid đặc hiệu của màng (trong) ty thể** (Giáo trình tr. 204).

**Acid béo** của lipid màng ở tế bào có nhân hầu như đều có **16, 18 hoặc 20 C**. Acid béo không bão hòa thường có 1 nối đôi, một số có 2–4 nối đôi; các nối đôi đều ở dạng **cis**. Hay gặp: palmitic (16:0), stearic (18:0), oleic 18:1(Δ^9^), linoleic 18:2(Δ^9,12^), arachidonic (Δ^5,8,11,14^).

> [!cap-nhat] Ký hiệu acid arachidonic
> Giáo trình (tr. 204) ghi acid arachidonic là **22:4**. Đúng phải là **20:4** (Δ^5,8,11,14^): acid arachidonic có **20 C**, là tiền chất của prostaglandin, leukotrien (xem hs-02). Đây là lỗi in.

**Cholesterol** chiếm tỷ lệ cao trong màng tế bào **động vật có vú**, nhưng **không có** ở màng hầu hết tế bào **không nhân** (prokaryote/nhân sơ, ví dụ vi khuẩn E. coli). Cholesterol liên quan mật thiết đến **tính lỏng** của màng (mục 1.2.3).

> [!cap-nhat] Cholesterol trong màng ở dạng tự do
> Giáo trình viết "phần lớn cholesterol ở dạng este hóa, liên kết lỏng lẻo với màng". Hiện nay biết rõ cholesterol của màng ở dạng **tự do** (không este hóa): nhóm **3-OH** phân cực nằm ngang hàng với đầu phân cực của phospholipid, nhân steroid cứng cắm vào giữa các đuôi acid béo. **Cholesterol este** (gắn thêm một acid béo vào 3-OH) thì **kỵ nước hoàn toàn**, không xếp được vào lớp kép; nó nằm trong **giọt lipid** dự trữ của tế bào và trong **lõi lipoprotein** (LDL, xem hs-08).

**Thành phần lipid khác nhau giữa các màng** (trích Bảng 13.1, % lipid màng; Giáo trình tr. 204):

| Màng | Cholesterol | PC | PE | SM | Cardiolipin (DPG) | Ghi nhớ |
|---|---|---|---|---|---|---|
| Màng bào tương (gan chuột) | **30** | 18 | 11 | 14 | – | Nhiều cholesterol nhất |
| Lưới nội nguyên sinh có hạt | 6 | **55** | 16 | 3 | – | Giàu PC |
| **Màng trong ty thể** | **3** | 45 | 24 | 2,5 | **18** | Rất ít cholesterol, **giàu cardiolipin** |
| Màng ngoài ty thể | 5 | 50 | 20 | 5 | 3,5 | |
| Màng lysosom | 14 | 25 | 13 | **24** | 5 | Giàu SM; có glycolipid 12% |
| Myelin | 22 | 11 | 14 | 6 | – | Có glycolipid |
| Hồng cầu chuột | 24 | 31 | 15 | 8,5 | – | |
| **Màng bào tương E. coli** | **0** | **0** | **80** | – | 5 | Không có cholesterol, PE chiếm ưu thế; có PG 15% |

**Vì sao như vậy?** Màng trong ty thể có nguồn gốc từ vi khuẩn (thuyết nội cộng sinh, xem sh-02) nên giống màng vi khuẩn: ít cholesterol, có cardiolipin. Cardiolipin (4 đuôi acid béo) góp phần giữ các phức hợp của chuỗi hô hấp lại với nhau và giữ cho màng trong **kín với H^+^**, điều kiện để tạo ATP (xem hs-06).

> [!vi-du] Bất đối xứng của lớp kép — lipid nào nằm ở lớp nào?
> Hai lớp của màng bào tương có thành phần khác nhau (sh-02 đã nêu). Cụ thể: **PC và SM** chủ yếu ở **lớp ngoài**; **PS và PE** chủ yếu ở **lớp trong** (mặt bào tương). Tế bào tốn ATP để giữ sự bất đối xứng này nhờ các enzym "lật" lipid (flippase). Khi tế bào **chết theo chương trình** (apoptosis) hoặc khi **tiểu cầu hoạt hóa**, PS bị lật ra **mặt ngoài**: đó là tín hiệu "hãy ăn tôi" cho đại thực bào, và là bề mặt mang điện âm để các **yếu tố đông máu** bám vào. Phòng xét nghiệm dùng **annexin V** (gắn PS) để phát hiện tế bào đang apoptosis. *(Bổ sung ngoài giáo trình.)*

#### b) Protein màng

Đặc tính rất khác nhau giữa các màng chủ yếu là do **protein** khác nhau. Giáo trình nêu **5 chức năng** của protein màng (tr. 205):

1. **Vận chuyển** các chất vào và ra khỏi tế bào.
2. **Tiếp nhận tín hiệu** từ hormon và các chất hóa học ở dịch gian bào, truyền vào trong tế bào (thụ thể).
3. Làm **neo** cho các thành phần cốt lõi của bào tương (khung xương) và của dịch gian bào.
4. Tham gia **nhận diện, hợp nhất chọn lọc** của tế bào khi biệt hóa và tạo các **nối đặc hiệu** với tế bào khác.
5. Một số là **enzym liên kết màng**, xúc tác phản ứng ở những khu vực nhất định.

Về thành phần, protein màng có cả acid amin (amino acid) **có cực** (acid amin kiềm, acid amin acid) lẫn acid amin **không phân cực**. Theo giáo trình, **cystein** chiếm tỷ lệ rất thấp nên protein màng có **rất ít cầu disulfua**.

#### c) Glucid màng

- Phủ mặt ngoài màng bào tương là **lớp áo glycocalyx**, bản chất là polysaccharid. Đã biết khoảng **200 loại** glucid tham gia cấu tạo màng; hay gặp: **glucose, glucosamin, N-acetylglucosamin, galactose, galactosamin, N-acetylgalactosamin** (và acid sialic). Glucid màng được cho là có vai trò trong **biệt hóa và phát triển** của tế bào (Giáo trình tr. 205).
- Glucid màng luôn ở dạng **phức hợp**: gắn với protein (**glycoprotein**) hoặc với lipid (**glycolipid**).
- **Glycolipid** chiếm **2–20%** lipid màng, gồm **3 loại**: glycolipid **trung tính** (cerebrosid), glycolipid **acid chứa acid sialic** (gangliosid), glycolipid **acid chứa acid sulfuric hoặc phosphoric** (sulfatid…). Cấu tạo: xem hs-02 mục 6.3.
- **Glycoprotein** tham gia cấu tạo **enzym màng, kháng nguyên bề mặt** và **thụ thể màng** (Giáo trình tr. 206). Kháng nguyên nhóm máu ABO là ví dụ rõ nhất (hs-01).

**Tỷ lệ protein – lipid – carbohydrat của một số màng** (Bảng 13.2, Giáo trình tr. 206, %):

| Màng | Protein | Lipid | Carbohydrat | Vì sao? |
|---|---|---|---|---|
| **Myelin** | **18** | **79** | 3 | Chức năng chính là **cách điện** cho sợi trục — cần nhiều lipid, ít protein |
| Màng bào tương hồng cầu người | 49 | 43 | **8** | Nhiều glycoprotein, glycolipid (kháng nguyên nhóm máu) |
| Màng bào tương gan chuột | 44 | 52 | 4 | |
| Màng bào tương amip | 54 | 42 | 4 | |
| **Màng trong ty thể** | **76** | 24 | **0** | Dày đặc enzym chuỗi hô hấp, ATP synthase, chất vận chuyển |
| Màng lục lạp (rau spinach) | 70 | 30 | 0 | Dày đặc protein quang hợp |

> [!bay]
> - Màng **giàu protein nhất**: màng **trong ty thể** (76%). Màng **giàu lipid nhất**: **myelin** (79%).
> - **Carbohydrat** phong phú ở **màng bào tương** của tế bào có nhân, nhưng **không có** ở màng trong ty thể và màng lục lạp (vì glucid màng chỉ quay ra **mặt ngoài tế bào**).

### 1.2. Cấu trúc của màng tế bào

Dù thành phần khác nhau, mọi màng sinh học đều theo **một mẫu hình chung**.

#### 1.2.1. Thí nghiệm của Gorter và Grendel (1925)

Hai nhà khoa học chiết lipid từ một số lượng hồng cầu đã biết, rồi trải lên mặt nước. Phospholipid tự xếp thành **một lớp đơn phân tử**: đầu ưa nước chúc xuống nước, đuôi kỵ nước chĩa lên không khí. **Diện tích lớp đơn ≈ 2 lần tổng diện tích màng hồng cầu**. Vì hồng cầu (động vật có vú) không có màng nào bên trong, kết luận: **lipid màng xếp thành lớp kép (bilayer)** (Giáo trình tr. 206–207). Giáo trình viết tên là "Gortner E"; tên đúng của tác giả là **Evert Gorter**.

**Vì sao chọn hồng cầu?** Hồng cầu trưởng thành không có nhân, ty thể hay lưới nội bào, nên toàn bộ lipid chiết ra **chỉ đến từ màng bào tương**. Nếu dùng tế bào khác, lipid của màng bào quan sẽ làm sai phép tính.

Thí nghiệm tiếp theo cho thấy phospholipid phân tán trong nước **tự hình thành** tấm kép hoặc **túi kín** có thành là lớp kép phospholipid, với cả phospholipid tinh khiết lẫn hỗn hợp lipid giống màng tự nhiên.

> [!ung-dung] Từ "túi lipid tự hình thành" đến thuốc
> Túi kín có thành là lớp kép phospholipid gọi là **liposom**. Người ta "nhốt" thuốc vào liposom để thay đổi cách thuốc phân bố trong cơ thể: ví dụ **amphotericin B dạng liposom** (bớt độc cho thận), **doxorubicin dạng liposom** (bớt độc cho tim). Vaccin mRNA (mARN) dùng **hạt nano lipid** — cùng nguyên lý lipid tự xếp lớp bao lấy hoạt chất.

#### 1.2.2. Mô hình khảm lỏng (fluid mosaic model)

Đầu những năm 1970, **Singer và Nicolson** đưa ra mô hình **khảm lỏng**: màng là **lớp kép phospholipid ở trạng thái lỏng**, trong đó các phân tử protein được **khảm** hoặc **nhúng** vào với độ nông sâu khác nhau — "những cù lao protein trong biển lipid lỏng" (Giáo trình tr. 207–208). Hình vẽ mô hình: xem sh-02, Hình 2.

**Lớp kép phospholipid** là đơn vị cấu trúc cơ bản. Phospholipid là phân tử **phân cực** (lưỡng tính). Động lực tạo lớp kép là **tương tác kỵ nước** của các chuỗi acyl: đầu phân cực quay ra hai mặt tiếp xúc nước, chuỗi acyl quay vào trong tạo **lõi kỵ nước**. Đầu ưa nước có các nhóm tạo được **liên kết hydro** (phosphat, –OH…) (Giáo trình tr. 205, 207).

**Hai loại protein màng** (Giáo trình tr. 208):

| | **Protein xuyên màng** (integral, intrinsic) | **Protein rìa màng** (peripheral, extrinsic) |
|---|---|---|
| Tỷ lệ | **70–80%** protein màng | **20–30%** |
| Vị trí | Có vùng **chôn trong lớp kép**, vùng khác nhô ra ngoài; một số bắc cầu từ mặt này sang mặt kia | **Không** tiếp xúc trực tiếp với lõi kỵ nước |
| Liên kết giữ | **3 loại**: (1) tương tác **ion** giữa acid amin có cực với đầu phân cực của lipid; (2) liên kết **kỵ nước** giữa acid amin kỵ nước với chuỗi acyl ở lõi; (3) liên kết **đặc hiệu** với cấu trúc lipid xác định (vùng có **cholesterol**, phức hợp **glycolipid**) | Gắn **gián tiếp** qua protein xuyên màng (liên kết protein – protein), hoặc trực tiếp với đầu phân cực của lipid bằng **liên kết ion và liên kết yếu** |
| Độ tan | Hầu hết **không tan trong nước** | Dễ tách hơn |
| Cách tách | Rất khó; phải dùng **chất tẩy** (Triton X-100, natri dodecylsulfat SDS, natri deoxycholat…) chiếm chỗ lipid để bao phần kỵ nước của protein | Dùng dung dịch muối, thay đổi pH (phá liên kết ion) — đủ tách |
| Ví dụ | **Enzym, protein vận chuyển, kháng nguyên, protein nhận diện** | Protein enzym không liên kết màng, protein của cấu trúc sợi và ống siêu vi dưới màng |

> [!bay]
> - Giáo trình ghi "hầu hết protein rìa màng khu trú ở **mặt ngoài** màng bào tương, giống một số protein của glycocalyx". Đi thi trả lời theo sách. Nhưng nhớ rằng nhiều protein rìa màng quan trọng nằm ở **mặt trong**: **spectrin, ankyrin, band 4.1, actin** của hồng cầu (sh-02).
> - Chất tẩy tách được protein xuyên màng vì chất tẩy cũng **lưỡng tính**: đầu kỵ nước của nó bao lấy vùng kỵ nước của protein thay cho lipid. Muối mật (deoxycholat là một **acid mật**, xem hs-08) chính là chất tẩy sinh lý trong ruột.

> [!cap-nhat] Bè lipid (lipid raft) và protein neo lipid
> - Liên kết loại (3) của giáo trình — protein gắn đặc hiệu vào "vùng có cholesterol hay phức hợp glycolipid" — ngày nay được mô tả thành khái niệm **bè lipid**: những vi vùng nhỏ, động, **giàu cholesterol và sphingolipid** (sphingomyelin, gangliosid), "đặc" hơn phần màng xung quanh. Nhiều thụ thể và protein truyền tín hiệu tập trung ở đây; một số virus, độc tố (độc tố tả gắn gangliosid GM1) đi vào tế bào qua các vùng này. Kích thước và đời sống thật của bè lipid vẫn còn được nghiên cứu.
> - Ngoài protein xuyên màng và rìa màng, còn loại **protein neo lipid**: protein gắn cộng hóa trị với một phân tử lipid cắm vào màng, điển hình là neo **GPI** (glycosylphosphatidylinositol) ở mặt ngoài.
> - Ví dụ lâm sàng: bệnh **đái huyết sắc tố kịch phát ban đêm** (PNH) do đột biến gen tổng hợp neo GPI → hồng cầu thiếu các protein bảo vệ CD55, CD59 (vốn neo bằng GPI) → bị bổ thể phá hủy. Chẩn đoán bằng **đếm tế bào dòng chảy** tìm hồng cầu, bạch cầu thiếu CD55/CD59.

#### 1.2.3. Tính lỏng của màng

Lớp kép có thể ở **trạng thái gel** (các chuỗi acyl xếp thẳng, sát nhau) hoặc **trạng thái lỏng** (các chuỗi acyl chuyển động tự do). Khi tăng nhiệt độ, màng chuyển từ gel sang lỏng (Giáo trình tr. 209, Hình 13.5). Ba yếu tố quyết định:

1. **Thành phần acid béo.** Lipid có chuỗi acyl **ngắn** hoặc **không bão hòa** chuyển sang lỏng ở **nhiệt độ thấp hơn**.
   - Chuỗi ngắn: diện tích tiếp xúc nhỏ, ít **liên kết Van der Waals** với chuỗi bên cạnh.
   - Nối đôi **cis** tạo **điểm gấp khúc**, chuỗi không xếp sát được → liên kết Van der Waals kém bền → dễ lỏng.
   - Màng tế bào động vật và vi khuẩn có **nhiều acid béo không bão hòa** hơn bão hòa, nên giữ được trạng thái lỏng **ở nhiệt độ thấp**.
2. **Cholesterol** — "yếu tố quyết định" tính lỏng (tr. 210). Vòng steroid cứng nằm xen giữa các phospholipid, gắn với các chuỗi acyl gần nhất và **hạn chế chuyển động** của chúng; đồng thời nó **chen vào giữa** không cho các chuỗi acyl xếp khít với nhau, nên **ngăn màng đông đặc thành gel** khi nhiệt độ hạ.
3. **Nhiệt độ** môi trường.

> [!bay] Cholesterol tác động "hai chiều"
> Câu hỏi hay bẫy: cholesterol làm màng lỏng hơn hay cứng hơn? Trả lời: cholesterol là **chất đệm tính lỏng**. Ở nhiệt độ cơ thể, nó **giảm** tính lỏng (làm màng bền, kém thấm). Khi nhiệt độ hạ, nó **ngăn** màng chuyển sang gel. Tóm lại theo giáo trình: tính lỏng phụ thuộc **thành phần lipid, nồng độ cholesterol và nhiệt độ**.

> [!vi-du] Vì sao tính lỏng quan trọng?
> Protein vận chuyển, thụ thể, enzym màng phải **đổi hình dạng** và **di chuyển** trong màng mới hoạt động được. Màng quá cứng thì chúng bị "kẹt"; màng quá lỏng thì màng thấm rỉ ion. Vi khuẩn, cá sống ở nước lạnh **tăng tỷ lệ acid béo không bão hòa** trong màng để giữ độ lỏng thích hợp — một ví dụ thích nghi ở mức phân tử.

## 2. Vận chuyển các chất qua màng bào tương

### 2.1. Màng lipid tinh khiết cho gì đi qua?

Màng nhân tạo chỉ có phospholipid (± cholesterol) cho thấy tính thấm "gốc" của lớp kép (Giáo trình tr. 210, Hình 13.7):

| Nhóm chất | Ví dụ | Qua lớp kép tinh khiết? |
|---|---|---|
| Khí | O~2~, CO~2~, N~2~ | **Qua dễ** |
| Phân tử phân cực **nhỏ**, không mang điện | **Nước**, urê, ethanol | **Qua được** |
| Phân tử phân cực **lớn**, không mang điện | **Glucose** | **Không** |
| Ion | H^+^, Na^+^, K^+^, Ca^2+^, Mg^2+^, Cl^−^, HCO~3~^−^, HPO~4~^2−^ | **Không** |
| Phân tử phân cực **mang điện** | Acid amin, **ATP**, **glucose-6-phosphat**, nucleosid | **Không** |

Vì vậy hầu hết chất tan trong nước cần **phân tử vận chuyển** (chất mang, *transport molecule*) ở màng. Có **hai cơ chế** vận chuyển:

- **Vận chuyển trực tiếp** (qua màng từng phân tử): **thụ động** gồm khuếch tán **đơn thuần** và khuếch tán **tăng cường**; và vận chuyển **tích cực** (nguyên phát, thứ phát).
- Vận chuyển theo cơ chế **nhập bào – xuất bào** (mục 2.6).

> [!bay] Đối chiếu thuật ngữ hai môn
> | Hóa sinh (bài này) | Sinh học (sh-04) |
> |---|---|
> | Khuếch tán đơn thuần | Vận chuyển thụ động |
> | Khuếch tán tăng cường | Vận chuyển có trung gian |
> | Vận chuyển tích cực | Vận chuyển chủ động |
> | Nhập bào (endocytosis) – xuất bào (exocytosis) | Ẩm thực bào (ẩm bào, nội thực bào, thực bào) – ngoại tiết bào |
>
> Giáo trình Hóa sinh xếp **khuếch tán tăng cường** rõ ràng vào **vận chuyển thụ động** (không tốn năng lượng chuyển hóa).

### 2.2. Khuếch tán đơn thuần

Phân tử nhỏ **hòa vào lớp kép phospholipid**, đi qua rồi hòa vào dung dịch nước ở phía bên kia. Tốc độ **tỷ lệ thuận với gradient nồng độ**, **không phụ thuộc** chất nào khác; khi nồng độ hai bên bằng nhau thì đạt **cân bằng**, không có tích lũy (Giáo trình tr. 211–212).

**Định luật Fick.** Với màng diện tích A, dày Δx, hai bên có nồng độ C~1~ > C~2~:

=> J = dn/dt = −D·A·dC/dx = D·A·(C~1~ − C~2~)/Δx

- J: tốc độ khuếch tán (mol/giây); D: **hằng số khuếch tán**.
- **D phụ thuộc bản chất chất khuếch tán**: độ hòa tan trong lipid (mỡ), kích thước, mức ion hóa. Bước chậm nhất là chất phải **rời nước để vào lõi kỵ nước**, nên tốc độ tỷ lệ với **tính kỵ nước** của chất.
- D qua màng phospholipid **thấp hơn 100–1000 lần** so với trong nước, vì độ nhớt của màng **gấp 100–1000 lần** nước.
- Theo giáo trình, màng tế bào luôn mang điện tích (−) nên **ion hóa trị 1 qua lại dễ hơn**.

![Hình 1. Tốc độ vận chuyển theo nồng độ: khuếch tán đơn thuần tăng tuyến tính; khuếch tán tăng cường tăng nhanh rồi bão hòa ở V~max~](dong-hoc-van-chuyen.svg)

**Năng lượng.** Đi xuôi gradient giải phóng năng lượng tự do (ΔG âm). Ví dụ của giáo trình: chuyển 1 mol chất từ dung dịch **1 M** sang **0,1 M** (chênh 10 lần, 25 °C) giải phóng khoảng **1359 calo** (≈ 5,7 kJ). Ngược lại, muốn đưa 1 mol chất **ngược** gradient đó phải **tốn** 1359 calo (Giáo trình tr. 212).

**Định luật Fick không áp dụng cho phân tử mang điện.** Sự khuếch tán của ion còn bị chi phối bởi **gradient điện thế** qua màng. Mỗi ion như Na^+^ khuếch tán thường kéo theo một ion **trái dấu** (như Cl^−^) để giữ trung hòa điện.

### 2.3. Khuếch tán tăng cường

Cần **protein vận chuyển** (chất mang, **permease**) ở màng. Ba đặc tính (Giáo trình tr. 212):

1. **Tốc độ lớn hơn rất nhiều** so với khuếch tán đơn thuần.
2. **Đặc hiệu**: mỗi protein chỉ dùng cho một loại phân tử/ion, hoặc một nhóm phân tử rất gần nhau.
3. Có **tốc độ tối đa (bão hòa)**: lúc đầu tốc độ tăng theo gradient, nhưng khi nồng độ đủ lớn thì mọi permease đều bận, tốc độ đạt **V~max~** (Hình 1).

Động học giống một phản ứng enzym đơn giản (xem Michaelis – Menten, hs-05):

=> S~ngoài~ + Permease ⇌ (S–Permease) → S~trong~

- **K~m~**: hằng số hình thành phức hợp S–permease = nồng độ cơ chất tại đó tốc độ = ½V~max~. **K~m~ càng nhỏ, ái lực càng lớn.**
- **V~max~**: tốc độ tối đa, phụ thuộc **số lượng** permease trên màng.

**Ví dụ 1 — Glucose vào hồng cầu** (Giáo trình tr. 213). Hồng cầu sống nhờ năng lượng từ glucose, nên cần glucose vào đều đặn.

| Thông số | Giá trị (theo giáo trình) |
|---|---|
| Permease | Protein xuyên màng, TLPT **45.000** |
| Tăng tốc so với khuếch tán qua lớp kép | **50.000 lần** |
| K~m~ với **D-glucose** | **1,5 mM** |
| K~m~ với D-mannose / D-galactose | 20 mM / 30 mM |
| K~m~ với **L-glucose** | **> 3000 mM** (gần như không vận chuyển) |

Ba đặc điểm của kiểu vận chuyển thụ động này thể hiện rõ: **tốc độ cao** (làm giảm gradient), **bão hòa**, và **đặc hiệu** (phân biệt cả đồng phân D/L).

> [!vi-du] Đọc bảng K~m~ như thế nào?
> Glucose máu khoảng 5 mM, gấp hơn 3 lần K~m~ (1,5 mM), nên permease của hồng cầu luôn hoạt động **gần V~max~**: hồng cầu lấy glucose ổn định dù đường huyết dao động. D-galactose (K~m~ 30 mM) cũng đi qua được nhưng kém hơn nhiều; L-glucose thì hầu như không — đây là bằng chứng permease nhận biết **cấu hình không gian** của đường (xem đồng phân D/L, hc-08b).

**Ví dụ 2 — Trao đổi anion ở hồng cầu trong vận chuyển CO~2~** (Giáo trình tr. 213–214).

- **Ở mô**: CO~2~ vào hồng cầu, được **carbonic anhydrase** chuyển thành H~2~CO~3~ → H^+^ + HCO~3~^−^. HCO~3~^−^ ra huyết tương để đến phổi. HCO~3~^−^ tan trong huyết tương **nhiều hơn CO~2~**, nên cách này tăng mạnh khả năng chở CO~2~.
- **Ở phổi**: HCO~3~^−^ từ huyết tương vào lại hồng cầu, carbonic anhydrase phân ly thành CO~2~ để thở ra.
- Mỗi HCO~3~^−^ qua màng thì **một Cl^−^ đi theo hướng ngược lại**, qua một permease xuyên màng (band 3, xem sh-02, sh-04). Vì là trao đổi 1:1 nên **không làm thay đổi điện tích** hai bên màng. Sự cặp đôi HCO~3~^−^ – Cl^−^ là **bắt buộc**.

=> CO~2~ + H~2~O ⇌ H~2~CO~3~ ⇌ H^+^ + HCO~3~^−^  (carbonic anhydrase)

> [!bay]
> Giáo trình gọi trao đổi Cl^−^/HCO~3~^−^ là "hệ thống **đồng vận chuyển** (cotransport)". Đó là vì sách dùng "đồng chuyển" làm **tên chung** cho cả vận chuyển cùng chiều lẫn đối chiều (mục 2.4). Xét chiều đi, trao đổi Cl^−^/HCO~3~^−^ là vận chuyển **đối chiều** (antiport).

> [!cap-nhat] Các họ chất mang glucose: GLUT và SGLT
> Giáo trình chỉ gọi chung là "glucose permease". Hiện nay biết người có nhiều **đồng dạng**, mỗi loại hợp với một mô (K~m~ là giá trị gần đúng):
>
> | Chất mang | Kiểu | Nơi có chính | Đặc điểm |
> |---|---|---|---|
> | **GLUT1** | Khuếch tán tăng cường | **Hồng cầu**, hàng rào máu – não | K~m~ thấp (≈1–2 mM): lấy glucose đều đặn — chính là permease giáo trình mô tả |
> | **GLUT2** | Khuếch tán tăng cường | **Gan**, tế bào β tụy, **mặt đáy** tế bào ruột và ống thận | K~m~ **cao** (≈15–20 mM): tốc độ tỷ lệ với đường huyết → gan và tụy "cảm nhận" được glucose máu |
> | **GLUT3** | Khuếch tán tăng cường | **Neuron** | K~m~ rất thấp: não được ưu tiên khi đường huyết hạ |
> | **GLUT4** | Khuếch tán tăng cường | **Cơ vân, cơ tim, mô mỡ** | **Phụ thuộc insulin**: insulin đưa GLUT4 từ túi dự trữ lên màng (xem hs-07) |
> | **GLUT5** | Khuếch tán tăng cường | Ruột | Chủ yếu vận chuyển **fructose** |
> | **SGLT1** | Tích cực thứ phát (2 Na^+^ : 1 glucose) | **Mặt đỉnh tế bào ruột** | Hấp thu glucose, galactose (mục 2.5c) |
> | **SGLT2** | Tích cực thứ phát (1 Na^+^ : 1 glucose) | **Ống lượn gần** của thận | Tái hấp thu phần lớn glucose lọc qua cầu thận |
>
> Ngoài chất mang, nay còn biết loại **kênh** (kênh ion, **aquaporin** – kênh nước) cho chất đi qua rất nhanh mà không gắn kiểu cơ chất – enzym (xem sh-04).

> [!ung-dung] Ngưỡng thận của glucose = V~max~ của chất mang
> Thận lọc glucose qua cầu thận rồi tái hấp thu gần hết ở ống lượn gần nhờ SGLT. Vì chất mang **bão hòa được**, khi glucose máu vượt khoảng **10 mmol/L** (≈ 180 mg/dL; tham khảo, thay đổi theo người) thì SGLT không "kịp" lấy hết, glucose tràn ra nước tiểu → **glucose niệu** (đái tháo đường, xem hs-07). Ngưỡng thận chính là biểu hiện lâm sàng của V~max~. Thuốc **ức chế SGLT2** (dapagliflozin, empagliflozin) cố ý gây glucose niệu để hạ đường huyết; khi đó glucose niệu dương tính **không** có nghĩa đái tháo đường mất kiểm soát.

### 2.4. Đơn chuyển và đồng chuyển

Theo số chất và chiều đi (Giáo trình tr. 214, Hình 13.11):

- **Đơn chuyển** (uniport): protein chỉ chở **một chất**. Ví dụ: glucose vào hồng cầu.
- **Đồng chuyển** (cotransport): chở **hai chất cặp đôi**, gồm:
  - **Cùng chiều** (symport): hai chất đi **cùng một phía** sang phía kia. Ví dụ: Na^+^ – glucose ở ruột.
  - **Đối chiều** (antiport): hai chất đi **ngược chiều nhau**. Ví dụ: Cl^−^/HCO~3~^−^ ở hồng cầu, Na^+^/Ca^2+^ ở cơ tim, Na^+^/H^+^.

![Hình 2. Đơn chuyển, đồng chuyển cùng chiều và đối chiều. Mũi tên màu cam: Na⁺ đi xuôi gradient, cung cấp năng lượng cho chất còn lại](don-dong-doi-chuyen.svg)

### 2.5. Vận chuyển tích cực

Vận chuyển tích cực cần **chất mang** và **năng lượng chuyển hóa**, đưa chất đi **ngược** gradient nồng độ hoặc điện thế, nên tạo ra sự **tích lũy** chất ở một phía màng. Về nhiệt động học đây là quá trình **không tự xảy ra**, phải đi kèm (trực tiếp hoặc gián tiếp) một quá trình **phát năng lượng**: hấp thu ánh sáng, phản ứng oxy hóa, thủy phân ATP, hoặc dòng "xuôi dốc" của một chất khác (Giáo trình tr. 214–215).

| | **Tích cực nguyên phát** | **Tích cực thứ phát** |
|---|---|---|
| Nguồn năng lượng | **Trực tiếp** từ phản ứng phát năng, thường là **ATP → ADP + P~i~** | Dòng **xuôi dốc** (downhill) của một chất khác — chất này **trước đó đã được bơm ngược dốc** bởi vận chuyển nguyên phát |
| Ví dụ | **Na^+^-K^+^-ATPase** | Na^+^ – glucose (ruột), Na^+^ – acid amin, Na^+^/Ca^2+^, Na^+^/H^+^ |

#### a) Năng lượng cần cho vận chuyển

Biến thiên năng lượng tự do của phản ứng S → P (Giáo trình tr. 215):

=> ΔG = ΔG°' + RT·ln([P]/[S])  (1)

Vận chuyển một chất **không tạo hay cắt liên kết hóa học nào**, nên ΔG°' = 0. Đưa chất từ vùng nồng độ C~1~ sang vùng C~2~:

=> ΔG~T~ = RT·ln(C~2~/C~1~)  (2)

Với **ion** (mang điện tích Z), phải cộng thêm phần **điện**, gọi chung là **hiệu điện thế hóa** (electrochemical potential):

=> ΔG~T~ = RT·ln(C~2~/C~1~) + Z·F·Δψ  (3)

R ≈ 8,314 J/mol·K; T: nhiệt độ tuyệt đối; F ≈ 96.485 C/mol (= J/V·mol, hằng số Faraday; một số sách làm tròn 8,315 và 96.480); Δψ: hiệu điện thế qua màng (volt). ΔG~T~ > 0 → phải tốn năng lượng (tích cực); ΔG~T~ < 0 → tự xảy ra (thụ động).

> [!vi-du] Tính thử: vì sao Na⁺ "rất muốn" vào tế bào?
> Lấy Na^+^ ngoài ≈ 145 mM, trong ≈ 12 mM, điện thế trong màng ≈ −70 mV, 37 °C (RT ≈ 2,58 kJ/mol):
> - Phần nồng độ: 2,58 × ln(12/145) ≈ 2,58 × (−2,49) ≈ **−6,4 kJ/mol**.
> - Phần điện (Z = +1, Δψ = −0,07 V): 96.480 × (−0,07) ≈ **−6,8 kJ/mol**.
> - Tổng ≈ **−13 kJ/mol**: cả nồng độ lẫn điện thế đều đẩy Na^+^ vào. Đây là "kho năng lượng" mà vận chuyển thứ phát khai thác (mục c).
> - Chiều ngược lại, đẩy 3 Na^+^ ra tốn ≈ 3 × 13 ≈ 40 kJ; đưa 2 K^+^ vào tốn thêm ≈ 5 kJ. Tổng ≈ 45 kJ, vừa đủ nằm trong năng lượng thủy phân 1 ATP trong tế bào (khoảng 50–60 kJ/mol). Đó là lý do **1 ATP đổi được 3 Na^+^ + 2 K^+^**. *(Số liệu minh họa, bổ sung ngoài giáo trình.)*

Hầu hết tế bào có **chênh lệch ion trên 10 lần** qua màng bào tương và màng bào quan. Vì thế vận chuyển tích cực là một trong những quá trình **tiêu thụ năng lượng chủ yếu** của tế bào (Giáo trình tr. 215).

#### b) Vận chuyển tích cực nguyên phát — Na^+^-K^+^-ATPase

Trong tế bào [Na^+^] thấp hơn ngoài, [K^+^] cao hơn ngoài. Sự chênh lệch này **không** do cân bằng Donnan mà được **thiết lập và duy trì** bởi enzym **Na^+^-K^+^-ATPase**: mỗi ATP bị cắt thành ADP + P~i~ thì **2 K^+^ vào, 3 Na^+^ ra** (Giáo trình tr. 215–216).

**Cấu trúc** (theo giáo trình):

- Protein xuyên màng dạng **dimer**; mỗi monomer gồm **2 tiểu đơn vị**:
  - **Tiểu đơn vị nhỏ**: TLPT **50.000 Da**, bản chất **glycoprotein** (mang oligosaccharid ở mặt ngoài).
  - **Tiểu đơn vị lớn**: TLPT **120.000 Da**, là polypeptid chứa **vị trí xúc tác thủy phân ATP**; làm nhiệm vụ chuyển ion: **3 vị trí cho Na^+^** và **1 vị trí gắn ATP** ở mặt bào tương; **2 vị trí cho K^+^** ở mặt ngoài.

**Hai trạng thái của enzym** — đây là điểm Hóa sinh nhấn mạnh hơn Sinh học:

| | **Trạng thái I** (E~I~) | **Trạng thái II** (P-E~II~) |
|---|---|---|
| Phosphoryl hóa | **Không** (dạng khử phosphoryl) | **Có** (dạng phosphoryl hóa) |
| Ái lực | **Cao với Na^+^**, yếu với K^+^ | **Cao với K^+^**, yếu với Na^+^ |
| Vị trí gắn ion quay về | Mặt **bào tương** | Mặt **ngoài** |

Bước (1) — phosphoryl hóa enzym (khi 3 Na^+^ đã gắn):

=> ATP + E~I~ → ADP + P-E~II~

Bước (2) — thủy phân phosphoenzym (khi 2 K^+^ đã gắn):

=> P-E~II~ + H~2~O → E~I~ + P~i~

Tổng cộng:

=> ATP + H~2~O → ADP + P~i~

> [!cap-nhat] Sửa phương trình (2) và cấu trúc hiện nay
> - Giáo trình (tr. 216) viết phương trình (2) là "P-E~II~ + H~2~O → E~I~ + **ADP** + P~i~". ADP đã được giải phóng ở bước (1); bước (2) chỉ giải phóng **P~i~**. Nếu không, cộng hai bước sẽ không ra phương trình tổng. Đây là lỗi in.
> - Hiện nay: đơn vị chức năng là **một cặp αβ** (α ≈110 kDa, xúc tác; β ≈35–55 kDa sau glycosyl hóa, glycoprotein). Nhóm phosphat gắn vào một gốc **aspartat** của tiểu đơn vị α. Bơm thuộc họ **ATPase kiểu P** ("P" = tự phosphoryl hóa) — cùng họ với **Ca^2+^-ATPase** và **H^+^/K^+^-ATPase** dạ dày (sh-04).

**Chu kỳ hoạt động** (Giáo trình tr. 216–217):

1. **3 Na^+^** gắn vào vị trí ái lực cao trên tiểu đơn vị lớn, ở **mặt trong** màng; ATP cũng gắn vào.
2. Enzym **bị phosphoryl hóa** → đổi trạng thái (I → II), **ái lực với Na^+^ giảm** → 3 Na^+^ được **giải phóng ra mặt ngoài**.
3. **2 K^+^** gắn vào vị trí ái lực cao ở **mặt ngoài**.
4. Enzym **bị khử phosphoryl** → ái lực với K^+^ giảm → **2 K^+^ được chuyển vào trong**; enzym trở lại trạng thái I, sẵn sàng chu kỳ mới.

Hình vẽ ba bước của bơm: xem sh-04, Hình 2.

**Ý nghĩa** (Giáo trình tr. 217):

- Tạo **điện thế màng**: bên trong âm hơn bên ngoài, hiệu điện thế **50–70 mV** (xem vl-05) → cần cho **dẫn truyền xung động thần kinh**.
- Giữ **nước** và **hình dạng (thể tích)** tế bào.
- Tạo gradient Na^+^ để **vận chuyển chất dinh dưỡng** (glucose, acid amin) theo kiểu tích cực thứ phát.

> [!cap-nhat] Họ vận chuyển ABC: P-glycoprotein và CFTR
> Ngoài các ATPase kiểu P, còn một họ lớn bơm tích cực nguyên phát dùng ATP: **họ ABC** (*ATP-binding cassette*), mỗi protein có 2 vùng xuyên màng và 2 vùng gắn ATP.
> - **P-glycoprotein** (P-gp, MDR1): **bơm đẩy** rất nhiều loại thuốc ra khỏi tế bào. Có ở **mặt lòng ruột** của tế bào ruột (hạn chế hấp thu thuốc), **hàng rào máu – não** (đẩy thuốc ra khỏi não), gan, ống thận. Tế bào ung thư tăng P-gp sẽ **kháng nhiều thuốc hóa trị cùng lúc** (đa kháng thuốc). **Digoxin** là cơ chất của P-gp: thuốc ức chế P-gp (verapamil, clarithromycin, amiodaron) làm **tăng nồng độ digoxin** → nguy cơ ngộ độc.
> - **CFTR** (thuộc họ ABC) đặc biệt ở chỗ nó là một **kênh Cl^−^**; ATP và sự phosphoryl hóa (protein kinase A) điều khiển việc **mở kênh**. Đột biến gây **bệnh xơ nang** (mục ứng dụng dưới).
> - **ABCA1** đẩy cholesterol và phospholipid ra cho apoA-I để tạo **HDL** (hs-08); thiếu ABCA1 gây **bệnh Tangier** (HDL gần như bằng 0).

> [!ung-dung] Bệnh xơ nang (cystic fibrosis) — hỏng một "kênh trong họ bơm"
> - **Di truyền lặn** trên nhiễm sắc thể thường; hay gặp ở người châu Âu, hiếm ở người châu Á. Đột biến thường gặp nhất là **mất phenylalanin 508** (F508del, xem sh-10): protein **gấp sai**, bị giữ lại ở lưới nội bào và phân hủy, không lên được màng.
> - Thiếu Cl^−^ đi ra lòng ống → nước không theo ra → chất tiết **đặc quánh**: tắc phế quản, nhiễm khuẩn phổi tái diễn; tắc ống tụy → **suy tụy ngoại tiết** (phải bổ sung men tụy, xem hs-05); nam vô sinh.
> - **Xét nghiệm mồ hôi**: ở tuyến mồ hôi, CFTR cần để **tái hấp thu** Cl^−^, nên người bệnh có mồ hôi **mặn**. **Cl^−^ mồ hôi ≥ 60 mmol/L** gợi ý chẩn đoán; 30–59 mmol/L là vùng trung gian (tham khảo).
> - Thuốc **điều biến CFTR** (ivacaftor, phối hợp elexacaftor – tezacaftor – ivacaftor) giúp protein gấp đúng và mở kênh, cải thiện rõ chức năng phổi.

> [!yhct] Dược liệu và P-glycoprotein — tương tác qua "bơm đẩy thuốc"
> - **Ban Âu** (*Hypericum perforatum*): **cảm ứng P-gp** ở ruột (cùng với CYP3A4, qua thụ thể PXR), làm **giảm nồng độ digoxin**, ciclosporin — bằng chứng lâm sàng rõ ở người. Chi tiết và cách phân biệt với Cỏ ban Việt Nam: xem khung YHCT ở bài *Hóa sinh gan* (mã hs-17, mục 4.4).
> - **Piperin** (Hồ tiêu, Tất bát) **ức chế P-gp và CYP3A4** trong thí nghiệm in vitro và trên động vật; một số nghiên cứu nhỏ trên người cho thấy làm tăng nồng độ vài thuốc. Mức bằng chứng còn hạn chế, nhưng đủ để thận trọng khi bệnh nhân đang dùng thuốc có khoảng điều trị hẹp.
> - **Berberin** là cơ chất của P-gp; điều này góp phần giải thích vì sao berberin **hấp thu đường uống rất kém** (sinh khả dụng thấp) — dữ liệu chủ yếu in vitro và động vật.
> - Ý nghĩa thực hành: "thuốc nam lành" vẫn có thể làm thay đổi nồng độ thuốc tây qua **bơm vận chuyển ở màng**, không chỉ qua enzym gan. Khi kê đơn cần hỏi bệnh nhân đang dùng **digoxin, thuốc chống thải ghép, thuốc chống đông, thuốc ung thư** hay không.

#### c) Vận chuyển tích cực thứ phát

**1. Hấp thu glucose (và acid amin) ở ruột** (Giáo trình tr. 217–218)

- Ở mặt đỉnh (diềm bàn chải) của tế bào niêm mạc ruột có **protein đồng vận chuyển cùng chiều glucose – Na^+^** (glucose-Na^+^ symport protein). Sự vận chuyển glucose **bắt buộc cặp đôi** với Na^+^.

=> Na^+^~ngoài~ + Glucose~ngoài~ ⇌ Na^+^~trong~ + Glucose~trong~

- [Na^+^] lòng ruột **cao hơn rất nhiều** so với trong tế bào, nên phản ứng nghiêng sang phải, dù [glucose] trong tế bào **cao hơn** lòng ruột. Tức là Na^+^ đi xuôi dốc "kéo" glucose đi ngược dốc.
- Gradient Na^+^ đó do **Na^+^-K^+^-ATPase** tạo ra. Vì vậy ATP được dùng **trực tiếp** để tạo gradient Na^+^, và **gián tiếp** để vận chuyển glucose.
- Hệ đồng vận chuyển **acid amin – Na^+^** hoạt động tương tự, nhất là với acid amin có **gốc R nhỏ** như **alanin**.
- Glucose, acid amin tích lũy trong tế bào rồi ra **máu** bằng **khuếch tán tăng cường** (glucose permease ở mặt đáy).
- Các **liên kết chặt** (tight junction) nối các tế bào niêm mạc với nhau, ngăn glucose khuếch tán ngược trở lại lòng ruột qua khe giữa các tế bào.

![Hình 3. Hấp thu glucose qua tế bào niêm mạc ruột: SGLT1 ở mặt đỉnh (tích cực thứ phát), Na⁺-K⁺-ATPase và GLUT2 ở mặt đáy – bên](te-bao-ruot.svg)

> [!cap-nhat] Vị trí của Na⁺-K⁺-ATPase ở tế bào ruột
> Giáo trình (tr. 219) viết Na^+^-K^+^-ATPase của tế bào niêm mạc ruột "chỉ theo một hướng (**hướng vào lòng ruột**)". Thực tế (và chính Hình 13.14 của sách vẽ đúng): bơm nằm ở **màng đáy – bên**, quay về phía **máu**, đẩy Na^+^ **ra dịch gian bào – máu**. Nhờ vậy Na^+^ trong tế bào luôn thấp, Na^+^ lòng ruột mới đi vào được qua SGLT1. Sự **phân cực** này (SGLT1 ở mặt đỉnh, bơm Na-K và GLUT2 ở mặt đáy) là điều kiện để glucose đi **một chiều** từ ruột vào máu. Tên hiện nay: chất mang mặt đỉnh = **SGLT1**, permease mặt đáy = **GLUT2**.

ORS (oresol) khai thác đúng cơ chế này: xem sh-04.

**2. Vận chuyển đối chiều Na^+^/Ca^2+^ ở cơ tim** (Giáo trình tr. 219)

=> Na^+^~ngoài~ + Ca^2+^~trong~ ⇌ Na^+^~trong~ + Ca^2+^~ngoài~

- Na^+^ vào (xuôi dốc) kéo Ca^2+^ **ra** khỏi tế bào cơ tim (ngược dốc), làm **giảm [Ca^2+^] nội bào**. Vì tăng Ca^2+^ gây co cơ, hệ này giúp cơ tim **giãn** và điều chỉnh sức co.
- Hệ Na^+^-K^+^-ATPase và Na^+^/Ca^2+^ ở cơ tim phân bố **mọi hướng** trên màng (khác với tế bào ruột).
- **Ouabain, digoxin** ức chế Na^+^-K^+^-ATPase → Na^+^ trong tế bào tăng → gradient Na^+^ giảm → Na^+^/Ca^2+^ kém hiệu quả → Ca^2+^ ở lại trong tế bào → **tim co bóp mạnh hơn**. Chi tiết lâm sàng, độc tính và dược liệu chứa glycosid tim: xem sh-04.

**3. Vận chuyển đối chiều Na^+^/H^+^ — điều hòa pH bào tương** (Giáo trình tr. 219–220)

- Na^+^ vào xuôi dốc **bắt buộc kéo theo H^+^ ra** khỏi bào tương.
- Để pH trong và ngoài tế bào ở khoảng 7, tế bào phải liên tục **bơm proton thừa** ra ngoài. Theo giáo trình, chuyển hóa glucose yếm khí sinh CO~2~, CO~2~ hydrat hóa thành H~2~CO~3~ rồi phân ly ra H^+^; nếu không thải H^+^ thì pH bào tương giảm nghiêm trọng.

> [!cap-nhat] Nguồn H⁺ trong tế bào
> CO~2~ chủ yếu sinh ra từ chuyển hóa **hiếu khí** (chu trình Krebs, xem hs-06). Chuyển hóa glucose **yếm khí** (đường phân) tạo **acid lactic** (cùng với H^+^ từ thủy phân ATP), đây mới là nguồn acid chính khi thiếu oxy — ví dụ ở cơ vận động mạnh, hay trong **toan lactic** ở người sốc (xem hs-07). Dù nguồn nào, bộ trao đổi **Na^+^/H^+^** vẫn là đường thải H^+^ quan trọng, đúng như giáo trình.

### 2.6. Nhập bào (endocytosis) và xuất bào (exocytosis)

Tế bào trao đổi không chỉ phân tử nhỏ (ion, monosaccharid, acid amin) mà cả **phân tử lớn** như protein (Giáo trình tr. 220).

**Xuất bào (ngoại xuất).** Các túi trong tế bào **hợp nhất với màng bào tương** rồi giải phóng chất bên trong ra ngoài. Đây là cách tế bào tiết **hormon peptid** (insulin), **protein huyết tương** (gan tiết albumin) và **protein cấu trúc ngoại bào** (collagen).

**Nhập bào (nội nhập)** — theo giáo trình gồm các bước:

1. **Thụ thể đặc hiệu** trên mặt ngoài màng nhận biết và gắn phân tử ở bên ngoài.
2. Vùng màng chứa phức hợp **thụ thể – cơ chất** lõm vào, tạo **túi nhập bào** (endocytic vesicle).
3. Túi hòa với **lysosom**; chất bị phân giải thành các sản phẩm trung gian như **acid amin, nucleotid**.
4. Các sản phẩm này vào bào tương, có thể được **tổng hợp lại** thành phân tử lớn mới.
5. Phần thoái hóa còn lại được gói thành túi và **xuất bào** ra ngoài; **màng được tái sinh**.

Giáo trình kết luận: sự **hòa nhập các màng** rất phức tạp, có các "yếu tố hòa nhập" **chưa biết rõ**, nhiều giả thuyết còn tranh cãi (tr. 221).

> [!cap-nhat] Protein SNARE — "yếu tố hòa nhập màng" nay đã rõ
> Hiện nay biết các túi hòa vào màng đích nhờ các protein **SNARE**: SNARE trên túi (như synaptobrevin) và SNARE trên màng đích (syntaxin, SNAP-25) **quấn chặt** vào nhau, kéo hai lớp màng sát lại đến khi hòa nhập. Ở đầu tận thần kinh, Ca^2+^ là tín hiệu kích hoạt. Công trình này được **giải Nobel Y học 2013** (Rothman, Schekman, Südhof). **Độc tố botulinum** cắt các protein SNARE nên chặn giải phóng acetylcholin (sh-04).

**Thụ thể LDL — ví dụ kinh điển của nhập bào qua thụ thể.** Các bước túi áo clathrin đã học ở sh-04; điều hòa bằng statin và SREBP ở hs-08. Dưới góc nhìn hóa sinh, cần nhớ thêm:

- Thụ thể LDL là **glycoprotein xuyên màng**, nhận diện **apoB-100** của LDL (và apoE).
- Trong thể nội bào (endosome), **pH acid** làm LDL **tách khỏi thụ thể**; thụ thể quay về màng (một thụ thể có thể dùng lại nhiều lần), còn LDL đi tiếp vào lysosom, cholesterol este bị thủy phân thành cholesterol tự do.
- Cholesterol tự do trong tế bào tăng → **ức chế HMG-CoA reductase** và **giảm tổng hợp thụ thể LDL** (điều hòa ngược).

> [!ung-dung] Tăng cholesterol máu gia đình và thuốc nhắm vào thụ thể LDL
> - Đột biến gen **thụ thể LDL** (hoặc gen apoB, gen PCSK9 dạng tăng hoạt) → LDL không vào được tế bào → **LDL-C máu rất cao**, có thể có u vàng ở gân, xơ vữa sớm. Ở người lớn, **LDL-C ≥ 4,9 mmol/L** (≈ 190 mg/dL) là ngưỡng gợi ý cần nghĩ tới thể gia đình (tham khảo; mỗi phòng xét nghiệm và hướng dẫn có tiêu chuẩn riêng).
> - **PCSK9** là protein gắn vào thụ thể LDL và dẫn thụ thể vào **lysosom bị phá hủy** thay vì quay về màng. Thuốc **ức chế PCSK9** (kháng thể đơn dòng) giữ thụ thể lại trên màng lâu hơn → hạ LDL-C mạnh. Đây là ví dụ thuốc tác động trực tiếp vào **chu trình tái sử dụng thụ thể** của nhập bào.

> [!vi-du] Dàn ý trả lời 9 câu hỏi ôn tập của giáo trình (tr. 221)
> 1. Thành phần hóa học chung: mục 1.1 (lipid – protein – glucid; Bảng 13.1, 13.2).
> 2. Mô hình cấu trúc màng: mục 1.2 (Gorter – Grendel, khảm lỏng, 2 loại protein, tính lỏng).
> 3. Khuếch tán đơn thuần: mục 2.2 (Fick, D, ion không theo Fick; ví dụ O~2~, CO~2~, urê, ethanol).
> 4. Khuếch tán tăng cường: mục 2.3 (3 đặc tính, K~m~ – V~max~; glucose hồng cầu, Cl^−^/HCO~3~^−^).
> 5. Đơn vận chuyển, đồng vận chuyển: mục 2.4.
> 6. Tích cực nguyên phát, Na^+^-K^+^-ATPase: mục 2.5a, b.
> 7. Tích cực thứ phát, glucose ở ruột non: mục 2.5c.1.
> 8. Thứ phát với Ca^2+^ và H^+^: mục 2.5c.2–3.
> 9. Sơ đồ nhập bào – xuất bào: mục 2.6.

## Tóm tắt

| Chủ đề | Điểm cốt lõi |
|---|---|
| Lipid màng | PC, PE, PS, PI, SM (+ PG, **cardiolipin – đặc hiệu ty thể**, PA); acid béo 16–20 C, nối đôi **cis**; **cholesterol** nhiều ở màng bào tương động vật có vú (30%), không có ở vi khuẩn |
| Protein màng | 5 chức năng: vận chuyển, thụ thể, neo, nhận diện, enzym. **Xuyên màng 70–80%** (3 kiểu liên kết, tách bằng chất tẩy) / **rìa màng 20–30%** (liên kết ion, yếu) |
| Glucid màng | Glycocalyx; ≈200 loại; **glycolipid 2–20%** lipid màng (trung tính, chứa acid sialic, chứa sulfat/phosphat); glycoprotein = enzym, kháng nguyên, thụ thể |
| Tỷ lệ P/L | Màng trong ty thể **76/24**; myelin **18/79**; hồng cầu 49/43 (glucid 8%) |
| Mô hình | **Gorter & Grendel 1925**: lớp đơn = 2 × diện tích màng → lớp kép. **Singer – Nicolson** (đầu 1970s): khảm lỏng |
| Tính lỏng | Tăng khi chuỗi **ngắn, không bão hòa**, nhiệt độ cao; **cholesterol** là chất đệm |
| Màng tinh khiết | Cho qua: khí, nước, urê, ethanol. Chặn: glucose, ion, acid amin, ATP, G6P |
| Khuếch tán đơn thuần | Theo **Fick** (tuyến tính, không bão hòa); D qua màng thấp hơn trong nước 100–1000 lần; chênh 10 lần ≈ 1359 cal; ion không theo Fick |
| Khuếch tán tăng cường | Permease: **nhanh, đặc hiệu, bão hòa** (K~m~, V~max~). Hồng cầu: TLPT 45.000, ×50.000, K~m~ D-glucose 1,5 mM, L-glucose > 3000 mM. Cl^−^/HCO~3~^−^ 1:1 |
| Đơn/đồng chuyển | Uniport; symport (Na^+^ – glucose); antiport (Cl^−^/HCO~3~^−^, Na^+^/Ca^2+^, Na^+^/H^+^) |
| Năng lượng | ΔG = RT ln(C~2~/C~1~) + ZFΔψ |
| Na^+^-K^+^-ATPase | Dimer; nhỏ 50 kDa (glycoprotein), lớn 120 kDa (xúc tác). E~I~ (ái lực Na^+^) ⇄ P-E~II~ (ái lực K^+^). **1 ATP: 3 Na^+^ ra, 2 K^+^ vào**; điện thế 50–70 mV |
| Thứ phát | Ruột: Na^+^ – glucose, Na^+^ – acid amin (alanin) → ra máu bằng khuếch tán tăng cường; liên kết chặt. Tim: Na^+^/Ca^2+^ (digoxin). Na^+^/H^+^: pH bào tương |
| Nhập – xuất bào | Thụ thể → túi → lysosom → acid amin, nucleotid → bào tương; xuất bào: hormon peptid, protein huyết tương, collagen; màng tái sinh |
| Bổ sung lâm sàng | GLUT1–5, SGLT1–2 (ngưỡng thận ≈10 mmol/L); P-gp (đa kháng thuốc, digoxin); CFTR – xơ nang (Cl^−^ mồ hôi ≥ 60 mmol/L); thụ thể LDL, PCSK9; SNARE |
