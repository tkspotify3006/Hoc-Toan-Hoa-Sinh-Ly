---
title: Hóa sinh thần kinh
thoi-gian: 50 phút
muc-tieu:
- Trình bày được đặc điểm chuyển hóa glucid, lipid, protein ở mô thần kinh; giải thích vì sao não phụ thuộc vào oxy và glucose.
- Mô tả được cơ chế dẫn truyền xung động thần kinh qua synap: duy trì điện thế màng, giải phóng chất dẫn truyền nhờ Ca^2+^, kết thúc tín hiệu.
- Kể được các chất dẫn truyền thần kinh kích thích và ức chế; nêu được 6 tiêu chuẩn của một chất dẫn truyền thần kinh.
- Viết được phản ứng tổng hợp và thoái hóa acetylcholin, serotonin, GABA; nêu được cách kết thúc tác dụng của catecholamin.
- Trình bày được cấu tạo, chức năng của một số peptid thần kinh (chất P, endorphin, enkephalin, somatostatin, angiotensin).
- Vận dụng giải thích cơ chế một số thuốc và ngộ độc tác động lên synap.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Não chỉ nặng **2%** cơ thể nhưng dùng **20–35%** lượng oxy; nhiên liệu gần như duy nhất là **glucose** (khoảng 103 g/ngày). Thiếu oxy **quá 5–6 phút** là tổn thương không hồi phục.
> 2. ATP của não chủ yếu dùng để **giữ chênh lệch ion qua màng** (bơm Na^+^–K^+^, điện thế nghỉ ≈ −70 mV) và **tổng hợp chất dẫn truyền thần kinh**.
> 3. Synap hóa học: xung điện tới → **Ca^2+^ vào** → túi hòa màng, **giải phóng** chất dẫn truyền vào khe (≈ 20 nm) → gắn **thụ thể** màng sau → kết thúc bằng **chuyển hóa, tái hấp thu, khuếch tán**.
> 4. **Acetylcholin** = acetyl-CoA + cholin (*cholin acetyltransferase*), bị **acetylcholinesterase** thủy phân thành acetat + cholin. Catecholamin bị **COMT, MAO** và **tái hấp thu**; serotonin bị **MAO** → 5-HIAA; **GABA** sinh từ **glutamat** (glutamat decarboxylase) và thoái hóa thành **succinat**.
> 5. Chất ức chế chính: **GABA** (não), **glycin** (tủy sống, thân não). Phân tử lớn = **peptid thần kinh**: chất P (11 aa, đau), β-endorphin (31 aa), enkephalin (5 aa), somatostatin (14 aa), angiotensin.

Mô thần kinh gồm **não** và **thần kinh ngoại biên**. Tế bào chính là **neuron**. Mỗi neuron có thể nối với một hoặc nhiều neuron khác; chỗ nối gọi là **synap**. Điểm khác căn bản của mô thần kinh so với các mô khác là khả năng **liên lạc có tổ chức rất cao**, nhờ neuron truyền xung động qua synap (Giáo trình tr. 328).

## 1. Chuyển hóa các chất trong mô thần kinh

### 1.1. Não "đốt" rất nhiều oxy

Chuyển hóa ở não diễn ra rất mạnh để cấp năng lượng cho hoạt động thần kinh (Giáo trình tr. 328–329):

- So sánh máu động mạch vào não với máu tĩnh mạch ra khỏi não: cứ **100 g não tiêu thụ 3,3 mL oxy mỗi phút**, nhiều **hơn 20 lần** cơ lúc nghỉ.
- Não chỉ chiếm **2% khối lượng cơ thể** nhưng dùng **20–35%** tổng lượng oxy của cả cơ thể.
- Não rất nhạy với thiếu oxy: chỉ chịu được **5–6 phút**. Thiếu oxy **quá 6 phút** gây **tổn thương không hồi phục**.

**Vì sao nhạy như vậy?** Não gần như **không dự trữ** năng lượng (rất ít glycogen, không dùng mỡ dự trữ) mà lại tiêu hao ATP liên tục. Thiếu oxy thì chuỗi hô hấp dừng, ATP không được tái tạo, bơm ion ngừng, màng neuron mất điện thế và rối loạn chuyển hóa lan ra toàn bộ mô.

> [!ung-dung] "Thời gian vàng" trong cấp cứu ngừng tim
> Con số 5–6 phút giải thích vì sao khi gặp người ngừng tim phải **ép tim, thổi ngạt ngay**, không chờ xe cấp cứu. Ép tim đưa máu có oxy lên não, kéo dài khoảng thời gian não còn cứu được. Đột quỵ thiếu máu não cũng theo logic này: mạch tắc càng lâu, vùng não chết càng rộng.

### 1.2. Chuyển hóa glucid — glucose là nhiên liệu chính

Trong **điều kiện bình thường**, nhiên liệu **duy nhất** cho não là **glucose** (Giáo trình tr. 329). Các số liệu giáo trình đưa ra:

| Chỉ số (não người, mỗi ngày) | Tổng lượng | Tốc độ trên mỗi gam mô |
|---|---|---|
| Glucose sử dụng | **≈ 103 g** | 0,3 µmol/phút/g |
| Oxy tiêu thụ | 3,4 (xem bẫy dưới) | 1,7 µmol/phút/g |
| ATP tiêu thụ | **20,4 mol** | 10,2 µmol/phút/g |

- Phần lớn ATP của não đến từ **chu trình acid citric**, chu trình này ở não chạy **gần tối đa** công suất. **Đường phân** chỉ hoạt động khoảng **20%** khả năng của nó. Nghĩa là não đốt glucose **hiếu khí, đến tận CO~2~ và H~2~O**, không "đốt dở" thành lactat.
- ATP được dùng chủ yếu cho hai việc: **duy trì gradient ion qua màng** và **tổng hợp chất dẫn truyền thần kinh** cùng các thành phần tế bào khác.

> [!bay] Đơn vị oxy trong giáo trình
> Giáo trình ghi oxy tiêu thụ "3,4 L/ngày". Tính lại từ chính số liệu của sách: 1,7 µmol/phút/g × khoảng 1400 g não × 1440 phút ≈ **3,4 mol/ngày**, không phải 3,4 lít (3,4 mol O~2~ là khoảng 76 lít). Tỷ lệ cũng khớp: 3,4 mol O~2~ / khoảng 0,57 mol glucose ≈ **6**, đúng với C~6~H~12~O~6~ + 6 O~2~ → 6 CO~2~ + 6 H~2~O. Khi thi, nhớ con số "3,4"; hiểu đơn vị đúng là mol.

**Glucose vào não bằng cách nào?** *(bổ sung)* Glucose không tự khuếch tán qua hàng rào máu–não mà đi qua **chất vận chuyển GLUT1** ở tế bào nội mô mao mạch, rồi vào neuron chủ yếu nhờ **GLUT3**. Hai chất vận chuyển này **không cần insulin**. Vì vậy não lấy glucose theo nồng độ trong máu: **đường huyết hạ là não thiếu nhiên liệu ngay**.

> [!vi-du] Khi đói lâu: não chuyển sang dùng thể ceton *(bổ sung)*
> Giáo trình nhấn mạnh glucose "trong điều kiện bình thường". Khi **nhịn đói kéo dài** (vài ngày trở lên), gan tạo nhiều **thể ceton** (acetoacetat, β-hydroxybutyrat) từ acid béo (xem hs-08, mục 2.4). Thể ceton tan trong nước, qua được hàng rào máu–não, và não **tăng dần** khả năng dùng chúng. Sau vài tuần đói, thể ceton có thể đáp ứng khoảng **hai phần ba** nhu cầu năng lượng của não. Nhờ đó cơ thể bớt phải phân giải protein cơ để tân tạo glucose.
>
> Não **không dùng trực tiếp acid béo** làm nhiên liệu chính: acid béo gắn albumin, qua hàng rào máu–não rất kém, và β-oxy hóa ở neuron rất thấp.

> [!ung-dung] Hạ đường huyết và thiếu vitamin B~1~
> - **Hạ đường huyết** (đường huyết **< 3,9 mmol/L**; tham khảo, mỗi phòng xét nghiệm có khoảng riêng): não thiếu glucose nên lú lẫn, nói khó, co giật, hôn mê. Xử trí: cho đường uống nếu còn tỉnh, **tiêm glucose ưu trương** nếu hôn mê.
> - **Thiếu vitamin B~1~** (thiamin): phức hợp pyruvat dehydrogenase và α-cetoglutarat dehydrogenase cần TPP. Mô thần kinh đốt glucose qua đúng hai bước này nên tổn thương nặng nhất (beriberi, bệnh não Wernicke ở người nghiện rượu; xem hs-06).

### 1.3. Chuyển hóa lipid

Lipid là nhóm đại phân tử đáng chú ý ở não (myelin, màng neuron). Chuyển hóa lipid ở mô thần kinh diễn ra **giống các mô khác**, nhưng **đổi mới chậm hơn** nhiều (Giáo trình tr. 329):

- Thí nghiệm đánh dấu bằng H^3^ (tritium): acid béo ở **gan** đổi mới **50% trong 24 giờ**; ở **não** chỉ được thay **20% trong 1 tuần**.
- Não tự tổng hợp được các **phospholipid tạp**.
- Lipid não ở dạng **phức hợp, biệt hóa cao** (phospholipid, sphingolipid, cerebrosid, gangliosid — xem hs-02). Vai trò chính của chúng là **giữ cấu trúc toàn vẹn của màng**, không phải làm nhiên liệu.

### 1.4. Chuyển hóa protein và acid amin (amino acid)

- Protein não **quay vòng (đổi mới) tương đối nhanh** so với protein các mô khác, dù neuron trưởng thành **không còn phân chia** (Giáo trình tr. 329–330). Protein mới liên tục được tạo để thay enzym, thụ thể, kênh ion, chất vận chuyển.
- Chuyển hóa acid amin ở não nhìn chung giống các mô khác (xem hs-09). Điểm riêng: một số acid amin là **tiền chất của chất dẫn truyền thần kinh** (tyrosin → catecholamin; tryptophan → serotonin; glutamat → GABA) và là nguyên liệu tạo **peptid thần kinh** (mục 3).

> [!bay]
> "Protein não đổi mới nhanh" và "neuron không phân chia" **không mâu thuẫn**. Đổi mới protein là thay **phân tử** bên trong một tế bào còn sống. Phân chia là tạo **tế bào mới**.

## 2. Dẫn truyền xung động thần kinh qua synap

### 2.1. Neuron, tế bào thần kinh đệm và hàng rào máu–não

**Neuron** là tế bào biệt hóa rất cao, nhận và truyền thông tin. Mỗi neuron gồm (Giáo trình tr. 330):

- **Thân tế bào** (chứa nhân, bộ máy tổng hợp protein);
- **Sợi nhánh** (dendrit) có các gai nhỏ, như "ăng-ten" **nhận tín hiệu** từ tế bào khác;
- Một **sợi trục** (axon) dài, **chuyển tín hiệu** đi tới tế bào khác.

**Tế bào thần kinh đệm** nằm xen giữa các neuron, làm **vật cách điện** và nâng đỡ. Giáo trình kể 5 loại:

| Loại tế bào đệm | Vai trò chính *(phần vai trò cụ thể là bổ sung)* |
|---|---|
| Tế bào sợi thần kinh (tế bào Schwann, ở ngoại biên) | Tạo bao myelin cho sợi thần kinh ngoại biên |
| Tế bào thần kinh đệm ít gai (oligodendrocyte) | Tạo bao myelin trong thần kinh trung ương |
| Vi tế bào thần kinh đệm (microglia) | Thực bào, "miễn dịch" của não |
| Tế bào màng não thất (ependymal) | Lót não thất, tham gia tạo dịch não tủy |
| **Tế bào hình sao** (astrocyte) | Tạo **hàng rào máu–não**, thu hồi chất dẫn truyền (glutamat, GABA), cấp glutamin cho neuron |

**Hàng rào máu–não.** Tế bào hình sao vươn chân bám quanh mao mạch, đồng thời **cảm ứng tế bào nội mô** mao mạch não khép kín với nhau. Kết quả là một mạng lưới **ngăn các phân tử tan trong nước đi thụ động** từ máu vào não. Các chất tan trong nước chỉ vào được não khi có **hệ thống vận chuyển qua màng riêng** cho chúng (Giáo trình tr. 330). Chất **tan trong lipid** (O~2~, CO~2~, ethanol, thuốc mê) thì qua dễ.

> [!ung-dung] Hàng rào máu–não và thuốc
> - **Dopamin không qua** được hàng rào máu–não, nhưng **L-DOPA** thì qua được nhờ chất vận chuyển acid amin. Vì vậy chữa Parkinson bằng L-DOPA chứ không bằng dopamin (mục 3.2).
> - Thuốc kháng histamin thế hệ 1 (diphenhydramin, clorpheniramin) tan trong lipid, vào não gây **buồn ngủ**; thế hệ 2 (loratadin, cetirizin) ít qua hơn nên ít buồn ngủ.
> - **Atropin** (amin bậc ba) qua được hàng rào máu–não; các thuốc kháng cholinergic có **amin bậc bốn** (mang điện dương thường trực, như butylscopolamin) hầu như không qua.

> [!cap-nhat] Số lượng neuron và tế bào đệm
> Giáo trình ghi mỗi người có **10^11^ – 10^13^ neuron** và tế bào thần kinh đệm **nhiều gấp hơn 10 lần** neuron. Các nghiên cứu đếm tế bào hiện nay (phương pháp phân lập nhân tế bào) cho kết quả não người có khoảng **86 tỷ (≈ 8,6 × 10^10^) neuron**, và số tế bào không phải neuron **xấp xỉ bằng** số neuron (tỷ lệ gần 1 : 1 cho toàn bộ não). Khi thi, trả lời theo giáo trình.

### 2.2. ATP duy trì điện thế màng ở neuron

Phần lý sinh của điện thế nghỉ, điện thế hoạt động đã học ở **vl-05**. Ở đây chỉ nhấn mạnh góc nhìn hóa sinh: **năng lượng lấy từ đâu** (Giáo trình tr. 330–331).

- Ở trạng thái nghỉ, mặt trong màng neuron **âm hơn** mặt ngoài, khoảng **−70 mV**.
- Điện thế này được giữ nhờ **bơm Na^+^–K^+^**: bơm **Na^+^ ra ngoài** và **K^+^ vào trong** theo kiểu **vận chuyển đối kháng** (antiport). Năng lượng cho bơm là **thủy phân ATP → ADP + Pi**, mà ATP này đến từ **chuyển hóa glucose**.
- Khi một vùng màng bị **khử cực** tới **ngưỡng**, các **kênh Na^+^** (protein đổi hình dạng) mở trong vài mili giây: Na^+^ (ngoài cao hơn trong) đổ vào, K^+^ (trong cao hơn ngoài) đi ra.
- Khử cực cục bộ làm protein kênh ở **vùng kế bên** đổi hình dạng và mở theo. Cứ thế xung điện lan dọc sợi trục **theo một chiều**, gồm liên tiếp **khử cực rồi tái khử cực**, nên truyền xa mà **không bị giảm độ lớn**.

> [!bay] Khử cực là màng "bớt âm"
> Giáo trình viết kênh Na^+^ mở khi điện thế màng "giảm (trở nên âm hơn) xuống dưới một giá trị ngưỡng". Cách hiểu đúng: **khử cực** là điện thế trong màng **bớt âm** (ví dụ từ −70 mV lên khoảng −55 mV là ngưỡng). Màng **âm hơn** mức nghỉ gọi là **tăng phân cực** (ưu phân cực), làm neuron **khó** phát xung hơn — đó là tác dụng của chất ức chế (mục 2.3).

> [!vi-du] Vì sao phần lớn ATP của não dành cho bơm ion?
> Mỗi xung điện cho một ít Na^+^ vào và K^+^ ra. Não có hàng chục tỷ neuron phát xung liên tục, nên lượng ion phải "bơm trả" là khổng lồ. Mỗi chu kỳ bơm tốn **1 ATP** để đẩy **3 Na^+^ ra, 2 K^+^ vào**. Người ta ước tính bơm Na^+^–K^+^ dùng khoảng **một nửa** (hoặc hơn) năng lượng của não *(bổ sung)*. Ngừng cấp ATP (thiếu oxy, thiếu glucose) thì gradient ion sụp trong vài phút, neuron mất khả năng phát xung và bắt đầu trương phù.

### 2.3. Synap điện, synap hóa học; chất dẫn truyền kích thích và ức chế

Neuron tương tác với nhau theo **hai cơ chế** (Giáo trình tr. 331):

| | **Synap điện** | **Synap hóa học** |
|---|---|---|
| Cách truyền | Dòng ion đi thẳng từ tế bào này sang tế bào kia | Qua **chất dẫn truyền thần kinh** đi ngang khe synap |
| Đặc điểm | **Nhanh** | **Linh hoạt**, điều chỉnh được mức độ tín hiệu |

Synap hóa học lại có **2 loại thụ thể**:

1. Chất dẫn truyền **gắn trực tiếp vào kênh ion**, làm kênh mở hoặc đóng (thụ thể kiểu kênh, ví dụ thụ thể nicotinic, thụ thể GABA~A~).
2. Chất dẫn truyền gắn vào một **thụ thể** rồi thụ thể giải phóng **chất thông tin thứ hai**, chất này mới tác động lên kênh ion (thụ thể gắn protein G, ví dụ thụ thể muscarinic, thụ thể adrenergic — xem cơ chế cAMP ở hs-14, mục 3).

**Chất dẫn truyền kích thích và ức chế** (Bảng 21.1, Giáo trình tr. 332):

| Kích thích | Ức chế |
|---|---|
| Acetylcholin, aspartat, dopamin, histamin, noradrenalin (norepinephrin), adrenalin (epinephrin), ATP, **glutamat**, serotonin (5-hydroxytryptamin) | **GABA** (acid γ-aminobutyric), **glycin**, taurin |

**Kích thích và ức chế khác nhau thế nào?**

- Chất **kích thích** gây **khử cực** màng sau synap, đưa màng về gần ngưỡng phát xung.
- Chất **ức chế** gắn vào thụ thể **là kênh ion**, làm kênh đổi hình dạng và **mở lỗ cho ion âm nhỏ, chủ yếu Cl^−^, đi vào** tế bào. Bên trong càng âm, màng **tăng phân cực**, tế bào **khó khử cực** hơn.

**Hai chất ức chế chính của thần kinh trung ương** (Giáo trình tr. 333):

- **Glycin**: tác dụng chủ yếu ở **tủy sống và thân não**.
- **GABA**: tác dụng chủ yếu lên **tất cả các phần khác của não**.
- **Strychnin** (alkaloid rất độc) **gắn vào thụ thể glycin**, chặn tác dụng ức chế của glycin. Mất "phanh" ở tủy sống nên neuron vận động phát xung tràn lan. Giáo trình ghi strychnin liều rất nhỏ được dùng để **kích thích thần kinh trung ương**.
- Nhiều thuốc như **benzodiazepin** (diazepam) và **barbiturat** (phenobarbital) **gắn vào thụ thể GABA**, làm tăng tác dụng ức chế của GABA: an thần, gây ngủ, chống co giật.

> [!cap-nhat] "Kích thích" hay "ức chế" tùy thụ thể
> Bảng 21.1 xếp dopamin, serotonin, histamin… vào nhóm kích thích. Hiện nay người ta coi tác dụng kích thích hay ức chế là **tính chất của thụ thể**, không phải của bản thân chất dẫn truyền. Ví dụ: dopamin gắn thụ thể **D~1~** gây kích thích nhưng gắn **D~2~** lại ức chế; acetylcholin **làm co** cơ vân (thụ thể nicotinic) nhưng **làm chậm** nhịp tim (thụ thể muscarinic M~2~). **Glutamat** (kích thích) và **GABA, glycin** (ức chế) thì gần như luôn giữ đúng vai trò. Khi thi, trả lời theo Bảng 21.1.

> [!yhct] Mã tiền — strychnin chặn thụ thể glycin
> Hạt **Mã tiền** (*Strychnos nux-vomica*) chứa **strychnin**, chất chặn thụ thể **glycin** ở tủy sống (cơ chế **đã chứng minh**): mất "phanh" ức chế nên gây co cứng, co giật kiểu uốn ván khi người bệnh vẫn tỉnh. Hiện **không còn dùng strychnin làm thuốc kích thích** vì khoảng liều an toàn quá hẹp. Mã tiền là vị **rất độc**, kể cả đã chế; cách chế biến và cảnh báo (xem bài *Hợp chất dị vòng*, mã hc-11, mục 7.3).

**Sáu tiêu chuẩn của một chất dẫn truyền thần kinh** (Giáo trình tr. 332):

1. Có mặt ở **đầu tận cùng sợi trục tiền synap**.
2. Neuron tiền synap có **enzym tổng hợp** chất đó.
3. **Kích thích sinh lý** làm chất đó được **giải phóng**.
4. Ở synap có **cơ chế kết thúc nhanh** tác dụng của nó.
5. Nó **tác động trực tiếp** lên màng sau synap.
6. Hệ quả: **thuốc làm thay đổi chuyển hóa** của chất đó sẽ **ảnh hưởng in vivo** tới dẫn truyền thần kinh.

> [!vi-du] Tiêu chuẩn 6 chính là nền tảng của dược lý thần kinh
> Hầu hết thuốc thần kinh – tâm thần đều nhắm vào một khâu của chất dẫn truyền: **tổng hợp** (L-DOPA), **thoái hóa** (thuốc ức chế cholinesterase, thuốc ức chế MAO), **tái hấp thu** (SSRI, cocain), hoặc **thụ thể** (atropin, benzodiazepin, thuốc chống loạn thần chẹn D~2~).

### 2.4. Tổng hợp, dự trữ và giải phóng chất dẫn truyền

**Tổng hợp.** Chất dẫn truyền **không phải peptid** (acid amin, dẫn xuất acid amin, chất trung gian chuyển hóa khác) có thể được tổng hợp **ở bất kỳ phần nào** của neuron: bào tương gần nhân, và cả trong **sợi trục, đầu tận cùng** (Giáo trình tr. 333). Ngược lại, peptid thần kinh chỉ tổng hợp được ở **thân tế bào** (mục 3.5).

**Dự trữ.** Chất dẫn truyền được chứa trong các **túi nhỏ** (túi synap) ở đầu tận cùng sợi tiền synap.

**Giải phóng — Ca^2+^ là "công tắc"** (Giáo trình tr. 333):

1. Xung điện tới đầu tận cùng, kênh Ca^2+^ mở, **Ca^2+^ đi vào**, nồng độ Ca^2+^ trong tế bào tăng.
2. Ca^2+^ gắn vào túi synap; đồng thời Ca^2+^ hoạt hóa **protein kinase phụ thuộc Ca^2+^–calmodulin**.
3. Kinase này **phosphoryl hóa synapsin I**, một protein vốn "neo" túi synap vào bộ khung của màng tiền synap.
4. Synapsin I đã phosphoryl hóa **tách khỏi túi**. Túi được giải phóng, **gắn và hòa vào màng** tiền synap, đổ chất dẫn truyền vào khe synap bằng **xuất bào** (exocytosis).
5. Sau đó synapsin I được **khử phosphoryl**, túi mới lại có thể nạp chất dẫn truyền cho chu kỳ sau.

Chất dẫn truyền đi rất nhanh qua **khe synap rộng khoảng 20 nm**, gắn vào thụ thể ở màng sau synap, làm màng thay đổi và khởi đầu xung điện ở tế bào sau synap. Như vậy synap đổi tín hiệu **điện → hóa → điện**.

> [!ung-dung] Độc tố botulinum và hạ calci máu *(bổ sung)*
> - **Độc tố botulinum** (đồ hộp, mắm, pate hỏng) cắt các protein giúp túi hòa màng. Acetylcholin không được giải phóng nên **liệt mềm**, sụp mi, nuốt khó, liệt hô hấp. Liều cực nhỏ được dùng làm thuốc (co cứng cơ, thẩm mỹ).
> - Thiếu Ca^2+^ ngoài tế bào lại làm **màng thần kinh dễ kích thích** (co quắp tay chân, dấu Chvostek, Trousseau). Đây là tác dụng của Ca^2+^ lên ngưỡng kênh Na^+^, khác với vai trò giải phóng chất dẫn truyền.

### 2.5. Kết thúc tín hiệu ở synap

Tín hiệu phải **tắt nhanh**, nếu không màng sau synap bị kích thích liên tục. Có **3 cách** (Giáo trình tr. 333):

| Cách | Ví dụ |
|---|---|
| **Chuyển hóa** (enzym phân hủy) | Acetylcholin bị acetylcholinesterase thủy phân ngay trong khe |
| **Tái hấp thu** vào neuron tiền synap (hoặc tế bào đệm) | Catecholamin, serotonin, GABA, glutamat |
| **Khuếch tán** ra khỏi khe synap | Mọi chất, đóng góp ít |

Các đáp ứng **nhanh** thường được kết thúc bằng **một hoặc cả hai cách đầu**.

## 3. Các chất dẫn truyền thần kinh

Đến nay đã phát hiện khoảng **40 chất** dẫn truyền thần kinh (theo giáo trình; con số thực tế được biết ngày nay lớn hơn nhiều). Chia **2 nhóm** (Giáo trình tr. 333–334):

| | **Phân tử nhỏ** | **Phân tử lớn (peptid thần kinh)** |
|---|---|---|
| Bản chất | Thường là **dẫn xuất acid amin** (và acetylcholin, ATP) | **Peptid** |
| Nơi tổng hợp | Ở **bất kỳ phần nào** của neuron, kể cả đầu tận cùng | Chỉ ở **thân tế bào** (cần ribosom), cắt từ protein tiền chất lớn |
| Tác dụng | **Nhanh**, gây phần lớn **đáp ứng cấp** (truyền cảm giác lên não, lệnh vận động xuống cơ) | Chậm hơn, điều biến; trung gian cho **đói, khát, tình dục, vui, buồn, đau…** |
| Ví dụ | Acetylcholin, catecholamin, serotonin, GABA, glutamat, glycin | Chất P, endorphin, enkephalin, somatostatin, angiotensin |

### 3.1. Acetylcholin

![Hình 1. Synap cholinergic: tổng hợp – giải phóng – gắn thụ thể – thủy phân acetylcholin](synap-cholinergic.svg)

**Tổng hợp.** Acetylcholin (ACh) được tạo **tại đầu tận cùng** bằng phản ứng ngưng tụ giữa **acetyl-CoA** và **cholin**, xúc tác bởi **cholin acetyltransferase** (ChAT) (Giáo trình tr. 334):

=> CH~3~–CO–SCoA + HO–CH~2~–CH~2~–N^+^(CH~3~)~3~ → CH~3~–CO–O–CH~2~–CH~2~–N^+^(CH~3~)~3~ + CoA-SH

=> Acetyl-CoA + cholin → acetylcholin + CoA-SH  (cholin acetyltransferase)

- **Cholin** chủ yếu lấy **từ thức ăn**; một phần **tái hấp thu từ khe synap**; một phần từ các đường chuyển hóa khác.
- **Acetyl-CoA** chủ yếu đến từ **khử carboxyl oxy hóa pyruvat** (phức hợp **pyruvat dehydrogenase**). Nhiên liệu chính của neuron là glucose, đi qua chu trình acid citric; acetyl-CoA dùng tổng hợp ACh là một phần của dòng này.
- Giáo trình ghi neuron **không tạo acetyl-CoA từ acetat + CoA** vì **không có acetyl-CoA synthetase**; nghĩa là nguồn acetyl-CoA cho ACh thực tế là **pyruvat** (từ glucose).
- **Vị trí:** acetyl-CoA được tạo **trong ty thể**, còn ChAT nằm **trong bào tương**. Acetyl-CoA được chuyển qua màng ty thể ra bào tương theo cơ chế giống các tế bào khác (không đi qua màng trực tiếp được; dùng "con thoi" citrat).

**Giải phóng và tác dụng.** ACh được giải phóng vào khe synap, gắn vào **thụ thể nicotinic–acetylcholin** trên màng sau synap.

> [!bay] Lỗi in trong giáo trình
> Giáo trình (tr. 334) viết "**Acetyl CoA** được giải phóng và tương tác với receptor nicotinic-acetylcholin". Chất được giải phóng vào khe và gắn thụ thể là **acetylcholin**, không phải acetyl-CoA. Acetyl-CoA chỉ là nguyên liệu, ở lại trong neuron.

**Thủy phân.** Sau khi truyền tin, ACh ở màng sau synap bị **acetylcholinesterase** (AChE) thủy phân (cắt liên kết ester):

=> CH~3~–CO–O–CH~2~–CH~2~–N^+^(CH~3~)~3~ + H~2~O → CH~3~–COOH + HO–CH~2~–CH~2~–N^+^(CH~3~)~3~

=> Acetylcholin + H~2~O → acetat + cholin  (acetylcholinesterase)

- **Cholin** được màng tiền synap **thu hồi** để tổng hợp lại ACh.
- **Acetat** được **tái hấp thu vào máu** và chủ yếu được chuyển hóa **ở mô khác**, không phải ở mô thần kinh.

**Hai loại thụ thể của acetylcholin** *(bổ sung, cần cho phần ứng dụng)*:

| | **Nicotinic** | **Muscarinic** |
|---|---|---|
| Bản chất | **Kênh ion** (Na^+^ vào → khử cực) | Thụ thể **gắn protein G** (chất thông tin thứ hai) |
| Vị trí chính | **Tấm vận động cơ vân**, hạch thần kinh tự chủ, não | **Cơ quan đích của phó giao cảm**: tim, cơ trơn, tuyến; não |
| Chất chẹn | Curare, thuốc giãn cơ khi gây mê | **Atropin**, scopolamin |

> [!ung-dung] Thuốc ức chế cholinesterase và ngộ độc phospho hữu cơ
> Ức chế AChE thì ACh **không bị phân hủy**, ứ lại trong khe và kích thích thụ thể liên tục.
> - **Ngộ độc phospho hữu cơ** (thuốc trừ sâu, khí độc thần kinh): chất độc **phosphoryl hóa serin** ở trung tâm hoạt động của AChE (cơ chế enzym: hs-05, mục 7.6). Triệu chứng gồm 3 nhóm:
>   - **Muscarinic**: co đồng tử, tăng tiết (nước bọt, phế quản, mồ hôi), co thắt phế quản, nhịp tim chậm, tiêu chảy, tiểu không tự chủ.
>   - **Nicotinic**: rung giật bó cơ, rồi **yếu – liệt cơ**, kể cả cơ hô hấp.
>   - **Thần kinh trung ương**: lú lẫn, co giật, hôn mê, ức chế hô hấp.
> - **Điều trị**: **atropin** liều cao, chỉnh theo dấu hiệu "thấm atropin" (hết tăng tiết phế quản), chỉ chặn được triệu chứng **muscarinic**; **pralidoxim** gỡ nhóm phospho, tái hoạt hóa AChE, về lý thuyết cứu được cả triệu chứng **nicotinic** (liệt cơ) nếu dùng **sớm** trước khi enzym bị "lão hóa" (pralidoxim mang điện dương thường trực nên **ít qua hàng rào máu–não**). Lưu ý: hiệu quả lâm sàng của pralidoxim trong ngộ độc thuốc trừ sâu **còn tranh cãi** (thử nghiệm lâm sàng không thấy giảm tử vong rõ), nhưng vẫn có trong nhiều phác đồ; **atropin + hồi sức hô hấp** mới là nền tảng. Cơ chế enzym, "lão hóa": hs-05, mục 7.6.
> - **Xét nghiệm hỗ trợ**: hoạt độ **cholinesterase huyết thanh** (butyrylcholinesterase, do gan tổng hợp; đơn vị U/L) **giảm mạnh** so với khoảng tham chiếu (tham khảo, mỗi phòng xét nghiệm có khoảng riêng); hoạt độ AChE hồng cầu phản ánh sát hơn mức ức chế ở synap.
> - **Thuốc ức chế cholinesterase thuận nghịch** dùng chữa bệnh:
>   - **Nhược cơ** (myasthenia gravis): cơ thể tạo **kháng thể chống thụ thể nicotinic** ở tấm vận động, số thụ thể giảm, cơ **yếu dần khi gắng sức**, sụp mi, nhìn đôi. **Neostigmin, pyridostigmin** giữ ACh lâu hơn trong khe để "bù" cho số thụ thể ít.
>   - **Alzheimer**: thiếu neuron cholinergic; **donepezil, rivastigmin, galantamin** cải thiện nhẹ triệu chứng nhận thức.
>   - Neostigmin còn dùng **giải giãn cơ** sau gây mê.

> [!yhct] Dược liệu tác động lên synap cholinergic
> - **Cà độc dược** (*Datura metel*, hoa, lá, hạt) chứa **scopolamin (hyoscin)** và **hyoscyamin/atropin**. Đây là các alkaloid **chẹn thụ thể muscarinic** (cơ chế **đã chứng minh rõ**, chính là dược lý của atropin). Trong YHCT, hoa và lá được dùng với liều rất nhỏ cho chứng ho, hen suyễn; tác dụng giãn phế quản, giảm tiết phù hợp với cơ chế kháng muscarinic. **Rất độc**: quá liều gây hội chứng kháng cholinergic — **giãn đồng tử, da khô nóng đỏ, sốt, mạch nhanh, bí tiểu, kích động, mê sảng, ảo giác**. Ngộ độc hay gặp do ăn nhầm hạt, uống rượu ngâm. Lưu ý: ngộ độc Cà độc dược và ngộ độc phospho hữu cơ cho triệu chứng **ngược nhau** (giãn đồng tử ↔ co đồng tử; khô ↔ tăng tiết).
> - **Thạch tùng răng cưa** (*Huperzia serrata*) chứa **huperzin A**, chất **ức chế AChE thuận nghịch**, cùng nhóm cơ chế với donepezil. Mức bằng chứng lâm sàng và các lưu ý (xem bài *Enzym*, mã hs-05, mục 10, khung YHCT).

### 3.2. Các catecholamin

**Epinephrin, norepinephrin và dopamin** (3,4-dihydroxyphenylethylamin) được tổng hợp từ **phenylalanin** (qua tyrosin → DOPA → dopamin → norepinephrin → epinephrin) và thoái hóa như đã học ở chương hormon (Giáo trình tr. 334). Sơ đồ đầy đủ, các enzym và coenzym: xem **hs-14, mục 5.1 (Hình 3)**. Các amin sinh học khác tạo bằng khử carboxyl acid amin: xem **hs-09, mục 4**.

**Ba cách kết thúc tác dụng của catecholamin** (Giáo trình tr. 335):

1. **Methyl hóa** một nhóm –OH của nhân catechol: enzym **catechol-O-methyltransferase (COMT)** ở bào tương chuyển nhóm methyl từ **S-adenosylmethionin (SAM)** sang –OH.
2. **Khử amin oxy hóa** mạch nhánh: **monoamin oxidase (MAO)** biến amin thành **aldehyd** và ion amoni. MAO tác dụng được cả lên amin đã hoặc chưa bị COMT methyl hóa.
3. **Tái hấp thu** về neuron tiền synap.

**Điểm mấu chốt:** các enzym thoái hóa (COMT, MAO) nằm **trong tế bào** (COMT ở bào tương; MAO ở **màng ngoài ty thể**), không nằm trong khe synap như AChE. Vì vậy catecholamin phải được **hấp thu từ khe synap vào trong tế bào** rồi mới bị thoái hóa. *(Giáo trình nói tới neuron tiền synap; thực tế MAO có nhiều ở đầu tận cùng tiền synap, còn COMT chủ yếu ở tế bào sau synap, tế bào đệm và gan.)* Với dopamin, có một **protein vận chuyển dopamin** đảm nhận việc tái hấp thu.

> [!ung-dung] Cocain, Parkinson và thuốc ức chế MAO
> - **Cocain** gắn vào **protein vận chuyển dopamin**, chặn tái hấp thu. Dopamin nằm lại lâu trong khe synap, kích thích liên tục thụ thể của neuron sau synap: gây khoái cảm và **nghiện** (Giáo trình tr. 335).
> - **Parkinson**: thoái hóa neuron dopaminergic ở chất đen, thể vân thiếu dopamin, gây run khi nghỉ, cứng cơ, chậm vận động. Điều trị bằng **L-DOPA** (qua được hàng rào máu–não, vào não được DOPA decarboxylase khử carboxyl thành dopamin). L-DOPA luôn dùng kèm **carbidopa** (hoặc benserazid): chất này ức chế DOPA decarboxylase **ở ngoại biên** nhưng **không qua được hàng rào máu–não**, nên L-DOPA không bị "tiêu" thành dopamin ngoài não, giảm buồn nôn, rối loạn nhịp. Thuốc ức chế **MAO-B** (selegilin) và **COMT** (entacapon) giúp dopamin, L-DOPA tồn tại lâu hơn.
> - Thuốc **ức chế MAO** không chọn lọc dùng chữa trầm cảm: phải kiêng thức ăn giàu **tyramin** (xem hs-09, mục 4).

### 3.3. Serotonin (5-hydroxytryptamin)

Serotonin được tổng hợp từ **tryptophan** qua 2 bước, tương tự đường tổng hợp catecholamin (Giáo trình tr. 335, Hình 21.2):

| Bước | Phản ứng | Enzym | Cần |
|---|---|---|---|
| 1 | Tryptophan → **5-hydroxytryptophan** (gắn –OH vào vị trí 5 của nhân indol) | **Tryptophan 5-monooxygenase** (tryptophan hydroxylase) | O~2~, **tetrahydrobiopterin** (BH~4~ → dihydrobiopterin) |
| 2 | 5-Hydroxytryptophan → **serotonin** (− CO~2~) | **Decarboxylase các L-acid amin thơm** (cùng enzym với DOPA decarboxylase) | Pyridoxal phosphat |

**Thoái hóa** — khác catecholamin, đường thoái hóa **chủ yếu là khử amin oxy hóa bởi MAO**:

=> Serotonin + O~2~ + H~2~O → 5-hydroxyindol-3-acetaldehyd + NH~3~ + H~2~O~2~  (MAO, coenzym FAD)

=> 5-Hydroxyindol-3-acetaldehyd + NAD^+^ → 5-hydroxyindol-3-acetat + NADH + H^+^  (aldehyd dehydrogenase)

Sản phẩm cuối là **acid 5-hydroxyindolacetic (5-HIAA)**, thải qua nước tiểu.

> [!bay]
> - Catecholamin: thoái hóa bởi **cả COMT và MAO** (sản phẩm cuối VMA). Serotonin: **không có nhóm catechol** nên **không** là cơ chất của COMT; thoái hóa **chủ yếu bởi MAO** (sản phẩm cuối 5-HIAA).
> - Cả catecholamin và serotonin đều cần một enzym **hydroxylase dùng tetrahydrobiopterin** ở bước đầu và một **decarboxylase dùng PLP** ở bước sau.

> [!ung-dung] Trầm cảm và thuốc SSRI
> - Giả thuyết kinh điển: trầm cảm liên quan tới **thiếu hoạt động serotonin và norepinephrin** ở não. Đây là giả thuyết **đã đơn giản hóa**, nhưng thuốc tác động lên hệ này vẫn có hiệu quả điều trị.
> - **SSRI** (thuốc ức chế chọn lọc tái hấp thu serotonin: fluoxetin, sertralin, escitalopram) **chặn protein vận chuyển serotonin** ở màng tiền synap, giữ serotonin lâu trong khe. Tác dụng chống trầm cảm thường xuất hiện sau **2–4 tuần**.
> - Phối hợp SSRI với thuốc ức chế MAO (hoặc tramadol, một số thuốc khác tăng serotonin) có thể gây **hội chứng serotonin**: sốt, vã mồ hôi, run, giật cơ, kích động — có thể tử vong.
> - **5-HIAA niệu tăng** rất cao gợi ý **u carcinoid** (u tế bào thần kinh nội tiết tiết nhiều serotonin, gây cơn bốc hỏa, tiêu chảy).

### 3.4. GABA (acid γ-aminobutyric) và glutamat

GABA được tổng hợp và thoái hóa qua một chuỗi phản ứng gọi là **nhánh chuyển hóa của GABA** (GABA shunt). Nhánh này "rẽ" ra từ chu trình acid citric ở **α-cetoglutarat** và "nhập" trở lại ở **succinat** (Giáo trình tr. 336–337, Hình 21.3).

![Hình 2. Nhánh chuyển hóa GABA và chu trình glutamat – glutamin](gaba-shunt.svg)

**Tổng hợp GABA:**

=> (1) α-Cetoglutarat + acid α-amin → glutamat + acid α-cetonic  (transaminase)

=> (2) Glutamat → GABA + CO~2~  (glutamat decarboxylase, coenzym PLP)

**Glutamat và glutamin:**

=> (3) Glutamat + NH~3~ + ATP → glutamin + ADP + Pi  (glutamin synthetase)

=> (4) Glutamin + H~2~O → glutamat + NH~3~  (glutaminase)

**Thoái hóa GABA:**

=> (5) GABA + acid α-cetonic → succinat semialdehyd + acid amin  (GABA transaminase)

=> (6) Succinat semialdehyd + NAD^+^ + H~2~O → succinat + NADH + H^+^  (succinat semialdehyd dehydrogenase)

Succinat đi tiếp vào **chu trình acid citric**.

**Ai làm gì? — chu trình glutamat – glutamin giữa neuron và tế bào hình sao:**

- **GABA** là chất dẫn truyền **ức chế**; **glutamat** là chất dẫn truyền **kích thích**. Glutamat còn tham gia chuyển hóa chung ở **tế bào hình sao**.
- Glutamat (và GABA) sau khi được giải phóng một phần được **tế bào hình sao thu hồi**. Ở đó glutamat được chuyển thành **glutamin** (phản ứng 3, tốn ATP). Glutamin **không có hoạt tính dẫn truyền**, nên vận chuyển an toàn trở lại **neuron tiền synap**.
- Ở neuron, **glutaminase** thủy phân glutamin thành glutamat (phản ứng 4):
  - ở **neuron kích thích**, glutamat này được nạp vào túi và dùng làm chất dẫn truyền;
  - ở **neuron ức chế**, glutamat được khử carboxyl thành **GABA** (phản ứng 2) rồi nạp vào túi.
- Vì vậy giáo trình coi glutamat như **chất trung gian** trong chuyển hóa GABA.

> [!bay] Tên enzym ở phản ứng 3
> Giáo trình ghi enzym tạo glutamin là "glutamyl synthetase". Tên chuẩn là **glutamin synthetase** (glutamine synthetase), cùng enzym đã học ở chu trình ure và vận chuyển NH~3~ (hs-09, mục 3.1). Ngoài ra cần phân biệt: **glutamat decarboxylase** (glutamat → GABA, mất CO~2~) với **glutamat dehydrogenase** (khử amin oxy hóa glutamat → α-cetoglutarat, xem hs-09).

> [!ung-dung] GABA, vitamin B~6~ và co giật
> - **Glutamat decarboxylase cần pyridoxal phosphat (PLP)**. Thiếu B~6~ (trẻ bú sữa thiếu B~6~, ngộ độc **isoniazid** liều cao) làm giảm tạo GABA, mất "phanh" ức chế nên **co giật**. Co giật do ngộ độc isoniazid thường **kháng thuốc chống co giật thông thường** và được điều trị đặc hiệu bằng **vitamin B~6~ tiêm tĩnh mạch**.
> - **Benzodiazepin, barbiturat** tăng tác dụng của GABA tại thụ thể (mục 2.3): dùng cắt cơn co giật, an thần. Rượu cũng tác động lên thụ thể GABA; vì vậy cai rượu đột ngột gây kích thích quá mức, run, co giật.
> - Glutamin synthetase ở tế bào hình sao là nơi **não khử độc NH~3~**. Khi NH~3~ máu cao (bệnh não gan), tế bào hình sao tích glutamin, trương phù — xem hs-09, mục 8.4.
> - Glutamat giải phóng quá mức khi thiếu máu não làm neuron bị kích thích đến chết (**độc tính kích thích**, *bổ sung*), góp phần mở rộng vùng tổn thương sau đột quỵ.

### 3.5. Các chất dẫn truyền thần kinh phân tử lớn — peptid thần kinh

**Đặc điểm chung** (Giáo trình tr. 338):

- Bản chất **peptid**. Chúng được tổng hợp dưới dạng **protein tiền chất lớn**, sau đó bị **thủy phân cắt bớt** thành peptid nhỏ có hoạt tính.
- Vì cần **bộ máy tổng hợp protein** (ribosom, lưới nội bào) nên chỉ tổng hợp được ở **thân tế bào**, **không** ở sợi trục.
- Mỗi loại neuron chỉ tổng hợp **một hoặc vài** peptid thần kinh.
- Peptid thần kinh thường làm trung gian cho các cảm giác **đói, khát, tình dục, vui, buồn, yêu thương, đau, đau khổ…**
- Một số peptid có trong mô não: chất P, các endorphin, các enkephalin, somatostatin, angiotensin I và II…

| Peptid | Số acid amin | Cấu tạo đáng nhớ | Chức năng |
|---|---|---|---|
| **Chất P** (substance P) | **11** | Arg^1^-Pro-Lys-Pro-Gln-Gln-Phe-Phe-Gly-Leu-Met^11^ (đầu C là Met) | Chất dẫn truyền **kích thích**, **truyền cảm giác đau** |
| **β-Endorphin** | **31** | Bắt đầu Tyr^1^-Gly-Gly-Phe-Met^5^…, kết thúc Glu^31^; là đoạn **61–91** của **β-lipotropin** (β-LPH, 91 aa) | Opioid nội sinh, **giảm đau rất mạnh** |
| **Enkephalin** | **5** (pentapeptid) | **Met-enkephalin**: Tyr-Gly-Gly-Phe-**Met**; **Leu-enkephalin**: Tyr-Gly-Gly-Phe-**Leu** | Giảm đau kiểu opioid |
| **Somatostatin** | **14** | Một **cầu disulfur** giữa **Cys^3^ và Cys^14^** | **Ức chế tiết hormon tăng trưởng (GH)** |
| **Angiotensin I** | **10** | Asp^1^-Arg-Val-Tyr-Ile-His-Pro-Phe-His-Leu^10^ | Tiền chất |
| **Angiotensin II** | **8** | Asp^1^-…-Pro-Phe^8^ (bỏ 2 aa cuối His-Leu) | **Co mạch, tăng huyết áp**, kích thích vỏ thượng thận **giải phóng aldosteron** |

Một số chi tiết của giáo trình (tr. 338–339):

- **Endorphin** thuộc nhóm **peptid opioid**, do **thùy trước tuyến yên** bài tiết; gọi là "opioid" vì tác dụng giống thuốc phiện trên thần kinh trung ương. Tên "endorphin" = **endo**genous (nội sinh) + m**orphin**, tức "morphin nội sinh". Giáo trình ghi β-endorphin giảm đau **gấp hàng trăm lần morphin**.
- **β-LPH** (91 aa) bị **protease** cắt, giải phóng β-endorphin (aa 61–91). Đây là ví dụ điển hình của "peptid được cắt ra từ tiền chất lớn".
- Endorphin, enkephalin gắn vào **thụ thể opiat** trong não, thể hiện tác dụng giảm đau mỗi khi có kích thích đau.
- Angiotensin II được tạo từ angiotensin I nhờ **enzym chuyển angiotensin** (ACE).
- Giáo trình viết enkephalin "có **đầu tận N** là Met" (Met-enkephalin) hoặc Leu, nhưng chính công thức sách đưa ra cho thấy Met/Leu nằm ở **vị trí 5, tức đầu C**; đầu N của cả hai là **Tyr**.
- Trình tự somatostatin trong giáo trình có ký hiệu "Try" — đó là **Trp** (tryptophan).
- Trình tự chất P trong giáo trình ghi vị trí 5–6 là **Glu-Glu**; trình tự chuẩn là **Gln-Gln** (glutamin), và đầu C là Met **amid hóa** (–NH~2~). Khi thi, nhớ con số **11 acid amin, đầu N là Arg, đầu C là Met**.

> [!vi-du] Mẹo nhớ peptid opioid
> **Enkephalin = 5 aa đầu của β-endorphin**: cả hai đều mở đầu bằng **Tyr-Gly-Gly-Phe-Met**. Đoạn "Tyr-Gly-Gly-Phe" chính là phần gắn vào thụ thể opiat. Met-enkephalin có đúng trình tự đó; Leu-enkephalin thay Met bằng Leu.

> [!ung-dung] Thuốc nhắm vào peptid thần kinh
> - **Naloxon** chẹn thụ thể opiat, đảo ngược ngộ độc morphin, heroin (đồng tử co nhỏ như đầu đinh ghim, thở chậm, hôn mê).
> - **Thuốc ức chế ACE** (captopril, enalapril) ngăn tạo angiotensin II → hạ huyết áp; tác dụng phụ ho khan.
> - **Octreotid** (đồng đẳng somatostatin, bền hơn) dùng chữa to đầu chi, u carcinoid, chảy máu do giãn tĩnh mạch thực quản.
> - Capsaicin (Ớt) bôi tại chỗ làm cạn chất P ở đầu dây thần kinh cảm giác, giảm đau thần kinh tại chỗ *(bổ sung)*.

**Vận chuyển peptid xuống đầu tận cùng.** Vì được tạo ở thân tế bào, peptid thần kinh phải **theo sợi trục** đi xuống vùng tiền synap (Giáo trình tr. 339):

| | Tốc độ |
|---|---|
| Vận chuyển **nhanh** | khoảng **400 mm/ngày** |
| Vận chuyển **chậm** | khoảng **1–5 mm/ngày** |

Sợi trục dài từ **1 mm đến 1 m**, nên thời gian đưa một peptid xuống đầu tận cùng thay đổi rất rộng (giáo trình ghi từ 150 mili giây đến 200 ngày). Đây là lý do neuron dùng peptid thần kinh **không thể** "bổ sung tại chỗ" nhanh như với chất dẫn truyền phân tử nhỏ.

## Tóm tắt

| Chủ đề | Điểm cốt lõi |
|---|---|
| Năng lượng não | 2% khối lượng, 20–35% oxy; 3,3 mL O~2~/100 g/phút; glucose ≈ 103 g/ngày (0,3 µmol/phút/g); ATP 20,4 mol/ngày; chu trình acid citric gần tối đa, đường phân ≈ 20%; thiếu oxy > 6 phút → không hồi phục |
| Khi đói lâu | Não dùng thêm **thể ceton** (bổ sung); không dùng acid béo trực tiếp |
| Lipid, protein | Lipid đổi mới chậm (20%/tuần ở não so với 50%/24 giờ ở gan); protein não quay vòng tương đối nhanh |
| Tế bào đệm, hàng rào máu–não | 5 loại tế bào đệm; tế bào hình sao + nội mô → chất tan trong nước cần chất vận chuyển riêng |
| Điện thế màng | ≈ −70 mV; bơm Na^+^–K^+^ (antiport) dùng ATP; khử cực tới ngưỡng → kênh Na^+^ mở; lan một chiều, không giảm biên độ |
| Synap | Điện (nhanh) và hóa học (linh hoạt; thụ thể kiểu kênh hoặc qua chất thông tin thứ hai) |
| Giải phóng | Ca^2+^ vào → CaM-kinase phosphoryl hóa **synapsin I** → túi hòa màng (xuất bào); khe ≈ 20 nm |
| Kết thúc | Chuyển hóa, tái hấp thu, khuếch tán |
| Kích thích / ức chế | Ức chế: **GABA** (não), **glycin** (tủy sống, thân não), taurin — mở kênh **Cl^−^** → tăng phân cực. Strychnin chặn thụ thể glycin; benzodiazepin, barbiturat tăng tác dụng GABA |
| Acetylcholin | Acetyl-CoA (PDH, ty thể) + cholin → ACh (**cholin acetyltransferase**, bào tương); **AChE** → acetat (vào máu) + cholin (tái dùng) |
| Catecholamin | Từ phenylalanin (hs-14); kết thúc: **COMT** (SAM), **MAO**, **tái hấp thu**; cocain chặn chất vận chuyển dopamin |
| Serotonin | Tryptophan → 5-hydroxytryptophan (hydroxylase, BH~4~) → serotonin (decarboxylase); MAO + aldehyd dehydrogenase → **5-HIAA** |
| GABA | α-cetoglutarat → glutamat → **GABA** (glutamat decarboxylase, PLP) → succinat semialdehyd → **succinat** (vào chu trình acid citric); chu trình glutamat–glutamin với tế bào hình sao |
| Peptid thần kinh | Tạo ở thân tế bào từ tiền chất; chất P 11 aa; β-endorphin 31 aa (đoạn 61–91 của β-LPH 91 aa); enkephalin 5 aa; somatostatin 14 aa (S–S Cys3–Cys14); angiotensin I 10, II 8 aa; vận chuyển 400 mm/ngày (nhanh) hoặc 1–5 mm/ngày (chậm) |
