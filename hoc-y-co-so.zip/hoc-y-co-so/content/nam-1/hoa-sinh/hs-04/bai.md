---
title: Hóa học acid nucleic
thoi-gian: 40 phút
muc-tieu:
- Trình bày được thành phần hóa học của acid nucleic, gọi đúng tên nucleosid và nucleotid, nêu được các liên kết N-glycosid, phosphoester và 3',5'-phosphodiester.
- Kể được các nucleotid tự do quan trọng (ATP, cAMP, NAD^+^, FAD, CoA…) và vai trò của chúng.
- Mô tả được cấu trúc xoắn kép B-DNA của Watson–Crick, phân biệt được các dạng A-DNA và Z-DNA; nêu được các lực làm bền cấu trúc acid nucleic và cấu trúc siêu xoắn.
- Giải thích được sự biến tính – hồi tính của DNA, nhiệt độ nóng chảy Tm, hiện tượng tăng hấp thụ tử ngoại và nguyên lý lai hóa.
- Trình bày được cấu trúc và chức năng của các loại RNA: tRNA, rRNA, mRNA, snRNA.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. **Nucleosid** = base + pentose (nối bằng liên kết **β-N-glycosid** ở C1'); **nucleotid** = nucleosid + phosphat (nối bằng liên kết **phosphoester**, thường ở C5').
> 2. Acid nucleic là chuỗi nucleotid nối bằng cầu **3',5'-phosphodiester**; ở pH sinh lý là **polyanion**. RNA (ARN) có **2'-OH** nên **bị kiềm thủy phân**, DNA (ADN) thì bền.
> 3. Nhiều nucleotid **tự do** có vai trò lớn: **ATP** (năng lượng), **cAMP** (chất truyền tin thứ hai), **NAD^+^, FAD, CoA** (coenzym chứa phần ADP).
> 4. **B-DNA**: xoắn phải, ~20 Å, 10 cặp base/vòng, bước 34 Å. **A-DNA** rộng, dẹt (11 cặp base); **Z-DNA** xoắn **trái** (12 cặp base). Độ bền chủ yếu nhờ **xếp chồng base (kỵ nước)** và cation; liên kết hydro quyết định **tính đặc hiệu bắt cặp**.
> 5. Đun nóng → DNA **biến tính** (tách mạch, độ nhớt giảm, **A~260~ tăng ~40%**); điểm giữa đường cong là **Tm**, tăng theo **% G–C** và nồng độ cation. Hạ về ~25 °C dưới Tm → **hồi tính**, là cơ sở của **lai hóa**. RNA: **rRNA ~80%, tRNA ~15%, mRNA ~5%**, cùng snRNA U1, U2, U4, U5, U6.

Nucleotid không chỉ là "viên gạch" của DNA và RNA. Theo giáo trình (tr. 55), chúng còn là kho dự trữ và vận chuyển **năng lượng**, là **tín hiệu hóa học** giúp tế bào đáp ứng với hormon, và là thành phần cấu tạo của nhiều **coenzym**. Bài này nhìn acid nucleic từ góc độ **hóa học – hóa sinh**: các liên kết, tính chất lý hóa, các lực giữ cấu trúc.

> [!bay] Đọc kèm bài khác, không học lại
> - Cấu tạo vòng của **base purin (A, G)** và **pyrimidin (C, T, U)**, cách đánh số nguyên tử: xem bài **Hợp chất dị vòng** (Hóa học, hc-11).
> - Ribose, deoxyribose và liên kết glycosid nói chung: bài **Glucid** (hc-08b).
> - Quy luật Chargaff, các thí nghiệm chứng minh vật chất di truyền, tái bản, phiên mã, mã di truyền: bài **Cơ sở phân tử của hiện tượng di truyền** (Sinh học, sh-09). Bài Sinh học viết **ADN, ARN**; giáo trình Hóa sinh viết **DNA, RNA** — cùng một chất.

## 1. Thành phần hóa học của acid nucleic

### 1.1. Ba thành phần: base, pentose, phosphat

Cấu trúc hóa học của acid nucleic được làm sáng tỏ nhờ công trình của **Levene** (giáo trình ghi "Phoebus Levine") và **Alexander Todd** (tr. 55). Thủy phân hoàn toàn một acid nucleic thu được ba loại chất:

| Thành phần | DNA | RNA |
|---|---|---|
| **Base nitơ** | A, G (purin); C, **T** (pyrimidin) | A, G (purin); C, **U** (pyrimidin) |
| **Pentose** | **2-deoxy-D-ribose** | **D-ribose** |
| **Acid phosphoric** | Có | Có |

Để khỏi nhầm số của đường với số của base, các carbon của pentose được đánh số **có dấu phẩy**: 1', 2', 3', 4', 5'. "2-deoxy" nghĩa là ở **C2'** chỉ còn H, mất nhóm –OH.

### 1.2. Nucleosid — liên kết N-glycosid

**Nucleosid** = base + pentose, **chưa có** phosphat. Carbon anomer **C1'** của đường nối với một nguyên tử N của base:

- base **purin** nối qua **N9**;
- base **pyrimidin** nối qua **N1**.

Liên kết C1'–N này gọi là **liên kết N-glycosid** (giáo trình: *liên kết glycosidic*). Trong acid nucleic nó luôn có cấu hình **β**: base nằm cùng phía với nhóm CH~2~OH (C5') của đường.

*Vì sao gọi là "glycosid"?* Đây chính là phản ứng tạo glycosid ở bài Glucid: –OH hemiacetal ở C1' của đường bị thay thế. Điểm khác là aglycon ở đây gắn qua **N** thay vì qua O.

### 1.3. Nucleotid — liên kết phosphoester

**Nucleotid** là **ester phosphat của nucleosid** (tr. 58). Acid phosphoric tạo liên kết **phosphoester** với một nhóm –OH của pentose:

- gắn ở **C5'** → **5'-nucleotid** (dạng gặp nhiều nhất, ví dụ AMP = adenosin 5'-monophosphat);
- gắn ở **C3'** → **3'-nucleotid**.

Gốc phosphat có thể gắn thêm phosphat thứ hai, thứ ba thành **nucleosid di- và triphosphat** (ADP, ATP). Các phosphat ký hiệu **α, β, γ** tính từ đường ra. Liên kết giữa đường và Pα là **phosphoester**; liên kết giữa các phosphat với nhau là **phosphoanhydrid**.

![Hình 1. Cấu tạo một nucleotid (ATP) và tên các liên kết](nucleotid.svg)

> [!bay]
> - **Nucleosid ≠ nucleotid.** Nucleosid chỉ gồm base + đường, **không** có phosphat; nucleotid **có** phosphat. Adenosin là nucleosid, AMP là nucleotid.
> - Trong ATP, liên kết "giàu năng lượng" là hai liên kết **phosphoanhydrid** (Pα–Pβ và Pβ–Pγ). Liên kết phosphoester đường–Pα **không** thuộc loại này.
> - Base nối với **C1'**, phosphat thường nối với **C5'**, chuỗi được kéo dài qua **C3'-OH**.

### 1.4. Danh pháp

Tóm tắt Bảng 4.1 của giáo trình (tr. 57):

| Base (viết tắt) | Nucleosid (viết tắt) | Nucleotid (5'-monophosphat) |
|---|---|---|
| Adenin (Ade, A) | **Adenosin** (Ado) | Acid adenylic = **AMP** |
| Guanin (Gua, G) | **Guanosin** (Guo) | Acid guanylic = **GMP** |
| Cytosin (Cyt, C) | **Cytidin** (Cyd) | Acid cytidylic = **CMP** |
| Uracil (Ura, U) | **Uridin** (Urd) | Acid uridylic = **UMP** |
| Thymin (Thy, T) | **Deoxythymidin** (dThd, dT) | Acid deoxythymidylic = **dTMP** |

Quy tắc gọi tên:

- Nucleosid của **purin** có đuôi **-osin** (adenosin, guanosin); của **pyrimidin** có đuôi **-idin** (cytidin, uridin, thymidin).
- Nucleotid gọi theo hai cách: "acid + tên base + -ylic" (acid adenylic) hoặc "nucleosid + số phosphat" (adenosin monophosphat).
- Đường là deoxyribose thì thêm tiền tố **deoxy-** hoặc chữ **d**: dAMP, dGMP, dCMP, dTMP; dATP, dGTP, dCTP, dTTP là nguyên liệu tổng hợp DNA.

> [!bay]
> - **Thymin hầu như chỉ có trong DNA**, nên nucleosid của nó luôn đi với deoxyribose. Vì vậy "thymidin" thường được hiểu ngầm là deoxythymidin.
> - Đuôi **-osin** dành cho purin, **-idin** cho pyrimidin. "Adenidin", "cytosin-nucleosid" là các tên sai hay gặp trong đề.

### 1.5. Chuỗi polynucleotid

Các nucleotid nối với nhau bằng **cầu 3',5'-phosphodiester**: một gốc phosphat nối **C3'-OH** của nucleotid này với **C5'-OH** của nucleotid kế tiếp (tr. 55). Vì vậy chuỗi có **hướng**: một đầu **5'** và một đầu **3'**. Trình tự luôn viết từ **5' sang 3'**.

Cách viết tắt trong giáo trình (Hình 4.1, tr. 56): tetranucleotid adenylyl-3',5'-uridylyl-3',5'-cytidylyl-3',5'-guanylyl-3'-phosphat viết gọn là **AUCGp**. Chữ **p đứng bên phải** một chữ cái là phosphat ở **3'**; **p đứng bên trái** (pA…) là phosphat ở **5'**.

Ba tính chất hóa học quan trọng của chuỗi (tr. 56–57):

1. **Polyanion.** Mỗi cầu phosphodiester còn một nhóm –OH acid rất mạnh. Ở pH sinh lý nhóm này phân ly hết, nên acid nucleic là **chuỗi mang điện âm** dày đặc. Hệ quả: DNA gắn chặt với **histon** (giàu Lys, Arg mang điện dương) và chạy về **cực dương** khi điện di.
2. **DNA thường là xoắn kép** với A = T và G = C. **RNA thường là mạch đơn**. Ngoại lệ: RNA của một số virus là mạch kép; DNA của một số virus là mạch đơn, nhưng khi vào tế bào chủ và nhân lên thì tạo dạng xoắn kép.
3. **Base biến đổi.** Một số DNA và RNA, nhất là ở vi sinh vật, chứa **dẫn xuất methyl hóa** của các base. Chúng được tạo ra **sau khi tổng hợp chuỗi**, nhờ enzym đặc hiệu.

**RNA bị thủy phân trong kiềm, DNA thì không** (tr. 57). Ở RNA, nhóm **2'-OH** nằm ngay cạnh cầu phosphodiester. Trong môi trường kiềm nó tấn công phosphat bên cạnh, cắt đứt chuỗi, tạo hỗn hợp **2'- và 3'-nucleotid**. DNA **không có 2'-OH** nên bền trong kiềm. Đó là một lý do DNA, chứ không phải RNA, được chọn làm "kho lưu trữ" thông tin lâu dài.

> [!ung-dung] "Nucleosid thiếu 3'-OH" — nguyên lý của nhiều thuốc kháng virus
> Chuỗi chỉ kéo dài được khi nucleotid cuối còn **3'-OH tự do** để tạo cầu phosphodiester mới. Nhiều thuốc là **nucleosid giả** không có 3'-OH. Khi bị gắn vào chuỗi DNA virus, chúng **chấm dứt chuỗi**:
> - **Zidovudin (AZT)**: thymidin có nhóm –N~3~ thay cho 3'-OH, dùng trị HIV.
> - **Acyclovir**: chỉ có "nửa đường" mạch hở, hoàn toàn không có C3', dùng trị Herpes.
>
> Enzym của virus hoạt hóa hoặc sử dụng các chất này mạnh hơn nhiều so với enzym của người, nhờ đó thuốc có tính chọn lọc.

## 2. Các nucleotid tự do có vai trò sinh học

Giáo trình chỉ nêu vai trò này ở phần mở đầu chương (tr. 55). Các chất cụ thể sẽ gặp lại ở bài **Enzym** (NAD^+^, FAD, hs-05) và **Năng lượng sinh học** (ATP, hs-06). Bảng dưới đây giúp nhận ra rằng chúng đều được "lắp" từ nucleotid.

| Chất | Cấu tạo | Vai trò chính |
|---|---|---|
| **ATP** | Adenosin 5'-triphosphat | "Đồng tiền năng lượng": thủy phân liên kết phosphoanhydrid giải phóng khoảng **30,5 kJ/mol** (7,3 kcal/mol) |
| **GTP, UTP, CTP** | Nucleosid triphosphat khác | GTP: dịch mã, protein G; **UTP** tạo **UDP-glucose** để tổng hợp glycogen; **CTP** tạo CDP-cholin để tổng hợp phospholipid |
| **cAMP** | Adenosin **3',5'-monophosphat vòng**: một phosphat nối **cả C3' lẫn C5'** của cùng một ribose | **Chất truyền tin thứ hai** của nhiều hormon (glucagon, adrenalin): adenylat cyclase tạo cAMP từ ATP; cAMP hoạt hóa protein kinase A; **phosphodiesterase** phân hủy cAMP thành 5'-AMP |
| **cGMP** | Guanosin 3',5'-monophosphat vòng | Truyền tin của NO và một số hormon; gây giãn cơ trơn mạch máu |
| **NAD^+^, NADP^+^** | **Dinucleotid**: nicotinamid–ribose–P–P–ribose–adenin (NADP^+^ có thêm 1 phosphat ở 2'-OH của ribose phía adenosin) | Coenzym của dehydrogenase; nhận 2 điện tử và 1 H^+^ (ion hydrid) ở vòng nicotinamid. Nguồn: **vitamin PP** (B3) |
| **FAD, FMN** | FAD = **riboflavin** (vitamin **B2**) + ADP; FMN = riboflavin phosphat | Coenzym của flavoprotein (ví dụ succinat dehydrogenase), nhận 2 H |
| **Coenzym A (CoA)** | 3'-phospho-ADP + **acid pantothenic** (vitamin **B5**) + β-mercaptoethylamin; đầu cuối là nhóm **–SH** | Mang nhóm acyl dưới dạng **thioester** (acetyl-CoA, acyl-CoA) |
| **SAM** (S-adenosylmethionin) | Adenosin gắn với methionin | Cho nhóm **–CH~3~** trong các phản ứng methyl hóa, kể cả methyl hóa base của DNA, RNA |

*Vì sao rất nhiều coenzym chứa "phần ADP"?* Phần ADP không trực tiếp tham gia phản ứng (phản ứng xảy ra ở nicotinamid, flavin hay nhóm –SH). Nó là một "tay cầm" giúp enzym **nhận ra và giữ** coenzym ở đúng chỗ.

> [!bay]
> - Trong NAD^+^ và FAD, hai nửa nối với nhau bằng liên kết **phosphoanhydrid** (5'–P–P–5'), **không** phải cầu 3',5'-phosphodiester như trong acid nucleic.
> - **cAMP** là cầu **3',5'** trong **cùng một** nucleotid. Đừng nhầm với 2',3'-nucleotid vòng là chất trung gian khi RNA bị kiềm thủy phân.
> - Riboflavin chứa **ribitol** (một polyalcol mạch hở), không phải vòng ribose. Gọi FAD là "dinucleotid" chỉ là cách gọi theo truyền thống.

> [!ung-dung] Nucleotid tự do trong lâm sàng và xét nghiệm
> - **Thuốc tác động lên cAMP/cGMP.** **Theophylin** và **cafein** ức chế phosphodiesterase, làm cAMP tăng; theophylin giãn phế quản. **Sildenafil** ức chế phosphodiesterase type 5 (PDE5), giữ cGMP cao, gây giãn mạch. **Độc tố tả** làm adenylat cyclase ở ruột hoạt động liên tục; cAMP tăng cao kéo Cl^−^ và nước vào lòng ruột, gây **tiêu chảy mất nước ồ ạt**.
> - **NADH hấp thụ ánh sáng ở 340 nm, NAD^+^ thì không.** Nhiều xét nghiệm enzym tự động dựa vào điểm này. Ví dụ: hoạt độ **ALT, AST** được đo bằng tốc độ **giảm độ hấp thụ ở 340 nm** khi NADH bị oxy hóa trong phản ứng ghép cặp. Khoảng tham chiếu thường dùng ở người lớn: ALT, AST khoảng **≤ 40 U/L** (tham khảo, mỗi phòng xét nghiệm có khoảng riêng).

## 3. Deoxyribonucleic acid (DNA)

### 3.1. Cấu trúc xoắn kép Watson–Crick: B-DNA

Năm **1953**, **Watson và Crick** công bố mô hình xoắn kép, mở ra ngành sinh học phân tử hiện đại (tr. 58). DNA và RNA có thể tồn tại ở **nhiều dạng xoắn kép** khác nhau, tùy **độ ẩm**, loại **cation** và **trình tự base**.

Dạng Watson–Crick gọi là **B-DNA**, được xác định bằng nhiễu xạ tia X khi có **Na^+^** và ở **độ ẩm 92%**. Đặc điểm theo giáo trình:

- Hai chuỗi polynucleotid **ngược chiều** nhau, cùng xoắn quanh một trục theo **quy tắc bàn tay phải** (xoắn phải).
- **Base ở bên trong**, gần trục; **khung đường – phosphat ở bên ngoài**. Mặt phẳng của base gần như **vuông góc** với trục xoắn.
- Base bắt cặp bổ sung bằng liên kết hydro: **G≡C (3 liên kết)**, **A=T (2 liên kết)**. Vì vậy trình tự mạch này **bổ sung** cho trình tự mạch kia.
- Hai mạch xoắn vặn vào nhau nên **không tách rời** được nếu không mở xoắn.

| Thông số B-DNA (tr. 58) | Giá trị |
|---|---|
| Đường kính vòng xoắn | khoảng **20 Å** (2 nm) |
| Số cặp base một vòng xoắn | **10** (lý tưởng) |
| Bước xoắn (độ dài một vòng) | **34 Å** (3,4 nm) |
| Khoảng cách giữa hai cặp base | **3,4 Å** |
| Góc xoay giữa hai cặp base liên tiếp | **36°** (= 360°/10) |
| Số đo lại của **Dickerson và Drew** | **10,1** cặp base/vòng; góc **35,6°** |

> [!bay] Đơn vị Å và nm
> Giáo trình in các số 20, 34, 3,4 **không kèm đơn vị**; đơn vị đúng là **ångström** (1 Å = 0,1 nm). Bài Sinh học (sh-09) dùng nm: 2 nm, 3,4 nm, 0,34 nm. Đây là **cùng một số liệu**. Đề có thể cho đơn vị nm hoặc Å, cần quy đổi trước khi chọn đáp án.

> [!vi-du] Rãnh lớn và rãnh nhỏ
> Hai khung đường – phosphat không cách đều nhau quanh trục. Vì thế bề mặt B-DNA có một **rãnh lớn** (major groove) và một **rãnh nhỏ** (minor groove) chạy xoắn ốc. Tại rãnh lớn, mép của các cặp base lộ ra nhiều nhất. Các **protein điều hòa gen** (yếu tố phiên mã) "đọc" trình tự DNA chủ yếu qua rãnh lớn mà **không cần tách hai mạch**.

### 3.2. Các dạng xoắn khác: A-DNA và Z-DNA

| | **B-DNA** | **A-DNA** | **Z-DNA** |
|---|---|---|---|
| Chiều xoắn | Phải | Phải | **Trái** |
| Cặp base / vòng | 10 (10,1) | **11** | **12** |
| Bước xoắn | 34 Å | **28 Å** | **45 Å** |
| Hình dạng | Chuẩn | **Rộng hơn, dẹt hơn**; cặp base nghiêng **20°** | Mảnh, khung phosphat gấp khúc **zigzag** |
| Gặp ở đâu (giáo trình) | Dạng chủ yếu trong tế bào | **Bào tử vi khuẩn Gram dương**: DNA dạng A **bền với tia tử ngoại**, là cơ chế tự bảo vệ | Chức năng chưa khẳng định; giả thuyết có chuyển đổi **thuận nghịch B ⇌ Z** trong tái tổ hợp gen và điều hòa biểu hiện gen |

*Vì sao một phân tử lại có nhiều dạng?* Khung đường – phosphat khá linh động (xem mục 3.3). Khi **mất nước** (độ ẩm thấp), DNA chuyển sang dạng A. Khi trình tự là các cặp **purin – pyrimidin xen kẽ** (như …GCGCGC…) và nồng độ muối cao, DNA dễ chuyển sang dạng Z.

> [!vi-du] Dạng A không chỉ của DNA
> **RNA mạch kép** (các đoạn kẹp tóc của tRNA, rRNA) và **phân tử lai DNA–RNA** đều có hình dạng giống **A-DNA**. Lý do là nhóm 2'-OH của ribose cản trở dạng B.

> [!bay] Chỉ **Z-DNA** xoắn **trái**. Mẹo nhớ theo số cặp base một vòng: **A – B – Z = 11 – 10 – 12**.

### 3.3. Các lực làm bền cấu trúc acid nucleic

So với protein, DNA có cấu trúc **đơn giản hơn**: chỉ có một số ít dạng **bậc 2**, không có cấu trúc bậc 3, bậc 4 kiểu protein. Lý do: protein có 20 loại acid amin (amino acid) với tính chất rất khác nhau, còn DNA chỉ có 4 base khá giống nhau. Ngược lại, **nhiều RNA có cấu trúc bậc 3** (tr. 59). Các lực tham gia cũng là các lực đã gặp ở protein, nhưng phối hợp theo cách riêng:

1. **Khung đường – phosphat.** Mỗi nucleotid có **6 góc xoay** trên khung và **1 góc xoay** quanh liên kết glycosid (hướng của base), tổng cộng **7 góc**. Về lý thuyết chuỗi rất linh động, nhưng trên thực tế cấu trúc chuỗi lại **rất bền và ổn định**.
2. **Liên kết hydro giữa các cặp base.** Quyết định **tính đặc hiệu** bắt cặp (A với T, G với C). Theo giáo trình, liên kết hydro **không** phải lực chính làm bền DNA.
3. **Xếp chồng base và tương tác kỵ nước.** Các vòng purin, pyrimidin phẳng có xu hướng **xếp chồng song song** như chồng đĩa, tương tác với nhau và tránh nước. Đây là lực **quyết định** độ bền của DNA, dù cơ chế chi tiết chưa hiểu hết.
4. **Tương tác ion.** Các phosphat cùng mang điện âm **đẩy nhau**. Cation trong dung dịch **che chắn** lực đẩy này, nên **Tm tăng khi nồng độ cation tăng**. **Mg^2+^** đặc biệt quan trọng để giữ cấu trúc của **tRNA, rRNA**.

*Vì sao liên kết hydro lại "không làm bền"?* Khi hai mạch tách ra, các base không mất liên kết hydro mà chuyển sang tạo liên kết hydro **với nước**. Năng lượng gần như "hòa vốn". Ngược lại, khi tách mạch, các base mất **xếp chồng** và phải phơi mặt kỵ nước ra nước — đó mới là phần năng lượng lớn bị mất.

### 3.4. Cấu trúc siêu xoắn

DNA của **mọi vi khuẩn**, **đa số virus**, và DNA **ty thể** (có ở hầu hết tế bào bậc cao) là phân tử **vòng**: hai đầu mỗi mạch nối với nhau thành vòng kín (tr. 60). Nhiều DNA vòng còn **xoắn thêm một lần nữa** quanh chính nó, gọi là **siêu xoắn** (siêu cuộn), đôi khi được coi là **cấu trúc bậc 3** của DNA.

Mức siêu xoắn được điều hòa bởi enzym **topoisomerase**, gồm hai nhóm:

- **Topoisomerase I**: cắt **một mạch**, cho mạch xoay rồi nối lại.
- **Topoisomerase II**: cắt **cả hai mạch**, cho một đoạn DNA khác luồn qua rồi nối lại (cần ATP). Ở vi khuẩn, enzym này gọi là **gyrase**.

Các thuốc ức chế topoisomerase (quinolon, camptothecin, etoposid) đã được trình bày ở bài sh-09.

### 3.5. Biến tính thuận nghịch

**Biến tính.** Đun dung dịch DNA quá một nhiệt độ nhất định, liên kết hydro và xếp chồng bị phá vỡ; **hai mạch tách rời** và cuộn lại một cách ngẫu nhiên (tr. 60). Tính chất vật lý của dung dịch thay đổi rõ:

- **Độ nhớt giảm** mạnh: sợi xoắn kép dài, cứng biến thành các cuộn mạch đơn mềm.
- **Độ hấp thụ tử ngoại tăng** khoảng **40%** (hiệu ứng **tăng sắc**, hyperchromic).

**Liên kết cộng hóa trị không bị phá vỡ**: trình tự base vẫn còn nguyên. Vì thế biến tính DNA có thể **thuận nghịch**.

> [!vi-du] Vì sao đo ở 260 nm và vì sao độ hấp thụ tăng?
> Vòng thơm của base purin, pyrimidin hấp thụ mạnh tia tử ngoại, cực đại khoảng **260 nm** (giáo trình chỉ ghi "vùng tử ngoại"). Khi các base **xếp chồng** sát nhau trong xoắn kép, chúng "che" lẫn nhau nên hấp thụ **ít hơn** (giảm sắc). Tách mạch thì base hết xếp chồng và hấp thụ trở lại đầy đủ. Theo dõi A~260~ khi tăng nhiệt độ là cách đơn giản nhất để "thấy" DNA tách mạch.

**Nhiệt độ nóng chảy Tm.** Vẽ A~260~ theo nhiệt độ được **đường cong nóng chảy** hình chữ S. **Điểm uốn** của đường cong, nơi một nửa DNA đã tách mạch, gọi là **nhiệt độ nóng chảy Tm**.

![Hình 2. Đường cong nóng chảy của DNA](tm.svg)

Tm phụ thuộc:

- **Nồng độ ion** (cation càng nhiều, Tm càng cao);
- **pH** (pH quá kiềm hoặc quá acid làm DNA biến tính ở nhiệt độ thấp hơn);
- **Tỷ lệ G và C**: DNA càng giàu G–C, **Tm càng cao**. Giáo trình giải thích: cặp G≡C có 3 liên kết hydro, bền hơn cặp A=T chỉ có 2.

> [!cap-nhat] Vì sao DNA giàu G–C bền hơn?
> Giáo trình (tr. 60) giải thích bằng số liên kết hydro (3 so với 2). Hiện nay các đo đạc nhiệt động học cho thấy phần đóng góp lớn hơn đến từ **lực xếp chồng**: các cặp G–C xếp chồng với nhau **mạnh hơn** các cặp A–T. Điều này cũng khớp với ý của chính giáo trình ở tr. 59 rằng xếp chồng mới là lực chính làm bền DNA. Đi thi, trả lời theo giáo trình (3 liên kết hydro); hiểu sâu thì nêu thêm vai trò xếp chồng.

**Hồi tính và lai hóa.** Theo giáo trình, nếu hạ nhiệt nhanh rồi **giữ ở khoảng 25 °C dưới Tm** một thời gian, các mạch đơn tìm lại mạch bổ sung và tạo lại **xoắn kép như ban đầu** (hồi tính). Không hạ xuống quá thấp, vì khi đó các mạch đơn tự gập lại hoặc bắt cặp sai chỗ và bị "khóa" luôn ở trạng thái đó. Sự bắt cặp bổ sung giữa hai mạch có nguồn gốc khác nhau (DNA với DNA, hoặc **DNA với RNA**) gọi là **lai hóa** (hybridization).

> [!ung-dung] Ứng dụng của A~260~, Tm và lai hóa
> - **Định lượng acid nucleic** trong phòng xét nghiệm sinh học phân tử: A~260~ = 1 tương ứng khoảng **50 µg/mL DNA mạch kép** và khoảng **40 µg/mL RNA**. Tỷ số **A~260~/A~280~ ≈ 1,8** (DNA) hoặc **≈ 2,0** (RNA) cho thấy mẫu sạch. Tỷ số thấp hơn gợi ý mẫu còn **lẫn protein**, vì protein hấp thụ mạnh ở 280 nm.
> - **Mẫu dò (probe)** là đoạn acid nucleic có đánh dấu, lai hóa với trình tự đích. Đây là nguyên lý của Southern blot (DNA), Northern blot (RNA), lai tại chỗ huỳnh quang (FISH) phát hiện bất thường nhiễm sắc thể, và của **PCR** (biến tính – gắn mồi – kéo dài; xem sh-09).
> - Tia tử ngoại diệt khuẩn (khoảng 254 nm) hiệu quả vì DNA hấp thụ mạnh vùng này và bị tổn thương (dimer thymin, xem bài Đột biến, sh-10).

> [!vi-du] Ước tính Tm của một đoạn mồi PCR ngắn
> Với oligonucleotid ngắn (khoảng dưới 20 base), người ta hay dùng công thức kinh nghiệm **Tm ≈ 2 × (A + T) + 4 × (G + C)** (°C). Ví dụ đoạn 5'-AGCTTGCAGGCATCGA-3' có 7 A+T và 9 G+C: Tm ≈ 2×7 + 4×9 = **50 °C**. Mỗi cặp G–C "đáng giá" gấp đôi cặp A–T, đúng như xu hướng nêu trên.

## 4. Ribonucleic acid (RNA)

### 4.1. Cấu trúc RNA

Giống DNA, các nucleotid trong RNA nối nhau bằng **cầu 3',5'-phosphodiester** (tr. 60). RNA là **chuỗi đơn**, nhưng:

- **Cấu trúc bậc 2**: những đoạn có trình tự bổ sung trên cùng một phân tử gập lại, **bắt cặp thành đoạn xoắn kép** (kiểu kẹp tóc).
- **Cấu trúc bậc 3**: nhờ nhiều liên kết hydro khác, phân tử tiếp tục gấp thành khối không gian (ví dụ tRNA hình chữ L).

So sánh DNA và RNA (Câu hỏi ôn tập 1 của giáo trình):

| | DNA | RNA |
|---|---|---|
| Pentose | 2-deoxyribose (không có 2'-OH) | Ribose (có 2'-OH) |
| Base pyrimidin | C, **T** | C, **U** |
| Số mạch | Thường **2 mạch**, xoắn kép (một số virus: mạch đơn) | Thường **1 mạch**, có đoạn tự bắt cặp (một số virus: mạch kép) |
| Bậc cấu trúc | Bậc 2 (B, A, Z); siêu xoắn ở DNA vòng | Bậc 2 và **bậc 3** phong phú |
| Trong kiềm | **Bền** | **Bị thủy phân** thành 2'- và 3'-nucleotid |
| Chức năng | Lưu trữ thông tin di truyền | Truyền đạt và thực hiện thông tin (mRNA, tRNA, rRNA, snRNA) |

### 4.2. Các loại RNA

| Loại | Tỷ lệ RNA tế bào (giáo trình) | Kích thước | Chức năng |
|---|---|---|---|
| **rRNA** (RNA ribosom) | **~80%** | Nhiều loại, từ 120 đến 4700 nucleotid | Thành phần cấu trúc của ribosom |
| **tRNA** (RNA vận chuyển) | **~15%** | **65–110** ribonucleotid | Vận chuyển acid amin, nhận biết mã trên mRNA |
| **mRNA** (RNA thông tin) | **~5%** | Rất thay đổi | Mang thông tin di truyền từ nhân ra ribosom |
| **snRNA** (RNA nhỏ của nhân) | Ít | Nhỏ | **U1, U2, U4, U5, U6**: cắt bỏ intron khi hoàn thiện mRNA |

#### a) tRNA

tRNA có cấu trúc chung hình **lá chẻ ba** (cỏ ba lá) với nhiều vùng chức năng. Hai vùng quan trọng nhất (tr. 61):

- **Đầu 3' mang bộ ba CCA-OH**, không tham gia xoắn kép. Acid amin được gắn vào nhóm –OH ở đầu này.
- **Bộ ba đối mã** (anticodon), bắt cặp bổ sung với mã trên mRNA.

Từ đó tRNA có **hai chức năng**: (1) mang acid amin ở dạng **đã hoạt hóa** (dễ tạo liên kết peptid) đến nơi tổng hợp protein; (2) **nhận biết mã** trên mRNA. Mỗi tRNA chỉ chở **một** loại acid amin, nhưng một acid amin có thể có **hai hay nhiều** tRNA.

#### b) rRNA

| Tế bào | Các loại rRNA (theo giáo trình) | Thuộc tiểu đơn vị ribosom (bổ sung) |
|---|---|---|
| **Không nhân** (vi khuẩn) | **5S** (120 nucleotid), **16S** (1540), **23S** (3200) | 16S → tiểu đơn vị nhỏ 30S; 23S + 5S → tiểu đơn vị lớn 50S |
| **Có nhân** | **5S**, **5,8S** (160), **18S** (1900), **28S** (4700) | 18S → tiểu đơn vị nhỏ 40S; 28S + 5,8S + 5S → tiểu đơn vị lớn 60S |
| **Ty thể** tế bào động vật | **12S** và **16S** | Ribosom ty thể giống ribosom vi khuẩn |

> [!cap-nhat] Kích thước rRNA
> Giáo trình ghi rRNA 23S có 3200 nucleotid và 28S có 4700 nucleotid. Theo trình tự đã giải hiện nay, rRNA 23S của *E. coli* dài khoảng **2900** nucleotid; rRNA 28S của người khoảng **5000** nucleotid. Các số khác (5S 120, 16S ~1540, 5,8S ~160, 18S ~1900) khớp với giáo trình. Đi thi trả lời theo giáo trình.

Kháng sinh nhắm vào rRNA vi khuẩn (aminoglycosid, tetracyclin, macrolid…): xem sh-09.

#### c) mRNA

mRNA trực tiếp mang thông tin di truyền từ nhân ra **ribosom ở bào tương**. mRNA của tế bào có nhân có cấu trúc lần lượt từ đầu 5' (tr. 61):

![Hình 3. Cấu trúc mRNA thuần thục ở tế bào có nhân](mrna.svg)

1. **Mũ** (cap): **7-methylguanosin 5'-triphosphat**;
2. một **đoạn không dịch mã** (không mã hóa acid amin);
3. **vùng mã hóa**, mở đầu bằng bộ ba **AUG**, kết thúc bằng một trong ba bộ ba **UAA, UAG, UGA**;
4. **đoạn không dịch mã thứ hai**;
5. **đuôi poly A** gồm khoảng **20–200** gốc adenosin monophosphat.

> [!bay] Số liệu khác nhau giữa hai giáo trình
> | | Hóa sinh (bài này) | Sinh học (sh-09) |
> |---|---|---|
> | Tỷ lệ tRNA | ~15% | 10–15% |
> | Độ dài tRNA | 65–110 nucleotid | ~75 nucleotid |
> | Tỷ lệ mRNA | ~5% | 5–10% |
> | Đuôi poly A | 20–200 A | 100–200 A |
>
> Các số này đều là khoảng gần đúng. Đuôi poly A mới gắn dài khoảng 200 A rồi **ngắn dần** theo "tuổi" của mRNA, nên các sách ghi khác nhau. Thi môn nào, dùng số của giáo trình môn đó.

> [!ung-dung] Vaccin mRNA
> Vaccin mRNA (ví dụ vaccin COVID-19) là một mRNA tổng hợp có đủ các phần ở Hình 3: **mũ 5'**, đoạn không dịch mã, vùng mã hóa kháng nguyên, đuôi **poly A**. Trong chuỗi, uridin được thay bằng một **nucleosid biến đổi** (N1-methylpseudouridin). Biến đổi này giúp mRNA **ít bị hệ miễn dịch bẩm sinh nhận diện** và được dịch mã nhiều hơn. Phát hiện này được trao giải **Nobel Y học 2023** (Karikó và Weissman). mRNA rất dễ bị phân hủy (RNA kém bền, xem mục 1.5), nên vaccin được bọc trong **hạt nano lipid** và cần bảo quản lạnh.

#### d) snRNA

Có **5 loại snRNA** nhiều trong nhân: **U1, U2, U4, U5, U6**. Chúng tham gia **cắt bỏ intron** khi hoàn thiện mRNA. Cơ chế cắt nối (thể nối, "thòng lọng") xem sh-09.

> [!yhct] Đông trùng hạ thảo và cordycepin — một "nucleosid thiếu 3'-OH" từ tự nhiên
> - Đông trùng hạ thảo (*Cordyceps sinensis*, nay xếp là *Ophiocordyceps sinensis*) và loài nuôi trồng phổ biến *Cordyceps militaris* chứa **adenosin** và **cordycepin**. Cordycepin chính là **3'-deoxyadenosin**: giống adenosin nhưng **thiếu nhóm 3'-OH**.
> - Theo mục 1.5, một nucleotid thiếu 3'-OH khi được gắn vào chuỗi RNA sẽ **chấm dứt chuỗi**. Thí nghiệm **trong ống nghiệm và trên tế bào** cho thấy cordycepin ức chế tổng hợp RNA, đặc biệt là gắn đuôi poly A. Đây là cơ sở của các nghiên cứu về tác dụng chống u, kháng viêm của nó.
> - **Mức bằng chứng:** chủ yếu **in vitro và trên động vật**; chưa có thử nghiệm lâm sàng đủ mạnh chứng minh tác dụng chữa bệnh ở người. Trong cơ thể, cordycepin còn bị enzym **adenosin deaminase** phân hủy nhanh. Công dụng "bổ phế thận" theo YHCT là quan niệm truyền thống, **không** suy ra trực tiếp từ cơ chế hóa học trên.
> - Hàm lượng adenosin, cordycepin được dùng làm chỉ tiêu **kiểm nghiệm chất lượng**, giúp phát hiện hàng giả, hàng kém chất lượng (thị trường có nhiều sản phẩm trộn hoặc làm giả).

## Tóm tắt

| Chủ đề | Điều cần nhớ |
|---|---|
| Thành phần | Base (A, G, C, T/U) + pentose (deoxyribose/ribose) + phosphat |
| Liên kết | Base–C1': **β-N-glycosid** (N9 purin, N1 pyrimidin); C5'–phosphat: **phosphoester**; giữa các phosphat: **phosphoanhydrid**; giữa các nucleotid: **3',5'-phosphodiester** |
| Danh pháp | Purin → **-osin** (adenosin, guanosin); pyrimidin → **-idin** (cytidin, uridin, deoxythymidin); AMP = acid adenylic; d = deoxy |
| Chuỗi | Hướng 5'→3'; polyanion ở pH sinh lý; RNA (2'-OH) bị kiềm thủy phân, DNA bền |
| Nucleotid tự do | ATP (năng lượng, ~30,5 kJ/mol); cAMP, cGMP (truyền tin thứ hai); NAD^+^ (B3), FAD (B2), CoA (B5) đều chứa phần ADP; SAM cho nhóm methyl |
| B-DNA | Xoắn phải, 2 mạch ngược chiều; ~20 Å; 10 cặp base/vòng; bước 34 Å; 3,4 Å; 36° (Dickerson: 10,1; 35,6°); Na^+^, độ ẩm 92% |
| A, Z | A: phải, 11 bp, 28 Å, nghiêng 20°, bào tử Gram dương, chống UV. Z: **trái**, 12 bp, 45 Å |
| Lực làm bền | Khung 7 góc xoay; liên kết hydro → **đặc hiệu**; xếp chồng/kỵ nước → **bền**; cation che lực đẩy phosphat; Mg^2+^ cho tRNA, rRNA |
| Siêu xoắn | DNA vòng (vi khuẩn, đa số virus, ty thể); topoisomerase I, II |
| Biến tính | Nhiệt → tách mạch, **độ nhớt giảm**, **A~260~ tăng ~40%**; Tm = điểm uốn, tăng theo cation và G–C; hồi tính ở ~Tm − 25 °C; lai hóa DNA–DNA, DNA–RNA |
| RNA | rRNA ~80% (vi khuẩn 5S, 16S, 23S; có nhân 5S, 5,8S, 18S, 28S; ty thể 12S, 16S); tRNA ~15%, 65–110 nt, lá chẻ ba, CCA-OH, đối mã; mRNA ~5%, mũ m⁷G – 5'UTR – AUG…stop – 3'UTR – poly A 20–200; snRNA U1, U2, U4, U5, U6 |
