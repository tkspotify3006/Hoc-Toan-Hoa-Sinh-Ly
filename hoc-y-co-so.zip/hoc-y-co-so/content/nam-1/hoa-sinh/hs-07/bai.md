---
title: Chuyển hóa glucid
thoi-gian: 75 phút
muc-tieu:
- Trình bày được đường phân (10 phản ứng, enzym, nơi xảy ra, năng lượng) và số phận của pyruvat khi thiếu oxy (thành lactat) và khi đủ oxy (thành CO~2~, H~2~O).
- Trình bày được con đường pentose phosphat (hexose monophosphat): các phản ứng giai đoạn 1 và ý nghĩa (NADPH, ribose-5-phosphat).
- Trình bày được cách fructose, galactose, mannose nhập vào đường phân.
- Trình bày được tân tạo glucose: nguyên liệu, ba "đường vòng" qua các bước không thuận nghịch, chu trình Cori và chu trình glucose–alanin, các điểm điều hòa.
- Trình bày được quá trình thoái hóa và tổng hợp glycogen, sự khác nhau giữa gan và cơ, và cơ chế điều hòa bằng hormon.
- Giải thích được cơ sở hóa sinh của hạ đường huyết, thiếu vitamin B~1~, bệnh ứ glycogen, galactose máu, không dung nạp fructose, đái tháo đường và thiếu G6PD.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. **Đường phân** (bào tương, 10 phản ứng): glucose → **2 pyruvat**, lời **2 ATP** + 2 NADH. Ba bước không thuận nghịch: **hexokinase, phosphofructokinase-1 (PFK-1), pyruvat kinase**; PFK-1 là "van" chính.
> 2. Thiếu O~2~: pyruvat → **lactat** (LDH), chỉ được 2 ATP. Đủ O~2~: pyruvat → acetyl-CoA → Krebs → chuỗi hô hấp: **38 ATP** theo giáo trình (≈ 30–32 theo số liệu hiện nay).
> 3. **Con đường pentose phosphat** không tạo ATP mà tạo **NADPH** (tổng hợp lipid, giữ glutathion ở dạng khử trong hồng cầu, enzym đầu là **G6PD**) và **ribose-5-phosphat** (tổng hợp nucleotid).
> 4. **Tân tạo glucose** (chủ yếu ở gan) đi ngược đường phân nhưng **đi vòng** qua 3 bước không thuận nghịch nhờ 4 enzym riêng: **pyruvat carboxylase, PEPCK, fructose-1,6-diphosphatase, glucose-6-phosphatase**.
> 5. **Glycogen**: tổng hợp qua **UDP-glucose** (glycogen synthase, insulin bật); thoái hóa nhờ **phosphorylase** (glucagon, adrenalin bật qua cAMP). Gan có glucose-6-phosphatase nên trả glucose vào máu, cơ thì không.

Glucid cung cấp phần lớn năng lượng cho cơ thể. Theo giáo trình, glucid chiếm khoảng **50–55%** năng lượng khẩu phần; **1 g glucid cho 4 kcal** (Giáo trình tr. 102). Cấu tạo của glucose, fructose, glycogen… đã học ở bài **Glucid** (hoa-hoc/hc-08b). Bài này đi theo góc nhìn hóa sinh: glucose được **đốt**, được **dựng lại**, được **cất vào kho** ra sao, ai **điều khiển**, và khi hỏng thì **bệnh gì**.

Vì sao glucose đặc biệt? Đây là chất **duy nhất** có thể cho ATP **khi không có oxy**. Điều này sống còn với các tế bào phụ thuộc glucose như **hồng cầu** (không có ty thể). Não cũng dùng glucose là chính. Ngoài vai trò năng lượng, glucid còn tham gia dựng glycolipid, glycoprotein, và qua **ribose-5-phosphat** tham gia tổng hợp acid nucleic.

## 1. Thoái hóa glucose

### 1.1. Đường phân (glycolysis)

Đường phân là chuỗi **10 phản ứng** biến 1 glucose (6C) thành **2 pyruvat** (3C). Toàn bộ diễn ra trong **bào tương** và **không cần O~2~**. Có thể chia làm hai giai đoạn (Giáo trình tr. 102–103):

- **Giai đoạn 1 – "đầu tư"** (phản ứng 1–5): gắn 2 nhóm phosphat vào glucose, rồi chặt đôi thành 2 triose phosphat. Tiêu **2 ATP** (ở phản ứng **1 và 3**).
- **Giai đoạn 2 – "thu hoạch"** (phản ứng 6–10): mỗi triose được oxy hóa thành pyruvat. Tạo **4 ATP** (ở phản ứng **7 và 10**, mỗi phản ứng xảy ra 2 lần vì có 2 triose) và **2 NADH**.

![Hình 1. Đường phân, giai đoạn 1 (phản ứng 1–5). Mũi tên màu cam: bước không thuận nghịch, cũng là điểm điều hòa](duong-phan-1.svg)

![Hình 2. Đường phân, giai đoạn 2 (phản ứng 6–10, xảy ra 2 lần cho mỗi glucose) và hai số phận của pyruvat](duong-phan-2.svg)

| Bước | Phản ứng | Enzym | Ghi chú |
|---|---|---|---|
| **1** | Glucose + ATP → **glucose-6-phosphat** (G6P) + ADP | **Hexokinase** (ở gan còn có **glucokinase**) | Cần Mg^2+^. **Không thuận nghịch.** Tiêu ATP thứ nhất |
| 2 | G6P ⇌ **fructose-6-phosphat** (F6P) | Phosphoglucose isomerase (PGI) | Đồng phân hóa aldose → cetose |
| **3** | F6P + ATP → **fructose-1,6-diphosphat** (F1,6DP) + ADP | **Phosphofructokinase-1** (PFK-1) | Cần Mg^2+^. **Không thuận nghịch.** Tiêu ATP thứ hai. Điểm điều hòa **quan trọng nhất** |
| 4 | F1,6DP ⇌ **glyceraldehyd-3-phosphat** (GAP) + **dihydroxyaceton phosphat** (DHAP) | Aldolase | Chặt 6C thành 2 × 3C |
| 5 | DHAP ⇌ GAP | Triose phosphat isomerase (TPI) | Chỉ GAP đi tiếp được; DHAP phải đổi thành GAP |
| 6 | GAP + NAD^+^ + P~i~ ⇌ **1,3-diphosphoglycerat** (1,3-DPG) + NADH + H^+^ | **Glyceraldehyd-3-phosphat dehydrogenase** (GAPDH) | **Bước oxy hóa duy nhất**; tạo liên kết acyl phosphat giàu năng lượng |
| 7 | 1,3-DPG + ADP ⇌ **3-phosphoglycerat** (3PG) + ATP | Phosphoglycerat kinase (PGK) | **ATP đầu tiên** (phosphoryl hóa mức cơ chất) |
| 8 | 3PG ⇌ **2-phosphoglycerat** (2PG) | Phosphoglycerat mutase (PGM) | Chuyển phosphat từ C3 sang C2 |
| 9 | 2PG ⇌ **phosphoenolpyruvat** (PEP) + H~2~O | Enolase | Cần Mg^2+^. Khử nước tạo liên kết **enol phosphat** giàu năng lượng |
| **10** | PEP + ADP → **pyruvat** + ATP | **Pyruvat kinase** (PK) | Cần Mg^2+^, K^+^. **Không thuận nghịch.** ATP thứ hai (mức cơ chất) |

Một số "vì sao" ở từng bước (Giáo trình tr. 103–107):

- **Bước 1 – vì sao phải gắn phosphat ngay?** G6P mang điện âm nên **không lọt qua màng** ra ngoài: glucose bị "nhốt" lại trong tế bào. Hexokinase **không đặc hiệu**: phosphoryl hóa được D-glucose, D-mannose, D-fructose; có ở **mọi tế bào**. Gan còn có **glucokinase**, chỉ làm việc mạnh khi **glucose máu cao** (sau bữa ăn).
- **Bước 3** là bước "cam kết": F1,6DP chỉ còn một lối là đi tiếp đường phân. Vì vậy tế bào đặt "van" điều hòa chính ở đây (mục 4).
- **Bước 4 – aldolase**: có 2 loại khác nhau về cơ chế. **Loại 1** ở động vật và thực vật; **loại 2** ở nấm, tảo, vi sinh vật.
- **Bước 6 – GAPDH** dùng nhóm **–SH của cystein** ở trung tâm hoạt động. Theo mô hình 5 bước của Trentham: GAP gắn vào enzym; –SH cộng vào nhóm aldehyd tạo **thiohemiacetal**; thiohemiacetal bị oxy hóa thành **thioester** bằng cách chuyển hydrid (H^−^) sang NAD^+^; một NAD^+^ mới thay chỗ NADH; cuối cùng P~i~ tấn công thioester, giải phóng **1,3-DPG** (một **acyl phosphat**). Ý nghĩa: năng lượng của phản ứng oxy hóa aldehyd **không mất đi** mà được giữ trong liên kết thioester, rồi chuyển vào liên kết acyl phosphat giàu năng lượng.
- **Bước 8 – PGM** có **phospho-histidin** ở trung tâm hoạt động. Enzym trao phosphat cho 3PG tạo chất trung gian **2,3-DPG**, rồi nhận lại phosphat ở C3, nhả ra 2PG. Đôi khi 2,3-DPG rời enzym, để lại enzym ở dạng mất phosphat, không hoạt động.
- **Bước 9 – enolase** chỉ hoạt động khi tạo phức với Mg^2+^. Khử nước làm năng lượng **dồn vào** liên kết phosphat của PEP (chất "năng lượng cao thứ hai" sau 1,3-DPG).

**Hexokinase và glucokinase** (bảng có bổ sung ngoài giáo trình):

| | Hexokinase | Glucokinase |
|---|---|---|
| Có ở | Mọi tế bào | **Gan** (và tế bào β tụy) |
| Đặc hiệu | Không đặc hiệu (glucose, mannose, fructose) | Chủ yếu glucose |
| Ái lực với glucose | **Cao** (K~m~ thấp): làm việc cả khi glucose máu thấp | **Thấp** (K~m~ cao): chỉ làm mạnh khi glucose máu **cao** |
| Bị G6P ức chế | **Có** (Giáo trình tr. 120) | Không |
| Ý nghĩa | Bảo đảm mô (não, hồng cầu) luôn lấy được glucose | Sau bữa ăn, gan "thu gom" glucose dư để làm glycogen |

> [!bay]
> - **Bước tiêu ATP**: 1 và 3. **Bước tạo ATP**: 7 và 10. **Bước tạo NADH**: chỉ bước 6. **Bước không thuận nghịch**: 1, 3, 10.
> - Đường phân **không dùng O~2~** và **không sinh CO~2~**.
> - Giai đoạn 2 xảy ra **2 lần** cho mỗi glucose. Vì vậy tổng tạo 4 ATP, trừ 2 ATP đầu tư, còn **lời 2 ATP**.
> - Tên **fructose-1,6-diphosphat** (giáo trình) nay thường gọi là fructose-1,6-**bis**phosphat, vì hai nhóm phosphat gắn ở hai vị trí khác nhau (không nối với nhau như trong ADP). Tương tự 1,3-DPG = 1,3-**bis**phosphoglycerat.

> [!ung-dung] Ống lấy máu đo đường huyết có chất **natri fluorid**
> Hồng cầu và bạch cầu trong ống máu vẫn tiếp tục đường phân, "ăn" glucose. Nếu để lâu ở nhiệt độ phòng, kết quả đường huyết sẽ **thấp giả**. Ống nắp xám chứa **fluorid**, chất **ức chế enolase** (bước 9), giúp giữ glucose ổn định hơn cho đến khi phân tích. Dù vậy, mẫu vẫn nên được ly tâm và đo sớm.

#### 2,3-DPG và vận chuyển oxy ở hồng cầu

Hồng cầu có một **nhánh phụ** của đường phân (Giáo trình tr. 106):

=> 1,3-DPG → 2,3-DPG (enzym diphosphoglycerat mutase) → 3PG + P~i~ (enzym 2,3-DPG phosphatase)

Nồng độ 2,3-DPG trong hồng cầu khá cao (khoảng **5 mmol/L**). Chất này gắn vào **deoxyhemoglobin** và làm **giảm ái lực của Hb với O~2~**, nhờ đó Hb **nhả O~2~ cho mô dễ hơn**. Như vậy, việc vận chuyển oxy phụ thuộc vào đường phân của hồng cầu.

> [!ung-dung] Thiếu enzym đường phân bẩm sinh ở hồng cầu
> Hồng cầu không có ty thể, nên **chỉ sống nhờ đường phân**. Thiếu enzym đường phân làm hồng cầu thiếu ATP, dễ vỡ, gây **thiếu máu tan máu**.
> - **Thiếu hexokinase**: tắc ở đầu con đường → **ít 2,3-DPG** → Hb **giữ chặt O~2~** hơn (đường cong bão hòa O~2~ lệch **trái**).
> - **Thiếu pyruvat kinase**: tắc ở cuối con đường → các chất phía trên ứ lại, **2,3-DPG tăng** → Hb **nhả O~2~ dễ hơn** (đường cong lệch **phải**). Đây là kiểu bù trừ giúp mô vẫn đủ O~2~ dù thiếu máu.
>
> Thiếu pyruvat kinase là nguyên nhân hay gặp nhất trong nhóm thiếu máu tan máu do thiếu enzym đường phân.

### 1.2. Số phận của pyruvat

Phản ứng 6 dùng NAD^+^. Lượng NAD^+^ trong tế bào có hạn. Muốn đường phân chạy tiếp, NADH phải được **tái oxy hóa** thành NAD^+^. Có hai cách, tùy có đủ O~2~ hay không.

#### a) Khi thiếu oxy: pyruvat → lactat

Khi cơ hoạt động mạnh mà máu đưa O~2~ tới không kịp, **lactat dehydrogenase** (LDH) dùng NADH để khử pyruvat thành **lactat**, trả lại NAD^+^ cho bước 6 (Giáo trình tr. 107). Phản ứng này thường được gọi là **phản ứng 11** của đường phân.

=> Pyruvat + NADH + H^+^ ⇌ Lactat + NAD^+^

**LDH có 5 isozym**, ghép từ 2 loại tiểu đơn vị **H** (heart, tim) và **M** (muscle, cơ): **H~4~, H~3~M, H~2~M~2~, HM~3~, M~4~**.

- Typ **H** chiếm ưu thế ở mô ưa khí như **cơ tim**; có xu hướng oxy hóa **lactat → pyruvat** (để đốt tiếp).
- Typ **M** chiếm ưu thế ở **gan, cơ xương**; có xu hướng xúc tác chiều **pyruvat → lactat**.

**Bilan năng lượng** của glucose → 2 lactat (Giáo trình tr. 108). 2 NADH tạo ra ở bước 6 được dùng hết ở phản ứng LDH, nên không còn NADH dư:

=> Glucose + 2 P~i~ + 2 ADP → 2 Lactat + 2 ATP + 2 H~2~O   (ΔG°' = −196 kJ/mol)

Chỉ **2 ATP** cho mỗi glucose. 2 ATP giữ được khoảng 2 × 30,5 = 61 kJ, tức khoảng **31%** của 196 kJ; phần còn lại tỏa thành nhiệt.

> [!bay] Con số 31%
> Giáo trình viết "cùng với sự tạo thành ATP, 31% năng lượng đã tạo ra ở dạng nhiệt năng". Tính lại thì **31% là phần được giữ lại trong ATP** (61/196), khoảng 69% còn lại mới là nhiệt. Nếu gặp câu hỏi, hãy hiểu đúng bản chất: hiệu suất của đường phân yếm khí khoảng 31%.

> [!ung-dung] Lactat máu và LDH
> - **Lactat máu** (tham khảo, mỗi phòng xét nghiệm có khoảng riêng): khoảng **0,5–2,2 mmol/L**. Lactat tăng khi mô thiếu O~2~ (sốc, suy hô hấp, gắng sức cực độ), khi ty thể hỏng (ngộ độc cyanid, bệnh ty thể), hoặc khi gan kém thanh thải lactat. **Toan lactic** là một cấp cứu.
> - **LDH** có trong hầu hết tế bào. LDH huyết thanh tăng khi có **tan máu** hoặc tổn thương mô (gan, cơ, u…). Trước đây, kiểu isozym LDH~1~ > LDH~2~ từng được dùng để chẩn đoán nhồi máu cơ tim; nay đã được thay bằng **troponin** tim.

#### b) Khi đủ oxy: pyruvat → CO~2~ + H~2~O

Pyruvat vào ty thể, bị **khử carboxyl oxy hóa** thành **acetyl-CoA** nhờ phức hợp **pyruvat dehydrogenase** (PDH, cần TPP, lipoamid, CoA, FAD, NAD^+^). Acetyl-CoA vào **chu trình acid citric** và bị đốt thành CO~2~. Phần này đã học kỹ ở bài **Năng lượng sinh học** (hoa-sinh/hs-06, mục 4).

NADH tạo ra ở bước 6 (trong bào tương) không đi thẳng vào ty thể được. Nó phải chuyển điện tử vào trong qua các **"con thoi"** (shuttle): con thoi **malat–aspartat** (gan, tim) hoặc con thoi **glycerol phosphat** (cơ xương, não).

**Tính ATP cho 1 glucose đốt hoàn toàn** (Giáo trình tr. 108):

| Giai đoạn | Sản phẩm | Theo giáo trình (NADH = 3, FADH~2~ = 2) | Theo số liệu hiện nay (NADH ≈ 2,5, FADH~2~ ≈ 1,5) |
|---|---|---|---|
| Đường phân | 2 ATP (lời) + 2 NADH (bào tương) | 2 + 2 × 3 = **8** | 2 + 5 = 7 (con thoi malat–aspartat) hoặc 2 + 3 = 5 (con thoi glycerol phosphat) |
| 2 pyruvat → 2 acetyl-CoA | 2 NADH | 2 × 3 = **6** | 5 |
| 2 vòng chu trình acid citric | 6 NADH, 2 FADH~2~, 2 GTP | 2 × 12 = **24** | 2 × 10 = 20 |
| **Tổng** | | **38 ATP** | **≈ 32** (hoặc 30) |

> [!cap-nhat] 38 ATP hay 30–32 ATP?
> Giáo trình ghi **38 ATP**; đi thi trả lời theo giáo trình. Hiện nay, dựa trên số H^+^ thực tế được bơm và tiêu tốn, người ta tính mỗi NADH cho khoảng 2,5 ATP và mỗi FADH~2~ khoảng 1,5 ATP, nên tổng là **khoảng 30–32 ATP**. Ngay cả theo cách tính cũ, nếu NADH bào tương vào qua con thoi glycerol phosphat (thành FADH~2~) thì chỉ được 36 ATP. So với 2 ATP của đường phân yếm khí, đốt ái khí cho nhiều năng lượng hơn khoảng **15–19 lần**.

> [!bay]
> - **2 ATP** là con số **lời** của đường phân. Con số **tạo ra** là 4 ATP.
> - Pyruvat → acetyl-CoA tạo **NADH** (1 NADH/pyruvat, tức 2 NADH/glucose), **không** tạo ATP trực tiếp. Giáo trình tính "3 ATP" là qua chuỗi hô hấp.
> - Đường phân chạy được cả khi có và không có O~2~. Thứ thay đổi là **số phận** của pyruvat và NADH.

### 1.3. Con đường hexose monophosphat (chu trình pentose phosphat)

Con đường này oxy hóa glucose **trong bào tương**, song song với đường phân. Giáo trình ghi nó chỉ chiếm khoảng **7–10%** lượng glucose bị thoái hóa nói chung, nhưng **chiếm ưu thế** ở **hồng cầu, gan, mô mỡ, tuyến sữa** đang tiết sữa (Giáo trình tr. 108). Đó đều là nơi cần nhiều **NADPH**.

![Hình 3. Con đường pentose phosphat: giai đoạn oxy hóa tạo NADPH và giai đoạn chuyển đổi đường](pentose.svg)

**Giai đoạn 1 – oxy hóa** (không thuận nghịch, tạo NADPH):

=> G6P + NADP^+^ → 6-phosphoglucono-δ-lacton + NADPH + H^+^   (**glucose-6-phosphat dehydrogenase, G6PD**)

=> 6-phosphoglucono-δ-lacton + H~2~O → 6-phosphogluconat + H^+^   (6-phosphogluconolactonase)

=> 6-phosphogluconat + NADP^+^ → ribulose-5-phosphat + CO~2~ + NADPH + H^+^   (6-phosphogluconat dehydrogenase)

Kết quả: mỗi G6P cho **2 NADPH**, **1 CO~2~** và **1 pentose phosphat** (5C). G6PD là enzym **đầu tiên** và là bước **điều hòa** của con đường.

**Giai đoạn 2 – chuyển đổi đường** (thuận nghịch) (Giáo trình tr. 110):

- Ribulose-5-phosphat → **ribose-5-phosphat** (ribose-5-phosphat isomerase), hoặc → **xylulose-5-phosphat** (ribulose-5-phosphat epimerase; giáo trình ghi tên là ribose-5-phosphat epimerase).
- Ribose-5-phosphat được dùng để tổng hợp **nucleotid purin, pyrimidin**.
- Nếu tế bào không cần thêm pentose, phần dư được "xào lại" thành **F6P** và **GAP** nhờ **transketolase** (chuyển nhóm **2C**, phản ứng 6 và 8; coenzym **TPP**) và **transaldolase** (chuyển nhóm **3C**, phản ứng 7). Tóm lại: 3 pentose (15C) → 2 F6P (12C) + 1 GAP (3C). F6P và GAP quay về đường phân hoặc tân tạo glucose.

Phương trình tổng quát khi đốt hoàn toàn 1 G6P (6 vòng) theo giáo trình:

=> 6 G6P + 12 NADP^+^ + 6 H~2~O → 5 G6P + 12 NADPH + 6 CO~2~ + P~i~

**Ý nghĩa:**

1. **Không tạo ATP.**
2. Tạo **NADPH**, "chất khử" dùng cho tổng hợp **acid béo, cholesterol, steroid**. Ở hồng cầu, NADPH dùng để giữ **glutathion ở dạng khử** (GSH), chất bảo vệ hồng cầu khỏi bị oxy hóa (xem hoa-sinh/hs-03).
3. Tạo **ribose-5-phosphat** cho tổng hợp **acid nucleic**.

> [!bay] NADH khác NADPH
> - **NADH** chủ yếu đưa điện tử vào **chuỗi hô hấp** để tạo ATP (dị hóa).
> - **NADPH** chủ yếu dùng làm **chất khử trong tổng hợp** (đồng hóa) và chống oxy hóa.
> - Con đường pentose phosphat tạo **NADPH**, không tạo NADH và không tạo ATP.

> [!ung-dung] Thiếu G6PD: vì sao hồng cầu vỡ?
> Hồng cầu không có ty thể, nên con đường pentose phosphat là **nguồn NADPH gần như duy nhất** của nó. Thiếu G6PD → thiếu NADPH → **không tái tạo được GSH** → H~2~O~2~ và gốc tự do tích tụ, oxy hóa Hb (kết tủa thành **thể Heinz**) và màng hồng cầu → **tan máu cấp**. Cơn tan máu thường xảy ra khi gặp **chất oxy hóa**: thuốc (primaquin, sulfonamid, dapson…), **đậu tằm**, **băng phiến** (naphthalen), hoặc khi **nhiễm trùng**. **Không dùng xanh methylen** cho người thiếu G6PD.
> Xét nghiệm: định lượng **hoạt độ G6PD** hồng cầu; ở Việt Nam đã có **sàng lọc sơ sinh**. Phần di truyền (lặn liên kết X, gặp chủ yếu ở nam) và các lưu ý với dược liệu chứa berberin: xem sinh-hoc/sh-08, mục 9.

### 1.4. Chuyển hóa các monosaccharid khác

Fructose (mật ong, hoa quả, từ saccharose), galactose (từ lactose của sữa) và mannose (từ glycoprotein) sau khi hấp thu đều được biến thành **chất trung gian của đường phân** (Giáo trình tr. 110–112). Bảng ở cuối mục tóm tắt "cửa vào" của từng đường.

#### a) Fructose

Fructose hấp thu qua ruột **chậm hơn** glucose, nhưng vào máu rồi thì chuyển hóa **nhanh hơn**: thời gian bán hủy sau tiêm khoảng **18 phút**, so với **41 phút** của glucose.

- **Ở cơ**: **hexokinase** phosphoryl hóa fructose thành **F6P**, đi thẳng vào đường phân.
- **Ở gan** (6 phản ứng):
  1. **Fructokinase**: fructose + ATP → **fructose-1-phosphat** (F1P). Enzym nào cũng không biến được F1P thành F1,6DP.
  2. **Aldolase B** (chặt được cả F1P và F1,6DP; còn gọi fructose-1-phosphat aldolase): F1P → **DHAP** + **glyceraldehyd**.
  3. Glyceraldehyd + ATP → GAP (**glyceraldehyd kinase**).
  4–6. Hoặc glyceraldehyd bị khử thành **glycerol** (alcol dehydrogenase, NADH), rồi glycerol + ATP → glycerol-3-phosphat (**glycerol kinase**), rồi bị oxy hóa thành **DHAP** (glycerol phosphat dehydrogenase, NAD^+^). DHAP đổi thành GAP nhờ TPI.

Vì sao fructose chuyển hóa nhanh? Fructokinase hoạt động mạnh hơn glucokinase, và fructose **vào sau bước PFK-1**, tức là **"đi tắt"** qua van điều hòa chính. Chuyển hóa fructose ở gan cũng **không phụ thuộc hormon** (insulin).

> [!ung-dung] Nhiều fructose: lợi hay hại?
> Giáo trình xem fructose là "đường sinh năng lượng tốt" vì chuyển hóa nhanh, không cần insulin. Mặt trái là chính điều đó: fructose vào gan **không bị PFK-1 kìm lại**. Khi uống quá nhiều (nước ngọt, siro ngô giàu fructose), gan nhận dồn dập triose, biến phần dư thành **acid béo, triglycerid**. Bước fructokinase tiêu ATP rất nhanh; ATP thoái hóa thành AMP rồi thành **acid uric**. Vì vậy tiêu thụ nhiều fructose liên quan đến **gan nhiễm mỡ, tăng triglycerid và tăng acid uric máu** (gout). Fructose trong **trái cây nguyên quả** (lượng vừa phải, kèm chất xơ) không gây vấn đề như vậy.

#### b) Galactose

Galactose được chuyển hóa ở **gan**:

1. **Galactokinase**: galactose + ATP → **galactose-1-phosphat**.
2. **Galactose-1-phosphat uridylyl transferase** (GALT): chuyển nhóm uridylyl từ UDP-glucose sang galactose-1-phosphat, tạo **glucose-1-phosphat** (G1P) và **UDP-galactose**.
3. **UDP-galactose-4-epimerase**: UDP-galactose → **UDP-glucose** (dùng lại ở bước 2, hoặc dùng để tổng hợp glycogen).
4. **Phosphoglucomutase**: G1P → **G6P**, đi vào đường phân hoặc cho glucose tự do.

Chiều ngược lại cũng quan trọng: nhờ epimerase, cơ thể tự tạo được **UDP-galactose** từ glucose. Ở **tuyến sữa** của phụ nữ có thai và cho con bú, UDP-galactose kết hợp với glucose tạo **lactose** (Giáo trình tr. 116). Vì vậy trẻ bị bệnh galactose máu vẫn **không cần ăn galactose** để sống.

#### c) Mannose

Chỉ qua 2 phản ứng: **hexokinase** (mannose → mannose-6-phosphat), rồi **phosphomannose isomerase** (mannose-6-phosphat → **F6P**).

| Đường | Enzym đầu tiên | Nhập vào đường phân dưới dạng |
|---|---|---|
| Fructose (cơ) | Hexokinase | F6P |
| Fructose (gan) | **Fructokinase** → aldolase B | DHAP + GAP (**sau** bước PFK-1) |
| Galactose | **Galactokinase** → GALT → epimerase | G1P → G6P |
| Mannose | Hexokinase → phosphomannose isomerase | F6P |

## 2. Tân tạo glucose (gluconeogenesis)

### 2.1. Vì sao, ở đâu, từ chất gì?

**Não** và **hồng cầu** dùng glucose là nguồn năng lượng chính nhưng **không tự tổng hợp được glucose** (Giáo trình tr. 113). Khi đói lâu và kho glycogen cạn (dự trữ glycogen gan chỉ đủ khoảng một ngày), cơ thể phải **tạo glucose mới từ chất không phải glucid**. Đó là tân tạo glucose.

- **Nơi xảy ra**: chủ yếu ở **gan**; khoảng **10%** ở **vỏ thận** và ruột (theo giáo trình).
- **Nguyên liệu**: **lactat** (từ cơ, hồng cầu), **glycerol** (từ thoái hóa triglycerid), các **acid amin (amino acid) sinh đường** (alanin, glutamin, aspartat…; chúng tạo pyruvat hoặc chất trung gian của chu trình acid citric), **propionat** (đi vào dưới dạng succinyl-CoA). Fructose, galactose, mannose cũng tạo glucose được ở gan.

> [!bay] Acid béo không tạo được glucose
> **Acetyl-CoA** (từ acid béo chẵn C) **không** cho glucose ở người: phản ứng pyruvat → acetyl-CoA không thuận nghịch, và 2C của acetyl-CoA vào chu trình acid citric thì mất đúng 2C dưới dạng CO~2~, không tạo thêm oxaloacetat (xem hs-06). Trong một phân tử triglycerid, chỉ phần **glycerol** (và propionat từ acid béo lẻ C) tạo được glucose.

### 2.2. Ba "đường vòng" của tân tạo glucose

Tân tạo glucose **dùng lại 7 enzym thuận nghịch** của đường phân. Riêng **3 bước không thuận nghịch** (hexokinase, PFK-1, pyruvat kinase) thì phải đi **đường vòng** bằng **4 enzym riêng** (Giáo trình tr. 113–114):

![Hình 4. Tân tạo glucose: ba đường vòng (màu cam) quanh ba bước không thuận nghịch của đường phân](tan-tao-glucose.svg)

| Bước đường phân không đảo được | Đường vòng của tân tạo glucose | Nơi | Năng lượng |
|---|---|---|---|
| Pyruvat kinase (PEP → pyruvat) | (1) **Pyruvat carboxylase**: pyruvat + CO~2~ → **oxaloacetat** (coenzym **biotin**). Oxaloacetat ra bào tương dưới dạng **malat** (con thoi malat–aspartat), rồi được oxy hóa lại thành oxaloacetat. (2) **Phosphoenolpyruvat carboxykinase** (PEPCK): oxaloacetat → **PEP** + CO~2~ | (1) **Ty thể**; (2) bào tương | 1 ATP + 1 GTP cho mỗi pyruvat |
| PFK-1 (F6P → F1,6DP) | **Fructose-1,6-diphosphatase**: F1,6DP + H~2~O → F6P + P~i~ | Bào tương | — |
| Hexokinase (glucose → G6P) | **Glucose-6-phosphatase**: G6P + H~2~O → glucose + P~i~ | Lưới nội bào (**gan, thận**) | — |

Vì sao phải đi vòng? Ba bước kia có ΔG rất âm. Muốn đi ngược thì phải dùng **phản ứng khác** cũng có ΔG âm theo chiều ngược lại: thủy phân bỏ phosphat (2 phosphatase), hoặc tiêu thêm ATP, GTP (pyruvat carboxylase, PEPCK). Nhờ có enzym riêng cho mỗi chiều, tế bào **điều khiển hai chiều độc lập**, tránh "chu trình vô ích" đốt ATP mà không được gì.

**Năng lượng** (Giáo trình tr. 114). Phương trình tổng quát (viết theo dạng đã cân bằng của các sách hóa sinh hiện hành):

=> 2 Pyruvat + 4 ATP + 2 GTP + 2 NADH + 2 H^+^ + 4 H~2~O → Glucose + 4 ADP + 2 GDP + 6 P~i~ + 2 NAD^+^

=> Glucose + 2 NAD^+^ + 2 ADP + 2 P~i~ → 2 Pyruvat + 2 NADH + 2 H^+^ + 2 ATP + 2 H~2~O

Từ 2 pyruvat, tân tạo glucose tiêu **4 ATP** (2 ở pyruvat carboxylase, 2 ở phosphoglycerat kinase chạy ngược) **+ 2 GTP** (PEPCK), tức **6 liên kết phosphat giàu năng lượng**, cộng **2 NADH** (GAPDH chạy ngược). Đường phân chỉ trả lại 2 ATP.

> [!bay] "4 ATP" của giáo trình nghĩa là gì?
> Giáo trình kết luận "năng lượng cần cho tổng hợp một glucose từ pyruvat là **4 ATP**". Con số này chỉ đếm **ATP** mà bỏ qua 2 GTP (hoặc cũng có thể hiểu là phần **chênh lệch** 6 − 2 = 4 so với đường phân). Cái giá đầy đủ là **4 ATP + 2 GTP + 2 NADH** cho mỗi glucose. Đề hỏi "theo giáo trình" thì trả lời 4 ATP; đề hỏi số liên kết giàu năng lượng thì là **6**. Giáo trình in phương trình với 4 H^+^ và 6 H~2~O; hai dòng trên là dạng đã cân bằng lại.

> [!bay]
> - **Pyruvat carboxylase** nằm trong **ty thể**, cần **biotin** và **ATP**, được **acetyl-CoA hoạt hóa**. Nó cũng là phản ứng bổ sung oxaloacetat cho chu trình acid citric (hs-06, mục 4.5).
> - **PEPCK** dùng **GTP** và **giải phóng CO~2~** (khử carboxyl kèm phosphoryl hóa). Giáo trình viết oxaloacetat được "carboxyl hóa" thành PEP; thực ra đây là phản ứng **khử carboxyl**: CO~2~ vừa gắn vào ở bước pyruvat carboxylase bị tách ra lại.
> - **Glucose-6-phosphatase** chỉ có ở **gan** (và thận, ruột). **Cơ không có**, nên glycogen cơ không cho glucose vào máu được.
> - Giáo trình viết ở trang 116 rằng gan là "nơi duy nhất" tân tạo glucose, nhưng ở trang 113 lại ghi khoảng 10% ở thận. Hiểu đúng: gan là nơi **chủ yếu**; thận góp phần đáng kể, nhất là khi **nhịn đói kéo dài**.

### 2.3. Chu trình Cori và chu trình glucose–alanin

**Chu trình Cori** (Giáo trình tr. 114): cơ hoạt động trong điều kiện yếm khí tạo **lactat**. Lactat theo máu về **gan**, được tân tạo thành **glucose**. Glucose theo máu trở lại cơ.

**Chu trình glucose–alanin** (Giáo trình tr. 116): ở cơ, pyruvat nhận nhóm amin (nhờ **alanin transaminase**, ALT) thành **alanin**. Alanin theo máu về gan, trả lại nhóm amin (đi vào chu trình ure) và trở thành pyruvat, rồi thành glucose. Glucose quay lại cơ.

| | Chu trình Cori | Chu trình glucose–alanin |
|---|---|---|
| Chất từ cơ về gan | **Lactat** | **Alanin** |
| Ngoài carbon, còn chở | NADH (gián tiếp) | **Nhóm amin (nitơ)** về gan để tạo ure |
| Chi phí | Cơ được 2 ATP, gan tiêu 6 → cơ thể mất **4 ATP** mỗi vòng | Tương tự, cộng thêm chi phí tạo ure |

Ý nghĩa: cơ "chuyển giao" gánh nặng cho gan. Cơ chỉ cần đường phân nhanh để có ATP tức thời; gan dùng năng lượng (chủ yếu từ oxy hóa acid béo) để dựng lại glucose.

> [!ung-dung] Rượu và hạ đường huyết
> Giáo trình nêu hạ đường huyết có thể do **giảm tân tạo glucose khi uống nhiều rượu** (Giáo trình tr. 121). Vì sao? Gan oxy hóa ethanol tạo rất nhiều **NADH**. Tỉ lệ NADH/NAD^+^ cao đẩy **pyruvat → lactat** và **oxaloacetat → malat**, làm cạn hai nguyên liệu đầu vào của tân tạo glucose. Người **uống rượu lúc đói** (đã cạn glycogen) có thể hạ đường huyết nặng, dễ bị nhầm là say rượu. Đồng thời lactat tăng, gây toan lactic.

### 2.4. Điều hòa tân tạo glucose

Điều hòa trước hết phụ thuộc **tỉ lệ insulin/glucagon** (Giáo trình tr. 116). Các enzym ở "cặp bước" đối nghịch được điều khiển **ngược chiều nhau**:

| Enzym | Ức chế dị lập thể | Hoạt hóa dị lập thể | Khi bị phosphoryl hóa | Tổng hợp enzym |
|---|---|---|---|---|
| **PFK-1** (đường phân) | ATP, citrat | AMP, **fructose-2,6-diphosphat** (F2,6DP) | | |
| **Fructose-1,6-diphosphatase** (tân tạo) | AMP, **F2,6DP** | | | |
| **Pyruvat kinase** (đường phân) | Alanin (và ATP) | F1,6DP | **Không hoạt động** | |
| **Pyruvat carboxylase** (tân tạo) | | **Acetyl-CoA** | | |
| **PEPCK** (tân tạo) | | | | **Glucagon** tăng tổng hợp |
| PFK-2 (tạo F2,6DP) | Citrat | AMP, F6P, P~i~ | **Không hoạt động** | |
| Fructose-2,6-diphosphatase (FDP-2, phân hủy F2,6DP) | F6P | Glycerol-3-phosphat | | |

**Cách hiểu cho dễ nhớ:**

- **F2,6DP** là "tín hiệu no". Nó **bật PFK-1** (đường phân) và **tắt fructose-1,6-diphosphatase** (tân tạo) cùng lúc.
- Khi **đói**, **glucagon** tăng → cAMP → protein kinase A **phosphoryl hóa PFK-2** (làm nó ngừng hoạt động, bổ sung: đồng thời bật hoạt tính FDP-2 trên cùng phân tử) → **F2,6DP giảm** → đường phân ở gan chậm lại, tân tạo glucose tăng. Glucagon cũng phosphoryl hóa làm **pyruvat kinase gan ngừng hoạt động**, nên PEP không bị "đốt" lại thành pyruvat.
- **Acetyl-CoA** dồi dào (do đang đốt mỡ khi đói) báo hiệu "đủ nhiên liệu" → **bật pyruvat carboxylase**, đẩy pyruvat sang tân tạo glucose.
- **AMP** cao (thiếu năng lượng) → bật PFK-1, tắt fructose-1,6-diphosphatase: ưu tiên **đốt** glucose lấy ATP.

## 3. Chuyển hóa glycogen

Glycogen được dự trữ trong bào tương dưới dạng **hạt** đường kính khoảng **100–400 Å** (10–40 nm). Mỗi hạt chứa sẵn cả enzym thoái hóa lẫn enzym tổng hợp glycogen (Giáo trình tr. 117). Hai kho chính là **gan** và **cơ**.

Vì sao cơ thể cần glycogen khi đã có mỡ dự trữ?

- Glycogen **nhiều nhánh**, nên có rất nhiều đầu không khử để enzym cắt **cùng lúc**: giải phóng glucose (và G6P) **nhanh, số lượng lớn**.
- Thoái hóa lipid và tân tạo glucose đều **quá chậm** khi cần năng lượng gấp.
- Lipid **không thoái hóa được trong điều kiện yếm khí**; glycogen thì cho ATP được cả khi thiếu O~2~ (qua đường phân).

| | Glycogen **gan** | Glycogen **cơ** |
|---|---|---|
| Vai trò | Giữ **glucose máu** ổn định cho toàn cơ thể | Nhiên liệu **tại chỗ** cho cơ co |
| Sản phẩm cuối của thoái hóa | **Glucose tự do** → máu (nhờ glucose-6-phosphatase) | **G6P** → đường phân trong chính tế bào cơ |
| Hormon chính kích thích thoái hóa | **Glucagon** (và adrenalin) | **Adrenalin** (cơ không có thụ thể glucagon) |
| Enzym đưa glucose vào khi tổng hợp | **Glucokinase** (hoạt động mạnh khi glucose máu cao) | **Hexokinase** |

### 3.1. Thoái hóa glycogen

Thoái hóa glycogen cần **3 enzym** (Giáo trình tr. 117–118):

1. **Glycogen phosphorylase** (gọi tắt phosphorylase) cắt liên kết **α(1→4)** từ đầu không khử bằng **phosphat vô cơ** (phân cắt bằng phosphat, *phosphorolysis*, không phải thủy phân). Sản phẩm là **glucose-1-phosphat** (G1P). Enzym **dừng lại khi còn 4 gốc glucose** tính tới điểm chia nhánh.
2. **Enzym cắt nhánh** (debranching enzyme) có **2 hoạt tính** trên cùng một phân tử:
   - **Hoạt tính chuyển nhánh** (oligo-α(1,4)→α(1,4) glucosyl transferase): chuyển **3 gốc** của nhánh còn 4 gốc sang nối vào đầu một mạch thẳng khác bằng liên kết α(1→4). Mạch kia dài thêm 3 gốc, nhánh chỉ còn **1 gốc** nối bằng liên kết α(1→6).
   - **Hoạt tính cắt nhánh** (amylo-α(1,6)-glucosidase): **thủy phân** liên kết α(1→6) của gốc còn lại, giải phóng **glucose tự do**.
3. **Phosphoglucomutase**: G1P ⇌ **G6P**. Ở cơ, G6P đi vào đường phân. Ở gan, G6P bị **glucose-6-phosphatase** thủy phân thành glucose cho vào máu.

Kết quả: khoảng **90%** gốc glucose ra dưới dạng **G1P**, khoảng **10%** ra dưới dạng **glucose tự do** (từ các điểm chia nhánh).

![Hình 5. Tổng hợp và thoái hóa glycogen. Màu cam: hai enzym điều hòa chính](glycogen.svg)

> [!vi-du] Vì sao cắt bằng phosphat lại "khôn" hơn thủy phân?
> Phosphorylase dùng P~i~ để cắt, nên gốc glucose ra ngay ở dạng **đã gắn phosphat** (G1P) mà **không tốn ATP**. Nếu thủy phân thì ra glucose tự do, muốn vào đường phân lại phải tiêu 1 ATP ở bước hexokinase. Vì vậy đường phân bắt đầu từ glycogen cơ cho **lời 3 ATP** mỗi gốc glucose (thay vì 2). G1P mang điện âm cũng không lọt ra khỏi tế bào cơ.

### 3.2. Tổng hợp glycogen

Tổng hợp glycogen xảy ra ở gần như mọi mô, nhưng chủ yếu ở **gan và cơ**, trong **bào tương** (Giáo trình tr. 118–119). Nguyên liệu là **glucose**: glucose → G6P (hexokinase/glucokinase) → G1P (phosphoglucomutase). Từ G1P đến glycogen cần **3 enzym**:

1. **UDP-glucose pyrophosphorylase**: G1P + **UTP** → **UDP-glucose** + PP~i~. PP~i~ bị thủy phân ngay thành 2 P~i~, kéo phản ứng đi một chiều. UDP-glucose là dạng glucose **"hoạt hóa"**, mang đủ năng lượng để gắn vào chuỗi glycogen.
2. **Glycogen synthase**: chuyển gốc glucose từ UDP-glucose đến **nhóm –OH ở C4** của gốc glucose ở **đầu không khử** của phân tử glycogen có sẵn, tạo liên kết **α(1→4)** và giải phóng UDP. UDP được nạp lại thành UTP nhờ ATP (enzym **nucleosid diphosphokinase**).
3. **Enzym gắn nhánh** (branching enzyme), tên là **amylo-(α1,4 → α1,6)-transglycosylase**: khi mạch thẳng dài khoảng **11 gốc**, enzym cắt một đoạn **6–7 gốc** ở đầu không khử và gắn vào **nhóm –OH ở C6** của một gốc glucose khác bằng liên kết **α(1→6)**, tạo nhánh mới. Cả nhánh cũ và nhánh mới lại được kéo dài bằng liên kết α(1→4).

**Mồi glycogenin.** Glycogen synthase **không tự bắt đầu** được một phân tử glycogen mới; nó chỉ **kéo dài** mạch đã có. Mạch mới khởi đầu trên một protein tên là **glycogenin**: gốc glucose đầu tiên được gắn vào nhóm –OH của **tyrosin 194**; sau đó glycogenin **tự xúc tác** gắn thêm khoảng 7 gốc glucose từ UDP-glucose, tạo đoạn **mồi** (primer). Hạt glycogen có glycogenin và glycogen synthase theo tỉ lệ **1:1**.

> [!cap-nhat] Ai gắn glucose đầu tiên vào glycogenin?
> Giáo trình ghi gốc glucose đầu tiên được gắn bởi một enzym "tyrosin-glucosyltransferase", sau đó glycogenin tự kéo dài. Hiện nay biết rằng chính **glycogenin** là enzym đó: nó **tự glucosyl hóa** (tự gắn glucose vào Tyr194 của chính nó) rồi tự kéo dài mạch mồi. Khi thi, chỉ cần nhớ: **glycogenin là mồi; glycogen synthase chỉ kéo dài**.

> [!bay]
> - **Phosphorylase** chỉ cắt **α(1→4)**, không cắt được α(1→6). **Enzym cắt nhánh** mới cắt α(1→6), và cắt bằng cách **thủy phân** (ra glucose tự do).
> - **Glycogen synthase** chỉ tạo **α(1→4)**. **Enzym gắn nhánh** mới tạo **α(1→6)**.
> - Dạng glucose được glycogen synthase dùng là **UDP-glucose**, không phải G6P hay G1P.
> - Tổng hợp và thoái hóa glycogen là **hai con đường khác nhau** (khác enzym), không phải một phản ứng chạy hai chiều.

### 3.3. Điều hòa chuyển hóa glycogen bằng hormon

**Ở cơ** (Giáo trình tr. 120): **adrenalin** (epinephrin) gắn thụ thể trên màng → hoạt hóa **adenylat cyclase** → tạo **cAMP** → cAMP hoạt hóa **protein kinase phụ thuộc cAMP** (PKA) → PKA phosphoryl hóa **phosphorylase b kinase** sang dạng hoạt động → enzym này phosphoryl hóa **phosphorylase b** (dạng ít hoạt động) thành **phosphorylase a** (dạng hoạt động) → glycogen bị thoái hóa.

**Ở gan**: **glucagon** điều khiển phosphorylase theo cơ chế giống như vậy (adrenalin cũng tác động lên gan).

Đây là một **chuỗi khuếch đại** (cascade): mỗi bước là một enzym hoạt hóa nhiều phân tử của bước sau. Chỉ một lượng rất nhỏ hormon cũng giải phóng được lượng lớn glucose trong vài giây đến vài phút.

**Bổ sung (ngoài giáo trình) – điều hòa "hai mặt":**

- Cùng tín hiệu cAMP–PKA đó cũng **phosphoryl hóa glycogen synthase**, làm nó **ngừng hoạt động**. Vậy là khi đói/căng thẳng: **bật phân giải, tắt tổng hợp** cùng lúc.
- **Insulin** (sau bữa ăn) làm ngược lại: hoạt hóa **protein phosphatase**, gỡ phosphat khỏi các enzym trên → **glycogen synthase hoạt động**, **phosphorylase ngừng**. Insulin còn tăng đưa glucose vào cơ, mô mỡ (qua **GLUT4**) và tăng glucokinase ở gan.
- Ở cơ đang co, phosphorylase được bật nhanh kể cả khi chưa có adrenalin: **Ca^2+^** (giải phóng khi co cơ) gắn tiểu đơn vị calmodulin, hoạt hóa **phosphorylase kinase**; còn **AMP** (tăng khi cạn ATP) hoạt hóa **dị lập thể trực tiếp phosphorylase b**.

| Hormon | Khi nào tiết | Glycogen synthase | Glycogen phosphorylase | Kết quả |
|---|---|---|---|---|
| **Insulin** | Sau ăn, glucose máu cao | **Bật** | Tắt | Cất glucose vào kho |
| **Glucagon** (gan) | Đói, glucose máu thấp | Tắt | **Bật** | Gan trả glucose vào máu |
| **Adrenalin** (gan, cơ) | Stress, vận động, hạ đường huyết | Tắt | **Bật** | Có glucose/ATP cấp tốc |

## 4. Điều hòa chuyển hóa glucid

### 4.1. Nguyên tắc chung

Đường phân và tân tạo glucose chạy **song song, ngược chiều nhau**, dùng chung nhiều phản ứng thuận nghịch. **Các bước không thuận nghịch**, do các enzym khác nhau xúc tác ở mỗi chiều, chính là **điểm điều hòa** (Giáo trình tr. 120).

- **Ở cơ**: mục tiêu là **ATP**; đường phân tăng tốc khi cơ co.
- **Ở gan**: mục tiêu là **giữ glucose máu hằng định**: khi cần thì sản xuất glucose cho máu; khi thừa (sau ăn) thì thu nhận và cất thành glycogen.

Đường phân ở gan và cơ có **4 enzym điều hòa**: **glycogen phosphorylase, hexokinase, phosphofructokinase-1, pyruvat kinase**.

| Enzym | Điều hòa (theo giáo trình) |
|---|---|
| Glycogen phosphorylase | Hormon: adrenalin (cơ), glucagon (gan), qua cAMP → phosphorylase b → a |
| Hexokinase | Bị **ức chế dị lập thể bởi chính sản phẩm** của nó, G6P |
| Pyruvat kinase | **ATP** nồng độ cao ức chế dị lập thể (giảm ái lực với PEP) |
| **PFK-1** | **ATP** ức chế (gắn vào vị trí dị lập thể, giảm ái lực với F6P); **citrat** làm tăng tác dụng ức chế của ATP; **F2,6DP** hoạt hóa: là yếu tố điều hòa **có ý nghĩa nhất** |

Logic: **ATP, citrat nhiều** (tế bào đủ năng lượng, chu trình acid citric đã "đầy") → đường phân chậm lại. **AMP nhiều** (thiếu năng lượng) → đường phân nhanh lên.

### 4.2. Điều hòa glucose máu (bổ sung, tổng hợp từ các mục trên)

Glucose máu là kết quả cân bằng giữa **nguồn vào** (hấp thu từ ruột, phân giải glycogen gan, tân tạo glucose) và **nguồn ra** (các mô sử dụng, tổng hợp glycogen, chuyển thành lipid; khi quá ngưỡng thận thì mất qua nước tiểu).

| Hormon | Tác dụng lên glucose máu | Cơ chế chính |
|---|---|---|
| **Insulin** (tế bào β tụy) | **Hạ** (hormon **duy nhất** làm hạ glucose máu) | Tăng đưa glucose vào cơ, mỡ (GLUT4); tăng tổng hợp glycogen, tăng đường phân, tăng tạo lipid; ức chế phân giải glycogen và tân tạo glucose |
| **Glucagon** (tế bào α tụy) | Tăng | Tăng phân giải glycogen gan và tân tạo glucose (cAMP) |
| **Adrenalin** (tủy thượng thận) | Tăng | Phân giải glycogen gan và cơ; giảm tiết insulin |
| **Cortisol** (vỏ thượng thận) | Tăng | Tăng tổng hợp enzym tân tạo glucose; tăng dị hóa protein cơ để cung cấp acid amin |
| **GH** (hormon tăng trưởng) | Tăng | Giảm sử dụng glucose ở mô ngoại vi (đối kháng insulin) |

**Xét nghiệm hay gặp** (tham khảo, mỗi phòng xét nghiệm có khoảng riêng):

| Xét nghiệm | Giá trị tham khảo / ngưỡng |
|---|---|
| Glucose huyết tương lúc đói | **3,9–5,5 mmol/L** (70–99 mg/dL); quy đổi mmol/L × 18 = mg/dL |
| Ngưỡng thận của glucose | Khoảng **10 mmol/L** (180 mg/dL; giáo trình chương thận ghi ≈ 1,7 g/L ≈ 9,4 mmol/L — hs-18): vượt mức này glucose xuất hiện trong nước tiểu |
| HbA1c | Bình thường < 5,7%; **≥ 6,5%**: một tiêu chuẩn chẩn đoán đái tháo đường |
| Fructosamin | Phản ánh glucose máu trung bình **2–3 tuần** gần nhất (HbA1c: khoảng **2–3 tháng**) |
| Lactat máu | 0,5–2,2 mmol/L |
| Ceton máu (β-hydroxybutyrat) | Thường < 0,6 mmol/L; > 3 mmol/L kèm toan máu gợi ý nhiễm toan ceton |

Ngưỡng chẩn đoán đái tháo đường (glucose đói ≥ 7,0 mmol/L, glucose 2 giờ sau nghiệm pháp dung nạp ≥ 11,1 mmol/L, HbA1c ≥ 6,5%): xem bài hoa-hoc/hc-08b, mục 7.

## 5. Rối loạn chuyển hóa glucid

### 5.1. Hạ đường huyết (hypoglycemia)

Theo giáo trình (tr. 121), hạ đường huyết là hội chứng giảm glucose máu, thường **dưới 50 mg/dL (2,8 mmol/L)**. Merimee và Tyson đưa ra mức thấp nhất **không bệnh lý** là **35 mg/dL (1,9 mmol/L)**, gặp ở phụ nữ khỏe mạnh chưa mãn kinh nhịn ăn 24 giờ.

**Nguyên nhân** (theo giáo trình):

- **Thuốc**: quá liều **insulin** hoặc thuốc hạ đường huyết khác.
- **Rượu**: giảm tân tạo glucose (mục 2.3).
- **Nhịn ăn**, hoặc hạ đường huyết tự phát (hiếm, thường do tổn thương nhiều cơ quan).
- **Hạ đường huyết lúc đói** do quá nhiều insulin: **u tế bào đảo tụy** (insulinoma); u ngoài tụy tiết chất giống insulin; bệnh gan; thiếu glucocorticoid; nhiễm trùng huyết; giảm dự trữ glycogen (ví dụ bệnh ứ glycogen bẩm sinh, mục 5.3).

**Triệu chứng** chia hai nhóm, tùy glucose giảm **nhanh** hay **từ từ**:

| Kiểu giảm | Vì sao có triệu chứng | Biểu hiện |
|---|---|---|
| **Nhanh** | Cơ thể phản ứng bằng cách **tăng tiết adrenalin** | Vã mồ hôi, đói, **run**, nôn, **tim nhanh** |
| **Từ từ** đến 20–30 mg/dL (1,1–1,7 mmol/L) | **Vỏ não thiếu năng lượng** (não phụ thuộc glucose) | Lo sợ, lú lẫn, lơ mơ, **hôn mê**; não có thể tổn thương, tử vong |

Trẻ em chịu đựng glucose thấp tốt hơn. Tuy vậy, glucose **< 30 mg/dL** ở trẻ tuổi đi học và **< 20 mg/dL** ở trẻ trước tuổi đi học là bất thường.

> [!cap-nhat] Ngưỡng hạ đường huyết hiện nay
> Giáo trình dùng mốc **< 50 mg/dL (2,8 mmol/L)**. Ở người bệnh đái tháo đường đang điều trị, các hướng dẫn hiện nay (ADA, Bộ Y tế) xếp mức độ: **< 3,9 mmol/L** (70 mg/dL) là **ngưỡng cảnh báo**, cần xử trí; **< 3,0 mmol/L** (54 mg/dL) là hạ đường huyết **có ý nghĩa lâm sàng**; mức **nặng** là khi người bệnh rối loạn ý thức, cần người khác giúp, bất kể con số. Chẩn đoán hạ đường huyết thật sự dựa vào **tam chứng Whipple**: có triệu chứng, glucose máu thấp đo được lúc đó, và triệu chứng hết khi glucose trở về bình thường.

> [!ung-dung] Xử trí và một nguyên nhân dễ bị bỏ sót
> - Người còn tỉnh: cho uống/ăn khoảng **15–20 g đường hấp thu nhanh** (nước đường, nước quả, kẹo), kiểm tra lại sau 15 phút. Người lơ mơ, hôn mê: **không đổ nước đường vào miệng** (sặc); tiêm **glucose ưu trương** tĩnh mạch (ví dụ glucose 30%) hoặc **glucagon** tiêm bắp.
> - Người nghiện rượu, suy dinh dưỡng: tiêm **vitamin B~1~ trước hoặc cùng lúc** với truyền glucose (xem hs-06, mục 4.1).
> - Người dùng **sulfonylurê** (glibenclamid…) có thể bị hạ đường huyết **kéo dài, tái đi tái lại**, cần theo dõi nhiều giờ.
> - **"Thuốc nam trị tiểu đường" trộn tân dược**: cơ quan quản lý dược nhiều nước (ví dụ Cục Khoa học Y tế Singapore – HSA) đã nhiều lần cảnh báo sản phẩm "thảo dược" bị trộn lén **glibenclamid**, gây hạ đường huyết nặng, có ca tử vong. Gặp người hạ đường huyết không rõ nguyên nhân, nhớ hỏi kỹ về thuốc nam, thực phẩm chức năng đang dùng.

### 5.2. Bệnh thiếu vitamin B~1~ (beriberi)

Thiếu thiamin (vitamin B~1~) gây **beriberi** (Giáo trình tr. 121). Bệnh xuất hiện khi thiamin trong thức ăn giảm (thiamin nằm nhiều ở **lớp ngoài của hạt gạo**, nên ăn gạo xát quá trắng dễ thiếu).

- Biểu hiện **thần kinh** và **tim**. Thần kinh ngoại biên: đau tay chân, yếu cơ, tê bì, rối loạn cảm giác da. Tim: có thể to, hoạt động suy yếu.
- Cơ sở hóa sinh: vitamin B~1~ là thành phần của **thiamin pyrophosphat** (TPP), coenzym của **3 enzym**: **pyruvat dehydrogenase**, **α-cetoglutarat dehydrogenase** và **transketolase** (con đường pentose phosphat). Thiếu B~1~ thì **pyruvat** và **α-cetoglutarat** máu tăng; hoạt độ **transketolase hồng cầu** giảm. Đo hoạt độ transketolase hồng cầu là một cách đánh giá tình trạng B~1~.
- Theo giáo trình, mối liên hệ giữa mức giảm của 3 enzym này và các triệu chứng lâm sàng **chưa thật rõ ràng**.

> [!bay] Năm mô tả beriberi
> Giáo trình in "bệnh lần đầu tiên được mô tả ở Java năm **1930** bởi Jacobus Bonitus (người Hà Lan)". Đây là lỗi in: thầy thuốc Hà Lan **Jacobus Bontius** mô tả beriberi ở Java vào khoảng **thập niên 1630** (ông mất năm 1631). Đến những năm 1930, thiamin đã được tinh chế và tổng hợp.

### 5.3. Các bệnh ứ glycogen bẩm sinh

Là nhóm bệnh **di truyền** do thiếu enzym của chuyển hóa glycogen. Giáo trình chia **10 typ** (tr. 122–123):

| Typ | Tên bệnh | Enzym thiếu | Đặc điểm chính (theo giáo trình) |
|---|---|---|---|
| **I** | **Von Gierke** | **Glucose-6-phosphatase** (gan) | G6P ứ lại: phosphorylase bị ức chế, glycogen synthase được hoạt hóa → glucose máu **không tăng** khi tiêm glucagon, adrenalin. **Gan to**, **hạ glucose máu trầm trọng**; glycogen cấu trúc **bình thường** nhưng tích nhiều ở gan; tăng thể ceton và tăng lipid máu |
| **II** | **Pompe** | **α-1,4-glucosidase** (của **lysosom**) | Glycogen cấu trúc bình thường tích lũy rất nhiều trong lysosom của **mọi tế bào**; chết do **suy tim, suy hô hấp**, thường không quá 1 tuổi |
| **III** | **Cori** | **Amylo-1,6-glucosidase** (enzym cắt nhánh) | Glycogen cấu trúc **bất thường** (nhánh ngắn, không thoái hóa hết); hạ glucose máu nhưng **nhẹ hơn typ I**; điều trị bằng chế độ ăn **giàu protein**; có thể khỏi ở tuổi dậy thì |
| **IV** | **Andersen** | **Amylo-(1,4→1,6)-transglycosylase** (enzym gắn nhánh) | Rối loạn **tổng hợp**: glycogen **ít nhánh, nhánh rất dài**; lượng glycogen gan không tăng; gan to, **xơ gan**, thường không sống quá 2 tuổi |
| **V** | **McArdle** | **Phosphorylase cơ** | Ứ glycogen ở cơ (cấu trúc bình thường); **chuột rút khi gắng sức**, đau cơ, **myoglobin niệu** |
| **VI** | **Hers** | **Phosphorylase gan** | Giống typ I nhưng **nhẹ**; hạ glucose máu, ứ glycogen gan |
| **VII** | **Tarui** | **Phosphofructokinase cơ** | Giống typ V: ứ glycogen cơ, chuột rút khi gắng sức, đôi khi myoglobin niệu |
| VIII | — | Adenylat cyclase (theo giáo trình) | Catecholamin niệu cao; tử vong từ nhỏ; biểu hiện như typ VI |
| IX | — | **Phosphorylase kinase** | Glycogen cấu trúc bình thường; glycogen gan tăng, gan to |
| X | — | Protein kinase phụ thuộc cAMP | Chỉ có gan to |

> [!ghi-nho] Mẹo nhớ
> - Nhóm **gan** (I, III, IV, VI, IX): **gan to + hạ glucose máu** (gan không trả được glucose vào máu). Typ I nặng nhất vì tắc ở **bước cuối chung** của cả phân giải glycogen lẫn tân tạo glucose.
> - Nhóm **cơ** (V, VII): **chuột rút, đau cơ khi gắng sức, myoglobin niệu**; glucose máu bình thường (cơ vốn không cấp glucose cho máu).
> - Typ II (Pompe): enzym của **lysosom**, nên ứ glycogen ở mọi tế bào, tổn thương nặng nhất là **tim**.
> - Typ III và IV là hai bệnh duy nhất trong bảng có glycogen **cấu trúc bất thường** (III: thiếu enzym cắt nhánh; IV: thiếu enzym gắn nhánh).

> [!cap-nhat] Về phân loại và điều trị
> - Phân loại hiện nay ghi nhận thêm một số typ khác (ví dụ typ 0 do thiếu **glycogen synthase**). **Typ VIII** trong giáo trình không còn được dùng như một bệnh riêng (được xếp chung vào nhóm thiếu phosphorylase kinase, typ IX). Khi thi, học theo bảng của giáo trình.
> - Ở typ I, tài liệu hiện nay nhấn mạnh thêm **toan lactic** và **tăng acid uric máu** (G6P ứ lại bị đẩy sang đường phân và con đường pentose). Điều trị chủ yếu là **ăn nhiều bữa, dùng tinh bột ngô sống** (tiêu hóa chậm) để giữ glucose máu, nhất là ban đêm.
> - **Bệnh Pompe** nay đã có **liệu pháp thay thế enzym** (alglucosidase alfa), giúp kéo dài đời sống nếu điều trị sớm.

### 5.4. Bệnh galactose máu bẩm sinh (galactosemia)

Do **thiếu bẩm sinh một trong ba enzym** chuyển hóa galactose: **galactokinase**, **galactose-1-phosphat uridylyl transferase** (GALT) và **UDP-galactose-4-epimerase** (Giáo trình tr. 123). Thể **kinh điển** là **thiếu GALT**.

- Trẻ bú sữa (chứa lactose = galactose + glucose) bị **nôn, tiêu chảy**, **còi cọc**, **chậm phát triển trí tuệ**; có **galactose niệu**; galactose máu tăng gây **đục thủy tinh thể**.
- Vì sao đục thủy tinh thể? (bổ sung) Galactose dư bị **aldose reductase** khử thành **galactitol**. Galactitol không ra khỏi thủy tinh thể được, kéo nước vào, làm sợi thủy tinh thể phù và đục. Trong thể thiếu GALT, **galactose-1-phosphat** ứ đọng còn gây độc cho gan, não, thận.
- Điều trị: chế độ ăn **không có sữa** (không lactose, không galactose), dùng sữa công thức đặc biệt (ví dụ sữa đậu nành). Phát hiện sớm nhờ **sàng lọc sơ sinh**.

### 5.5. Bệnh về chuyển hóa fructose

- **Không dung nạp fructose di truyền**: theo giáo trình do thiếu **fructose-1-phosphat aldolase** (aldolase B) hoặc **fructose-1,6-diphosphatase**. Biểu hiện: **không dung nạp fructose**, **hạ glucose máu**; nặng thì **nhiễm acid lactic**, **gan to** (Giáo trình tr. 123). Hiện nay, tên "không dung nạp fructose di truyền" dành riêng cho thiếu **aldolase B**; thiếu fructose-1,6-diphosphatase được xếp là một **rối loạn tân tạo glucose** riêng (hạ glucose máu, toan lactic khi nhịn đói), dù fructose cũng làm bệnh nặng thêm.
- **Thể lành tính** (fructose niệu lành tính) do thiếu **fructokinase gan**: fructose không vào được gan, chỉ thải ra nước tiểu, không gây hại.

Vì sao thiếu aldolase B lại gây hạ đường huyết? (bổ sung) Fructokinase vẫn chạy, nên **F1P ứ lại** trong gan, "giam" mất phosphat. Tế bào gan **cạn P~i~ và ATP**: phosphorylase (cần P~i~) không phân giải được glycogen, tân tạo glucose cũng bị ức chế. Kết quả là hạ đường huyết sau khi ăn đồ chứa fructose hoặc saccharose.

> [!ung-dung] Đường "ẩn" trong thuốc
> Người không dung nạp fructose phải tránh **fructose, saccharose** và cả **sorbitol** (cơ thể chuyển sorbitol thành fructose). Sorbitol, saccharose hay có trong **siro thuốc**, viên ngậm, thuốc nhuận tràng. Khi kê đơn cho trẻ có tiền sử nôn, hạ đường huyết sau ăn hoa quả, cần đọc kỹ **tá dược**.

### 5.6. Bệnh đái tháo đường (ĐTĐ)

ĐTĐ (bệnh tiểu đường) là một **hội chứng** gồm nhiều rối loạn, trong đó **tăng glucose máu** là dấu hiệu đặc trưng. Nguyên nhân là insulin **giảm về số lượng** hoặc **về chất lượng** (tác dụng kém) (Giáo trình tr. 123).

**Chuỗi hậu quả khi thiếu insulin** (đây là chỗ cần hiểu "vì sao"):

1. Glucose khó vào cơ, mô mỡ (giảm **GLUT4** trên màng) → **glucose máu tăng**.
2. Glucose máu vượt **ngưỡng thận** → **glucose niệu**; glucose kéo theo nước (lợi niệu thẩm thấu) → **đái nhiều** → mất nước → **khát, uống nhiều**.
3. Tế bào "đói giữa đống đường" → **ăn nhiều**; cơ thể tăng thoái hóa **lipid và protein** để lấy năng lượng → **gầy sút**. Đó là triệu chứng điển hình **"ba nhiều, một ít"**: **đái nhiều, uống nhiều, ăn nhiều, gầy nhiều**.
4. Đường phân bị hạn chế; **phân giải glycogen** thành glucose tăng; **tân tạo glucose** từ chất không phải glucid tăng → glucose máu càng tăng.
5. Thoái hóa lipid tạo rất nhiều **acetyl-CoA**. Acetyl-CoA này **không vào được hết chu trình acid citric** (vì oxaloacetat đang bị rút đi cho tân tạo glucose), nên được chuyển thành **cholesterol** và các **thể ceton** (acid acetoacetic, acid β-hydroxybutyric, aceton). Thể ceton tăng trong máu, xuất hiện trong nước tiểu → **nhiễm acid chuyển hóa** (nhiễm toan ceton).

**Các rối loạn chuyển hóa gây biến chứng** (Giáo trình tr. 124):

- **Glycosyl hóa** (tên giáo trình dùng; thuật ngữ chuẩn hiện nay là **glycat hóa** — *glycation* — để phân biệt với glycosyl hóa có enzym tạo glycoprotein, xem hs-12): glucose gắn **không cần enzym** vào protein trong máu và mô; mức độ phụ thuộc nồng độ glucose máu. Albumin huyết thanh bị glycosyl hóa thành **fructosamin**; hemoglobin A bị glycosyl hóa thành **HbA~1c~**. Định lượng **fructosamin và HbA~1c~** để **theo dõi điều trị** ĐTĐ.
- **Gluco-oxy hóa**: phản ứng glycosyl hóa kèm phản ứng oxy hóa tạo **gốc tự do**, mở đầu chuỗi phản ứng sinh gốc tự do gấp bội; đây là một nguyên nhân của **biến chứng mạch máu**.
- **Tăng chuyển hóa theo con đường polyol**: glucose dư bị khử thành **sorbitol** (enzym aldose reductase), rồi thành **fructose**. Sorbitol và fructose tăng trong **thủy tinh thể** gây **đục thủy tinh thể**.

**Hai loại ĐTĐ chính** (theo cách gọi của giáo trình):

| | ĐTĐ **typ 1** (phụ thuộc insulin, IDDM) | ĐTĐ **typ 2** (không phụ thuộc insulin, NIDDM) |
|---|---|---|
| Bản chất | **Tự miễn**: phá hủy **tế bào β** tụy | Insulin tác dụng kém (kháng insulin) kèm suy giảm dần chức năng tế bào β |
| Kháng thể | Kháng tế bào đảo, kháng insulin, kháng **GAD** (glutamic acid decarboxylase, enzym biến glutamat thành GABA) | Không có |
| Insulin máu | **Thiếu tuyệt đối** hoặc gần tuyệt đối | Theo giáo trình: **bình thường** |
| Triệu chứng | **Rầm rộ** | **Ôn hòa** (mệt, khát), có khi **không triệu chứng** |
| Thể ceton niệu | **Có thể xuất hiện** | Theo giáo trình: không |
| Insulin ngoại sinh | **Bắt buộc** để sống | Không phụ thuộc |
| Tỉ lệ | | Giáo trình ghi 85% ca ĐTĐ ở nước phát triển, gần như 100% ở nước đang phát triển |
| Tuổi | Thường người trẻ | Thường chẩn đoán **sau 40 tuổi**, hay **tình cờ** qua xét nghiệm glucose máu, glucose niệu; cũng gặp ở người trẻ |

ĐTĐ là bệnh **mạn tính**, gây biến chứng nặng ở **tim mạch** (theo giáo trình, hơn 70% người bệnh ĐTĐ tử vong do bệnh tim mạch), **thận**, **thần kinh** (Giáo trình tr. 125).

> [!cap-nhat] ĐTĐ: những điểm đã thay đổi
> - Tên **IDDM/NIDDM** đã **bỏ** từ cuối thập niên 1990 (WHO, ADA), vì nhiều người bệnh typ 2 về sau cũng **cần insulin**. Nay chỉ gọi **typ 1, typ 2**, ĐTĐ thai kỳ và các typ đặc biệt khác.
> - ĐTĐ typ 2 chiếm khoảng **90–95%** tổng số ca ở hầu hết các nước.
> - Ở typ 2, insulin máu **giai đoạn đầu thường bình thường hoặc tăng** (để bù kháng insulin), sau đó **giảm dần** khi tế bào β suy. Typ 2 **vẫn có thể nhiễm toan ceton** khi có stress nặng (nhiễm trùng, phẫu thuật) hoặc do một số thuốc (nhóm ức chế SGLT2). Nhưng **hôn mê tăng áp lực thẩm thấu** mới là biến chứng cấp đặc trưng hơn của typ 2.
> - ĐTĐ typ 2 ngày càng gặp ở **người trẻ**, gắn với béo phì và ít vận động.
> - Khi thi, trả lời theo bảng của giáo trình.

> [!yhct] "Tiêu khát", berberin, Hoài sơn và người bệnh ĐTĐ
> - **Tiêu khát** trong YHCT mô tả chứng khát, uống nhiều, ăn nhiều, tiểu nhiều, gầy, rất giống "ba nhiều, một ít" của ĐTĐ. Nhưng đây là **hai hệ thống khái niệm khác nhau**: tiêu khát là một chứng theo biện chứng YHCT, không đồng nhất với ĐTĐ (được chẩn đoán bằng glucose máu, HbA1c). Không YHCT nào thay được **insulin** ở ĐTĐ typ 1.
> - **Berberin** (Hoàng liên, Hoàng bá, Vàng đắng): cơ chế ở mức tế bào (ức chế nhẹ phức hợp I → hoạt hóa **AMPK**) đã nêu ở bài *Năng lượng sinh học* (mã hs-06). Liên hệ với bài này: trên **tế bào gan nuôi cấy và động vật**, AMPK hoạt hóa làm giảm biểu hiện **PEPCK** và **glucose-6-phosphatase**, tức là **giảm tân tạo glucose ở gan**, giống một phần cơ chế của thuốc **metformin**. Ở người, đã có nhiều **thử nghiệm lâm sàng cỡ nhỏ** (chủ yếu ở Trung Quốc) và các phân tích gộp cho thấy berberin **giảm glucose đói và HbA1c ở mức khiêm tốn**, nhưng chất lượng nghiên cứu **chưa cao**. Cần thận trọng: berberin **ức chế một số enzym CYP** (tương tác thuốc), dùng cùng sulfonylurê/insulin có thể gây **hạ đường huyết**, và **tránh dùng cho trẻ sơ sinh** (xem bài *Các nguyên lý và quy luật cơ bản của sự di truyền*, mã sh-08, khung YHCT về thiếu G6PD).
> - **Hoài sơn** (củ mài) là vị thường có trong các bài thuốc chữa tiêu khát (ví dụ Lục vị địa hoàng hoàn). Tác dụng hạ glucose của dịch chiết, polysaccharid Hoài sơn mới thấy **trên động vật**. Mặt khác, Hoài sơn **giàu tinh bột** (bài *Glucid*, mã hc-08b), nên dùng làm thực phẩm với lượng lớn thì **làm tăng** glucose máu như ngũ cốc.
> - **Thực hành**: thuốc **hoàn mật**, **cao lỏng có đường**, siro thuốc mang theo một lượng đường đáng kể. Với người bệnh ĐTĐ, cần tính lượng đường này, hoặc chọn dạng bào chế khác (viên nước, thuốc sắc không thêm đường).

## Tóm tắt

| Chủ đề | Điểm cần nhớ |
|---|---|
| Đường phân | Bào tương, 10 phản ứng, glucose → 2 pyruvat. Tiêu ATP ở **1, 3**; tạo ATP ở **7, 10**; NADH ở **6**. Không thuận nghịch: **hexokinase, PFK-1, pyruvat kinase**. Lời **2 ATP** |
| Hexokinase / glucokinase | Mọi mô, K~m~ thấp, bị G6P ức chế / gan, K~m~ cao, hoạt động khi glucose máu cao |
| Hồng cầu | Chỉ có đường phân; nhánh **2,3-DPG** giảm ái lực Hb–O~2~; thiếu PK → 2,3-DPG tăng; thiếu HK → 2,3-DPG giảm |
| Yếm khí | Pyruvat → lactat (**LDH**, 5 isozym H/M), tái tạo NAD^+^; **2 ATP**/glucose; ΔG°' = −196 kJ/mol |
| Ái khí | Pyruvat → acetyl-CoA (PDH, TPP) → Krebs → chuỗi hô hấp: **38 ATP** (sách) / ≈ 30–32 (hiện nay) |
| Pentose phosphat | Bào tương; **G6PD** → 6-phosphogluconolacton → 6-phosphogluconat → ribulose-5-P + CO~2~; **2 NADPH**/G6P; transketolase (TPP, 2C), transaldolase (3C). Không tạo ATP. Thiếu G6PD → tan máu |
| Monosaccharid khác | Fructose: cơ (hexokinase → F6P), gan (**fructokinase** → F1P → **aldolase B** → DHAP + glyceraldehyd, qua mặt PFK-1). Galactose: galactokinase → **GALT** → epimerase. Mannose: hexokinase → phosphomannose isomerase → F6P |
| Tân tạo glucose | Gan (thận khoảng 10%); từ lactat, glycerol, acid amin sinh đường, propionat; **không** từ acetyl-CoA. 4 enzym riêng: **pyruvat carboxylase** (ty thể, biotin, ATP), **PEPCK** (GTP), **fructose-1,6-diphosphatase**, **glucose-6-phosphatase** |
| Chu trình | **Cori**: lactat cơ → glucose gan. **Glucose–alanin**: alanin cơ → glucose gan (kèm chở N) |
| Điều hòa đường phân/tân tạo | PFK-1: ATP, citrat (−); AMP, **F2,6DP** (+). F1,6-diphosphatase: AMP, F2,6DP (−). Pyruvat carboxylase: acetyl-CoA (+). PEPCK: glucagon tăng tổng hợp |
| Thoái hóa glycogen | **Phosphorylase** (P~i~, cắt α1→4, ra G1P, dừng cách nhánh 4 gốc) + **enzym cắt nhánh** (chuyển 3 gốc; cắt α1→6 ra glucose tự do) + phosphoglucomutase. 90% G1P, 10% glucose |
| Tổng hợp glycogen | G1P + UTP → **UDP-glucose**; **glycogen synthase** (α1→4, chỉ kéo dài) cần mồi **glycogenin** (Tyr194); **enzym gắn nhánh** (11 gốc → chuyển 6–7 gốc, α1→6) |
| Gan khác cơ | Gan có **glucose-6-phosphatase**, trả glucose vào máu, chịu **glucagon**. Cơ dùng G6P tại chỗ, chịu **adrenalin** (và Ca^2+^, AMP) |
| Hormon | **Insulin** hạ glucose (bật synthase, tắt phosphorylase). Glucagon, adrenalin, cortisol, GH tăng glucose. Cascade cAMP → PKA → phosphorylase kinase → phosphorylase b → a |
| Hạ đường huyết | Sách: < 50 mg/dL (2,8 mmol/L). Giảm nhanh → triệu chứng adrenalin; giảm từ từ → triệu chứng thần kinh. Nguyên nhân: insulin, thuốc, rượu, insulinoma, bệnh ứ glycogen |
| Thiếu B~1~ | TPP của PDH, α-KGDH, **transketolase**; pyruvat, α-KG máu tăng; transketolase hồng cầu giảm |
| Ứ glycogen | I Von Gierke (G6Pase), II Pompe (α-glucosidase lysosom), III Cori (cắt nhánh), IV Andersen (gắn nhánh), V McArdle (phosphorylase cơ), VI Hers (phosphorylase gan), VII Tarui (PFK cơ) |
| Galactose máu | Thiếu **GALT** (kinh điển): nôn, tiêu chảy, chậm phát triển, đục thủy tinh thể; bỏ sữa |
| Fructose | Thiếu aldolase B: hạ glucose máu, toan lactic, gan to. Thiếu fructokinase: lành tính |
| ĐTĐ | Thiếu insulin → glucose máu tăng, glucose niệu, "ba nhiều một ít", thể ceton, toan chuyển hóa. Glycat hóa (giáo trình: "glycosyl hóa"; **HbA1c, fructosamin**), gốc tự do, con đường **polyol** (sorbitol → đục thủy tinh thể). Typ 1 tự miễn (anti-GAD), typ 2 kháng insulin |
