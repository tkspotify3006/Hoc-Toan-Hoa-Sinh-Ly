---
title: Hóa học acid amin, protein và hemoglobin
thoi-gian: 60 phút
muc-tieu:
- Phân loại được 20 acid amin thường gặp theo gốc R (5 nhóm) và nhận ra công thức của từng nhóm; nêu được các acid amin thiết yếu.
- Kể được các liên kết hóa học trong phân tử protein và mô tả được 4 bậc cấu trúc, kèm ví dụ.
- Trình bày được tính chất của acid amin và protein (tích điện – pHi, hòa tan, kết tủa, biến tính) và các phương pháp phân tích dựa trên chúng (chuẩn độ, phản ứng màu, điện di, sắc ký).
- Phân loại được protein và nêu được các chức năng chính của protein.
- Mô tả được cấu trúc phân tử hemoglobin (hem, globin, 2,3-DPG) và myoglobin; giải thích được hình dạng đường cong phân ly oxy và các yếu tố làm dịch chuyển nó.
- Kể được các loại hemoglobin ở người bình thường (HbA~1~, HbA~2~, HbF) và một số dẫn xuất, biến thể có ý nghĩa lâm sàng.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. **20 acid amin** (amino acid) đều là α-acid amin dãy **L** (trừ glycin), chỉ khác nhau ở **gốc R**. Sách chia **5 nhóm**: R không phân cực (6), R thơm (3), R base (+) (3), R phân cực không tích điện (6), R acid (−) (2).
> 2. Protein (trên 50 acid amin) có **4 bậc cấu trúc**: bậc 1 = trình tự (liên kết **peptid**); bậc 2 = xoắn α, gấp nếp β (liên kết **hydro**); bậc 3 = gập không gian (S–S, ion, kỵ nước); bậc 4 = nhiều chuỗi ghép lại (ion, kỵ nước).
> 3. **Biến tính** = phá bậc 2–4, **không** cắt liên kết peptid → mất hoạt tính. **Kết tủa** = mất lớp áo nước + trung hòa điện tích. Tại **pHi**, protein không di chuyển trong điện trường.
> 4. **Hemoglobin** = 4 chuỗi (HbA~1~ = α~2~β~2~) + 4 **hem** (protoporphyrin IX + Fe^2+^) + 1 phân tử 2,3-DPG; chở 4 O~2~, gắn O~2~ có **tính hợp tác** → đường cong **hình sigma**. Myoglobin 1 chuỗi, 1 hem → đường **hyperbol**, ái lực cao hơn.
> 5. H^+^, CO~2~, nhiệt độ, 2,3-DPG tăng → đường cong **dịch phải** (nhả O~2~ cho mô). HbF, CO → **dịch trái**. CO gắn Hb mạnh gấp ≈ 210 lần O~2~; MetHb (Fe^3+^) không chở được O~2~.

Bài này nhìn acid amin và protein từ góc **hóa sinh**. Phần hóa học cơ bản đã học ở bài **Amin, amid, amino acid (hoa-hoc/hc-10)**: ion lưỡng cực, cách tính pI, phản ứng van Slyke, ninhydrin, tạo liên kết peptid. Ở đây không nhắc lại, chỉ dẫn chéo. Sinh tổng hợp protein (dịch mã) xem **sinh-hoc/sh-09**.

Protein là phân tử hữu cơ **nhiều nhất** trong tế bào sống. Protein chiếm khoảng **50% trọng lượng khô** của tế bào, và một tế bào có tới hàng nghìn loại protein. Protein vừa là vật liệu xây dựng, vừa thực hiện hầu hết hoạt động sống. Protein cũng tạo ra **tính đặc thù** của tế bào, của cá thể và của loài (Giáo trình tr. 37).

## 1. Acid amin

### 1.1. Cấu tạo chung

**Acid amin** là chất hữu cơ có **hai nhóm chức chính**: nhóm **carboxyl** (–COOH) và nhóm **amin** (–NH~2~). Cả hai cùng gắn vào **carbon alpha (C~α~)** (Giáo trình tr. 37).

=> Công thức chung ở pH 7: ^+^H~3~N–C~α~H(R)–COO^−^

- Ở pH sinh lý, acid amin tồn tại ở **dạng ion**: –NH~3~^+^ và –COO^−^ (xem hc-10, mục 3.4–3.5).
- Các acid amin chỉ khác nhau ở **gốc R**. Gốc R đơn giản nhất là **H** (glycin). R có thể là gốc hydrocarbon thuần, hoặc mang thêm nhóm chức –SH, –OH, –NH~2~, –COOH.
- **Prolin** là ngoại lệ: nhóm amin của nó nằm **trong vòng** (amin bậc II, gọi là *imino acid*), nên không đúng hẳn công thức chung.
- Carbon gắn với hai nhóm chức chính là **α**, các carbon tiếp theo trên gốc R là β, γ…
- Trừ glycin, cả 20 acid amin thường gặp đều có **đồng phân quang học**. Trong tự nhiên (trong protein) gặp dạng **L** (Giáo trình tr. 38).

> [!bay]
> - "Dãy **L**" là cấu hình so với glyceraldehyd, **không** có nghĩa là quay trái. Ví dụ L-alanin quay phải.
> - Acid amin của protein là **α-acid amin**. β-alanin (trong coenzym A) và GABA (γ-aminobutyrat) là acid amin không có trong protein.

### 1.2. Phân loại acid amin

**Cách 1 — theo tính chất gốc R (5 nhóm, Giáo trình tr. 38–39)**

| Nhóm | Đặc điểm gốc R | Acid amin (ký hiệu 3 chữ, 1 chữ) | Ghi nhớ |
|---|---|---|---|
| **1** | **Không phân cực, kỵ nước** (6) | Gly (G), Ala (A), Val (V), Leu (L), Ile (I), Pro (P) | Val, Leu, Ile có **mạch nhánh** |
| **2** | **Nhân thơm** (3) | Phe (F), Tyr (Y), Trp (W) | Tyr có –OH phenol; Trp có nhân indol |
| **3** | **Base, tích điện dương** (3) | Lys (K), Arg (R), His (H) | Lys: –NH~2~ ở C~ε~; Arg: nhóm guanidin; His: nhân imidazol |
| **4** | **Phân cực, không tích điện** (6) | Ser (S), Thr (T), Cys (C), Met (M), Asn (N), Gln (Q) | Ser, Thr có –OH; Cys có –SH; Met có S; Asn, Gln là amid |
| **5** | **Acid, tích điện âm** (2) | Asp (D), Glu (E) | thêm một nhóm –COO^−^ |

**Cách 2 — theo cấu tạo mạch (2 nhóm):**

- **Acid amin mạch thẳng**: chia tiếp theo số nhóm –NH~2~ và –COOH thành **trung tính, acid, base** (như ở hc-10, mục 3.1).
- **Acid amin mạch vòng**: chia thành **nhân thơm** (Phe, Tyr) và **dị vòng** (Trp, His, Pro).

**Bảng pI và trọng lượng phân tử** (TLPT, trích Bảng 3.1, Giáo trình tr. 39):

| Acid amin | TLPT | pI | | Acid amin | TLPT | pI |
|---|---|---|---|---|---|---|
| Glycin | 75 | 5,97 | | Serin | 105 | 5,68 |
| Alanin | 89 | 6,01 | | Cystein | 121 | 5,07 |
| Leucin | 131 | 5,98 | | Methionin | 149 | 5,74 |
| Prolin | 115 | 6,48 | | Phenylalanin | 165 | 5,48 |
| Tryptophan | 204 | 5,89 | | Tyrosin | 181 | 5,66 |
| **Lysin** | 146 | **9,74** | | **Aspartat** | 133 | **2,77** |
| **Arginin** | 174 | **10,76** | | **Glutamat** | 147 | **3,22** |
| **Histidin** | 155 | **7,59** | | | | |

Quy luật cần nhớ: nhóm R **base** có pI **cao** (7,6–10,8), nhóm R **acid** có pI **thấp** (≈ 3), các nhóm còn lại pI ≈ 5–6.

> [!bay] Chỗ dễ nhầm khi xếp nhóm
> - Giáo trình xếp **Met vào nhóm 4** (phân cực) và **Pro, Gly vào nhóm 1**. Một số sách khác (Lehninger) xếp Met vào nhóm không phân cực. Đi thi theo cách xếp của giáo trình.
> - **Tyr** có –OH nhưng nằm ở nhóm **nhân thơm**, không ở nhóm 4.
> - **Asn, Gln** là **amid** của Asp, Glu: gốc R **không** tích điện. Đừng nhầm Gln (Q) với Glu (E), Asn (N) với Asp (D).
> - **His** có pK~a~ của nhân imidazol ≈ 6, gần pH sinh lý. Vì vậy His vừa nhận vừa nhường H^+^ được trong cơ thể, là nhóm **đệm** quan trọng của hemoglobin (mục 4.3).

**Acid amin thiết yếu** *(bổ sung — chương này của giáo trình không liệt kê, sẽ gặp lại ở chương Chuyển hóa protein)*

Cơ thể người **không tự tổng hợp** được khung carbon của một số acid amin, nên phải lấy từ thức ăn. Đó là các acid amin **thiết yếu** (cần thiết):

| Thiết yếu | Mẹo nhớ |
|---|---|
| **Val, Leu, Ile, Thr, Met, Phe, Trp, Lys** (8 chất, kinh điển cho người lớn) + **His** (cần cho trẻ; nay tính chung là 9) | "**V**ài **L**ần **Í**t **T**hấy **M**ẹ **P**hải **T**ìm **L**ại **H**ộp" |
| **Arg**: bán thiết yếu (trẻ đang lớn cần thêm) | |

> [!bay] Thiết yếu "có điều kiện"
> - **Tyr** được tạo từ **Phe**; **Cys** lấy S từ **Met**. Khi thiếu Phe hay Met, hai chất này cũng trở thành thiết yếu.
> - Ở bệnh **phenylceton niệu** (thiếu enzym chuyển Phe → Tyr), người bệnh phải ăn ít Phe, nên **Tyr trở thành thiết yếu** (xem hc-10 mục 3.6).

**Acid amin ít gặp** (Giáo trình tr. 38)

- Ngoài 20 acid amin thường gặp, protein còn chứa **dẫn xuất** của chúng, được tạo **sau khi** chuỗi đã tổng hợp xong: **hydroxyprolin, hydroxylysin** (trong **collagen** của mô liên kết); **γ-carboxyglutamat** (trong **prothrombin**).
- Một số acid amin **không** tham gia cấu tạo protein nhưng quan trọng trong chuyển hóa: **ornitin, citrulin** (chu trình ure).

> [!ung-dung] Vitamin C, vitamin K và các acid amin "sửa đổi"
> - Phản ứng gắn –OH tạo hydroxyprolin, hydroxylysin cần **vitamin C**. Thiếu vitamin C thì collagen kém bền: chảy máu chân răng, xuất huyết dưới da, vết thương lâu lành (bệnh **scorbut**).
> - Phản ứng gắn thêm nhóm –COOH tạo γ-carboxyglutamat cần **vitamin K**. Nhờ hai nhóm COO^−^ cạnh nhau, prothrombin (và các yếu tố đông máu VII, IX, X) gắn được Ca^2+^ để hoạt động. Thuốc chống đông **warfarin** đối kháng vitamin K. Thiếu vitamin K gây chảy máu ở trẻ sơ sinh, nên trẻ được tiêm vitamin K~1~ ngay sau sinh.

### 1.3. Tính chất của acid amin

(Giáo trình tr. 40) — phần hóa học chi tiết đã có ở hc-10, mục 3.4–3.5.

- **Dễ tan trong nước**, không tan trong ether, ít tan trong alcol.
- Nhóm α-amin phản ứng với HNO~2~ (**van Slyke**). Nhóm α-carboxyl tạo muối với kiềm, tạo ester với alcol. Cả hai nhóm cùng tạo **liên kết peptid**.
- **Lưỡng tính**. Tùy pH, acid amin có thể ở dạng cation, ion lưỡng cực hoặc anion:

=> pH < pH~i~: ^+^H~3~N–CHR–COOH (tích điện +) · pH = pH~i~: ^+^H~3~N–CHR–COO^−^ · pH > pH~i~: H~2~N–CHR–COO^−^ (tích điện −)

Giáo trình gọi điểm đẳng điện là **pH~i~** hoặc **pI**. Dựa vào sự tích điện, khả năng hấp thụ ánh sáng, phản ứng màu và độ tan khác nhau, người ta phân tích acid amin bằng các phương pháp ở mục 1.4.

**Phản ứng màu đặc hiệu** (Bảng 3.3, Giáo trình tr. 40):

| Phản ứng | Phát hiện | Thuốc thử | Màu |
|---|---|---|---|
| **Ninhydrin** | mọi α-acid amin | ninhydrin | xanh tím |
| **Sakaguchi** | **Arg** (nhóm guanidin) | α-naphtol + natri hypoclorit | đỏ |
| **Nitroprusiat** | **Cys** (–SH) | natri nitroprusiat / NH~4~OH | đỏ |
| Tạo sulfur chì | **Cys** | chì acetat / NaOH | xám đen (PbS) |
| **Pauly** | **His** (cả Tyr) | acid sulfanilic diazo hóa / kiềm | đỏ |
| **Xanthoprotein** | nhân thơm: **Tyr, Trp, Phe** | HNO~3~ đặc, đun sôi | vàng |
| **Adamkiewicz** (Hopkins–Cole) | **Trp** | acid glyoxylic / H~2~SO~4~ đặc | vòng đỏ tím |
| **Millon** | **Tyr** (–OH phenol) | Hg(NO~3~)~2~ / HNO~3~, đun nóng | đỏ |

> [!bay] Bảng 3.3 in nhầm vài chỗ
> - Phản ứng xanthoprotein dùng **HNO~3~ đặc** (nitro hóa nhân thơm), không phải "HNO~2~" như bảng in.
> - Phản ứng Adamkiewicz–Hopkins–Cole thực chất **đặc hiệu cho Trp** (nhân indol). Bảng ghi "Tyr, Trp".
> - Màu ninhydrin bảng ghi "xanh"; chính xác là **xanh tím** (tím Ruhemann). Prolin cho màu **vàng**.

> [!vi-du] Vì sao da tay dính HNO~3~ lại vàng?
> HNO~3~ nitro hóa nhân thơm của Tyr, Trp trong keratin da, tạo hợp chất nitro màu vàng. Đó chính là phản ứng xanthoprotein ngay trên tay.

### 1.4. Một số phương pháp phân tích acid amin

#### a) Chuẩn độ — xác định pI

(Giáo trình tr. 40–42) Khi thêm dần OH^−^ vào dung dịch acid amin ở dạng cation, pH tăng theo **đường cong chuẩn độ** có các "bậc" (vùng đệm) tại các pK~a~.

- **Glycin** (R không ion hóa): có 2 bậc, **pK~1~ = 2,34** (nhóm COOH), **pK~2~ = 9,60** (nhóm NH~3~^+^). pI nằm giữa: **pI = (pK~1~ + pK~2~)/2 = 5,97**.
- Mọi acid amin có R **không ion hóa** đều có đường cong giống glycin. Chỉ khác nhau ở giá trị: pK~1~ từ **1,8 đến 2,4**, pK~2~ từ **8,8 đến 11**.
- Acid amin có R **ion hóa được** (Glu, His…) có **3 bậc**, bậc thứ ba là của nhóm R:
  - **Glu**: pK~1~ 2,19; pK~R~ 4,25; pK~2~ 9,67. pI = trung bình **hai nhóm carboxyl** = (2,19 + 4,25)/2 = **3,22**.
  - **His**: pK~1~ 1,82; pK~R~ 6,0; pK~2~ 9,17. pI = trung bình **nhóm amin và nhân imidazol** = (6,0 + 9,17)/2 ≈ **7,59**.

> [!ghi-nho] Quy tắc tính pI
> Viết các pK~a~ theo thứ tự tăng dần. Chọn **hai pK~a~ kẹp dạng có điện tích tổng bằng 0**, rồi lấy trung bình. Với acid amin acid là hai pK~a~ **nhỏ**; với acid amin base là hai pK~a~ **lớn**.

#### b) Khả năng hấp thụ ánh sáng tử ngoại

- **Trp, Tyr, Phe** (nhân thơm) hấp thụ ánh sáng ở bước sóng **240–280 nm**. Cực đại của Trp và Tyr ở gần **280 nm** (Giáo trình tr. 42).
- Ở cùng nồng độ, **Trp hấp thụ mạnh gấp khoảng 4 lần Tyr**; Phe hấp thụ rất yếu.

> [!ung-dung] Đo protein bằng A~280~
> Hầu hết protein có Trp, Tyr. Vì thế đo độ hấp thụ ở **280 nm** là cách nhanh để ước lượng nồng độ protein trong phòng thí nghiệm, không cần thuốc thử. Nguyên lý đo quang (định luật Lambert–Beer) xem bài Vật lý vl-10.

#### c) Sắc ký

- **Sắc ký giấy**: các acid amin tan khác nhau trong dung môi nên di chuyển với tốc độ khác nhau.
- **Sắc ký trao đổi ion**: sắc ký cột với nhựa trao đổi anion (*anionid*) hoặc trao đổi cation (*cationid*); **sắc ký lỏng cao áp** (HPLC).

## 2. Peptid

### 2.1. Khái niệm

- **Peptid** gồm các acid amin nối với nhau bằng **liên kết peptid** (–CO–NH–). Cách hình thành liên kết peptid đã học ở hc-10, mục 3.5d.
- Tên theo số gốc: **dipeptid** (2), **tripeptid** (3)…; **oligopeptid**: vài chục gốc; **polypeptid**: nhiều gốc. Mỗi acid amin trong chuỗi gọi là một **gốc acid amin**.
- **Đánh số**: số **1** là gốc còn nhóm α-amin tự do (**N tận**); số **n** là gốc còn nhóm α-carboxyl tự do (**C tận**) (Giáo trình tr. 42–43).

**Tính chất liên kết peptid** (Giáo trình tr. 43):

- **Rất bền** trong điều kiện nội bào, vì phản ứng thủy phân cần năng lượng hoạt hóa cao.
- Muốn cắt nhanh phải có **enzym peptidase** (có ở mọi tế bào và mô). Trong phòng thí nghiệm, phải đun với **HCl 6M** (hoặc base mạnh) ở **110 °C trong 18–36 giờ** mới thủy phân hoàn toàn thành acid amin.
- Peptid cũng tích điện tùy pH (theo các gốc acid amin), nên chuẩn độ được và có **pH~i~ riêng**.

> [!vi-du] Vì sao chuỗi peptid gập được thành xoắn α? (đào sâu)
> Liên kết C–N của nhóm peptid mang **một phần tính chất liên kết đôi** (cặp electron của N liên hợp với C=O, như ở amid, hc-10 mục 2.4). Vì vậy 6 nguyên tử C~α~–CO–NH–C~α~ nằm **trên cùng một mặt phẳng** và không quay quanh C–N được. Chuỗi chỉ quay được ở hai liên kết hai bên C~α~. Số kiểu gập vì thế bị giới hạn, và xoắn α, gấp nếp β là những kiểu gập "vừa khít" nhất.

### 2.2. Một số peptid có hoạt tính sinh học

| Peptid | Số acid amin | Chức năng | Nguồn |
|---|---|---|---|
| **Vasopressin** (ADH) | 9 | Tái hấp thu nước ở ống thận | Bảng 3.4, tr. 43 |
| **Met-enkephalin** | 5 | Ức chế cảm giác đau (gắn thụ thể opioid) | Bảng 3.4 |
| **Gastrin nhỏ** | 17 | Kích thích dạ dày bài tiết HCl | Bảng 3.4 |
| **Glucagon** | 29 | Tăng glucose máu | Bảng 3.4 |
| **Bradykinin** | 9 | Gây giãn mạch | Bảng 3.4 |
| **Chất P** | 10 (thực tế 11) | Chất dẫn truyền thần kinh (cảm giác đau) | Bảng 3.4 |
| **Glutathion** | 3 | Chống oxy hóa trong tế bào, giải độc | bổ sung |
| **Oxytocin** | 9 | Co cơ tử cung, tiết sữa | bổ sung (hc-10) |
| **Insulin** | 51 (2 chuỗi) | Hạ glucose máu | tr. 44 |

> [!bay] Chất P có 11 acid amin
> Bảng 3.4 ghi chất P có 10 acid amin. Trình tự thật của chất P là **11 gốc** (Arg-Pro-Lys-Pro-Gln-Gln-Phe-Phe-Gly-Leu-Met-NH~2~). Nếu đề hỏi theo bảng của giáo trình thì chọn 10.

**Glutathion (GSH)** là tripeptid **γ-Glu-Cys-Gly**. Điểm đặc biệt: Glu nối với Cys qua nhóm **γ-carboxyl** của gốc R, không qua nhóm α-carboxyl như liên kết peptid thông thường. Nhờ vậy peptidase thường không cắt được nó.

- Nhóm **–SH** của Cys là phần hoạt động. Hai phân tử GSH nhường H, nối với nhau thành **GSSG** (cầu disulfur):

=> 2 GSH ⇌ GSSG + 2 H^+^ + 2 e^−^

- Trong hồng cầu, GSH phân hủy H~2~O~2~ (nhờ enzym glutathion peroxidase), nhờ đó bảo vệ màng hồng cầu và hemoglobin khỏi bị oxy hóa. Muốn tái tạo GSH từ GSSG, hồng cầu cần NADPH, do enzym **G6PD** cung cấp (xem sinh-hoc/sh-08, mục 9).
- Ở gan, GSH liên hợp với chất độc để thải ra ngoài. Quá liều paracetamol làm cạn GSH (xem hc-04, hc-10).

**Oxytocin và vasopressin** đều có **9 gốc**, có cầu disulfur nối Cys1–Cys6, và chỉ khác nhau ở **2 vị trí** (gốc 3 và gốc 8). Vậy mà một chất gây co tử cung, chất kia giữ nước ở thận. Đây là ví dụ cho thấy **cấu trúc bậc 1 quyết định chức năng**.

> [!ung-dung] Peptid làm thuốc
> - **Oxytocin** tiêm để gây chuyển dạ, chống chảy máu sau sinh. **Desmopressin** (dẫn xuất vasopressin) chữa đái tháo nhạt.
> - **Insulin** tiêm điều trị đái tháo đường. Insulin là peptid, bị enzym tiêu hóa cắt nên **không uống được**.
> - Thuốc **ức chế men chuyển** (captopril, enalapril) ban đầu được thiết kế từ peptid trong nọc rắn. Men chuyển (ACE) cũng là enzym **phân hủy bradykinin**; bradykinin ứ lại nên một số người dùng thuốc này bị **ho khan**.

> [!yhct] Thủy điệt (con đỉa) và hirudin — một peptid chống đông
> - Tuyến nước bọt của đỉa hút máu (*Hirudo medicinalis*) tiết **hirudin**, một polypeptid khoảng **65 acid amin**. Hirudin gắn trực tiếp vào **thrombin**, ức chế rất mạnh và đặc hiệu, nên máu không đông. Cơ chế này đã được chứng minh rõ; hirudin tái tổ hợp (lepirudin) và peptid tổng hợp **bivalirudin** từng hoặc đang được dùng làm thuốc chống đông.
> - Trong YHCT, **Thủy điệt** được xếp vào nhóm thuốc **phá huyết, trục ứ**. Cần phân biệt hai việc: hirudin chống đông là **cơ chế đã chứng minh**; còn chuyện vị thuốc khô đã qua sao, chế (nhiệt làm **biến tính** protein, mục 3.3) giữ được bao nhiêu hoạt tính và hiệu quả lâm sàng ra sao thì **bằng chứng còn hạn chế**, chủ yếu là thực nghiệm.
> - Thận trọng thực tế: không dùng cho **phụ nữ có thai**, người **đang chảy máu**, và người đang dùng **thuốc chống đông** hay chống kết tập tiểu cầu (nguy cơ chảy máu cộng hợp).

## 3. Protein

Giáo trình quy ước: **protein** là phân tử có **trên 50 acid amin** (Giáo trình tr. 43). Ranh giới với polypeptid chỉ là quy ước: insulin 51 gốc thường vẫn được gọi là hormon peptid.

### 3.1. Phân loại protein

**Theo cấu tạo** (Giáo trình tr. 43):

| Loại | Thủy phân cho | Ví dụ |
|---|---|---|
| **Protein thuần** (đơn giản) | Chỉ acid amin | Albumin, globulin, **histon** |
| **Protein tạp** (liên hợp) | Acid amin + **nhóm ngoại** (phần không phải acid amin) | Nhóm ngoại là glucid → **glycoprotein**; lipid → **lipoprotein**; acid nucleic → **nucleoprotein**; kim loại → **metalloprotein**; **hem** → hemoprotein (**hemoglobin**, myoglobin, cytochrom) |

**Theo hình dạng** (Giáo trình tr. 44) — dựa vào tỷ lệ chiều dài / chiều ngang:

| Loại | Tỷ lệ dài/ngang | Ví dụ | Đặc điểm |
|---|---|---|---|
| **Protein cầu** | **nhỏ hơn 10** | Enzym, protein huyết thanh (albumin, globulin), hemoglobin | Thường tan trong nước, làm nhiệm vụ "động" |
| **Protein sợi** | **lớn hơn 10** | **Keratin** của tóc, móng, vuốt; **collagen** của mô liên kết | Không tan, bền cơ học, làm nhiệm vụ cấu trúc |

### 3.2. Cấu trúc phân tử protein

#### 3.2.1. Các liên kết hóa học trong phân tử protein

(Giáo trình tr. 44)

| Liên kết | Hình thành giữa | Loại | Vai trò |
|---|---|---|---|
| **Peptid** –CO–NH– | α-COOH của gốc này và α-NH~2~ của gốc kia | Cộng hóa trị, rất bền | Tạo **bậc 1** |
| **Disulfur** –S–S– | Hai nhóm –SH của **hai Cys** (mất 2 H), cùng chuỗi hoặc khác chuỗi | Cộng hóa trị | Khóa bậc 3 (và nối chuỗi) |
| **Hydro** | H của nhóm imin (–NH–) và O của nhóm carbonyl (–CO–), cùng chuỗi hoặc khác chuỗi | Không cộng hóa trị, yếu nhưng rất nhiều | Tạo **bậc 2** |
| **Ion** (cầu muối) | –COO^−^ của gốc acid (Asp, Glu) và –NH~3~^+^ của gốc base (Lys, Arg) | Hút tĩnh điện | Bậc 3, bậc 4 |
| **Tương tác kỵ nước** | Các gốc hydrocarbon (phenyl, methyl, isobutyl…) quay vào nhau, tránh nước | Lực Van der Waals | Bậc 3, bậc 4 |

> [!ghi-nho] Hai liên kết cộng hóa trị, ba liên kết yếu
> Chỉ **peptid** và **disulfur** là liên kết **cộng hóa trị**. Hydro, ion, kỵ nước đều là liên kết **yếu**. Từng liên kết yếu dễ đứt, nhưng có hàng trăm liên kết nên giữ được hình dạng protein. Cũng vì chúng yếu nên protein dễ bị **biến tính** (mục 3.3).

#### 3.2.2. Các bậc cấu trúc

![Hình 1. Bốn bậc cấu trúc của phân tử protein](bac-cau-truc-protein.svg)

**Bậc 1** (Giáo trình tr. 44)

- Là **số lượng, thành phần và trật tự sắp xếp** các acid amin trong chuỗi polypeptid.
- Do **liên kết peptid** quyết định. Nghiên cứu bằng **phương pháp hóa học** (thủy phân, xác định trình tự).
- Ví dụ **insulin**: **51 acid amin**, gồm **chuỗi A (21 gốc)** và **chuỗi B (30 gốc)**. Insulin các loài khác nhau ở các vị trí **A8, A9, A10 và B30**.
- Insulin có **3 cầu disulfur**: 2 cầu **nối chuỗi A với chuỗi B** (A7–B7, A20–B19) và 1 cầu **trong chuỗi A** (A6–A11).

> [!ung-dung] Insulin lợn, insulin người
> Insulin lợn chỉ khác insulin người **một acid amin** (B30: Ala thay vì Thr). Nhờ vậy trước đây insulin lợn, bò được dùng chữa đái tháo đường. Ngày nay dùng insulin người **tái tổ hợp** và các **insulin analog**: đổi vài acid amin ở chuỗi B để insulin hấp thu nhanh hơn hoặc tác dụng kéo dài hơn. Đây là ứng dụng trực tiếp của hiểu biết về **cấu trúc bậc 1**.

> [!bay] Thay một acid amin có thể đổi cả chức năng
> Bậc 1 quyết định các bậc cao hơn. Ví dụ kinh điển: **HbS** chỉ thay **Glu → Val** ở vị trí 6 của chuỗi β mà gây bệnh hồng cầu hình liềm (mục 4.5).

**Bậc 2** (Giáo trình tr. 45)

- Là sự **xoắn đều đặn** hoặc **gấp nếp có chu kỳ** của chuỗi polypeptid. Do **liên kết hydro** giữa các nhóm –NH– và –CO– của **khung** chuỗi quyết định. Nghiên cứu bằng **nhiễu xạ tia X**.
- **Xoắn α** (ví dụ α-keratin):
  - Mỗi vòng xoắn 360° có **3,6 gốc acid amin**.
  - Liên kết hydro nằm **trong cùng một chuỗi**: nhóm C=O của gốc thứ n nối với N–H của gốc thứ **n + 4**, song song với trục xoắn.
  - Xoắn có thể theo chiều phải hoặc trái, nhưng **xoắn phải bền hơn**. Protein tạo từ L-acid amin hầu như chỉ có xoắn α phải.
  - Các gốc R chĩa **ra ngoài** trục xoắn.
- **Gấp nếp β**:
  - Liên kết hydro nằm **giữa hai chuỗi** (hoặc hai đoạn của cùng một chuỗi) nằm cạnh nhau.
  - Các chuỗi có thể **song song** (cùng chiều N→C) hoặc **đối song** (ngược chiều).
  - Các gốc R nằm luân phiên **trên và dưới** mặt phẳng nếp gấp.

> [!bay] Liên kết hydro của bậc 2 ở đâu?
> - Bậc 2 dùng liên kết hydro giữa các nhóm **của khung** (C=O và N–H của liên kết peptid), **không** phải giữa các gốc R. Liên kết giữa các **gốc R** thuộc về **bậc 3**.
> - Xoắn α: liên kết hydro **trong một chuỗi**. Gấp nếp β: liên kết hydro **giữa các chuỗi/đoạn chuỗi**.
> - Giáo trình viết NH của gốc thứ nhất nối với CO của gốc "thứ tư". Cách nói chuẩn hiện nay là C=O của gốc **n** với N–H của gốc **n + 4** (bỏ qua 3 gốc ở giữa).

> [!cap-nhat] "β-keratin của tóc"
> Giáo trình lấy β-keratin của tóc làm ví dụ gấp nếp β. Hiện nay tóc, móng được xếp là **α-keratin** (xoắn α cuộn lại). Tóc chỉ chuyển một phần sang dạng β khi bị **kéo căng, hấp nóng ẩm**. Ví dụ kinh điển của gấp nếp β là **fibroin của tơ tằm** (và β-keratin của lông vũ, vảy bò sát). Đi thi vẫn trả lời theo giáo trình.

**Bậc 3** (Giáo trình tr. 46)

- Là **cấu trúc không gian ba chiều** của **một** chuỗi polypeptid. Chuỗi vừa xoắn vừa gấp khúc một cách dày đặc và phức tạp. Những đoạn ở **xa nhau trong trình tự** có thể nằm **sát nhau trong không gian**.
- Giữ bởi **liên kết disulfur, liên kết ion, tương tác kỵ nước** (và liên kết hydro) giữa các **gốc R**.
- Quy luật chung ở protein cầu tan trong nước: gốc **kỵ nước** dồn vào **lõi**, gốc **phân cực, tích điện** quay **ra ngoài** tiếp xúc với nước.
- Ví dụ: **myosin, trypsin**, mỗi **chuỗi polypeptid của hemoglobin**. Nghiên cứu bằng **nhiễu xạ tia X**.

**Bậc 4** (Giáo trình tr. 46)

- Là sự **sắp xếp tương hỗ** của **từ 2 chuỗi polypeptid trở lên** trong một phân tử protein. Mỗi chuỗi (gọi là **tiểu đơn vị**) đã có sẵn cấu trúc bậc 2, bậc 3 riêng.
- Các chuỗi gắn với nhau bằng **liên kết ion và tương tác kỵ nước**.
- Ví dụ điển hình: **hemoglobin, 4 chuỗi**. Nghiên cứu bằng nhiễu xạ tia X.

> [!bay]
> - **Insulin** có 2 chuỗi nhưng **không** được xem là có bậc 4: hai chuỗi nối bằng **cầu disulfur** (cộng hóa trị) và đều sinh ra từ **một** tiền chất (proinsulin). Bậc 4 là các chuỗi **riêng rẽ**, gắn bằng liên kết **không cộng hóa trị**.
> - **Myoglobin** chỉ có 1 chuỗi nên cao nhất là **bậc 3**. **Hemoglobin** có **bậc 4**.

### 3.3. Tính chất lý hóa của protein

#### 3.3.1. Lưỡng tính và pH đẳng điện

(Giáo trình tr. 46)

- Tính chất của protein phụ thuộc thành phần acid amin của nó. Giáo trình đưa tiêu chí:

=> (Lys + Arg) / (Glu + Asp) > 1 → protein **tính base**; < 1 → protein **tính acid**

- Ví dụ protein base: **histon** (giàu Lys, Arg, tích điện dương nên gắn chặt với ADN (DNA) mang điện âm). Đa số protein huyết tương (albumin) có tính acid: pHi khoảng 4,7–5, nên ở pH máu 7,4 chúng **tích điện âm**.
- **pHi** của protein là pH mà tại đó **tổng điện tích âm bằng tổng điện tích dương**. Tại pHi, protein **không di chuyển** trong điện trường.
- pH < pHi: protein tích điện **dương**; pH > pHi: tích điện **âm**.
- Ứng dụng: tách và phân tích protein bằng **điện di**, **sắc ký ái lực**, **sắc ký trao đổi ion** (mục 3.5).

#### 3.3.2. Hòa tan, kết tủa và biến tính

**Hòa tan** (Giáo trình tr. 46). Trong nước, protein tồn tại ở dạng **dung dịch keo**. Đa số protein tan trong dung dịch **muối loãng**. Hai yếu tố giữ protein tan:

1. **Lớp áo nước** (lớp vỏ hydrat) bao quanh các nhóm phân cực trên bề mặt phân tử.
2. Các phân tử protein **tích điện cùng dấu** nên đẩy nhau, không kết dính lại.

**Kết tủa.** Làm **mất lớp áo nước và trung hòa điện tích** thì protein kết tủa. Các cách thường dùng:

| Cách làm kết tủa | Phá yếu tố nào | Protein có bị biến tính? |
|---|---|---|
| **Muối trung tính nồng độ cao** ((NH~4~)~2~SO~4~, NaCl bão hòa) — "diêm tích" | Muối giành nước → **mất áo nước** | Thường **không** (hòa tan lại được) |
| Đưa **pH về pHi** | **Mất điện tích** → hết lực đẩy | Thường không |
| **Dung môi hữu cơ** (ethanol, aceton), nhất là khi lạnh | Giành nước, giảm hằng số điện môi | Ở nhiệt độ thường dễ biến tính |
| **Muối kim loại nặng** (Hg^2+^, Pb^2+^, Ag^+^, Cu^2+^) | Gắn vào nhóm –COO^−^, –SH | **Có** |
| **Acid mạnh** (acid tricloracetic, acid sulfosalicylic) | Trung hòa điện, phá cấu trúc | **Có** |

> [!ung-dung] Kết tủa protein trong thực tế
> - **Protein niệu**: nhỏ **acid sulfosalicylic** hoặc **đun nóng** nước tiểu (có thêm acid acetic) → vẩn đục nếu có protein (bệnh thận). Que thử nước tiểu hiện nay dùng nguyên lý "sai số protein" của chất chỉ thị pH.
> - **Ngộ độc kim loại nặng** (Hg, Pb, Cu…): uống **sữa, lòng trắng trứng** để protein trong đó gắn kim loại thay cho protein niêm mạc. Đây chỉ là sơ cứu tạm thời, vẫn phải đến cơ sở y tế.
> - Phân đoạn **globulin huyết thanh** bằng amoni sulfat ở các nồng độ khác nhau (globulin tủa trước, albumin tủa sau) — ứng dụng ở mục 3.5.

**Biến tính** (Giáo trình tr. 47)

- Protein bị biến tính khi **cấu trúc bậc 2, bậc 3, bậc 4 bị thay đổi hoặc đảo lộn**. Mọi liên kết có thể bị đứt **trừ liên kết peptid**, nên **bậc 1 vẫn còn nguyên**.
- Hậu quả: độ nhớt, độ hòa tan thay đổi (thường kém tan, dễ tủa); **hoạt tính sinh học giảm hoặc mất**.
- Tác nhân **vật lý**: nhiệt độ cao, áp suất cao, tia tử ngoại. Tác nhân **hóa học**: acid mạnh, kiềm mạnh, muối kim loại nặng (thêm: ure nồng độ cao, chất khử cầu disulfur, chất tẩy rửa, ethanol).
- **Biến tính không thuận nghịch**: loại bỏ tác nhân rồi mà protein **không** trở lại trạng thái ban đầu (ví dụ lòng trắng trứng luộc chín).
- **Biến tính thuận nghịch**: loại bỏ tác nhân thì protein trở lại như cũ, hoặc gần như cũ.

> [!vi-du] Thí nghiệm ribonuclease — bậc 1 "chứa sẵn" bậc 3
> - **Ribonuclease** là enzym có **một chuỗi 124 acid amin** với **4 cầu disulfur**.
> - Cho enzym vào dung dịch **ure 8M** (phá liên kết hydro, kỵ nước) có **β-mercaptoethanol** HO–CH~2~–CH~2~–SH (khử cầu –S–S– thành hai nhóm –SH). Chuỗi duỗi ra, **mất hoạt tính enzym**.
> - Loại bỏ ure và β-mercaptoethanol (thẩm tích), để các nhóm –SH bị **oxy hóa trở lại bởi không khí**. Chuỗi tự gập lại, các cầu disulfur nối **đúng cặp**, **hoạt tính được phục hồi** (Giáo trình tr. 47, Hình 3.8–3.9).
> - Kết luận (Anfinsen, giải Nobel Hóa học 1972): **trình tự acid amin (bậc 1) chứa đủ thông tin để protein tự gập thành cấu trúc không gian đúng**.

> [!ung-dung] Biến tính trong y học và đời sống
> - **Tiệt khuẩn** bằng nhiệt (hấp ướt), cồn 70°, tia UV: đều làm biến tính protein của vi sinh vật.
> - **Sốt quá cao** (trên 41–42 °C) nguy hiểm một phần vì protein, enzym của cơ thể bắt đầu biến tính.
> - **Bảo quản** chế phẩm protein (vaccin, insulin, albumin, enzym) ở **2–8 °C**, tránh đông đá, tránh lắc mạnh.
> - Nấu chín thức ăn làm protein **biến tính**: chuỗi duỗi ra nên enzym tiêu hóa cắt **dễ hơn**.
> - Cấu trúc gập **sai** rồi kết tụ thành sợi gây các bệnh **amyloid**, trong đó có bệnh do **prion** (bò điên).

### 3.4. Chức năng của protein

(Giáo trình tr. 48) — chia hai nhóm:

| Nhóm | Chức năng | Ví dụ |
|---|---|---|
| **Protein chức năng** | **Xúc tác** | Các **enzym** |
| | **Vận chuyển** | **Hemoglobin** (O~2~), **transferrin** (sắt), **ceruloplasmin** (đồng), protein chở hormon; albumin chở thuốc, chất độc |
| | **Bảo vệ** | **Kháng thể** IgA, IgE, IgM, IgG; **interferon** (chống virus, vi khuẩn); **fibrin** (cục máu đông) |
| | **Điều hòa, vận động** | Protein **co cơ**: myosin, actin; **histon** điều hòa sao chép, phiên mã; hormon peptid |
| **Protein cấu trúc** | Tạo mô liên kết, khung xương, cấu tạo cơ thể | **Collagen**, **elastin**, keratin |

> [!ung-dung] Protein huyết tương trên phiếu xét nghiệm
> *(Khoảng tham chiếu tham khảo, mỗi phòng xét nghiệm có khoảng riêng.)*
> - **Protein toàn phần** huyết thanh: khoảng **60–80 g/L**; **albumin**: khoảng **35–50 g/L**.
> - Albumin do **gan** tổng hợp, giữ **áp lực keo** giữ nước trong lòng mạch. Albumin giảm (xơ gan, thận hư, suy dinh dưỡng) → **phù**.
> - **Ferritin, transferrin**: đánh giá dự trữ và vận chuyển sắt. **Ceruloplasmin giảm** gợi ý bệnh **Wilson** (ứ đồng).

### 3.5. Một số phương pháp nghiên cứu protein

(Giáo trình tr. 48–49) Phần lớn dựa vào **sự tích điện** của protein:

1. **Kết tủa phân đoạn** bằng dung dịch muối trung tính ở các nồng độ khác nhau.
2. **Điện di** trên giấy hoặc trên gel **polyacrylamid**. (Ứng dụng điện di protein huyết thanh đã nêu ở hc-10, mục 3.5a.)
3. **Sắc ký trao đổi ion** trên cột.

**Sắc ký trao đổi ion — nguyên lý.** Nhựa là chất **không tan** (agarose, polyacrylamid, cellulose, thủy tinh…) có gắn **cộng hóa trị** các nhóm tích điện:

| Nhựa | Nhóm gắn trên nhựa | Nhựa giữ lại | Tên gọi |
|---|---|---|---|
| **Carboxymethyl (CM)** | R–CH~2~–COO^−^ (tích điện **âm**) | **Cation** (protein tích điện dương) | **Nhựa trao đổi cation** |
| **Diethylaminoethyl (DEAE)** | R–NH^+^(C~2~H~5~)~2~ (tích điện **dương**) | **Anion** | **Nhựa trao đổi anion** |

- Phân tử **cùng dấu** với nhựa bị đẩy, ra khỏi cột **đầu tiên**. Phân tử **trái dấu** bị giữ lại, ra sau. Càng tích điện trái dấu mạnh thì ra càng muộn.
- Ví dụ của giáo trình (Hình 3.10, tr. 49): hỗn hợp **Hb F, A~1~, A~2~, S, C** tách trên cột **CM-Sephadex C-50** (trao đổi cation) với pH tăng dần. Thứ tự ra khỏi cột: **F → A → A~2~ → S → C**.

> [!vi-du] Vì sao HbS và HbC ra sau HbA?
> HbS thay **Glu → Val**, HbC thay **Glu → Lys** ở vị trí 6 chuỗi β. Mất một gốc âm (S), hoặc đổi gốc âm thành gốc dương (C), làm phân tử **bớt âm, thêm dương**. Trên nhựa CM (mang điện âm), chúng bị giữ chặt hơn nên ra muộn hơn HbA; HbC ra muộn nhất. Cùng lý do đó, khi **điện di ở pH kiềm** (8,6), HbS và HbC chạy về cực dương **chậm hơn** HbA. Đây là cơ sở xét nghiệm **điện di hemoglobin** chẩn đoán bệnh hemoglobin.

## 4. Hemoglobin

**Hemoglobin (Hb)** là một **protein tạp** (hemoprotein), nhóm ngoại là **hem**. Chức năng chính: **vận chuyển O~2~ và CO~2~**. Hb còn là một **hệ đệm** quan trọng của cơ thể (Giáo trình tr. 49).

### 4.1. Cấu trúc phân tử hemoglobin

Phân tử Hb gồm: **4 hem**, **globin** (4 chuỗi polypeptid) và **1 phân tử 2,3-DPG**.

**Hem** (Giáo trình tr. 49–50)

- **Porphin**: 4 vòng **pyrol** (đánh số I, II, III, IV) nối với nhau qua 4 **cầu methylen** (=CH–), ký hiệu **α, β, γ, δ**.
- Thay 8 vị trí ở vòng ngoài của porphin bằng các nhóm thế (methyl, ethyl, vinyl, acetat, propionat) được các **porphyrin**. Trong cơ thể chủ yếu là **protoporphyrin IX** (4 methyl, 2 vinyl, 2 propionat).
- **Hem = protoporphyrin IX + Fe^2+^**. Fe^2+^ nằm ở **trung tâm**, liên kết với **4 nguyên tử N** của 4 vòng pyrol, trên mặt phẳng vòng porphyrin.
- Fe^2+^ còn **2 vị trí phối trí** ở hai phía mặt phẳng: một vị trí gắn với **His F8** của globin (His "gần"), vị trí còn lại để **gắn O~2~**. Hem nằm trong một "túi" kỵ nước của chuỗi globin, nhờ đó Fe^2+^ ít bị oxy hóa.

> [!bay] Oxy **hóa** và oxy **gắn**
> Khi gắn O~2~, sắt **vẫn là Fe^2+^**. Đây là phản ứng **oxygen hóa** (gắn oxy thuận nghịch), không phải **oxy hóa** Fe^2+^ → Fe^3+^. Nếu Fe bị oxy hóa thành Fe^3+^ thì thành **methemoglobin**, và Hb mất khả năng chở O~2~ (mục 4.3).

**Globin** (Giáo trình tr. 50)

- Globin là phần protein của Hb, quyết định **đặc tính chủng loại** của Hb.
- Mỗi phân tử Hb có **4 chuỗi polypeptid**. Mỗi chuỗi có **8 đoạn xoắn** (α-helix), ký hiệu **A, B, C, D, E, F, G, H**. Đoạn không xoắn nằm giữa hai đoạn xoắn được gọi theo tên ghép, ví dụ **AB** là đoạn giữa xoắn A và xoắn B.
- Mỗi chuỗi globin có cấu trúc bậc 2, bậc 3; bốn chuỗi ghép lại thành **bậc 4**.
- **HbA~1~** = **α~2~β~2~**: 2 chuỗi **α (141 acid amin)** + 2 chuỗi **β (146 acid amin)**. Mỗi chuỗi mang **1 hem** → Hb chở tối đa **4 O~2~**.
- **TLPT** của Hb khoảng **64 000**.

**2,3-DPG** (2,3-diphosphoglycerat; nay thường gọi 2,3-BPG, bisphosphoglycerat) (Giáo trình tr. 50)

- Tạo ra từ **thoái hóa glucose** (một nhánh rẽ của đường phân trong hồng cầu). Nồng độ trong **hồng cầu đặc biệt cao**.
- Một phân tử 2,3-DPG nằm ở **khoang trung tâm** của Hb, tỷ lệ **1:1** (mol), **liên kết muối với 2 chuỗi β**.
- Tác dụng: **làm giảm ái lực của Hb với O~2~** → giúp Hb nhả O~2~ cho mô.

> [!vi-du] Vì sao 2,3-DPG làm giảm ái lực?
> 2,3-DPG mang nhiều điện tích âm (một nhóm COO^−^ và hai nhóm phosphat). Nó lọt vừa khoang trung tâm của Hb ở dạng **khử oxy** (dạng T, "căng"), gắn bằng liên kết ion với các gốc tích điện dương (His, Lys) của hai chuỗi β. Khi Hb gắn O~2~ và chuyển sang dạng R ("giãn"), khoang này hẹp lại, đẩy 2,3-DPG ra. Vậy 2,3-DPG **ổn định dạng khử oxy**, khiến Hb khó giữ O~2~ hơn.

### 4.2. Các hemoglobin ở người bình thường

(Giáo trình tr. 51)

| Loại | Thành phần | Tỷ lệ | Ghi chú |
|---|---|---|---|
| **HbA~1~** | α~2~β~2~ | **≈ 98%** Hb người trưởng thành | α 141, β 146 acid amin |
| **HbA~2~** | α~2~δ~2~ | **≈ 2%** | Điện di trên giấy chạy **chậm hơn** HbA~1~ |
| **HbF** (bào thai) | α~2~γ~2~ | Lúc mới sinh **≈ 80%** → 2–3 tháng **≈ 50%** → 1 tuổi **dưới 0,5%** | Tạo từ thời kỳ bào thai |

- **Thời kỳ phôi** (vài tuần đầu) còn có chuỗi **ζ (zeta)** và **ε (epsilon)** tạo các Hb phôi.
- Chuỗi **α** có mặt từ rất sớm và giữ ổn định suốt đời. Chuỗi **γ** cao trong bào thai rồi giảm dần sau sinh; chuỗi **β** tăng dần, chiếm ưu thế từ vài tháng sau sinh (Hình 3.13, tr. 51).

> [!ung-dung] HbF — chở oxy từ mẹ sang con
> Chuỗi γ khác chuỗi β ở chỗ gắn 2,3-DPG (gốc His 143 của β được thay bằng Ser ở γ, bớt một điện tích dương). Vì vậy **HbF gắn 2,3-DPG yếu hơn** → **ái lực với O~2~ cao hơn** HbA (đường cong **dịch trái**). Ở bánh nhau, HbF của thai "giành" được O~2~ từ HbA của mẹ.
> Thuốc **hydroxyurea** kích thích tạo lại HbF ở người lớn, được dùng điều trị bệnh hồng cầu hình liềm.

### 4.3. Tính chất của hemoglobin

#### a) Kết hợp với oxy

(Giáo trình tr. 52) Hb kết hợp **thuận nghịch** với O~2~. Mức gắn phụ thuộc **H^+^, 2,3-DPG, CO~2~ và nhiệt độ**:

=> HHb(DPG)(CO~2~) + O~2~ ⇌ HbO~2~ + H^+^ + DPG + CO~2~

- **Tính hợp tác**: khi **một** trong bốn tiểu đơn vị đã gắn O~2~, **ái lực của các tiểu đơn vị còn lại tăng lên**, nên chúng gắn O~2~ dễ hơn. Vì vậy đường cong phân ly oxy của Hb có **hình chữ S (sigma)**.
- Một phân tử Hb kết hợp và vận chuyển được **4 phân tử O~2~**.

![Hình 2. Đường cong phân ly oxy của myoglobin và hemoglobin; các yếu tố làm dịch chuyển đường cong của Hb](duong-cong-phan-ly-oxy.svg)

**Đọc đường cong.** **P~50~** là phân áp O~2~ làm Hb bão hòa 50%. **P~50~ càng thấp thì ái lực càng cao.**

- Ở **phổi** (pO~2~ ≈ 100 mmHg), Hb gần bão hòa hoàn toàn (≈ 97–98%).
- Ở **mô** lúc nghỉ (pO~2~ ≈ 40 mmHg), Hb còn bão hòa ≈ 75%, tức đã nhả khoảng 1/4 lượng O~2~. Khi mô hoạt động mạnh (pO~2~ ≈ 20 mmHg), đoạn dốc của đường sigma giúp Hb nhả thêm rất nhiều O~2~ chỉ với một chút giảm pO~2~.
- Đường cong hình sigma là lợi thế: **gắn đầy ở phổi, nhả nhiều ở mô**. Myoglobin (đường hyperbol) thì ở 40 mmHg vẫn gần bão hòa, nên nó **giữ** O~2~ chứ không "giao" O~2~.

**Hiệu ứng Bohr và các yếu tố dịch chuyển đường cong** *(phần giải thích cơ chế là bổ sung; giáo trình nêu ở dạng phương trình trên)*

| Yếu tố | Đường cong | Ý nghĩa |
|---|---|---|
| **↑ H^+^ (↓ pH)** — **hiệu ứng Bohr** | Dịch **phải** | Mô hoạt động sinh acid → Hb nhả O~2~ đúng nơi cần |
| **↑ CO~2~** | Dịch **phải** | CO~2~ tạo H^+^ và gắn trực tiếp vào globin |
| **↑ Nhiệt độ** | Dịch **phải** | Cơ đang co, sốt |
| **↑ 2,3-DPG** | Dịch **phải** | Tăng khi lên **vùng cao**, **thiếu máu** mạn → thích nghi |
| HbF, **CO**, methemoglobin | Dịch **trái** | Giữ chặt O~2~, khó nhả cho mô |
| ↓ H^+^ (kiềm), ↓ nhiệt độ, ↓ 2,3-DPG | Dịch **trái** | Máu dự trữ lâu ngày mất 2,3-DPG |

**Cơ chế hiệu ứng Bohr (tóm tắt).** Khi Hb nhả O~2~, một số gốc (nhất là **His** ở đầu C chuỗi β) nhận H^+^. Gốc này tích điện dương, tạo **cầu muối** ổn định dạng khử oxy. Ngược lại, H^+^ nhiều thì dạng khử oxy được ưu tiên, Hb nhả O~2~. Ở phổi xảy ra chiều ngược lại: Hb gắn O~2~, **nhả H^+^**; H^+^ kết hợp HCO~3~^−^ tạo CO~2~ để thở ra.

> [!bay]
> - **Dịch phải = ái lực giảm = P~50~ tăng = nhả O~2~ dễ hơn.** Đừng nghĩ "dịch phải" là "tốt hơn cho việc gắn O~2~".
> - Hiệu ứng Bohr nói về **H^+^ và CO~2~**. 2,3-DPG cũng làm dịch phải nhưng **không** gọi là hiệu ứng Bohr.
> - Đường cong trong giáo trình (Hình 3.15, tr. 53) vẽ **Hb đã loại CO~2~ và DPG** (ái lực rất cao) bên cạnh Hb **trong hồng cầu** (dịch phải hẳn). Hình đó cho thấy chính 2,3-DPG và CO~2~ trong hồng cầu đã kéo đường cong sang phải.

#### b) Kết hợp với CO~2~ — dẫn xuất carbamin

CO~2~ gắn vào nhóm **–NH~2~ tự do** (đầu N) của globin, tạo **carbaminohemoglobin** (Giáo trình tr. 52):

=> Hb–NH~2~ + CO~2~ → Hb–NH–COOH

Phần lớn CO~2~ trong máu được chở ở dạng **HCO~3~^−^** trong huyết tương; dạng carbamin chỉ là một phần nhỏ (sẽ học ở chương Khí máu và thăng bằng acid–base).

#### c) Kết hợp với CO — carboxyhemoglobin

=> HbO~2~ + CO → HbCO + O~2~

- **Ái lực của Hb với CO mạnh gấp khoảng 210 lần với O~2~** (Giáo trình tr. 52). Một lượng nhỏ CO trong không khí đã chiếm nhiều hem. Ngoài ra HbCO làm các hem còn lại **giữ chặt O~2~** (dịch trái), nên mô càng thiếu O~2~.
- Phần hóa học vô cơ của CO và các số liệu khác nhau giữa các sách xem bài hoa-hoc/vc-04, mục CO.

> [!ung-dung] Ngộ độc CO
> - Hay gặp khi **đốt than** sưởi trong phòng kín, chạy **máy phát điện** trong nhà, cháy nhà.
> - Da, niêm mạc có thể **đỏ hồng** (màu đỏ tươi của HbCO), không tím, nên dễ bỏ sót.
> - **Máy đo SpO~2~ thông thường cho kết quả "bình thường" giả**, vì nó không phân biệt được HbCO với HbO~2~. Phải định lượng **HbCO** bằng máy khí máu có bộ đo CO-oximetry. *(Tham khảo: người không hút thuốc dưới 3%; người hút thuốc có thể tới khoảng 10%.)*
> - Xử trí: đưa ra chỗ thoáng, **thở O~2~ nồng độ cao** (oxy cao áp nếu nặng). O~2~ nhiều sẽ cạnh tranh đẩy CO ra khỏi hem.

#### d) Sự oxy hóa Hb — methemoglobin

Một số chất oxy hóa (**nitrit, clorat, ferricyanid**) oxy hóa Fe^2+^ của hem thành Fe^3+^, tạo **methemoglobin (MetHb)** (Giáo trình tr. 52):

=> Hb(Fe^2+^) → MetHb(Fe^3+^) + e^−^

**MetHb không vận chuyển được O~2~.** Bình thường hồng cầu luôn có enzym khử MetHb trở lại Hb (cần NADH), nên MetHb chỉ khoảng **1–2%** Hb toàn phần (tham khảo).

> [!ung-dung] Methemoglobin máu
> - Nguyên nhân hay gặp: ngộ độc **nitrit** (muối diêm trong thịt muối, nước giếng nhiều nitrat ở trẻ nhũ nhi), thuốc **dapson**, thuốc tê **benzocain**, anilin (xem vc-03, vc-04, hc-10).
> - Biểu hiện: **tím tái** không cải thiện khi thở O~2~, máu màu **nâu sô-cô-la**.
> - Giải độc: **xanh methylen** giúp khử Fe^3+^ trở lại Fe^2+^. **Không dùng** cho người **thiếu G6PD** (có thể gây tan máu).

#### e) Hoạt tính peroxidase

Hb có hoạt tính giống **peroxidase**: xúc tác H~2~O~2~ oxy hóa một chất màu (AH~2~) (Giáo trình tr. 52):

=> AH~2~ + H~2~O~2~ → A + 2 H~2~O

Ứng dụng: **tìm máu trong nước tiểu** (và trong phân).

> [!ung-dung] Ô "máu" (BLD) trên que thử nước tiểu
> Que thử dùng chính phản ứng peroxidase này nên **dương tính với cả hồng cầu, Hb tự do và myoglobin**. Que dương tính mà soi **không thấy hồng cầu** thì nghĩ đến **tan máu** (Hb niệu) hoặc **tiêu cơ vân** (myoglobin niệu). Xét nghiệm tìm **máu ẩn trong phân** kiểu cũ (guaiac) cũng dựa trên nguyên lý này.

#### f) Tính chất đệm

Hb có nhiều gốc **His** (pK~a~ ≈ 6–7), nên là hệ đệm quan trọng của máu. Xem chương Khí máu và thăng bằng acid–base.

### 4.4. Xét nghiệm hemoglobin thường gặp *(bổ sung)*

*(Khoảng tham chiếu tham khảo, mỗi phòng xét nghiệm có khoảng riêng.)*

| Xét nghiệm | Giá trị tham khảo | Ý nghĩa |
|---|---|---|
| **Nồng độ Hb** trong máu | Nam ≈ **130–170 g/L**; nữ ≈ **120–150 g/L** | Giảm = **thiếu máu** (theo WHO: dưới 130 g/L ở nam, dưới 120 g/L ở nữ không mang thai) |
| **HbA1c** | Bình thường **dưới 5,7%** | Đánh giá đường huyết trung bình 2–3 tháng; **≥ 6,5%** là một tiêu chuẩn chẩn đoán đái tháo đường |
| **Điện di Hb** | HbA ≈ 96–98%; HbA~2~ ≈ **2–3,5%**; HbF dưới 1% | Phát hiện HbS, HbE, HbH, β-thalassemia (HbA~2~ tăng) |
| **HbCO** | Dưới 3% (không hút thuốc) | Ngộ độc CO |
| **MetHb** | Khoảng 1–2% | Ngộ độc nitrit, thuốc |

> [!ung-dung] HbA1c — glucose "đánh dấu" lên hemoglobin
> - Glucose trong máu tự gắn (không cần enzym) vào nhóm **–NH~2~ của Val đầu N chuỗi β**. Phản ứng này là **glycat hóa** (*glycation*), không phải glycosyl hóa có enzym (phân biệt ở [hs-01 mục 6.2](#/bai/nam-1/hoa-sinh/hs-01)). Sản phẩm là **HbA1c**.
> - Glucose máu càng cao thì HbA1c càng cao. Hồng cầu sống khoảng **120 ngày**, nên HbA1c phản ánh đường huyết **trung bình 2–3 tháng** trước, không phụ thuộc bữa ăn.
> - Ngưỡng tham khảo (ADA, Bộ Y tế): **dưới 5,7%** bình thường; **5,7–6,4%** tiền đái tháo đường; **≥ 6,5%** đái tháo đường. Mục tiêu điều trị cho đa số người bệnh là **dưới 7%**.
> - **Sai lệch**: tuổi hồng cầu bị rút ngắn (**tan máu, mất máu, thalassemia**, mới truyền máu) làm HbA1c **thấp giả**. Một số biến thể Hb (HbE, HbS) gây nhiễu tùy phương pháp đo. Ở các bệnh nhân này cần đánh giá đường huyết bằng cách khác.

### 4.5. Hemoglobin bất thường *(bổ sung)*

Cơ chế di truyền của các bệnh dưới đây đã học ở **sinh-hoc/sh-09** (HbE, lỗi cắt nối) và **sinh-hoc/sh-10** (đột biến gen, HbS, β-thalassemia ở Việt Nam). Ở đây chỉ nêu **hậu quả hóa sinh**.

Có hai kiểu rối loạn:

| Kiểu | Bản chất | Ví dụ |
|---|---|---|
| **Bệnh Hb về chất** | Chuỗi globin **sai một acid amin** | **HbS** (β6 Glu → Val), **HbC** (β6 Glu → Lys), **HbE** (β26 Glu → Lys) |
| **Bệnh Hb về lượng** — **thalassemia** | Chuỗi globin **bình thường nhưng thiếu** | **α-thalassemia** (thiếu chuỗi α), **β-thalassemia** (thiếu chuỗi β) |

**HbS — bệnh hồng cầu hình liềm**

- Glu (tích điện âm, ưa nước) thay bằng **Val (kỵ nước)** trên **bề mặt** chuỗi β.
- Khi **thiếu O~2~**, gốc Val này dính vào một "túi" kỵ nước của phân tử HbS bên cạnh. Các phân tử **trùng hợp thành sợi dài**, làm hồng cầu biến dạng **hình liềm**, cứng, dễ vỡ (tan máu) và gây **tắc mạch nhỏ** (cơn đau).
- Người **dị hợp** (HbAS) ít triệu chứng và kháng sốt rét tốt hơn. Vì vậy gen HbS phổ biến ở vùng sốt rét châu Phi; ở Việt Nam hiếm.

**Thalassemia** — rất quan trọng ở Việt Nam

- **β-thalassemia**: chuỗi β thiếu → chuỗi α thừa, tủa lại trong hồng cầu non, gây tan máu và tạo máu không hiệu quả. Cơ thể bù bằng chuỗi δ và γ, nên **HbA~2~ (α~2~δ~2~) tăng** (trên 3,5%, dấu hiệu chẩn đoán người mang gen) và **HbF tăng**.
- **α-thalassemia**: chuỗi α thiếu → chuỗi thừa tự ghép 4 với nhau: **HbH (β~4~)** ở người lớn, **Hb Bart's (γ~4~)** ở thai. Hai loại này có **ái lực O~2~ rất cao** và không có tính hợp tác, nên gần như không nhả O~2~ cho mô. Thai mất cả 4 gen α (chỉ có Hb Bart's) bị **phù thai**, thường tử vong.
- Người **mang gen** thường chỉ thiếu máu nhẹ, hồng cầu **nhỏ, nhược sắc** (MCV, MCH giảm).

> [!ung-dung] Thalassemia — sàng lọc trước hôn nhân, trước sinh
> - Theo Viện Huyết học – Truyền máu TƯ, Việt Nam có khoảng **hơn 10% dân số mang gen** thalassemia (tỷ lệ cao hơn ở một số dân tộc miền núi). **HbE** cũng rất phổ biến ở Đông Nam Á.
> - Hai người cùng mang gen kết hôn: mỗi lần mang thai có **25%** nguy cơ con bị bệnh nặng. Vì vậy cần **xét nghiệm công thức máu, điện di Hb** trước khi kết hôn hoặc khi mang thai.
> - **Bẫy lâm sàng**: thiếu máu hồng cầu nhỏ **không phải lúc nào cũng do thiếu sắt**. Người mang gen thalassemia mà uống sắt kéo dài sẽ bị **ứ sắt**. Cần kiểm tra **ferritin** trước khi bổ sung sắt lâu dài. Người bệnh nặng phải truyền máu định kỳ và dùng **thuốc thải sắt**.

## 5. Myoglobin

(Giáo trình tr. 52–53)

- **Myoglobin (Mb)** là protein của **cơ**, chiếm khoảng 2% tổng protein của cơ. Cơ càng nhiều Mb thì càng đỏ (cơ tim, cơ chân của chim bay xa, cơ của động vật lặn như cá nhà táng).
- Gồm **1 chuỗi polypeptid** (khoảng **153 acid amin**) kết hợp với **1 hem**. TLPT khoảng **17 000**.
- Chuỗi của Mb **giống** chuỗi globin của Hb: khoảng **75% chuỗi là xoắn α**, có **8 đoạn xoắn** (A–H), xoắn theo chiều phải.
- So sánh trình tự đoạn xoắn F (F1–F9) giữa Mb cá nhà táng và chuỗi α, β của Hb người: hai vị trí **F4 (Leu)** và **F8 (His)** **giống nhau ở cả ba chuỗi**. His F8 chính là gốc **gắn với Fe** của hem, nên nó được bảo tồn qua tiến hóa.
- Mb chỉ có **một** vị trí gắn O~2~:

=> Mb + O~2~ ⇌ MbO~2~

- Mb gắn và nhả O~2~ ở **phân áp O~2~ rất thấp**, nên làm nhiệm vụ **dự trữ và vận chuyển O~2~ trong cơ**. Mức gắn phụ thuộc nồng độ O~2~ trong tế bào cơ, pH, nhiệt độ và lực ion.

**So sánh Hb và Mb**

| | **Hemoglobin** | **Myoglobin** |
|---|---|---|
| Vị trí | Hồng cầu | Tế bào cơ |
| Số chuỗi / số hem | **4 / 4** | **1 / 1** |
| Bậc cấu trúc cao nhất | **Bậc 4** | **Bậc 3** |
| TLPT | ≈ 64 000 | ≈ 17 000 |
| Số O~2~ gắn tối đa | 4 | 1 |
| Đường cong phân ly O~2~ | **Sigma** (hợp tác) | **Hyperbol** |
| Ái lực với O~2~ | Thấp hơn (P~50~ ≈ 26 mmHg trong máu) | **Cao hơn** (P~50~ ≈ 3 mmHg) |
| Chịu ảnh hưởng của 2,3-DPG, hiệu ứng Bohr | Có, rõ | Không (2,3-DPG không gắn) |
| Chức năng | **Vận chuyển** O~2~ phổi → mô; chở CO~2~, H^+^; đệm | **Dự trữ** O~2~ trong cơ, chuyển O~2~ tới ty thể |

> [!vi-du] Vì sao O~2~ "chảy" từ Hb sang Mb?
> Ở mao mạch cơ, pO~2~ khoảng 20–40 mmHg. Tại đó Hb chỉ còn bão hòa 30–75% và đang nhả O~2~, còn Mb gần như bão hòa hoàn toàn. Mb "đón" O~2~ do Hb nhả ra rồi chuyển vào ty thể. Khi cơ co mạnh, pO~2~ trong tế bào xuống rất thấp, Mb mới nhả kho O~2~ của nó.

**Myoglobin trong máu** (Giáo trình tr. 53) — *tham khảo, mỗi phòng xét nghiệm có khoảng riêng*

- Bình thường rất thấp: nam khoảng **30–90 ng/mL**, nữ **dưới 50 ng/mL**.
- Khi **cơ bị tổn thương**, Mb thoát vào máu. **Nhồi máu cơ tim cấp**: Mb tăng sau **1–3 giờ**, cao nhất sau **5–12 giờ**, về bình thường sau **18–30 giờ**.
- Mb cũng tăng khi **phá hủy cơ xương** (chấn thương dập cơ, tiêu cơ vân) và khi **suy thận** (giảm đào thải).

> [!cap-nhat] Myoglobin và chẩn đoán nhồi máu cơ tim
> Giáo trình nêu Mb như dấu ấn của nhồi máu cơ tim cấp. Mb tăng sớm nhưng **không đặc hiệu cho tim** (tổn thương cơ xương cũng tăng). Hiện nay các hướng dẫn quốc tế (ESC, ACC/AHA) dùng **troponin tim độ nhạy cao (hs-cTn)** là dấu ấn chuẩn để chẩn đoán nhồi máu cơ tim, và **không khuyến cáo** dùng Mb nữa. Đi thi vẫn trả lời theo giáo trình.

> [!ung-dung] Tiêu cơ vân và suy thận cấp
> Chấn thương dập cơ nặng, vận động quá sức, say nóng, một số thuốc (statin hiếm gặp)… có thể gây **tiêu cơ vân**. Mb ồ ạt vào máu rồi lọc qua thận, làm **nước tiểu màu nâu đỏ** (que thử "máu" dương tính nhưng không thấy hồng cầu, mục 4.3e). Mb có thể làm tắc ống thận gây **suy thận cấp**. Xét nghiệm hay dùng là **CK (creatin kinase)** tăng rất cao; xử trí chính là **truyền dịch** sớm, đủ.

## Tóm tắt

| Nội dung | Ghi nhớ |
|---|---|
| Acid amin | α-amin + α-carboxyl trên C~α~; dãy L (trừ Gly); Pro là imino acid |
| 5 nhóm (giáo trình) | (1) không phân cực: G A V L I P · (2) thơm: F Y W · (3) base: K R H · (4) phân cực: S T C M N Q · (5) acid: D E |
| Thiết yếu | Val, Leu, Ile, Thr, Met, Phe, Trp, Lys (+ His) |
| Acid amin ít gặp | Hydroxyprolin, hydroxylysin (collagen, cần vit C); γ-carboxyglutamat (prothrombin, cần vit K); ornitin, citrulin (không trong protein) |
| pI | Gly 5,97 = (2,34 + 9,60)/2; Glu 3,22; His 7,59; Lys 9,74; Arg 10,76 |
| Phản ứng màu | Ninhydrin (α-aa), Sakaguchi (Arg), nitroprusiat (Cys), Pauly (His), xanthoprotein (nhân thơm), Millon (Tyr), Adamkiewicz (Trp) |
| UV | Trp, Tyr hấp thụ cực đại ≈ 280 nm |
| Peptid | Đánh số từ N tận; thủy phân hoàn toàn: HCl 6M, 110 °C, 18–36 h; glutathion = γ-Glu-Cys-Gly |
| Protein | Trên 50 acid amin; thuần / tạp (nhóm ngoại); cầu (dài/ngang dưới 10) / sợi (trên 10) |
| Liên kết | Peptid, disulfur (cộng hóa trị); hydro, ion, kỵ nước (yếu) |
| Bậc 1 | Trình tự; peptid; insulin 51 aa (A21 + B30) |
| Bậc 2 | Xoắn α (3,6 gốc/vòng, hydro trong chuỗi), gấp nếp β (hydro giữa chuỗi); nhiễu xạ tia X |
| Bậc 3 / bậc 4 | Không gian 1 chuỗi (S–S, ion, kỵ nước) / ghép nhiều chuỗi (ion, kỵ nước) — Hb |
| Kết tủa | Mất áo nước + trung hòa điện tích; muối trung tính, pH = pHi, kim loại nặng, acid mạnh |
| Biến tính | Mất bậc 2–4, còn bậc 1 (peptid nguyên); thuận nghịch (ribonuclease) hoặc không |
| Sắc ký trao đổi ion | CM (−) trao đổi cation; DEAE (+) trao đổi anion; cùng dấu ra trước |
| Hb | α~2~β~2~, 4 hem (protoporphyrin IX + Fe^2+^), 1 DPG gắn 2 chuỗi β; TLPT 64 000 |
| Hb bình thường | HbA~1~ 98%, HbA~2~ (α~2~δ~2~) 2%, HbF (α~2~γ~2~) 80% lúc sinh → dưới 0,5% lúc 1 tuổi |
| Đường cong O~2~ | Hb sigma (hợp tác), Mb hyperbol; dịch phải: ↑H^+^ (Bohr), ↑CO~2~, ↑t°, ↑DPG; dịch trái: HbF, CO |
| Dẫn xuất Hb | Carbamin (CO~2~), HbCO (CO, ái lực ×210), MetHb (Fe^3+^, nitrit), peroxidase (tìm máu niệu) |
| Hb bất thường | HbS (β6 Glu→Val), HbE (β26 Glu→Lys); thalassemia (thiếu chuỗi; β-thal: HbA~2~ tăng) |
| Mb | 1 chuỗi ≈ 153 aa, 1 hem, 75% xoắn α, 8 đoạn xoắn; F4 Leu, F8 His bảo tồn; tăng trong máu sau tổn thương cơ |
