---
title: Hóa sinh gan
thoi-gian: 50 phút
muc-tieu:
- Nêu được thành phần hóa học chính của nhu mô gan, thành phần hóa học và vai trò của mật (acid mật, muối mật, sắc tố mật).
- Phân tích được những điểm riêng của gan trong chuyển hóa glucid (glycogen, glucose-6-phosphatase, điều hòa glucose máu), lipid (thể ceton, phospholipid, lipoprotein, cholesterol ester) và protein (albumin, yếu tố đông máu, transaminase, tổng hợp ure).
- Trình bày được hai cơ chế khử độc của gan (cố định – thải trừ và biến đổi hóa học), cho ví dụ các phản ứng oxy hóa, khử, thủy phân, liên hợp; nêu được vai trò của cytochrom P450 và hiện tượng cảm ứng enzym.
- Phân tích được giá trị các xét nghiệm hóa sinh gan: nhóm tổn thương tế bào (ALT, AST, GGT, LDH, GLDH), nhóm ứ mật (ALP, bilirubin), nhóm chức năng (albumin, BSP; bổ sung PT/INR, NH~3~), và vận dụng vào tình huống ngộ độc paracetamol, bệnh gan do rượu, tương tác thuốc.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Gan là "nhà máy hóa chất" ở **cửa ngõ tĩnh mạch cửa**: giữ và trả **glucose** (nhờ **glucose-6-phosphatase**), tạo **thể ceton** "đốt mỡ hộ" các mô khác, tạo **toàn bộ albumin**, phần lớn **yếu tố đông máu** và **toàn bộ ure** của cơ thể.
> 2. **Mật** = muối mật + sắc tố mật + cholesterol. Acid mật (từ cholesterol) **liên hợp glycin hoặc taurin** + Na^+^/K^+^ → **muối mật**: nhũ tương hóa lipid, hoạt hóa lipase.
> 3. **Khử độc** theo 2 cách: **cố định – thải nguyên dạng** qua mật (kim loại nặng, chất màu) và **biến đổi hóa học**: oxy hóa, khử, thủy phân (ngày nay gọi là **pha I**, chủ yếu do **cytochrom P450**) rồi **liên hợp** với acid glucuronic, sulfat, glutathion, acetyl, glycin, glutamin (**pha II**) → chất tan trong nước, thải qua mật hoặc nước tiểu.
> 4. Chuyển hóa **không phải lúc nào cũng khử độc**: paracetamol → **NAPQI** độc, được **glutathion** trung hòa; quá liều làm cạn glutathion → hoại tử gan → giải độc bằng **N-acetylcystein**. Thuốc **cảm ứng** hay **ức chế** CYP gây **tương tác thuốc**.
> 5. Xét nghiệm gan chia 3 nhóm: **tổn thương tế bào** (ALT, AST tăng), **ứ mật** (ALP, GGT, bilirubin liên hợp tăng), **suy chức năng tổng hợp** (albumin giảm, PT kéo dài/INR tăng, NH~3~ tăng). ALT, AST cao **không** có nghĩa là chức năng gan kém.

## 1. Đại cương và thành phần hóa học của nhu mô gan

### 1.1. Vì sao gan đặc biệt?

Gan là một trong những cơ quan quan trọng nhất về **chuyển hóa**. Giáo trình ghi gan nặng khoảng 2 kg (Giáo trình tr. 276); ở người trưởng thành thường vào khoảng 1,2–1,6 kg. Đây là tạng đặc lớn nhất trong cơ thể.

- **Tế bào nhu mô gan** (hepatocyte, *parenchymal cell*) chiếm khoảng **80% khối lượng gan**. Hầu hết hoạt động chuyển hóa diễn ra ở đây.
- Gan còn có **tế bào Kupffer** (đại thực bào nằm trong xoang gan), làm nhiệm vụ bắt giữ vi khuẩn, hồng cầu già và các hạt lạ từ máu cửa.

**Vì sao gan dễ mắc bệnh?** Mọi chất hấp thu từ ruột (chất dinh dưỡng, thuốc, độc chất, vi khuẩn) đều theo **tĩnh mạch cửa** về gan **trước tiên**. Gan là "trạm kiểm soát" đầu tiên, nên cũng là nơi hứng chịu nhiều tổn thương nhất. Bệnh lý gan – mật thường gặp hơn bệnh của nhiều cơ quan khác, và xét nghiệm hóa sinh là công cụ chính để chẩn đoán, theo dõi điều trị (Giáo trình tr. 276).

### 1.2. Thành phần hóa học của gan

Thành phần thay đổi theo tình trạng ăn uống và hoạt động của cơ thể. Bảng dưới là số liệu của giáo trình, tính theo % khối lượng gan tươi (Giáo trình tr. 276, Bảng 17.1).

| Chất | Tỷ lệ % |
|---|---|
| Nước | 70–75 |
| Chất khô | 25–30 |
| Protein | 12–15 |
| **Glycogen** | **2–10** (dao động mạnh nhất) |
| Glucose | 0,1 |
| Lipid trung tính | 2,0 |
| Phospholipid | 2,5 |
| Cholesterol | 2,3 |
| Chất khoáng, vitamin | Rất thấp |

Diễn giải từng nhóm chất (Giáo trình tr. 277):

- **Protein** chiếm khoảng **1/2 chất khô**: albumin, globulin, một ít nucleoprotein, collagen và **ferritin**. Ferritin = **apoferritin + sắt**, là **dạng dự trữ sắt** của cơ thể. Gan còn chứa nhiều acid amin (amino acid) tự do (cystein, methionin, tryptophan, arginin, glycin, histidin), nhiều nhất là **acid glutamic**.
- **Glucid** chủ yếu là **glycogen**, 2–10% tùy tình trạng cơ thể. Sau bữa ăn glycogen gan cao; nhịn đói 1 ngày gần như cạn.
- **Lipid** chiếm khoảng 5% trọng lượng khô; trong đó **40% lipid trung tính, 50% phospholipid, 10% cholesterol**. Phospholipid nhiều vì gan cần nó để làm màng tế bào và "đóng gói" lipoprotein (mục 2.2).
- **Enzym**: gan có hệ enzym rất hoàn chỉnh, gồm nhiều enzym **chỉ gan mới có** (glucose-6-phosphatase, các enzym của chu trình ure, enzym tạo thể ceton…).
- **Vitamin, khoáng**: gan dự trữ nhiều vitamin **A, D, K, B~12~**, các vitamin nhóm B (B~1~, B~2~…), vitamin C; các ion Fe, Na, K, Mg, Cu, Zn…

> [!bay] Số liệu lipid trong giáo trình không khớp nhau
> Bảng 17.1 ghi cholesterol 2,3% (gần bằng phospholipid 2,5%), nhưng lời văn lại nói cholesterol chỉ chiếm **10%** lipid gan, phospholipid **50%**. Hai số liệu này không thể cùng đúng. Khi thi, nhớ **tỷ lệ trong lời văn**: lipid gan ≈ 5% trọng lượng khô, gồm 40% lipid trung tính – 50% phospholipid – 10% cholesterol. Gan dự trữ **vitamin tan trong dầu (A, D, K)** và **B~12~** là ý hay hỏi.

## 2. Chức năng chuyển hóa glucid, lipid, protein của gan

Gần như mọi con đường chuyển hóa đã học đều diễn ra ở gan. Mục này chỉ nêu những điểm **gan khác các mô khác** (Giáo trình tr. 277).

### 2.1. Chuyển hóa glucid — gan là "ngân hàng glucose"

**Khi glucose máu tăng** (sau bữa ăn): glucose từ ruột theo tĩnh mạch cửa về gan rất nhiều. Gan **giữ lại** glucose và tăng **tổng hợp glycogen** để dự trữ (chi tiết enzym: hs-07).

**Gan tổng hợp glycogen từ nhiều nguồn mà cơ không làm được** (Giáo trình tr. 277):

- Từ các ose khác: **galactose, fructose, mannose**, nhờ hệ enzym chỉ có ở gan.
- Từ các sản phẩm chuyển hóa trung gian như **lactat, pyruvat** (con đường **tân tạo glucose**). Khi cơ hoạt động mạnh, cơ thoái hóa glycogen tạo nhiều lactat; lactat theo máu về gan để tân tạo glucose rồi glucose lại về cơ. Vòng này gọi là **chu trình Cori**.

**Khi glucose máu giảm** (xa bữa ăn): gan **phân giải glycogen** và trả glucose vào máu. Cơ cũng có glycogen nhưng **không** trả glucose vào máu được, vì chỉ gan có **glucose-6-phosphatase** (Giáo trình tr. 278):

=> Glucose-6-phosphat + H~2~O → Glucose + H~3~PO~4~  (glucose-6-phosphatase)

Glucose tự do mới qua được màng tế bào ra máu; glucose-6-phosphat mang điện âm nên bị "nhốt" trong tế bào.

**Vì sao nói gan là cơ quan duy nhất (không kể tuyến nội tiết) điều hòa glucose máu?** Vì gan vừa **dự trữ được nhiều glycogen**, vừa **trả được glucose tự do** vào máu. Insulin, glucagon, adrenalin… chỉ là "tín hiệu"; nơi thực hiện lệnh là gan. Do đó toàn bộ hệ điều hòa glucose máu bằng hormon **phụ thuộc vào sự toàn vẹn của gan** (Giáo trình tr. 278). Người suy gan nặng dễ bị **hạ glucose máu**.

**Hai sản phẩm glucid khác của gan** (Giáo trình tr. 278):

- **Acid glucuronic** (dạng hoạt hóa **UDP-glucuronat**), nguyên liệu của phản ứng **liên hợp khử độc** (mục 4.2.4).
- Giáo trình ghi gan tổng hợp **heparin**, một polysaccharid chống đông máu tự nhiên (xem khung cập nhật bên dưới).

> [!cap-nhat] Hai chỗ cần hiểu lại ở mục glucid
> - **Acetyl-CoA không tạo được glucose.** Giáo trình kể acetyl-CoA trong số nguyên liệu gan dùng tổng hợp glycogen (tr. 277). Ở người, bước pyruvat → acetyl-CoA **không thuận nghịch**, và 2 carbon của acetyl-CoA vào chu trình Krebs thì mất đi dưới dạng 2 CO~2~. Vì vậy acetyl-CoA (và acid béo chẵn carbon) **không** tân tạo glucose được (xem hs-07). Nguyên liệu đúng là lactat, pyruvat, glycerol, acid amin sinh đường.
> - **Heparin do dưỡng bào (tế bào mast) tổng hợp**, không phải tế bào gan. Tên "heparin" có từ việc người ta tách được chất này **lần đầu từ gan** (gan chó, năm 1916). Heparin là một glycosaminoglycan (hs-01).
> - Giáo trình ghi glucose-6-phosphatase "chỉ ở gan". Chính xác hơn: enzym này có ở **gan và thận** (một ít ở ruột). Ý chính vẫn đúng: **cơ không có**.

### 2.2. Chuyển hóa lipid

**Thoái hóa: gan "oxy hóa acid béo hộ" các mô khác** (Giáo trình tr. 278)

- β-oxy hóa acid béo ở gan rất mạnh, tạo nhiều **acetyl-CoA**.
- Một phần nhỏ acetyl-CoA vào **chu trình acid citric** để tạo năng lượng cho chính gan; một phần dùng tổng hợp **cholesterol** và **acid mật**.
- **Phần lớn** acetyl-CoA được dùng tạo **thể ceton** (acetoacetat, β-hydroxybutyrat; hs-08). Thể ceton tan trong nước, theo máu tới **não, thận, tim, cơ**; tại đó chúng được chuyển lại thành acetyl-CoA để đốt lấy năng lượng.
- Như vậy thể ceton là **dạng vận chuyển acetyl-CoA** từ gan đến các mô khác. Gan có hệ enzym oxy hóa acid béo rất mạnh, đã "đốt" acid béo **hộ** các mô.

> [!vi-du] Vì sao gan tạo thể ceton nhưng không dùng thể ceton?
> Muốn dùng acetoacetat, tế bào cần enzym chuyển CoA từ succinyl-CoA sang acetoacetat (**succinyl-CoA: acetoacetat CoA transferase**, còn gọi thiophorase). **Gan không có enzym này**. Nhờ vậy gan không "ăn" lại sản phẩm mình làm ra; toàn bộ thể ceton được dành cho mô ngoại vi. Khi đói lâu ngày, **não** dùng thể ceton để thay một phần glucose.

**Tổng hợp: gan "đóng gói" lipid để xuất đi** (Giáo trình tr. 278–279)

- Mô mỡ tổng hợp lipid mạnh nhất, nhưng tổng hợp lipid ở gan có ý nghĩa riêng: gan tạo **triglycerid nội sinh** từ glucid và acid béo thừa.
- Gan tổng hợp **rất nhiều phospholipid**. Phospholipid là thành phần có cực, giữ vai trò chính trong cấu tạo vỏ **lipoprotein** huyết thanh. Nhờ có phospholipid, gan "đóng gói" triglycerid và cholesterol vào **VLDL** để đưa **ra khỏi gan** (hs-08).
- Khi chức năng gan suy giảm, việc tổng hợp và vận chuyển lipid ra khỏi gan bị rối loạn. Lipid ứ lại gây **gan nhiễm mỡ** (ứ đọng mỡ ở gan).

> [!cap-nhat] Lipid thức ăn có "về gan trước" không?
> Giáo trình viết lipid sau khi hấp thu, tái tổng hợp ở ruột thì "hầu hết được vận chuyển về gan trước khi đến các tổ chức khác" (tr. 278). Hiện nay biết rõ: acid béo **chuỗi dài** được đóng gói thành **chylomicron**, đi theo **bạch huyết** vào tuần hoàn chung, gặp **mô mỡ và cơ** trước; ở đó lipoprotein lipase lấy bớt triglycerid. Chỉ phần **chylomicron tàn dư** mới về gan. Riêng acid béo **chuỗi ngắn và trung bình** mới đi thẳng theo tĩnh mạch cửa về gan.

**Cholesterol** (Giáo trình tr. 279)

- Gan tổng hợp **phần lớn cholesterol huyết thanh**.
- Cholesterol được **ester hóa** (gắn acid béo vào nhóm –OH) ở gan hoặc trong huyết tương. Enzym ester hóa trong huyết tương là **LCAT** (lecithin-cholesterol acyltransferase), một enzym **do gan sản xuất**.
- Cholesterol ester chiếm khoảng **60–70%** cholesterol toàn phần huyết tương.
- Khi chức năng gan giảm, tỷ lệ **cholesterol ester / cholesterol toàn phần giảm**. Đây là một chỉ số chức năng gan (gan không làm đủ LCAT).

> [!ung-dung] Rượu và gan nhiễm mỡ — vì sao người nghiện rượu bị gan nhiễm mỡ?
> Ethanol được oxy hóa ở gan (mục 4.2.1): ethanol → acetaldehyd → acetat. Cả hai bước đều **sinh NADH**. Tỷ lệ NADH/NAD^+^ trong tế bào gan tăng vọt, kéo theo:
> - **β-oxy hóa acid béo bị chậm lại** (cần NAD^+^) → acid béo ứ đọng;
> - pyruvat bị khử thành lactat, dihydroxyaceton phosphat bị khử thành **glycerol-3-phosphat** → có sẵn "khung" để **tổng hợp triglycerid**;
> - **tân tạo glucose bị ức chế** (thiếu pyruvat, oxaloacetat) → người say rượu mà nhịn ăn dễ **hạ glucose máu**; lactat tăng làm giảm thải acid uric (dễ lên cơn gout).
>
> Kết quả: triglycerid tích tụ → **gan nhiễm mỡ do rượu**. Đây là giai đoạn còn **hồi phục** nếu ngừng rượu. Nếu tiếp tục, acetaldehyd (rất độc, gắn vào protein) và gốc tự do gây **viêm gan do rượu** rồi **xơ gan**.

> [!cap-nhat] Gan nhiễm mỡ không do rượu — tên gọi mới
> Từ năm 2023, các hội gan mật lớn (AASLD, EASL…) đổi tên "bệnh gan nhiễm mỡ không do rượu" (NAFLD) thành **bệnh gan nhiễm mỡ liên quan rối loạn chuyển hóa** (**MASLD**), gắn với béo phì, kháng insulin, đái tháo đường typ 2, rối loạn lipid máu. Người vừa có rối loạn chuyển hóa vừa uống rượu mức vừa phải được xếp vào nhóm **MetALD**. Ở Việt Nam đây là nguyên nhân tăng ALT rất hay gặp.

### 2.3. Chuyển hóa protein

**Tổng hợp protein huyết tương** (Giáo trình tr. 279)

- Gan tổng hợp **toàn bộ albumin** và **một phần globulin** (γ-globulin là kháng thể, do tương bào tạo ra).
- Gan tổng hợp **fibrinogen, prothrombin** và phần lớn các yếu tố đông máu, cùng **ferritin** và nhiều protein huyết tương khác.
- Khi suy gan: albumin giảm nên **tỷ số albumin/globulin (A/G) giảm**; yếu tố đông máu giảm nên có **rối loạn đông máu** (chảy máu chân răng, xuất huyết dưới da, thời gian prothrombin kéo dài).

**Tổng hợp acid amin không cần thiết** từ các acid α-cetonic (nhờ trao đổi amin), đưa vào máu cho các cơ quan khác tổng hợp protein.

**Thoái hóa acid amin.** Gan chứa nhiều enzym thoái hóa acid amin, đặc biệt **transaminase**: **AST** (GOT) và **ALT** (GPT) (hs-09).

- Khi tế bào gan bị phá hủy, transaminase thoát ra máu; hoạt độ huyết thanh có thể **tăng gấp nhiều lần**, nhất là **ALT**.
- Khi tổn thương sâu hơn, enzym **ty thể** như **glutamat dehydrogenase (GLDH)** cũng xuất hiện và tăng trong máu (Giáo trình tr. 279).

**Tổng hợp ure — khử độc NH~3~.** Các enzym của **chu trình ure** hoạt động mạnh ở gan, và **gan là nơi duy nhất tổng hợp ure** của cơ thể (chu trình chi tiết: hs-09). Khả năng dự trữ rất lớn: giáo trình ghi khi **3/4 tổ chức gan** bị hủy hoại hoặc cắt bỏ, chức năng tổng hợp ure vẫn bình thường (Giáo trình tr. 279). Vì vậy ure máu **giảm** và NH~3~ máu **tăng** chỉ xuất hiện khi suy gan **rất nặng**.

**Thoái hóa hemoglobin.** Gan nhận **bilirubin tự do** và liên hợp thành **bilirubin liên hợp** (sắc tố mật) để thải qua mật (chi tiết: hs-10).

> [!bay]
> - Gan tổng hợp **toàn bộ** albumin nhưng chỉ **một phần** globulin. Suy gan: albumin ↓, globulin thường **↑** (phản ứng viêm, kháng thể) → A/G **giảm**, có khi **đảo ngược** (< 1).
> - "3/4 gan bị hủy mà ure vẫn bình thường": ure máu **bình thường không loại trừ** bệnh gan. Ure máu tăng thường là do **thận** (hs-09); ure máu **thấp** mới gợi ý suy gan nặng (hoặc ăn ít đạm, có thai).

## 3. Chức năng tạo mật

Gan **sản xuất mật liên tục**, dự trữ ở **túi mật** và bài tiết từng đợt xuống **tá tràng** khi thức ăn từ dạ dày xuống. Lượng mật trung bình khoảng **1000 ml/ngày** ở người trưởng thành (Giáo trình tr. 279).

### 3.1. Thành phần hóa học của mật

Thành phần chính: **muối mật, sắc tố mật, cholesterol** (Giáo trình tr. 279–280, Bảng 17.2).

| | Mật ở ống gan | Mật ở túi mật |
|---|---|---|
| pH | **7,5** | **6,8** |
| Nước | 97,6% | 86% |
| Chất khô | 2,4% | 14% |
| Muối mật | 0,6% | **7%** |
| Mucin, sắc tố mật | 0,5% | 4,1% |
| Cholesterol | 0,15% | 0,6% |

**Vì sao mật túi đặc hơn nhiều?** Niêm mạc túi mật **hút lại nước và điện giải**, cô đặc mật khoảng 5–10 lần. Muối mật tăng từ 0,6% lên 7%; mucin, sắc tố cũng tăng. pH giảm vì túi mật hấp thu HCO~3~^−^.

> [!bay] Lỗi in trong Bảng 17.2
> Bảng ghi tỷ trọng mật túi là "1,206–1,048". Số đầu gần như chắc chắn là lỗi in của **1,026**. Tỷ trọng mật túi khoảng **1,026–1,048**, cao hơn mật ống gan (1,009–1,013) vì mật túi đặc hơn.

**Acid mật — thành phần quan trọng nhất của mật**

- Acid mật là **sản phẩm thoái hóa cuối cùng của cholesterol** ở gan (nhân steroid không bị phá vỡ). Đây là **đường thải cholesterol chính** của cơ thể.
- Giáo trình nêu 3 acid mật chính ở người: **acid cholic, acid deoxycholic, acid lithocholic** (Giáo trình tr. 280). Ba chất cùng có khung steroid và nhánh –COOH, khác nhau ở số nhóm –OH: cholic có 3 –OH (C3, C7, C12), deoxycholic có 2 (C3, C12), lithocholic chỉ có 1 (C3).
- Acid mật **không** được bài tiết tự do. Chúng được **liên hợp** với **glycin** hoặc **taurin** (taurin là dẫn xuất của cystein, có nhóm –SO~3~H), rồi kết hợp với **Na^+^ hoặc K^+^**, tạo **muối mật**: **glycocholat** và **taurocholat** natri, kali.

=> Acid cholic + Glycin → Acid glycocholic (+ Na^+^ → Natri glycocholat)

=> Acid cholic + Taurin → Acid taurocholic (+ Na^+^ → Natri taurocholat)

**Vì sao phải liên hợp?** Liên hợp làm pK~a~ giảm mạnh (nhất là với taurin), nên ở pH ruột muối mật **ion hóa hoàn toàn**, tan tốt và không bị hấp thu thụ động sớm ở đoạn trên ruột. Nhờ vậy muối mật ở lại lòng ruột đủ lâu để làm việc tiêu hóa mỡ.

- Muối mật kết hợp với chất tan trong lipid như **cholesterol** tạo phức hợp **tan trong nước**, nhờ đó cholesterol được đưa ra khỏi tế bào gan theo mật.

> [!cap-nhat] Acid mật nguyên phát và thứ phát
> Cách phân loại hiện nay (xem hs-08, mục 4.3): gan tổng hợp **acid mật nguyên phát** là **acid cholic** và **acid chenodeoxycholic**. Vi khuẩn ruột cắt –OH ở C7 để tạo **acid mật thứ phát**: cholic → **deoxycholic**, chenodeoxycholic → **lithocholic**. Danh sách "cholic, deoxycholic, lithocholic" của giáo trình đúng là những acid có mặt trong mật, nhưng bỏ sót acid **chenodeoxycholic**, vốn nhiều ngang acid cholic. Đi thi trả lời theo giáo trình; nếu được hỏi "nguyên phát/thứ phát" thì dùng cách chia này.

**Sắc tố mật** là sản phẩm thoái hóa của hemoglobin, chủ yếu là **bilirubin liên hợp** và **biliverdin** (Giáo trình tr. 281; chi tiết: hs-10).

### 3.2. Tác dụng của mật

1. **Màu của mật**: mật mới tiết có màu **vàng** (bilirubin). Mật túi **sẫm hơn**, từ xanh lá đến nâu nhạt, vì bilirubin bị oxy hóa thành biliverdin và mật bị cô đặc.
2. **Nhũ tương hóa lipid**: muối mật có một mặt ưa nước, một mặt kỵ nước, nên chia giọt mỡ lớn thành giọt rất nhỏ. Diện tích tiếp xúc với **lipase** tăng lên rất nhiều. Muối mật còn **hoạt hóa lipase**. Hạt nhũ tương rất nhỏ (đường kính **dưới 0,5 micron**) có thể được hấp thu trực tiếp (Giáo trình tr. 281). Vì thế **tiêu hóa và hấp thu lipid phụ thuộc vào lượng muối mật** — kể cả hấp thu **vitamin A, D, E, K**.
3. **Tăng nhu động ruột**, vì lượng mật xuống ruột mỗi ngày rất lớn.
4. **Đào thải chất độc, chất cặn bã** của chuyển hóa theo mật xuống ruột rồi ra phân (bilirubin, cholesterol, thuốc, kim loại nặng).
5. **Chu trình gan – ruột**: ruột hấp thu lại **80–90% acid mật** (Giáo trình tr. 281; tài liệu hiện nay thường ghi khoảng 95%, chủ yếu ở **hồi tràng**) đưa về gan dùng lại. Phần còn lại theo phân ra ngoài và được gan bù lại từ cholesterol.

> [!ung-dung] Khi mật không xuống được ruột (tắc mật)
> - **Phân bạc màu, có mỡ** (thiếu sắc tố mật, mỡ không được tiêu hóa).
> - **Thiếu vitamin K** (vitamin tan trong dầu, hấp thu cần muối mật) → gan không carboxyl hóa được prothrombin và các yếu tố VII, IX, X → **thời gian prothrombin kéo dài**. Tiêm vitamin K thì PT trở về bình thường (khác với suy tế bào gan, xem mục 5.4).
> - Muối mật ứ lại trong máu, lắng ở da gây **ngứa**; bilirubin liên hợp trào ngược vào máu gây **vàng da**, nước tiểu sẫm.

## 4. Chức năng khử độc

Hằng ngày cơ thể tiếp nhận chất độc từ **bên trong** (chất độc **nội sinh**: H~2~O~2~, bilirubin tự do, NH~3~…) và từ **bên ngoài** qua thức ăn, nước uống, thuốc (chất độc **ngoại sinh**: rượu, kháng sinh, thuốc ngủ…). Gan giữ chúng lại, biến thành chất không độc rồi đào thải. Gan khử độc bằng **hai cách** (Giáo trình tr. 281).

### 4.1. Khử độc theo cơ chế cố định và thải trừ

Chất độc đến gan được gan **giữ lại** rồi **thải nguyên dạng** theo đường mật, **không bị biến đổi hóa học**. Cách này áp dụng cho:

- **Muối kim loại nặng**: đồng (Cu), chì (Pb)…
- **Một số chất màu**.

Dựa vào cơ chế này, người ta thăm dò chức năng gan bằng cách **tiêm chất màu** (ít độc) vào tĩnh mạch rồi đo nồng độ trong máu theo thời gian. Gan tốt thì chất màu được giữ lại, thải qua mật và **giảm nhanh** trong máu (nghiệm pháp BSP, mục 5.3).

> [!ung-dung] Bệnh Wilson — khi gan không thải được đồng
> Bình thường đồng thừa được gan thải qua **mật**. Ở bệnh Wilson (di truyền lặn, đột biến gen *ATP7B*), protein vận chuyển đồng vào mật bị hỏng. Đồng ứ ở gan (viêm gan, xơ gan), rồi tràn sang **não** (rối loạn vận động) và **giác mạc** (vòng Kayser–Fleischer). Ceruloplasmin máu thường **giảm**. Đây là minh chứng rõ cho con đường "cố định – thải qua mật".

### 4.2. Khử độc theo cơ chế hóa học

Đây là cách khử độc **chính và quan trọng nhất**. Chất độc bị **biến đổi hóa học** thành chất ít độc và **dễ tan trong nước** để đào thải (Giáo trình tr. 282). Hai ví dụ với chất độc nội sinh:

- **NH~3~ → ure**: NH~3~ (từ thoái hóa acid amin, base nitơ) rất độc với não; gan giữ lại và tổng hợp thành **ure** không độc, thải qua nước tiểu (hs-09).
- **H~2~O~2~** được phân hủy bởi **catalase**, enzym hoạt động rất mạnh ở gan:

=> 2 H~2~O~2~ → 2 H~2~O + O~2~  (catalase)

Ngoài ra gan có 4 loại phản ứng khử độc: **oxy hóa, khử, thủy phân, liên hợp**.

**Vì sao phải "làm cho tan trong nước"?** Thuốc và độc chất muốn vào được cơ thể thường **tan trong lipid** (dễ qua màng ruột). Nhưng chất tan trong lipid khi qua thận sẽ được **tái hấp thu** trở lại qua màng ống thận và không thải ra được. Gan phải gắn thêm nhóm phân cực (–OH, –COOH, –NH~2~) rồi gắn các phân tử lớn tích điện (glucuronat, sulfat…) để chất đó **tan trong nước**, bị "nhốt" trong nước tiểu hoặc mật.

![Hình 1. Hai pha chuyển hóa thuốc và độc chất ở gan](pha-khu-doc.svg)

> [!ghi-nho] Cách gọi hiện nay: pha I và pha II
> Sách dược lý và hóa sinh hiện đại xếp các phản ứng của giáo trình thành **hai pha**:
> - **Pha I** (phản ứng chức năng hóa): **oxy hóa, khử, thủy phân**. Tạo ra hoặc bộc lộ một nhóm chức (–OH, –NH~2~, –COOH, –SH). Enzym chủ yếu là **cytochrom P450** ở **lưới nội bào trơn** (microsom).
> - **Pha II** (phản ứng **liên hợp**): gắn chất độc (hoặc sản phẩm pha I) với một phân tử nội sinh: **acid glucuronic, sulfat, glutathion, acetyl, glycin, glutamin, nhóm methyl**. Sản phẩm thường **mất hoạt tính, tan trong nước**.
>
> Không phải chất nào cũng đi đủ hai pha: chất đã có sẵn nhóm –OH (phenol, paracetamol) có thể liên hợp ngay.

#### 4.2.1. Phản ứng oxy hóa

Do các enzym **cytochrom P450**, **flavin monooxygenase**, **amin oxidase** hoặc các **dehydrogenase** thực hiện (Giáo trình tr. 282). Phản ứng tổng quát của cytochrom P450 (monooxygenase, xem hs-05):

=> RH + O~2~ + NADPH + H^+^ → ROH + H~2~O + NADP^+^

Một nguyên tử O đi vào cơ chất (tạo –OH), nguyên tử O kia tạo nước. Vì một phân tử O~2~ "chia" cho hai việc nên enzym được gọi là **oxidase chức năng hỗn hợp** (*mixed-function oxidase*).

| Kiểu oxy hóa | Ví dụ trong giáo trình | Enzym |
|---|---|---|
| Oxy hóa carbon **mạch thẳng** | **Ethanol → acetaldehyd → acid acetic** | **Alcol dehydrogenase** (ADH), **aldehyd dehydrogenase** (ALDH) |
| Oxy hóa carbon **mạch vòng** | **Hexobarbital** → dẫn xuất có –OH trên vòng cyclohexenyl, mất tác dụng | Cytochrom P450 |
| Oxy hóa **hydrocarbon thơm** | **Acetanilid → para-hydroxyacetanilid** (chính là **paracetamol**) | Cytochrom P450 |
| **Khử amin oxy hóa** | **Phenylethylamin → phenylacetaldehyd + NH~3~** | **Amin oxidase** (MAO) |
| **N-oxy hóa** | **Trimethylamin → trimethylamin N-oxid** (không mùi, tan trong nước) | Flavin monooxygenase |

=> CH~3~CH~2~OH → CH~3~CHO → CH~3~COOH  (ADH rồi ALDH; mỗi bước sinh 1 NADH)

> [!vi-du] Ba ví dụ "đời thường" của bảng trên
> - **Đỏ mặt khi uống rượu**: nhiều người Đông Á mang biến thể gen **ALDH2** hoạt tính rất yếu. Acetaldehyd tích tụ gây đỏ mặt, tim nhanh, buồn nôn. Thuốc **disulfiram** (cai rượu) ức chế ALDH, cố tình tạo phản ứng khó chịu này.
> - **Acetanilid → paracetamol**: acetanilid là thuốc hạ sốt cũ; người ta phát hiện chính sản phẩm hydroxyl hóa của nó ở gan (paracetamol) mới là chất có tác dụng tốt và ít độc hơn (xem hc-10). Đây là ví dụ "chất chuyển hóa trở thành thuốc".
> - **Hội chứng mùi cá** (trimethylamin niệu): thiếu bẩm sinh enzym **FMO3** nên trimethylamin (từ cholin, cá biển) không được N-oxy hóa; mồ hôi, hơi thở có mùi cá ươn.

#### 4.2.2. Phản ứng khử

- **Khử aldehyd, ceton**: **cloral → tricloroethanol** (cộng 2H) (Giáo trình tr. 283).
- **Khử nhóm nitro** (–NO~2~ → –NH~2~): **cloramphenicol** bị khử thành dẫn xuất amin không còn tác dụng kháng khuẩn.

#### 4.2.3. Phản ứng thủy phân

Cắt liên kết ester, amid bằng nước. Ví dụ: **procain** (thuốc tê) bị thủy phân thành **acid para-aminobenzoic** và **diethylaminoethanol** (Giáo trình tr. 283).

> [!cap-nhat] Chuyển hóa không phải lúc nào cũng là "khử độc"
> Giáo trình gọi tất cả các phản ứng trên là "khử độc". Ngày nay dùng chữ trung tính hơn: **chuyển hóa thuốc và chất lạ** (*biotransformation*), vì sản phẩm có thể:
> - **mất tác dụng, ít độc hơn** (đa số trường hợp: hexobarbital, cloramphenicol, procain);
> - **vẫn có hoạt tính**, thậm chí là chất chính: **tricloroethanol** chính là chất gây ngủ của cloral hydrat; codein phải được CYP2D6 chuyển thành **morphin** mới giảm đau mạnh;
> - **độc hơn chất ban đầu** (gọi là **hoạt hóa sinh học**, *bioactivation*): paracetamol → **NAPQI** (mục 4.4); **aflatoxin B~1~** → epoxid gây ung thư gan (sh-10); alkaloid **pyrrolizidin** → dẫn xuất pyrrol gây tắc xoang gan (hs-09).
>
> Thủy phân procain thực ra diễn ra chủ yếu **trong huyết tương** (nhờ cholinesterase huyết tương, do gan tổng hợp), không phải trong tế bào gan. Đi thi trả lời theo giáo trình.

#### 4.2.4. Phản ứng liên hợp

**a) Liên hợp với acid glucuronic** — phổ biến nhất (Giáo trình tr. 283–284)

- Chất được liên hợp: **bilirubin tự do**, **phenol** và dẫn xuất, **alcol thơm**, **terpen**, acid béo, **alkaloid**, **steroid**…
- Dạng hoạt hóa của acid glucuronic là **UDP-glucuronat** (UDPGA), được tạo từ **UDP-glucose** bằng cách oxy hóa nhóm –CH~2~OH ở C6 thành –COOH (enzym UDP-glucose dehydrogenase, dùng 2 NAD^+^).
- Liên kết hình thành là **liên kết osid** (glycosid) giữa nhóm **–OH bán acetal** (C1) của acid glucuronic với nhóm **–OH phenol, –OH alcol** hoặc nhóm **–COOH** của chất độc. Enzym: **UDP-glucuronyl transferase** (UGT).

=> UDP-glucose → UDPGA (UDP-acid glucuronic)

=> Phenol + UDPGA → Phenyl glucuronid + UDP

=> R–COOH + UDPGA → R–CO–O–glucuronid + UDP

=> Bilirubin tự do + 2 UDPGA → Bilirubin liên hợp (diglucuronid) + 2 UDP

Sản phẩm liên hợp **không độc, dễ tan**, thải theo **mật** hoặc **nước tiểu**.

**b) Liên hợp với acid sulfuric** (Giáo trình tr. 284)

- **Indol, phenol** và dẫn xuất (tạo ra do **thối rữa protein ở ruột**, được hấp thu một phần) và **hormon steroid** được thải dưới dạng **ester sulfat**.
- Ví dụ trong sách: phenol + H~2~SO~4~ → **phenylsulfat kali**. Trong tế bào, "nhóm sulfat hoạt hóa" thực chất là **PAPS** (3'-phosphoadenosin-5'-phosphosulfat), enzym là sulfotransferase.
- Indol từ ruột → **indoxyl** → indoxyl sulfat (**indican** niệu); indican niệu tăng khi thối rữa ở ruột mạnh.

**c) Liên hợp với acid acetic (acetyl hóa)** (Giáo trình tr. 284)

- Đào thải các acid **meta-, para-aminobenzoic**, **sulfamid**…: nhóm –NH~2~ được gắn nhóm acetyl (từ **acetyl-CoA**, enzym N-acetyltransferase).
- Ví dụ: acid para-aminobenzoic → **acid para-acetylamidobenzoic**.

> [!vi-du] Người "acetyl hóa nhanh" và "acetyl hóa chậm"
> Enzym N-acetyltransferase 2 (NAT2) có biến thể di truyền. Người **acetyl hóa chậm** dùng **isoniazid** (thuốc lao) có nồng độ thuốc trong máu cao hơn, dễ bị **viêm thần kinh ngoại biên** và **độc gan** hơn. Đây là ví dụ về **dược di truyền học**: cùng một liều, mỗi người chuyển hóa khác nhau.

**d) Liên hợp với glycin** (Giáo trình tr. 284)

- Các **acid thơm** và acid dị vòng được liên hợp theo cách này.
- Ví dụ kinh điển: **acid benzoic + glycin → acid hippuric** (thải qua nước tiểu). Acid benzoic có trong thực phẩm (natri benzoat là chất bảo quản) và nhiều quả.

=> C~6~H~5~–COOH + H~2~N–CH~2~–COOH → C~6~H~5~–CO–NH–CH~2~–COOH (acid hippuric) + H~2~O

**e) Liên hợp với glutamin** (Giáo trình tr. 285)

- Ví dụ: **acid phenylacetic + glutamin → phenylacetylglutamin**, thải qua nước tiểu.

> [!ung-dung] Liên hợp glutamin cứu trẻ thiếu enzym chu trình ure
> Trẻ thiếu bẩm sinh enzym chu trình ure (hs-09) bị tăng NH~3~ máu nặng. Thuốc **natri phenylbutyrat** (chuyển thành phenylacetat) được dùng để **"kéo" nitơ ra ngoài bằng đường khác**: mỗi phân tử phenylacetylglutamin mang theo **2 nguyên tử N** của glutamin ra nước tiểu, thay cho ure. Natri benzoat (tạo hippurat, mang 1 N của glycin) cũng dùng theo cùng nguyên lý. Đây là ứng dụng trực tiếp của phản ứng liên hợp trong sách.

**f) Liên hợp với glutathion** *(bổ sung — giáo trình không liệt kê ở chương này)*

**Glutathion** (GSH, γ-Glu-Cys-Gly; hs-09, mục 7.2) dùng nhóm –SH của cystein để gắn vào các chất **ái điện tử** (electrophil) độc, phản ứng có enzym **glutathion S-transferase** (GST) xúc tác. Sản phẩm được cắt dần thành dẫn xuất cystein rồi acetyl hóa thành **acid mercapturic**, thải qua nước tiểu. Đây là "lá chắn" chính của tế bào gan chống lại các chất chuyển hóa hoạt động mạnh như **NAPQI**.

### 4.3. Hai hệ thống enzym khử độc và hiện tượng cảm ứng enzym

Các phản ứng trên do **hai hệ thống enzym chính** thực hiện (Giáo trình tr. 285):

1. **Hệ thống oxidase chức năng hỗn hợp** ở **lưới nội bào trơn**, cần **cytochrom P450**.
2. **Hệ thống enzym xúc tác phản ứng liên hợp** (UGT, sulfotransferase, GST, N-acetyltransferase…).

**Cảm ứng enzym.** Nhiều chất nội sinh và ngoại sinh làm **tăng tổng hợp** các enzym thuộc hai hệ thống này; người ta đã biết **hàng trăm chất** như vậy. Khi bị cảm ứng, gan chuyển hóa **nhanh hơn** cả chất gây cảm ứng lẫn **nhiều chất khác**. Giáo trình nhấn mạnh: đây là hiện tượng cần chú ý khi **phối hợp thuốc** (Giáo trình tr. 285). Về hình thái, dùng lâu các thuốc cảm ứng làm **lưới nội bào trơn tăng sinh** (sh-02).

**Cytochrom P450 (CYP)** *(bổ sung)*: là một **họ** hemoprotein (có nhân hem, nên gan cần tổng hợp nhiều hem; hs-10). Ở người có khoảng 57 gen CYP; vài dạng chuyển hóa phần lớn thuốc:

| Dạng CYP | Thuốc/chất tiêu biểu | Điểm cần nhớ |
|---|---|---|
| **CYP3A4** | Khoảng một nửa số thuốc: nhiều statin (simvastatin, atorvastatin), thuốc chẹn kênh calci, ciclosporin, tacrolimus, thuốc tránh thai | Bị **bưởi chùm**, clarithromycin, ketoconazol **ức chế**; bị rifampicin, carbamazepin, **Ban Âu** **cảm ứng** |
| **CYP2D6** | Codein, nhiều thuốc chống trầm cảm, chẹn β | Đa hình di truyền rất mạnh (người chuyển hóa "siêu nhanh" và "kém") |
| **CYP2C9** | Warfarin, nhiều NSAID | Tương tác làm thay đổi tác dụng chống đông của warfarin |
| **CYP2E1** | **Ethanol** (hệ MEOS), **paracetamol → NAPQI**, CCl~4~, halothan | **Rượu dùng lâu cảm ứng** CYP2E1 |
| **CYP1A2** | Caffein, theophyllin | **Khói thuốc lá cảm ứng** |

> [!ung-dung] Tương tác thuốc qua CYP — hai chiều ngược nhau
> - **Chất ức chế CYP** → thuốc kia chuyển hóa **chậm**, nồng độ trong máu **tăng** → **ngộ độc**. Ví dụ: simvastatin + clarithromycin → nguy cơ **tiêu cơ vân**; ciclosporin + ketoconazol → độc thận.
> - **Chất cảm ứng CYP** → thuốc kia chuyển hóa **nhanh**, nồng độ **giảm** → **thất bại điều trị**. Ví dụ: rifampicin làm **thuốc tránh thai uống mất tác dụng**; phenobarbital, carbamazepin làm giảm tác dụng warfarin.
> - Cảm ứng cần **vài ngày đến 1–2 tuần** (phải tổng hợp enzym mới), và **tan dần** sau khi ngừng chất cảm ứng. Ức chế thường xuất hiện **ngay**.
> - **Ngừng** một chất cảm ứng đột ngột cũng nguy hiểm: thuốc kia (đã được tăng liều để bù) bây giờ tích lũy lại.

### 4.4. Ứng dụng: ngộ độc paracetamol

![Hình 2. Chuyển hóa paracetamol ở liều thường và khi quá liều](paracetamol.svg)

**Ở liều điều trị**, phần lớn paracetamol được **liên hợp trực tiếp** (pha II) với **acid glucuronic** và **sulfat** rồi thải qua nước tiểu. Chỉ khoảng 5–10% đi qua **CYP2E1** (và CYP3A4, CYP1A2) tạo **NAPQI** (*N*-acetyl-*p*-benzoquinon imin), một chất **ái điện tử rất mạnh**. NAPQI lập tức bị **glutathion** liên hợp, thành dẫn xuất cystein, acid mercapturic, vô hại.

**Khi quá liều** (người lớn, thường từ khoảng **150 mg/kg** hoặc trên 7,5–10 g một lần):

1. Con đường glucuronid và sulfat **bão hòa** → nhiều paracetamol bị đẩy sang CYP → **NAPQI tăng vọt**.
2. **Glutathion gan cạn dần**. Khi còn dưới khoảng 30% mức bình thường, NAPQI không còn bị trung hòa.
3. NAPQI **gắn cộng hóa trị vào nhóm –SH của protein** tế bào (nhất là protein ty thể) → stress oxy hóa, tế bào gan **hoại tử**, nặng nhất ở **vùng quanh tĩnh mạch trung tâm tiểu thùy** (vùng 3, nơi có nhiều CYP2E1 nhất).
4. Xét nghiệm: **ALT, AST tăng rất cao** (hàng nghìn U/L) sau 24–72 giờ; nặng thì **PT/INR tăng**, hạ glucose máu, toan lactic, bệnh não gan.

**Thuốc giải độc: N-acetylcystein (NAC)** cung cấp **cystein** để gan **tổng hợp lại glutathion** (hs-09); NAC cũng có thể giúp tăng liên hợp sulfat. NAC hiệu quả nhất khi dùng **trong vòng 8–10 giờ** sau uống; muộn hơn vẫn nên dùng.

> [!bay]
> - **Người nghiện rượu mạn** và **người suy dinh dưỡng, nhịn đói** dễ ngộ độc paracetamol ở liều thấp hơn: rượu lâu ngày **cảm ứng CYP2E1** (tạo nhiều NAPQI hơn), còn thiếu ăn làm **glutathion dự trữ thấp**.
> - Những giờ đầu sau uống quá liều, người bệnh có thể **gần như không có triệu chứng** và ALT **còn bình thường**. Không được dựa vào ALT ban đầu để loại trừ ngộ độc; phải đo **nồng độ paracetamol máu** (từ giờ thứ 4) và điều trị theo đó.
> - Nhiều thuốc cảm cúm, giảm đau phối hợp **đều chứa paracetamol** (xem hc-02). Uống nhiều loại cùng lúc dễ vượt liều tối đa (người lớn thường không quá **4 g/ngày**).

> [!yhct] Thảo dược và cytochrom P450: tương tác có thật, mức bằng chứng khác nhau
> - **Ban Âu** (*Hypericum perforatum*, St John's wort; khác loài với **Cỏ ban/Điền cơ hoàng** *Hypericum japonicum* dùng ở Việt Nam): hoạt chất **hyperforin** hoạt hóa thụ thể nhân **PXR** → **cảm ứng CYP3A4** (và bơm thải thuốc P-glycoprotein — xem bài *Hóa sinh màng tế bào*, mã hs-13). **Bằng chứng lâm sàng rõ ở người**: làm giảm nồng độ **ciclosporin** (đã có ca thải ghép), thuốc kháng HIV, **thuốc tránh thai uống**, digoxin, warfarin. Nhiều nước bắt buộc ghi cảnh báo tương tác trên nhãn.
> - **Bưởi chùm** (ức chế "tự sát" CYP3A4 ở ruột) và **berberin** của Hoàng liên, Hoàng bá (ức chế CYP2D6, 2C9, 3A4): đã trình bày ở bài *Enzym* (mã hs-05, mục 7.6 và mục 10). **Bưởi ta** (*Citrus maxima*) cũng chứa furanocoumarin và đã có báo cáo ca bệnh tăng nồng độ tacrolimus; người dùng thuốc chuyển hóa qua CYP3A4 nên thận trọng.
> - **Tổn thương gan do thảo dược** (**Hà thủ ô đỏ**; **Thổ tam thất** chứa alkaloid pyrrolizidin): xem khung YHCT ở bài *Chuyển hóa acid amin* (mã hs-09, mục 8.4). Điểm bổ sung từ bài này: pyrrolizidin **tự nó chưa độc**; chính **CYP3A4 của gan** biến nó thành dẫn xuất pyrrol hoạt động, phá hủy tế bào nội mô xoang gan. Vì vậy người đang dùng chất **cảm ứng CYP3A4** có thể nhạy cảm hơn.
> - **Ý nghĩa thực hành:** trước khi kê thuốc thang hay chế phẩm thảo dược cho người đang dùng thuốc tây có "khoảng điều trị hẹp" (warfarin, ciclosporin, tacrolimus, thuốc chống động kinh, thuốc tránh thai), phải hỏi kỹ và cân nhắc. Đây là tương tác **dược động học** có cơ chế hóa sinh đã chứng minh, khác với quan niệm "tương phản, tương úy" trong phối ngũ YHCT.

## 5. Một số xét nghiệm hóa sinh về gan

Bệnh gan có thể gây **tổn thương tế bào gan** (viêm gan virus, ung thư gan, ngộ độc thuốc, hóa chất…), **ứ mật** (viêm gan, sỏi mật…) hoặc **suy giảm chức năng** tế bào gan (xơ gan, suy gan…). Nhiều bệnh **kết hợp** cả ba, với mức độ tùy loại bệnh và giai đoạn. Do đó xét nghiệm gan được chia thành **ba nhóm** (Giáo trình tr. 285).

![Hình 3. Đọc bộ xét nghiệm gan theo ba nhóm](xet-nghiem-gan.svg)

*Khoảng tham chiếu dưới đây theo giáo trình (đo ở 37 °C) kèm giá trị thường dùng hiện nay; chỉ để **tham khảo, mỗi phòng xét nghiệm có khoảng riêng**. Nguyên lý "enzym thoát ra máu khi tế bào vỡ" và bảng enzym chẩn đoán chung: xem **hs-05, mục 9**.*

### 5.1. Xét nghiệm đánh giá tổn thương hủy hoại tế bào gan

#### a) Aminotransferase (transaminase): AST và ALT

| | **AST** (GOT, aspartat aminotransferase) | **ALT** (GPT, alanin aminotransferase) |
|---|---|---|
| Phân bố | **Rộng**: gan, **tim, cơ xương** (cả hồng cầu) | **Trước hết ở gan**, ít ở thận, cơ xương |
| Vị trí trong tế bào | Bào tương + **ty thể** | **Bào tương** |
| Giá trị bình thường (giáo trình) | Nam **10–50 U/L**, nữ **10–35 U/L** (nhiều phòng xét nghiệm Việt Nam ghi chung ≤ 40 U/L — hs-05) | Nam **10–50 U/L**, nữ **10–35 U/L** (nhiều phòng xét nghiệm ghi ≤ 40 U/L) |
| Ý nghĩa | Kém đặc hiệu gan | **Đặc hiệu gan hơn** |

(Giáo trình tr. 285–286)

- **Viêm gan virus**: cả ALT và AST đều tăng, nhưng **ALT tăng nhiều hơn**, có thể **hàng trăm lần** bình thường (theo giáo trình).
- Theo dõi viêm gan cấp: nếu enzym huyết thanh **tăng kéo dài hơn 7–8 tuần**, bệnh có thể chuyển thành **mạn tính** hoặc **xơ gan**.
- Tăng trong tổn thương gan do nhiều nguyên nhân khác: **nhiễm độc rượu cấp** có mê sảng, thuốc mê **halothan**, **CCl~4~**…; và trong các bệnh gan khác như **tắc mật, ung thư gan** (tăng ở mức độ khác nhau).

> [!bay] Tỷ số AST/ALT (De Ritis)
> - Viêm gan virus, do thuốc, gan nhiễm mỡ chuyển hóa: thường **ALT > AST** (tỷ số < 1).
> - **Bệnh gan do rượu**: thường **AST/ALT > 2**, và hiếm khi AST vượt 300–400 U/L. Lý do: rượu làm **thiếu vitamin B~6~** (PLP), mà ALT phụ thuộc PLP nhiều hơn; rượu còn hại **ty thể**, nơi có AST ty thể.
> - AST tăng đơn độc, ALT bình thường → nghĩ tới **tim, cơ** (nhồi máu cơ tim, tiêu cơ vân, tập luyện nặng) hoặc mẫu bị **tan máu**.

#### b) γ-glutamyl transferase (GGT, γGT)

(Giáo trình tr. 286)

- Enzym **gắn ở màng tế bào**; nồng độ cao ở **thận, tụy và gan** (đường mật).
- Bình thường: nam **9–40 U/L**, nữ **9–35 U/L**.
- Cung cấp thông tin hữu ích về bệnh gan – mật, nhưng **không phân biệt được** tắc mật với bệnh tế bào gan. Trong tắc mật, GGT có thể **tăng trước ALP**; GGT **tăng cao nhất trong tắc đường mật**.
- Hầu hết bệnh gan – mật đều có GGT tăng. Tăng cao khi tổn thương gan do nhiễm độc cấp: **rượu**, CCl~4~, halothan…
- Dùng trong chẩn đoán **ung thư gan** ở người **không vàng da**, và để xác định **nguồn gốc gan** của ALP tăng.
- GGT còn tăng trong **bệnh tụy** và **nhiễm trùng cấp**.

> [!ung-dung] GGT và người uống rượu
> Rượu **cảm ứng** gan tổng hợp GGT (không cần tế bào vỡ), nên GGT là chỉ số nhạy để phát hiện và **theo dõi cai rượu**: GGT giảm dần trong vài tuần sau khi ngừng uống. Các thuốc cảm ứng enzym (phenytoin, carbamazepin, phenobarbital) cũng làm GGT tăng nhẹ mà gan không bệnh (xem hs-05, mục 8).

#### c) Lactat dehydrogenase (LDH)

(Giáo trình tr. 286)

- Bình thường: nam **135–225 U/L**, nữ **134–215 U/L**.
- Có ở **bào tương của mọi tế bào**, nên LDH tăng **không đặc hiệu** cho cơ quan nào.
- Phân tích **isoenzym** có giá trị hơn: **LDH~5~** có nhiều ở **gan và cơ xương**. LDH~5~ tăng nhẹ trong vàng da, bệnh đường mật; tăng vừa trong viêm gan virus cấp, xơ gan; **tăng cao trong ung thư gan** nguyên phát hoặc thứ phát.

#### d) Glutamat dehydrogenase (GLDH)

(Giáo trình tr. 286–287)

- Enzym có nhiều ở **ty thể** tế bào gan, tim, thận.
- Tổn thương gan **nhẹ** (viêm gan cấp tuần đầu) hoặc ít (viêm gan mạn, xơ gan): GLDH **tăng nhẹ**. Tổn thương **nặng, sâu** (tế bào gan hoại tử, ty thể vỡ): GLDH **tăng cao**.
- **Vì sao?** Enzym bào tương (ALT) thoát ra ngay khi màng tế bào "rò rỉ"; enzym **ty thể** (GLDH, AST ty thể) chỉ ra khi **bào quan bị phá hủy**. GLDH vì thế phản ánh **mức độ sâu** của tổn thương.

> [!bay] Khoảng tham chiếu GLDH trong giáo trình
> Giáo trình ghi GLDH bình thường nam 9–40 U/L, nữ 9–35 U/L, **trùng hệt** khoảng của GGT ngay trang trước. Các tài liệu hóa sinh lâm sàng thường ghi GLDH người lớn chỉ khoảng **dưới 5–7 U/L** (37 °C). Nhiều khả năng sách bị lặp số. Đi thi, nếu được hỏi số, dùng số của giáo trình; khi đọc phiếu xét nghiệm thật, theo khoảng của phòng xét nghiệm.

### 5.2. Xét nghiệm đánh giá tình trạng ứ mật

#### a) Phosphatase kiềm (ALP, *alkaline phosphatase*)

(Giáo trình tr. 287)

- Bình thường (giáo trình): nam và nữ **30–90 U/L**. Hiện nay theo phương pháp IFCC, người lớn thường khoảng **40–130 U/L**.
- **Tăng sinh lý**: phụ nữ có thai (3 tháng cuối, do ALP **nhau thai**), **trẻ em đang lớn** (ALP **xương**).
- Nguồn gốc: chủ yếu ở **xương** (tạo cốt bào), phần nhỏ hơn ở **gan** (giáo trình ghi "microsom gan"; chính xác hơn là màng tế bào gan phía **vi quản mật**).
- Trong bệnh gan:
  - **tăng nhẹ đến vừa** khi rối loạn chức năng tế bào gan (viêm gan, xơ gan);
  - **tăng mạnh** khi **tắc mật ngoài gan** (sỏi ống mật chủ, u đầu tụy) và **tắc mật trong gan** (do thuốc, xơ đường mật nguyên phát);
  - **luôn luôn tăng** trong **ung thư gan di căn**.
- Ngoài gan: tăng trong bệnh **xương** (bệnh Paget, u di căn xương) và mọi tình trạng tăng hoạt động tạo cốt bào.

**Vì sao tắc mật làm ALP tăng?** Ứ mật làm tế bào gan **tăng tổng hợp** ALP (cảm ứng), và muối mật ứ lại "hòa tan" ALP khỏi màng đưa vào máu. Vì là cảm ứng tổng hợp, ALP tăng **chậm hơn** (vài ngày) so với ALT trong viêm gan.

> [!bay] ALP tăng — gan hay xương?
> Làm thêm **GGT**: ALP tăng **kèm GGT tăng** → nguồn **gan – mật**; ALP tăng mà **GGT bình thường** → nghĩ tới **xương**, thai kỳ hoặc tuổi đang lớn. GGT không có trong xương, đó là lý do giáo trình nói GGT dùng "chẩn đoán bệnh lý gan ở bệnh nhân có tăng hoạt độ phosphatase kiềm".

#### b) Bilirubin huyết thanh

(Giáo trình tr. 287; chuyển hóa bilirubin và bảng phân biệt ba loại vàng da: **hs-10, mục 2**)

- Nồng độ bilirubin huyết thanh là kết quả **cân bằng** giữa tốc độ **tạo** bilirubin (thoái hóa hem) và khả năng **thanh lọc** của gan.

| | Giáo trình | Đổi ra µmol/L (× 17,1) |
|---|---|---|
| Bilirubin toàn phần | **< 1 mg/dL** | < khoảng **17 µmol/L** |
| Bilirubin tự do (gián tiếp) | **< 0,8 mg/dL** | < khoảng 14 µmol/L |
| Bilirubin liên hợp (trực tiếp) | **< 0,2 mg/dL** | < khoảng **3,4 µmol/L** |

- Khi bilirubin toàn phần tăng, phải định lượng riêng **hai phân đoạn**:
  - Tăng bilirubin **liên hợp** khi **trên 50%** bilirubin toàn phần là dạng liên hợp (tắc mật, viêm gan);
  - Tăng bilirubin **tự do** khi **trên 80%** là dạng tự do (tan máu, hội chứng Gilbert).

#### c) Alpha-fetoprotein (AFP)

(Giáo trình tr. 287–288)

- AFP là một **glycoprotein** do **gan thai nhi** tổng hợp; giáo trình ghi nó biến mất khoảng **4 tuần sau sinh** khi gan ngừng tổng hợp (thực tế AFP giảm dần, về mức người lớn vào khoảng **8–12 tháng tuổi**; vì vậy AFP ở trẻ nhỏ phải đọc theo khoảng tham chiếu theo tuổi). Người trưởng thành khỏe mạnh: không có hoặc rất ít.
- AFP **không** phản ánh tổn thương hay chức năng gan; nó là **dấu ấn ung thư**: tăng **rất cao (hàng trăm lần)** trong **ung thư gan nguyên phát** (ung thư biểu mô tế bào gan), tăng ít hơn trong ung thư gan thứ phát, viêm gan virus cấp và mạn.

> [!ung-dung] AFP trong thực hành
> Người **viêm gan B, C mạn** hoặc **xơ gan** (nhóm nguy cơ cao ung thư gan, rất phổ biến ở Việt Nam) được tầm soát định kỳ bằng **siêu âm gan ± AFP** khoảng **6 tháng/lần**. AFP bình thường **không loại trừ** ung thư gan (khoảng một nửa khối u nhỏ không tăng AFP); AFP còn tăng ở phụ nữ có thai và u tế bào mầm. Vì vậy AFP luôn được đọc **cùng hình ảnh học**.

### 5.3. Xét nghiệm thăm dò, đánh giá chức năng gan

#### a) Nghiệm pháp bài tiết BSP (bromosulfophthalein)

(Giáo trình tr. 288)

- Dựa trên khả năng gan **giữ chất màu** từ huyết tương và **thải vào mật** (cơ chế cố định – thải trừ, mục 4.1).
- Cách làm: tiêm tĩnh mạch BSP liều **5 mg/kg** cân nặng; sau **45 phút** lấy máu đo lượng BSP còn lại.
- Kết quả: chức năng gan **bình thường** nếu gan thải được **95%** chất màu trong 45 phút (còn lại **≤ 5%**). BSP còn lại **> 5%**: tỷ lệ thuận với mức độ **suy giảm chức năng gan**.

> [!cap-nhat] Nghiệm pháp BSP đã bị bỏ
> BSP có nguy cơ gây **phản ứng phản vệ** (có ca tử vong) và hoại tử nếu thoát mạch, nên **không còn dùng** trên lâm sàng. Nguyên lý tương tự hiện chỉ còn ở nghiệm pháp **xanh indocyanin** (ICG), dùng hạn chế (vd đánh giá trước phẫu thuật cắt gan). Đi thi vẫn cần nhớ liều 5 mg/kg, 45 phút, ngưỡng 5%.

#### b) Albumin huyết thanh

(Giáo trình tr. 288)

- Bình thường **35–50 g/L**, chiếm **53–65%** protein toàn phần huyết thanh.
- Albumin là protein có ý nghĩa nhất để đánh giá **khả năng tổng hợp** của gan.
- Nồng độ albumin còn phụ thuộc: **dinh dưỡng** (lượng acid amin trong thức ăn, đặc biệt **tryptophan**), **hormon**, **áp lực thẩm thấu**, **chức năng thận** (mất qua nước tiểu trong hội chứng thận hư).
- **Thời gian bán hủy của albumin khoảng 20 ngày**. Vì thế khi gan bệnh, albumin **không giảm ngay**; sự suy giảm tổng hợp chỉ phát hiện được sau khoảng **3 tuần**.
- Ý nghĩa: albumin đánh giá bệnh gan **mạn tính** hơn là cấp tính. Albumin giảm nghĩa là gan đã suy giảm chức năng **từ trước đó khá lâu**. Albumin **bình thường chưa loại trừ** bệnh gan cấp.

> [!vi-du] Vì sao người xơ gan bị phù, cổ trướng?
> Albumin tạo phần lớn **áp suất keo** của huyết tương (vl-03), giữ nước trong lòng mạch. Albumin giảm → nước thoát ra mô kẽ (**phù**) và ổ bụng (**cổ trướng**); tăng áp lực tĩnh mạch cửa làm cổ trướng nặng thêm. Albumin còn chở bilirubin tự do, acid béo, nhiều thuốc; albumin thấp làm phần thuốc **tự do** tăng, dễ quá liều.

### 5.4. Bổ sung: các xét nghiệm hay dùng hiện nay

Giáo trình không trình bày các xét nghiệm sau, nhưng chúng có trong hầu hết phiếu xét nghiệm gan ngày nay.

| Xét nghiệm | Bình thường (tham khảo) | Ý nghĩa |
|---|---|---|
| **Thời gian prothrombin (PT)** và **INR** | PT khoảng 11–14 giây; INR khoảng 0,8–1,2 | Đo các yếu tố đông máu **do gan tổng hợp** (II, V, VII, X, fibrinogen). Yếu tố VII có thời gian bán hủy chỉ khoảng **6 giờ**, nên PT/INR là chỉ số **sớm nhất** của suy chức năng tổng hợp trong **suy gan cấp** (khác với albumin) |
| **NH~3~ máu** | Khoảng dưới 35–50 µmol/L (tùy phương pháp) | Tăng khi gan không tổng hợp được ure hoặc máu cửa đi tắt qua gan (xơ gan có tuần hoàn bàng hệ) → **bệnh não gan**. Lấy mẫu và đọc kết quả: xem **hs-09, mục 8.3–8.4** |
| **Protein toàn phần, tỷ số A/G** | Protein 60–80 g/L; A/G khoảng 1,2–2 | A/G **giảm hoặc đảo ngược** trong xơ gan (albumin ↓, globulin ↑) |
| **Ure máu** | Khoảng 2,5–7,5 mmol/L | **Giảm** trong suy gan rất nặng (mục 2.3) |
| **Cholesterol ester / toàn phần** | Khoảng 60–70% (theo giáo trình tr. 279) | Giảm khi suy tế bào gan (thiếu LCAT); ít dùng hiện nay |

> [!ung-dung] Phân biệt PT kéo dài do suy gan và do tắc mật — nghiệm pháp vitamin K (Koller)
> Tiêm **vitamin K** rồi đo lại PT sau 24–48 giờ:
> - PT **trở về bình thường** → gan vẫn tổng hợp tốt, chỉ thiếu vitamin K (do **tắc mật** làm kém hấp thu, hoặc dùng kháng sinh kéo dài, thuốc kháng vitamin K).
> - PT **không cải thiện** → **tế bào gan suy**, không còn đủ khả năng tổng hợp protein đông máu.

> [!ung-dung] Đọc kiểu tổn thương gan do thuốc bằng tỷ số R
> Khi nghi tổn thương gan do thuốc hoặc thảo dược, người ta tính:
> **R = (ALT ÷ giới hạn trên của ALT) ÷ (ALP ÷ giới hạn trên của ALP)**.
> - **R ≥ 5**: kiểu **tổn thương tế bào gan** (paracetamol, isoniazid, Hà thủ ô…).
> - **R ≤ 2**: kiểu **ứ mật** (amoxicilin – acid clavulanic, steroid đồng hóa…).
> - **2 < R < 5**: kiểu **hỗn hợp**.
>
> Kèm theo "**quy luật Hy**": tổn thương tế bào gan do thuốc mà **ALT > 3 lần** giới hạn trên **và bilirubin toàn phần > 2 lần** giới hạn trên (không do tắc mật) là dấu hiệu **nặng**, tỷ lệ tử vong hoặc phải ghép gan khoảng 10%. Phải **ngừng ngay** thuốc nghi ngờ.

> [!bay] Những nhầm lẫn kinh điển khi đọc xét nghiệm gan
> - "Men gan" (ALT, AST) **không** phải "chức năng gan". Ở **xơ gan giai đoạn cuối**, ALT có thể **gần bình thường** (còn ít tế bào để vỡ) trong khi albumin rất thấp và INR rất cao.
> - **ALT giảm nhanh** kèm **bilirubin và INR tăng** trong viêm gan cấp nặng là dấu hiệu **xấu** (gan "hết tế bào để chết"), không phải đang hồi phục.
> - Albumin là chỉ số của bệnh **mạn** (bán hủy ≈20 ngày); PT/INR mới là chỉ số của **suy gan cấp**.
> - Thiếu B~6~ làm ALT, AST **thấp giả** (ở người nghiện rượu, suy dinh dưỡng, chạy thận).

## Tóm tắt

| Chủ đề | Điều cốt lõi |
|---|---|
| Thành phần gan | Nước 70–75%; protein ≈ 1/2 chất khô (albumin, globulin, collagen, **ferritin = apoferritin + Fe**); glycogen **2–10%**; lipid ≈ 5% khô (40% trung tính, 50% phospholipid, 10% cholesterol); vitamin A, D, K, B~12~ |
| Glucid | Dự trữ glycogen; tạo glycogen từ galactose, fructose, mannose, lactat, pyruvat; **glucose-6-phosphatase** → trả glucose vào máu → gan điều hòa glucose máu; tạo **acid glucuronic** |
| Lipid | β-oxy hóa mạnh → **thể ceton** cho mô khác (gan không dùng); tổng hợp **phospholipid**, lipoprotein (VLDL) đưa lipid ra khỏi gan (thiếu → gan nhiễm mỡ); tạo phần lớn cholesterol; cholesterol ester 60–70%, **giảm khi suy gan** |
| Protein | **Toàn bộ albumin**, một phần globulin, fibrinogen, prothrombin; A/G giảm khi suy gan; AST, ALT, GLDH; **duy nhất tổng hợp ure** (còn bình thường khi mất 3/4 gan); liên hợp bilirubin |
| Mật | ≈1000 ml/ngày; muối mật, sắc tố mật, cholesterol; acid cholic, deoxycholic, lithocholic + **glycin/taurin** + Na^+^/K^+^ → glycocholat, taurocholat; nhũ tương hóa, hoạt hóa lipase, tăng nhu động, thải độc; tái hấp thu 80–90% (nay: ≈95%) |
| Khử độc 1 | **Cố định – thải trừ** nguyên dạng qua mật: kim loại nặng (Cu, Pb), chất màu (cơ sở nghiệm pháp BSP) |
| Khử độc 2 | **Hóa học**: NH~3~ → ure; H~2~O~2~ → catalase. **Oxy hóa** (ethanol → acetaldehyd → acetat; hexobarbital; acetanilid → p-hydroxyacetanilid; phenylethylamin; trimethylamin N-oxid), **khử** (cloral → tricloroethanol; cloramphenicol), **thủy phân** (procain), **liên hợp** (glucuronic qua **UDPGA**; sulfat: phenol, indol, steroid; acetic: PABA, sulfamid; **glycin: benzoic → hippuric**; **glutamin: phenylacetic → phenylacetylglutamin**; bổ sung: glutathion) |
| Enzym khử độc | Oxidase chức năng hỗn hợp (**cytochrom P450**, lưới nội bào trơn) + enzym liên hợp; **cảm ứng enzym** → tương tác thuốc. Hiện nay: **pha I** / **pha II** |
| Paracetamol | Liều thường: glucuronid + sulfat; ≈5–10% → CYP2E1 → **NAPQI** + GSH. Quá liều: GSH cạn → hoại tử vùng 3 → ALT hàng nghìn; giải độc **N-acetylcystein** |
| Tổn thương tế bào | **ALT** (đặc hiệu gan, tăng hơn AST trong viêm gan virus), **AST** (gan, tim, cơ), nam 10–50, nữ 10–35 U/L; tăng > 7–8 tuần → mạn; **GGT** (màng; rượu, tắc mật); **LDH~5~** (ung thư gan); **GLDH** (ty thể → tổn thương sâu) |
| Ứ mật | **ALP** (30–90 U/L theo sách; xương, gan, nhau thai; tắc mật tăng mạnh, di căn gan luôn tăng); bilirubin TP < 1 mg/dL (17 µmol/L), liên hợp > 50% → tăng BR liên hợp, tự do > 80% → tăng BR tự do; **AFP** = dấu ấn ung thư gan nguyên phát |
| Chức năng | **BSP** 5 mg/kg, 45 phút, còn ≤ 5% (đã bỏ); **albumin** 35–50 g/L, bán hủy ≈20 ngày → bệnh mạn; bổ sung **PT/INR** (suy gan cấp), **NH~3~** (bệnh não gan) |
