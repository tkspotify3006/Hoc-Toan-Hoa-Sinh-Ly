---
title: Hóa sinh các dịch sinh vật
thoi-gian: 40 phút
muc-tieu:
- Trình bày được sự tạo thành, tính chất và thành phần hóa học của dịch não tủy (protein, glucose, lactat, enzym, chất vô cơ) và ý nghĩa của từng chỉ số.
- Vận dụng được các chỉ số dịch não tủy (protein, glucose, Cl^−^, lactat, tế bào) để phân biệt viêm màng não do vi khuẩn, do lao và do virus.
- Trình bày được thành phần hóa học của sữa mẹ (protein, lipid, glucid, chất khoáng, vitamin, enzym), đặc điểm của sữa non, và so sánh được sữa mẹ với sữa bò.
- Trình bày được thành phần của dịch vị: HCl (nguồn gốc, cơ chế bài tiết, điều hòa), các enzym (pepsin, cathepsin, rennin, lipase), mucin; liên hệ với xét nghiệm dịch vị và thuốc ức chế bơm proton.
- Nêu được nguồn gốc và thành phần của dịch bạch huyết so với huyết tương.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. **Dịch não tủy** = huyết tương được **siêu lọc** qua đám rối mạch mạc: trong, không màu, ≈150 ml, tạo 500 ml/ngày. **Protein rất thấp** (≈1/250 huyết tương), **glucose = 60–80% máu**, **Cl^−^ cao hơn máu** (120–130 mEq/L).
> 2. Viêm màng não **vi khuẩn**: glucose **giảm mạnh**, protein tăng, lactat > 3,5 mmol/L, bạch cầu **đa nhân trung tính**. **Lao**: glucose giảm, protein tăng rất cao, **Cl^−^ giảm mạnh**, **lympho**. **Virus**: glucose **gần bình thường**, protein tăng nhẹ, lactat < 3 mmol/L, lympho.
> 3. **Sữa mẹ**: protein 1–1,5 g/100 ml (casein + lactalbumin + lactoglobulin), **lactose ≈7 g/100 ml**, lipid nhũ tương giàu acid béo chưa no cần thiết, nhiều oligosaccharid nuôi vi khuẩn **bifidus**, có enzym. **Sữa non** giàu protein, giàu **kháng thể**.
> 4. **Dịch vị** 2–3 lít/ngày, pH 1–2. **Tế bào viền** tiết **HCl** (H^+^ từ H~2~CO~3~, Cl^−^ từ NaCl máu, bơm chủ động); **tế bào chính** tiết **pepsinogen** → pepsin (nhờ HCl, tự hoạt hóa). **Gastrin kích thích**, secretin – cholecystokinin **ức chế** tiết HCl. Mucin bảo vệ niêm mạc.
> 5. **Bạch huyết** = dịch lọc từ huyết tương qua thành mạch: glucose, ure như huyết tương; **protein thấp hơn** (chân < ruột < gan); sau bữa ăn bạch huyết ruột và ống ngực **đục như sữa** do lipid thức ăn (chylomicron).

Chương này xem xét bốn loại dịch: **dịch não tủy**, **sữa**, **dịch vị** và **bạch huyết**. Điểm chung là cả bốn đều có nguồn gốc từ **huyết tương**: hoặc được lọc ra (dịch não tủy, bạch huyết), hoặc được tế bào tuyến "chế biến" lại (sữa, dịch vị). Vì vậy cách học hiệu quả là luôn **so sánh với huyết tương** (hs-19): chất nào cao hơn, chất nào thấp hơn, vì sao.

## 1. Dịch não tủy

### 1.1. Tạo thành, lưu thông và chức năng

- **Tạo thành:** dịch não tủy (DNT; *cerebrospinal fluid*, CSF) được tạo ra chủ yếu ở **đám rối mạch mạc** (*choroid plexus*) trong các não thất, như một quá trình **siêu lọc huyết tương**. Hàng rào giữa máu và DNT (giáo trình gọi chung là **hàng rào máu não**) chỉ cho qua nước, ion, phân tử nhỏ; protein lớn qua rất ít.
- **Vị trí:** DNT có trong **não thất**, **ống tủy** và **khoang dưới nhện**.
- **Lưu thông và tái hấp thu:** DNT được tạo ra liên tục và cũng tự tiêu đi liên tục. Nó được hấp thu qua các **nhung mao màng nhện** (*arachnoid villi*) vào xoang tĩnh mạch ở não và đám rối tĩnh mạch quanh tủy sống.
- **Lượng tạo ra:** khoảng **500 ml/ngày** (Giáo trình tr. 341).
- **Chức năng:** làm "đệm nước" **bảo vệ thần kinh trung ương** trước thay đổi áp lực và sang chấn.

> [!vi-du] Một phép tính nhỏ cho thấy DNT "thay mới" rất nhanh
> Tổng lượng DNT ở người lớn khoảng 150 ml, mà mỗi ngày tạo ra 500 ml. Vậy DNT được **thay mới khoảng 3–4 lần mỗi ngày**. Khi đường thoát bị tắc (u, dị dạng), dịch vẫn tiếp tục được tạo ra nên ứ lại, gây **não úng thủy** và tăng áp lực nội sọ.

### 1.2. Tính chất của dịch não tủy

| Đặc điểm | Giá trị theo giáo trình |
|---|---|
| Thể tích | Người lớn **≈150 ml**; trẻ sơ sinh 30–60 ml; trẻ dưới 1 tuổi ≈100 ml |
| Màu sắc | **Trong suốt, không màu** (như nước suối) |
| Tỷ trọng | **1,003–1,008** |
| Áp lực (chọc dò thắt lưng, tư thế nằm) | **80–180 mmH~2~O** |
| Lượng được phép rút | Người lớn **không quá 10–12 ml**; trẻ em **3–5 ml** |

DNT ở **não thất** và ở **tủy sống thắt lưng** có thành phần hơi khác nhau. Mẫu xét nghiệm thường lấy bằng **chọc dò tủy sống thắt lưng** (Giáo trình tr. 341).

> [!bay]
> - Không rút nhiều DNT một lúc: áp lực trong sọ giảm đột ngột có thể gây **tụt kẹt não**. Vì thế giáo trình giới hạn lượng rút (người lớn ≤ 10–12 ml, trẻ em 3–5 ml).
> - DNT **bình thường phải trong**. Đục (như nước vo gạo) gợi ý nhiều bạch cầu, tức viêm mủ. Có máu hoặc vàng (vàng do bilirubin từ hồng cầu vỡ) gợi ý xuất huyết, hoặc do chọc dò chạm mạch máu.

### 1.3. Protein

**Nguồn gốc.** Khoảng **80% protein** trong DNT đến từ **huyết tương**, khuếch tán qua hàng rào máu não. Phần còn lại do mô não – tủy **tự tổng hợp**. Ở người lớn, protein toàn phần trong DNT chỉ khoảng **1/250 so với huyết tương** (Giáo trình tr. 341–342).

**Vì sao thấp như vậy?** Hàng rào máu não chặn các phân tử lớn. Albumin (khoảng 66 kDa) chỉ lọt qua rất ít; IgG còn lớn hơn nên qua ít hơn nữa.

**Protein thay đổi theo tuổi** (Giáo trình tr. 342, Bảng 22.1): cao nhất ở **thai nhi và trẻ sơ sinh** (hàng rào máu não chưa hoàn thiện), thấp nhất ở trẻ 1–16 tuổi, rồi **tăng dần theo tuổi** ở người lớn.

| Tuổi (theo Bảng 22.1) | Protein toàn phần (mg/L, trung bình) |
|---|---|
| Thai 27–30 tuần | 1390 |
| Sơ sinh 0–1 tuần | 770 |
| 1–16 tuổi | 220 |
| 17–30 tuổi | 367 |
| 61–77 tuổi | 526 |

> [!ung-dung] Khoảng tham chiếu thường dùng
> Protein DNT người lớn khoảng **0,15–0,45 g/L** (150–450 mg/L). Đây là số liệu tham khảo, mỗi phòng xét nghiệm có khoảng riêng. Cần lưu ý đơn vị: DNT tính bằng **g/L hay mg/L**, còn protein huyết thanh tính bằng **chục g/L** (khoảng 60–80 g/L).

**Bốn nguyên nhân làm tăng protein DNT** (Giáo trình tr. 342):

1. **Tăng tính thấm của hàng rào máu não**, thường gặp nhất trong **viêm**.
2. **Giảm dòng chảy DNT**: tắc nghẽn do khối u, áp xe tủy. Dịch ứ lại phía dưới chỗ tắc nên protein bị cô đặc.
3. **Phản ứng miễn dịch**: cơ thể tăng tổng hợp **globulin miễn dịch** ngay trong hệ thần kinh.
4. **Hủy hoại mô thần kinh**: protein từ tế bào não bị giải phóng vào DNT.

**Các bệnh làm tăng protein DNT** (Giáo trình tr. 343, Bảng 22.2):

| Nhóm | Ví dụ |
|---|---|
| Nhiễm trùng | Viêm màng não do vi khuẩn, lao, nấm, virus; viêm não do virus; ký sinh trùng; áp xe não |
| Bệnh ác tính | U hệ thần kinh trung ương; thâm nhiễm màng não |
| Giảm dòng chảy DNT | U tủy; não úng thủy |
| Nguyên nhân khác | **Hội chứng Guillain–Barré**; neurosarcoidosis |

> [!bay] Phân ly đạm – tế bào
> Trong **hội chứng Guillain–Barré**, protein DNT **tăng** nhưng số **tế bào vẫn bình thường**. Hiện tượng này gọi là **phân ly đạm – tế bào**, là dấu hiệu kinh điển của bệnh. Ngược lại, trong viêm màng não thì protein và tế bào **cùng tăng**.

**Một số protein đặc biệt trong DNT** (Giáo trình tr. 343–344, Bảng 22.3):

| Protein | Giá trị bình thường (giáo trình) | Ý nghĩa |
|---|---|---|
| **CRP** (protein phản ứng C) | 1,5–37 µg/L | Do **gan** tổng hợp khi được cytokin (từ đại thực bào) kích thích; tế bào bị viêm **không** tạo CRP. Tăng rất cao trong **viêm màng não nhiễm khuẩn** |
| **Neopterin** (D-neopterin) | < 3 nmol/L | Sản phẩm oxy hóa 7,8-dihydroneopterin của **đại thực bào**; tăng khi nhiễm khuẩn, virus, nấm có kèm **đáp ứng miễn dịch tế bào** |
| **β~2~-microglobulin** | 0,6–2,1 mg/L | Tăng khi có **lympho bào hoạt hóa** trong hệ thần kinh; giúp phát hiện sớm **di căn lymphoma, leukemia** lên thần kinh |
| IgG, IgA, IgM, albumin, prealbumin (transthyretin), α~2~-microglobulin | Xem Bảng 22.3 | IgG tăng khi có tổng hợp kháng thể tại chỗ |

**Enzym trong DNT** có 3 nguồn: huyết thanh, tế bào thần kinh, và tế bào khối u hoặc tế bào viêm (Giáo trình tr. 344).

- **Enolase** (đặc hiệu neuron), **CK-BB** (isoenzym creatin kinase của não), **LDH**: là những chỉ thị **không đặc hiệu** cho mức độ tổn thương tế bào não.
- Hoạt độ các enzym này có thể tăng trong **viêm màng não nhiễm khuẩn**, và cả trong **ung thư phổi, ung thư vú** di căn.

### 1.4. Glucose

- DNT thắt lưng bình thường có glucose chỉ bằng **60–80% glucose huyết thanh**. DNT gần não thất có glucose **gần bằng** huyết thanh hơn (Giáo trình tr. 344).
- Glucose đi vào DNT nhờ **chất vận chuyển** (GLUT1) ở hàng rào máu não, tức là **khuếch tán có trung gian** (sh-04). Vì vậy glucose DNT **luôn đi theo glucose máu**, nhưng chậm hơn vài giờ (thường nêu khoảng 2–4 giờ).

**Glucose DNT tăng:** đái tháo đường, nhất là **hôn mê do đái tháo đường**; viêm não, động kinh, múa vờn, u não, xuất huyết não, tăng huyết áp.

**Glucose DNT giảm:** **viêm màng não nhiễm khuẩn** (não mô cầu, phế cầu, liên cầu) và **do lao**. Có trường hợp viêm màng não vi khuẩn glucose DNT chỉ còn khoảng **1 mmol/L**. Trong khi đó, viêm màng não **do virus** có glucose DNT **gần như bình thường** (Giáo trình tr. 344).

**Vì sao vi khuẩn làm glucose DNT giảm?** Có ba lý do cộng lại: **vi khuẩn và bạch cầu đa nhân** tiêu thụ glucose; mô não bị viêm tăng **đường phân yếm khí**; và viêm làm **giảm vận chuyển** glucose qua hàng rào. Virus thì nhân lên **bên trong** tế bào và không có "đội quân" bạch cầu đa nhân lớn, nên glucose ít bị tiêu thụ.

> [!bay] Luôn đọc glucose DNT cùng glucose máu
> Glucose DNT phải được so với **glucose máu lấy cùng lúc**. Bệnh nhân đái tháo đường có glucose máu 20 mmol/L thì glucose DNT 5 mmol/L là **thấp** (tỷ số 0,25). Ngược lại, một người hạ đường huyết có glucose DNT thấp chưa chắc đã bị viêm màng não. Trong thực hành, tỷ số **glucose DNT/máu < 0,4** gợi ý mạnh viêm màng não vi khuẩn. Glucose DNT bình thường khoảng **2,5–4,4 mmol/L** khi glucose máu bình thường (tham khảo, mỗi phòng xét nghiệm có khoảng riêng).

### 1.5. Lactat và LDH

- Lactat DNT thắt lưng bình thường: **1,1–2,4 mmol/L**.
- Lactat **> 3,5 mmol/L** gặp trong **viêm màng não nhiễm khuẩn**; lactat **< 3 mmol/L** thường gặp trong viêm màng não **do virus** (Giáo trình tr. 344).
- Hoạt độ **LDH** trong DNT có ý nghĩa và **nhạy hơn** nồng độ lactat, nhưng chưa được dùng rộng rãi.

**Vì sao lactat tăng?** Lactat DNT gần như **độc lập với lactat máu**, vì lactat qua hàng rào máu não rất chậm. Nó phản ánh **đường phân yếm khí tại chỗ**: vi khuẩn, bạch cầu và mô não thiếu oxy đều tạo lactat. Đây chính là "mặt kia" của hiện tượng glucose DNT giảm.

### 1.6. Các chất vô cơ

| Chất | Giá trị bình thường (giáo trình) | So với huyết thanh | Thay đổi bệnh lý |
|---|---|---|---|
| **Cl^−^** | **120–130 mEq/L** | **Cao hơn** | Giảm trong viêm màng não, viêm não, viêm tủy xám; **giảm mạnh trong viêm màng não lao** |
| Ca^2+^ | 2,43 ± 0,05 mEq/L | Tương đối ổn định | **Tăng** trong viêm màng não mủ, lao, chấn thương sọ não, xuất huyết não; **giảm** trong co giật, còi xương |
| Mg^2+^ | 2,4 ± 0,14 mEq/L | **Cao hơn** | — |
| HCO~3~^−^ | 24–30 mEq/L | Tương đương | — |

(Giáo trình tr. 344–345)

**Vì sao Cl^−^ trong DNT cao hơn huyết tương?** DNT có rất ít protein. Trong huyết tương, protein mang điện âm "chiếm chỗ" một phần anion. Ở DNT, phần anion thiếu hụt đó được Cl^−^ bù vào để giữ cân bằng điện tích. Ngoài ra đám rối mạch mạc còn chủ động tiết Cl^−^.

> [!cap-nhat] Cl⁻ dịch não tủy và chẩn đoán lao màng não
> Giáo trình nêu Cl^−^ DNT **giảm mạnh** trong viêm màng não lao (tr. 344). Đây là dấu hiệu kinh điển và vẫn hay gặp trong đề thi. Hiện nay, Cl^−^ DNT **ít được dùng** để chẩn đoán vì Cl^−^ DNT giảm chủ yếu do **Na^+^ và Cl^−^ máu giảm** (bệnh nhân lao màng não hay bị hạ natri máu), chứ không đặc hiệu cho lao. Chẩn đoán lao màng não ngày nay dựa vào: tế bào lympho, protein tăng cao, glucose giảm, kết hợp **tìm vi khuẩn lao** bằng nhuộm, cấy, **xét nghiệm sinh học phân tử** (như Xpert MTB/RIF) và **ADA** dịch não tủy. Đi thi vẫn trả lời theo giáo trình: Cl^−^ giảm mạnh trong lao màng não.

### 1.7. Ứng dụng: phân biệt viêm màng não theo nguyên nhân

Giáo trình không có mục riêng về **tế bào** trong DNT, nhưng xét nghiệm DNT trên lâm sàng luôn gồm **4 nhóm**: **sinh hóa** (protein, glucose, Cl^−^, lactat), **tế bào** (số lượng và loại), **vi sinh** và **áp lực/màu sắc**. DNT bình thường có rất ít tế bào: **≤ 5 tế bào/µL**, chủ yếu lympho.

![Hình 1. Định hướng nguyên nhân viêm màng não từ glucose và loại tế bào trong dịch não tủy](dnt-phan-biet.svg)

| Chỉ số | Bình thường | Vi khuẩn (mủ) | Lao | Virus |
|---|---|---|---|---|
| Màu sắc | Trong | **Đục** | Trong hoặc hơi vàng; để lâu có thể có màng fibrin | Trong |
| Áp lực | 80–180 mmH~2~O | Tăng rõ | Tăng | Bình thường hoặc tăng nhẹ |
| Tế bào | ≤ 5/µL, lympho | **Rất tăng** (hàng trăm đến hàng nghìn/µL), **bạch cầu đa nhân trung tính** | Tăng vừa (thường vài chục đến vài trăm/µL), **lympho** | Tăng nhẹ đến vừa, **lympho** |
| Protein | 0,15–0,45 g/L | Tăng (thường > 1 g/L) | **Tăng rất cao** (có thể vài g/L) | Bình thường hoặc tăng nhẹ |
| Glucose (tỷ số DNT/máu) | ≥ 0,6 | **Giảm mạnh** (< 0,4; có khi ≈1 mmol/L) | Giảm | **Bình thường** |
| Cl^−^ | 120–130 mEq/L | Giảm nhẹ | **Giảm mạnh** (theo giáo trình) | Bình thường |
| Lactat | 1,1–2,4 mmol/L | **> 3,5 mmol/L** | Tăng | **< 3 mmol/L** |

*(Số liệu cột "Bình thường", glucose, Cl^−^, lactat theo giáo trình tr. 341–344; số tế bào và mức tăng protein là giá trị tham khảo lâm sàng, mỗi phòng xét nghiệm có khoảng riêng.)*

> [!ung-dung] Đọc kết quả DNT như thế nào?
> - **Bước 1 — glucose:** thấp hay bình thường (so với máu)? Thấp thì nghĩ **vi khuẩn, lao, nấm**. Bình thường thì nghĩ **virus**.
> - **Bước 2 — tế bào:** đa nhân trung tính chiếm ưu thế thì nghĩ **vi khuẩn**. Lympho chiếm ưu thế mà glucose thấp thì nghĩ **lao hoặc nấm**.
> - **Bước 3 — protein, lactat, Cl^−^** để củng cố. Lactat > 3,5 mmol/L nghiêng về vi khuẩn.
> - **Bẫy thực tế:** bệnh nhân đã uống kháng sinh trước khi chọc dò có thể có DNT "nửa vời" (tế bào chuyển sang lympho, glucose bớt giảm), dễ nhầm với virus. Viêm màng não do virus **giai đoạn rất sớm** cũng có thể có nhiều đa nhân. Sinh hóa chỉ **định hướng**; chẩn đoán xác định cần **nhuộm Gram, nuôi cấy, PCR**.
> - **Viêm màng não do nấm** (như *Cryptococcus* ở người nhiễm HIV) có DNT giống lao: lympho, protein tăng, glucose giảm.

## 2. Sữa

### 2.1. Đại cương và tính chất

- Giáo trình gọi sữa là **chất dinh dưỡng hoàn hảo nhất**: **100 ml sữa cung cấp 63 kcal** (Giáo trình tr. 345).
- Tuyến vú chuẩn bị tiết sữa **từ khi có thai** và bắt đầu tiết vào **những ngày gần sinh**. Sự tạo và tiết sữa chịu kiểm soát của **tuyến yên** (prolactin, oxytocin) và **tuyến sinh dục**.
- Thành phần sữa **thay đổi theo thời gian**, từ lúc bắt đầu đến lúc thôi tiết sữa: **sữa non** (vài ngày đầu) → sữa chuyển tiếp → **sữa ổn định** (sữa trưởng thành).
- **Tính chất:** trắng đục, có mùi vị đặc biệt; **tỷ trọng 1,026–1,028** (ở 15 °C); **pH hơi acid, 6,56–6,95**.

**Vì sao sữa trắng đục?** Sữa là một **nhũ tương** (hạt mỡ phân tán trong nước) kèm các **hạt micelle casein–calci**. Cả hai loại hạt đều tán xạ ánh sáng, giống như sương mù làm mờ ánh đèn.

### 2.2. Protein

Sữa mẹ chứa khoảng **1–1,5 g protein/100 ml** (Giáo trình tr. 345). Protein sữa chia 3 nhóm:

| Nhóm | Đặc điểm hóa học | Vai trò |
|---|---|---|
| **Casein** (α, β, γ, tách bằng điện di) | **Phosphoprotein**: chứa **nhiều nhóm phosphat**; các monomer trùng hợp với nhau, nối bằng **cầu disulfur**; giàu **acid amin (amino acid) cần thiết** | Protein quan trọng nhất. Nhóm phosphat **cố định ion calci**, giúp casein **dễ hòa tan** và mang theo nhiều calci |
| **Lactalbumin** (α, β) | **Ít phosphat** nhưng **nhiều lưu huỳnh**; giàu **tryptophan** | Protein "váng sữa" (whey), dễ tiêu |
| **Lactoglobulin** | Ít phosphat, nhiều lưu huỳnh | Protein "váng sữa"; gồm cả globulin miễn dịch |

Ngoài ra sữa còn có nhiều **peptid** và **acid amin tự do**. Trong 18 acid amin ở Bảng 22.4, nhiều nhất là **acid glutamic (264 mg/100 ml)**; acid amin cần thiết nhiều nhất là **leucin (150 mg)** (Giáo trình tr. 346).

> [!bay]
> - **Casein giàu phosphat; lactalbumin, lactoglobulin giàu lưu huỳnh.** Đề thi hay đảo hai đặc điểm này.
> - **α-lactalbumin** của sữa mẹ giàu tryptophan. Nó còn là một tiểu đơn vị của enzym **lactose synthase** ở tuyến vú, tức là chính protein này tham gia tạo ra đường sữa.

### 2.3. Lipid

- Lipid sữa là hỗn hợp phức tạp, **chủ yếu là triglycerid**, có **tỷ trọng thấp** nên nổi lên thành váng kem khi để yên.
- Lipid ở trạng thái **nhũ tương hóa**: hạt nhũ tương kích thước 0,5–10 µm, trung bình **2–3 µm**. Giáo trình ghi 1 lít sữa có tới 2 tỷ hạt (Giáo trình tr. 346).
- Có nhiều **acid béo chưa no cần thiết**, tới **20 loại acid béo**. Theo Bảng 22.4 (100 ml sữa mẹ): acid palmitic 1,1 g, stearic 0,2 g, **linoleic 0,3 g**, linolenic vết.
- **Cholesterol**: giáo trình ghi khoảng 0,20 g/100 ml.
- **Phospholipid**: chủ yếu **lecithin** (19%), cephalin (0,02–0,05%).

Cấu tạo của triglycerid, acid béo chưa no cần thiết và lecithin: xem hs-02. Chylomicron vận chuyển lipid sau hấp thu: xem hs-08.

> [!bay] Về số liệu cholesterol
> Con số "cholesterol khoảng 0,20 g/100 ml" (= 200 mg/100 ml) của giáo trình **cao hơn nhiều** so với các tài liệu dinh dưỡng hiện nay; các tài liệu này thường ghi cholesterol sữa mẹ chỉ khoảng **10–20 mg/100 ml**. Đi thi ghi theo giáo trình nếu được hỏi đúng con số, nhưng nên nhớ rằng sữa mẹ có cholesterol **cao hơn sữa công thức** (sữa công thức gốc dầu thực vật gần như không có cholesterol), và cholesterol này cần cho sự phát triển của não, màng tế bào của trẻ.

### 2.4. Glucid

- Glucid chính là **lactose**, được **tuyến vú tổng hợp từ glucose máu**: một phần glucose được chuyển thành galactose, rồi galactose + glucose → lactose.
- Nồng độ lactose khoảng **7 g/100 ml**. Lactose **kém ngọt hơn saccharose khoảng 6 lần** (Giáo trình tr. 346).
- Glucose tự do: giáo trình ghi khoảng 1 g/100 ml. *(Các phân tích hiện nay cho thấy glucose tự do trong sữa mẹ thấp hơn nhiều, chỉ vài chục mg/100 ml; đi thi theo sách.)*
- **Oligosaccharid đặc biệt**: chứa **N-acetylglucosamin, L-fucose, glucose và galactose**. Chúng là chất **cần cho sự phát triển của vi khuẩn sinh acid lactic** *Lactobacillus bifidus* (nay gọi là *Bifidobacterium*). Đây là vi khuẩn ruột đặc trưng của **trẻ còn bú mẹ**, sẽ mất đi khi trẻ thôi bú.

Cấu tạo lactose (galactose + glucose, liên kết β(1→4)), tính khử và **không dung nạp lactose**: xem hc-08b, mục 5.

> [!vi-du] Vì sao oligosaccharid sữa mẹ quan trọng?
> Người **không tiêu hóa được** phần lớn oligosaccharid sữa mẹ, vì ruột non không có enzym cắt những liên kết đặc biệt của chúng. Do đó chúng xuống đến đại tràng gần như nguyên vẹn, làm "thức ăn riêng" cho *Bifidobacterium*. Vi khuẩn này lên men tạo **acid lactic, acid acetic**, làm pH ruột trẻ bú mẹ **thấp**, gây bất lợi cho vi khuẩn gây bệnh. Đây cũng là lý do phân trẻ bú mẹ có mùi chua và màu vàng tươi. Ngày nay các oligosaccharid này được gọi là **HMO** (*human milk oligosaccharides*).

### 2.5. Chất khoáng và vitamin

- Sữa chứa **nhiều calci, phospho, kali**, rất quan trọng cho sự phát triển xương của trẻ. Các chất khoáng **dễ tiêu hóa, hấp thu** vì chủ yếu ở dạng **kết hợp với casein và phospholipid** (Giáo trình tr. 347).
- **Sắt trong sữa thấp** (khoảng 1–2 mg/L), nhưng ở dạng hợp chất hữu cơ **dễ chuyển hóa, hấp thu**.
- Có các nguyên tố vi lượng: coban, đồng, kẽm, chì, iod, crom, asen, titan…

Một số số liệu trong **100 ml sữa mẹ ổn định** (Giáo trình tr. 346, Bảng 22.4):

| Chất khoáng | Lượng | Vitamin | Lượng |
|---|---|---|---|
| Natri | 15 mg | Vitamin A | 254 IU (retinol 40 µg) |
| Kali | 41 mg | Vitamin D | 2,2 IU |
| **Calci** | **34 mg** | Vitamin E | 0,18 IU |
| **Phospho** | **15 mg** | Vitamin K | 1,5 IU |
| Magnesi | 2 mg | Vitamin B~1~ | 0,01 mg |
| Sắt | 0,1 mg | Vitamin B~2~ | 0,04 mg |
| Kẽm | 0,4 mg | Vitamin B~12~ | 0,03 µg |
| Iod | 5,9 µg | Acid folic | 0,2 µg |

> [!ung-dung] Những con số có ý nghĩa lâm sàng
> - **Tỷ lệ Ca/P ≈ 34/15 ≈ 2/1**: tỷ lệ này thuận lợi cho hấp thu calci. Sữa bò có tỷ lệ Ca/P thấp hơn (khoảng 1,2–1,3) và lượng phospho cao, nên trẻ sơ sinh uống sữa bò tươi dễ bị **hạ calci máu, co giật**.
> - **Vitamin D (2,2 IU/100 ml) và vitamin K rất thấp.** Vì vậy trẻ bú mẹ hoàn toàn được khuyến cáo **bổ sung vitamin D** (thường 400 IU/ngày), và trẻ sơ sinh được **tiêm vitamin K** ngay sau sinh để phòng **xuất huyết do thiếu vitamin K**.
> - Giáo trình ghi vitamin C là "4 µg/100 ml"; các bảng thành phần thực phẩm thường ghi khoảng **4 mg/100 ml**. Rất có thể là lỗi in đơn vị.

### 2.6. Các enzym

Sữa mẹ có nhiều enzym: **amylase, lipase, protease, galactase, catalase, peroxidase, phosphatase, xanthin oxidase** (Giáo trình tr. 347).

**Vì sao sữa mẹ cần enzym?** Tụy của trẻ sơ sinh còn non, tiết ít **lipase** và **amylase**. Lipase của sữa mẹ (được muối mật hoạt hóa) giúp trẻ **tự tiêu hóa mỡ sữa** ngay trong ruột. Đun sôi sữa mẹ sẽ làm mất hoạt tính các enzym này; vì vậy sữa mẹ vắt ra nên được bảo quản lạnh và **hâm ấm** (không đun sôi).

### 2.7. Sữa non

- **Sữa non** (*colostrum*) được tiết ra **trong vài ngày đầu sau sinh**. Nó khác sữa ổn định về **nồng độ và thành phần protein** (Giáo trình tr. 347).
- Giáo trình ghi: sữa non có **nồng độ protein cao, tới 28%**, chủ yếu là **kháng thể IgG**, chiếm tới **40–50% protein toàn phần**.

> [!cap-nhat] Kháng thể trong sữa non người là IgA tiết
> Giáo trình ghi kháng thể chủ yếu của sữa non là **IgG**. Hiện nay đã thống nhất: ở **người**, kháng thể chiếm ưu thế trong sữa non và sữa mẹ là **IgA tiết** (*secretory IgA*, sIgA), chiếm khoảng 90% tổng globulin miễn dịch. sIgA không được hấp thu vào máu trẻ. Nó ở lại trên bề mặt niêm mạc ruột, **bám và trung hòa vi khuẩn, virus** ngay tại chỗ, và bền với pepsin, trypsin nhờ có **mảnh tiết** (*secretory component*). Kháng thể **IgG** của mẹ thì chủ yếu đã sang con **qua nhau thai** trong thai kỳ. Đặc điểm "IgG chiếm ưu thế và protein rất cao" là của **sữa non bò**, vì bê không nhận được kháng thể qua nhau thai. Sữa non người có protein cao hơn sữa ổn định, nhưng ở mức vài g/100 ml. Đi thi: nếu câu hỏi trích đúng giáo trình thì chọn IgG; nếu hỏi theo kiến thức hiện nay thì chọn IgA tiết.

Sữa non còn giàu **lactoferrin** (protein gắn sắt, kìm khuẩn), **lysozym**, bạch cầu sống, vitamin A, và có tác dụng nhuận tràng nhẹ giúp trẻ đào thải **phân su**. Đó là lý do cần cho trẻ **bú sớm trong giờ đầu sau sinh** và không bỏ sữa non.

### 2.8. So sánh sữa mẹ và sữa bò (bổ sung)

Giáo trình chỉ trình bày sữa mẹ. Bảng dưới đây so sánh với sữa bò dùng số liệu tham khảo thường gặp trong tài liệu dinh dưỡng nhi khoa (giá trị gần đúng/100 ml, dao động theo từng nguồn):

![Hình 2. Thành phần đa lượng và tỷ lệ casein : whey của sữa mẹ và sữa bò](sua-me-sua-bo.svg)

| Thành phần | Sữa mẹ (ổn định) | Sữa bò | Ý nghĩa |
|---|---|---|---|
| Năng lượng | ≈65–70 kcal | ≈65–70 kcal | Tương đương |
| **Protein** | **≈1,0–1,5 g** | **≈3,3 g** | Sữa bò gấp ≈3 lần, gây **quá tải thận** của trẻ nhỏ (nhiều ure, điện giải phải thải) |
| Tỷ lệ casein : whey | **≈40 : 60** | **≈80 : 20** | Casein đông vón thành **cục sữa to, dai** trong dạ dày; sữa mẹ tạo cục mịn, **dễ tiêu** |
| β-lactoglobulin | **Không có** | Có nhiều | Là **dị nguyên** chính gây **dị ứng đạm sữa bò** |
| Lipid | ≈3,5–4,5 g, nhiều acid béo chưa no cần thiết, có lipase | ≈3,5–3,9 g, nhiều acid béo no | Sữa mẹ dễ tiêu mỡ hơn |
| **Lactose** | **≈7 g** | **≈4,6–4,8 g** | Năng lượng, hấp thu calci; galactose cho myelin hóa |
| Oligosaccharid (HMO) | Nhiều | Rất ít | Nuôi *Bifidobacterium* |
| Calci / Phospho | 34 / 15 mg (Ca/P ≈ 2) | ≈120 / 95 mg (Ca/P ≈ 1,2–1,3) | Sữa bò nhiều P → nguy cơ **hạ calci máu sơ sinh** |
| Natri | ≈15 mg | ≈45–50 mg | Sữa bò dễ gây tăng natri máu nếu pha đặc |
| Sắt | Thấp, hấp thu **≈50%** | Thấp, hấp thu **≈10%** | Uống sữa bò tươi sớm dễ thiếu máu thiếu sắt (kèm vi xuất huyết ruột) |
| Kháng thể, lactoferrin, lysozym | **Nhiều** (sIgA) | Rất ít | Bảo vệ chống nhiễm trùng |

> [!ung-dung] Vì sao không cho trẻ dưới 12 tháng uống sữa bò tươi thay sữa mẹ?
> Có năm lý do hóa sinh: **(1)** protein và điện giải quá cao, gây gánh nặng cho thận non; **(2)** casein nhiều, khó tiêu; **(3)** Ca/P thấp, dễ hạ calci máu; **(4)** sắt khó hấp thu, dễ thiếu máu; **(5)** không có sIgA, HMO, lipase. Sữa công thức cho trẻ nhỏ được chế từ sữa bò nhưng đã **điều chỉnh** lại: giảm protein, tăng tỷ lệ whey, thêm lactose, dầu thực vật, sắt, vitamin. Tuy vậy, sữa công thức vẫn **không có** kháng thể và tế bào sống như sữa mẹ.

> [!yhct] Thuốc "thông sữa" và "hồi sữa" — quan niệm và bằng chứng
> - **Quan niệm YHCT:** thiếu sữa sau sinh được chia thành hai thể. Thể **khí huyết hư** (sữa ít, loãng, vú mềm) được bồi bổ khí huyết. Thể **can uất khí trệ** (vú căng tức mà sữa không ra) được sơ can, thông lạc. Các vị "thông nhũ" hay dùng là **Vương bất lưu hành**, **Thông thảo**, **Lậu lô**, cùng món ăn – thuốc **móng giò lợn (Trư đề)** hầm. Ngược lại, **Mạch nha sao** liều cao được dùng để **hồi sữa** (cắt sữa) khi cai sữa.
> - **Cơ chế đã biết:** lượng sữa phụ thuộc chủ yếu vào **prolactin** (tạo sữa) và **oxytocin** (phun sữa). Hai hormon này được kích thích mạnh nhất bởi **trẻ bú thường xuyên và làm trống bầu vú**. Món hầm nhiều nước, giàu đạm và năng lượng giúp **bù dịch và dinh dưỡng** cho mẹ.
> - **Mức bằng chứng:** tác dụng tăng tiết sữa của các vị thuốc trên chủ yếu dựa vào **kinh nghiệm**. Chỉ có một số nghiên cứu trên động vật và thử nghiệm lâm sàng nhỏ, chất lượng thấp, **chưa đủ** để kết luận. Tác dụng "hồi sữa" của Mạch nha cũng chưa được chứng minh rõ. **Xuyên sơn giáp** (vảy tê tê), một vị thông sữa kinh điển, nay **bị cấm** khai thác và buôn bán vì tê tê là loài nguy cấp, quý hiếm được ưu tiên bảo vệ (thuộc Phụ lục I CITES). Không nên kê vị này.

## 3. Dịch vị

### 3.1. Nguồn gốc và điều hòa bài tiết

Dịch vị là hỗn hợp chất tiết của các tế bào tuyến dạ dày (Giáo trình tr. 347):

| Tế bào | Vị trí | Tiết ra |
|---|---|---|
| **Tế bào chính** | Tuyến thân – đáy vị | **Pepsinogen** |
| **Tế bào viền** (tế bào thành) | Vùng **thân và đáy** dạ dày | **HCl** |
| Tế bào biểu mô và các tuyến vùng **tâm vị** (và môn vị) | Bề mặt niêm mạc, tâm vị – môn vị | Dịch **kiềm**: clorua, bicarbonat, **mucin** |

**Điều hòa bài tiết.** Bài tiết dịch vị chịu ảnh hưởng của các hormon dạ dày – ruột (**gastrin, secretin, cholecystokinin**), của **cafein, histamin** (kích thích), cũng như **lượng và tính chất thức ăn**. Riêng với HCl (Giáo trình tr. 347–348):

- **Kích thích:** **gastrin** (do tế bào G ở hang vị tiết ra), histamin, cafein, dây thần kinh X (phế vị).
- **Ức chế:** **secretin, cholecystokinin – pancreozymin** (do tá tràng tiết khi nhũ trấp acid, giàu mỡ xuống ruột). *(Bổ sung: tại chỗ, **somatostatin** của tế bào D ở dạ dày là chất ức chế tiết acid quan trọng khi pH lòng dạ dày xuống thấp.)*

> [!bay] Cholecystokinin và pancreozymin là MỘT hormon
> Giáo trình liệt kê "secretin, cholecystokinin **và** pancreozymin" như ba chất. Thực ra **cholecystokinin (CCK) và pancreozymin là cùng một hormon**: lúc đầu người ta đặt hai tên theo hai tác dụng (co túi mật; kích thích tụy tiết enzym), về sau mới biết là một peptid. Ngày nay gọi chung là **CCK**.
>
> **Ý nghĩa sinh lý:** khi thức ăn acid xuống tá tràng, tá tràng tiết secretin và CCK để **"phanh" dạ dày** (giảm tiết acid, chậm làm rỗng), đồng thời kích thích tụy tiết **bicarbonat** trung hòa acid. Đó là một vòng **điều hòa ngược**.

### 3.2. Tính chất

- Lượng: **2–3 lít/24 giờ**.
- Bình thường **trong suốt**, màu sáng hoặc **vàng nhạt**.
- **pH 1–2**, là dịch acid nhất cơ thể.
- Thành phần: **97–99% nước**; còn lại là mucin, enzym tiêu hóa và muối vô cơ (Giáo trình tr. 347).

### 3.3. HCl

**Nguồn gốc của H^+^ và Cl^−^** (Giáo trình tr. 347):

- **H^+^** đến từ sự phân ly của **H~2~CO~3~** trong tế bào viền. H~2~CO~3~ được tạo từ CO~2~ và H~2~O nhờ enzym **carbonic anhydrase**.
- **Cl^−^** lấy từ **NaCl của máu**.
- H^+^ được đưa ra lòng dạ dày bằng **vận chuyển chủ động**, ngược gradient nồng độ rất lớn.

=> CO~2~ + H~2~O → H~2~CO~3~ → H^+^ + HCO~3~^−^  (carbonic anhydrase)

=> H^+^ (trong tế bào) + K^+^ (lòng dạ dày) + ATP → H^+^ (lòng dạ dày) + K^+^ (trong tế bào) + ADP + P~i~  (H^+^/K^+^-ATPase)

![Hình 3. Cơ chế bài tiết HCl của tế bào viền và vị trí tác dụng của thuốc ức chế bơm proton](te-bao-vien-hcl.svg)

**Vì sao phải dùng bơm?** pH dịch vị khoảng 1, pH trong tế bào khoảng 7,2. Nồng độ H^+^ ở lòng dạ dày cao hơn trong tế bào khoảng **một triệu lần** (10^6^). Không có cơ chế thụ động nào đẩy H^+^ ngược dốc như vậy được. Cái bơm làm việc này là **H^+^/K^+^-ATPase** (bơm proton): mỗi phân tử ATP đổi 1 H^+^ ra lấy 1 K^+^ vào. HCO~3~^−^ sinh ra cùng lúc được đổi sang máu lấy Cl^−^ ở cực đáy tế bào. Vì vậy sau bữa ăn, máu tĩnh mạch dạ dày **kiềm hơn** và nước tiểu có thể hơi kiềm ("**sóng kiềm** sau ăn").

**Các dạng HCl và cách định lượng.** HCl tồn tại ở dạng **tự do** và dạng **kết hợp** với protein, chủ yếu với mucin. "Độ acid" dạ dày được định lượng bằng **chuẩn độ**. Kết quả là tổng của HCl tự do, HCl kết hợp và các acid yếu khác. Giáo trình ghi nồng độ HCl khoảng **40 mEq/L** (Giáo trình tr. 348).

**Vai trò của HCl:**

- Tạo pH tối ưu cho **pepsin** và **hoạt hóa pepsinogen**.
- **Làm biến tính protein** thức ăn, giúp enzym dễ cắt.
- **Diệt khuẩn** thức ăn.
- Giúp **hấp thu sắt** (giữ sắt ở dạng tan, thuận lợi cho việc khử Fe^3+^ → Fe^2+^ để hấp thu) và giải phóng vitamin B~12~ khỏi protein thức ăn.
- Acid xuống tá tràng kích thích tiết **secretin**.

**Bệnh lý.** Nồng độ HCl thay đổi trong **viêm loét dạ dày – tá tràng**, **đa toan, cường toan**, **cường dây thần kinh X**… (Giáo trình tr. 348). Ngược lại, HCl **giảm hoặc mất** (vô toan) trong **viêm teo niêm mạc dạ dày** và **thiếu máu ác tính** (bệnh Biermer).

### 3.4. Các enzym thủy phân protein và lipase

**Pepsin** (Giáo trình tr. 348):

- Do **tế bào chính** tiết ra dưới dạng tiền chất **pepsinogen** (M = **40.000 Da**).
- Pepsinogen được hoạt hóa thành **pepsin** (M = **33.000 Da**) nhờ **HCl** hoặc **tự hoạt hóa** (pepsin có sẵn cắt pepsinogen). Quá trình hoạt hóa cắt bỏ một đoạn **42 acid amin** ở đầu N.
- Trung bình **1 lít dịch vị có khoảng 1 g pepsin**.
- Pepsin thủy phân protein thành **peptid** (không đến acid amin tự do).

**Vì sao tiết dạng tiền chất?** Nếu tế bào tiết thẳng pepsin, enzym sẽ **tiêu hóa chính tế bào và tuyến** sinh ra nó. Pepsinogen chỉ được "mở khóa" khi đã ra **lòng dạ dày**, nơi có HCl. Đây là nguyên tắc chung của enzym tiêu hóa protein (trypsinogen, chymotrypsinogen của tụy), đã gặp ở hs-05.

**Cathepsin**: enzym thủy phân protein, hoạt động thích hợp ở **pH 3,9**. Nó quan trọng khi độ acid dịch vị **yếu**, như ở **trẻ còn bú mẹ**.

**Rennin** (chymosin), enzym làm **đông vón sữa** (Giáo trình tr. 348):

- Biến **casein** hòa tan thành **paracasein không tan**. Paracasein kết hợp Ca^2+^ tạo **cục sữa đông**.
- Tác dụng: giữ sữa **không qua dạ dày quá nhanh**, tạo điều kiện cho pepsin tiêu hóa.
- Giáo trình ghi rennin có chủ yếu ở **trẻ em**; người lớn không có rennin, tác nhân làm đông vón sữa ở người lớn là **pepsin**.

> [!cap-nhat] Rennin ở người
> Giáo trình (tr. 348) ghi rennin có ở trẻ em. Hiện nay đã biết **gen chymosin ở người là gen giả** (không tạo ra enzym hoạt động). Rennin điển hình có ở **dạ dày bê non** và các động vật nhai lại non; chất "men dịch vị" làm phô mai lấy từ đó. Ở người (cả trẻ bú mẹ), sữa được làm đông vón chủ yếu nhờ **pepsin và acid**. Đi thi trả lời theo giáo trình.

**Lipase dạ dày**: có một ít, thủy phân lipid nhưng **không phải vai trò chính**. Lipid chủ yếu được tiêu hóa ở ruột non nhờ lipase tụy và muối mật (hs-17).

### 3.5. Mucin và các chất khác

**Mucin** (mucoprotein) do **tế bào nhầy** vùng **tâm vị và môn vị** tiết ra. Thành phần chủ yếu là **glycoprotein** (Giáo trình tr. 348). Vai trò:

- Tạo lớp nhầy **bảo vệ niêm mạc dạ dày** khỏi HCl và pepsin. Lớp nhầy giữ bicarbonat sát bề mặt niêm mạc, nên pH tại đó gần trung tính dù lòng dạ dày có pH 1–2.
- Bảo vệ các **vitamin tan trong nước** (B~1~, B~12~, C) khỏi bị HCl và pepsin phá hủy.
- Giúp **hấp thu sắt và vitamin B~12~**.

> [!bay] Vitamin B₁₂ cần "yếu tố nội"
> Giáo trình gán việc giúp hấp thu B~12~ cho mucin. Chính xác hơn, chất đó là **yếu tố nội** (*intrinsic factor*, yếu tố Castle). Đây là một **glycoprotein do tế bào viền tiết ra**; ngày xưa nó được tách chung với phân đoạn "mucoprotein" của dịch vị. Yếu tố nội gắn B~12~ và đưa B~12~ đến **hồi tràng** để hấp thu. Viêm teo dạ dày tự miễn phá hủy tế bào viền nên **mất cả HCl lẫn yếu tố nội**, gây **thiếu máu ác tính** (thiếu máu hồng cầu to: thiếu B~12~ làm thiếu nucleotid cho tổng hợp ADN (DNA) của tế bào tủy xương; liên hệ hs-11, mục 6.1).

**Các chất khác** trong dịch vị bình thường: ion **Na^+^, Ca^2+^, K^+^, Mg^2+^, Cl^−^**; **ure**, một số acid amin, **creatin**, **acid uric** (Giáo trình tr. 348).

**Chất bất thường** (bệnh lý):

| Chất | Gợi ý |
|---|---|
| **Acid lactic, acid butyric** | **Hẹp môn vị**: thức ăn ứ đọng lâu, bị vi khuẩn **lên men** |
| **Sắc tố mật** | **Dịch ruột – mật trào ngược** lên dạ dày |
| **Máu đỏ tươi** hoặc **máu đen** (bã cà phê) | **Chảy máu dạ dày**. Máu đen vì Hb bị HCl biến thành **hematin** màu nâu đen |

> [!ung-dung] Xét nghiệm dịch vị và thuốc ức chế bơm proton
> - **Xét nghiệm dịch vị** (hút dịch vị, chuẩn độ HCl tự do và toàn phần, đo lưu lượng acid cơ bản và sau kích thích) ngày nay **ít làm**. Chẩn đoán bệnh dạ dày chủ yếu dựa vào **nội soi**, sinh thiết và xét nghiệm ***Helicobacter pylori*** (test hơi thở ure, test nhanh urease). *H. pylori* sống được trong môi trường acid nhờ enzym **urease** phân giải ure thành NH~3~ để trung hòa acid quanh nó. Đo acid dạ dày và **gastrin máu** vẫn còn dùng khi nghi **hội chứng Zollinger–Ellison** (u tiết gastrin → tăng tiết acid rất mạnh, loét nhiều ổ, khó lành).
> - **Thuốc ức chế bơm proton** (omeprazol, esomeprazol, pantoprazol, lansoprazol…) gắn **không thuận nghịch** vào H^+^/K^+^-ATPase, chặn **bước cuối cùng chung** của mọi con đường kích thích tiết acid (gastrin, histamin, acetylcholin). Vì vậy đây là nhóm giảm acid mạnh nhất (cơ chế bơm: xem sh-04). Thuốc kháng **H~2~** (famotidin…) chỉ chặn đường histamin nên yếu hơn. Thuốc **kháng acid** (antacid: Al(OH)~3~, Mg(OH)~2~, CaCO~3~) không giảm tiết mà **trung hòa** HCl đã tiết ra.
> - **Hệ quả hóa sinh khi dùng ức chế bơm proton lâu dài:** acid giảm nên có thể giảm hấp thu **vitamin B~12~**, **sắt**, **magnesi**, tăng nguy cơ nhiễm khuẩn đường ruột; gastrin máu tăng do mất cơ chế điều hòa ngược.

> [!yhct] Ô tặc cốt, Mẫu lệ — "chế toan"
> Các vị chứa **CaCO~3~** (Ô tặc cốt, Mẫu lệ, Ngõa lăng tử; bài Ô bối tán) trung hòa HCl giống thuốc kháng acid calci carbonat. Phản ứng hóa học và nguy cơ hội chứng sữa – kiềm (xem bài *Hợp chất vô cơ: oxide, acid, base, muối*, mã vc-05, mục 6.2; và bài *Khí máu và thăng bằng acid — base*, mã hs-16, mục 3.2). Ở bài này chỉ cần nhớ: đó là tác dụng **trung hòa acid đã tiết** (giống antacid), **không giảm tiết** như thuốc ức chế bơm proton, không diệt *H. pylori* và không thay thế phác đồ điều trị loét.

## 4. Bạch huyết

**Nguồn gốc.** Bạch huyết được tạo từ **huyết tương** nhờ quá trình **lọc qua thành mao mạch**. Dịch bạch huyết gồm dịch của **hệ bạch mạch**, **dịch khe** (dịch kẽ) và **dịch ngoại bào**. Vì vậy thành phần bạch huyết **khác nhau đôi chút tùy nguồn gốc** (Giáo trình tr. 349).

**Thành phần hóa học:**

- **Glucose và ure**: tương tự huyết tương (phân tử nhỏ, qua thành mạch tự do).
- **Điện giải** (Na^+^, K^+^, Ca^2+^, Mg^2+^, Cl^−^): khác huyết tương chút ít. Cl^−^ trong bạch huyết **hơi cao hơn** huyết tương, cùng lý do với DNT: protein (anion) ít hơn thì Cl^−^ bù vào.
- **Protein thấp hơn huyết tương** và **khác nhau theo nơi lấy**: bạch huyết ở **chân 2–3 g%**, ở **ruột 4–6 g%**, ở **gan 6–8 g%**.
- **Lipid** chủ yếu là **lipid trung tính**, nồng độ thay đổi theo nguồn gốc. **Sau bữa ăn**, lipid trong bạch huyết **ruột và ống ngực** tăng rất cao, làm bạch huyết **đục như sữa** (gọi là **dưỡng chấp**). Đó là lipid của thức ăn được hấp thu và đóng gói dưới dạng **chylomicron** (hs-08).

**Vì sao protein bạch huyết gan cao nhất?** Mao mạch gan (xoang gan) có thành **rất thưa**, có lỗ lớn, nên protein huyết tương lọt ra nhiều. Mao mạch cơ – da ở chân thì kín, ít protein lọt ra. Mao mạch ruột ở mức trung gian.

**Bảng so sánh trong 100 ml** (Giáo trình tr. 349, Bảng 22.5):

| Chất | Bạch huyết vùng cổ | Bạch huyết ống ngực | Huyết tương |
|---|---|---|---|
| Nước | 95 g | 94 g | 90 g |
| **Protein** | **2 g** | **4 g** | **7,5 g** |
| **Fibrinogen** | — | 40 mg | 300 mg |
| Glucose | 100 mg | 110 mg | 100 mg |
| Na^+^ | 330 mg | 330 mg | 320 mg |
| K^+^ | 23 mg | 24 mg | 20 mg |
| Ca^2+^ | 10 mg | 11 mg | 10 mg |
| Cl^−^ | 420 mg | 410 mg | 370 mg |

> [!bay]
> - Bạch huyết **có fibrinogen** (ít hơn huyết tương nhiều), nên bạch huyết cũng **đông được**, nhưng chậm và cục đông mềm.
> - Bảng 22.5 của giáo trình ghi "phospho vô cơ" huyết tương là 307 mg/100 ml. Con số này **gần chắc chắn là lỗi in**: phosphat vô cơ huyết thanh bình thường chỉ khoảng **3–4,5 mg/100 ml** (0,8–1,5 mmol/L), cùng bậc với bạch huyết (3–4 mg). Đừng học thuộc con số 307.

> [!ung-dung] Tràn dưỡng chấp
> Khi **ống ngực** bị tổn thương (sau phẫu thuật lồng ngực, chấn thương, u lympho chèn ép), bạch huyết giàu chylomicron chảy vào khoang màng phổi gây **tràn dưỡng chấp màng phổi**: dịch màu **trắng đục như sữa**. Xét nghiệm hóa sinh dịch màng phổi thấy **triglycerid tăng cao** (thường > 1,24 mmol/L, tức > 110 mg/dL) và có chylomicron. Một biện pháp điều trị là cho ăn chế độ **thay mỡ bằng triglycerid chuỗi trung bình (MCT)**: acid béo chuỗi trung bình được hấp thu thẳng vào **tĩnh mạch cửa** mà không đi qua bạch huyết, nên giảm lượng dưỡng chấp chảy qua ống ngực.

## Tóm tắt

| Dịch | Nguồn gốc | Điểm hóa sinh phải nhớ | Ứng dụng |
|---|---|---|---|
| **Dịch não tủy** | Siêu lọc huyết tương ở đám rối mạch mạc; 150 ml, 500 ml/ngày | Trong, tỷ trọng 1,003–1,008; áp lực 80–180 mmH~2~O; protein ≈1/250 huyết tương (80% từ huyết tương); glucose 60–80% máu; lactat 1,1–2,4 mmol/L; **Cl^−^ 120–130 mEq/L (cao hơn máu)**; Mg^2+^ cao hơn máu | Vi khuẩn: glucose ↓↓, lactat > 3,5, đa nhân. Lao: glucose ↓, protein ↑↑, Cl^−^ ↓↓, lympho. Virus: glucose bình thường, lactat < 3, lympho. Guillain–Barré: phân ly đạm – tế bào |
| **Sữa mẹ** | Tuyến vú (tuyến yên, tuyến sinh dục điều hòa) | 63 kcal/100 ml; pH 6,56–6,95; protein 1–1,5 g (casein giàu **phosphat**, lactalbumin/lactoglobulin giàu **lưu huỳnh**); lactose ≈7 g (kém ngọt 6 lần saccharose); oligosaccharid nuôi *bifidus*; Ca/P ≈ 2; nhiều enzym | Ưu việt hơn sữa bò (protein vừa đủ, whey nhiều, không có β-lactoglobulin, sắt dễ hấp thu, có sIgA). Bổ sung vitamin D, K cho trẻ |
| **Sữa non** | Vài ngày đầu sau sinh | Protein cao, nhiều kháng thể (giáo trình: IgG 40–50% protein; hiện nay: sIgA chiếm ưu thế ở người) | Cho bú sớm, không bỏ sữa non |
| **Dịch vị** | Tế bào chính (pepsinogen), tế bào viền (HCl), tế bào nhầy (mucin, HCO~3~^−^) | 2–3 L/ngày, pH 1–2, 97–99% nước; HCl ≈40 mEq/L (H^+^ từ H~2~CO~3~, Cl^−^ từ NaCl máu, bơm chủ động); gastrin ↑, secretin – CCK ↓; pepsinogen 40 kDa → pepsin 33 kDa (cắt 42 aa); cathepsin pH 3,9; rennin: casein → paracasein | Ức chế bơm proton chặn H^+^/K^+^-ATPase. Thiếu máu ác tính: mất HCl và yếu tố nội. Hẹp môn vị: acid lactic, butyric |
| **Bạch huyết** | Lọc huyết tương qua thành mao mạch | Glucose, ure ≈ huyết tương; protein thấp hơn (chân 2–3 < ruột 4–6 < gan 6–8 g%); có ít fibrinogen; sau ăn đục như sữa (chylomicron) | Tràn dưỡng chấp: triglycerid dịch tăng cao |
