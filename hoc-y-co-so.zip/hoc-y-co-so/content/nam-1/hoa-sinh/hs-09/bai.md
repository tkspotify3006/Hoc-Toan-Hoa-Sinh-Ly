---
title: Chuyển hóa acid amin
thoi-gian: 60 phút
muc-tieu:
- Trình bày được hai cách tách nhóm amin khỏi acid amin, là trao đổi amin (transaminase, coenzym PLP) và khử amin oxy hóa (L-acid amin oxidase, glutamat dehydrogenase), và giải thích vì sao hai quá trình này phối hợp với nhau qua glutamat.
- Trình bày được số phận của NH~3~ (tạo glutamin, đào thải qua thận) và 5 phản ứng của chu trình ure (enzym, vị trí ty thể – bào tương, năng lượng, điều hòa); nêu được mối liên quan giữa chu trình ure và chu trình acid citric.
- Nêu được số phận của nhóm carboxyl (amin sinh học) và của khung carbon (acid amin sinh đường, sinh ceton).
- Trình bày được sự tổng hợp acid amin, sự tạo thành creatin – creatinin và glutathion cùng vai trò của chúng.
- Nêu được thế nào là bệnh lý acid amin và nhận biết một số bệnh thường gặp (phenylceton niệu, alkapton niệu, bạch tạng, tăng amoniac máu, bệnh não gan).
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Protein → acid amin (amino acid) nhờ protease tiêu hóa (pepsin, trypsin, chymotrypsin…) và, trong tế bào, nhờ **ubiquitin + ATP**. Acid amin **không dự trữ**: phần thừa bị thoái hóa.
> 2. Tách nhóm amin = **trao đổi amin** (transaminase, coenzym **PLP** – vitamin B~6~; ALT, AST) gom –NH~2~ về **glutamat**, rồi **khử amin oxy hóa** glutamat bằng **GLDH** (ty thể) giải phóng **NH~4~^+^**.
> 3. NH~3~ rất độc (não) → được "đóng gói" thành **glutamin** để chở đi; ở **gan** NH~4~^+^ thành **ure** qua **5 enzym**: CPS I, OTC (**ty thể**) → ASS, ASL, arginase (**bào tương**). Enzym then chốt: **CPS I**, hoạt hóa bởi **N-acetylglutamat**.
> 4. Khung carbon → pyruvat, oxaloacetat, α-cetoglutarat, succinyl-CoA, fumarat (**sinh đường**) hoặc acetyl-CoA, acetoacetyl-CoA (**sinh ceton**). Khử carboxyl tạo **amin sinh học** (GABA, histamin, serotonin…).
> 5. Acid amin là nguyên liệu của **creatin** (Gly + Arg + Met) → **creatinin**, **glutathion** (γ-Glu-Cys-Gly, chống oxy hóa), hem, base nitơ, hormon. Thiếu enzym bẩm sinh → **bệnh lý acid amin** (vd phenylceton niệu).

Bài này dùng lại hai bài đã học. Cấu trúc, tính chất của acid amin và liên kết peptid: xem bài *Amin, amid, amino acid* (môn Hóa học, hc-10). Enzym, coenzym PLP và ý nghĩa xét nghiệm **ALT, AST**: xem bài *Enzym* (hs-05, mục coenzym và mục 9). Ở đây ta theo dấu **một acid amin từ bữa ăn đến khi nitơ của nó ra nước tiểu dưới dạng ure**.

## 1. Thủy phân protein thành acid amin

Protein là polymer của acid amin. Người tổng hợp được phần lớn acid amin, trừ một số phải lấy từ thức ăn (**acid amin cần thiết**, mục 6). Cơ thể **không có kho dự trữ acid amin** như glycogen hay mỡ. Acid amin vượt nhu cầu tổng hợp protein và các chất khác sẽ bị **thoái hóa**: tách nhóm amin (phần lớn thành ure), còn khung carbon thành chất trung gian của chu trình acid citric (Giáo trình tr. 147).

### 1.1. Thủy phân protein ngoại sinh (tiêu hóa protein)

| Nơi | Enzym | Hoạt hóa từ | Cắt ở đâu (theo giáo trình) |
|---|---|---|---|
| **Dạ dày** (pH 1–2) | **Pepsin** | Pepsinogen, nhờ **HCl** | Liên kết của acid amin **nhân thơm** hoặc acid amin **acid** → peptid ngắn hơn |
| **Ruột non** (pH kiềm; enzym do **tụy** tiết) | **Trypsin** | Trypsinogen, nhờ **enterokinase** của ruột non | Liên kết peptid của acid amin **kiềm** (Lys, Arg) |
| | **Chymotrypsin** | Chymotrypsinogen, nhờ trypsin | Liên kết của acid amin **trung tính** |
| | **Elastase** | Proelastase, nhờ trypsin | Liên kết của acid amin **nhỏ**: Gly, Ala, Ser |
| | **Carboxypeptidase** | Procarboxypeptidase, nhờ trypsin | Cắt từ **đầu C** → giải phóng acid amin tự do |
| **Ruột non** (niêm mạc tiết) | **Aminopeptidase** | — | Cắt từ **đầu N** → giải phóng acid amin tự do |

Acid amin tự do được hấp thu qua thành ruột bằng **vận chuyển tích cực**, tốn năng lượng (Giáo trình tr. 147–148).

**Vì sao enzym tiêu hóa protein được tiết ở dạng tiền chất (zymogen)?** Nếu tiết sẵn dạng hoạt động, chúng sẽ "tiêu hóa" chính tế bào tuyến đã tạo ra chúng. Tiền chất chỉ được hoạt hóa **khi đã ra đến lòng ống tiêu hóa**. Acid pH 1–2 ở dạ dày còn làm **biến tính** protein (phá cấu trúc bậc 2, 3, 4), mở chuỗi cho enzym dễ cắt.

> [!bay]
> - **Trypsin là "chìa khóa chủ"**: enterokinase chỉ hoạt hóa trypsinogen; còn trypsin hoạt hóa tiếp **cả** chymotrypsinogen, proelastase, procarboxypeptidase và cả trypsinogen khác.
> - Pepsin bị **bất hoạt** khi xuống ruột non vì pH kiềm.
> - Carboxypeptidase là **exopeptidase cắt đầu C** (tụy tiết); aminopeptidase là **exopeptidase cắt đầu N** (ruột tiết). Pepsin, trypsin, chymotrypsin, elastase cắt **bên trong** chuỗi (endopeptidase).

> [!cap-nhat]
> Giáo trình ghi chymotrypsin cắt liên kết của acid amin "trung tính". Hiện nay các sách hóa sinh mô tả chính xác hơn: chymotrypsin ưu tiên cắt sau acid amin **nhân thơm** (Phe, Tyr, Trp) và gốc kỵ nước lớn (các acid amin này cũng là acid amin trung tính). Đi thi trả lời theo giáo trình.

> [!ung-dung] Viêm tụy cấp
> Nếu trypsinogen bị hoạt hóa sớm **ngay trong tụy** (do sỏi mật, rượu…), trypsin sẽ hoạt hóa dây chuyền các enzym khác và tụy "tự tiêu hóa". Đó là cơ chế bệnh sinh chính của **viêm tụy cấp** (xét nghiệm amylase, lipase: xem hs-05 mục 9).

### 1.2. Thủy phân protein nội sinh

Protein của chính cơ thể cũng liên tục bị phân hủy và tổng hợp mới với tốc độ cân bằng ở người trưởng thành. Đó là **sự đổi mới protein** (protein turnover). Mỗi ngày khoảng **1–2% protein toàn phần** được đổi mới; ở trẻ đang lớn tỷ lệ này cao hơn. Phần lớn acid amin giải phóng ra được **dùng lại** để tổng hợp protein mới; một phần bị thoái hóa và đào thải (Giáo trình tr. 148).

- Pepsin, trypsin, chymotrypsin… **không** tham gia đổi mới protein trong tế bào.
- **Protein huyết tương** gắn vào thụ thể đặc hiệu trên tế bào gan và bị thoái hóa trong **lysosom**.
- Protein **trong tế bào** (kể cả protein hỏng, protein đột biến) bị đánh dấu bằng **ubiquitin** rồi thoái hóa, cần **ATP**.

**Ubiquitin** là protein nhỏ **76 acid amin**, có ở mọi tế bào nhân thật, **không có ở tế bào nhân sơ** (vi khuẩn). Protein bị gắn ubiquitin là protein "đến hạn hủy". Giáo trình chia quá trình thành 4 bước:

| Bước | Enzym | Việc xảy ra |
|---|---|---|
| 1 | **E1** (enzym hoạt hóa) | Dùng **ATP** gắn ubiquitin vào E1 bằng **liên kết thioester** (UB-CO-S-E1) |
| 2 | **E2** (enzym tiếp hợp) | Nhận ubiquitin từ E1 (cũng bằng liên kết thioester), giải phóng E1 |
| 3 | **E3** (enzym nối, ligase) | Chuyển ubiquitin sang **protein đích** → phức hợp ubiquitin–protein |
| 4 | **Phức hợp protease phụ thuộc ATP** | Cắt protein thành peptid; ubiquitin được **giải phóng, dùng lại** |

> [!cap-nhat] Lysosom và proteasom là hai hệ thống khác nhau
> Giáo trình viết sự thoái hóa protein nội sinh "xảy ra ở lysosom nhờ ubiquitin phụ thuộc ATP". Hiện nay người ta tách rõ hai hệ thống: (1) **lysosom** phân hủy protein lấy từ ngoài vào (vd protein huyết tương qua thụ thể) và các bào quan, khối protein bị "tự thực" (autophagy); (2) **hệ ubiquitin – proteasom**: protein gắn chuỗi ubiquitin bị phân hủy ở **proteasom 26S** (chính là "phức hợp protease phụ thuộc ATP" ở bước 4) trong **bào tương và nhân**, không phải trong lysosom. Giải Nobel Hóa học 2004 trao cho phát hiện cơ chế ubiquitin.

## 2. Tách nhóm amin khỏi acid amin

Thoái hóa một acid amin gồm ba phần: **nhóm amin** (mục 2–3), **nhóm carboxyl** (mục 4) và **khung carbon** (mục 5). Ta bắt đầu với nhóm amin vì đây là phần "khó xử lý" nhất: nó giải phóng ra NH~3~ độc.

### 2.1. Trao đổi amin (transamination)

**Định nghĩa.** Nhóm α-amin của một acid amin được chuyển sang carbon α (nhóm ceton) của một **acid α-cetonic**. Kết quả: acid amin ban đầu thành acid α-cetonic tương ứng, còn acid α-cetonic nhận thì thành acid amin mới. Enzym xúc tác: **transaminase** (aminotransferase) (Giáo trình tr. 149).

=> R~1~–CH(NH~3~^+^)–COO^−^ + R~2~–CO–COO^−^ ⇌ R~1~–CO–COO^−^ + R~2~–CH(NH~3~^+^)–COO^−^

Đặc điểm cần nhớ:

- Hầu hết acid amin chuyển nhóm amin cho **cùng một chất nhận là α-cetoglutarat**, tạo ra **glutamat**. Nhờ vậy nitơ của nhiều acid amin khác nhau được **gom về một chất**.
- Phản ứng **thuận nghịch**, không giải phóng NH~3~ tự do và hầu như không tốn năng lượng. Vì vậy trao đổi amin dùng được **cả để thoái hóa lẫn để tổng hợp** acid amin (mục 6).
- Transaminase có ở **cả ty thể và bào tương**, phổ biến ở các mô, hoạt tính cao.
- Coenzym: **pyridoxal phosphat (PLP)**, dạng hoạt động của **vitamin B~6~**.

Hai transaminase quan trọng nhất:

=> **ALT** (alanin transaminase, GPT): Alanin + α-cetoglutarat ⇌ Pyruvat + Glutamat

=> **AST** (aspartat transaminase, GOT): Aspartat + α-cetoglutarat ⇌ Oxaloacetat + Glutamat

**Vai trò của PLP — cơ chế "bóng bàn".** PLP mang nhóm **aldehyd** (–CHO). Phản ứng chia thành hai nửa:

1. Acid amin thứ nhất gắn vào PLP (tạo base Schiff), để lại nhóm amin trên coenzym. PLP thành **pyridoxamin phosphat (PMP)**, mang –CH~2~–NH~2~; acid amin thành acid α-cetonic.
2. PMP chuyển nhóm amin cho acid α-cetonic thứ hai (thường là α-cetoglutarat) → acid amin mới (glutamat), và PLP được **tái tạo**.

Enzym "chạy qua lại" giữa hai dạng PLP ⇌ PMP như quả bóng bàn giữa hai cơ chất. Coenzym ở đây đóng vai **chất mang tạm** nhóm amin.

![Hình 1. Trao đổi amin: PLP nhận nhóm –NH₂ (thành PMP) rồi trao lại cho α-cetoglutarat. Mũi tên cam: đường đi của nhóm amin](trao-doi-amin.svg)

> [!ung-dung] ALT, AST trong xét nghiệm
> AST, ALT nằm **trong tế bào**. Khi tế bào gan, tim, cơ bị hủy, chúng tràn vào máu. Vì vậy hoạt độ ALT, AST huyết thanh giúp **chẩn đoán, tiên lượng bệnh gan và bệnh tim** (Giáo trình tr. 149). Phân bố mô, khoảng tham chiếu (≤ 40 U/L, tham khảo), tỷ số AST/ALT trong bệnh gan do rượu: xem bài *Enzym* (hs-05, mục 9). Nhắc lại hai ý gắn với bài này:
> - **ALT** chủ yếu ở **bào tương tế bào gan** → đặc hiệu gan hơn. **AST** có cả ở bào tương **và ty thể**, ở gan, tim, cơ.
> - Thiếu **vitamin B~6~** (nghiện rượu, dùng **isoniazid** kéo dài để điều trị lao) làm giảm hoạt tính transaminase và các enzym phụ thuộc PLP khác. Vì vậy người dùng isoniazid thường được bổ sung B~6~.

> [!bay]
> - Trao đổi amin **không tạo NH~3~**, không làm giảm tổng lượng nitơ amin; nó chỉ **dồn** nitơ về glutamat. NH~3~ chỉ được giải phóng ở bước sau (khử amin oxy hóa glutamat).
> - Coenzym của transaminase là **PLP (B~6~)**, không phải NAD^+^ hay FAD.

### 2.2. Khử amin oxy hóa (oxidative deamination)

#### a) Khử amin oxy hóa các acid amin thông thường — L-acid amin oxidase

Gồm hai giai đoạn: acid amin bị **oxy hóa** thành **acid α-imin**, rồi acid imin **tự thủy phân** (không cần enzym) thành acid α-cetonic và NH~4~^+^. Enzym: **L-acid amin oxidase**, coenzym **FMN** (Giáo trình tr. 149–150).

=> R–CH(NH~3~^+^)–COO^−^ + FMN → R–C(=NH)–COO^−^ + FMNH~2~

=> R–C(=NH)–COO^−^ + H~2~O → R–CO–COO^−^ + NH~4~^+^

=> FMNH~2~ + O~2~ → FMN + H~2~O~2~

=> 2 H~2~O~2~ → 2 H~2~O + O~2~ (catalase)

Enzym này có ở gan, thận nhưng **hoạt tính thấp** và sinh ra **H~2~O~2~ độc**. Vì vậy nó **không có vai trò quan trọng** trong khử amin ở người.

> [!cap-nhat]
> Giáo trình ghi quá trình này "xảy ra ở bào tương", rồi lại nói enzym có ở "lưới nội bào gan, thận". Theo các sách hiện nay, L-acid amin oxidase nằm chủ yếu trong **peroxisom** của tế bào gan, thận; đây cũng là nơi có **catalase** để phân hủy H~2~O~2~ sinh ra.

#### b) Khử amin oxy hóa glutamat — glutamat dehydrogenase (GLDH)

Glutamat (tạo ra chủ yếu từ trao đổi amin) đi vào **ty thể** và bị khử amin oxy hóa nhờ **glutamat dehydrogenase (GLDH)**. Coenzym: **NAD^+^ hoặc NADP^+^** (Giáo trình tr. 150).

=> Glutamat + NAD(P)^+^ + H~2~O ⇌ α-cetoglutarat + NH~4~^+^ + NAD(P)H + H^+^

- GLDH có **hoạt tính rất mạnh** nên glutamat bị khử amin với tốc độ cao. Đây là con đường **trung tâm** giải phóng NH~3~ khỏi acid amin.
- Phản ứng **thuận nghịch**: chiều thuận giải phóng NH~4~^+^ (thoái hóa); chiều nghịch **gắn NH~4~^+^** vào α-cetoglutarat (tổng hợp glutamat, mục 6.2). Chiều nào thắng tùy nhu cầu cơ thể.
- GLDH là một trong số ít enzym dùng được **cả NAD^+^ lẫn NADP^+^**. NADH sinh ra đi vào chuỗi hô hấp tạo ATP (xem hs-06).

### 2.3. Liên quan giữa trao đổi amin và khử amin oxy hóa

Vì L-acid amin oxidase yếu, phần lớn acid amin **không bị khử amin trực tiếp**. Chúng bị khử amin **gián tiếp qua glutamat** (Giáo trình tr. 150):

=> Acid amin + α-cetoglutarat → (transaminase) → Acid α-cetonic + Glutamat

=> Glutamat + NAD^+^ + H~2~O → (GLDH) → α-cetoglutarat + NH~4~^+^ + NADH + H^+^

Cộng lại (α-cetoglutarat được tái tạo, đóng vai "con thoi"):

=> Acid amin + NAD^+^ + H~2~O → Acid α-cetonic + NH~4~^+^ + NADH + H^+^

Quá trình phối hợp này gọi là **trao đổi – khử amin** (transdeamination). **Vì sao cơ thể chọn đường vòng này?**

1. Transaminase **có hoạt tính cao** và có cho hầu hết acid amin.
2. GLDH **hoạt tính rất mạnh**, chỉ cần **một enzym** cho một cơ chất (glutamat) thay vì mỗi acid amin một enzym khử amin riêng.
3. **Có lợi về năng lượng**: tạo NADH (→ ATP), không sinh H~2~O~2~ độc như đường L-acid amin oxidase.

> [!bay]
> - Glutamat là "**ngã tư**" của chuyển hóa nitơ: vừa là **sản phẩm** của trao đổi amin, vừa là **cơ chất** của GLDH, vừa nhận NH~4~^+^ để tạo glutamin (mục 3.1).
> - α-cetoglutarat là **chất nhận** nhóm amin; nó không bị tiêu hao trong chuỗi trao đổi – khử amin vì được GLDH tái tạo.

## 3. Số phận của NH~3~: glutamin và chu trình ure

### 3.1. NH~3~ độc và cách cơ thể vận chuyển nó: glutamin

NH~4~^+^ sinh ra ở hầu hết các mô và là **chất độc**, nhất là với **não**. Khi NH~4~^+^ máu tăng cao, người bệnh có biểu hiện nhiễm độc, có thể **hôn mê**. Giáo trình giải thích: NH~4~^+^ làm thay đổi pH tế bào và **làm cạn cơ chất của chu trình acid citric** (Giáo trình tr. 151). Cơ chế: NH~4~^+^ dư đẩy phản ứng GLDH theo chiều **nghịch**, rút α-cetoglutarat khỏi chu trình Krebs để tạo glutamat, nên tế bào não thiếu ATP.

Vì vậy NH~4~^+^ phải được biến thành chất **không độc** trước khi vào máu đến gan hoặc thận. Ở các mô, NH~4~^+^ được gắn vào glutamat tạo **glutamin**, enzym **glutamin synthetase**, qua hai bước:

=> Bước 1: Glutamat + ATP → γ-glutamyl phosphat + ADP

=> Bước 2: γ-glutamyl phosphat + NH~4~^+^ → Glutamin + P~i~

**Glutamin** **không độc, trung tính**, dễ qua màng tế bào. Mỗi phân tử glutamin chở **2 nitơ** (một ở nhóm α-amin, một ở nhóm amid). Glutamin theo máu đến gan và thận. Ở đó **glutaminase** (trong **ty thể**) thủy phân glutamin, trả lại NH~4~^+^:

=> Glutamin + H~2~O → Glutamat + NH~4~^+^

Số phận tiếp theo của NH~4~^+^ tùy nơi (Giáo trình tr. 151):

| Nơi | NH~4~^+^ đi đâu | Ý nghĩa |
|---|---|---|
| **Thận** | Thải thẳng ra **nước tiểu** dưới dạng NH~4~^+^ | Thải H^+^ kèm theo → góp phần **điều hòa thăng bằng acid – base**. Khi nước tiểu nhiều H^+^ (toan máu), thủy phân glutamin ở thận tăng mạnh |
| **Gan** | Chuyển thành **ure** (chu trình ure) → máu → thận → nước tiểu | Con đường **chính** đào thải nitơ |

> [!vi-du] Từ cơ xương đến gan: glutamin và alanin
> *(Bổ sung ngoài giáo trình.)* Cơ xương còn gửi nitơ về gan bằng **alanin**: ở cơ, pyruvat (từ đường phân) nhận nhóm amin thành alanin; alanin theo máu về gan, nhờ **ALT** trả nhóm amin cho α-cetoglutarat, còn pyruvat được dùng để tạo lại glucose gửi về cơ. Vòng này gọi là **chu trình glucose – alanin**. Như vậy **glutamin và alanin** là hai dạng "xe chở" nitơ chính trong máu.

### 3.2. Chu trình ure

Ure (H~2~N–CO–NH~2~) được tổng hợp ở **tế bào gan**. **Nguyên liệu** (Giáo trình tr. 151–152):

| Nguyên liệu | Góp gì vào ure |
|---|---|
| **NH~4~^+^** tự do | Nitơ thứ nhất |
| **Aspartat** | Nitơ thứ hai |
| **CO~2~** dưới dạng **HCO~3~^−^** | Nguyên tử carbon |
| **3 ATP** | Năng lượng |
| **Ornitin** | "Mồi" (chất mang), được tái tạo sau mỗi vòng |
| **5 enzym** | Xúc tác 5 phản ứng |

Giáo trình chia thành **2 bước**: bước 1 là tổng hợp carbamyl phosphat; bước 2 gồm 4 phản ứng của vòng ornitin. Tổng cộng **5 phản ứng – 5 enzym**.

![Hình 2. Chu trình ure: 2 phản ứng trong ty thể, 3 phản ứng trong bào tương tế bào gan. Màu cam: enzym then chốt CPS I và chất hoạt hóa N-acetylglutamat; vòng nhỏ bên phải nối với chu trình acid citric](chu-trinh-ure.svg)

**Phản ứng ① — Tổng hợp carbamyl phosphat** (ty thể). Enzym: **carbamyl phosphat synthetase I** (CPS I), **enzym then chốt** của chu trình ure. Dùng **2 ATP**.

=> HCO~3~^−^ + NH~4~^+^ + 2 ATP → H~2~N–CO–O–PO~3~^2−^ (carbamyl phosphat) + 2 ADP + P~i~

**Phản ứng ② — Tạo citrulin** (ty thể). Enzym: **ornitin carbamyl transferase** (OTC). Nhóm carbamyl được chuyển sang ornitin.

=> Carbamyl phosphat + Ornitin → Citrulin + P~i~

Citrulin **ra khỏi ty thể** vào bào tương.

**Phản ứng ③ — Tạo argininosuccinat** (bào tương). Enzym: **argininosuccinat synthetase**. Aspartat mang nitơ thứ hai vào. Tốn 1 ATP nhưng cắt thành **AMP + PPi**, tức dùng **2 liên kết giàu năng lượng**.

=> Citrulin + Aspartat + ATP → Argininosuccinat + AMP + PP~i~

**Phản ứng ④ — Tạo arginin và fumarat** (bào tương). Enzym: **argininosuccinat lyase** (hình trong giáo trình ghi là *argininosuccinase*). Khung carbon của aspartat tách ra dưới dạng **fumarat**.

=> Argininosuccinat → Arginin + Fumarat

**Phản ứng ⑤ — Tạo ure và tái tạo ornitin** (bào tương). Enzym: **arginase**, protein **4 tiểu đơn vị**, cần ion **Mn^2+^**.

=> Arginin + H~2~O → Ure + Ornitin

Ornitin được **vận chuyển trở lại ty thể**, gặp carbamyl phosphat và bắt đầu vòng mới (Giáo trình tr. 152–153).

| Phản ứng | Enzym | Vị trí | Năng lượng |
|---|---|---|---|
| ① HCO~3~^−^ + NH~4~^+^ → carbamyl phosphat | **CPS I** (then chốt) | Ty thể | 2 ATP → 2 ADP |
| ② + ornitin → citrulin | Ornitin carbamyl transferase (OTC) | Ty thể | — |
| ③ + aspartat → argininosuccinat | Argininosuccinat synthetase | Bào tương | ATP → AMP + PPi |
| ④ → arginin + fumarat | Argininosuccinat lyase | Bào tương | — |
| ⑤ arginin → ure + ornitin | Arginase (Mn^2+^) | Bào tương | — |

**Phương trình tổng** (Giáo trình tr. 153):

=> Aspartat + HCO~3~^−^ + NH~4~^+^ + 3 ATP + H~2~O → Ure + 2 ADP + AMP + 2 P~i~ + PP~i~ + Fumarat

Theo giáo trình, đào thải nitơ dưới dạng ure **tiêu tốn khoảng 15% năng lượng** thu được từ thoái hóa acid amin.

> [!bay]
> - **3 ATP nhưng 4 liên kết phosphat giàu năng lượng**: phản ứng ③ cắt ATP thành AMP + PPi, và PPi bị thủy phân tiếp thành 2 P~i~.
> - Hai nitơ của ure đến từ **NH~4~^+^** (qua carbamyl phosphat) và **aspartat**; carbon từ **HCO~3~^−^**. Ornitin **không** góp nguyên tử nào vào ure, nó chỉ là chất mang.
> - **Ty thể**: CPS I, OTC (2 phản ứng đầu). **Bào tương**: 3 phản ứng sau. Chất đi ra ty thể là **citrulin**; chất đi vào là **ornitin**.
> - CPS **I** (ty thể, dùng NH~4~^+^, chu trình ure) khác CPS **II** (bào tương, dùng nitơ amid của glutamin, tổng hợp **pyrimidin**).
> - Arginase **không** tạo arginin; nó **thủy phân** arginin. Enzym tạo arginin là argininosuccinat lyase.

> [!vi-du] Arginase ở đâu?
> Giáo trình viết arginase "thấy ở não, thận và một số cơ quan khác". Điều này đúng nhưng dễ gây hiểu lầm: arginase **nhiều nhất ở gan** (bào tương tế bào gan) và **chỉ gan có đủ 5 enzym** nên chỉ gan tổng hợp được ure. Arginase ở mô khác (thận…) là một dạng khác (isoenzym), chủ yếu tạo ornitin cho các mục đích khác.

#### Điều hòa chu trình ure

- Điều hòa **chủ yếu ở bước tổng hợp carbamyl phosphat**. CPS I chỉ hoạt động khi có **N-acetylglutamat** (NAG), chất **hoạt hóa dị lập thể** bắt buộc (Giáo trình tr. 154).
- NAG được tổng hợp từ **acetyl-CoA + glutamat**; **arginin** thúc đẩy sự tổng hợp này. NAG bị thủy phân bởi **deacylase**.
- Nồng độ các chất trung gian của chu trình, như **ornitin**, cũng ảnh hưởng tốc độ chu trình.

**Vì sao logic?** Sau bữa giàu protein, nhiều acid amin → nhiều glutamat và arginin → nhiều NAG → CPS I hoạt động mạnh → tăng tạo ure, đúng lúc có nhiều NH~3~ cần thải.

> [!bay]
> Giáo trình viết NAG "được tổng hợp từ acetyl-CoA, glutamat, arginin". Chính xác hơn: **nguyên liệu** chỉ là acetyl-CoA + glutamat; **arginin là chất hoạt hóa** enzym tổng hợp NAG (N-acetylglutamat synthase), không góp nguyên tử vào NAG.

#### Liên quan giữa chu trình ure và chu trình acid citric

Hai chu trình nối với nhau qua **fumarat** và **aspartat** (Giáo trình tr. 153–154):

1. Chu trình ure **cung cấp fumarat** (phản ứng ④).
2. Fumarat → malat → **oxaloacetat** (các phản ứng giống của chu trình acid citric).
3. Oxaloacetat **trao đổi amin** với acid amin, đặc biệt **glutamat** (enzym **AST**), tạo **aspartat** và α-cetoglutarat.
4. Aspartat phản ứng với **citrulin** của chu trình ure tạo argininosuccinat (phản ứng ③).

Như vậy aspartat là "cầu" đưa nitơ (từ glutamat, tức từ nhiều acid amin) vào ure, còn fumarat đưa khung carbon trở lại chuyển hóa năng lượng. Người ta gọi hai chu trình gắn nhau như vậy là "**xe đạp Krebs**" (Krebs bicycle), vì Hans Krebs phát hiện cả hai.

> [!ung-dung] Xét nghiệm ure máu
> - Giáo trình: ure máu **0,2–0,4 g/L (3,5–7 mmol/L)**; ure nước tiểu **15–20 g/24 giờ**, thay đổi theo lượng protein ăn vào (Giáo trình tr. 153). Nhiều phòng xét nghiệm ở Việt Nam hiện dùng khoảng **2,5–7,5 mmol/L** (tham khảo, mỗi phòng xét nghiệm có khoảng riêng).
> - **Ure máu tăng**: suy thận (giảm thải), ăn nhiều protein, xuất huyết tiêu hóa (protein máu bị tiêu hóa trong ruột), tăng dị hóa (sốt, nhiễm trùng nặng), mất nước.
> - **Ure máu giảm**: suy gan nặng (giảm tạo ure, trong khi **NH~3~ máu tăng**), ăn quá ít protein.
> - Vì ure chịu ảnh hưởng của chế độ ăn và chức năng gan, đánh giá **chức năng lọc của thận** nên dựa thêm vào **creatinin** (mục 7.1).

## 4. Chuyển hóa nhóm carboxyl: khử carboxyl và amin sinh học

Trong các mô, acid amin có thể bị **khử carboxyl** nhờ **decarboxylase** (đặc hiệu cho từng acid amin), tạo ra **amin** và CO~2~ (Giáo trình tr. 154):

=> R–CH(NH~3~^+^)–COO^−^ → R–CH~2~–NH~2~ + CO~2~

Coenzym của các decarboxylase acid amin cũng là **PLP** (vitamin B~6~) (xem hs-05, bảng coenzym). Nhiều amin tạo ra có **hoạt tính sinh học mạnh**:

| Acid amin | Amin sinh học | Vai trò |
|---|---|---|
| **Glutamat** | **GABA** (acid γ-amino butyric) | Chất **ức chế** dẫn truyền thần kinh, nhiều ở thần kinh trung ương, nhất là não |
| **Histidin** | **Histamin** | Dẫn truyền thần kinh; gây giãn mạch, co phế quản, tiết acid dạ dày; có ở nhiều mô (dưỡng bào) |
| **Tryptophan** (qua 5-hydroxytryptophan) | **Serotonin** | Dẫn truyền thần kinh, co mạch, nhu động ruột |
| **Tyrosin** (qua DOPA) | **Dopamin** → noradrenalin → adrenalin (catecholamin) | Dẫn truyền thần kinh, hormon tủy thượng thận |

=> Glutamat: ^−^OOC–(CH~2~)~2~–CH(NH~3~^+^)–COO^−^ → ^−^OOC–(CH~2~)~2~–CH~2~–NH~2~ (GABA) + CO~2~

**Bất hoạt amin.** Khi hết tác dụng, amin bị **khử amin oxy hóa** nhờ **mono amin oxidase (MAO)** hoặc **diamin oxidase** thành aldehyd, rồi aldehyd bị dehydrogenase oxy hóa thành acid. Acid carboxylic tiếp tục thoái hóa đến CO~2~ và H~2~O (Giáo trình tr. 154–155):

=> R–CH~2~–NH~2~ + O~2~ → (MAO) → R–CHO + NH~4~^+^

=> R–CHO + NAD^+^ → (dehydrogenase) → R–COOH + NADH + H^+^

> [!ung-dung] Thuốc tác động lên amin sinh học
> - **Thuốc ức chế MAO** (một nhóm thuốc chống trầm cảm, thuốc trị Parkinson) làm amin dẫn truyền thần kinh tồn tại lâu hơn. Người dùng thuốc này ăn nhiều thức ăn giàu **tyramin** (phô mai lâu năm, đồ lên men) có thể bị **cơn tăng huyết áp**, vì tyramin không còn bị MAO ở ruột, gan phân hủy.
> - **Thuốc kháng histamin H~1~** (chống dị ứng) và **H~2~** (giảm tiết acid dạ dày) chặn thụ thể của histamin.
> - **Levodopa** (L-DOPA) điều trị Parkinson: qua được hàng rào máu – não rồi được **khử carboxyl** thành dopamin ngay trong não; thường dùng kèm chất ức chế decarboxylase ngoại vi (carbidopa) để thuốc không bị chuyển hóa sớm ngoài não.

> [!bay]
> Khử carboxyl **giữ nguyên nhóm amin** (sản phẩm là amin), còn khử amin **giữ nguyên nhóm carboxyl** (sản phẩm là acid α-cetonic). Về coenzym: transaminase và decarboxylase cùng dùng **PLP**, còn khử amin oxy hóa dùng **FMN** (L-acid amin oxidase) hoặc **NAD(P)^+^** (GLDH).

## 5. Chuyển hóa khung carbon

### 5.1. Khung carbon đi về đâu?

Sau khi mất nhóm amin, 20 acid amin cho ra chỉ **7 sản phẩm**: **pyruvat, oxaloacetat, α-cetoglutarat, succinyl-CoA, fumarat, acetyl-CoA, acetoacetyl-CoA** (Giáo trình tr. 155):

| Sản phẩm | Acid amin (theo giáo trình) | Số |
|---|---|---|
| **Pyruvat** | Gly, Ala, Cys, Ser, Thr, Trp | 6 |
| **Oxaloacetat** | Asp, Asn | 2 |
| **α-cetoglutarat** | Glu, Gln, Arg, His, Pro | 5 |
| **Succinyl-CoA** | Val, Ile, Thr, Met | 4 |
| **Fumarat** | Phe, Tyr (và Asp qua chu trình ure) | — |
| **Acetyl-CoA, acetoacetyl-CoA** | Leu, Lys, Trp, Tyr, Phe (và một phần Ile) | 5 |

Một acid amin có thể xuất hiện ở hai dòng vì khung carbon của nó bị cắt thành **hai mảnh** (vd Phe, Tyr → fumarat + acetoacetat; Thr → pyruvat hoặc succinyl-CoA).

Các sản phẩm này có ba hướng đi (Giáo trình tr. 156):

1. **Thoái hóa hoàn toàn** trong chu trình acid citric → CO~2~ + H~2~O + năng lượng. Mọi acid amin đều đi được đường này.
2. **Tạo glucose** (tân tạo glucose): sản phẩm là pyruvat hoặc chất trung gian của chu trình Krebs → oxaloacetat → phosphoenolpyruvat → glucose. Acid amin như vậy gọi là **acid amin sinh đường**.
3. **Tạo thể ceton**: sản phẩm là acetyl-CoA hoặc acetoacetyl-CoA. Acid amin như vậy gọi là **acid amin sinh ceton**.

**Vì sao acetyl-CoA không tạo được glucose?** Hai carbon của acetyl-CoA vào chu trình Krebs thì **mất đi đúng 2 CO~2~** trước khi về lại oxaloacetat. Không có lượng oxaloacetat "dư" nào được tạo ra để làm glucose. Phản ứng pyruvat → acetyl-CoA lại **không thuận nghịch**. Ngược lại, chất trung gian 4–5 carbon của chu trình làm **tăng thêm** oxaloacetat, nên tạo được glucose.

### 5.2. Acid amin sinh đường và sinh ceton

Giáo trình định nghĩa theo **thực nghiệm** (Giáo trình tr. 156):

- **Acid amin sinh đường**: đưa vào cơ thể người bệnh **đái tháo đường tụy** thì thấy **tăng glucose niệu**. Có **14** acid amin: Gly, Ala, Ser, Thr, Cys, Arg, His, Pro, Glu, Gln, Met, Val, Asp, Asn.
- **Acid amin sinh ceton**: làm **tăng thể ceton** trong nước tiểu, vì khung carbon tạo ra acetoacetyl-CoA, acetyl-CoA.
- **Vừa sinh đường vừa sinh ceton**: Phe, Tyr, Trp, Ile, Lys.
- Còn lại **Leu**: chỉ **sinh ceton**.

| Loại | Acid amin |
|---|---|
| Chỉ sinh đường | 14 acid amin kể trên |
| Vừa sinh đường vừa sinh ceton | Phe, Tyr, Trp, Ile, Lys |
| Chỉ sinh ceton | Leu |

> [!cap-nhat]
> Giáo trình xếp **Lys** vào nhóm "vừa sinh đường vừa sinh ceton". Theo các sách hóa sinh hiện nay, **Leu và Lys** là hai acid amin **chỉ sinh ceton**; Thr được một số sách xếp vào nhóm vừa sinh đường vừa sinh ceton. Đi thi trả lời theo giáo trình (chỉ Leu là sinh ceton đơn thuần).

> [!ung-dung] Khi đói kéo dài
> Khi nhịn đói, glycogen gan cạn sau khoảng một ngày. Cơ thể phân giải **protein cơ** để lấy acid amin sinh đường (nhất là **alanin**, **glutamin**) làm nguyên liệu tạo glucose cho não và hồng cầu. Đó là lý do người đói lâu, bệnh nặng kéo dài hoặc đái tháo đường không kiểm soát bị **teo cơ**, và lượng **ure niệu tăng** (nhiều acid amin bị tách nitơ).

### 5.3. Thoái hóa riêng của một số họ acid amin

Giáo trình nhóm theo số carbon và sản phẩm cuối (Giáo trình tr. 156–157).

**a) Họ 3C → pyruvat: Ala, Ser, Cys (và Gly, Thr, Trp)**

- **Ala**: trao đổi amin với α-cetoglutarat (ALT) → pyruvat + glutamat; glutamat bị GLDH khử amin và tái tạo α-cetoglutarat. Tổng: Ala + NAD^+^ + H~2~O → Pyruvat + NH~4~^+^ + NADH + H^+^.
- **Ser**: khử amin bằng **serin hydratase** (serin dehydratase) → pyruvat + NH~4~^+^.
- **Cys**: → pyruvat, đồng thời tạo các chất chứa lưu huỳnh: H~2~S, SO~3~^2−^, SCN^−^.
- **Trp** → Ala → pyruvat; **Gly** → Ser → pyruvat; **Thr** → aminoaceton → pyruvat.

**b) Họ 4C → oxaloacetat: Asp, Asn**

- **Asp** trao đổi amin với α-cetoglutarat (AST) → oxaloacetat + glutamat.
- **Asn** bị **asparaginase** thủy phân → Asp + NH~4~^+^, rồi Asp đi như trên. Asp cũng có thể thành **fumarat** qua chu trình ure.

**c) Họ 5C → α-cetoglutarat qua glutamat: Glu, Gln, Pro, Arg, His**

- Tất cả trước hết thành **glutamat**, rồi GLDH chuyển glutamat thành α-cetoglutarat.
- **Gln** → Glu + NH~4~^+^ (glutaminase). **Pro, Arg** → glutamat semialdehyd → Glu. **His** → Glu.

**d) Acid amin mạch nhánh: Leu, Ile, Val**

Thoái hóa theo cách tương tự nhau. Với Leu (giáo trình):

=> Leu → α-cetoisocaproat → isovaleryl-CoA → β-methylcrotonyl-CoA → … → acetyl-CoA

Bước thứ hai (khử carboxyl oxy hóa acid α-cetonic mạch nhánh) do **một phức hợp enzym chung** cho cả ba acid amin, gọi là phức hợp **α-cetoacid mạch nhánh dehydrogenase** *(bổ sung)*. Val cho succinyl-CoA; Ile cho succinyl-CoA và acetyl-CoA; Leu cho acetyl-CoA và acetoacetat.

**e) Phe, Tyr → fumarat và acetoacetat**

=> Phe → Tyr → p-hydroxyphenylpyruvat → **homogentisat** → maleylacetoacetat → fumarylacetoacetat → **fumarat + acetoacetat**

- Phe → Tyr do **phenylalanin hydroxylase**. Vì vậy Tyr **không cần thiết** chừng nào cơ thể có đủ Phe.
- Một sản phẩm cho đường (fumarat), một cho ceton (acetoacetat): Phe, Tyr "vừa sinh đường vừa sinh ceton".
- Đây là con đường của ba bệnh kinh điển: **phenylceton niệu**, **alkapton niệu** và (từ nhánh Tyr → melanin) **bạch tạng** (mục 8).

> [!bay]
> Giáo trình viết chất trung gian là "4-maleylacetat" và "4-fumarylacetoacetat". Tên đúng là **maleylacetoacetat** và **fumarylacetoacetat** (đồng phân cis – trans của nhau); fumarylacetoacetat bị thủy phân thành fumarat + acetoacetat.

## 6. Tổng hợp acid amin

### 6.1. Acid amin cần thiết

Người và động vật bậc cao tổng hợp được khoảng **10 (hoặc 12)** trong 20 acid amin thường gặp: đó là các acid amin **không cần thiết**. **8 acid amin** cơ thể người **không tổng hợp được** phải lấy từ thức ăn: các acid amin **cần thiết** (Giáo trình tr. 147, 157–158):

=> **Val, Ile, Leu, Lys, Met, Phe, Trp, Thr**

**Arg và His**: cơ thể trẻ em tổng hợp không đủ → **acid amin bán cần thiết**.

> [!vi-du] Cách nhớ 8 acid amin cần thiết theo nhóm
> - **3 acid amin mạch nhánh**: Val, Leu, Ile.
> - **2 acid amin thơm**: Phe, Trp (Tyr không cần thiết vì tạo được từ Phe).
> - **3 acid amin còn lại**: Lys, Met (chứa S), Thr (chứa –OH).
> - Thêm **Arg, His**: bán cần thiết ở trẻ em.

> [!cap-nhat]
> Giáo trình ghi 8 acid amin cần thiết cho người trưởng thành. Hiện nay (FAO/WHO và các sách dinh dưỡng – hóa sinh), **histidin** được tính là acid amin cần thiết **cả ở người lớn**, nên danh sách là **9**. Đi thi trả lời theo giáo trình (8).

### 6.2. Đưa nitơ vào hợp chất sinh học

**a) Cố định N~2~** (chỉ ở vi sinh vật; thực vật nhận nhờ vi khuẩn cộng sinh và hấp thu nitrit, nitrat). Enzym **nitrogenase** (Giáo trình tr. 158):

=> N~2~ + 10 H^+^ + 8 e^−^ + 16 ATP → 2 NH~4~^+^ + 16 ADP + 16 P~i~ + H~2~

Phá liên kết ba N≡N rất tốn năng lượng: **16 ATP** cho mỗi phân tử N~2~.

**b) NH~4~^+^ đi vào acid amin qua glutamin và glutamat** — con đường giống nhau ở mọi cơ thể sống.

*Tạo glutamin* — glutamin synthetase, con đường quan trọng nhất:

=> Glu + NH~4~^+^ + ATP → Gln + P~i~ + ADP + H^+^

*Tạo glutamat ở vi khuẩn* — amin hóa α-cetoglutarat bằng **glutamat synthetase** (tên hiện nay: glutamat synthase, GOGAT), glutamin là chất cho nhóm amin:

=> α-cetoglutarat + Gln + NADPH + H^+^ → 2 Glu + NADP^+^

*Tạo glutamat ở động vật* — chủ yếu bằng **trao đổi amin** với α-cetoglutarat; hoặc gắn NH~4~^+^ trực tiếp nhờ **GLDH** (chiều nghịch):

=> α-cetoglutarat + NH~4~^+^ + NADPH + H^+^ → Glu + NADP^+^ + H~2~O

Như vậy NH~4~^+^ được đưa vào phân tử sinh học dưới dạng **nhóm amin của glutamat** hoặc **nhóm amid của glutamin**. Từ đó nhóm amin được phân phát đi tổng hợp các acid amin khác và các hợp chất chứa nitơ.

### 6.3. Tổng hợp các acid amin

Tổng hợp acid amin = **gắn nhóm amin vào khung carbon** tương ứng. Khung carbon lấy từ các chất trung gian chuyển hóa. Theo nguồn khung carbon, chia thành các **họ** (Giáo trình tr. 159):

| Họ (chất khởi đầu) | Nguồn |
|---|---|
| **α-cetoglutarat** | Chu trình acid citric |
| **3-phosphoglycerat** | Đường phân |
| **Oxaloacetat** | Chu trình acid citric |
| **Pyruvat** | Đường phân |
| **Phosphoenolpyruvat + erythrose-4-phosphat** (acid amin thơm) | Đường phân + con đường pentose phosphat |
| **Ribose-5-phosphat** (histidin) | Con đường pentose phosphat |

Thực vật bậc cao tổng hợp được tất cả acid amin từ N~2~ (nhờ cộng sinh), nitrit, nitrat; *E. coli* tổng hợp được tất cả từ NH~4~^+^.

**Điều hòa.** Tổng hợp acid amin được điều hòa bằng **ức chế ngược (feedback)**: sản phẩm cuối ức chế enzym xúc tác **phản ứng đầu tiên** của con đường. Enzym này là **enzym dị lập thể**, sản phẩm cuối là **chất ức chế dị lập thể**. Có hai kiểu đặc biệt:

- **Ức chế phối hợp**: nhiều sản phẩm cuối cùng ức chế một enzym.
- **Ức chế ngược kế tiếp nhau**: các chất trung gian ức chế ngược theo từng chặng.

**Vì sao ức chế bước đầu tiên?** Nếu chặn ở bước giữa, các chất trung gian phía trước sẽ ứ đọng và lãng phí năng lượng. Chặn ngay từ đầu thì không tốn nguyên liệu khi sản phẩm đã đủ.

## 7. Tổng hợp các chất có hoạt tính sinh học từ acid amin

Acid amin không chỉ để xây protein. Nhiều chất quan trọng có nguồn gốc acid amin (Giáo trình tr. 159–161):

| Chất | Tạo từ | Ghi chú |
|---|---|---|
| **Porphyrin** (của hem: Hb, Mb, cytochrom, catalase) | **Glycin + succinyl-CoA** | Học ở bài Chuyển hóa hemoglobin |
| **Base purin, pyrimidin** | **Gly, Asp, Gln** (và Ser) | Có trong ATP, GTP, UTP, acid nucleic, NAD^+^, FAD |
| **Hormon tuyến giáp T~3~, T~4~**; **adrenalin, noradrenalin** | **Phe, Tyr** | Nhiều hormon khác là peptid, protein |
| **Cholin, ethanolamin** (của phospholipid) | **Serin** | |
| **Creatin** | **Gly, Arg, Met** | Dự trữ năng lượng ở cơ (mục 7.1) |
| **Glutathion** | **Glu, Cys, Gly** | Chống oxy hóa (mục 7.2) |
| **Chất dẫn truyền thần kinh** | Glu → GABA; His → histamin; Trp → serotonin; Phe, Tyr → catecholamin; **Glycin** tự nó là chất ức chế dẫn truyền | Mục 4 |
| **Taurin** (liên hợp acid mật) | **Cys** | |
| **Vitamin PP** (acid nicotinic) | **Trp** | Lượng tạo ra không đủ thay thế hoàn toàn vitamin từ thức ăn |

### 7.1. Creatin, creatin phosphat và creatinin

**Tổng hợp creatin** từ 3 acid amin: **Gly, Arg, Met** (Giáo trình tr. 159–160):

=> Gly + Arg → (amidinotransferase) → Guanidoacetat + Ornitin

=> Guanidoacetat + S-adenosylmethionin → (methyltransferase) → Creatin + S-adenosylhomocystein

- **Arg** cho nhóm amidin, **Gly** cho khung, **Met** (dạng hoạt hóa S-adenosylmethionin) cho nhóm **methyl**.
- Bước 1 (tạo guanidoacetat) diễn ra chủ yếu ở **thận**, bước 2 (methyl hóa) ở **gan** *(bổ sung; giáo trình chỉ ghi creatin được tổng hợp ở gan)*. Creatin theo máu đến **cơ** và các mô.

**Creatin phosphat** — dạng dự trữ năng lượng của cơ. Enzym **creatin kinase (CK)** chuyển phosphat từ ATP sang creatin khi **cơ nghỉ**, và ngược lại tái tạo ATP khi **cơ cần**:

=> Creatin + ATP ⇌ Creatin phosphat + ADP

**Vì sao cơ cần "kho đệm" này?** ATP trong cơ chỉ đủ cho vài giây co cơ mạnh. Creatin phosphat tái tạo ATP **ngay lập tức** bằng một phản ứng duy nhất, chờ đường phân và phosphoryl oxy hóa tăng tốc.

**Creatinin** — creatin (và creatin phosphat) **mất nước, đóng vòng** thành creatinin. Đặc điểm:

- Tạo ra **mỗi ngày một lượng gần như hằng định**, **tỷ lệ với khối lượng cơ**.
- Đào thải qua **thận** ra nước tiểu (lọc ở cầu thận, hầu như không tái hấp thu).

> [!ung-dung] Creatinin và CK trong xét nghiệm
> - Vì lượng tạo ra ổn định và thải chủ yếu qua lọc cầu thận, **creatinin máu** là xét nghiệm cơ bản đánh giá **chức năng lọc của thận**: thận suy thì creatinin máu tăng. Từ creatinin máu, tuổi, giới người ta **ước tính mức lọc cầu thận (eGFR)**. Khoảng tham chiếu thường dùng ở người lớn: nam khoảng **62–120 µmol/L**, nữ khoảng **53–100 µmol/L** (như hs-18, hs-19; có phòng xét nghiệm dùng nam 62–106, nữ 44–80 µmol/L — tham khảo, mỗi phòng xét nghiệm có khoảng riêng).
> - Người **ít cơ** (người già gầy yếu, trẻ em) có creatinin thấp; vì vậy creatinin "bình thường" ở người rất gầy vẫn có thể che giấu suy thận.
> - **CK** tăng khi tổn thương cơ (tiêu cơ vân, nhồi máu cơ tim với CK-MB): xem hs-05 mục 9.

### 7.2. Glutathion

**Cấu trúc.** Glutathion là **tripeptid γ-Glu-Cys-Gly**. Liên kết giữa Glu và Cys dùng nhóm carboxyl **γ** (ở gốc R) của glutamat, không phải nhóm α-carboxyl như liên kết peptid thông thường. Nhóm **–SH của Cys** là phần hoạt động. Dạng khử viết là **GSH**; hai phân tử nối nhau bằng cầu disulfid là dạng oxy hóa **GSSG** (Giáo trình tr. 160).

**Tổng hợp** qua hai bước, mỗi bước dùng **1 ATP** (enzym synthetase):

=> Glu + Cys + ATP → γ-Glu-Cys + ADP + P~i~

=> γ-Glu-Cys + Gly + ATP → γ-Glu-Cys-Gly + ADP + P~i~

**Vai trò** — một **chất khử** nồng độ cao, nhất là trong **hồng cầu**:

- Khử **methemoglobin** (Fe^3+^, không chở được O~2~) về hemoglobin:

=> 2 GSH + 2 MetHb → GSSG + 2 Hb + 2 H^+^

- Khử độc **H~2~O~2~** và gốc tự do nhờ **glutathion peroxidase**, bảo vệ **màng tế bào** (nhất là màng hồng cầu):

=> 2 GSH + H~2~O~2~ → GSSG + 2 H~2~O

- GSSG được tái tạo thành GSH nhờ **glutathion reductase**, dùng **NADPH** do **con đường pentose phosphat** cung cấp:

=> GSSG + NADPH + H^+^ → 2 GSH + NADP^+^

Trong tế bào, tỷ lệ **GSH/GSSG khoảng 500**: glutathion gần như luôn ở dạng khử, sẵn sàng "hy sinh" thay cho protein và lipid màng (Giáo trình tr. 161).

> [!ung-dung] Khi glutathion không đủ
> - **Thiếu G6PD** (glucose-6-phosphat dehydrogenase, enzym đầu của con đường pentose phosphat): hồng cầu thiếu NADPH → không tái tạo được GSH → khi gặp chất oxy hóa (một số thuốc như primaquin, sulfonamid; ăn **đậu tằm**; nhiễm trùng) màng hồng cầu bị oxy hóa → **tan máu cấp**. Chi tiết ở bài Chuyển hóa glucid.
> - **Ngộ độc paracetamol**: liều cao tạo nhiều chất chuyển hóa độc (NAPQI), vốn được GSH trung hòa. GSH gan cạn → **hoại tử tế bào gan** (ALT, AST tăng rất cao). Thuốc giải độc **N-acetylcystein** cung cấp Cys để gan tổng hợp lại glutathion.

## 8. Bệnh lý acid amin

### 8.1. Khái niệm (theo giáo trình)

**Bệnh lý acid amin** (aminoacidopathies) là các **rối loạn chuyển hóa acid amin**, phần lớn là **rối loạn di truyền hiếm gặp** (Giáo trình tr. 147, 161). Nguyên nhân thuộc một trong hai nhóm:

1. **Thiếu hụt enzym đặc hiệu** trên đường chuyển hóa một acid amin.
2. **Bất thường hệ thống vận chuyển** acid amin qua màng (ở ống thận, ruột).

Hậu quả chung: **tăng acid amin trong máu**, **tăng đào thải acid amin (hoặc chất chuyển hóa của nó) ra nước tiểu**, kèm dấu hiệu lâm sàng tương ứng.

**Vì sao thiếu một enzym gây bệnh?** Cơ chất phía trước enzym **ứ đọng** (tràn vào máu, nước tiểu, có khi bị chuyển sang đường phụ thành chất độc), còn sản phẩm phía sau **thiếu**. Hai cơ chế này giải thích gần như mọi triệu chứng.

### 8.2. Một số bệnh thường gặp *(bổ sung ngoài giáo trình)*

Phần này giáo trình chỉ nêu khái niệm; các bệnh dưới đây là ví dụ kinh điển, hay gặp trong thi và lâm sàng.

| Bệnh | Enzym / khiếm khuyết | Chất ứ đọng – dấu hiệu xét nghiệm | Biểu hiện chính |
|---|---|---|---|
| **Phenylceton niệu** (PKU) | **Phenylalanin hydroxylase** (Phe → Tyr); hiếm hơn: thiếu coenzym tetrahydrobiopterin (BH~4~) | **Phe máu tăng** cao; Phe chuyển sang đường phụ thành **phenylpyruvat** (một acid phenylcetonic, nên gọi "phenylceton niệu"), phenyllactat, phenylacetat trong nước tiểu (mùi "chuột", mùi mốc) | **Chậm phát triển trí tuệ** nếu không điều trị sớm, co giật; **da, tóc nhạt màu** (thiếu Tyr để tạo melanin) |
| **Alkapton niệu** | **Homogentisat oxidase** (homogentisat 1,2-dioxygenase) | **Acid homogentisic** trong nước tiểu; nước tiểu **sẫm đen khi để lâu ngoài không khí** hoặc khi kiềm hóa | Thường lành tính lúc nhỏ; người lớn: sắc tố đen lắng ở sụn, gân (**ochronosis**: vành tai, củng mạc sạm), **viêm khớp** cột sống, khớp lớn |
| **Bạch tạng** (thể da – mắt typ 1) | **Tyrosinase** của tế bào hắc tố (Tyr → DOPA → melanin) | Không có tăng acid amin máu; thiếu **melanin** | Da, tóc trắng; mắt sợ ánh sáng, giảm thị lực, rung giật nhãn cầu; dễ **ung thư da** |
| **Bệnh nước tiểu siro cây phong** (MSUD) | Phức hợp **α-cetoacid mạch nhánh dehydrogenase** | Leu, Ile, Val và acid α-cetonic của chúng tăng; nước tiểu **mùi đường cháy, siro** | Sơ sinh bỏ bú, nôn, co giật, hôn mê |
| **Homocystin niệu** | Thường là **cystathionin β-synthase** | **Homocystein** máu tăng, homocystin niệu | Lệch thể thủy tinh, dáng cao gầy, chậm trí tuệ, **huyết khối** sớm |
| **Cystin niệu** (rối loạn **vận chuyển**) | Kênh tái hấp thu acid amin kiềm ở ống thận và ruột | Tăng thải **Cys(tin), Orn, Arg, Lys** niệu | **Sỏi cystin** (cystin rất ít tan) |
| **Bệnh Hartnup** (rối loạn **vận chuyển**) | Kênh vận chuyển acid amin trung tính | Tăng acid amin trung tính niệu; mất Trp | Thiếu Trp → thiếu vitamin PP: ban da giống **pellagra**, rối loạn thần kinh |

Hầu hết các bệnh trên **di truyền lặn trên nhiễm sắc thể thường**.

> [!ung-dung] Phenylceton niệu: điều trị bằng chế độ ăn
> - **Phát hiện sớm** là then chốt: xét nghiệm Phe trong giọt máu gót chân sơ sinh. Tại Việt Nam, PKU nằm trong các gói **sàng lọc sơ sinh mở rộng** (bằng kỹ thuật khối phổ) ở một số bệnh viện; sàng lọc cơ bản thường chỉ gồm G6PD, suy giáp bẩm sinh, tăng sản thượng thận bẩm sinh.
> - Điều trị: **chế độ ăn ít Phe** suốt đời (sữa công thức đặc biệt, hạn chế thịt, cá, trứng, sữa thường), giữ Phe máu trong khoảng mục tiêu (thường khoảng 120–360 µmol/L; người bình thường dưới khoảng 120 µmol/L — tham khảo). Ở người bệnh này **Tyr trở thành acid amin cần thiết** (xem hs-03).
> - Người PKU phải tránh chất ngọt **aspartam** (Asp-Phe methyl ester), vì nó giải phóng Phe. Nhãn đồ uống "ăn kiêng" thường ghi cảnh báo "chứa phenylalanin".
> - Phụ nữ PKU khi mang thai phải kiểm soát Phe thật chặt từ trước khi thụ thai: Phe máu mẹ cao gây **đầu nhỏ, dị tật tim** cho thai, dù thai không mắc bệnh.

> [!bay]
> - PKU và bạch tạng đều làm **da, tóc nhạt**, nhưng cơ chế khác: PKU **thiếu Tyr** (và Phe dư ức chế tyrosinase); bạch tạng **thiếu tyrosinase** dù Tyr bình thường. PKU có Phe máu tăng, chậm trí tuệ; bạch tạng thì không.
> - Alkapton niệu: thiếu enzym ở **sau** homogentisat (homogentisat oxidase), nên **homogentisat** ứ đọng. Không nhầm với PKU (thiếu enzym đầu tiên Phe → Tyr).
> - Alkapton niệu là một trong những bệnh đầu tiên được **Archibald Garrod** (1902) mô tả là "**sai sót bẩm sinh của chuyển hóa**" (inborn errors of metabolism).

### 8.3. Tăng amoniac máu

**Nguyên nhân** chia hai nhóm:

| Nhóm | Ví dụ | Cơ chế |
|---|---|---|
| **Di truyền** — thiếu enzym chu trình ure | Thiếu CPS I, **OTC** (hay gặp nhất, di truyền **liên kết X**), argininosuccinat synthetase (citrulin máu tăng), argininosuccinat lyase, arginase; thiếu N-acetylglutamat synthase | Chu trình ure tắc → NH~3~ và glutamin ứ đọng. Thiếu OTC: carbamyl phosphat tràn ra bào tương đi vào đường tổng hợp pyrimidin → **tăng acid orotic niệu** |
| **Mắc phải** (hay gặp hơn nhiều) | **Xơ gan**, suy gan cấp; nối tắt cửa – chủ; một số thuốc (acid valproic) | Gan không đủ tế bào hoặc máu đi tắt qua gan → NH~3~ từ ruột không được chuyển thành ure |

**Biểu hiện**: chán ăn, nôn, lơ mơ, kích thích, run vẫy (asterixis), co giật, **hôn mê**; ở trẻ sơ sinh thiếu enzym chu trình ure: bỏ bú, li bì sau vài ngày bú sữa (sữa mang protein).

> [!cap-nhat] Vì sao NH~3~ độc với não?
> Giáo trình giải thích NH~4~^+^ làm cạn α-cetoglutarat của chu trình acid citric (mục 3.1). Cơ chế này vẫn được thừa nhận, nhưng hiện nay người ta nhấn mạnh thêm: ở não, NH~3~ được **tế bào sao** (astrocyte) khử độc bằng glutamin synthetase; **glutamin tích tụ** trong tế bào sao kéo nước vào → **tế bào sao phù**, **phù não**. NH~3~ còn làm rối loạn dẫn truyền thần kinh (glutamat, GABA). Đây là cơ sở của bệnh não do tăng amoniac và bệnh não gan.

**Nguyên tắc điều trị** (để hiểu cơ chế, không phải phác đồ):

- **Giảm nguồn NH~3~**: hạn chế protein tạm thời (trong thiếu enzym chu trình ure); ở bệnh não gan, giảm NH~3~ do vi khuẩn ruột sinh ra.
- **Tăng thải nitơ bằng đường khác**: **natri benzoat** gắn glycin thành hippurat; **phenylbutyrat** → phenylacetat gắn glutamin thành phenylacetylglutamin; cả hai thải qua nước tiểu, "kéo" nitơ ra mà không cần chu trình ure.
- **Bổ sung arginin** (trừ thiếu arginase) để tái tạo ornitin; trường hợp nặng phải **lọc máu**.

### 8.4. Bệnh não gan

**Bệnh não gan** là rối loạn chức năng não do **suy gan** hoặc nối tắt cửa – chủ, NH~3~ đóng vai trò trung tâm.

- **Nguồn NH~3~**: vi khuẩn ruột phân hủy protein, ure (nhờ urease) và tế bào ruột thủy phân glutamin. Bình thường NH~3~ theo tĩnh mạch cửa về gan và bị chuyển thành ure; khi gan xơ, NH~3~ **vào thẳng tuần hoàn chung**, lên não.
- **Yếu tố khởi phát** hay gặp: **xuất huyết tiêu hóa** (máu trong ruột = một "bữa protein" lớn), **táo bón**, nhiễm trùng, **hạ K^+^** và dùng lợi tiểu, thuốc an thần, ăn quá nhiều đạm.
- **Điều trị** dựa trên hóa sinh: **lactulose** (đường đôi không hấp thu) bị vi khuẩn lên men thành acid → môi trường đại tràng **acid** → NH~3~ nhận H^+^ thành **NH~4~^+^ không thấm** qua niêm mạc, bị giữ lại và đào thải theo phân (lactulose còn nhuận tràng); **rifaximin** (kháng sinh ít hấp thu) giảm vi khuẩn sinh NH~3~; **L-ornitin L-aspartat** cung cấp cơ chất cho chu trình ure và tổng hợp glutamin.

> [!ung-dung] Xét nghiệm amoniac máu
> - Lấy **máu tĩnh mạch** (ống chống đông EDTA hoặc heparin), **đặt ngay trong đá**, gửi phân tích trong vòng khoảng 30 phút. Để lâu ở nhiệt độ phòng, hồng cầu và sự thủy phân glutamin làm NH~3~ **tăng giả**. Bệnh nhân không nên nắm tay chặt, garo lâu (cơ co tạo NH~3~).
> - Khoảng tham chiếu ở người lớn thường khoảng **dưới 35–50 µmol/L** tùy phương pháp (tham khảo, mỗi phòng xét nghiệm có khoảng riêng); trẻ sơ sinh cao hơn.
> - Ở bệnh não gan, mức NH~3~ **không tỷ lệ chặt** với độ nặng triệu chứng; chẩn đoán chủ yếu dựa vào lâm sàng. Nhưng một kết quả NH~3~ **bình thường** ở người nghi bệnh não gan gợi ý nên tìm nguyên nhân khác.

> [!yhct] Thuốc YHCT có thể gây tổn thương gan: theo dõi bằng ALT
> - **Hà thủ ô đỏ** (*Reynoutria multiflora*, tên cũ *Polygonum multiflorum*): đã có nhiều **báo cáo ca bệnh và loạt ca bệnh** ở người (Trung Quốc, Hàn Quốc, châu Âu…) về **viêm gan do thuốc**, chủ yếu kiểu **tổn thương tế bào gan** (ALT tăng rõ, có thể vàng da), cả với dạng chế. Cơ chế chưa sáng tỏ, được cho là phụ thuộc cơ địa; một số cơ quan quản lý dược (Anh, Trung Quốc) đã ra cảnh báo.
> - **Thổ tam thất** (*Gynura japonica*, khác với Tam thất *Panax notoginseng*): chứa **alkaloid pyrrolizidin**, gây **hội chứng tắc xoang gan** (gan to, cổ trướng, vàng da) — bằng chứng từ nhiều ca bệnh ở người và cơ chế đã rõ. Nguy cơ cao khi nhầm lẫn hai vị thuốc do trùng tên "tam thất".
> - **Ý nghĩa thực hành**: tổn thương gan do thuốc chỉ phát hiện được nhờ **ALT** (transaminase học ở mục 2.1). Khi người bệnh dùng các vị này dài ngày, hoặc có bệnh gan sẵn, nên hỏi tiền sử, theo dõi **ALT** định kỳ và ngừng thuốc khi ALT tăng. Đây là **tác dụng phụ đã ghi nhận ở người**, tách biệt với công năng "bổ can thận" theo quan niệm YHCT.

## Tóm tắt

| Chủ đề | Điều cốt lõi |
|---|---|
| Tiêu hóa protein | Pepsin (dạ dày, hoạt hóa bởi HCl); trypsin (hoạt hóa bởi enterokinase, rồi hoạt hóa các proenzym khác), chymotrypsin, elastase, carboxypeptidase (tụy); aminopeptidase (ruột). Hấp thu: vận chuyển tích cực |
| Protein nội sinh | Đổi mới 1–2%/ngày; ubiquitin (76 aa) + ATP; E1 → E2 → E3 → protease phụ thuộc ATP (proteasom) |
| Trao đổi amin | Transaminase (ALT, AST), coenzym **PLP (B~6~)**, ty thể + bào tương, thuận nghịch, chất nhận chung **α-cetoglutarat → glutamat** |
| Khử amin oxy hóa | L-acid amin oxidase (FMN, yếu, tạo H~2~O~2~); **GLDH** (ty thể, NAD^+^/NADP^+^, rất mạnh, thuận nghịch) |
| Trao đổi – khử amin | Acid amin → (transaminase) glutamat → (GLDH) NH~4~^+^; α-cetoglutarat là con thoi |
| Vận chuyển NH~3~ | Glutamin synthetase (Glu + NH~4~^+^ + ATP → Gln); glutaminase ở gan, thận; thận thải NH~4~^+^ giúp cân bằng acid – base |
| Chu trình ure | Gan; ① CPS I (ty thể, 2 ATP, **then chốt**, cần **NAG**) ② OTC (ty thể) ③ ASS (bào tương, ATP → AMP + PPi) ④ ASL → fumarat ⑤ arginase (Mn^2+^) → ure + ornitin. 3 ATP = 4 liên kết giàu năng lượng. N từ NH~4~^+^ và Asp, C từ HCO~3~^−^ |
| Ure – Krebs | Fumarat → malat → OAA → (AST) Asp → vào chu trình ure |
| Xét nghiệm | Ure máu 3,5–7 mmol/L (sách) ; creatinin đánh giá lọc cầu thận; NH~3~ máu (lấy mẫu trong đá) |
| Khử carboxyl | Decarboxylase (PLP): Glu → GABA, His → histamin, Trp → serotonin, Tyr → dopamin; bất hoạt bằng MAO |
| Khung carbon | 7 sản phẩm; 14 aa sinh đường, 5 aa vừa đường vừa ceton (Phe, Tyr, Trp, Ile, Lys), Leu chỉ sinh ceton (theo sách) |
| Tổng hợp | 8 aa cần thiết (Val, Leu, Lys, Ile, Met, Phe, Trp, Thr), Arg, His bán cần thiết; NH~4~^+^ vào qua Glu, Gln; ức chế ngược enzym đầu tiên |
| Creatin | Gly + Arg + Met; CK: creatin phosphat dự trữ năng lượng cơ; creatinin hằng định theo khối cơ, thải qua thận |
| Glutathion | γ-Glu-Cys-Gly, 2 ATP; khử MetHb, khử H~2~O~2~ (GSH peroxidase); tái tạo nhờ NADPH (pentose phosphat); GSH/GSSG ≈ 500 |
| Bệnh lý acid amin | Di truyền, hiếm; thiếu enzym hoặc rối loạn vận chuyển → tăng aa máu, niệu. PKU (Phe hydroxylase), alkapton niệu (homogentisat oxidase), bạch tạng (tyrosinase), tăng NH~3~ (thiếu enzym chu trình ure, xơ gan) |
