---
title: Hóa sinh cơ
thoi-gian: 40 phút
muc-tieu:
- Mô tả được cấu trúc của cơ vân (sợi cơ, tơ cơ, đơn vị co cơ) và cấu tạo, vai trò của các protein cơ vân: myosin, actin, tropomyosin, troponin và các protein phụ.
- Trình bày được cơ chế trượt sợi, bốn bước của chu trình đầu S1 myosin trên actin, và sự điều hòa co cơ vân bằng Ca^2+^.
- Trình bày được các nguồn năng lượng cho co cơ vân theo thứ tự huy động: ATP tự do, creatin phosphat, ADP (adenylat kinase), đường phân yếm khí và ái khí, thoái hóa lipid và protein.
- So sánh được cơ chế co cơ trơn với cơ vân; nêu được vai trò của actin, myosin ở các tế bào không phải tế bào cơ.
- Vận dụng được để giải thích creatinin, CK, myoglobin niệu, tiêu cơ vân, co cứng tử thi, chuột rút.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Đơn vị co cơ (sarcomere) nằm giữa hai **đĩa Z**: **sợi dày = myosin**, **sợi mỏng = actin + tropomyosin + troponin**.
> 2. Khi co, các sợi **không ngắn lại** mà **trượt lên nhau**: **băng I và vùng H ngắn lại, băng A giữ nguyên**.
> 3. Chu trình đầu S1: **ATP gắn → S1 tách** khỏi actin → **thủy phân ATP → S1 "dựng lên"** → **tách Pi → cú đẩy** kéo actin về đĩa M → **tách ADP** → trở lại phức hợp **rigor**.
> 4. **Ca^2+^** từ lưới cơ tương gắn **troponin C** → tropomyosin dịch đi → lộ vị trí gắn trên actin. Cơ trơn **không có troponin**: Ca^2+^–**calmodulin** hoạt hóa **kinase chuỗi nhẹ myosin**.
> 5. Năng lượng: **ATP tự do (1–2 giây) → creatin phosphat + CK (đến ~7–8 giây) → đường phân yếm khí (lactat) → oxy hóa ái khí → lipid** (> 95% khi gắng sức kéo dài).

> [!ghi-nho] Đã học ở bài khác — xem lại, không viết lại
> - Troponin – tropomyosin "che/mở" vị trí gắn, co cứng tử thi, troponin tim: **Sinh học sh-06** (mục 3.3, có hình).
> - Co cơ dưới góc nhìn cơ học (công, lực, co đẳng trương – đẳng trường, nợ oxy): **Vật lý vl-03**.
> - Phosphocreatin là hợp chất phosphat giàu năng lượng: **hs-06**. Tổng hợp creatin từ Gly, Arg, Met và creatinin: **hs-09** mục 7.1.
> - Đường phân, lactat, chu trình Cori, bệnh ứ glycogen ở cơ (McArdle, Tarui): **hs-07**. Isoenzym CK (MM, MB, BB): **hs-05**. Myoglobin: **hs-03** mục 5.

## 1. Cấu trúc của cơ vân

Cơ thể có ba loại mô cơ: **cơ vân** (cơ xương), **cơ trơn** (không có vân) và **cơ tim**. Mô cơ chiếm khoảng **40% trọng lượng cơ thể**. Đặc tính riêng của cơ là **co và duỗi**, nhờ đó cơ tham gia vận động, tuần hoàn, hô hấp, bài tiết, giữ thăng bằng (Giáo trình tr. 318).

### 1.1. Từ bó cơ đến đơn vị co cơ

Cơ vân co theo **ý muốn**. Tổ chức của nó đi từ lớn đến nhỏ:

| Cấp | Đặc điểm (Giáo trình tr. 318) |
|---|---|
| **Bó cơ** | Đường kính 20–100 µm |
| **Sợi cơ** (tế bào cơ) | Tế bào **nhiều nhân, khổng lồ**, có thể dài bằng cả chiều dài cơ |
| **Tơ cơ** (myofibril) | Nằm trong bào tương sợi cơ, chạy dọc suốt sợi cơ |
| **Đơn vị co cơ** (sarcomere) | Đoạn lặp lại của tơ cơ, nằm giữa **hai đĩa Z**; dài **2,5–3 µm khi cơ giãn**, ngắn lại khi cơ co |

Dưới kính hiển vi điện tử, tơ cơ có các vùng sáng – tối xen kẽ, tạo nên "vân":

- **Băng A** (sẫm): chiều dài đúng bằng **sợi dày**. Phần sẫm nhất là nơi sợi dày và sợi mỏng **cài vào nhau**.
- **Băng I** (sáng): chỉ có **sợi mỏng**. **Đĩa Z** nằm ở giữa băng I.
- **Vùng H**: phần giữa băng A **chỉ có sợi dày** (sợi mỏng chưa vươn tới).
- **Đĩa M**: đường giữa băng A, nơi giữ các sợi dày.

Một đơn vị co cơ = **1 băng A + 2 nửa băng I**.

![Hình 1. Đơn vị co cơ khi cơ giãn và khi cơ co: sợi không ngắn lại, chỉ trượt lên nhau](don-vi-co-co.svg)

> [!bay] Băng nào ngắn lại khi co?
> - **Băng I** và **vùng H** ngắn lại; **băng A không đổi** (vì băng A = chiều dài sợi dày, mà sợi dày không co ngắn).
> - Mẹo: chữ **A** = "**A**nisotropic", cũng là "**A**lways (luôn) giữ nguyên". **H** và **I** là phần "khoảng trống" bị lấp lại.

### 1.2. Sợi dày — myosin

Sợi dày của cơ động vật có xương sống chỉ gồm **một loại protein là myosin** (Giáo trình tr. 319).

**Phân tử myosin** — rất lớn, khoảng **470 kDa**, gồm **6 chuỗi polypeptid**:

- **2 chuỗi nặng** (mỗi chuỗi 230 kDa). Đầu tận N của mỗi chuỗi cuộn thành một **đầu hình cầu** (khoảng 55 × 200 Å). Đầu tận C của hai chuỗi xoắn vào nhau thành **đuôi xoắn kép α** dài khoảng **1600 Å**. Vì vậy myosin có hình "**hai đầu cầu + một đuôi gậy**".
- **4 chuỗi nhẹ** (18 kDa và 20 kDa), gắn ở phần đầu.

**Cắt myosin bằng enzym** — cách người ta tìm ra vùng nào làm việc gì:

| Enzym | Sản phẩm | Đặc điểm |
|---|---|---|
| **Trypsin** | **LMM** (meromyosin nhẹ) | Đoạn đuôi hình gậy, xoắn kép α, dài 850 Å |
| | **HMM** (meromyosin nặng) | Đoạn gậy ngắn + **hai đầu hình cầu** |
| **Papain** cắt tiếp HMM | **2 × HMM S-1** (S1) | **Đầu hình cầu**: có **vị trí ATPase** và **vị trí gắn actin** |
| | **1 × HMM S-2** (S2) | Đoạn cổ hình gậy |

> [!bay]
> Hai "vũ khí" của myosin đều nằm ở **đầu S1**: hoạt tính **ATPase** và chỗ **gắn actin**. Đuôi (LMM) không có hoạt tính enzym; nó chỉ giúp các phân tử myosin **xếp lại thành sợi dày**.

**Từ phân tử thành sợi dày.** Ở lực ion thấp, myosin tồn tại dạng phân tử đơn. Ở điều kiện sinh lý, vài trăm phân tử myosin tự kết hợp, **đuôi xếp so le** vào nhau. Các phân tử ở hai nửa sợi quay đuôi vào giữa, nên sợi dày có **hai đầu cực** đều là các đầu myosin, còn **giữa sợi thì trơn** (không có đầu).

**Chức năng.** Chuỗi nặng có hoạt tính **ATPase**: thủy phân ATP → ADP + Pi để lấy năng lượng cho co cơ. Vì thế co cơ là sự **chuyển hóa năng lượng hóa học (ATP) thành năng lượng cơ học**. **Chuỗi nhẹ**, khi được **phosphoryl hóa**, điều chỉnh hoạt tính ATPase của chuỗi nặng.

### 1.3. Sợi mỏng — actin, tropomyosin, troponin

#### a) Actin

- Có ở mọi tế bào nhân thật. Ở lực ion thấp, actin là các **phân tử đơn hình cầu (G-actin)**, có hai thùy, mỗi phân tử gắn **1 ATP**.
- Ở điều kiện sinh lý, G-actin **trùng hợp** thành sợi **F-actin**. Khi trùng hợp, ATP bị **thủy phân thành ADP + Pi**, nhưng **ADP vẫn gắn lại** trên mỗi đơn vị F-actin.
- F-actin là **lõi của sợi mỏng**. Mỗi đơn vị actin có thể gắn **một đầu S1** riêng.
- F-actin là phân tử **có cực** (hai đầu khác nhau). Các sợi mỏng xuất phát từ **hai phía của đĩa Z**, quay hai chiều ngược nhau.
- Có ít nhất **6 dạng phân tử (isoform)** actin, rất giống nhau: actin cơ vân khác actin cơ tim, cơ trơn và actin của tế bào không phải cơ.
- Chức năng: tham gia **di chuyển của nhiều loại tế bào**, kể cả sự co cơ (Giáo trình tr. 319–320).

> [!bay] Số liệu in sai trong giáo trình
> Giáo trình in khối lượng phân tử actin là **"4 kDa"**. Một phân tử G-actin thực ra khoảng **42 kDa** (khoảng 375 acid amin/amino acid). Nếu đề hỏi, chọn đáp án gần 42 kDa; nếu chỉ có 4 kDa thì đó là số theo sách.

#### b) Tropomyosin

- **Cấu trúc**: 2 chuỗi polypeptid xoắn α **song song** với nhau, tạo phân tử **hình roi dài 400 Å**. Các phân tử nối **đầu – đuôi** thành sợi dài nằm trong **rãnh xoắn của F-actin**. Mỗi phân tử tropomyosin trải dọc **7 đơn vị actin**.
- **Chức năng**: **điều chỉnh tương tác actin – myosin**. Ở cơ nghỉ, nó nằm đúng chỗ làm cản trở đầu S1 gắn vào actin.

> [!bay]
> Giáo trình ghi mỗi chuỗi tropomyosin **66 kDa**. Số liệu hiện nay: mỗi chuỗi khoảng **33–35 kDa**; **cả phân tử** (2 chuỗi) khoảng 66–70 kDa. Có thể sách đã ghi khối lượng của cả phân tử.

#### c) Troponin

Phức hợp **76 kDa** gồm **3 chuỗi** (Giáo trình tr. 320). **Mỗi tropomyosin gắn một phức hợp troponin.**

| Tiểu đơn vị | Khối lượng | Gắn với | Vai trò |
|---|---|---|---|
| **Troponin T** (TnT) | 37 kDa | **Tropomyosin** | "Neo" phức hợp vào tropomyosin |
| **Troponin I** (TnI) | 23 kDa | **Actin** | **Ức chế** (Inhibitory) gắn actin – myosin khi cơ nghỉ |
| **Troponin C** (TnC) | 18 kDa | **Ca^2+^** | "Công tắc" nhận tín hiệu Ca^2+^ |

Mẹo nhớ: **T** = **T**ropomyosin, **I** = **I**nhibitory (gắn actin), **C** = **C**alci.

> [!bay]
> Ca^2+^ gắn vào **troponin C**, không gắn vào TnI, TnT, tropomyosin hay myosin. Thứ "che" vị trí gắn là **tropomyosin** (được TnI giữ ở vị trí ức chế). Xem lại "troponin = công tắc, tropomyosin = tấm che" ở sh-06.

> [!ung-dung] Troponin tim — vì sao đặc hiệu?
> **TnI và TnT** của cơ tim (cTnI, cTnT) có trình tự acid amin **khác** dạng của cơ vân. Vì vậy xét nghiệm miễn dịch đo được riêng troponin tim. Khi tế bào cơ tim hoại tử, troponin tim vào máu: đây là xét nghiệm chính chẩn đoán **nhồi máu cơ tim** hiện nay (xem sh-06, hs-05). TnC của tim và cơ chậm thì giống nhau, nên **không** dùng TnC làm xét nghiệm.

### 1.4. Các protein khác của cơ

Ngoài myosin và actin, cơ còn các protein phụ **kiểm soát sự lắp ráp và chiều dài sợi** (Giáo trình tr. 320–321). Đĩa Z là nơi **neo hai sợi mỏng quay ngược chiều nhau**.

| Protein | Vị trí, đặc điểm | Vai trò |
|---|---|---|
| **α-actinin** | Gắn đầu tận của F-actin ở trong đĩa Z | Neo sợi mỏng vào đĩa Z |
| **Desmin, vimentin** | Bên cạnh đĩa Z | Giữ các tơ cơ cạnh nhau nằm sát, thẳng hàng |
| **Titin** (giáo trình in "tinin") | **Lớn nhất đã biết**: khoảng 33 000 acid amin, khoảng 3 600 kDa; kéo dài từ **sợi dày đến đĩa Z** | Như "lò xo" giữ sợi dày ở giữa đơn vị co cơ; **kiểm soát chiều dài sợi dày** |
| **Nebulin** | Khoảng 7 000 acid amin, khoảng 800 kDa; chạy dọc **80% chiều dài sợi actin**, gắn vào đĩa Z | **Kiểm soát chiều dài sợi actin** |
| **C-protein, M-protein** | Ở sợi dày (M-protein ở đĩa M) | Tham gia **lắp ráp sợi dày** |
| **Myoglobin** | 1 chuỗi **153 acid amin** + hem | **Dự trữ và vận chuyển O~2~** tới ty thể của tế bào cơ; gắn O~2~ được ở áp lực O~2~ thấp |

> [!vi-du] Vì sao myoglobin hợp với cơ?
> Myoglobin có ái lực với O~2~ **cao hơn** hemoglobin (đường cong hyperbol, hs-03 mục 5). Hb nhả O~2~ ở mao mạch cơ, Mb "đón" lấy rồi chuyển vào ty thể. Cơ hoạt động **ái khí kéo dài** (cơ tim, cơ giữ tư thế, cơ chân chim bay xa) giàu Mb nên **màu đỏ**. Đây cũng là protein thoát ra nhiều khi cơ bị hủy: gây **myoglobin niệu** (mục 6).

## 2. Sự co cơ vân

### 2.1. Thuyết trượt sợi

Khi cơ co, **chiều dài đơn vị co cơ giảm**. Nhưng kính hiển vi điện tử cho thấy **chỉ băng I và vùng H hẹp lại**, còn **chiều dài sợi dày và sợi mỏng không đổi** (Giáo trình tr. 321).

Giải thích: các **đầu S1 của myosin kéo sợi actin từ hai phía về đĩa M**. Sợi dày và sợi mỏng **trượt lên nhau**, cài sâu vào nhau hơn. Hai đĩa Z bị kéo lại gần nhau. Cơ có thể ngắn lại khoảng **1/3** so với lúc nghỉ.

### 2.2. Cơ chế phân tử — chu trình bốn bước của đầu S1

**Khởi động.** Xung thần kinh đến **điểm nối thần kinh – cơ** → **Ca^2+^ được giải phóng** vào vùng đơn vị co cơ → Ca^2+^ gắn **troponin C** → thay đổi hình dạng của sợi actin (qua troponin – tropomyosin) → **myosin gắn được vào actin**, tạo **phức hợp actin–myosin** (Giáo trình tr. 321–322).

Co cơ là sự **ghép cặp** giữa **thủy phân ATP** và **sự trượt của đầu myosin** dọc sợi actin. Chu trình bắt đầu từ phức hợp actin–myosin gọi là **phức hợp rigor**:

![Hình 2. Chu trình bốn bước của đầu S1 myosin trên sợi actin](chu-trinh-cau-noi.svg)

| Bước | Điều xảy ra | Ý nghĩa |
|---|---|---|
| **1. ATP gắn** | ATP gắn vào vị trí ATP còn trống ở đầu S1 → **mở khe** ở vị trí gắn actin | **Đầu S1 tách khỏi actin** |
| **2. Thủy phân ATP** | **ATPase** ở đầu S1 thủy phân ATP → ADP + Pi (cả hai vẫn gắn ở đầu S1). Năng lượng "**dựng**" đầu myosin lên: **trạng thái năng lượng cao**, đầu S1 gần **vuông góc** với actin, chuyển về phía đĩa Z | Đầu S1 bám vào **một tiểu đơn vị actin mới** |
| **3. Tách Pi** | Pi rời đầu S1 → **đóng khe** → S1 **gắn chặt** actin → trạng thái chuyển tiếp trung gian → lập tức xảy ra "**một hoạt động có hiệu quả**" (cú đẩy) | Đầu S1 đi **một bước khoảng 60 Å** dọc actin **về phía đĩa Z** = **kéo sợi actin về phía đĩa M** |
| **4. Tách ADP** | ADP được giải phóng | Trở lại **phức hợp rigor**, nhưng đã bước thêm một bước; vị trí ATP lại trống |

- Mỗi sợi dày có khoảng **500 đầu S1**. Mỗi đầu bước **khoảng 5 lần/giây**, các đầu **không đồng thời** (luôn có đầu đang bám), nên sợi mỏng không tuột ngược lại.
- **Chuỗi nhẹ myosin** làm **tăng tốc độ co**: bỏ chuỗi nhẹ đi thì tốc độ trượt **giảm 10 lần**. Chuỗi nhẹ hoạt động như **cánh tay đòn**, khuếch đại sự đổi hình dạng của đầu S1 thành một bước dài (Giáo trình tr. 322).

> [!bay] ATP cần cho cả co lẫn duỗi
> - Năng lượng của **cú đẩy** đến từ thủy phân ATP (bước 2), được "giải phóng" khi **tách Pi** (bước 3).
> - Nhưng **tách đầu S1 khỏi actin** lại cần **ATP gắn vào** (bước 1), không cần thủy phân. Thiếu ATP, đầu myosin kẹt ở trạng thái rigor: cơ **cứng đờ**, không duỗi được.
> - Đầu S1 di chuyển **về phía đĩa Z** (đầu "+" của actin), nhờ đó **kéo actin về đĩa M**. Hai cách nói này là một, đề thi hay đảo để gây nhiễu.

> [!vi-du] Co cứng tử thi (rigor mortis)
> Tên "phức hợp rigor" lấy từ hiện tượng này. Sau khi chết, tế bào không còn tạo ATP; Ca^2+^ rò ra khỏi lưới cơ tương nên đầu myosin vẫn bám được actin, nhưng **không có ATP để tách ra**. Cơ cứng lại, thường xuất hiện **vài giờ** sau chết, rồi mất dần sau **1–2 ngày** khi protein cơ bị phân hủy (thời gian thay đổi nhiều theo nhiệt độ, thể trạng). Pháp y dùng dấu hiệu này để **ước tính thời gian tử vong**.

### 2.3. Điều hòa co cơ vân bằng Ca^2+^

Phân tử điều hòa chủ yếu của co cơ vân là **ion Ca^2+^** (Giáo trình tr. 325).

| Trạng thái | Diễn biến | [Ca^2+^] bào tương |
|---|---|---|
| **Cơ nghỉ** | Phức hợp troponin–tropomyosin nằm dọc rãnh actin, đầu S1 **không gắn được** actin. Màng **lưới cơ tương** (sarcoplasmic reticulum) không thấm Ca^2+^ và có **Ca^2+^-ATPase** bơm Ca^2+^ vào lưới. Trong lưới, Ca^2+^ được giữ nhờ **calsequestrin** | **dưới 10^−7^ M** (trong lưới cơ tương: **trên 10^−3^ M**) |
| **Cơ co** | Xung thần kinh làm màng lưới cơ tương **tăng thấm Ca^2+^ trong vài phần nghìn giây**; Ca^2+^ khuếch tán nhanh qua **kênh Ca^2+^** ra bào tương → đủ để đổi hình dạng troponin–tropomyosin → **co cơ bắt đầu** | **khoảng 10^−5^ M** |
| **Cơ giãn trở lại** | Hết kích thích → màng lưới cơ tương lại không thấm; Ca^2+^ được **bơm ngược** vào lưới → Ca^2+^ tách khỏi TnC → TnI và tropomyosin trở lại vị trí che → ATP gắn myosin nhưng **ATPase bị ức chế**, phức hợp actin–myosin **phân ly** → cơ nghỉ | trở về **dưới 10^−7^ M** |

**Calsequestrin**: protein **55 kDa**, rất giàu acid amin acid (**37% là Asp và Glu**), mỗi phân tử gắn **trên 40 ion Ca^2+^**. Vì sao nhiều Asp, Glu? Nhóm –COO^−^ của chúng là chỗ "đậu" cho Ca^2+^ mang điện dương.

> [!bay]
> - Bơm Ca^2+^ **về lưới cơ tương** (để **giãn** cơ) là quá trình **tiêu tốn ATP** (Ca^2+^-ATPase). Đây là lý do thứ hai khiến **giãn cơ cũng cần ATP**.
> - Nồng độ Ca^2+^ chênh nhau **khoảng 100 lần** giữa nghỉ (10^−7^) và co (10^−5^), và **khoảng 10 000 lần** giữa bào tương nghỉ và trong lưới cơ tương (10^−3^).
> - Giáo trình viết ở cơ nghỉ "troponin gắn dọc theo rãnh của actin". Chính xác hơn: **tropomyosin** nằm trong rãnh, troponin gắn trên tropomyosin; cả phức hợp cùng che vị trí gắn.

> [!ung-dung] Sốt cao ác tính — khi "van" Ca^2+^ bị kẹt mở (bổ sung)
> Kênh giải phóng Ca^2+^ của lưới cơ tương cơ vân là **thụ thể ryanodin (RyR1)**. Người mang đột biến RyR1 khi gây mê bằng **thuốc mê bay hơi** (halothan, sevofluran…) hoặc **succinylcholin** thì Ca^2+^ tràn ra bào tương không kiểm soát. Cơ **co cứng** liên tục, đốt ATP ồ ạt: **sốt rất cao, tăng CO~2~, toan lactic, tăng K^+^ máu, tiêu cơ vân**. Thuốc giải là **dantrolen**, chặn RyR1. Đây là ví dụ rõ nhất cho thấy Ca^2+^ bào tương quyết định co cơ và co cơ tiêu tốn ATP như thế nào.

## 3. Nguồn năng lượng cho co cơ vân

ATP là nguồn năng lượng **duy nhất được dùng trực tiếp** cho co cơ. Mọi nguồn khác chỉ có nhiệm vụ **tái tạo ATP**, nhanh hay chậm khác nhau (Giáo trình tr. 323–324).

![Hình 3. Các nguồn tái tạo ATP cho cơ theo thời gian gắng sức](nguon-nang-luong.svg)

### 3.1. ATP tự do

Dưới tác dụng của **ATPase** (đầu S1 myosin), liên kết **pyrophosphat tận cùng** của ATP bị cắt, giải phóng năng lượng:

=> ATP + H~2~O → ADP + Pi + năng lượng   (ATPase)

Nhưng ATP tự do trong tế bào cơ rất ít: **khoảng 5 µmol/g cơ tươi**, chỉ đủ cho **2–3 lần co**, tức **1–2 giây** gắng sức nặng.

### 3.2. Creatin phosphat và creatin kinase (CK)

**Creatin phosphat** (phosphocreatin) là "kho ATP dự phòng" thứ hai. Enzym **creatin kinase (CK)** chuyển ngay nhóm phosphat của nó cho ADP:

=> Creatin phosphat + ADP → Creatin + ATP   (creatin kinase)

- Hàm lượng: **15–20 µmol/g cơ tươi**, gấp **3–4 lần** ATP tự do.
- Đủ cho thêm khoảng **6–7 giây**. Tổng ATP + creatin phosphat: **khoảng 7–8 giây** hoạt động.
- **Vì sao nhanh?** Chỉ **một phản ứng**, một enzym, nằm ngay cạnh sợi cơ. Liên kết phosphat của creatin phosphat **giàu năng lượng hơn** ATP (−10,3 so với −7,3 kcal/mol, hs-06), nên phản ứng nghiêng về phía tạo ATP khi ADP tăng.
- Phản ứng **thuận nghịch**: khi **cơ nghỉ**, ATP dư (từ oxy hóa) lại nạp phosphat cho creatin để tái tạo kho creatin phosphat (hs-09 mục 7.1).

> [!bay]
> - Giáo trình viết phản ứng CK **một chiều** (CP + ADP → creatin + ATP) vì đang nói về lúc cơ co. Thực chất phản ứng **thuận nghịch**.
> - **Creatin phosphat** (dự trữ năng lượng) khác **creatinin** (sản phẩm thải, đánh giá thận). Đề hay cho hai chữ này đứng cạnh nhau.
> - CK cần **Mg^2+^** (dạng Mg–ADP/Mg–ATP). Lấy máu vào ống **EDTA** làm CK **thấp giả** (hs-05).

### 3.3. ADP và adenylat kinase

Lúc co mạnh, ADP tích tụ nhiều nhất. Hai phân tử ADP có thể tạo thêm một ATP nhờ **adenylat kinase** (myokinase):

=> ADP + ADP → ATP + AMP   (adenylat kinase)

Giáo trình nhận xét cách tạo ATP thứ hai này **ít thuận lợi**, vì làm giảm lượng ADP trong cơ (Giáo trình tr. 323–324).

> [!vi-du] AMP — tín hiệu "báo động năng lượng"
> AMP sinh ra từ phản ứng này là một **tín hiệu** rất nhạy: AMP **hoạt hóa phosphofructokinase-1 (PFK-1)** để đẩy nhanh đường phân và hoạt hóa **glycogen phosphorylase** của cơ (hs-07), đồng thời hoạt hóa **AMPK** (hs-06). Khi AMP nhiều, một phần bị khử amin thành IMP và NH~3~; tổng lượng nucleotid adenin của cơ giảm, cần thời gian để hồi phục.

### 3.4. Đường phân yếm khí và ái khí

ATP và creatin phosphat chỉ đủ cho **7–8 giây**. Muốn hoạt động lâu hơn, cơ dùng glucose (từ máu) và **glycogen của chính nó** theo **đường phân** (giáo trình gọi là con đường *hexose diphosphat*). Đường yếm khí và ái khí **giống nhau đến pyruvat**, chỉ khác số phận của pyruvat:

| | **Đường phân yếm khí** | **Oxy hóa ái khí** |
|---|---|---|
| Điều kiện | Thiếu O~2~ (gắng sức mạnh, đột ngột) | Đủ O~2~ |
| Sản phẩm cuối | **Lactat** (pyruvat nhận H từ NADH, enzym **LDH**) | **CO~2~ + H~2~O** (pyruvat → acetyl-CoA → chu trình Krebs → chuỗi hô hấp) |
| ATP/glucose (theo giáo trình) | **2** | **36 hoặc 38** |
| Ưu điểm | **Nhanh**, không cần O~2~ | **Hiệu quả** gấp nhiều lần |
| Nhược điểm | Ít ATP; lactat và H^+^ tích tụ | Phụ thuộc cung cấp O~2~, chậm khởi động hơn |

Theo giáo trình, thoái hóa glucose theo cả hai con đường **cũng chỉ đủ cho cơ hoạt động trong vài phút**.

**Vì sao cơ vẫn phải dùng đường yếm khí dù "lỗ"?** Lúc khởi động gắng sức, tim phổi chưa kịp tăng cung cấp O~2~ (ví dụ chạy nước rút ở vl-03). Đường phân yếm khí tái tạo **NAD^+^** (khi khử pyruvat thành lactat) nên đường phân chạy liên tục được, sinh ATP **nhanh** mà không cần O~2~.

> [!vi-du] Glycogen cơ "lời" hơn glucose máu một chút
> Nếu xuất phát từ **glycogen**, phosphorylase cắt ra **glucose-1-phosphat** mà không tốn ATP (không qua bước hexokinase). Vì vậy mỗi gốc glucose từ glycogen cho **3 ATP** khi đi đến lactat, thay vì 2 ATP từ glucose tự do (hs-07).

**Lactat đi đâu?** Lactat theo máu về **gan**, được **tân tạo thành glucose**, glucose lại theo máu trở về cơ: đó là **chu trình Cori** (hs-07 mục 2.3). Cơ "chuyển gánh nặng" cho gan; mỗi vòng cơ thể tiêu hao thêm khoảng 4 ATP. Một phần lactat còn được **cơ tim** và **sợi cơ ái khí** oxy hóa trực tiếp làm nhiên liệu.

> [!cap-nhat] Số ATP và vai trò của lactat
> - Giáo trình (2008) ghi 1 glucose oxy hóa hoàn toàn cho **36 hoặc 38 ATP**. Hiện nay, tính theo tỉ lệ P/O thực đo (khoảng 2,5 cho NADH, 1,5 cho FADH~2~), con số được chấp nhận là **khoảng 30–32 ATP**. Đi thi trả lời theo giáo trình.
> - Quan niệm cũ "acid lactic gây **đau cơ âm ỉ 1–2 ngày sau tập**" không còn được chấp nhận: lactat được thanh thải khỏi máu trong vòng khoảng một giờ sau gắng sức. Đau cơ khởi phát muộn chủ yếu do **tổn thương vi thể của sợi cơ và phản ứng viêm**, nhất là sau các động tác co cơ kéo dài (đi xuống dốc, hạ tạ). Mỏi cơ cấp khi gắng sức mạnh là do nhiều yếu tố (H^+^, Pi tích tụ, rối loạn giải phóng Ca^2+^), không chỉ do lactat.

### 3.5. Thoái hóa lipid và protein

Gắng sức **kéo dài** thì cơ phải dùng **lipid** và (ít hơn) **protein** (acid amin). Nguồn này cung cấp **trên 95%** năng lượng co cơ khi hoạt động kéo dài (Giáo trình tr. 324).

**Bảng giá trị năng lượng** (theo Bảng 20.1 của giáo trình):

| Chất | Khối lượng phân tử | ΔG°' (kcal/mol) | Năng lượng (kcal/g) |
|---|---|---|---|
| Glucose | 180 | −686 | **3,81** |
| Lactat | 90 | −326 | 3,62 |
| Palmitat | 256 | −2380 | **9,30** |
| Tripalmitin | 809 | −7510 | 9,30 |
| Glycin | 75 | −234 | 3,12 |

Glucid và protein cho **3–4 kcal/g**; lipid cho **khoảng 9,3 kcal/g**, **gấp gần 3 lần**.

**Vì sao lipid "đậm" năng lượng hơn?** Carbon của lipid **ở trạng thái khử hơn** (oxy hóa trung bình thấp hơn):

- Glucid: carbon đã mang sẵn oxy: =CH–OH, –CH=O, –CH~2~–OH.
- Lipid: phần lớn là –CH~2~– chưa có oxy.

Carbon càng "chưa bị oxy hóa" thì khi thoái hóa càng tách ra được nhiều **đương lượng khử** (H^+^ + e^−^, dưới dạng NADH, FADH~2~). Từ lipid tách ra **gần gấp 3 lần** so với glucid hoặc protein. Các đương lượng khử này đi vào **chuỗi hô hấp ở ty thể** để tổng hợp ATP (hs-06).

> [!bay]
> - Oxy hóa lipid **bắt buộc cần O~2~** (β-oxy hóa sinh NADH, FADH~2~ phải qua chuỗi hô hấp). Cơ **không** dùng acid béo để tạo ATP yếm khí được; do đó gắng sức càng nặng (thiếu O~2~) thì cơ càng dựa vào glucid.
> - Thứ tự huy động theo thời gian: **ATP → creatin phosphat → glycogen/glucose (yếm khí rồi ái khí) → lipid**. Nhưng **công suất** (lượng ATP/giây) thì giảm dần theo chiều ngược lại: nguồn nhanh nhất thì ít nhất.

> [!vi-du] Hai kiểu sợi cơ (bổ sung)
> - **Sợi chậm (typ I, "cơ đỏ")**: nhiều ty thể, nhiều **myoglobin**, mao mạch dày; dùng chủ yếu **oxy hóa ái khí** (acid béo); co chậm nhưng **bền**. Nhiều ở cơ giữ tư thế, ở vận động viên sức bền.
> - **Sợi nhanh (typ II, "cơ trắng")**: nhiều glycogen, giàu enzym **đường phân**; co **nhanh, mạnh** nhưng **mau mỏi**. Nhiều ở vận động viên chạy nước rút, cử tạ.

## 4. Cơ tim và cơ trơn

### 4.1. Cơ tim

**Cấu trúc tương tự cơ vân**, nhưng thích nghi với hoạt động **bơm liên tục** suốt đời. Hai điểm khác chính (Giáo trình tr. 325):

- **Chuyển hóa**: cơ tim **phụ thuộc chuyển hóa ái khí nhiều hơn** cơ vân (rất nhiều ty thể, myoglobin). Vì thế thiếu máu cơ tim (thiếu O~2~) gây tổn thương rất nhanh.
- **Khởi động co**: do **chính cơ tim** (tự động), không phải do thần kinh bên ngoài; thần kinh chỉ điều chỉnh đáp ứng.

### 4.2. Cơ trơn — cấu trúc và myosin

Cơ trơn ở thành ruột, tử cung, mạch máu lớn… co **chậm, kéo dài**, **không theo ý muốn**. Tế bào **hình thoi nhỏ, một nhân**. Sợi dày và sợi mỏng xếp **gần theo chiều dài** tế bào nhưng **không tạo thành tơ cơ**, nên **không có vân**.

**Myosin cơ trơn khác myosin cơ vân ở 3 điểm** (Giáo trình tr. 325):

1. Hoạt độ **ATPase tối đa chỉ khoảng 10%** của myosin cơ vân.
2. Chỉ tương tác với actin khi một **gốc Ser** đặc biệt trên **chuỗi nhẹ** được **phosphoryl hóa**.
3. Sợi dày có **ít liên kết ngang** hơn.

### 4.3. Co cơ trơn được khởi phát bởi Ca^2+^ — nhưng qua calmodulin

Sợi mỏng cơ trơn có **actin và tropomyosin nhưng không có troponin** (Giáo trình tr. 326). Ca^2+^ vẫn là tín hiệu khởi phát, nhưng đi theo đường khác:

=> Ca^2+^ ↑ (khoảng 10^−5^ M) → Ca^2+^–calmodulin → hoạt hóa kinase chuỗi nhẹ myosin (MLCK)

=> MLCK phosphoryl hóa chuỗi nhẹ myosin → myosin gắn actin → co

=> Ca^2+^ ↓ (khoảng 10^−7^ M, nhờ Ca^2+^-ATPase màng) → MLCK bất hoạt; phosphatase khử phosphoryl chuỗi nhẹ → giãn

| | **Cơ vân** | **Cơ trơn** |
|---|---|---|
| Protein nhận Ca^2+^ | **Troponin C** (trên sợi mỏng) | **Calmodulin** (trong bào tương) |
| Điều hòa ở sợi nào | Sợi **mỏng** (actin) | Sợi **dày** (myosin, qua chuỗi nhẹ) |
| Cách "bật" | Ca^2+^ làm **tropomyosin dịch đi** | Ca^2+^ → MLCK → **phosphoryl hóa chuỗi nhẹ** |
| Nguồn Ca^2+^ chính | Lưới cơ tương | Phụ thuộc độ thấm màng bào tương với Ca^2+^ (và một phần lưới nội bào) |
| Tốc độ | Nhanh | **Chậm hơn rất nhiều** |
| Tiêu thụ ATP | Cao | **Thấp**; giữ trương lực lâu dài rất "tiết kiệm" |

- **Ca^2+^ là chất truyền tin thứ hai** (như cAMP); **calmodulin** là chất **nhận tín hiệu** Ca^2+^ trong tế bào.
- TnC và calmodulin **giống nhau** về cấu trúc và chức năng; người ta cho rằng **TnC là một biến thể của calmodulin**, đã "tiến hóa" để cơ vân đáp ứng **nhanh** với Ca^2+^.

> [!bay]
> - "Cơ trơn không có troponin" **không** có nghĩa là cơ trơn không cần Ca^2+^. Ca^2+^ vẫn **khởi phát** co, chỉ là qua **calmodulin – MLCK**.
> - Cơ trơn **vẫn có tropomyosin**; thứ thiếu là **troponin**.

### 4.4. Cơ trơn chịu điều khiển của hormon

Ví dụ **epinephrin** (Giáo trình tr. 326):

=> Epinephrin + thụ thể màng → hoạt hóa adenylat cyclase → ATP → AMP vòng (cAMP) + PPi

=> cAMP gắn tiểu đơn vị điều hòa R của protein kinase dạng không hoạt động R~2~C~2~ → giải phóng tiểu đơn vị xúc tác C (hoạt động)

=> C phosphoryl hóa MLCK → MLCK gắn Ca^2+^–calmodulin yếu hẳn → chuỗi nhẹ ít được phosphoryl hóa → **cơ trơn giãn**

Ứng dụng của giáo trình: khi **hen** (phế quản co thắt quá mức), dùng **khí dung epinephrin** để **giãn phế quản**.

> [!cap-nhat] Thuốc giãn phế quản hiện nay
> Giáo trình nêu khí dung epinephrin để cắt cơn hen. Hiện nay thuốc cắt cơn chuẩn là **thuốc chủ vận chọn lọc β~2~** dạng hít (**salbutamol**…), cùng cơ chế tăng cAMP ở cơ trơn phế quản nhưng **ít tác dụng lên tim** hơn epinephrin (theo GINA). Epinephrin dùng trong **sốc phản vệ** (tiêm bắp). Đi thi trả lời theo giáo trình.

> [!bay] Epinephrin làm cơ trơn giãn hay co?
> **Tùy loại thụ thể.** Qua **β~2~** (phế quản, mạch máu cơ vân) → tăng cAMP → **giãn**. Qua **α~1~** (mạch máu da, tạng) → tăng Ca^2+^ bào tương → **co** (vì vậy epinephrin làm **tăng huyết áp**). Giáo trình chỉ mô tả nhánh cAMP.

> [!ung-dung] Thuốc tác động lên co cơ trơn
> - **Chẹn kênh calci** (amlodipin, nifedipin): giảm Ca^2+^ vào cơ trơn mạch máu → giãn mạch, hạ huyết áp (sh-06).
> - **Nitrat** (nitroglycerin): tạo NO → tăng cGMP → giảm Ca^2+^ và tăng khử phosphoryl chuỗi nhẹ myosin → giãn mạch, giảm cơn đau thắt ngực.
> - **Oxytocin**: tăng Ca^2+^ trong cơ trơn tử cung → gây co tử cung (thúc đẻ, cầm máu sau sinh).

## 5. Sự chuyển động của các tế bào khác

Actin và myosin không chỉ có ở cơ. **Actin** có ở rất nhiều nơi, chiếm **5–10% protein** của tế bào nhân thật. **Myosin** chỉ bằng khoảng **1/10 lượng actin**. Như vậy actin còn những vai trò **không cần myosin**: tham gia các hệ chuyển động khác và làm **bộ khung tế bào** (Giáo trình tr. 326–327).

### 5.1. Actin tạo vi sợi có khả năng co rút

- Ở tế bào không phải cơ, G-actin và F-actin ở **trạng thái cân bằng**, tạo **vi sợi**. G-actin trùng hợp cần **ATP**.
- Sự lắp – tháo vi sợi phụ thuộc các **protein gắn actin**. Ví dụ **profilin** (16 kDa) gắn G-actin tỉ lệ **1:1**, tạo **profilactin**, **ngăn trùng hợp**.
- **Ví dụ thụ tinh** (của sách): đầu tinh trùng chứa nhiều profilactin. Khi tiếp xúc vỏ trứng, **pH ở đầu tinh trùng tăng** → profilactin phân ly → G-actin được giải phóng → **trùng hợp bùng nổ** thành một bó F-actin trong **vài giây** → đầu tinh trùng **lồi ra**, xuyên qua vỏ trứng, mở đầu sự hòa màng.
- Lắp – tháo sợi actin cũng quan trọng cho: **chuyển động kiểu amip, thực bào**, thò ra – thụt vào của màng, chuyển động của **vi nhung mao**, vận chuyển trong **sợi trục thần kinh**.

### 5.2. Actomyosin cũng có khả năng co rút

- Myosin ở tế bào không phải cơ tạo **sợi dày ở dạng vi bản**, cũng co rút được.
- **Phân chia tế bào**: cuối kỳ phân bào, một **vòng thắt actomyosin** xuất hiện ở vùng xích đạo, **vuông góc với trục** tế bào. Vòng này co lại, thắt đôi tế bào.
- **Tiểu cầu** chứa actomyosin. Tiểu cầu co rút (giúp **co cục máu đông**) được khởi phát bằng **Ca^2+^–calmodulin hoạt hóa kinase chuỗi nhẹ myosin**, **giống cơ trơn**.

> [!ghi-nho]
> Chuyển động kiểu chân giả, lông – roi (vi ống, dynein) và colchicin đã học ở **sh-06**. Ở đây chỉ cần nhớ hai ý hóa sinh: **actin trùng hợp nhờ ATP, điều hòa bởi protein gắn actin (profilin)**; **actomyosin ngoài cơ điều hòa giống cơ trơn (Ca^2+^–calmodulin–MLCK)**.

## 6. Ứng dụng lâm sàng — xét nghiệm và bệnh lý cơ

Phần này tổng hợp các ứng dụng từ kiến thức trên. Số liệu xét nghiệm là **tham khảo, mỗi phòng xét nghiệm có khoảng riêng**.

### 6.1. Creatinin — "dấu vết" của khối cơ

Creatin và creatin phosphat tự **mất nước, đóng vòng** (không cần enzym) thành **creatinin** với tốc độ gần như hằng định mỗi ngày (khoảng 1–2% kho creatin). Vì kho creatin nằm chủ yếu ở cơ, lượng creatinin tạo ra **tỉ lệ với khối lượng cơ**. Creatinin thải qua **lọc cầu thận** (hs-09 mục 7.1).

| Xét nghiệm | Khoảng tham chiếu thường dùng (người lớn) | Ý nghĩa |
|---|---|---|
| **Creatinin huyết thanh** | Nam khoảng **62–120 µmol/L**; nữ khoảng **53–100 µmol/L** (nhiều phòng xét nghiệm Việt Nam; phương pháp enzym có khoảng thấp hơn) | Tăng khi **giảm mức lọc cầu thận**; dùng ước tính eGFR |

> [!bay] Creatinin cao chưa chắc do thận
> - Người **nhiều cơ** (vận động viên thể hình), người **uống thực phẩm bổ sung creatin**, ăn nhiều thịt chín có creatinin **cao hơn** mà thận bình thường.
> - Người **ít cơ** (già yếu, suy kiệt, cắt cụt chi) có creatinin **thấp**; giá trị "bình thường" ở họ có thể **che giấu suy thận**.
> - **Tiêu cơ vân** làm tăng creatinin vừa do tổn thương thận, vừa do giải phóng từ cơ.

### 6.2. CK — dấu ấn tổn thương cơ

CK là enzym của **bào tương** sợi cơ. Màng sợi cơ bị tổn thương thì CK thoát vào máu.

| Xét nghiệm | Khoảng tham chiếu thường dùng | Tăng khi |
|---|---|---|
| **CK toàn phần** | Nam khoảng **24–190 U/L**; nữ khoảng **24–170 U/L** | Tiêu cơ vân, chấn thương, tiêm bắp, gắng sức nặng, viêm cơ, loạn dưỡng cơ, thuốc (statin), co giật, nhồi máu cơ tim |
| **CK-MB** | ≤ 24 U/L | Ưu thế ở **cơ tim** (hs-05); nay chỉ còn vai trò phụ, troponin tim là xét nghiệm chính |

- **CK-MM** chiếm gần hết CK của cơ vân; tổn thương cơ vân làm tăng chủ yếu CK-MM.
- **Loạn dưỡng cơ Duchenne** (bổ sung): thiếu protein **dystrophin** (protein nối khung actin dưới màng sợi cơ với chất nền ngoài tế bào) → màng sợi cơ dễ rách khi co → CK tăng **rất cao** (hàng chục lần) ngay từ nhỏ, trước cả khi yếu cơ rõ.

### 6.3. Tiêu cơ vân và myoglobin niệu

**Tiêu cơ vân** là tình trạng sợi cơ vân bị hủy hàng loạt, giải phóng chất bên trong tế bào cơ vào máu.

- **Nguyên nhân**: chấn thương **dập cơ** (vùi lấp, tai nạn), **gắng sức quá mức** (nhất là trời nóng), say nóng, co giật, **sốt cao ác tính** (mục 2.3), thuốc (**statin**, đặc biệt khi dùng chung với thuốc ức chế CYP3A4 hoặc fibrat), rượu, **hạ K^+^ máu** nặng, bệnh cơ chuyển hóa (McArdle, hs-07).
- **Hóa sinh của hậu quả** — mỗi chất thoát ra gây một vấn đề:

| Chất thoát từ cơ | Hậu quả |
|---|---|
| **CK** | **Tăng rất cao**; tiêu chuẩn thường dùng là **trên 5 lần giới hạn trên** (hay gặp trên 1 000 U/L, có khi hàng chục nghìn). Đạt đỉnh sau **1–3 ngày**, giảm chậm |
| **Myoglobin** | Qua lọc cầu thận → **nước tiểu nâu đỏ** ("màu coca"). Que thử **"máu" dương tính nhưng soi không thấy hồng cầu** (hs-03). Mb gây **tắc ống thận** và độc với ống thận (nhất là khi nước tiểu acid) → **suy thận cấp** |
| **K^+^** (ion chủ yếu trong tế bào) | **Tăng K^+^ máu** → rối loạn nhịp tim, có thể tử vong |
| **Phosphat, acid hữu cơ** | Tăng phosphat máu, **toan chuyển hóa** |
| **Creatin** | Creatinin tăng nhanh |

- Myoglobin **tăng và giảm sớm** (thải nhanh), còn CK **tăng muộn hơn và kéo dài**. Vì vậy có lúc Mb niệu đã hết mà CK vẫn rất cao.
- **Xử trí chính**: **truyền dịch sớm, đủ** để duy trì lượng nước tiểu cao, rửa Mb khỏi ống thận; theo dõi K^+^, creatinin, CK.

> [!ung-dung] Tình huống điển hình
> Một nam thanh niên tập "squat" liên tục nhiều giờ trong ngày nóng. Hôm sau đau đùi dữ dội, cơ sưng, nước tiểu **màu nâu sẫm**. Que thử nước tiểu: **máu (+++)**, soi cặn **không có hồng cầu**. **CK 45 000 U/L**, K^+^ 5,8 mmol/L, creatinin 160 µmol/L. Chẩn đoán: **tiêu cơ vân do gắng sức** có **myoglobin niệu** và tổn thương thận cấp. Cần truyền dịch tích cực.

### 6.4. Co cứng tử thi và cơn co cứng cơ do thiếu ATP

- **Co cứng tử thi**: hết ATP → đầu myosin kẹt ở trạng thái **rigor** (mục 2.2).
- **Bệnh McArdle** (thiếu phosphorylase cơ, hs-07): gắng sức mạnh thì cơ không lấy được năng lượng từ glycogen, ATP tụt → cơ **co cứng, đau** (gọi là co cứng – *contracture*), có thể kèm **myoglobin niệu**. Cùng bản chất với rigor: **thiếu ATP thì cơ không duỗi được**.

### 6.5. Chuột rút

**Chuột rút** là cơn co cơ **đột ngột, không tự chủ, gây đau**, thường ở bắp chân, tự hết sau vài giây đến vài phút.

- **Chuột rút khi gắng sức**: cơ chế **chưa thống nhất**. Hiện nay giả thuyết được ủng hộ nhiều là **rối loạn kiểm soát thần kinh – cơ** khi cơ mỏi (tăng kích thích từ thoi cơ, giảm ức chế từ thể Golgi gân). Giả thuyết "mất nước, mất điện giải" là quan niệm phổ biến nhưng bằng chứng **không mạnh**. Kéo giãn cơ thụ động thường cắt được cơn.
- Chuột rút thường gặp ở người **xơ gan**, **chạy thận nhân tạo**, phụ nữ có thai, người dùng **thuốc lợi tiểu**.

> [!bay] Hạ calci máu gây co cứng cơ — vì sao, khi Ca^2+^ lại cần cho co cơ?
> Nghe có vẻ ngược. Khi Ca^2+^ **ngoài tế bào** giảm, màng **tế bào thần kinh** trở nên **dễ kích thích hơn** (ngưỡng điện thế giảm), thần kinh tự phát xung liên tục → cơ co cứng (**cơn tetani**: co quắp bàn tay "bàn tay người đỡ đẻ", tê quanh miệng). Đây là tác dụng lên **thần kinh**, không phải do thiếu Ca^2+^ trong sợi cơ. Hạ Mg^2+^, kiềm hô hấp (thở nhanh) cũng gây cơn tương tự.

> [!yhct] Thược dược Cam thảo thang và chuột rút
> - **Quan niệm YHCT**: bài **Thược dược Cam thảo thang** (Bạch thược + Chích cam thảo, *Thương hàn luận*) vốn dùng cho chứng **chân co quắp** (cước loan cấp), theo lý "toan cam hóa âm, hoãn cấp chỉ thống".
> - **Bằng chứng hiện đại**: ở Nhật, chế phẩm này (Shakuyakukanzoto) được dùng nhiều cho **chuột rút ở người xơ gan và chạy thận nhân tạo**. Có một số **thử nghiệm lâm sàng nhỏ** cho kết quả giảm tần suất cơn, nhưng **cỡ mẫu nhỏ, chất lượng chưa cao**. Cơ chế (paeoniflorin, glycyrrhizin tác động lên kênh ion ở màng cơ – thần kinh) mới dựa trên **nghiên cứu in vitro và động vật**.
> - **Cảnh báo — nghịch lý thú vị**: glycyrrhizin của **Cam thảo** (qua chất chuyển hóa acid glycyrrhetinic) gây **giả cường aldosteron** (cơ chế 11β-HSD2: xem bài *Hóa sinh hormon*, mã hs-14) → **hạ K^+^ máu**. Hạ K^+^ nặng lại gây **yếu cơ** và đã có báo cáo **tiêu cơ vân do hạ K^+^** khi dùng cam thảo liều cao, kéo dài. Vì vậy bài thuốc này thường chỉ dùng **ngắn ngày, khi lên cơn**; người già, người dùng lợi tiểu thải K^+^ cần theo dõi K^+^ máu.

## Tóm tắt

| Chủ đề | Ý chính |
|---|---|
| Tổ chức cơ vân | Bó cơ (20–100 µm) → sợi cơ (tế bào nhiều nhân) → tơ cơ → **đơn vị co cơ** (giữa 2 đĩa Z, 2,5–3 µm khi giãn). Băng A (sợi dày), băng I (chỉ sợi mỏng, có đĩa Z), vùng H, đĩa M |
| Myosin | ~470 kDa, **2 chuỗi nặng (230 kDa) + 4 chuỗi nhẹ**. Trypsin → LMM (đuôi) + HMM; papain cắt HMM → **S1 (ATPase + gắn actin)** + S2. Chuỗi nhẹ phosphoryl hóa điều chỉnh ATPase, làm cánh tay đòn |
| Actin | G-actin (gắn ATP) → F-actin (giữ ADP); có cực; ≥ 6 isoform; giáo trình in 4 kDa (thực tế ~42 kDa) |
| Tropomyosin | 2 chuỗi xoắn α, dài 400 Å, nằm trong rãnh F-actin, phủ 7 actin; điều chỉnh tương tác actin–myosin |
| Troponin | 76 kDa: **TnT** (gắn tropomyosin), **TnI** (gắn actin, ức chế), **TnC** (gắn Ca^2+^) |
| Protein phụ | α-actinin (neo actin vào Z), desmin – vimentin, **titin** (lớn nhất, chiều dài sợi dày), **nebulin** (chiều dài actin), C-, M-protein, **myoglobin** (153 aa, dự trữ O~2~) |
| Trượt sợi | Sợi không ngắn lại; **băng I, vùng H ngắn**, **băng A giữ nguyên**; cơ ngắn ~1/3 |
| Chu trình S1 | **ATP gắn → tách** · **thủy phân → dựng lên, bám actin mới** · **tách Pi → cú đẩy ~60 Å** · **tách ADP → rigor**. ~500 đầu/sợi dày, ~5 lần/giây |
| Điều hòa Ca^2+^ | Nghỉ < 10^−7^ M (lưới cơ tương > 10^−3^ M, calsequestrin 55 kDa gắn > 40 Ca^2+^); co ~10^−5^ M; giãn nhờ **Ca^2+^-ATPase** bơm về lưới (tốn ATP) |
| Năng lượng | ATP tự do ~5 µmol/g (1–2 giây) → **creatin phosphat** 15–20 µmol/g + **CK** (tổng 7–8 giây) → adenylat kinase (2 ADP → ATP + AMP) → đường phân yếm khí (2 ATP, lactat) / ái khí (36–38 ATP theo sách; nay ~30–32) → **lipid > 95%** khi kéo dài (9,3 kcal/g so với 3–4 kcal/g) |
| Cơ tim | Giống cơ vân; phụ thuộc ái khí hơn; tự khởi động |
| Cơ trơn | **Không troponin**; Ca^2+^–**calmodulin** → **MLCK** phosphoryl hóa chuỗi nhẹ (Ser) → co. ATPase ~10% cơ vân; chậm, tiết kiệm ATP. Epinephrin → cAMP → PKA phosphoryl hóa MLCK → giãn |
| Tế bào khác | Actin 5–10% protein, myosin ~1/10 actin. Profilin (16 kDa) – profilactin – thụ tinh; vòng actomyosin khi phân bào; tiểu cầu co rút qua Ca^2+^–calmodulin–MLCK |
| Lâm sàng | **Creatinin** tỉ lệ khối cơ, đánh giá lọc cầu thận; **CK** tăng khi tổn thương cơ; **tiêu cơ vân**: CK > 5 lần, **myoglobin niệu** (que "máu" + không hồng cầu), tăng K^+^, suy thận cấp → truyền dịch; **co cứng tử thi** = thiếu ATP; hạ Ca^2+^ máu gây tetani qua thần kinh |
