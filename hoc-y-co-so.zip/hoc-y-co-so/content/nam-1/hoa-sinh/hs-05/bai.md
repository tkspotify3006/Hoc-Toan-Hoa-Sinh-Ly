---
title: Enzym
thoi-gian: 60 phút
muc-tieu:
- Gọi tên được enzym theo 4 cách và xếp được một enzym vào 6 lớp của danh pháp quốc tế (mã EC), có ví dụ cho từng lớp.
- Mô tả được thành phần cấu tạo (apoenzym, cofactor, coenzym, nhóm phụ), trung tâm hoạt động và các dạng cấu trúc của enzym (đơn chuỗi/đa chuỗi, dị lập thể, isoenzym, zymogen, phức hợp đa enzym).
- Trình bày được cấu tạo và cơ chế hoạt động của coenzym NAD^+^ và FAD; nối được mỗi coenzym với vitamin tạo ra nó.
- Giải thích được vì sao enzym làm phản ứng xảy ra nhanh: giảm năng lượng hoạt hóa qua phức hợp ES.
- Viết được phương trình Michaelis–Menten và Lineweaver–Burk, đọc được K~m~, V~max~ trên đồ thị và tính được chúng từ số liệu đơn giản.
- Trình bày được ảnh hưởng của nồng độ cơ chất, nồng độ enzym, nhiệt độ, pH, chất hoạt hóa và các kiểu ức chế; nhận ra kiểu ức chế trên đồ thị.
- (Bổ sung) Nêu được các cơ chế điều hòa enzym và ý nghĩa của các enzym huyết thanh hay dùng trong chẩn đoán; một số thuốc tác động qua enzym.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Enzym là **chất xúc tác sinh học**, bản chất **protein**: không bị tiêu hao, **không đổi hằng số cân bằng**, nhưng **đặc hiệu** cao và chỉ hoạt động ở nhiệt độ, pH vừa phải.
> 2. Danh pháp quốc tế (theo giáo trình) chia **6 lớp** theo kiểu phản ứng: **1** oxy hóa khử – **2** vận chuyển nhóm – **3** thủy phân – **4** phân cắt (lyase) – **5** đồng phân – **6** tổng hợp (ligase, cần ATP). Mỗi enzym có mã **EC** 4 số. Từ 2018 EC có thêm **lớp 7 – translocase** (mục 2.3).
> 3. Enzym tạp = **apoenzym** (protein) + **cofactor** (ion kim loại hoặc **coenzym**, phần lớn là dẫn xuất **vitamin B**). Cơ chất gắn vào **trung tâm hoạt động** tạo phức hợp **ES**.
> 4. Enzym **giảm năng lượng hoạt hóa**. Động học: **v = V~max~·[S] / (K~m~ + [S])**; K~m~ = [S] khi v = V~max~/2; **K~m~ nhỏ ⇒ ái lực lớn**. Đồ thị Lineweaver–Burk cắt trục tung tại 1/V~max~, trục hoành tại −1/K~m~.
> 5. Ức chế **cạnh tranh**: K~m~ tăng, V~max~ giữ nguyên. **Không cạnh tranh**: V~max~ giảm, K~m~ giữ nguyên. **Phi cạnh tranh**: cả hai cùng giảm.

## 1. Enzym là gì?

Enzym là chất xúc tác do cơ thể sống tạo ra. Gần như mọi phản ứng hóa sinh trong tế bào đều cần enzym; thiếu enzym, các phản ứng này xảy ra chậm đến mức vô nghĩa với sự sống (Giáo trình tr. 62).

| Giống chất xúc tác hóa học thông thường | Khác chất xúc tác hóa học thông thường |
|---|---|
| Không bị tiêu hao, không sinh thêm sau phản ứng | Bản chất là **protein** |
| Không "tạo ra" phản ứng mới, chỉ làm phản ứng vốn có xảy ra **nhanh hơn rất nhiều** | **Đặc hiệu** cao: chỉ tạo đúng sản phẩm, gần như không có phản ứng phụ |
| Thay đổi tốc độ nhưng **không làm thay đổi hằng số cân bằng** | Có thể **đặc hiệu tuyệt đối** (một cơ chất) hoặc **đặc hiệu tương đối** (một nhóm cơ chất có cấu trúc gần nhau) |
| | Chỉ hoạt động ở vùng **nhiệt độ và pH vừa phải** |

**Vì sao enzym không đổi cân bằng?** Enzym làm nhanh cả chiều thuận lẫn chiều nghịch với cùng một tỉ lệ. Hệ đạt cân bằng sớm hơn, nhưng vị trí cân bằng vẫn như cũ (xem mục 5).

> [!cap-nhat] Không phải mọi chất xúc tác sinh học đều là protein
> Giáo trình viết enzym có bản chất là protein. Hiện nay đã biết một số **RNA (ARN) có hoạt tính xúc tác** (ribozym). Ví dụ quan trọng: phản ứng tạo liên kết peptid trong **ribosom** do rRNA xúc tác (xem sinh-hoc/sh-09). Đi thi trả lời "enzym có bản chất protein" theo giáo trình.

## 2. Cách gọi tên và phân loại enzym

### 2.1. Bốn cách gọi tên (Giáo trình tr. 63)

| Cách gọi | Ví dụ |
|---|---|
| Tên **cơ chất** + đuôi **-ase** | Ure → **urease**; protein → **proteinase** |
| Tên **kiểu tác dụng** + -ase | Oxy hóa → **oxidase**; trao đổi amin → **aminotransferase**; khử CO~2~ → **decarboxylase** |
| Tên **cơ chất + kiểu tác dụng** + -ase (cách rõ nhất) | **Lactat dehydrogenase** (lấy H của lactat); **tyrosin decarboxylase** |
| **Tên thường gọi**, không có đuôi -ase | **Pepsin, trypsin, chymotrypsin** |

### 2.2. Danh pháp quốc tế — mã EC

Khi số enzym đã biết lên tới hàng nghìn, Hiệp hội enzym quốc tế (Enzyme Commission, **EC**) xếp chúng theo **kiểu phản ứng được xúc tác**. Mỗi enzym có một mã gồm **4 số**:

- Số thứ 1: **lớp** (class), từ 1 đến 6.
- Số thứ 2: **dưới lớp** (subclass).
- Số thứ 3: **nhóm** (sub-subclass).
- Số thứ 4: số thứ tự của enzym trong nhóm.

Ví dụ của giáo trình: **hexokinase = EC 2.7.1.1**. Nghĩa là lớp 2 (vận chuyển nhóm), dưới lớp 7 (chuyển nhóm chứa phospho), nhóm 1, enzym số 1.

### 2.3. Sáu lớp enzym (Giáo trình tr. 63–66)

| Lớp | Phản ứng tổng quát | Các dưới lớp chính | Ví dụ trong sách |
|---|---|---|---|
| **1. Oxy hóa khử** (oxidoreductase) | AH~2~ + B → A + BH~2~ (trao đổi H hoặc electron) | **Dehydrogenase** (nhận điện tử không phải O~2~, vd NAD^+^); **oxidase** (dùng O~2~ làm chất nhận nhưng O không vào cơ chất); **reductase**; **catalase**; **peroxidase**; **oxygenase/hydroxylase** (gắn O vào cơ chất) | Lactat dehydrogenase, malat dehydrogenase; cytochrom oxidase, xanthin oxidase; cytochrom P-450; phenylalanin hydroxylase |
| **2. Vận chuyển nhóm** (transferase) | AX + B → A + BX (nhóm X **không phải H**) | **Aminotransferase** (chuyển –NH~2~); transcetolase, transaldolase (chuyển đơn vị 2C, 3C); acyl-, methyl-, glucosyl-transferase, phosphorylase; **kinase** (chuyển gốc phosphat từ ATP); thiolase; **polymerase** | AST, ALT; hexokinase; glycogen phosphorylase; DNA (ADN), RNA polymerase |
| **3. Thủy phân** (hydrolase) | AB + H~2~O → AH + BOH | Esterase, glucosidase, **protease**, **phosphatase**, phospholipase, amidase, desaminase, nuclease | Lipase (triacylglycerol lipase), adenosin desaminase |
| **4. Phân cắt** (lyase) | AB → A + B (tách nhóm **không cần nước**) | **Decarboxylase**, **aldolase**, hydratase (gắn H~2~O), dehydratase (tách H~2~O), synthase (gắn 2 phân tử **không cần ATP**) | Pyruvat decarboxylase; aldolase (fructose-1,6-bisphosphat → GAP + DHAP); fumarase; citrat synthase |
| **5. Đồng phân** (isomerase) | ABC → ACB | **Racemase** (D ↔ L), **epimerase**, isomerase (aldose ↔ cetose), **mutase** (chuyển nhóm trong cùng phân tử) | Ribose-5-phosphat epimerase; phosphopentose isomerase |
| **6. Tổng hợp** (ligase, synthetase) | A + B + ATP → AB + ADP + Pi | **Synthetase** (gắn 2 phân tử, cần ATP); **carboxylase** (gắn CO~2~); **ligase** | Pyruvat carboxylase; DNA ligase |

> [!ghi-nho] Mẹo nhớ thứ tự 6 lớp
> "**Ôxy – Vận – Thủy – Phân – Đồng – Tổng**" (1 → 6). Một cách khác hay dùng trong sách tiếng Anh: **OTHLIL** = Oxidoreductase, Transferase, Hydrolase, Lyase, Isomerase, Ligase.

> [!bay]
> - **Synthase ≠ synthetase.** Giáo trình xếp *synthase* (không cần ATP, vd citrat synthase) vào **lớp 4**; *synthetase* (cần ATP) thuộc **lớp 6**.
> - **Phosphorylase ≠ phosphatase.** Phosphorylase (lớp 2) **gắn** phosphat vô cơ để cắt liên kết (glycogen + Pi → glucose-1-phosphat). Phosphatase (lớp 3) **thủy phân** để **tách** phosphat ra.
> - **Kinase** chuyển phosphat **từ ATP** sang cơ chất → lớp **2**, không phải lớp 6, dù có dùng ATP.
> - **Hydratase** gắn H~2~O vào liên kết đôi (fumarase) → lớp **4**, không phải thủy phân. Thủy phân là **cắt đứt** liên kết nhờ nước.
> - Trong sách, mục ligase bị in nhầm số là "1.2.3"; thực tế là lớp **thứ 6**.

> [!cap-nhat] Lớp thứ 7 và các mã EC đã đổi
> - Từ năm 2018, danh pháp EC có thêm **lớp 7: translocase**, gồm enzym **vận chuyển ion hoặc phân tử qua màng** (vd ATP synthase của ty thể, nay là EC 7.1.2.2).
> - Một số enzym giáo trình xếp vào lớp 4 nay mang mã khác: **citrat synthase** đã chuyển từ EC 4.1.3.7 sang **EC 2.3.3.1** (transferase); glycogen synthase là **EC 2.4.1.11**. Còn PEP carboxykinase mà sách để ở mục kinase có mã **EC 4.1.1.32** (lyase).
> - Đi thi: trả lời **6 lớp** và ví dụ đúng như giáo trình.

## 3. Cấu trúc phân tử enzym

### 3.1. Thành phần cấu tạo (Giáo trình tr. 66–67)

Enzym là protein có khối lượng phân tử từ khoảng **12.000 đến hàng triệu Dalton**. Cũng như protein, enzym chia làm hai loại:

- **Enzym thuần** (một thành phần): chỉ gồm các gốc acid amin (amino acid). Ví dụ pepsin, trypsin.
- **Enzym tạp** (hai thành phần, **holoenzym**): ngoài phần protein còn cần một **chất cộng tác** (cofactor).

=> Holoenzym = Apoenzym + Cofactor

| Thành phần | Bản chất | Vai trò |
|---|---|---|
| **Apoenzym** | Phần protein | Quyết định **tính đặc hiệu** và các đặc tính cơ bản của enzym |
| **Cofactor** | Ion kim loại (Fe^2+^, Mg^2+^, Mn^2+^, Zn^2+^…) hoặc phân tử hữu cơ (**coenzym**) | Bổ sung khả năng phản ứng, trực tiếp tham gia xúc tác |
| **Nhóm phụ** (prosthetic group) | Cofactor **gắn chặt**, không tách ra được | Ví dụ: FAD trong một số flavoprotein, hem trong cytochrom |

- Coenzym hay gặp ở enzym **oxy hóa khử** và **vận chuyển nhóm**. Thiếu coenzym, các enzym này không hoạt động.
- Phần lớn coenzym là **vitamin** hoặc dẫn xuất của vitamin. Đây là lý do thiếu vitamin gây rối loạn chuyển hóa (mục 4).

**Enzym kim loại** (metalloenzym): kim loại có thể tham gia trực tiếp xúc tác, làm chất oxy hóa khử, hoặc tạo phức với cơ chất.

| Kim loại | Enzym (Giáo trình tr. 67) |
|---|---|
| Fe^2+^ / Fe^3+^ | Cytochrom oxidase, catalase, peroxidase |
| Cu^2+^ | Cytochrom oxidase |
| Zn^2+^ | Carbonic anhydrase, alcol dehydrogenase |
| Mg^2+^ | Hexokinase, glucose-6-phosphatase, pyruvat kinase |
| Se | Glutathion peroxidase |

> [!ung-dung] Vì sao ống xét nghiệm có chất chống đông EDTA không dùng để đo ALP, CK?
> EDTA "bắt" các ion kim loại hóa trị 2 (Mg^2+^, Zn^2+^). Enzym cần các ion này, như **phosphatase kiềm** (ALP, cần Zn^2+^ và Mg^2+^) hay **creatin kinase** (CK, phản ứng cần Mg^2+^–ADP), sẽ cho kết quả **thấp giả**. Vì vậy phần lớn xét nghiệm enzym dùng **huyết thanh** hoặc huyết tương heparin.

### 3.2. Trung tâm hoạt động (Giáo trình tr. 67–68)

**Trung tâm hoạt động** (active site) là một vùng nhỏ của phân tử enzym, nơi cơ chất gắn vào và bị biến đổi thành sản phẩm. Một enzym có thể có một hoặc vài trung tâm hoạt động.

- Trung tâm hoạt động gồm những nhóm hóa học **tiếp xúc trực tiếp** với cơ chất, và cả những nhóm **không tiếp xúc** nhưng tham gia trực tiếp vào xúc tác.
- Các acid amin hay gặp ở đây mang nhóm **phân cực hoặc ion hóa**, dễ tạo liên kết hydro hoặc liên kết ion với cơ chất: **serin** (–OH), **cystein** (–SH), **glutamat** (γ-COO^−^), **lysin** (ε-NH~3~^+^), **histidin** (vòng imidazol), tryptophan (vòng indol).
- Các acid amin này có thể nằm **xa nhau** trên chuỗi polypeptid nhưng lại **gần nhau trong không gian** nhờ chuỗi gấp cuộn. Vì thế làm biến tính (phá cấu trúc không gian) là làm mất trung tâm hoạt động.

Hai giả thuyết giải thích sự gắn enzym – cơ chất:

| | **"Ổ khóa – chìa khóa"** (lock and key) | **"Cảm ứng không gian"** (induced fit) |
|---|---|---|
| Tác giả | Emil **Fischer** (giáo trình ghi năm 1890; thường được dẫn là 1894) | Daniel **Koshland** (1958) |
| Nội dung | Trung tâm hoạt động có hình dạng **cố định**, khớp sẵn với cơ chất | Trung tâm hoạt động **mềm dẻo**, tự thay đổi hình dạng khi cơ chất tới để ôm khít cơ chất |
| Giải thích được | Đặc hiệu **tuyệt đối** | Cả đặc hiệu **tương đối** |

### 3.3. Các dạng cấu trúc của phân tử enzym (Giáo trình tr. 68–70)

**a) Enzym đơn chuỗi và đa chuỗi**

- **Đơn chuỗi** (monomer): ribonuclease A, lysozym, lipase, pepsin, chymotrypsin.
- **Đa chuỗi** (oligomer, polymer): AST, ALP, CK, hexokinase (**2 chuỗi**); **LDH (4 chuỗi)**; RNA polymerase (5); ATP synthetase (12); glutamat dehydrogenase (GLDH, 40 chuỗi).

**b) Enzym dị lập thể (allosteric enzyme)**

Ngoài trung tâm hoạt động, enzym dị lập thể còn có **vị trí dị lập thể** để gắn **chất điều hòa**:

- Chất hoạt hóa dị lập thể (yếu tố dương, A) gắn vào → enzym đổi hình dạng theo hướng **tăng ái lực** với cơ chất → phản ứng nhanh lên.
- Chất ức chế dị lập thể (yếu tố âm, I) gắn vào → **giảm ái lực** → phản ứng chậm lại.
- Thường thì chất hoạt hóa là chất **đứng trước** trong chuỗi phản ứng, còn chất ức chế là chất **đứng sau** hoặc **sản phẩm cuối cùng** (ức chế ngược, feedback).

Ví dụ của sách: **phosphofructokinase (PFK)** trong đường phân được **hoạt hóa bởi ADP, AMP** (tín hiệu "tế bào thiếu năng lượng") và **bị ức chế bởi ATP, citrat** (tín hiệu "đủ năng lượng").

> [!vi-du] Vì sao enzym dị lập thể không theo đúng Michaelis–Menten?
> Ở enzym nhiều chuỗi, một chuỗi gắn chất hoạt hóa có thể **lan truyền** sự thay đổi hình dạng sang các chuỗi bên cạnh. Kết quả là đồ thị v theo [S] có dạng **chữ S** (sigmoid) chứ không phải hyperbol. Nhờ vậy enzym phản ứng rất nhạy với một thay đổi nhỏ của nồng độ chất điều hòa, giống "công tắc" hơn là "vòi nước".

**c) Isoenzym (isozym)**

**Isoenzym** là những dạng phân tử **khác nhau** của **cùng một enzym**, cùng xúc tác **một phản ứng**, có trong cùng một loài, thậm chí cùng một cơ thể. Chúng khác nhau về tính chất lý hóa, về K~m~ và V~max~, và về **phân bố ở các mô**.

- **LDH** gồm 4 chuỗi, ghép từ 2 loại: chuỗi **H** (tim) và chuỗi **M** (cơ). Có **5 isoenzym**:

| LDH~1~ | LDH~2~ | LDH~3~ | LDH~4~ | LDH~5~ |
|---|---|---|---|---|
| HHHH | HHHM | HHMM | HMMM | MMMM |
| "kiểu tim" | | | | "kiểu gan" (cả cơ vân) |

- **CK** gồm 2 chuỗi: **B** (não) và **M** (cơ), tạo **3 isoenzym**: **CK-BB** (não), **CK-MB** (cơ tim nhiều nhất), **CK-MM** (cơ vân).

> [!ung-dung] Isoenzym giúp xác định cơ quan bị tổn thương
> Tổng LDH hoặc tổng CK tăng chỉ cho biết "có tế bào bị hủy". Đo **isoenzym** cho biết tế bào nào: **CK-MB** gợi ý tổn thương **cơ tim**; LDH~1~ cao hơn LDH~2~ (bình thường ngược lại) gặp sau **nhồi máu cơ tim** hoặc **tan máu**; LDH~5~ tăng gợi ý bệnh **gan** hoặc cơ vân. Xem thêm mục 9.

**d) Tiền enzym (proenzym, zymogen)**

Một số enzym được tổng hợp ở dạng **chưa có hoạt tính**. Một đoạn polypeptid **che trung tâm hoạt động**. Khi được bài tiết tới đúng nơi, đoạn này bị **cắt đi** (thủy phân) và enzym trở nên hoạt động.

- Tên có đuôi **-ogen**: pepsinogen → pepsin; trypsinogen → trypsin; chymotrypsinogen → chymotrypsin.
- Hoặc tiền tố **pro-**: **prothrombin** → thrombin (đông máu).

**Vì sao cần zymogen?** Enzym tiêu hóa protein nếu hoạt động ngay trong tế bào tụy hay dạ dày sẽ **tự tiêu hóa** chính cơ quan tạo ra nó.

> [!ung-dung] Viêm tụy cấp
> Khi trypsinogen bị hoạt hóa **sớm ngay trong tụy** (do sỏi mật gây trào ngược, rượu…), trypsin hoạt hóa tiếp các zymogen khác và tụy bị **tự tiêu hóa**. Enzym tụy tràn vào máu, nên **amylase và lipase máu tăng cao**, đây là xét nghiệm chính để chẩn đoán (mục 9).

**e) Phức hợp đa enzym**

Nhiều enzym xúc tác các bước **liên tiếp** của một con đường kết tụ lại thành một khối. Sản phẩm của bước trước được chuyển ngay sang enzym sau, nên hiệu quả cao. Nếu bị tách riêng, từng enzym dễ biến tính và mất hoạt tính.

Ví dụ: phức hợp **pyruvat dehydrogenase** biến pyruvat thành **acetyl-CoA**. Phức hợp gồm 3 enzym: pyruvat dehydrogenase, dihydrolipoyl transacetylase, dihydrolipoyl dehydrogenase.

> [!bay] Phức hợp pyruvat dehydrogenase cần mấy coenzym?
> Ở tr. 70, giáo trình liệt kê 4 coenzym: **TPP, acid lipoic, CoA, NAD^+^**. Nhưng ở tr. 72 chính giáo trình lại ghi phức hợp này cần thêm **FAD**. Hóa sinh hiện đại thống nhất là **5 coenzym**: TPP (B~1~), acid lipoic, CoA (B~5~), **FAD (B~2~)**, NAD^+^ (B~3~). FAD là nhóm phụ của enzym thứ 3 (dihydrolipoyl dehydrogenase). Nếu đề hỏi "theo giáo trình", hãy đọc kỹ đề.

## 4. Coenzym — "vitamin đang làm việc"

Coenzym cùng enzym tham gia xúc tác. Nhiều coenzym gắn vào enzym như một **cơ chất thứ hai**: nhận một nhóm hoặc H ở phản ứng này, rồi nhả ra ở phản ứng khác. Số khác gắn **cộng hóa trị** vào enzym và đóng vai trò như một phần của trung tâm hoạt động (Giáo trình tr. 70).

Có coenzym chỉ cần biến đổi ít từ vitamin (pyridoxin → pyridoxal phosphat). Có coenzym cần tế bào biến đổi nhiều (niacin → NAD^+^).

### 4.1. Coenzym oxy hóa khử

**a) NAD^+^ và NADP^+^ — từ niacin (vitamin B~3~, PP)**

- **Niacin** là acid pyridin-3-carboxylic. Tế bào chuyển nó thành **nicotinamid adenin dinucleotid (NAD^+^)** và **NADP^+^**.
- NADP^+^ chỉ khác NAD^+^ ở **một gốc phosphat thêm ở vị trí 2′** của ribose bên phía adenosin.
- **Phần hoạt động** là **vòng nicotinamid**. Vòng này nhận **2 electron và 1 H^+^** (tức một ion hydrid H^−^) vào vị trí C4 của vòng. Ion H^+^ thứ hai được giải phóng ra môi trường.

=> NAD^+^ + 2H (2 e^−^ + 2H^+^ lấy từ cơ chất) → NADH + H^+^

- Coenzym của các **dehydrogenase**. Có enzym dùng NAD^+^, có enzym dùng NADP^+^.

**b) FMN và FAD — từ riboflavin (vitamin B~2~)**

- Riboflavin gồm vòng **isoalloxazin** (flavin) nối qua **N-10** với alcol **ribitol**.
- **FMN** (flavin mononucleotid) = riboflavin + 1 phosphat ở C5′ của ribitol.
- **FAD** (flavin adenin dinucleotid) = FMN + AMP, nối bằng liên kết pyrophosphat (cấu trúc giống NAD^+^, nhưng thay nicotinamid bằng flavin).
- **Phần hoạt động** là vòng **isoalloxazin**: nhận **2 electron và 2 H^+^** (vào N-1 và N-5).

=> FAD + 2H → FADH~2~

| | NAD^+^ / NADP^+^ | FMN / FAD |
|---|---|---|
| Vitamin | B~3~ (niacin, PP) | B~2~ (riboflavin) |
| Phần hoạt động | Vòng nicotinamid | Vòng isoalloxazin |
| Nhận | 2e^−^ + **1H^+^** (thêm 1 H^+^ tự do) | 2e^−^ + **2H^+^** |
| Dạng khử | NADH + H^+^ / NADPH + H^+^ | FMNH~2~ / FADH~2~ |
| Gắn với enzym | Lỏng, đi từ enzym này sang enzym khác | Thường **gắn chặt** (nhóm phụ) |

> [!vi-du] NADH và NADPH dùng vào việc khác nhau
> Hai coenzym gần như giống hệt nhau, nhưng tế bào dùng chúng cho hai mục đích riêng. **NADH** chủ yếu mang điện tử từ các phản ứng **thoái hóa** tới **chuỗi hô hấp** để tạo ATP. **NADPH** cung cấp H cho các phản ứng **tổng hợp** (acid béo, cholesterol) và chống oxy hóa (giữ glutathion ở dạng khử). Gốc phosphat thêm vào giống như "nhãn dán" để enzym nhận đúng loại coenzym. Chi tiết ở bài Năng lượng sinh học (hs-06) và chuyển hóa glucid (hs-07).

**c) Coenzym hem (porphyrin Fe)**

Hem là coenzym của **cytochrom**, **catalase**, **peroxidase**, mono- và dioxygenase. Hem vận chuyển điện tử nhờ Fe chuyển qua lại giữa hai hóa trị:

=> Fe^2+^ − e^−^ ⇌ Fe^3+^

| Enzym có hem | Phản ứng |
|---|---|
| Cytochrom (chuỗi hô hấp) | 2 Cyt b (Fe^2+^) + 2 Cyt c (Fe^3+^) ⇌ 2 Cyt b (Fe^3+^) + 2 Cyt c (Fe^2+^) |
| **Catalase** | 2 H~2~O~2~ → 2 H~2~O + O~2~ |
| **Peroxidase** | H~2~O~2~ + AH~2~ → 2 H~2~O + A |
| **Monooxygenase (cytochrom P-450)** | RH + NADPH + H^+^ + O~2~ → ROH + NADP^+^ + H~2~O |
| Dioxygenase | Gắn cả 2 nguyên tử O của O~2~ vào cơ chất |

Phản ứng của **cytochrom P-450** gắn nhóm –OH vào thuốc và chất lạ (xenobiotic). Chất trở nên **dễ tan trong nước hơn** để thải qua thận, và thường bớt độc hơn.

> [!bay]
> Giáo trình tr. 72 in phản ứng peroxidase là "2H~2~O~2~ + AH~2~ → 2H~2~O + A", sai hệ số. Phương trình cân bằng đúng (chính giáo trình viết ở tr. 64) là **H~2~O~2~ + AH~2~ → 2H~2~O + A**.

**d) Acid lipoic**

Acid lipoic (acid 6,8-dithio-octanoic) là một acid béo chứa **2 nguyên tử S**. Nó luân phiên giữa dạng –S–S– (oxy hóa) và 2 nhóm –SH (khử). Acid lipoic tham gia phức hợp **khử carboxyl oxy hóa** acid pyruvic và acid α-cetoglutaric, cùng với TPP, CoA, FAD và NAD^+^.

### 4.2. Coenzym vận chuyển nhóm (Giáo trình tr. 73–74)

| Coenzym | Vitamin gốc | Nhóm vận chuyển | Enzym/phản ứng điển hình |
|---|---|---|---|
| **Thiamin pyrophosphat (TPP)** | B~1~ (thiamin) | Tách **CO~2~** của acid α-cetonic | Khử carboxyl pyruvat, α-cetoglutarat; transcetolase |
| **Coenzym A** (CoA-SH) | B~5~ (acid pantothenic) | Nhóm **acyl** (acetyl…) | Tạo acetyl-CoA ("acetat hoạt động") → chu trình citric, tổng hợp acid béo, cholesterol, hormon steroid |
| **S-adenosyl-methionin (SAM)** | Không phải vitamin (từ methionin + ATP) | Nhóm **methyl** –CH~3~ | Các phản ứng methyl hóa |
| **Acid tetrahydrofolic (FH~4~)** | B~9~ (acid folic) | Nhóm **1 carbon** | Tổng hợp purin, thymin |
| **Biotin** | B~7~ (biotin, vitamin H) | **CO~2~** (carboxyl hóa) | Pyruvat carboxylase, acetyl-CoA carboxylase |
| **Pyridoxal phosphat (PLP)** | B~6~ (pyridoxin) | Nhóm **amin** | **Transaminase** (AST, ALT); khử carboxyl acid amin |

**Cấu tạo CoA:** acid pantothenic nối với **thioethanolamin** thành pantethein; pantethein nối với nucleotid adenosin qua liên kết pyrophosphat. Nhóm **–SH** ở đầu thioethanolamin là nơi gắn nhóm acyl (liên kết thioester giàu năng lượng).

**Cơ chế của PLP trong trao đổi amin.** PLP nhận nhóm amin của acid amin 1 (biến thành acid α-cetonic 1) và trở thành **pyridoxamin phosphat**. Sau đó pyridoxamin phosphat trao nhóm amin cho acid α-cetonic 2 (biến thành acid amin 2) và trở lại dạng PLP:

=> Acid amin 1 + Acid α-cetonic 2 ⇌ Acid α-cetonic 1 + Acid amin 2

(Giáo trình hình 5.5 ghi nhầm sản phẩm cuối là "acid α-cetonic 1"; đúng ra là sản phẩm của bước sau là **acid amin 2**, còn chất bị biến đổi là **acid α-cetonic 2**.)

PLP còn là coenzym của các enzym **khử carboxyl acid amin**, tạo ra các **amin sinh học**:

| Acid amin | Sản phẩm | Vai trò |
|---|---|---|
| Acid glutamic | **GABA** | Chất ức chế hoạt động thần kinh |
| Histidin | **Histamin** | Tăng tính thấm thành mạch, gây phản ứng dị ứng |
| Phenylalanin, tyrosin (+ hydroxyl hóa) | **Norepinephrin, epinephrin** | Hormon, chất dẫn truyền thần kinh |

> [!ung-dung] Thiếu vitamin = thiếu coenzym = enzym "đứng máy"
> - **Thiếu B~1~**: enzym khử carboxyl pyruvat và α-cetoglutarat ngừng hoạt động, nên mô dùng nhiều glucose bị ảnh hưởng nặng nhất: **thần kinh ngoại biên, tiêu hóa, tim mạch**. Biểu hiện là bệnh **beriberi**, viêm thần kinh do rượu, viêm thần kinh do thai nghén. Ở người nghiện rượu thiếu B~1~, truyền glucose trước khi bù thiamin có thể khởi phát **bệnh não Wernicke**, nên phải **cho B~1~ trước hoặc cùng lúc**.
> - **Isoniazid** (thuốc lao) kết hợp với pyridoxal và làm cạn B~6~, gây **viêm thần kinh ngoại biên**. Vì vậy thường dùng kèm vitamin B~6~.
> - **Thiếu B~3~** gây bệnh **pellagra** ("3D": viêm da, tiêu chảy, sa sút trí tuệ).

## 5. Cơ chế xúc tác của enzym (Giáo trình tr. 74–76)

### 5.1. Điều kiện cần: ΔG < 0

Năng lượng tự do (G) là phần năng lượng có thể sinh công. Một phản ứng chỉ **tự xảy ra** khi đi từ mức G cao xuống mức G thấp:

=> A + B → C + D; G~1~ (chất đầu) > G~2~ (sản phẩm) ⇒ ΔG = G~2~ − G~1~ < 0

### 5.2. Điều kiện đủ: vượt qua "sức ỳ" hóa học

Dù ΔG < 0, nhiều phản ứng vẫn **không tự xảy ra**. Đó là do **sức ỳ hóa học** của vật chất, gồm 4 yếu tố:

1. Yếu tố **entropy**: các phân tử chuyển động hỗn loạn, ít khi gặp nhau đúng cách.
2. **Lớp áo nước** bao quanh cơ chất cản trở, có thể làm mất hoạt tính của cơ chất.
3. **Hình thể không gian cồng kềnh** của cơ chất.
4. Các nhóm chức trên phân tử enzym **chưa được sắp xếp đúng hướng**.

Muốn phản ứng xảy ra phải cấp thêm một năng lượng để thắng sức ỳ. Đó là **năng lượng hoạt hóa (E~a~)**: năng lượng cần để đưa **toàn bộ phân tử của 1 mol cơ chất** (ở một nhiệt độ nhất định) lên **trạng thái chuyển tiếp** ở đỉnh hàng rào năng lượng.

### 5.3. Enzym làm giảm năng lượng hoạt hóa

Trong ống nghiệm, có thể tăng tốc phản ứng bằng cách **đun nóng**. Cơ thể không làm vậy được. Enzym chọn cách khác: **hạ thấp hàng rào năng lượng**.

=> E + S ⇌ ES → E + P

Enzym biến một phản ứng thành **hai bước**, mỗi bước có năng lượng hoạt hóa **thấp hơn nhiều**:

- (a) Bước **liên phân tử**: E gắn S tạo phức hợp **ES**. Sự gắn tạo ra nhiều liên kết yếu và **giải phóng năng lượng tự do**.
- (b) Bước **nội phân tử**: phần năng lượng vừa giải phóng giúp đưa ES qua trạng thái chuyển tiếp, tạo **EP**, rồi giải phóng **P** và **E tự do**.

Giáo trình gọi hai trạng thái chuyển tiếp này là **ES1\*** và **ES2\***.

![Hình 1. Enzym làm giảm năng lượng hoạt hóa (Ea) nhưng không làm thay đổi ΔG của phản ứng](nang-luong-hoat-hoa.svg)

> [!bay]
> - Enzym làm giảm **E~a~**, **không** làm thay đổi **ΔG**, cũng **không** làm thay đổi **hằng số cân bằng**. Mức năng lượng của S và P vẫn y như cũ (hình 1).
> - Enzym **không** làm một phản ứng có ΔG > 0 tự xảy ra. Muốn vậy phải **ghép** với một phản ứng giải phóng năng lượng (thường là thủy phân ATP), xem bài hs-06.

> [!vi-du] Enzym hạ hàng rào bằng cách nào? (ngoài giáo trình)
> Sách Hóa sinh hiện đại nêu một số "chiêu" cụ thể: giữ hai cơ chất **sát nhau và đúng hướng** (khắc phục entropy); **gạt bỏ lớp áo nước**; dùng nhóm acid–base của histidin, glutamat để cho/nhận H^+^; tạo **liên kết cộng hóa trị tạm thời** với cơ chất (serin trong các serin protease như trypsin, chymotrypsin); dùng ion kim loại. Điểm chung: trung tâm hoạt động **gắn chặt nhất với trạng thái chuyển tiếp**, chứ không phải với cơ chất ban đầu.

## 6. Động học enzym (Giáo trình tr. 76–79)

### 6.1. Tốc độ phản ứng và đơn vị hoạt độ

- **Tốc độ phản ứng enzym**: lượng cơ chất bị biến đổi trong **1 phút** ở **25 °C**, trong điều kiện chuẩn hóa.
- **Đơn vị quốc tế (IU hoặc U)**: lượng enzym biến đổi được **1 µmol cơ chất trong 1 phút** ở 25 °C, điều kiện chuẩn hóa.
- **Tốc độ ban đầu (v)**: tốc độ đo trong **vài phút đầu** (khoảng 5 phút), khi chưa bị ảnh hưởng bởi sự cạn cơ chất, tích tụ sản phẩm hay thay đổi pH. Lúc này tốc độ tăng **tuyến tính** theo thời gian; về sau đường cong mới uốn xuống. Hoạt độ enzym chỉ đo chính xác ở giai đoạn này.
- **Tốc độ cực đại (V~max~)**: khi [S] tăng thì v tăng, đến lúc **mọi phân tử enzym đều bão hòa** cơ chất thì v không tăng nữa, đạt V~max~.

> [!cap-nhat] Nhiệt độ chuẩn và đơn vị SI
> Giáo trình định nghĩa đơn vị U ở **25 °C**. Hiện nay các phòng xét nghiệm (theo khuyến cáo IFCC) đo hoạt độ enzym ở **37 °C**. Vì vậy kết quả và khoảng tham chiếu phải ghi kèm nhiệt độ đo. Đơn vị SI của hoạt độ là **katal** (kat = 1 mol/giây); **1 U ≈ 16,67 nkat**. Ở Việt Nam, phiếu xét nghiệm vẫn dùng **U/L**.

### 6.2. Phương trình Michaelis–Menten

Năm **1913**, Michaelis và Menten đưa ra giả thuyết: enzym phải tạo **phức hợp ES** trước rồi mới tạo sản phẩm.

=> E + S ⇌ ES → E + P   (k~1~ chiều tạo ES, k~−1~ chiều phân ly ES, k~2~ chiều tạo P)

=> v = V~max~ · [S] / (K~m~ + [S])

Trong đó: v là tốc độ ban đầu; V~max~ là tốc độ tối đa; [S] là nồng độ cơ chất; **K~m~ là hằng số Michaelis** của enzym đối với cơ chất đó.

**Ba trường hợp cần nhớ:**

| Điều kiện | Phương trình rút gọn | Ý nghĩa |
|---|---|---|
| [S] **≪** K~m~ | v ≈ (V~max~/K~m~)·[S] | v **tỉ lệ thuận** với [S]: động học **bậc 1** (đoạn đầu dốc thẳng) |
| [S] **=** K~m~ | v = V~max~/2 | Định nghĩa thực hành của K~m~ |
| [S] **≫** K~m~ | v ≈ V~max~ | Enzym bão hòa: động học **bậc 0**; v chỉ còn phụ thuộc **[E]** |

![Hình 2. Đồ thị Michaelis–Menten khi không có chất ức chế, có chất ức chế cạnh tranh và không cạnh tranh](michaelis-menten.svg)

### 6.3. Ý nghĩa của K~m~ và V~max~

**K~m~:**

- Là một hằng số **tổng hợp từ các hằng số tốc độ**: K~m~ = (k~−1~ + k~2~)/k~1~. Về giá trị, K~m~ bằng **nồng độ cơ chất làm v = V~max~/2**. Đơn vị là **mol/L**.
- Là hằng số **đặc trưng** cho từng cặp enzym – cơ chất. Nó thể hiện **ái lực** của enzym với cơ chất:
  - **K~m~ nhỏ → ái lực lớn**: chỉ cần ít cơ chất đã đạt nửa tốc độ tối đa.
  - **K~m~ lớn → ái lực nhỏ**.
- Muốn đạt (gần) V~max~, [S] phải **≥ 100 lần K~m~**.

**V~max~** phản ánh **số vòng quay** (turnover number) của enzym. Hằng số k~2~ được gọi là số vòng quay: số phân tử cơ chất **một phân tử enzym** biến thành sản phẩm trong một đơn vị thời gian, khi enzym đã bão hòa cơ chất.

| Enzym | Cơ chất | Số vòng quay/giây (Giáo trình bảng 5.1) |
|---|---|---|
| **Catalase** | H~2~O~2~ | **40.000.000** (nhanh nhất bảng) |
| Carbonic anhydrase | HCO~3~^−^ | 400.000 |
| Acetylcholinesterase | Acetylcholin | 14.000 |
| Lactat dehydrogenase | Lactat | 1.000 |
| Fumarase | Fumarat | 800 |
| DNA polymerase I | DNA | 15 |
| ATPase | ATP | 0,4 |

> [!bay]
> - K~m~ **không phụ thuộc** nồng độ enzym. Còn **V~max~ tỉ lệ thuận** với [E]: gấp đôi lượng enzym thì V~max~ gấp đôi, K~m~ giữ nguyên (Giáo trình tr. 80).
> - K~m~ là một **nồng độ** (mol/L), không phải tốc độ. Đừng nhầm "K~m~ = V~max~/2". Đúng là: **khi [S] = K~m~ thì v = V~max~/2**.
> - Hai isoenzym của cùng một enzym có thể có **K~m~ khác nhau** với cùng một cơ chất.

> [!ung-dung] K~m~ giải thích vì sao gan và não "ăn" glucose khác nhau
> **Hexokinase** ở não, cơ có K~m~ với glucose rất thấp (khoảng 0,1 mmol/L), nên luôn gần bão hòa: não vẫn lấy đủ glucose kể cả khi đường huyết thấp. **Glucokinase** ở gan (một isoenzym của hexokinase) có K~m~ cao (khoảng 8–10 mmol/L), nên chỉ làm việc mạnh khi **đường huyết cao sau ăn**. Gan nhờ đó chỉ "thu" glucose để dự trữ khi thừa (số liệu theo các sách Hóa sinh hiện hành, không có trong giáo trình).

### 6.4. Phương trình và đồ thị Lineweaver–Burk

Từ đường hyperbol rất khó xác định chính xác V~max~, vì đường cong chỉ **tiệm cận** V~max~. Lineweaver và Burk **nghịch đảo hai vế** phương trình Michaelis–Menten để được một **đường thẳng** dạng y = ax + b:

=> 1/v = (K~m~/V~max~) · 1/[S] + 1/V~max~

(Trong giáo trình, dấu nhân giữa K~m~/V~max~ và 1/[S] bị in nhầm thành dấu "=".)

| Trên đồ thị (trục hoành 1/[S], trục tung 1/v) | Bằng |
|---|---|
| Giao điểm với **trục tung** | **1/V~max~** |
| Giao điểm với **trục hoành** (kéo dài sang trái) | **−1/K~m~** |
| **Độ dốc** | **K~m~/V~max~** |

![Hình 3. Đồ thị Lineweaver–Burk (trên) và cách nhận ra ba kiểu ức chế thuận nghịch (dưới)](lineweaver-burk.svg)

**Ý nghĩa của đồ thị Lineweaver–Burk** (Giáo trình tr. 79):

- Biến hyperbol thành đường thẳng, nên tìm **K~m~ và V~max~** dễ dàng.
- Là công cụ xác định **pH và nhiệt độ tối ưu**.
- Là công cụ xác định **kiểu chất ức chế** (cạnh tranh hay không cạnh tranh).

> [!vi-du] Tính K~m~ và V~max~ — làm thế nào?
> **Bài 1.** Một enzym có V~max~ = 100 µmol/phút, K~m~ = 2 mmol/L. Tính v khi [S] = 2 mmol/L và khi [S] = 6 mmol/L.
> - [S] = K~m~ ⇒ v = V~max~/2 = **50 µmol/phút**.
> - [S] = 6 ⇒ v = 100 × 6/(2 + 6) = **75 µmol/phút**.
>
> **Bài 2.** Đồ thị Lineweaver–Burk cắt trục tung tại 1/v = 0,02 phút/µmol và cắt trục hoành tại 1/[S] = −0,5 L/mmol.
> - V~max~ = 1/0,02 = **50 µmol/phút**.
> - −1/K~m~ = −0,5 ⇒ K~m~ = **2 mmol/L**.
>
> **Bài 3.** Ở [S] nào thì v = 90% V~max~?
> - 0,9 = [S]/(K~m~ + [S]) ⇒ [S] = **9 K~m~**. Cách giải nhanh: v/V~max~ = [S]/(K~m~ + [S]).
> - Tương tự, v = 99% V~max~ khi [S] = 99 K~m~. Đây là lý do giáo trình nói phải có [S] ≥ 100 K~m~ mới "đạt" V~max~.

## 7. Các yếu tố ảnh hưởng đến hoạt động enzym (Giáo trình tr. 79–83)

Enzym trong huyết thanh có lượng rất nhỏ, nên lâm sàng **đo hoạt độ** (tốc độ phản ứng mà enzym xúc tác) chứ không đo nồng độ. Vì vậy mọi yếu tố làm thay đổi tốc độ đều phải được **chuẩn hóa** khi xét nghiệm.

### 7.1. Nồng độ cơ chất và nồng độ enzym

- **[S]**: theo đồ thị Michaelis–Menten (mục 6).
- **[E]**: cùng một lượng cơ chất, tăng [E] thì v tăng và ngược lại. **K~m~ không phụ thuộc [E]**.

### 7.2. Nhiệt độ

- Nhiệt độ tăng làm phân tử chuyển động mạnh, va chạm hiệu quả nhiều hơn, nên v **tăng**. Trong vùng enzym chưa biến tính, tăng **10 °C** thì v tăng khoảng **2 lần** (hệ số nhiệt độ **Q~10~ = 2**).
- Nhưng enzym là protein. Quá một mức, protein **biến tính** và v giảm nhanh. Biến tính bắt đầu ở khoảng **40–50 °C**. Đồ thị v theo nhiệt độ vì thế có dạng **quả chuông** với một **nhiệt độ tối ưu**, ở người gần với nhiệt độ cơ thể.
- **Thời gian** tiếp xúc nhiệt cũng quan trọng: enzym chịu được nhiệt độ cao hơn trong thời gian ngắn.

**Hệ quả thực hành (Giáo trình tr. 80):**

- Kết quả phải ghi rõ **đo ở nhiệt độ nào**, và hiệu chỉnh nếu cần.
- Mẫu huyết thanh có thể bảo quản trong **tủ lạnh 0–4 °C** hoặc đông lạnh trong thời gian nhất định. **Không đông lạnh – rã đông nhiều lần**, vì làm biến tính protein.
- Một số vi khuẩn sống ở suối nước nóng, đáy biển nóng có **enzym chịu nhiệt**: **Taq**, Tli, **Pfu**, Tth, Tma DNA polymerase. Nhiệt độ tối ưu khoảng **75–80 °C**, chịu được 95 °C trong vài chục phút. Nhờ vậy chúng được dùng trong phản ứng **PCR**.

### 7.3. pH

- Enzym là protein **mang điện**. pH quá cao hoặc quá thấp làm thay đổi **trạng thái ion hóa** của các acid amin ở trung tâm hoạt động (và của cơ chất), có thể làm **biến tính** enzym.
- Mỗi enzym có một khoảng pH hoạt động và một **pH tối ưu**. Đa số enzym sinh lý có pH tối ưu khoảng **7–8**.
- Ngoại lệ điển hình: **pepsin** (dịch vị) có pH tối ưu khoảng **2**; **trypsin** (ruột non) có pH tối ưu kiềm, khoảng **8–9**.
- Trong phòng thí nghiệm phải giữ pH bằng **dung dịch đệm** phù hợp.

> [!yhct] Enzym trong dược liệu: vì sao Sinh mạch nha và Sao mạch nha khác nhau?
> Mạch nha chứa **amylase** thủy phân tinh bột (xem bài *Glucid*, mã hc-08b, mục 6). Bài này giải thích phần **"vì sao"** bằng động học enzym:
> - **Nhiệt độ**: amylase là protein. Khi **sao vàng, sao cháy** (tiêu mạch nha), phần lớn amylase bị **biến tính**. Các phép đo **in vitro** đều cho thấy hoạt tính amylase giảm mạnh sau khi sao. Vì vậy cùng là mạch nha, **sinh mạch nha** giữ hoạt tính enzym tốt nhất. Amylase của mầm lúa mạch mất hoạt tính nhanh ở khoảng 70–80 °C, nên **sắc** (100 °C) cũng làm bất hoạt gần hết enzym. Muốn giữ enzym thì phải dùng dạng **bột sống**, không đun.
> - **pH**: amylase hoạt động tốt ở pH gần trung tính. Đi qua **dạ dày** (pH 1,5–3), enzym uống vào bị bất hoạt phần lớn.
> - **Kết luận thận trọng**: hoạt tính enzym của mạch nha **đã được chứng minh in vitro**. Còn công năng **tiêu thực, hóa tích** theo YHCT (kể cả của sao mạch nha, tiêu mạch nha vốn rất ít enzym) **chưa có thử nghiệm lâm sàng chuẩn** cho thấy là do amylase. Có thể còn những cơ chế khác (chất xơ, chất tạo mùi khi sao). Không nên quy toàn bộ công năng cho một enzym.

### 7.4. Chất hoạt hóa

**Chất hoạt hóa** (activator) làm tăng tốc độ phản ứng, hoặc chuyển enzym từ dạng không hoạt động sang dạng hoạt động. Thường là phân tử nhỏ hoặc ion:

- **Kim loại**: Ca^2+^, Fe^2+^, Mg^2+^, Mn^2+^, Zn^2+^, K^+^.
- **Anion**: Br^−^, Cl^−^ (vd Cl^−^ hoạt hóa amylase nước bọt).

Cơ chế: tạo một vị trí tích điện dương để hút nhóm tích điện âm của cơ chất; thay đổi cấu hình không gian, ổn định cấu trúc bậc 3, bậc 4 của enzym; làm cầu nối giữa cơ chất với enzym hoặc coenzym; tham gia oxy hóa khử. Một số **coenzym** cũng được xem như chất hoạt hóa, ví dụ NAD^+^.

### 7.5. Chất ức chế thuận nghịch

**Chất ức chế** gắn vào enzym và làm giảm hoặc mất hoạt tính. Giáo trình mô tả 3 kiểu ức chế **thuận nghịch**:

| | **Cạnh tranh** (competitive) | **Không cạnh tranh** (noncompetitive) | **Phi cạnh tranh** (uncompetitive) |
|---|---|---|---|
| Chất ức chế gắn vào | **Trung tâm hoạt động** (cấu trúc **giống cơ chất**) | Vị trí **khác** trung tâm hoạt động, gắn được cả E lẫn ES | **Chỉ phức hợp ES**, ở vị trí khác trung tâm hoạt động |
| Phản ứng | E + I ⇌ EI | E + I ⇌ EI; ES + I ⇌ ESI | ES + I ⇌ ESI |
| Tăng [S] có khắc phục được không? | **Có** (cơ chất "thắng" chất ức chế) | **Không** | **Không**, còn làm ức chế **mạnh hơn** (vì có nhiều ES hơn để I gắn) |
| **K~m~** | **Tăng** | Không đổi | **Giảm** |
| **V~max~** | Không đổi | **Giảm** | **Giảm** |
| Đồ thị Lineweaver–Burk | Các đường **cắt nhau trên trục tung** (1/V~max~) | Các đường **cắt nhau trên trục hoành** (−1/K~m~) | Các đường **song song** |
| Ví dụ trong sách | **Malonat**, oxalat, glutarat ức chế **succinat dehydrogenase** | Ion kim loại nặng **Pb**, **Hg** | — |

**Ví dụ kinh điển về ức chế cạnh tranh.** Succinat dehydrogenase (chu trình citric) biến succinat (^−^OOC–CH~2~–CH~2~–COO^−^) thành fumarat. **Malonat** (^−^OOC–CH~2~–COO^−^) chỉ ngắn hơn một nhóm CH~2~. Nó chui vào trung tâm hoạt động nhưng không bị khử hydro được, nên "chiếm chỗ" của succinat.

> [!bay] Ba câu hỏi "đọc đồ thị" hay gặp
> - **V~max~ không đổi** → chắc chắn là **cạnh tranh**: vì ở [S] rất lớn, cơ chất đẩy hết chất ức chế ra.
> - **K~m~ không đổi** → **không cạnh tranh**: chất ức chế không làm thay đổi sự gắn của S, chỉ làm một phần enzym "chết".
> - **Hai đường song song** (K~m~ và V~max~ cùng giảm một tỉ lệ) → **phi cạnh tranh**.
> - Đừng nhầm hai tên gọi: "**không** cạnh tranh" (noncompetitive) và "**phi** cạnh tranh" (uncompetitive) là **hai kiểu khác nhau**.

> [!vi-du] "Không cạnh tranh" thuần túy ít gặp
> Giáo trình (và nhiều sách) mô tả kiểu "không cạnh tranh" với K~m~ giữ nguyên. Thực tế, đa số chất ức chế gắn ngoài trung tâm hoạt động làm thay đổi **cả K~m~ lẫn V~max~** ở mức khác nhau. Sách hiện đại gọi đây là **ức chế hỗn hợp** (mixed); "không cạnh tranh thuần túy" chỉ là một trường hợp riêng của nó. Đi thi dùng định nghĩa của giáo trình.

### 7.6. Ức chế không thuận nghịch (bổ sung ngoài giáo trình)

Chất ức chế **gắn cộng hóa trị** (hoặc gắn cực chặt) vào enzym, thường vào acid amin của trung tâm hoạt động. Enzym bị **hỏng vĩnh viễn**. Hoạt tính chỉ phục hồi khi cơ thể **tổng hợp enzym mới**. Tăng [S] không có tác dụng; trên đồ thị, kết quả giống như **giảm lượng enzym** (V~max~ giảm).

| Chất | Enzym bị ức chế | Hậu quả / ứng dụng |
|---|---|---|
| **Phospho hữu cơ** (thuốc trừ sâu; khí độc thần kinh), DFP | **Acetylcholinesterase** (gắn vào serin) | Acetylcholin ứ đọng → **ngộ độc** (co đồng tử, tăng tiết, co giật, suy hô hấp) |
| **Aspirin** | **Cyclooxygenase (COX)**, acetyl hóa serin | Tiểu cầu không tổng hợp lại được enzym nên tác dụng chống kết tập kéo dài **suốt đời tiểu cầu** (7–10 ngày) |
| **Penicillin** | Transpeptidase tạo vách vi khuẩn | Diệt khuẩn |
| **Furanocoumarin** của **bưởi chùm** (grapefruit) | **CYP3A4** ở ruột (bất hoạt "tự sát") | Tăng nồng độ nhiều thuốc trong máu (một số statin, thuốc chẹn kênh calci, thuốc ức chế miễn dịch) |

> [!ung-dung] Cấp cứu ngộ độc phospho hữu cơ
> Phải xử trí cùng lúc hai việc. **Atropin** chặn thụ thể muscarinic của acetylcholin đang ứ đọng. **Pralidoxim** (PAM) "giật" nhóm phospho ra khỏi serin để **tái hoạt hóa** enzym. PAM chỉ hiệu quả khi dùng **sớm**: để lâu, phức hợp enzym–phospho bị "lão hóa" và không gỡ ra được nữa, khi đó ức chế trở thành **không thuận nghịch thật sự**.

## 8. Điều hòa hoạt động enzym

Tế bào không để mọi enzym chạy hết công suất. Giáo trình nói tới **enzym dị lập thể** và **zymogen** (mục 3.3); bảng sau tổng hợp đầy đủ các cách điều hòa thường gặp ở môn Hóa sinh.

| Cách điều hòa | Cơ chế | Tốc độ | Ví dụ |
|---|---|---|---|
| **Dị lập thể** | Chất điều hòa gắn **không cộng hóa trị** vào vị trí dị lập thể; thuận nghịch | Tức thì (giây) | PFK: ATP, citrat ức chế; AMP, ADP hoạt hóa. **Ức chế ngược**: sản phẩm cuối ức chế enzym đầu con đường |
| **Biến đổi cộng hóa trị** (bổ sung) | Gắn/tháo **nhóm phosphat** (kinase/phosphatase) vào Ser, Thr, Tyr; thuận nghịch | Nhanh (giây – phút), thường theo **hormon** | Glucagon, adrenalin → phosphoryl hóa → **glycogen phosphorylase hoạt động**, **glycogen synthase bất hoạt** (hs-07) |
| **Cắt hoạt hóa zymogen** | Thủy phân cắt một đoạn peptid; **không thuận nghịch** | Nhanh, một lần | Pepsinogen → pepsin; trypsinogen → trypsin; prothrombin → thrombin; dòng thác đông máu |
| **Thay đổi lượng enzym** (bổ sung) | **Cảm ứng** hoặc **kìm hãm** tổng hợp enzym ở mức gen; tăng/giảm phân hủy | Chậm (giờ – ngày) | Rượu, thuốc chống động kinh, rifampicin **cảm ứng** CYP và GGT; insulin cảm ứng glucokinase |
| **Phân khu** (bổ sung) | Enzym và cơ chất nằm ở các ngăn khác nhau của tế bào | — | Tổng hợp acid béo ở bào tương; β-oxy hóa ở ty thể |

> [!ung-dung] Vì sao GGT tăng ở người uống rượu nhiều?
> Rượu **cảm ứng** gan tổng hợp thêm GGT. Vì thế GGT có thể tăng ngay cả khi tế bào gan chưa bị hủy nhiều. Sau vài tuần ngừng rượu, GGT giảm dần. Đây là một ví dụ của điều hòa bằng **thay đổi lượng enzym**, khác với cơ chế "tế bào vỡ, enzym tràn ra" của ALT, AST (mục 9).

## 9. Enzym trong chẩn đoán (bổ sung ngoài giáo trình)

**Nguyên lý.** Phần lớn enzym hoạt động **trong tế bào**. Khi tế bào bị tổn thương hoặc tăng sinh, enzym **thoát vào máu**. Do đó hoạt độ enzym huyết thanh tăng, phản ánh **mức độ tổn thương** và, nhờ phân bố mô khác nhau, gợi ý **cơ quan nào** bị tổn thương. Ngoài ra, enzym có thể tăng do **cảm ứng tổng hợp** (GGT, ALP) hoặc do **tắc đường thải** (ALP, amylase).

Khoảng tham chiếu dưới đây ở người lớn, đo ở 37 °C, chỉ để **tham khảo; mỗi phòng xét nghiệm có khoảng riêng**. (Riêng ALT/AST, giáo trình chương Hóa sinh gan ghi nam 10–50, nữ 10–35 U/L — xem hs-17.)

| Enzym | Lớp | Có nhiều ở | Tăng gặp trong | Tham chiếu (tham khảo) |
|---|---|---|---|---|
| **ALT** (GPT, alanin aminotransferase) | 2 | **Bào tương tế bào gan** (khá đặc hiệu gan) | **Viêm gan** do virus, thuốc, độc chất; gan nhiễm mỡ | ≤ 40 U/L |
| **AST** (GOT, aspartat aminotransferase) | 2 | Gan (bào tương + **ty thể**), **tim**, cơ vân, hồng cầu | Viêm gan; tổn thương gan do **rượu** (AST/ALT > 2); nhồi máu cơ tim; tổn thương cơ | ≤ 40 U/L |
| **CK** (creatin kinase) và **CK-MB** | 2 | Cơ vân (MM), **cơ tim** (MB), não (BB) | Tổn thương cơ (tiêu cơ vân, tiêm bắp, gắng sức); **CK-MB**: nhồi máu cơ tim | CK nam khoảng 24–190, nữ 24–170 U/L; CK-MB ≤ 24 U/L |
| **LDH** (lactat dehydrogenase) | 1 | Hầu hết các mô | Rất kém đặc hiệu: tan máu, nhồi máu cơ tim (tăng muộn, kéo dài), bệnh gan, u lympho | Khoảng 135–225 U/L (phương pháp IFCC) |
| **Amylase** | 3 | **Tụy**, tuyến nước bọt | **Viêm tụy cấp**; viêm tuyến mang tai (quai bị) | Khoảng 30–110 U/L |
| **Lipase** | 3 | **Tụy** | **Viêm tụy cấp** (đặc hiệu hơn amylase, tăng kéo dài hơn) | Khoảng 13–60 U/L |
| **ALP** (phosphatase kiềm) | 3 | Gan – **đường mật**, **xương** (tạo cốt bào), nhau thai, ruột | **Tắc mật**; bệnh xương (còi xương, Paget, u di căn xương); bình thường cao ở **trẻ đang lớn**, **phụ nữ có thai** | Khoảng 40–130 U/L (người lớn) |
| **GGT** (γ-glutamyl transferase) | 2 | Gan – **đường mật**, thận, tụy | **Tắc mật**, **rượu**, thuốc cảm ứng enzym | Nam khoảng 11–50, nữ 7–32 U/L |

**Đọc theo cặp, theo kiểu tăng:**

- **Viêm gan cấp** (virus, thuốc): ALT, AST tăng mạnh, có thể **trên 10 lần** giới hạn trên; thường **ALT > AST**.
- **Tổn thương gan do rượu**: **AST/ALT > 2**, GGT tăng. Rượu làm thiếu B~6~ (PLP), mà ALT cần PLP nhiều hơn AST, nên ALT tăng ít.
- **Tắc mật**: **ALP + GGT** cùng tăng. Nếu ALP tăng mà GGT bình thường, nghĩ tới nguồn **xương** (hoặc trẻ em, thai kỳ).
- **Viêm tụy cấp**: amylase hoặc lipase **≥ 3 lần** giới hạn trên, kèm đau bụng điển hình.
- **Nhồi máu cơ tim** (kinh điển): CK-MB tăng sau **3–6 giờ**, đỉnh 12–24 giờ, về bình thường sau **2–3 ngày**; LDH tăng muộn hơn và kéo dài khoảng 1–2 tuần.

> [!cap-nhat] Chẩn đoán nhồi máu cơ tim ngày nay dùng troponin
> Các sách cũ dùng bộ ba "CK – AST – LDH" để chẩn đoán nhồi máu cơ tim. Hiện nay (Định nghĩa toàn cầu về nhồi máu cơ tim; hướng dẫn của Bộ Y tế), dấu ấn được chọn là **troponin tim (cTnT, cTnI), nhất là loại độ nhạy cao (hs-troponin)**. Troponin là **protein cấu trúc**, **không phải enzym**, nhưng đặc hiệu cho cơ tim hơn nhiều. **CK-MB** chỉ còn vai trò phụ (vd phát hiện nhồi máu tái phát, vì CK-MB về bình thường nhanh). AST và LDH không còn dùng để chẩn đoán nhồi máu cơ tim.

> [!bay]
> - ALT, AST cao cho biết **tế bào gan đang bị hủy**, **không** đo **chức năng** gan. Chức năng tổng hợp của gan đánh giá bằng **albumin**, **thời gian prothrombin**. Ở xơ gan giai đoạn cuối, ALT có thể **gần bình thường** vì còn ít tế bào gan để hủy.
> - **Tan máu** khi lấy mẫu làm **LDH, AST, K^+^** tăng giả, vì hồng cầu chứa nhiều các chất này.
> - Mẫu để lâu ở nhiệt độ phòng hoặc đông – rã nhiều lần làm hoạt độ enzym **giảm giả** (mục 7.2).

## 10. Enzym trong điều trị (bổ sung ngoài giáo trình)

**a) Dùng enzym làm thuốc**

| Enzym | Dùng cho |
|---|---|
| **Men tụy** (pancreatin: lipase, amylase, protease) | Suy tụy ngoại tiết (viêm tụy mạn, xơ nang); viên **bao tan ở ruột** để không bị acid dịch vị phá hủy (mục 7.3) |
| **Thuốc tiêu sợi huyết** (streptokinase, alteplase) | Hoạt hóa plasminogen → plasmin làm tan cục máu đông: nhồi máu cơ tim, đột quỵ nhồi máu não **sớm** |
| **L-asparaginase** | Bạch cầu cấp dòng lympho: tế bào ung thư này thiếu asparagin, bị "bỏ đói" |
| **Liệu pháp thay thế enzym** (vd imiglucerase) | Bệnh di truyền thiếu enzym, vd bệnh **Gaucher** (thiếu glucocerebrosidase) |

**b) Thuốc là chất ức chế enzym** — áp dụng trực tiếp kiến thức mục 7

| Thuốc | Enzym đích | Kiểu ức chế | Dùng trong |
|---|---|---|---|
| **Statin** (atorvastatin, lovastatin…) | **HMG-CoA reductase** (bước giới hạn tốc độ tổng hợp cholesterol) | **Cạnh tranh** | Tăng cholesterol máu |
| **Methotrexat** | Dihydrofolat reductase (tạo FH~4~) | **Cạnh tranh** (cấu trúc giống acid folic) | Ung thư, viêm khớp dạng thấp |
| **Allopurinol** | **Xanthin oxidase** (tạo acid uric) | Cơ chất giả; sản phẩm oxypurinol gắn rất chặt | **Gout** (hs-11) |
| Captopril, enalapril | Enzym chuyển angiotensin (ACE) | Cạnh tranh | Tăng huyết áp |
| **Aspirin** | COX | **Không thuận nghịch** | Giảm đau, chống kết tập tiểu cầu |
| Acarbose | α-glucosidase ruột | Cạnh tranh | Đái tháo đường typ 2 (giảm đường huyết sau ăn) |

> [!yhct] Hoạt chất dược liệu ức chế enzym — ví dụ chính xác và mức bằng chứng
> | Dược liệu | Hoạt chất | Enzym bị ức chế | Mức bằng chứng |
> |---|---|---|---|
> | **Hồng khúc** (gạo men đỏ, *Monascus purpureus*) | **Monacolin K**, chính là **lovastatin** | HMG-CoA reductase (**cạnh tranh**) | **Lâm sàng**: nhiều thử nghiệm ở người cho thấy giảm LDL-cholesterol; vì chính là một statin nên **không dùng chung với statin** (hàm lượng, citrinin, tác dụng phụ: xem khung YHCT ở bài *Chuyển hóa lipid và lipoprotein*, mã hs-08) |
> | **Tang diệp** (lá dâu tằm) | **1-deoxynojirimycin** (giống glucose) | α-glucosidase ruột (**cạnh tranh**, giống acarbose) | **Lâm sàng nhỏ, ngắn hạn**: giảm đường huyết sau ăn; chưa đủ để thay thuốc |
> | **Thạch tùng răng cưa** (*Huperzia serrata*) | **Huperzin A** | **Acetylcholinesterase** (thuận nghịch) | **Lâm sàng**: thử nghiệm ở Trung Quốc về sa sút trí tuệ, chất lượng phương pháp **thấp**; chưa được các hướng dẫn quốc tế khuyến cáo |
> | **Cam thảo** | Acid glycyrrhetinic (chất chuyển hóa của glycyrrhizin) | **11β-HSD2** ở thận (enzym bất hoạt cortisol) | **Lâm sàng rõ** (về tác dụng phụ): **giả cường aldosteron** (hạ K^+^, tăng huyết áp) khi dùng liều cao, kéo dài; cơ chế và lưu ý kê đơn: khung YHCT ở bài *Hóa sinh hormon*, mã hs-14 |
> | **Hoàng liên, Hoàng bá** | **Berberin** | **CYP2D6, CYP2C9, CYP3A4** | **Dược động học ở người** (dùng nhiều ngày làm giảm hoạt tính các CYP này) → nguy cơ **tương tác thuốc** |
>
> **Tách bạch hai tầng:** cột "enzym bị ức chế" là **cơ chế hóa sinh đã chứng minh**. Nó **không đồng nghĩa** với công năng theo YHCT (vd Tang diệp "sơ phong thanh nhiệt"; Cam thảo "điều hòa các vị thuốc"). Có rất nhiều bài báo "cao chiết X ức chế enzym Y **in vitro**". Phần lớn dùng nồng độ **cao hơn nhiều** so với nồng độ đạt được trong máu, nên **không suy ra được tác dụng điều trị**. Ngược lại, ức chế CYP lại là lý do thật để **hỏi bệnh nhân đang dùng thuốc tây gì** trước khi kê thuốc thang.

## Tóm tắt

| Chủ đề | Điểm cốt lõi |
|---|---|
| Bản chất | Xúc tác sinh học, protein; không đổi cân bằng; đặc hiệu tuyệt đối/tương đối |
| Gọi tên | 4 cách: cơ chất + ase; tác dụng + ase; cơ chất + tác dụng + ase; tên thường gọi |
| Phân loại EC | 6 lớp: oxy hóa khử – vận chuyển nhóm – thủy phân – phân cắt – đồng phân – tổng hợp (cần ATP); mã 4 số (hexokinase 2.7.1.1) |
| Cấu tạo | Holoenzym = apoenzym + cofactor (ion kim loại/coenzym; nhóm phụ gắn chặt) |
| Trung tâm hoạt động | Ser, Cys, Glu, Lys, His, Trp; Fischer (khóa – chìa) và Koshland (cảm ứng không gian) |
| Dạng cấu trúc | Đơn/đa chuỗi; dị lập thể (PFK); isoenzym (LDH 5 dạng H/M; CK 3 dạng BB, MB, MM); zymogen (-ogen, pro-); phức hợp đa enzym (pyruvat dehydrogenase) |
| Coenzym | NAD^+^/NADP^+^ (B~3~, 2e + 1H^+^); FMN/FAD (B~2~, 2e + 2H^+^); hem (Fe^2+^/Fe^3+^); lipoic; TPP (B~1~, CO~2~); CoA (B~5~, acyl); SAM (methyl); FH~4~ (1C); biotin (carboxyl hóa); PLP (B~6~, amin) |
| Cơ chế | ΔG < 0 là điều kiện cần; enzym giảm E~a~ qua phức hợp ES |
| Động học | v = V~max~[S]/(K~m~ + [S]); K~m~ = [S] ở V~max~/2; K~m~ nhỏ = ái lực lớn; [S] ≥ 100 K~m~ để đạt V~max~; LB: 1/V~max~ (trục tung), −1/K~m~ (trục hoành), dốc K~m~/V~max~ |
| Yếu tố ảnh hưởng | [S], [E]; nhiệt độ (Q~10~ = 2, biến tính từ 40–50 °C); pH (tối ưu 7–8; pepsin ~2); chất hoạt hóa (ion); chất ức chế |
| Ức chế | Cạnh tranh: K~m~↑; không cạnh tranh: V~max~↓; phi cạnh tranh: cả hai ↓ (song song); không thuận nghịch: phospho hữu cơ, aspirin |
| Lâm sàng | ALT (gan), AST, CK-MB, LDH, amylase/lipase (tụy), ALP/GGT (mật); troponin thay CK-MB trong nhồi máu cơ tim |
