---
title: Khí máu và sự thăng bằng acid – base
thoi-gian: 60 phút
muc-tieu:
- Trình bày được cách máu vận chuyển O~2~ (vai trò hemoglobin) và CO~2~ (3 dạng: bicarbonat, carbamin, hòa tan), kèm cơ chế đẳng hydro và sự đổi chỗ Cl^−^.
- Kể được các hệ đệm của huyết tương, hồng cầu, tế bào; viết và dùng được phương trình Henderson–Hasselbalch cho hệ đệm bicarbonat.
- Giải thích được vai trò của phổi (điều chỉnh pCO~2~) và thận (tái hấp thu HCO~3~^−^, bài tiết acid chuẩn độ và NH~4~^+^) trong điều hòa thăng bằng acid – base.
- Nêu được ý nghĩa các thông số khí máu: pH, pCO~2~, bicarbonat thực (AB), bicarbonat chuẩn (SB), base đệm (BB), base dư (BE); tính được khoảng trống anion.
- Phân biệt được 4 rối loạn acid – base nguyên phát, cơ chế bù của từng loại và các rối loạn hỗn hợp; đọc được một kết quả khí máu đơn giản.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. **O~2~** đi trong máu chủ yếu nhờ **Hb** (1 g Hb chở 1,34 ml O~2~). **CO~2~** đi dưới 3 dạng: **HCO~3~^−^ 78%**, **carbamin 13%**, **hòa tan 9%** (số liệu giáo trình).
> 2. Trong hồng cầu, **carbonic anhydrase** biến CO~2~ + H~2~O thành H~2~CO~3~ → H^+^ + HCO~3~^−^. H^+^ được **Hb khử oxy** giữ lại (**cơ chế đẳng hydro**); HCO~3~^−^ ra huyết tương, đổi lấy **Cl^−^** đi vào (**sự đổi chỗ clorid**).
> 3. **pH = pK + log [HCO~3~^−^] / (0,03 × pCO~2~)** với pK = 6,1. Tỷ số **20/1** ⇒ pH **7,40**. Thận lo **tử số** (HCO~3~^−^), phổi lo **mẫu số** (pCO~2~).
> 4. Bốn rối loạn nguyên phát: **toan / kiềm chuyển hóa** (HCO~3~^−^ đổi trước) và **toan / kiềm hô hấp** (pCO~2~ đổi trước). Bù trừ luôn làm thông số còn lại thay đổi **cùng chiều**, kéo tỷ số về gần 20/1.
> 5. Đọc khí máu: **pH** (toan hay kiềm) → thông số nào **giải thích** được pH (nguyên phát) → có **bù** chưa → nếu toan chuyển hóa thì tính **khoảng trống anion** = Na^+^ − (Cl^−^ + HCO~3~^−^), bình thường ≈ 8–12 mmol/L.

Bài này dựa trên hai bài đã học. Cấu trúc **hemoglobin**, đường cong phân ly oxy, 2,3-DPG, HbF, dẫn xuất carbamin: xem **hs-03, mục 4**. Phân áp khí, định luật **Henry, Dalton**, bảng phân áp O~2~ – CO~2~ ở phổi và mô: xem **vat-ly/vl-03, mục 3**. Ở đây chỉ nhắc lại những gì cần để hiểu thăng bằng acid – base.

Vì sao hai chủ đề "khí máu" và "acid – base" đi chung một chương? Vì **CO~2~ chính là acid**. Mỗi phút mô sinh ra khoảng 200 ml CO~2~. Khi tan vào nước, CO~2~ tạo H~2~CO~3~ và giải phóng H^+^. Nếu không có cơ chế chở CO~2~ đi khéo léo, máu tĩnh mạch sẽ toan nặng. Trong khi đó, pH máu động mạch chỉ được dao động trong một khoảng hẹp quanh **7,40** (Giáo trình tr. 263).

## 1. Sự vận chuyển khí trong máu

### 1.1. Vận chuyển O~2~ — vai trò của hemoglobin

Oxy tan trong huyết tương **rất kém**. Ở 38 °C, 1 lít huyết tương chỉ hòa tan được **2,3 ml O~2~**. Một lít máu có khoảng **150 g Hb**, chở được khoảng **200 ml O~2~**, tức **gấp 87 lần** huyết tương (Giáo trình tr. 263).

- **1 g Hb gắn tối đa 1,34 ml O~2~** (150 × 1,34 ≈ 200 ml).
- Hb là chất mang O~2~ lý tưởng: bão hòa **98%** ở phổi, nhưng chỉ còn **35%** ở cơ đang hoạt động. Nghĩa là Hb vừa "nhặt" được gần hết O~2~ ở phổi, vừa "thả" được phần lớn O~2~ ở nơi cần.
- Có được điều đó là nhờ Hb gắn O~2~ theo kiểu **hợp tác** (giáo trình gọi là *sự cộng tác*): một hem đã gắn O~2~ thì các hem còn lại gắn dễ hơn. Kết quả là đường cong phân ly **hình sigma** (xem hs-03).

> [!vi-du] Tính hàm lượng O~2~ trong máu
> Hàm lượng O~2~ ≈ 1,34 × Hb (g/dL) × SaO~2~ + 0,003 × pO~2~ (ml/dL). *(Công thức bổ sung, dùng trong lâm sàng.)*
> Người có Hb 15 g/dL, SaO~2~ 98%, pO~2~ 100 mmHg: 1,34 × 15 × 0,98 + 0,3 ≈ 19,7 + 0,3 = **20 ml O~2~/dL**. Phần hòa tan (0,3) chỉ chiếm khoảng 1,5%.
> Vì vậy người **thiếu máu** (Hb 7,5 g/dL) dù SaO~2~ vẫn 98% thì chỉ còn khoảng **một nửa** lượng O~2~. Đo SpO~2~ bình thường **không** loại trừ được thiếu oxy mô.

### 1.2. Các yếu tố ảnh hưởng đến sự gắn O~2~ của Hb

Giáo trình tóm tắt bằng một cân bằng (Giáo trình tr. 264):

=> HHb·(DPG, CO~2~) + O~2~ ⇌ HbO~2~ + CO~2~ + DPG + H^+^

Đọc phương trình theo nguyên lý Le Chatelier: tăng **DPG, CO~2~ hoặc H^+^** (vế phải) sẽ đẩy cân bằng sang trái, tức Hb **nhả O~2~**.

| Yếu tố tăng | Ái lực Hb với O~2~ | Ý nghĩa |
|---|---|---|
| **2,3-DPG** | Giảm | Tăng khi lên núi cao (dưới 5500 m), trở về bình thường khi xuống đồng bằng → mô dùng O~2~ hiệu quả hơn |
| **pCO~2~** | Giảm | Ở mô, CO~2~ nhiều → nhả O~2~ |
| **[H^+^] (pH giảm)** — hiệu ứng **Bohr** | Giảm | Mô hoạt động sinh acid → nhả O~2~ |
| **Nhiệt độ** | Giảm | Cơ đang co, sốt → nhả O~2~ |

**HbA và HbF** (bảng 16.1, Giáo trình tr. 264). HbF có 2 chuỗi **γ** thay cho 2 chuỗi β. Ở vị trí **143**, chuỗi β có **His^+^**, còn chuỗi γ có **Ser** (không tích điện). Do mất một điện tích dương, **2,3-DPG gắn vào HbF kém hơn**. Vì thế HbF có ái lực với O~2~ **cao hơn** HbA, và "hút" được O~2~ từ máu mẹ sang máu thai. (Cả hai đều còn α-NH~3~^+^ tự do và Lys^+^ 82.)

> [!vi-du] Hiệu ứng Haldane — "mặt kia" của hiệu ứng Bohr *(bổ sung)*
> - **Bohr**: H^+^ và CO~2~ làm Hb **nhả O~2~**.
> - **Haldane**: ngược lại, khi Hb **nhả O~2~** thì nó **gắn được nhiều CO~2~ và H^+^ hơn** (Hb khử oxy là acid yếu hơn và tạo carbamin dễ hơn).
> - Hệ quả: ở **mô**, việc nhả O~2~ giúp máu nhận thêm CO~2~. Ở **phổi**, Hb gắn O~2~ thì đẩy CO~2~ và H^+^ ra để thở ra. Hai hiệu ứng là một cơ chế nhìn từ hai phía.

### 1.3. Vận chuyển CO~2~ — 3 dạng

CO~2~ trong máu được chở dưới 3 dạng (bảng 16.2, Giáo trình tr. 264–265):

| Dạng | Tỷ lệ (giáo trình) | Tạo thành ở đâu, thế nào |
|---|---|---|
| **Bicarbonat (HCO~3~^−^)** | **78%** | Trong hồng cầu, nhờ enzym **carbonic anhydrase (CA)** |
| **Carbamin** | **13%** | CO~2~ gắn vào nhóm **–NH~2~ tự do** đầu N của chuỗi α và β của Hb |
| **Hòa tan** | **9%** | CO~2~ tan vật lý (định luật Henry) |

**a) Dạng bicarbonat.** Phần lớn CO~2~ khuếch tán vào hồng cầu. Ở đó **carbonic anhydrase** (một enzym chứa kẽm, có rất nhiều trong hồng cầu, gần như không có trong huyết tương) xúc tác:

=> CO~2~ + H~2~O ⇌ H~2~CO~3~ ⇌ H^+^ + HCO~3~^−^

Không có enzym, phản ứng hydrat hóa CO~2~ xảy ra quá chậm so với thời gian máu đi qua mao mạch (chưa tới 1 giây). Có CA, phản ứng nhanh hơn hàng nghìn lần. Bước thứ hai (H~2~CO~3~ phân ly) xảy ra tự phát, không cần enzym.

**b) Dạng carbamin** (Giáo trình tr. 264–265):

=> R–NH~2~ + CO~2~ ⇌ R–NH–COO^−^ + H^+^

Vì pH trong hồng cầu là **7,20**, các nhóm amin phần lớn ở dạng **R–NH~3~^+^**. Muốn gắn CO~2~, chúng phải nhả H^+^ trước:

=> R–NH~3~^+^ ⇌ R–NH~2~ + H^+^

Như vậy **cả hai con đường** (tạo HCO~3~^−^ và tạo carbamin) **đều sinh ra H^+^**. Số H^+^ này phải được đệm ngay.

**c) Dạng hòa tan**: CO~2~ tan tốt hơn O~2~ khoảng 20 lần (vl-03), nhưng vẫn chỉ chiếm phần nhỏ. Tuy nhiên đây là dạng quyết định **pCO~2~** mà máy khí máu đo được.

> [!bay] Tỷ lệ các dạng CO~2~ khác nhau giữa các sách
> Giáo trình ghi **78 / 13 / 9** (%). Nhiều sách sinh lý khác ghi khoảng **70 / 20–23 / 7–10**. Tất cả đều thống nhất: **HCO~3~^−^ nhiều nhất, carbamin thứ hai, hòa tan ít nhất**. Đi thi trả lời theo giáo trình.
> Cũng lưu ý: carbamin gắn vào **nhóm amin** của globin, **không** gắn vào Fe của hem. Vì thế CO~2~ không cạnh tranh chỗ với O~2~ như CO.

### 1.4. Khả năng đệm của hemoglobin và cơ chế đẳng hydro

Ngoài chở O~2~ và một phần CO~2~, Hb còn là **hệ đệm** vì giữ được H^+^. Nhóm nhận H^+^ là **4 nhóm amin đầu N** và đặc biệt các **vòng imidazol của His**: mỗi phân tử Hb có **38 gốc His** trên 4 chuỗi (Giáo trình tr. 265). Imidazol có pK~a~ gần 6–7, rất sát pH máu, nên đệm tốt nhất trong vùng này.

Nhóm amin đầu N của chuỗi α và chuỗi β tham gia ba quá trình theo cách khác nhau (bảng 16.3, Giáo trình tr. 265):

| Quá trình | Đầu N chuỗi α | Đầu N chuỗi β |
|---|---|---|
| Tạo carbamin | Có | Có |
| Gắn 2,3-DPG | Không | **Có** |
| Gắn H^+^ (hiệu ứng Bohr) | **Có** | Không |

**Cơ chế đẳng hydro** (*isohydric*). HbO~2~ là acid mạnh hơn HHb. Ở mô, khi HbO~2~ nhả O~2~ để thành HHb, nó lập tức **nhận H^+^** vừa sinh ra từ H~2~CO~3~. Do đó máu nhận thêm rất nhiều CO~2~ mà pH **hầu như không đổi** (pH máu tĩnh mạch chỉ thấp hơn động mạch vài phần trăm đơn vị). Ở phổi xảy ra chiều ngược lại: Hb gắn O~2~, trở thành acid mạnh hơn, **nhả H^+^**. H^+^ kết hợp HCO~3~^−^ thành H~2~CO~3~, rồi CA tách thành CO~2~ + H~2~O để thở ra (hình 16.2, Giáo trình tr. 266).

Ai đệm số H^+^ sinh ra khi vận chuyển CO~2~? (bảng 16.4, Giáo trình tr. 266):

| Cách đệm H^+^ | Tỷ lệ |
|---|---|
| Hemoglobin (đệm thông thường) | 50% |
| Cơ chế đẳng hydro (cũng của Hb) | 40% |
| Các hệ đệm khác (phosphat hồng cầu, protein huyết tương) | 10% |

Như vậy **Hb gánh tới 90%** lượng H^+^ sinh ra từ CO~2~.

**Sự đổi chỗ clorid** (*chloride shift*, còn gọi hiện tượng Hamburger). HCO~3~^−^ tạo ra trong hồng cầu nhiều hơn ngoài huyết tương nên khuếch tán ra ngoài. Để giữ cân bằng điện tích, **Cl^−^ đi vào hồng cầu** thay thế. Sự trao đổi này qua một protein trao đổi anion của màng hồng cầu (protein **band 3**). Xem thêm chương 15 (hs-15, Trao đổi muối – nước).

![Hình 1. Hồng cầu ở mao mạch mô: carbonic anhydrase, cơ chế đẳng hydro và sự đổi chỗ clorid](trao-doi-co2-hong-cau.svg)

> [!bay]
> - Ở **mô**: HCO~3~^−^ đi **ra** huyết tương, Cl^−^ đi **vào** hồng cầu. Ở **phổi**: ngược lại, Cl^−^ đi ra, HCO~3~^−^ đi vào để chuyển lại thành CO~2~.
> - Phần lớn CO~2~ được chở **trong huyết tương dưới dạng HCO~3~^−^**, nhưng HCO~3~^−^ đó được **sinh ra trong hồng cầu** (nơi có CA).
> - Do nhận thêm Cl^−^ và nước, hồng cầu ở máu tĩnh mạch **hơi to hơn** hồng cầu ở máu động mạch.

> [!ung-dung] Thuốc ức chế carbonic anhydrase — acetazolamid
> - **Acetazolamid** ức chế CA ở ống thận, mắt, đám rối mạch mạc. Dùng điều trị **glôcôm** (giảm tiết thủy dịch), phòng **say độ cao**, đôi khi làm lợi tiểu.
> - Vì thận không tái hấp thu được HCO~3~^−^, thuốc gây **toan chuyển hóa nhẹ, tăng Cl^−^** (khoảng trống anion bình thường, xem mục 3.6). Trong say độ cao, chính mức toan nhẹ này kích thích tăng thông khí, giúp thích nghi nhanh hơn.

## 2. Sự thăng bằng acid – base

### 2.1. Cơ sở hóa lý

#### a) Khái niệm pH

Nước phân ly rất yếu: H~2~O ⇌ H^+^ + OH^−^. Nồng độ nước nguyên chất là 1000/18 = **55,5 mol/L**, gần như không đổi, nên (Giáo trình tr. 266–267):

=> [H^+^] × [OH^−^] = K~eq~ × [H~2~O] = 1,8×10^−16^ × 55,5 ≈ 1,0×10^−14^

Trong nước nguyên chất [H^+^] = [OH^−^] = 10^−7^ mol/L. Sorensen (1909) đặt **pH = −log[H^+^]**. Lấy −log hai vế ta có **pH + pOH = 14**. Ví dụ [H^+^] = 10^−2^ M thì [OH^−^] = 10^−12^ M.

> [!vi-du] pH nhỏ thay đổi, [H^+^] thay đổi lớn
> pH là thang **logarit**. pH 7,40 ứng với [H^+^] ≈ **40 nmol/L**; pH 7,10 ứng với ≈ 80 nmol/L (gấp đôi); pH 7,00 ứng với 100 nmol/L. Vì vậy pH máu "chỉ" giảm từ 7,40 xuống 7,10 đã là toan rất nặng.

#### b) Phương trình Henderson–Hasselbalch

Với một acid yếu HA ⇌ H^+^ + A^−^, ta có K = [H^+^][A^−^]/[HA]. Lấy −log hai vế (Giáo trình tr. 267):

=> pH = pK + log ([A^−^] / [HA])

Hệ đệm **đệm tốt nhất khi [A^−^] = [HA]**, tức khi **pH = pK**.

Áp dụng cho hệ đệm bicarbonat của huyết tương:

=> pH = pK + log ([HCO~3~^−^] / [H~2~CO~3~])

Lượng H~2~CO~3~ thật trong máu rất nhỏ; nó cân bằng với CO~2~ hòa tan. Theo định luật Henry, CO~2~ hòa tan tỷ lệ với pCO~2~: [CO~2~ hòa tan] = **α × pCO~2~**, với **α = 0,03** mmol/L cho mỗi mmHg ở 37 °C (giáo trình ghi đơn vị mEq/L). Phương trình thực hành là (Giáo trình tr. 268):

=> pH = 6,1 + log ([HCO~3~^−^] / (0,03 × pCO~2~))

*Giáo trình không ghi con số pK; giá trị **pK = 6,1** là hằng số chuẩn (ở 37 °C) dùng trong mọi sách.*

> [!vi-du] Tính thử
> - Người bình thường: HCO~3~^−^ = 24 mmol/L, pCO~2~ = 40 mmHg. Mẫu số = 0,03 × 40 = 1,2. Tỷ số = 24 / 1,2 = **20**. log 20 = 1,30. pH = 6,1 + 1,30 = **7,40**.
> - Toan chuyển hóa chưa bù: HCO~3~^−^ = 12, pCO~2~ = 40. Tỷ số = 12 / 1,2 = 10; log 10 = 1. pH = **7,10**.
> - Nếu phổi bù, hạ pCO~2~ xuống 26: mẫu số = 0,78; tỷ số ≈ 15,4; log ≈ 1,19. pH ≈ **7,29**, gần bình thường hơn.
> - Bài học: **pH phụ thuộc vào TỶ SỐ, không phụ thuộc giá trị tuyệt đối**. Giữ tỷ số 20/1 là giữ pH 7,40.

#### c) Vì sao hệ bicarbonat quan trọng dù pK = 6,1 xa pH 7,4?

Theo lý thuyết, một hệ đệm có pK 6,1 đệm kém ở pH 7,4. Nhưng hệ bicarbonat là **hệ thống mở** (Giáo trình tr. 268):

- Thêm acid mạnh: HCO~3~^−^ giảm, tạo H~2~CO~3~ → CO~2~ **được thở ra**. Vì CO~2~ thừa bị thải, tỷ số HCO~3~^−^/pCO~2~ ít thay đổi.
- Thêm base: base bị H~2~CO~3~ trung hòa, rồi hô hấp lại điều chỉnh pCO~2~.
- Nếu hô hấp không điều chỉnh được (ví dụ suy hô hấp), pCO~2~ thay đổi mạnh và hệ bicarbonat mất hiệu lực.

Giáo trình nêu 3 lý do hệ HCO~3~^−^/H~2~CO~3~ quan trọng: **nhạy với điều hòa của phổi và thận**, **dễ đo lường**, **có lượng lớn trong máu**. Phương trình Henderson–Hasselbalch là phương trình cơ bản mô tả trạng thái acid – base của cơ thể.

### 2.2. Các hệ đệm của cơ thể

pH máu động mạch bình thường là **7,38–7,42** (Giáo trình tr. 268). Mỗi ngày chuyển hóa sinh ra khoảng **100 mEq H^+^** (acid không bay hơi), chưa kể lượng CO~2~ khổng lồ.

| Nơi | Hệ đệm (dạng base / dạng acid) |
|---|---|
| **Huyết tương và dịch gian bào** | Bicarbonat **HCO~3~^−^ / H~2~CO~3~**; phosphat **HPO~4~^2−^ / H~2~PO~4~^−^**; protein **proteinat / protein** |
| **Hồng cầu** | Hemoglobinat / hemoglobin **KHb / HHb**; oxyhemoglobinat / oxyhemoglobin **KHbO~2~ / HHbO~2~** (cùng phosphat, bicarbonat) |
| **Trong tế bào** | K^+^, protein, các phosphat hữu cơ |

Khả năng đệm (Giáo trình tr. 269):

| Bảng 16.5 — Hệ đệm của máu | Khả năng đệm |
|---|---|
| Hemoglobin | **82%** |
| Protein | 10% |
| Bicarbonat | 7% |
| Phosphat | 1% |

Trong tế bào có nhiều K^+^, protein và phosphat hữu cơ, nên tế bào đệm tốt khi CO~2~ thay đổi. Đối với acid chuyển hóa, phần lớn được đệm **trong tế bào các mô**:

| Bảng 16.6 — Đệm acid chuyển hóa của cơ thể | Khả năng đệm |
|---|---|
| Tế bào của các mô | **52%** |
| Dịch ngoại bào | 42% |
| Hồng cầu | 6% |

> [!bay] Hệ đệm nào "mạnh nhất"?
> - Theo **bảng 16.5 của giáo trình**, trong **máu** hệ đệm **hemoglobin** chiếm phần lớn (**82%**). Con số này hợp lý khi xét việc đệm **acid carbonic** (CO~2~), vì hệ bicarbonat không thể tự đệm chính H~2~CO~3~ của nó.
> - Với **acid cố định** (acid lactic, thể ceton…), nhiều sách sinh lý lại coi **bicarbonat** là hệ đệm quan trọng nhất của **dịch ngoại bào**, nhờ lượng lớn và là hệ mở.
> - Xét **toàn cơ thể** đối với acid chuyển hóa, **tế bào các mô đệm nhiều nhất (52%)**, không phải máu.
> - Đi thi: câu hỏi "trong máu" → hemoglobin; "quan trọng vì được phổi và thận điều hòa, dễ đo" → bicarbonat; "toàn cơ thể" → tế bào các mô.

**Hệ đệm phosphat** đóng góp ít trong máu (1%) vì nồng độ thấp, dù pK (≈ 6,8) rất gần pH máu. Nó quan trọng **trong tế bào** và trong **nước tiểu** (xem 2.3c).

### 2.3. Sự điều hòa thăng bằng acid – base

Có ba tuyến bảo vệ, khác nhau về tốc độ:

| Tuyến | Tốc độ | Bản chất |
|---|---|---|
| **Hệ đệm** | Tức thì (giây) | Chỉ "chuyển" acid/base mạnh thành yếu, **không loại bỏ** được H^+^ |
| **Phổi** | Phút → giờ | Điều chỉnh **pCO~2~** (mẫu số) |
| **Thận** | Giờ → ngày | Điều chỉnh **HCO~3~^−^** (tử số), **thải thật sự** H^+^ ra ngoài |

#### a) Tác dụng của hệ đệm

Khi acid mạnh HCl vào cơ thể (Giáo trình tr. 269):

=> HCl + NaHCO~3~ ⇌ NaCl + H~2~CO~3~ → CO~2~ + H~2~O

CO~2~ dễ bay hơi được phổi thở ra, nên pCO~2~ không tăng. Cơ thể mất một phần HCO~3~^−^, nhưng tỷ số Henderson–Hasselbalch ít đổi nên pH ít đổi.

Khi base mạnh NaOH vào (Giáo trình tr. 270):

=> NaOH + H~2~CO~3~ ⇌ NaHCO~3~ + H~2~O

NaHCO~3~ tạo thành lại là base đệm của huyết tương. pH cũng rất ít thay đổi.

#### b) Điều hòa bởi phổi

Phổi biến cơ thể thành **hệ thống mở**. Mô tạo CO~2~ liên tục, khoảng **200 ml/phút**, và phổi thải liên tục (Giáo trình tr. 270).

- **pCO~2~ máu tỷ lệ nghịch với thông khí phế nang.** Thở nhanh sâu → pCO~2~ giảm; thở chậm nông → pCO~2~ tăng.
- Trung tâm hô hấp nhạy với H^+^ và CO~2~ (qua các **thụ thể hóa học**, chemoreceptor). Máu toan → tăng thông khí, thải CO~2~; máu kiềm → giảm thông khí, giữ CO~2~.
- Khi acid mạnh vào, CA tách H~2~CO~3~ thành CO~2~ thải ra phổi: acid mạnh "biến mất", cơ thể chỉ mất một phần NaHCO~3~, pCO~2~ không đổi. Khi base mạnh vào, OH^−^ kết hợp CO~2~ tạo HCO~3~^−^; phổi giảm thải CO~2~ để giữ pCO~2~ bình thường.

#### c) Điều hòa bởi thận

Thận có **3 cơ chế** (Giáo trình tr. 270–271), cùng mục tiêu giữ lượng bicarbonat ngoài tế bào. Cả ba đều bắt đầu từ cùng một phản ứng trong tế bào ống thận: CO~2~ + H~2~O → H~2~CO~3~ (nhờ **CA**) → H^+^ + HCO~3~^−^. H^+^ được **bài tiết** vào lòng ống, HCO~3~^−^ đi **về máu**.

1. **Tái hấp thu bicarbonat**: gần **90%** HCO~3~^−^ lọc qua cầu thận được tái hấp thu ở **ống lượn gần**. H^+^ bài tiết ra kết hợp với HCO~3~^−^ đã lọc; mỗi H^+^ tiết ra "đổi" được một HCO~3~^−^ về máu cùng Na^+^. Cơ chế này **chỉ giữ lại**, không tạo thêm HCO~3~^−^ mới.
2. **Đào thải acid chuẩn độ được (muối acid) và acid không bay hơi**: ở **ống lượn xa**, H^+^ được tiết ra thế chỗ Na^+^. Trong nước tiểu, **Na~2~HPO~4~ nhận H^+^ thành NaH~2~PO~4~**, làm nước tiểu toan; Na^+^ trở về máu. Một số acid hữu cơ (acid acetic, acid lactic…) được thải nguyên dạng.
3. **Bài tiết H^+^ dưới dạng muối amoni**: tế bào ống thận tạo **NH~3~** chủ yếu do **thủy phân glutamin** nhờ enzym **glutaminase**. NH~3~ khuếch tán thụ động ra lòng ống, kết hợp H^+^ thành **NH~4~^+^** (không khuếch tán ngược được) và bị thải ra. Xem thêm chương 18 (hóa sinh thận và nước tiểu).

Mỗi ngày thận thải khoảng **30–50 mEq H^+^ dưới dạng NH~4~^+^** và **10–30 mEq** dưới dạng các muối acid khác (Giáo trình tr. 271).

> [!vi-du] Vì sao NH~4~^+^ là "van xả" quan trọng nhất khi toan kéo dài?
> Lượng phosphat lọc vào nước tiểu có hạn, nên acid chuẩn độ khó tăng nhiều. Còn tổng hợp NH~3~ từ glutamin thì **tăng dần trong nhiều ngày** khi toan kéo dài. Đây là lý do thận cần **2–4 ngày** mới bù hoàn chỉnh. Mỗi H^+^ thải đi dưới dạng NH~4~^+^ hay H~2~PO~4~^−^ đều kèm một HCO~3~^−^ **mới** được tạo ra và trả về máu. *(Hiện nay biết NH~3~ được tạo chủ yếu ở tế bào ống lượn gần, rồi được "bẫy" ở ống góp; ý chính của giáo trình vẫn đúng.)*

### 2.4. Các thông số đánh giá trạng thái acid – base

Mẫu xét nghiệm là **máu động mạch** (hoặc máu mao mạch đã "động mạch hóa"), lấy trong ống có heparin, **không cho tiếp xúc với không khí** (Giáo trình tr. 271). Phải đánh giá pH **kết hợp** với các thông số khác.

| Thông số | Định nghĩa | Giá trị bình thường (giáo trình) | Thay đổi khi |
|---|---|---|---|
| **pH** máu động mạch | — | 7,38–7,42 | Mọi rối loạn chưa bù hết |
| **pCO~2~** máu động mạch | Phân áp CO~2~; **chỉ phụ thuộc thông khí phế nang** (tỷ lệ nghịch) | ≈ 40 mmHg | Rối loạn **hô hấp** (hoặc bù hô hấp) |
| **AB** — bicarbonat thực (*actual*) | HCO~3~^−^ đo ở đúng pH, pCO~2~ thực của bệnh nhân | 25 mEq/L | **Phụ thuộc nhiều vào pCO~2~**: pCO~2~ tăng thì AB tăng theo |
| **SB** — bicarbonat chuẩn (*standard*) | HCO~3~^−^ đo ở điều kiện chuẩn **pCO~2~ = 40 mmHg, 37 °C** | 25 mEq/L | **Chỉ đổi khi rối loạn chuyển hóa** |
| **BB** — base đệm (*buffer base*) | Tổng các anion đệm của máu toàn phần (HCO~3~^−^, HPO~4~^2−^, proteinat, Hb^−^…) | 46 mEq/L | Ít phụ thuộc pCO~2~; phụ thuộc một phần vào Hb |
| **BE** — base dư (*base excess*) | Lượng acid (hoặc base) cần thêm vào máu để đưa pH về 7,40 ở pCO~2~ 40 mmHg, 37 °C | **0** | **Âm** khi thiếu base (thừa acid); **dương** khi thừa base |

**Vì sao cần SB khi đã có AB?** Vì CO~2~ tan vào máu sẽ tự tạo thêm HCO~3~^−^ (CO~2~ + H~2~O → H^+^ + HCO~3~^−^). Do đó trong **toan hô hấp**, AB tăng chỉ vì pCO~2~ tăng, chưa chắc thận đã giữ HCO~3~^−^. SB "đưa" mẫu máu về pCO~2~ 40 mmHg để loại ảnh hưởng hô hấp, chỉ còn phản ánh **thành phần chuyển hóa**. Tương tự, **BE** không chỉ cho biết có rối loạn chuyển hóa mà còn cho phép **ước tính lượng base hoặc acid cần bù** cho bệnh nhân (Giáo trình tr. 272).

> [!bay]
> - AB > SB → có **toan hô hấp** (CO~2~ ứ làm AB tăng). AB < SB → có **kiềm hô hấp**. AB = SB → không có rối loạn hô hấp.
> - **BE âm** (ví dụ −12) = **thiếu base** = toan chuyển hóa. Đừng nhầm "base dư âm" là "dư acid hô hấp".
> - **pCO~2~** là thông số **hô hấp**; **HCO~3~^−^, SB, BB, BE** là thông số **chuyển hóa**.

**Khoảng tham chiếu thường dùng trên phiếu khí máu** *(tham khảo, mỗi phòng xét nghiệm có khoảng riêng)*:

| Thông số | Khoảng tham chiếu |
|---|---|
| pH | 7,35–7,45 |
| pCO~2~ | 35–45 mmHg (4,7–6,0 kPa) |
| pO~2~ | 80–100 mmHg (khí trời) |
| HCO~3~^−^ | 22–26 mmol/L (khí máu động mạch; HCO~3~^−^ huyết thanh trên phiếu sinh hóa thường ghi 22–28/29 — hs-15) |
| BE | −2 đến +2 mmol/L |
| SaO~2~ | 95–100% |
| Khoảng trống anion Na^+^ − (Cl^−^ + HCO~3~^−^) | ≈ 8–12 mmol/L |

> [!cap-nhat] Khoảng pH bình thường
> Giáo trình ghi pH máu động mạch **7,40 ± 0,05** (tr. 263) và cũng ghi **7,38–7,42** (tr. 268, 271). Phiếu khí máu và sách lâm sàng hiện nay dùng **7,35–7,45**: dưới 7,35 là **toan máu** (acidemia), trên 7,45 là **kiềm máu** (alkalemia). Khoảng 7,38–7,42 là vùng "trung tâm" hẹp hơn. Đi thi lý thuyết theo giáo trình; đọc phiếu xét nghiệm theo 7,35–7,45. Đơn vị: với ion hóa trị 1 như HCO~3~^−^, **1 mEq/L = 1 mmol/L**.

## 3. Rối loạn thăng bằng acid – base

Rối loạn thăng bằng acid – base là tình trạng bệnh lý làm thay đổi pH sinh lý của máu. Có **4 loại chủ yếu** (nguyên phát) và **4 loại hỗn hợp** (Giáo trình tr. 272).

Nguyên tắc gọi tên rất đơn giản, nhìn vào phương trình Henderson–Hasselbalch:

| Rối loạn | Thay đổi nguyên phát | pH | Bù trừ (cùng chiều) | Cơ quan bù |
|---|---|---|---|---|
| **Toan chuyển hóa** | **↓ HCO~3~^−^** | ↓ | ↓ pCO~2~ | Phổi (tăng thông khí) |
| **Kiềm chuyển hóa** | **↑ HCO~3~^−^** | ↑ | ↑ pCO~2~ | Phổi (giảm thông khí) |
| **Toan hô hấp** | **↑ pCO~2~** | ↓ | ↑ HCO~3~^−^ | Thận (giữ HCO~3~^−^) |
| **Kiềm hô hấp** | **↓ pCO~2~** | ↑ | ↓ HCO~3~^−^ | Thận, hệ đệm |

> [!ghi-nho] Quy tắc "cùng chiều"
> Bù trừ không đánh vào nguyên nhân, mà làm **thông số còn lại thay đổi cùng chiều** với thông số nguyên phát, để **tỷ số HCO~3~^−^ / (0,03 × pCO~2~) quay về gần 20**. Bù gần như **không bao giờ** đưa pH về đúng 7,40, và **không bao giờ vượt quá** (bù quá mức không xảy ra).
> Nếu hai thông số thay đổi **ngược chiều** (ví dụ pCO~2~ tăng mà HCO~3~^−^ giảm) → chắc chắn là **rối loạn hỗn hợp**.

### 3.1. Nhiễm toan chuyển hóa

**Định nghĩa**: rối loạn do **HCO~3~^−^ huyết tương giảm**, làm pH máu giảm dưới giới hạn bình thường (Giáo trình tr. 272).

**Biểu hiện sinh hóa**: pH thấp, HCO~3~^−^ huyết thanh giảm, **pCO~2~ giảm** khi phổi bù, **nước tiểu toan** khi thận bù. pH thấp trước khi bù, có thể về bình thường hoặc chỉ giảm nhẹ sau bù.

- **Cl^−^ có thể tăng** khi toan do **mất HCO~3~^−^ qua ỉa chảy**.
- **K^+^ có thể giảm** trong toan do thận, do ỉa chảy (mất K^+^), hoặc trong toan ceton của đái tháo đường *(K^+^ máu lúc đầu có thể bình thường hoặc cao vì K^+^ ra khỏi tế bào, nhưng tổng K^+^ cơ thể thiếu)*.

**Nguyên nhân** (4 nhóm theo giáo trình):

| Nhóm | Ví dụ *(ví dụ cụ thể là bổ sung)* |
|---|---|
| **Tăng tạo H^+^** | Toan ceton đái tháo đường, nhịn đói; toan lactic (sốc, thiếu oxy mô, co giật) |
| **Ăn uống / đưa vào thừa acid** | Ngộ độc methanol, ethylen glycol, salicylat; truyền nhiều NH~4~Cl |
| **Giảm bài tiết H^+^** | Suy thận, toan ống thận |
| **Mất HCO~3~^−^** | Ỉa chảy, rò tụy – mật, dùng acetazolamid |

**Bù trừ** (Giáo trình tr. 272):

- **Phổi**: pH thấp kích thích chemoreceptor → **tăng thông khí** (thở nhanh sâu, kiểu **Kussmaul** trong toan ceton) → pCO~2~ giảm → H~2~CO~3~ giảm → tỷ số tăng, pH trở về gần bình thường. Bù phổi **bắt đầu sớm** và **hoàn thành trong 12–24 giờ**.
- **Thận**: hiệu quả hơn khi nguyên nhân **không phải do thận**. Thận tăng bài tiết H^+^ và tăng tái hấp thu (tạo mới) HCO~3~^−^. Bù thận **hoàn thành trong 2–4 ngày**.

> [!vi-du] Bù hô hấp "đúng mức" là bao nhiêu? — công thức Winter *(bổ sung)*
> Trong toan chuyển hóa, pCO~2~ dự kiến ≈ **1,5 × HCO~3~^−^ + 8 (± 2)** mmHg.
> Ví dụ HCO~3~^−^ = 12 → pCO~2~ dự kiến = 1,5 × 12 + 8 = 26 (24–28).
> - pCO~2~ đo được nằm trong khoảng → bù hô hấp **thích hợp**.
> - pCO~2~ **cao hơn** khoảng → có thêm **toan hô hấp** (phổi không bù nổi).
> - pCO~2~ **thấp hơn** khoảng → có thêm **kiềm hô hấp** (ví dụ ngộ độc salicylat).

### 3.2. Nhiễm kiềm chuyển hóa

**Định nghĩa**: tình trạng **thừa HCO~3~^−^** trong máu, làm tỷ số HCO~3~^−^/H~2~CO~3~ tăng và pH tăng (Giáo trình tr. 273). Cần **hai điều kiện**: (1) HCO~3~^−^ ngoài tế bào tăng, và (2) thận **không bài xuất** được lượng HCO~3~^−^ thừa đó. *(Bình thường thận thải HCO~3~^−^ thừa rất nhanh. Kiềm chuyển hóa kéo dài được là vì có yếu tố "duy trì" như thiếu thể tích, thiếu Cl^−^, thiếu K^+^ hoặc thừa aldosteron.)*

**Biểu hiện**: pH tăng, HCO~3~^−^ tăng, pCO~2~ bình thường hoặc **tăng nhẹ** nếu phổi bù. pCO~2~ hiếm khi vượt **60 mmHg**; cao hơn nữa gợi ý có thêm **toan hô hấp**. **K^+^ và Cl^−^ giảm.** Nước tiểu thường kiềm (giảm bài tiết acid, tăng bài tiết HCO~3~^−^).

**Nguyên nhân**:

- Đưa vào **thừa chất kiềm**: uống nhiều thuốc kháng acid, NaHCO~3~.
- **Mất H^+^**: **nôn mửa** (mất HCl của dịch vị), hút dịch dạ dày.
- **Cạn kiệt K^+^**.
- **Kiềm mạn**: điều trị **steroid**, **bệnh Cushing**, **cường aldosteron**, **ăn/uống nhiều cam thảo (licorice)** kéo dài.

**Bù trừ**: pH tăng **ức chế trung tâm hô hấp** → giảm thông khí → pCO~2~ tăng (tăng mẫu số). Thận **giảm tái hấp thu HCO~3~^−^** (tăng bài xuất HCO~3~^−^) và giữ H^+^ (giảm tử số). Bù bằng phổi **ít hiệu quả**, vì giảm thông khí cũng làm **giảm pO~2~**, mà thiếu O~2~ lại kích thích thở.

> [!ung-dung] Nôn kéo dài (hẹp môn vị, nôn nghén nặng)
> Mất HCl → kiềm chuyển hóa **giảm Cl^−^, giảm K^+^**. Cơ thể mất nước, thiếu thể tích → thận giữ Na^+^ bằng mọi giá, phải thải H^+^ và K^+^ để đổi. Vì vậy có hiện tượng **nước tiểu toan nghịch thường** dù máu đang kiềm. Điều trị chính là bù **NaCl và KCl** (truyền dịch muối) để thận "dám" thải HCO~3~^−^.

> [!bay] Cam thảo (licorice) trong danh sách nguyên nhân
> Giáo trình xếp **uống nhiều cam thảo kéo dài** vào nguyên nhân kiềm chuyển hóa mạn. Cơ chế (glycyrrhizin → acid glycyrrhetinic ức chế **11β-HSD2** → cortisol tác động như aldosteron → giữ Na^+^, thải K^+^ và H^+^) đã trình bày ở bài *Hóa sinh hormon* (mã hs-14, khung YHCT), kèm khuyến cáo khi kê Cam thảo. Ở bài này chỉ cần nhớ: kiềm chuyển hóa + **hạ K^+^** + tăng huyết áp, renin và aldosteron **đều thấp**.

> [!yhct] Vị thuốc "chế toan" chứa CaCO~3~ và kiềm chuyển hóa
> - Thành phần (**CaCO~3~** trong Mẫu lệ, Ô tặc cốt, Ngõa lăng tử) và cơ chế trung hòa HCl dịch vị: xem bài *Hợp chất vô cơ: oxide, acid, base, muối* (mã vc-05, mục 6.2) và bài *Hóa sinh các dịch sinh vật* (mã hs-22, khung YHCT), không nhắc lại ở đây.
> - **Liên hệ riêng với bài này**: giáo trình xếp "ăn uống phải các chất kháng acid" vào nguyên nhân kiềm chuyển hóa. Với calci carbonat nói chung (chưa có báo cáo riêng cho các vị thuốc này), uống **liều cao, kéo dài**, nhất là kèm sữa hoặc ở người **suy thận**, có thể gây **hội chứng sữa – kiềm**: tăng Ca^2+^ máu, kiềm chuyển hóa, suy thận. Khi gặp bệnh nhân tăng calci máu kèm kiềm chuyển hóa, cần hỏi tiền sử dùng các vị thuốc này.

### 3.3. Nhiễm toan hô hấp

**Định nghĩa**: tình trạng **tăng pCO~2~** máu do **giảm thông khí phế nang** (Giáo trình tr. 273). Thường gặp trong **suy hô hấp mạn** hoặc **đợt cấp của suy hô hấp**. Ở toan hô hấp **cấp**: pCO~2~ tăng, pH giảm, HCO~3~^−^ (gần như) bình thường, tỷ số HCO~3~^−^/H~2~CO~3~ giảm.

**Nguyên nhân**: giảm thông khí phế nang nguyên phát (Giáo trình tr. 274):

- **Tắc đường thở** (dị vật, co thắt phế quản nặng).
- **Ức chế trung tâm hô hấp** (quá liều thuốc ngủ, opioid, chấn thương sọ não).
- Bệnh thần kinh – cơ: **bại liệt**.
- **Bệnh phổi** (bệnh phổi tắc nghẽn mạn tính – COPD, phù phổi nặng).
- Biến dạng lồng ngực: **gù, vẹo cột sống**.

**Bù trừ**: **thận đóng vai trò chủ yếu** bằng cách giữ lại HCO~3~^−^ (phổi chỉ tham gia một phần, vì phổi chính là nơi bị bệnh). Thận tăng trao đổi Na^+^/H^+^ (tăng bài xuất H^+^, giữ Na^+^), giữ HCO~3~^−^ và tăng tạo NH~3~. **Cl^−^ huyết thanh giảm** vì Cl^−^ được trao đổi với HCO~3~^−^ và thải cùng H^+^, NH~4~^+^. Ngoài ra, một phần CO~2~ vào tế bào, được CA hydrat hóa thành H~2~CO~3~; H^+^ được Hb và các hệ đệm khác đệm, còn HCO~3~^−^ làm tăng tử số.

Thời gian bù thận: **bắt đầu sau 6–12 giờ**, **tối ưu sau 2–3 ngày**, **hoàn thành khoảng ngày thứ 5**. Giáo trình viết thêm: trong toan hô hấp **mạn**, bù thận không đưa được pH về mức sinh lý. Hiểu đúng: ở giai đoạn **cấp** thận chưa kịp bù (HCO~3~^−^ gần như chưa đổi); bù thận chỉ phát huy ở giai đoạn **mạn**, nhưng kể cả khi đã bù tối đa, pH thường vẫn **hơi thấp** chứ không về hẳn 7,40.

> [!vi-du] Cấp hay mạn? *(quy tắc bổ sung, gần đúng)*
> Cứ pCO~2~ tăng 10 mmHg so với 40:
> - **Cấp** (chưa kịp bù thận): HCO~3~^−^ tăng ≈ **1** mmol/L (chỉ nhờ đệm), pH giảm ≈ 0,08.
> - **Mạn** (đã bù thận): HCO~3~^−^ tăng ≈ **3,5** mmol/L, pH giảm ≈ 0,03.
> Ví dụ pCO~2~ 60: cấp → HCO~3~^−^ ≈ 26, pH ≈ 7,25; mạn (COPD) → HCO~3~^−^ ≈ 31–33, pH ≈ 7,35.

### 3.4. Nhiễm kiềm hô hấp

**Định nghĩa**: tình trạng **giảm pCO~2~** máu do **tăng thông khí phế nang quá mức** (Giáo trình tr. 274). *(Giáo trình viết kiềm hô hấp "thường gặp trong suy hô hấp mạn hoặc đợt cấp" — câu này lặp lại nguyên văn mục toan hô hấp. Thực tế, kiềm hô hấp gặp khi người bệnh **thở nhanh quá mức**: thiếu oxy, lo âu, sốt, đau…; suy hô hấp mạn có ứ CO~2~ thì gây **toan** hô hấp.)* Khi kiềm hô hấp: pCO~2~ giảm, pH tăng, HCO~3~^−^ bình thường, tỷ số HCO~3~^−^/H~2~CO~3~ tăng.

**Nguyên nhân**: tăng thông khí nguyên phát. Giáo trình nêu **thiếu oxy** (lên vùng cao, viêm phổi), **phù phổi**. *Bổ sung các nguyên nhân hay gặp: lo âu – cơn hoảng sợ (thở nhanh), đau, sốt, nhiễm khuẩn huyết giai đoạn đầu, có thai, bệnh gan nặng, ngộ độc salicylat giai đoạn đầu, thở máy quá mức.*

**Bù trừ** theo giáo trình: hô hấp tự bù bằng cách giảm thông khí. Nếu chemoreceptor không đáp ứng được với pO~2~ cao và pCO~2~ thấp, thì **các hệ đệm** (hemoglobinat/hemoglobin, proteinat/protein, phosphat Na~2~HPO~4~/NaH~2~PO~4~) **nhả H^+^** để biến HCO~3~^−^ thành H~2~CO~3~ → HCO~3~^−^ giảm, H~2~CO~3~ tăng, tỷ số giảm, pH giảm. H^+^ của các hệ đệm (trong tế bào) được thay bằng **K^+^** đi vào tế bào → **K^+^ máu hạ**.

> [!cap-nhat] Bù thận trong kiềm hô hấp
> Giáo trình chỉ nêu bù bằng hệ đệm. Hiện nay biết rõ: nếu kiềm hô hấp kéo dài **trên 2–3 ngày**, **thận** là cơ quan bù chính, bằng cách **giảm tái hấp thu HCO~3~^−^** và giảm bài tiết NH~4~^+^, acid chuẩn độ (HCO~3~^−^ giảm khoảng 4–5 mmol/L cho mỗi 10 mmHg pCO~2~ giảm). Đây là phép đối xứng với toan hô hấp mạn. Ngoài hạ K^+^, kiềm máu cấp còn làm **giảm Ca^2+^ ion hóa** (Ca^2+^ gắn albumin nhiều hơn) → **tê quanh miệng, đầu chi, co quắp tay** ở người thở nhanh do lo âu.

### 3.5. Các rối loạn acid – base hỗn hợp

Trên lâm sàng có thể gặp **hai hay nhiều rối loạn tiên phát cùng lúc**, hoặc một rối loạn **không được bù đầy đủ** (Giáo trình tr. 275). Giáo trình nêu 4 kiểu:

| Kiểu hỗn hợp | Tình huống của giáo trình | Khí máu điển hình |
|---|---|---|
| **Toan hô hấp + kiềm chuyển hóa** | Toan hô hấp kéo dài (COPD) được điều trị **thừa thuốc lợi niệu** → giảm mạnh thể tích máu, hạ K^+^ → kiềm chuyển hóa chồng lên | **HCO~3~^−^ và pCO~2~ đều tăng**, K^+^ giảm; pH có thể gần bình thường |
| **Kiềm hô hấp + toan chuyển hóa** | **Ngộ độc salicylat** (uống quá liều aspirin): lúc đầu salicylat kích thích thụ thể hóa học → tăng thông khí (kiềm hô hấp); sau đó sản phẩm phụ gây toan chuyển hóa | **pCO~2~ thấp mà pH bình thường** gợi ý quá liều aspirin. **Trẻ em**: toan chuyển hóa trội; **thiếu niên, người lớn**: kiềm hô hấp trội |
| **Toan hô hấp + toan chuyển hóa** | **Ngừng tim – phổi**: CO~2~ ứ lại + toan lactic do thiếu oxy mô | **pH rất thấp** (cả hai cùng làm toan) |
| **Kiềm hô hấp + kiềm chuyển hóa** | Bệnh nhân **thở máy** (thông khí quá mức) kèm **lợi tiểu** không theo dõi cẩn thận | **pH rất cao** |

> [!bay]
> - **pH bình thường không có nghĩa là không có rối loạn.** pH bình thường mà pCO~2~ và HCO~3~^−^ đều bất thường → hoặc bù hoàn toàn (hiếm, chủ yếu ở rối loạn mạn nhẹ), hoặc **hỗn hợp** hai rối loạn ngược nhau.
> - Hai rối loạn **cùng hướng** (toan + toan, kiềm + kiềm) làm pH lệch rất xa; hai rối loạn **ngược hướng** làm pH gần bình thường.

### 3.6. Đọc một kết quả khí máu — 4 bước *(phần thực hành bổ sung)*

![Hình 2. Lưu đồ phân tích khí máu động mạch](luu-do-khi-mau.svg)

**Bước 1 — pH**: dưới 7,35 là **toan máu**, trên 7,45 là **kiềm máu**. Nếu pH bình thường mà các thông số khác lệch, chuyển sang nghĩ đến bù hoàn toàn hoặc hỗn hợp.

**Bước 2 — Nguyên phát**: tìm thông số **giải thích được hướng của pH**.

- pH toan: pCO~2~ > 45 → **toan hô hấp**; HCO~3~^−^ < 22 → **toan chuyển hóa**.
- pH kiềm: pCO~2~ < 35 → **kiềm hô hấp**; HCO~3~^−^ > 26 → **kiềm chuyển hóa**.

**Bước 3 — Bù trừ**: thông số còn lại đổi **cùng chiều**? Có thể dùng Winter (toan chuyển hóa) hoặc quy tắc 1 / 3,5 (toan hô hấp) để kiểm tra mức bù. Lệch khỏi dự kiến → có rối loạn thứ hai.

**Bước 4 — Toan chuyển hóa: tính khoảng trống anion (AG)**

=> AG = Na^+^ − (Cl^−^ + HCO~3~^−^)  (bình thường ≈ 8–12 mmol/L)

**Vì sao có "khoảng trống"?** Huyết tương luôn trung hòa điện. Na^+^ là cation chính; Cl^−^ và HCO~3~^−^ là hai anion được đo. Phần chênh lệch là các **anion không đo** (chủ yếu **albumin**, ngoài ra phosphat, sulfat, acid hữu cơ). Khi một acid mạnh HA vào máu, H^+^ "ăn" HCO~3~^−^, còn A^−^ ở lại:

- Nếu A^−^ là anion lạ (ceton, lactat, formiat…) → HCO~3~^−^ giảm, Cl^−^ không đổi → **AG tăng**.
- Nếu cơ thể mất HCO~3~^−^ (ỉa chảy) hay giữ HCl → HCO~3~^−^ giảm, **Cl^−^ tăng bù vào** → **AG bình thường** (toan tăng Cl^−^). Đúng như giáo trình ghi: Cl^−^ có thể tăng trong toan do ỉa chảy.

| Toan chuyển hóa **AG tăng** | Toan chuyển hóa **AG bình thường (tăng Cl^−^)** |
|---|---|
| Toan **ceton** (đái tháo đường, nhịn đói, rượu) | **Ỉa chảy**, rò tiêu hóa dưới |
| Toan **lactic** (sốc, thiếu oxy, co giật, metformin trong suy thận) | **Toan ống thận** |
| **Suy thận** (ứ sulfat, phosphat) | Thuốc ức chế **carbonic anhydrase** (acetazolamid) |
| **Ngộ độc**: methanol, ethylen glycol, salicylat | Truyền nhiều NaCl 0,9% hoặc NH~4~Cl |

> [!bay] Khoảng trống anion
> - Có nơi tính AG **có cả K^+^**: AG = (Na^+^ + K^+^) − (Cl^−^ + HCO~3~^−^), khi đó bình thường ≈ 12–16. Phải biết phòng xét nghiệm dùng công thức nào.
> - **Albumin máu thấp** (xơ gan, hội chứng thận hư) làm AG **thấp giả**, có thể che một toan AG tăng. Mỗi 10 g/L albumin giảm, AG giảm khoảng 2,5 mmol/L.

> [!vi-du] Ba phiếu khí máu mẫu
> **Phiếu 1.** Bệnh nhân đái tháo đường typ 1, thở sâu, hơi thở mùi táo: pH 7,25; pCO~2~ 28; HCO~3~^−^ 12; Na^+^ 138, Cl^−^ 102.
> → pH < 7,35: **toan**. HCO~3~^−^ thấp giải thích pH → **toan chuyển hóa**. pCO~2~ thấp = bù hô hấp; Winter: 1,5 × 12 + 8 = 26 ± 2 → 24–28 ⇒ **bù thích hợp**. AG = 138 − 114 = **24** → **toan AG tăng** (toan ceton).
>
> **Phiếu 2.** Bệnh nhân COPD lâu năm, ổn định: pH 7,36; pCO~2~ 60; HCO~3~^−^ 33.
> → pH ở giới hạn thấp, lệch về phía toan. pCO~2~ cao giải thích được → **toan hô hấp**. HCO~3~^−^ tăng cùng chiều, phù hợp mức bù mạn (dự kiến 24 + 2 × 3,5 = 31, chấp nhận lệch ± 2) ⇒ **toan hô hấp mạn đã bù**. Kiểm tra: 33 / (0,03 × 60) = 18,3; log ≈ 1,26; pH ≈ 7,36. ✓
>
> **Phiếu 3.** Người lớn uống nhiều viên aspirin: pH 7,43; pCO~2~ 22; HCO~3~^−^ 14; Na^+^ 140, Cl^−^ 104.
> → pH bình thường nhưng cả hai thông số đều thấp. AG = 140 − 118 = **22** (tăng) → có **toan chuyển hóa**. Winter dự kiến pCO~2~ 27–31, nhưng đo được 22 (**thấp hơn**) → có thêm **kiềm hô hấp**. ⇒ **Hỗn hợp kiềm hô hấp + toan chuyển hóa**, đúng kiểu ngộ độc salicylat của giáo trình.

## Tóm tắt

| Chủ đề | Điều phải nhớ |
|---|---|
| Vận chuyển O~2~ | 1 L huyết tương hòa tan 2,3 ml O~2~; 150 g Hb chở ≈ 200 ml (×87); 1 g Hb = 1,34 ml O~2~; bão hòa 98% ở phổi, 35% ở cơ hoạt động |
| Ái lực Hb–O~2~ giảm khi | ↑ DPG, ↑ pCO~2~, ↑ H^+^ (Bohr), ↑ nhiệt độ. HbF: Ser 143 thay His 143 → gắn DPG kém → ái lực cao |
| Vận chuyển CO~2~ | HCO~3~^−^ 78%, carbamin 13%, hòa tan 9%; CA trong hồng cầu; cả tạo HCO~3~^−^ lẫn carbamin đều sinh H^+^; pH hồng cầu 7,20 |
| Đệm H^+^ khi chở CO~2~ | Hb 50% + đẳng hydro 40% + đệm khác 10%; HCO~3~^−^ ra – Cl^−^ vào (đổi chỗ clorid) |
| Henderson–Hasselbalch | pH = 6,1 + log [HCO~3~^−^]/(0,03 × pCO~2~); 24/1,2 = 20 → 7,40; hệ mở |
| Hệ đệm | Máu: Hb 82, protein 10, bicarbonat 7, phosphat 1 (%). Toàn cơ thể với acid chuyển hóa: tế bào mô 52, dịch ngoại bào 42, hồng cầu 6 |
| Phổi | Chỉnh pCO~2~ (tỷ lệ nghịch thông khí); nhanh |
| Thận | Tái hấp thu ≈ 90% HCO~3~^−^ ở ống lượn gần; thải acid chuẩn độ (HPO~4~^2−^ → H~2~PO~4~^−^) 10–30 mEq/ngày; thải NH~4~^+^ (glutaminase) 30–50 mEq/ngày; chậm (ngày) |
| Thông số | pH 7,38–7,42 (lâm sàng 7,35–7,45); pCO~2~ ≈ 40; AB = SB = 25; BB 46; BE 0 (âm = thiếu base); SB chỉ đổi khi rối loạn chuyển hóa |
| 4 rối loạn | Toan CH ↓HCO~3~^−^ (bù ↓pCO~2~, 12–24 h); kiềm CH ↑HCO~3~^−^ (bù ↑pCO~2~, hiếm > 60); toan HH ↑pCO~2~ (thận bù, 6–12 h → 5 ngày); kiềm HH ↓pCO~2~ (đệm, hạ K^+^) |
| Hỗn hợp | Toan HH + kiềm CH (COPD + lợi niệu); kiềm HH + toan CH (aspirin); toan HH + toan CH (ngừng tim); kiềm HH + kiềm CH (thở máy + lợi niệu) |
| AG | Na^+^ − (Cl^−^ + HCO~3~^−^) ≈ 8–12; tăng: ceton, lactic, suy thận, methanol, salicylat; bình thường (tăng Cl^−^): ỉa chảy, toan ống thận, acetazolamid |
