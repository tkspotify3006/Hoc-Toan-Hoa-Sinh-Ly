---
title: Sự trao đổi muối – nước
thoi-gian: 40 phút
muc-tieu:
- Trình bày được hàm lượng, sự phân bố và vai trò của nước; hàm lượng, sự phân bố và vai trò của các chất vô cơ chính (Na^+^, K^+^, Cl^−^, HCO~3~^−^, Ca^2+^, phosphat) trong cơ thể.
- Giải thích được các yếu tố quyết định sự vận chuyển nước (áp suất thẩm thấu, áp lực thủy tĩnh, áp suất keo – cân bằng Donnan) và sự trao đổi nước, chất giữa trong – ngoài thành mạch, giữa trong – ngoài tế bào.
- Trình bày được cơ chế điều hòa trao đổi muối nước: thần kinh (khát, thụ thể thẩm thấu), nội tiết (ADH, aldosteron – hệ renin–angiotensin, ANP) và các cơ quan tham gia.
- Nêu được thế nào là rối loạn nước – điện giải, các thông số đánh giá; tính được áp lực thẩm thấu huyết tương và vận dụng vào dịch truyền, bù nước.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Nước chiếm khoảng **60%** khối lượng người trưởng thành, chia hai khu vực: **trong tế bào** (nhiều K^+^, phosphat, protein) và **ngoài tế bào** (nhiều Na^+^, Cl^−^, HCO~3~^−^). Bilan nước bình thường **bằng 0** (vào ≈ ra ≈ 2500 mL/ngày).
> 2. Nước luôn đi về phía có **áp suất thẩm thấu cao hơn** và rời khỏi nơi có **áp lực thủy tĩnh cao hơn**. Áp suất thẩm thấu do **protein** tạo ra gọi là **áp suất keo**.
> 3. Ở mao mạch: đầu động mạch huyết áp thắng áp suất keo → nước **ra** mô (+7 mmHg); đầu tĩnh mạch áp suất keo thắng → nước **về** mạch (−8 mmHg). Ở màng tế bào: **bơm Na^+^-K^+^-ATPase** giữ chênh lệch ion.
> 4. Điều hòa: **ADH** giữ **nước**; **aldosteron** giữ **Na^+^** (nước theo), thải K^+^; **ANP** thải Na^+^ và nước; **khát** đưa nước vào.
> 5. Áp lực thẩm thấu huyết tương ≈ **2[Na^+^] + [glucose] + [ure]** ≈ 275–295 mOsm/kg (một số tài liệu ghi 285–295). Na^+^ quyết định thẩm thấu ngoại bào; K^+^ quyết định điện thế màng — rối loạn K^+^ gây **loạn nhịp tim, liệt cơ**.

Theo giáo trình (tr. 250), môi trường lỏng của cơ thể luôn được giữ **hằng định** nhờ sự cân bằng giữa nước, các thành phần đặc biệt của tế bào và các chất điện giải. Nước và muối gắn chặt với nhau: muối đi đâu, nước theo đó. Vì vậy sách gộp chung thành "trao đổi muối – nước".

> [!bay] Đọc kèm bài khác, không học lại
> - **Thẩm thấu, định luật van't Hoff, cân bằng Donnan, cân bằng Starling, siêu lọc cầu thận, ý nghĩa của dung dịch đẳng – ưu – nhược trương**: bài **Chuyển động trong cơ thể sống** (Vật lý, vl-03, mục 1.5–1.6).
> - **Bơm Na^+^-K^+^, trao đổi anion band 3, vận chuyển thụ động – chủ động**: bài **Vận chuyển vật chất qua màng tế bào** (Sinh học, sh-04).
> - **Tính chất hóa học của Na, K, Ca, Mg** và vai trò sinh học của chúng: bài **Kim loại khối s** (Hóa học, vc-01).
> - **Cấu trúc và cơ chế tác dụng của ADH, aldosteron**; Cam thảo gây giả cường aldosteron: bài **Hóa sinh hormon** (hs-14). HCO~3~^−^ và thăng bằng acid – base: bài **hs-16**.

## 1. Nước trong cơ thể

### 1.1. Cấu tạo và đặc tính — nước tự do, nước kết hợp

Phân tử nước có hình chữ V (giáo trình gọi là hình tam giác). Góc liên kết H–O–H là **104,5°**. Liên kết O–H phân cực mạnh, nên cả phân tử **phân cực mạnh**. Nhờ đó các phân tử nước nối với nhau bằng **liên kết hydro**, và nước hòa tan được rất nhiều chất vô cơ lẫn hữu cơ.

Giáo trình chia nước trong cơ thể thành hai dạng (tr. 250–251):

| Dạng | Đặc điểm | Ví dụ, số liệu |
|---|---|---|
| **Nước tự do** | Lưu thông, đông ở 0 °C, sôi ở 100 °C; thay đổi theo ăn uống | Nước trong máu, dịch tiêu hóa, nước tiểu |
| **Nước kết hợp** — nước hydrat hóa | Tạo **lớp vỏ hydrat** quanh các tiểu phân protein, tạo hạt keo, micell | Cứ **10 g protein giữ 5 g nước** để hydrat hóa |
| **Nước kết hợp** — nước bị cầm | Bị giữ trong mạng lưới **gel**, làm gel ở trạng thái nửa rắn | Chiếm phần lớn nước kết hợp |

Nước kết hợp **không đông ở 0 °C** mà ở nhiệt độ thấp hơn. Nhờ nước bị cầm trong gel, cơ và tim chứa tới 70–80% nước mà vẫn rắn chắc. Ngược lại, máu chứa khoảng 83% nước nhưng ở thể lỏng vì **không có cấu tạo gel**.

### 1.2. Hàm lượng nước

- Nước chiếm **40–75%** khối lượng cơ thể, tùy giới, tuổi, thể trạng. Người trưởng thành bình thường: **55–65%**.
- **Càng trẻ càng nhiều nước**: thai 2 tháng khoảng 97%, thai 3 tháng 94%, thai 5 tháng 85%; trẻ sơ sinh khoảng 80%.
- Nước **giảm** ở người già và người béo, vì **mô mỡ chỉ chứa 25–30% nước** (mô liên kết 60–80%).

| Cơ quan | Nước (%) | Dịch sinh học | Nước (%) |
|---|---|---|---|
| Gan | 70 | Máu | 80–83 |
| Thận | 82,7 | Nước tiểu | 95 |
| Phổi | 79 | Mồ hôi | 99,5 |
| Xương | 16–46 | Sữa | 89 |
| Cơ | 70 | Nước bọt | 99,4 |

*Bảng theo giáo trình tr. 251 (bảng 15.1).*

> [!bay]
> - Giáo trình ghi trẻ sơ sinh có khoảng 80% nước, "sau một tuần còn khoảng 60%". Tài liệu sinh lý nhi khoa thường mô tả tỷ lệ này giảm **dần** (khoảng 75–80% lúc sinh, gần 60% vào cuối năm đầu). Tuần đầu trẻ chỉ sụt khoảng 5–10% cân nặng, chủ yếu do mất nước ngoại bào. Đi thi trả lời theo sách.
> - Người **béo** có tỷ lệ nước **thấp** hơn người gầy cùng cân nặng. Nữ có tỷ lệ nước thấp hơn nam vì nhiều mỡ hơn. Đây là lý do khi tính liều dịch, người già, người béo dễ bị **mất nước** hơn ta tưởng.

### 1.3. Phân bố nước — hai khu vực

![Hình 1. Phân bố nước trong cơ thể người trưởng thành theo quy ước sinh lý hiện hành (60% – 2/3 – 1/3)](phan-bo-nuoc.svg)

- **Nước trong tế bào** (dịch nội bào, *intracellular fluid* – ICF).
- **Nước ngoài tế bào** (dịch ngoại bào, *extracellular fluid* – ECF): nước trong huyết tương, bạch huyết, dịch gian bào (dịch kẽ), mô liên kết, xương sụn, và các dịch sinh học khác (nước bọt, dịch tụy, mật, dịch ruột, dịch vị, dịch não tủy).

Giáo trình (tr. 252, bảng 15.2) cho tỷ lệ so với **nước toàn phần**:

| Khu vực | % nước toàn phần |
|---|---|
| **Trong tế bào** | **55** |
| **Ngoài tế bào** | **45**, gồm: |
| – Huyết tương và bạch huyết | 7,5 |
| – Dịch gian bào | 20 |
| – Các dịch sinh học | 2 |
| – Xương sụn | 8 |
| – Mô liên kết | 7,5 |

> [!cap-nhat] 55/45 hay 2/3 – 1/3?
> Giáo trình ghi nội bào **55%**, ngoại bào **45%** nước toàn phần. Con số này tính cả nước trong **xương, sụn, mô liên kết đặc** và các dịch xuyên bào vào ngoại bào (cách chia cũ). Sách sinh lý và lâm sàng hiện nay dùng quy ước làm tròn: **nước toàn phần ≈ 60% P; nội bào ≈ 2/3 (40% P); ngoại bào ≈ 1/3 (20% P)**, trong đó **dịch kẽ ≈ 3/4** và **huyết tương ≈ 1/4** ngoại bào (5% P). Quy ước này dùng để tính dịch truyền, như Hình 1. Đi thi môn Hóa sinh: trả lời theo bảng của giáo trình.

> [!vi-du] Ví dụ — người 70 kg
> Nước toàn phần ≈ 0,6 × 70 = **42 L**. Nội bào ≈ 28 L, ngoại bào ≈ 14 L (dịch kẽ ≈ 10,5 L, huyết tương ≈ 3,5 L). Thể tích **máu** ≈ 5 L, vì máu = huyết tương + tế bào máu.
> Hệ quả: truyền 1 L **NaCl 0,9%** thì dịch ở lại **ngoại bào** (Na^+^ không vào tế bào), chỉ khoảng 1/4 ở lại trong lòng mạch. Truyền 1 L **glucose 5%** thì glucose bị chuyển hóa, còn lại nước tự do phân bố khắp **nước toàn phần**: chỉ khoảng 1/12 (≈ 80 mL) ở lại lòng mạch. Vì vậy glucose 5% **không dùng để bù thể tích máu**.

### 1.4. Nhu cầu nước

- Người lớn: khoảng **35 g (≈ 35 mL) nước/kg/ngày**; người 60 kg cần ≈ 2,1 L.
- Trẻ em: nhu cầu tính theo cân nặng **gấp 3–4 lần** người lớn; trẻ sơ sinh tới **140 g/kg**.
- Nhu cầu tăng khi trời nóng, lao động nặng, ra nhiều mồ hôi.

### 1.5. Bilan nước

Lượng nước vào bằng lượng nước ra gọi là **bilan nước bằng không**. Cơ thể chỉ tự điều chỉnh được trong một giới hạn; bilan bị rối loạn trong bệnh nội tiết, bệnh thận, suy tim, bệnh gan.

| Nước vào | mL/ngày | Nước ra | mL/ngày |
|---|---|---|---|
| Uống | 1200 | Nước tiểu | 1400 |
| Trong thức ăn | 1000 | Mồ hôi | 500 |
| Nước chuyển hóa | 300 | Hơi thở | 500 |
| | | Phân | 100 |
| **Tổng** | **2500** | **Tổng** | **2500** |

*Theo giáo trình tr. 253 (bảng 15.3).*

**Nước chuyển hóa** (nước nội sinh) là nước sinh ra khi oxy hóa glucid, lipid, protein ở chuỗi hô hấp (2H^+^ + 2e + ½O~2~ → H~2~O). Mồ hôi và hơi thở gọi là **mất nước không nhận biết**. Lượng này tăng mạnh khi sốt, thở nhanh, trời nóng.

### 1.6. Vai trò của nước

- **Cấu tạo**: tham gia cấu tạo cơ thể qua nước kết hợp.
- **Phản ứng**: là môi trường và cơ chất của phản ứng **hydrat hóa, thủy phân**, hợp nước.
- **Dung môi và vận chuyển**: đưa chất dinh dưỡng đến mô, đưa chất cặn bã đến cơ quan bài tiết.
- **Điều hòa thân nhiệt**: thải nhiệt qua **mồ hôi, hơi thở**; tuần hoàn phân phối nhiệt khắp cơ thể.
- **Bảo vệ, bôi trơn**: dịch khớp, dịch màng tim, màng phổi, dịch não tủy.
- **Tạo áp suất** của các dịch, cùng với các chất hòa tan.

## 2. Các chất vô cơ (các muối)

### 2.1. Hàm lượng và phân bố

Chất vô cơ chiếm **4–5%** khối lượng cơ thể và phân bố **không đều**:

| Nơi | Chất vô cơ đặc trưng |
|---|---|
| Xương, răng | Ca, Mg, P dưới dạng muối phức **không tan** |
| Dịch ngoại bào, da, mô dưới da | **Na, Cl** |
| Dịch trong tế bào | **K, phosphat, Mg** |
| Tuyến giáp | Iod |
| Dịch dạ dày | HCl |
| Dịch tụy | HCO~3~^−^ |

- **Nguyên tố đa lượng**: Na, K, Cl, Ca, P, Mg.
- **Nguyên tố vi lượng**: I, Br, Cu, Co, Mn, Zn, Mo…
- **Nguyên tố siêu vi lượng**: Cr, Si, Ti…

Các chất này tồn tại dưới dạng muối không tan, muối tan trong dịch, hoặc kết hợp với protein.

> [!vi-du] Thành phần ion hai bên màng tế bào (gần đúng, mmol/L)
> | Ion | Huyết tương | Trong tế bào (cơ) |
> |---|---|---|
> | Na^+^ | ≈ 140 | ≈ 10–15 |
> | K^+^ | ≈ 4 | ≈ 140–150 |
> | Ca^2+^ tự do | ≈ 1,2 | ≈ 0,0001 |
> | Mg^2+^ | ≈ 1 | cao hơn nhiều (phần lớn gắn ATP, protein) |
> | Cl^−^ | ≈ 100 | ≈ 5–10 |
> | HCO~3~^−^ | ≈ 24 | ≈ 10 |
> | Phosphat, protein | thấp | **rất cao** (anion chính trong tế bào) |
>
> Mẹo nhớ: **ngoài = muối ăn** (NaCl), **trong = K^+^ + phosphat + protein**. Mỗi bên đều trung hòa điện.

### 2.2. Nhu cầu

| Chất | Nhu cầu/ngày (người lớn) | Chất | Nhu cầu/ngày |
|---|---|---|---|
| Na | 6 g | Phosphat | 1,5 g |
| K | 4 g | Mg | 0,3 g |
| Ca | 0,8 g | Fe | 0,02 g |
| Cl | 4 g | Nguyên tố vi lượng | rất nhỏ |

*Theo giáo trình tr. 254 (bảng 15.4).* Trẻ đang lớn cần nhiều **Ca, P** hơn; phụ nữ có thai, cho con bú cần nhiều **Fe, Ca, P** hơn.

> [!cap-nhat] Natri — nên ăn bao nhiêu?
> Giáo trình ghi nhu cầu Na là 6 g/ngày. Khuyến nghị hiện nay của **WHO** là người lớn ăn **dưới 2 g natri/ngày, tương đương dưới 5 g muối (NaCl)/ngày**, vì ăn mặn làm tăng huyết áp và nguy cơ tim mạch, đột quỵ. Cách quy đổi: 1 g NaCl chứa ≈ 0,4 g Na, nên **muối ≈ natri × 2,5**. Người Việt hiện ăn trung bình khoảng 9 g muối/ngày, gần gấp đôi khuyến nghị.

### 2.3. Hấp thu và bài xuất

- **Hấp thu** chủ yếu ở **ruột non**, mỗi muối có cơ chế riêng. **NaCl, KCl** hấp thu dễ nhất.
- Sau khi vào máu, muối được đưa đến mô theo chức năng: **sắt** chủ yếu về **gan**; **Ca, P, Mg, F** về **xương, răng**; **NaCl** đọng nhiều ở **da**.
- **Bài xuất** qua ba đường:

| Đường | Muối chủ yếu |
|---|---|
| **Phân** | Fe, Ca, phosphat, Mg, kim loại nặng (Hg, Pb, Bi, Cu) |
| **Nước tiểu** (phần lớn muối) | Na, K, Ca, Cl, S, I, Co, P |
| **Mồ hôi** | Một phần NaCl, sulfat |

### 2.4. Vai trò chung

1. **Cấu tạo**: muối Ca, P không tan tạo hình xương, răng; P có trong acid nucleic, màng tế bào (phospholipid).
2. **Giữ protein ở trạng thái keo** ổn định trong tế bào và mô.
3. **Tạo áp suất thẩm thấu**: phần lớn áp suất thẩm thấu của dịch cơ thể do **chất vô cơ hòa tan** tạo ra, từ đó quyết định sự phân bố nước.
4. **Hệ đệm**: hai hệ đệm chính là **bicarbonat** và **phosphat**.
5. **Hoạt hóa hoặc ức chế enzym**: Cl^−^ hoạt hóa **amylase**; Na^+^, K^+^ hoạt hóa **ATPase**; kim loại nặng **ức chế** enzym.
6. **Thành phần enzym, coenzym, hormon** (iod trong hormon giáp), tham gia **đông máu** (Ca^2+^) và **dẫn truyền thần kinh**.

### 2.5. Một số chất vô cơ quan trọng

#### a) Natri — cation chính ngoài tế bào

- **Na^+^ máu: 136–145 mmol/L** (giáo trình).
- **Vì sao Na^+^ quyết định thể tích ngoại bào?** Na^+^ là chất tan chủ yếu của dịch ngoại bào và hầu như bị "nhốt" ở ngoài tế bào nhờ bơm Na^+^-K^+^. Thêm Na^+^ thì áp suất thẩm thấu ngoại bào tăng, nước bị giữ lại, **thể tích huyết tương tăng**. Do đó **tổng lượng Na^+^ quyết định thể tích ngoại bào**, còn **nồng độ Na^+^ phản ánh tỷ lệ nước so với muối**.
- Na^+^ tham gia **thăng bằng acid – base** nhờ trao đổi **Na^+^/H^+^** ở ống thận, và tham gia **kích thích thần kinh – cơ**.
- Mỗi ngày ăn vào **100–200 mmol** Na^+^, hấp thu **tích cực** ở ruột non.
- **Thận** là cơ quan điều hòa Na^+^: lọc ở cầu thận, **tái hấp thu ≈ 70% ở ống lượn gần**, phần còn lại ở **quai Henle và ống lượn xa**. Khi cần, thận tái hấp thu tới **99%** Na^+^ đã lọc.
- **Aldosteron** (vỏ thượng thận) **tăng** tái hấp thu Na^+^, nước theo sau. **ANP** (tâm nhĩ) **tăng** lọc cầu thận và tăng thải Na^+^, nước.

#### b) Kali — cation chính trong tế bào

- **98%** K^+^ nằm **trong tế bào**, chỉ 2% ngoài tế bào. Trong tế bào ≈ **150 mmol/L**; ngoài tế bào **3,5–5 mmol/L**.
- Chênh lệch này do **bơm Na^+^-K^+^-ATPase** duy trì.
- Vai trò: chuyển hóa tế bào (hoạt hóa nhiều enzym), **kích thích thần kinh – cơ**, điều hòa nồng độ H^+^.
- Ăn vào **80–100 mmol/ngày**; hấp thu ở ruột non; lọc ở cầu thận, **tái hấp thu ở ống lượn gần**. **Bài xuất K^+^** phụ thuộc **lượng Na^+^ được tái hấp thu** ở đoạn xa và **nồng độ aldosteron**.
- Điều quan trọng không chỉ là nồng độ K^+^ máu mà là **tỷ lệ K^+^ trong / ngoài tế bào**. Tỷ lệ này quyết định điện thế nghỉ và điện thế hoạt động (xem vl-05). Tăng hay giảm K^+^ máu đều làm rối loạn tỷ lệ, gây **loạn nhịp tim và liệt cơ**.

> [!bay] Kali máu thấp chưa chắc là thiếu kali toàn cơ thể
> Vì chỉ 2% K^+^ ở ngoài tế bào, K^+^ máu thay đổi mạnh khi K^+^ **dịch chuyển** qua màng:
> - **Vào tế bào** (hạ K^+^ máu): **insulin**, kích thích **β~2~** (salbutamol, adrenalin), **nhiễm kiềm**.
> - **Ra khỏi tế bào** (tăng K^+^ máu): **nhiễm toan**, thiếu insulin, **tan máu, ly giải cơ**, tổn thương mô.
> Ví dụ: bệnh nhân nhiễm toan ceton đái tháo đường có thể có K^+^ máu bình thường hoặc cao dù **tổng K^+^ cơ thể đã thiếu**; khi truyền insulin, K^+^ máu tụt nhanh. Vì vậy phải theo dõi và bù K^+^.

#### c) Clo — anion chính ngoài tế bào

- **Cl^−^ huyết thanh: 99–109 mmol/L** (giáo trình).
- Vai trò: giữ **thể tích** dịch, **áp suất thẩm thấu** ngoại bào và **trung hòa điện**. Cl^−^ đi theo Na^+^ nên thay đổi song song với Na^+^ và lượng nước. Lệch tỷ lệ Na^+^/Cl^−^ góp phần làm thay đổi thăng bằng acid – base.
- Ăn vào **70–200 mmol/ngày** dưới dạng muối Na, K. Ở thận, Cl^−^ được tái hấp thu **thụ động theo Na^+^** ở ống lượn gần và quai Henle. Thừa thì thải qua nước tiểu, mồ hôi.
- Ra mồ hôi nhiều kích thích tiết **aldosteron**; aldosteron tác động lên **tuyến mồ hôi** để giữ Na^+^ và Cl^−^.

**Sự đổi chỗ của clo (clo shift, hiện tượng Hamburger).** Ở mô, CO~2~ khuếch tán vào hồng cầu. Enzym **carbonic anhydrase** (CA) trong hồng cầu xúc tác:

=> CO~2~ + H~2~O ⇌ H~2~CO~3~ ⇌ H^+^ + HCO~3~^−^

H^+^ được **hemoglobin đệm** (tạo HHb). HCO~3~^−^ tích lại trong hồng cầu nên khuếch tán ra huyết tương. Để giữ cân bằng điện, **Cl^−^ đi vào hồng cầu** đổi chỗ cho HCO~3~^−^ (qua protein trao đổi anion band 3 — sh-04). Ở phổi, quá trình đảo ngược.

#### d) Bicarbonat (HCO~3~^−^)

- **Anion nhiều thứ hai** của dịch ngoại bào; là dạng chính của CO~2~ trong huyết tương, chiếm **trên 90% CO~2~ toàn phần**.
- **HCO~3~^−^ huyết thanh: 22–28 mmol/L.** Là thành phần của **hệ đệm bicarbonat**, hoạt động ngay khi pH máu thay đổi; cũng là dạng vận chuyển CO~2~ từ mô đến phổi.
- Thận điều chỉnh HCO~3~^−^: tái hấp thu gần hoàn toàn (**90% ở ống lượn gần**, phần còn lại ở ống lượn xa).
  - **Nhiễm acid chuyển hóa**: HCO~3~^−^ máu **giảm**; thận tăng thải H^+^.
  - **Nhiễm kiềm chuyển hóa**: HCO~3~^−^ máu **tăng**; thận tăng thải HCO~3~^−^ cùng Na^+^.
- Chi tiết: bài **hs-16**.

#### e) Calci

- **> 99%** calci nằm trong **xương**; khoảng **1%** ở máu và dịch ngoại bào; trong bào tương rất ít. Theo giáo trình, nồng độ Ca trong máu cao hơn trong tế bào cơ tim, cơ trơn **5.000–10.000 lần**. Chênh lệch khổng lồ này cho phép Ca^2+^ làm **tín hiệu**: chỉ cần mở kênh là Ca^2+^ ùa vào tế bào.
- Ba dạng Ca trong máu:

| Dạng | Tỷ lệ | Ghi chú |
|---|---|---|
| **Tự do** (ion hóa, Ca^2+^) | ≈ **45%** | Dạng **có hoạt tính sinh học** |
| Gắn **protein** (chủ yếu albumin) | ≈ **40%** | Thay đổi theo albumin máu |
| Phức với anion (bicarbonat, citrat, phosphat, lactat) | ≈ **15%** | Thay đổi khi truyền nhiều máu citrat, khi phẫu thuật |

- **Hạ calci máu**: giảm hormon cận giáp (PTH), **giảm magnesi**, **giảm albumin**, tổn thương cầu thận, bệnh gan mạn, suy dinh dưỡng.
- **Tăng calci máu**: **cường cận giáp** (nguyên nhân chính), sau đó là **khối u**; giáo trình nêu thêm cường giáp và **thuốc lợi niệu** làm tăng tái hấp thu Ca ở thận.

> [!bay]
> - **Lợi niệu nhóm thiazid** làm **tăng** tái hấp thu Ca (có thể gây tăng Ca máu). **Furosemid** (lợi niệu quai) thì ngược lại, làm **tăng thải** Ca. "Thuốc lợi niệu gây tăng Ca" trong sách là nói về thiazid.
> - **Giảm albumin** làm Ca **toàn phần** giảm nhưng Ca^2+^ **tự do** có thể vẫn bình thường (hạ Ca "giả").

> [!ung-dung] Đọc kết quả calci
> - **Ca toàn phần** thường 2,15–2,55 mmol/L; **Ca^2+^ ion hóa** 1,15–1,30 mmol/L (tham khảo, mỗi phòng xét nghiệm có khoảng riêng).
> - Hiệu chỉnh theo albumin (công thức hay dùng): **Ca hiệu chỉnh = Ca đo được + 0,02 × (40 − albumin g/L)** (mmol/L). Ví dụ Ca 1,90 mmol/L, albumin 25 g/L → Ca hiệu chỉnh = 1,90 + 0,02 × 15 = **2,20 mmol/L**, gần bình thường.
> - **Nhiễm kiềm** (ví dụ thở nhanh khi lo âu) làm albumin gắn Ca nhiều hơn → Ca^2+^ tự do **giảm** → tê quanh miệng, **co quắp tay** dù Ca toàn phần bình thường.

#### f) Phosphat

- Có nhiều trong tế bào; thành phần của **DNA (ADN), RNA** (ARN), coenzym, các hợp chất phosphat **giàu năng lượng**: ATP, GTP, creatin phosphat, **2,3-DPG** (2,3-diphosphoglycerat; tên hiện nay là 2,3-bisphosphoglycerat).
- **Thiếu phosphat** làm **cạn ATP** và giảm 2,3-DPG trong hồng cầu → hemoglobin **giữ oxy chặt hơn**, mô khó nhận oxy.
- Nguyên nhân chính của **giảm phosphat máu** là phosphat **đi vào tế bào** (để tổng hợp phosphat hữu cơ). Khi phosphat hữu cơ thoái hóa, phosphat vô cơ ra máu và được **thận** điều hòa.
- Theo giáo trình: phosphat máu toàn phần ≈ **12 mg% (3,9 mmol/L)**, chủ yếu là phosphat **hữu cơ**; phosphat **vô cơ** chỉ **3–4 mg%**. **Xương** chứa **80%** phosphat toàn cơ thể.

> [!ung-dung] Hội chứng nuôi ăn lại (refeeding)
> Người suy kiệt lâu ngày được cho ăn hoặc truyền glucose nhiều đột ngột: insulin tăng, glucose và **phosphat ùa vào tế bào** để tạo glucose-6-phosphat, ATP. Phosphat máu (kèm K^+^, Mg^2+^) **tụt mạnh**, có thể gây suy hô hấp, suy tim, tử vong. Đây là ví dụ rõ nhất cho câu của sách "giảm phosphat máu chủ yếu do phosphat vào tế bào". Xét nghiệm hay đo **phosphat vô cơ**: người lớn khoảng 0,8–1,45 mmol/L (tham khảo).

#### g) Magnesi (bổ sung)

Giáo trình chỉ nhắc Mg trong phần phân bố và nhu cầu (0,3 g/ngày). Mg^2+^ là **cation nhiều thứ hai trong tế bào**, khoảng một nửa nằm trong xương. Mg^2+^ là cofactor của hầu hết enzym dùng ATP (cơ chất thật là **phức Mg-ATP**). Mg máu khoảng 0,7–1,0 mmol/L (tham khảo). **Thiếu Mg^2+^** làm giảm tiết PTH → **hạ Ca** khó điều chỉnh, và làm thận mất K^+^ → **hạ K^+^** khó điều chỉnh. Vì vậy hạ Ca, hạ K^+^ "kháng trị" thì phải kiểm tra Mg.

> [!ung-dung] Khoảng tham chiếu điện giải đồ (người lớn)
> | Chỉ số | Giáo trình | Thường dùng hiện nay |
> |---|---|---|
> | Na^+^ | 136–145 mmol/L | 135–145 mmol/L |
> | K^+^ | 3,5–5 mmol/L | 3,5–5,0 mmol/L |
> | Cl^−^ | 99–109 mmol/L | 98–107 mmol/L |
> | HCO~3~^−^ | 22–28 mmol/L | 22–29 mmol/L |
> | Áp lực thẩm thấu huyết tương | — | 275–295 mOsm/kg |
>
> Số liệu tham khảo, mỗi phòng xét nghiệm có khoảng riêng. Mẫu máu **bị tan máu** (lấy máu khó, garo lâu, để lâu không ly tâm) cho **K^+^ tăng giả** vì K^+^ trong hồng cầu thoát ra.

## 3. Sự trao đổi muối – nước

Trao đổi muối và nước **không tách rời** nhau. Muối và nước được hấp thu ở ống tiêu hóa, đưa đến mô; đồng thời nước mang chất thải đến ống tiêu hóa, thận, da, phổi để đào thải. Nhờ đó muối nước của cơ thể luôn được **đổi mới**.

### 3.1. Các yếu tố quyết định sự vận chuyển và phân bố nước

#### a) Áp suất thẩm thấu (ASTT)

ASTT của một dịch do các chất hòa tan trong dịch đó tạo nên. Giáo trình (tr. 258) chia chất hòa tan thành **ba loại**:

| Loại chất tan | Đặc điểm | Vai trò trong ASTT giữa các khu vực |
|---|---|---|
| **Chất điện giải** | Ngoại bào: Na^+^, Cl^−^; nội bào: K^+^, phosphat | **Gần như quyết định** ASTT của từng khu vực |
| **Chất hữu cơ phân tử nhỏ** (glucose, ure, acid amin/amino acid) | Qua màng tế bào và thành mạch tương đối dễ | Nồng độ gần như nhau ở các khu vực → ASTT do chúng gần như **ngang nhau** |
| **Chất hữu cơ phân tử lớn**, nhất là **protein** | Lượng khác nhau giữa các khu vực, khó qua màng | Tạo **áp suất keo** |

**Quy tắc**: ASTT có tác dụng **giữ nước và kéo nước** vào khu vực của nó. Nơi nào ASTT cao, nước đi vào nơi đó. Nước vào làm loãng dịch, ASTT giảm, cho đến khi hai bên **đẳng trương**.

> [!bay] Chất nào "kéo" nước giữa hai khu vực?
> Một chất chỉ gây chênh lệch thẩm thấu **có hiệu lực** khi nó **không qua được** màng ngăn cách hai khu vực.
> - Qua **màng tế bào**: Na^+^ (ngoài) và K^+^ (trong) có hiệu lực vì bị bơm giữ lại; **ure** đi qua tự do nên **không** kéo nước (gọi là chất thẩm thấu không hiệu lực). Glucose có hiệu lực khi thiếu insulin, vì khi đó glucose khó vào nhiều loại tế bào.
> - Qua **thành mao mạch**: Na^+^, Cl^−^, glucose đều qua dễ, nên **chỉ protein** (albumin) tạo chênh lệch, tức **áp suất keo**.

#### b) Áp lực thủy tĩnh (ALTT)

ALTT do nước ép lên màng tế bào, hoặc do dòng máu ép lên thành mạch (huyết áp). ALTT có tác dụng **đẩy nước ra** khỏi khu vực của nó: nơi nào ALTT cao, nước rời khỏi nơi đó.

#### c) Cân bằng Donnan và áp suất do keo

Thí nghiệm Donnan (tr. 258–259): bình chia đôi bằng màng bán thấm. Ngăn 1 chứa NaCl nồng độ **a**; ngăn 2 chứa natri proteinat (Na^+^R^−^) nồng độ **b**. Nước, Na^+^, Cl^−^ qua màng được; ion keo **R^−^ thì không**. Sau một thời gian, x mol/L NaCl từ ngăn 1 sang ngăn 2 và đạt **cân bằng Donnan**:

=> (a − x)(a − x) = (b + x)·x  →  x = a² / (b + 2a)

- **Định luật Donnan 1**: khi cân bằng, **tích số nồng độ các ion khuếch tán** ở hai bên màng **bằng nhau**: [Na^+^]~1~·[Cl^−^]~1~ = [Na^+^]~2~·[Cl^−^]~2~.
- **Định luật Donnan 2**: ở mỗi bên, **tổng điện tích dương = tổng điện tích âm**.
- Kết quả: bên có ion keo proteinat có **tổng số tiểu phân nhiều hơn**, nên **ASTT cao hơn**. Chênh lệch ASTT do ion keo **cộng với** các ion khuếch tán bị nó giữ lại gọi là **áp suất do keo** (áp suất keo).

Cách giải bài tập Donnan và ý nghĩa: xem vl-03 mục 1.5c (cùng công thức, ký hiệu C~1~, C~2~).

> [!vi-du] Tính nhanh
> a = 0,1 mol/L NaCl; b = 0,1 mol/L NaR. x = 0,01/(0,1 + 0,2) ≈ **0,033 mol/L**.
> Cân bằng: ngăn 1 có Na^+^ = Cl^−^ = 0,067 (tổng 0,133 mol/L tiểu phân). Ngăn 2 có Na^+^ = 0,133; R^−^ = 0,1; Cl^−^ = 0,033 (tổng 0,267 mol/L). Kiểm tra: 0,067 × 0,067 ≈ 0,133 × 0,033 ≈ 0,0044. Ngăn chứa protein có **gấp đôi** số tiểu phân, nên hút nước.

#### d) Các yếu tố khác

**Sức bền thành mạch**, sức bền của **màng tế bào**, **lực co bóp của tim** và **lưu lượng máu** cũng ảnh hưởng đến vận chuyển nước.

### 3.2. Trao đổi giữa các khu vực

#### a) Giữa huyết tương và dịch gian bào — qua thành mao mạch

Thành mao mạch cho nước và chất phân tử nhỏ qua, nhưng **giữ protein**. Huyết tương có **60–80 g/L protein** nên ASTT keo trong lòng mạch ≈ **25 mmHg**; dịch gian bào ít protein, ASTT keo ≈ **10 mmHg**. Huyết áp mao mạch thay đổi dọc đường đi: đầu mao động mạch **30 mmHg**, giữa mao mạch 23 mmHg, đầu mao tĩnh mạch **15 mmHg**. ALTT dịch gian bào ≈ **8 mmHg**.

![Hình 2. Trao đổi nước giữa huyết tương và dịch kẽ theo số liệu của giáo trình (tr. 259–260)](trao-doi-mao-mach.svg)

| | Đầu mao động mạch | Đầu mao tĩnh mạch |
|---|---|---|
| Lực đẩy ra = HA − ALTT kẽ | 30 − 8 = 22 | 15 − 8 = 7 |
| Lực kéo vào = ASTT keo máu − ASTT keo kẽ | 25 − 10 = 15 | 25 − 10 = 15 |
| **Chênh lệch** | **+7 mmHg**: nước và **chất dinh dưỡng đi ra** mô | **−8 mmHg**: nước và **chất cặn bã đi vào** mạch |

**Vì sao áp suất keo gần như không đổi dọc mao mạch còn huyết áp thì giảm?** Protein không ra khỏi mạch nên nồng độ của nó gần như giữ nguyên; còn huyết áp bị tiêu hao do ma sát khi máu chảy. Chính sự **giảm dần huyết áp** làm chiều trao đổi đổi ngược từ đầu động mạch sang đầu tĩnh mạch.

> [!bay]
> - vl-03 dùng số liệu khác (kPa, huyết áp 4 → 2 kPa, chênh áp keo 2 kPa) nhưng **cùng nguyên lý**. Môn Hóa sinh: thuộc số của giáo trình Hóa sinh (30/15/25/10/8 mmHg → +7/−8).
> - Phần dịch lọc ra **nhiều hơn** phần hút về một chút; phần dư được **bạch huyết** đưa về tuần hoàn.

> [!cap-nhat] Nguyên lý Starling sửa đổi
> Giáo trình (và nhiều sách kinh điển) mô tả: lọc ra ở đầu động mạch, **hút về** ở đầu tĩnh mạch. Nghiên cứu sinh lý vi tuần hoàn gần đây (nguyên lý Starling sửa đổi, vai trò lớp **glycocalyx** lót lòng mạch) cho thấy ở phần lớn mô, khi ổn định, sự **hút về liên tục ở đầu tĩnh mạch rất ít**; dịch lọc ra chủ yếu trở về qua **bạch huyết**. Mô hình cũ vẫn đúng về **hướng tác động** của từng lực và vẫn dùng để giải thích phù. Đi thi trả lời theo sơ đồ của giáo trình.

> [!ung-dung] Phù và albumin
> - **Giảm protein máu** (xơ gan, hội chứng thận hư, suy dinh dưỡng): ASTT keo máu giảm → lực kéo vào giảm → **phù**, có thể kèm tràn dịch màng bụng (cổ trướng), màng phổi.
> - **Tăng huyết áp tĩnh mạch** (suy tim phải, huyết khối tĩnh mạch): ALTT đầu tĩnh mạch tăng → phù chân.
> - **Tăng tính thấm thành mạch** (viêm, dị ứng, bỏng, sốc nhiễm khuẩn): protein lọt ra mô, kéo nước theo.
> - Danh sách đầy đủ 4 cơ chế: vl-03 mục 1.6a.

#### b) Giữa trong và ngoài tế bào — qua màng tế bào

- Màng tế bào cho **nước qua lại tự do**. Nước thường **đi theo** chất điện giải để san bằng chênh lệch ASTT.
- Các chất khác qua màng **có chọn lọc**, nhiều chất theo cơ chế **vận chuyển tích cực**, để giữ chênh lệch nồng độ.
- **Bơm Na^+^, K^+^-ATPase**: mỗi ATP thủy phân đưa **3 Na^+^ ra** và **2 K^+^ vào**, ngược gradient nồng độ. Khoảng **25% năng lượng lúc nghỉ** của cơ thể dùng cho bơm này (giáo trình).
- Na^+^, K^+^ còn qua **kênh ion** khi dẫn truyền thần kinh – cơ.
- Cl^−^/HCO~3~^−^: trao đổi ngược chiều (**antiport**) trong clo shift.
- H^+^: đi **cùng chiều** (**symport**) với lactat, glucose, acid amin; đi **ngược chiều** (antiport) với Ca^2+^, K^+^.
- Chi tiết các kiểu vận chuyển: sh-04 và bài **Hóa sinh màng tế bào** (hs-13).

> [!vi-du] Vì sao tế bào không vỡ dù trong tế bào đầy protein?
> Protein và phosphat hữu cơ trong tế bào tạo hiệu ứng Donnan: lẽ ra nước sẽ liên tục đi vào làm tế bào phình rồi vỡ. Bơm Na^+^-K^+^ đẩy 3 Na^+^ ra, chỉ đưa 2 K^+^ vào, nên liên tục **"bơm" chất tan ra ngoài**, làm Na^+^ ngoại bào thành chất thẩm thấu có hiệu lực, cân bằng lại. Khi **thiếu ATP** (thiếu máu cục bộ, ngộ độc), bơm ngừng, Na^+^ và nước tràn vào → **phù tế bào**. Đây là cơ chế phù não sớm trong đột quỵ.

### 3.3. Áp lực thẩm thấu huyết tương — tính toán và ứng dụng

Đơn vị: **osmol** = số mol tiểu phân hòa tan. Tính trên 1 kg nước gọi là **osmolality** (mOsm/kg, đo bằng máy đo độ hạ băng điểm); tính trên 1 L dung dịch gọi là **osmolarity** (mOsm/L). Trong huyết tương hai giá trị gần bằng nhau.

Na^+^ luôn đi kèm một anion (Cl^−^, HCO~3~^−^), nên lấy **2 × Na^+^** để tính cả anion. Công thức thường dùng ở Việt Nam (các nồng độ đều tính bằng **mmol/L**):

=> ASTT huyết tương (mOsm/kg) ≈ 2 × [Na^+^] + [glucose] + [ure]

*(Lưu ý viết tắt: trong bài này ASTT là áp suất/áp lực thẩm thấu, ALTT là áp lực thủy tĩnh — đừng lẫn hai chữ.)*

- Bình thường: 2 × 140 + 5 + 5 = **290 mOsm/kg** (khoảng 275–295).
- Nếu glucose và BUN tính bằng mg/dL (tài liệu Mỹ): 2 × Na + glucose/18 + BUN/2,8.
- **Áp lực thẩm thấu hiệu dụng** (trương lực, *tonicity*) = 2[Na^+^] + [glucose], **bỏ ure** vì ure qua màng tế bào tự do.
- **Khoảng trống thẩm thấu** (osmolar gap) = giá trị **đo** − giá trị **tính**. Bình thường dưới khoảng 10. Khoảng trống tăng gợi ý có chất thẩm thấu "lạ": **ethanol, methanol, ethylen glycol**, mannitol.

> [!vi-du] Ba ví dụ tính
> 1. Na^+^ 140, glucose 5, ure 5 → 280 + 5 + 5 = **290 mOsm/kg**: bình thường.
> 2. Đái tháo đường mất bù: Na^+^ 150, glucose 40, ure 15 → 300 + 40 + 15 = **355 mOsm/kg**: **tăng áp lực thẩm thấu** nặng (trạng thái tăng áp lực thẩm thấu do tăng glucose máu thường > 320). Áp lực hiệu dụng = 300 + 40 = 340. Tế bào não mất nước → lơ mơ, hôn mê.
> 3. Người uống rượu: Na^+^ 140, glucose 5, ure 5 → tính được 290, nhưng **máy đo 330** → khoảng trống 40 mOsm/kg → nghĩ tới chất thẩm thấu ngoại sinh (ethanol, hoặc nguy hiểm hơn là methanol trong rượu pha cồn công nghiệp).

> [!bay] Glucose máu tăng làm natri máu giảm
> Glucose máu rất cao (khi thiếu insulin) là chất thẩm thấu **có hiệu lực**: nó kéo nước từ tế bào ra ngoại bào, **pha loãng Na^+^**. Kết quả: Na^+^ đo được **thấp** dù tổng Na^+^ không giảm. Ước tính thường dùng: glucose tăng mỗi 5,6 mmol/L (100 mg/dL) thì Na^+^ giảm khoảng 1,6 mmol/L. Khi glucose về bình thường, Na^+^ sẽ tăng trở lại.

> [!ung-dung] Các dịch truyền thường dùng
> | Dịch | Thành phần (mmol/L) · ASTT | Ở lại đâu · dùng khi |
> |---|---|---|
> | **NaCl 0,9%** ("nước muối sinh lý") | Na^+^ 154, Cl^−^ 154 · ≈ 308 mOsm/L lý thuyết (hiệu dụng ≈ 286) | **Ngoại bào** · bù dịch ngoại bào, sốc giảm thể tích, mất nước đẳng trương, pha thuốc |
> | **Ringer lactat** | Na^+^ 130, K^+^ 4, Ca^2+^ ≈ 1,4, Cl^−^ 109, lactat 28 · ≈ 273 (hơi nhược trương) | **Ngoại bào** · bù dịch khi tiêu chảy, bỏng, phẫu thuật; lactat được gan chuyển thành HCO~3~^−^ |
> | **Glucose 5%** | Glucose 278 · ≈ 278 khi còn trong chai | **Nước toàn phần** (glucose bị chuyển hóa) · bù **nước tự do** (mất nước ưu trương), ít năng lượng; **không** bù thể tích máu |
> | NaCl 3% | Na^+^, Cl^−^ 513 · ≈ 1026 (**ưu trương**) | Kéo nước ra khỏi tế bào · hạ Na^+^ máu nặng có triệu chứng thần kinh (theo phác đồ chuyên khoa) |
>
> - NaCl 0,9% chứa Cl^−^ **154** mmol/L, cao hơn nhiều so với huyết tương (≈ 100). Truyền lượng lớn có thể gây **nhiễm toan tăng clo**. Ringer lactat gần huyết tương hơn về Cl^−^.
> - Ringer lactat có **Ca^2+^**, nên không truyền chung đường với máu chống đông bằng citrat (tạo phức, gây đông).
> - Liên hệ: glucose 5% đẳng trương "trong chai" nhưng "nhược trương trong cơ thể" — xem vl-03 mục 1.5d.

> [!ung-dung] Oresol (ORS) — vì sao có glucose?
> Ở ruột non, **SGLT1** đồng vận chuyển **Na^+^ cùng glucose** (2 Na^+^ : 1 glucose). Cơ chế này **vẫn hoạt động** khi tiêu chảy do độc tố tả. Na^+^ được hấp thu kéo theo nước. Vì vậy uống dung dịch muối có glucose bù nước hiệu quả hơn nước muối đơn thuần. ORS **nồng độ thẩm thấu thấp** của WHO/UNICEF (2002): Na^+^ 75, Cl^−^ 65, glucose 75, K^+^ 20, citrat 10 mmol/L; tổng **245 mOsm/L**.
> - Pha **đúng lượng nước** ghi trên gói. Pha đặc quá → dung dịch ưu trương, kéo nước vào lòng ruột, **tiêu chảy nặng hơn** và có thể gây tăng Na^+^ máu ở trẻ nhỏ.
> - Nước ngọt, nước tăng lực **không thay thế** được ORS: nhiều đường, ít Na^+^, ASTT cao.

## 4. Điều hòa trao đổi muối nước

Cơ thể khỏe mạnh luôn giữ được nhu cầu nước, cân bằng nước và điện giải nhờ **cơ chế thần kinh, nội tiết** cùng sự tham gia của **ống tiêu hóa, thận, phổi, da**.

![Hình 3. Ba trục điều hòa muối nước: ADH, renin – angiotensin – aldosteron và ANP](dieu-hoa.svg)

### 4.1. Cơ chế thần kinh

**Thụ thể thẩm thấu** và **thụ thể thể tích** ở **vùng dưới đồi** (hypothalamus) rất nhạy:

- ASTT huyết tương **tăng 1–2%** → bài tiết **ADH tăng tới 4 lần**, đồng thời gây **khát**.
- ASTT **giảm 1–2%** → **ngừng** bài tiết ADH.

### 4.2. Cơ chế nội tiết

#### a) ADH (vasopressin, hormon chống bài niệu)

- **Peptid** do **vùng dưới đồi tổng hợp**, **dự trữ ở thùy sau tuyến yên** (hậu yên).
- Tác dụng: tăng **tính thấm nước** của ống thận (ống lượn xa, ống góp) → tăng tái hấp thu **nước**, **cô đặc nước tiểu**.
- **Thiếu ADH**: không tái hấp thu được nước → đái nhiều, nước tiểu loãng (**đái nhạt**, đái tháo nhạt).
- **Điều hòa**: thể tích tuần hoàn **giảm** hoặc ASTT huyết tương **tăng** → khát + tăng ADH → uống nhiều, giữ nước ở thận → thể tích tăng, ASTT giảm → ức chế ADH và hết khát (**điều hòa ngược âm tính**).

> [!vi-du] Cơ chế phân tử (bổ sung)
> ADH gắn thụ thể **V2** ở tế bào ống góp → tăng AMP vòng → các kênh nước **aquaporin-2** được gắn lên màng phía lòng ống → nước thấm từ lòng ống vào tủy thận ưu trương. Rượu (ethanol) ức chế tiết ADH, nên uống bia rượu làm đi tiểu nhiều và dễ mất nước.

#### b) Aldosteron và hệ renin – angiotensin

- **Aldosteron**: hormon **vỏ thượng thận** (lớp cầu), tăng **tái hấp thu Na^+^** ở ống thận (đoạn xa, ống góp) và tăng **thải K^+^, H^+^**. Nước được tái hấp thu theo Na^+^.
- Bài tiết aldosteron được điều hòa qua **hệ renin – angiotensin** (Hình 15.3 của giáo trình):
  1. **Áp suất tưới máu thận giảm** (giảm thể tích máu, tụt huyết áp) → thận tiết **renin**.
  2. Renin cắt **angiotensinogen** (do gan sản xuất) thành **angiotensin I**.
  3. Enzym chuyển **ACE** (có nhiều ở mao mạch **phổi**) biến angiotensin I thành **angiotensin II**.
  4. Angiotensin II gây **co mạch** (tăng huyết áp) và kích thích vỏ thượng thận tiết **aldosteron** → **giữ Na^+^ và H~2~O**.
- Tăng K^+^ máu cũng kích thích trực tiếp tiết aldosteron.

#### c) ANP (atrial natriuretic peptide — peptid lợi niệu natri tâm nhĩ)

- **Peptid** do **tế bào cơ tâm nhĩ** tổng hợp, giải phóng khi **thể tích máu tăng, huyết áp tăng** (thành nhĩ bị căng).
- Tác dụng lên thận: **tăng tốc độ lọc cầu thận** và **giảm tái hấp thu Na^+^** ở ống thận → **tăng thải Na^+^ và nước**. Theo Zeidel và Brenner (giáo trình trích), ANP làm giãn mao mạch cầu thận, tăng lọc.
- ANP **đối kháng** với hệ renin – angiotensin – aldosteron.

| Hormon | Nơi tiết | Kích thích tiết | Tác dụng chính lên thận | Kết quả |
|---|---|---|---|---|
| **ADH** | Vùng dưới đồi → hậu yên | ↑ ASTT, ↓ thể tích | ↑ tái hấp thu **nước** | Giữ nước, nước tiểu đặc |
| **Aldosteron** | Vỏ thượng thận | Angiotensin II, ↑ K^+^ | ↑ tái hấp thu **Na^+^**, ↑ thải K^+^, H^+^ | Giữ muối + nước |
| **ANP** | Tâm nhĩ | ↑ thể tích, ↑ huyết áp | ↑ lọc, ↓ tái hấp thu Na^+^ | Thải muối + nước |

> [!bay]
> - **ADH điều chỉnh nồng độ** (giữ nước "thuần", làm **giảm** Na^+^ máu nếu tiết quá mức). **Aldosteron điều chỉnh thể tích** (giữ Na^+^ kèm nước, nên Na^+^ máu thay đổi ít).
> - ADH và ANP đều là **peptid**; aldosteron là **steroid**. Renin là **enzym**, không phải hormon tác dụng trực tiếp lên ống thận.
> - ACE nằm nhiều ở **phổi** chứ không phải ở thận.

> [!ung-dung] Thuốc tác động lên hệ điều hòa
> - **Thuốc ức chế men chuyển** (captopril, enalapril…) và **chẹn thụ thể angiotensin II** (losartan…): hạ huyết áp; giảm aldosteron nên có thể **tăng K^+^ máu**.
> - **Spironolacton**: đối kháng aldosteron → lợi tiểu **giữ K^+^**.
> - **Furosemid, thiazid**: tăng thải Na^+^ ở đoạn trước, đưa nhiều Na^+^ đến đoạn xa → tăng trao đổi Na^+^/K^+^ → **mất K^+^** (hạ K^+^ máu).

### 4.3. Các cơ quan tham gia

Theo giáo trình, quan trọng nhất là **cơ quan tiêu hóa** (hấp thu nước, muối) và **thận** (cơ quan điều chỉnh chính), sau đó là **da** (mồ hôi) và **phổi** (hơi thở).

## 5. Rối loạn nước – điện giải

Rối loạn nước – điện giải **rất hay gặp** trên lâm sàng và đa dạng về nguyên nhân. Đánh giá đúng mức độ và nguyên nhân để điều chỉnh kịp thời thì hiệu quả điều trị tăng lên nhiều.

- Rối loạn **nước**: **thừa nước** hoặc **thiếu nước**.
- Rối loạn **điện giải**: **tăng** hoặc **hạ** điện giải trong máu. Hai ion liên quan chặt nhất với thay đổi nước của huyết tương là **Na^+^ và K^+^**.

**Các thông số đánh giá** (giáo trình tr. 262):

1. **Thể tích tuần hoàn** (mạch, huyết áp, áp lực tĩnh mạch trung tâm, hematocrit).
2. **Thể tích nước tiểu** (lượng nước tiểu/24 giờ).
3. **ASTT của huyết tương và của nước tiểu**.
4. **Định lượng điện giải** trong **máu** và trong **nước tiểu** (điện giải đồ).

*Phần dưới đây mở rộng ý của giáo trình (sách chỉ nêu nguyên tắc), dùng để hiểu và làm câu tình huống.*

### 5.1. Mất nước — ba kiểu

Kiểu mất nước được gọi theo **ASTT (hay Na^+^) của dịch ngoại bào còn lại**:

| | **Đẳng trương** | **Ưu trương** | **Nhược trương** |
|---|---|---|---|
| Bản chất | Mất nước và muối **tương đương** | Mất **nước nhiều hơn** muối | Mất **muối nhiều hơn** nước (hoặc chỉ bù nước, không bù muối) |
| Na^+^ máu, ASTT | **Bình thường** | **Tăng** (Na^+^ > 145) | **Giảm** (Na^+^ < 135) |
| Nước di chuyển | Không đổi giữa hai khu vực | Từ **tế bào ra** ngoại bào | Từ ngoại bào **vào tế bào** |
| Khu vực bị thiếu | **Ngoại bào** | **Nội bào** chủ yếu (tế bào teo) | Ngoại bào thiếu nặng; tế bào **phù** |
| Biểu hiện nổi bật | Mạch nhanh, tụt huyết áp, da mất đàn hồi | **Khát dữ dội**, niêm mạc khô, sốt, rối loạn ý thức | **Không khát**, trụy mạch sớm, buồn nôn, chuột rút, lú lẫn, co giật |
| Nguyên nhân hay gặp | Tiêu chảy, nôn, mất máu, bỏng, dẫn lưu | Không uống được (người già, hôn mê), sốt, mồ hôi nhiều, **đái tháo nhạt**, lợi niệu thẩm thấu (đái tháo đường) | Suy vỏ thượng thận (**Addison**), lạm dụng lợi tiểu, tiêu chảy/nôn chỉ bù bằng nước lọc |
| Dịch bù (nguyên tắc) | NaCl 0,9%, Ringer lactat | Nước uống, glucose 5% (bù **từ từ**) | NaCl 0,9%; nặng: NaCl ưu trương theo phác đồ |

> [!bay] Khát hay không khát?
> Khát do **ASTT tăng** và do **giảm thể tích** gây ra. Trong mất nước **ưu trương**, tế bào (kể cả tế bào thần kinh vùng dưới đồi) mất nước, nên **khát nhiều nhất**. Trong mất nước **nhược trương**, ASTT giảm nên bệnh nhân thường **không khát** dù thiếu dịch nặng.

### 5.2. Thừa nước và phù

- **Ngộ độc nước** (thừa nước nhược trương): uống hoặc truyền quá nhiều nước không muối, nhất là khi ADH tiết không thích hợp (SIADH) hoặc suy thận. Na^+^ giảm, nước vào tế bào → **phù não**: đau đầu, nôn, co giật.
- **Phù** (thừa nước và muối ở dịch kẽ): do mất cân bằng Starling (mục 3.2a) **cộng với** thận **giữ Na^+^**. Ở **suy tim, xơ gan, hội chứng thận hư**, thể tích máu "hiệu dụng" giảm → hệ renin – angiotensin – aldosteron hoạt hóa (**cường aldosteron thứ phát**) → giữ muối nước → phù nặng thêm. Vì vậy điều trị phù cần **ăn nhạt** và thuốc lợi tiểu (thường có spironolacton).

### 5.3. Rối loạn natri

| | **Hạ Na^+^ máu** (< 135 mmol/L) | **Tăng Na^+^ máu** (> 145 mmol/L) |
|---|---|---|
| Thực chất | Thường là **thừa nước** so với muối | Thường là **thiếu nước** so với muối |
| Nguyên nhân | Mất muối (lợi tiểu thiazid, Addison, nôn – tiêu chảy bù bằng nước lọc); thừa nước (SIADH, suy tim, xơ gan, uống quá nhiều nước); glucose máu rất cao kéo nước ra ngoại bào (ASTT **không** giảm). *Giả hạ Na^+^* thật sự là sai số đo khi mỡ máu hoặc protein máu rất cao | Không uống được, mất nước qua da, hơi thở, đái tháo nhạt, lợi niệu thẩm thấu; hiếm khi do truyền nhiều NaCl, NaHCO~3~ |
| Hậu quả | Nước vào tế bào → **phù não**: buồn nôn, lú lẫn, co giật, hôn mê | Tế bào mất nước → **não teo**: khát, kích thích, co giật, hôn mê; có thể **xuất huyết não** |

> [!bay] Điều chỉnh natri phải chậm
> Hạ hoặc tăng Na^+^ **mạn tính** thì tế bào não đã tự thích nghi (đẩy ra hoặc tích thêm chất thẩm thấu). Nếu nâng Na^+^ lên **quá nhanh**, nước bị rút đột ngột khỏi tế bào não → **hội chứng hủy myelin do thẩm thấu**. Ngược lại, hạ Na^+^ quá nhanh khi điều trị tăng Na^+^ → **phù não**. Khuyến cáo thường dùng: với hạ Na^+^ mạn, nâng Na^+^ **không quá khoảng 8–10 mmol/L trong 24 giờ**.

### 5.4. Rối loạn kali

| | **Hạ K^+^ máu** (< 3,5 mmol/L) | **Tăng K^+^ máu** (> 5,0 mmol/L) |
|---|---|---|
| Nguyên nhân mất / thừa | **Mất qua tiêu hóa** (nôn, tiêu chảy); **mất qua thận** (lợi tiểu furosemid, thiazid; cường aldosteron; dùng nhiều **Cam thảo** — giả cường aldosteron, xem hs-14); ăn thiếu | **Suy thận** (không thải được); thiếu aldosteron (Addison); thuốc **ức chế men chuyển, chẹn thụ thể AT II, spironolacton**; truyền/uống nhiều K^+^ |
| Nguyên nhân dịch chuyển | K^+^ vào tế bào: **insulin**, chất kích thích β~2~, **nhiễm kiềm** | K^+^ ra khỏi tế bào: **nhiễm toan**, thiếu insulin, **tan máu, ly giải cơ** (dập nát cơ, bỏng) |
| Biểu hiện | **Yếu cơ, liệt mềm**, liệt ruột (chướng bụng, táo bón); điện tim: **T dẹt, sóng U**; loạn nhịp; tăng độc tính **digoxin** | Yếu cơ, dị cảm; điện tim: **T cao nhọn**, QRS giãn; **rung thất, ngừng tim** — cấp cứu |

**Vì sao cả hạ lẫn tăng K^+^ đều làm liệt cơ?** Điện thế nghỉ phụ thuộc tỷ lệ [K^+^]~trong~/[K^+^]~ngoài~ (phương trình Nernst, vl-05). **Hạ K^+^** ngoài tế bào làm màng **ưu cực** hơn, khó đạt ngưỡng → cơ yếu. **Tăng K^+^** làm màng **khử cực một phần** kéo dài → kênh Na^+^ bị bất hoạt → cũng không phát được điện thế hoạt động. Tim rất nhạy với thay đổi này.

> [!ung-dung] Tăng kali máu — xử trí theo cơ chế hóa sinh
> - **Calci gluconat/clorid** tĩnh mạch: ổn định màng tế bào cơ tim (tác dụng trong vài phút, không làm giảm K^+^).
> - **Insulin + glucose**, **salbutamol**: đẩy K^+^ **vào tế bào** (đúng cơ chế dịch chuyển ở trên).
> - **Lợi tiểu quai, nhựa trao đổi ion, lọc máu**: **thải** K^+^ ra khỏi cơ thể.
> - Trước khi xử trí, loại trừ **tăng K^+^ giả** do mẫu máu bị tan máu.

> [!yhct] Thuốc "lợi thủy thẩm thấp" và điện giải
> - **Quan niệm YHCT**: nhóm **lợi thủy thẩm thấp** (Phục linh, Trư linh, Trạch tả, Xa tiền tử, Ý dĩ…) dùng khi "thủy thấp đình trệ": tiểu ít, phù. Bài kinh điển **Ngũ linh tán** (Trư linh, Phục linh, Trạch tả, Bạch truật, Quế chi). Lưu ý: "thẩm thấp" ở đây là khái niệm YHCT (cho thấp tà thoát ra qua đường tiểu), **không** phải áp suất thẩm thấu của hóa sinh.
> - **Bằng chứng**: tác dụng **lợi niệu** của Trạch tả, Trư linh, Phục linh và Ngũ linh tán (tăng lượng nước tiểu, tăng thải Na^+^, Cl^−^) được ghi nhận chủ yếu trên **động vật thực nghiệm**; cơ chế chưa thống nhất. Thử nghiệm trên người còn **ít và nhỏ**. Tác dụng, nếu có, **yếu hơn nhiều** so với furosemid. Một số dược liệu lợi tiểu như **Râu ngô** chứa nhiều **muối kali**; dược liệu học coi đây là một phần lý do gây lợi tiểu.
> - **Hệ quả thực hành**: thuốc lợi tiểu, dù là thảo dược, đều có thể gây **mất nước và rối loạn điện giải** khi dùng liều cao, kéo dài, ở người già, hoặc khi **phối hợp với lợi tiểu tân dược**. Người suy thận, đang dùng thuốc giữ K^+^ (spironolacton, ức chế men chuyển) cần thận trọng với nước sắc giàu kali. Nên kiểm tra **điện giải đồ** khi dùng lâu. Mang tiêu (Na~2~SO~4~) gây tả hạ thẩm thấu: xem bài *Kim loại khối s (IA, IIA)* (mã vc-01). Cam thảo hạ K^+^: xem bài *Hóa sinh hormon* (mã hs-14).

> [!vi-du] Câu hỏi ôn tập của giáo trình (tr. 262) và chỗ trả lời
> 1. Vai trò và phân bố muối vô cơ → mục 2.1, 2.4, 2.5.
> 2. Các yếu tố quyết định vận chuyển và phân bố nước → mục 3.1.
> 3. Vận chuyển nước, chất giữa trong – ngoài tế bào, trong – ngoài thành mạch → mục 3.2.
> 4. Điều hòa trao đổi muối nước → mục 4.
> 5. Các thông số đánh giá rối loạn nước – điện giải → mục 5.

## Tóm tắt

| Chủ đề | Điều cốt lõi |
|---|---|
| Nước | 55–65% P người lớn; trẻ càng nhỏ càng nhiều nước; mỡ ít nước (25–30%). Nước tự do / nước kết hợp (hydrat hóa, bị cầm). |
| Phân bố | Giáo trình: nội bào 55%, ngoại bào 45% nước toàn phần. Quy ước lâm sàng: 60% P – 2/3 nội bào – 1/3 ngoại bào (3/4 kẽ, 1/4 huyết tương). |
| Bilan | Vào 2500 mL (uống 1200, ăn 1000, chuyển hóa 300) = ra 2500 mL (tiểu 1400, mồ hôi 500, thở 500, phân 100). |
| Chất vô cơ | 4–5% P. Ngoài tế bào: Na^+^ (136–145), Cl^−^ (99–109), HCO~3~^−^ (22–28). Trong tế bào: K^+^ (≈150; máu 3,5–5), phosphat, Mg. Ca: 99% ở xương; máu 45% tự do – 40% gắn protein – 15% phức. |
| Yếu tố vận chuyển nước | ASTT kéo nước vào (điện giải quyết định; protein → áp suất keo); ALTT đẩy nước ra; Donnan: x = a²/(b + 2a). |
| Mao mạch | (30 − 8) − (25 − 10) = +7 → ra; (15 − 8) − (25 − 10) = −8 → về; dư → bạch huyết. |
| Màng tế bào | Nước qua tự do; bơm Na^+^-K^+^: 3 Na^+^ ra / 2 K^+^ vào / 1 ATP; ≈ 25% năng lượng lúc nghỉ. |
| Điều hòa | Thụ thể thẩm thấu (ASTT ↑ 1–2% → ADH × 4, khát). ADH giữ nước; aldosteron (qua renin → AT I → ACE → AT II) giữ Na^+^, thải K^+^; ANP thải Na^+^, nước. |
| Áp lực thẩm thấu | 2Na^+^ + glucose + ure ≈ 290 mOsm/kg; hiệu dụng bỏ ure; khoảng trống thẩm thấu > 10 → rượu, methanol… |
| Dịch truyền | NaCl 0,9% và Ringer lactat → ngoại bào; glucose 5% → nước tự do (không bù thể tích máu); ORS dựa vào đồng vận chuyển Na^+^–glucose. |
| Rối loạn | Mất nước đẳng / ưu (Na^+^ ↑, khát) / nhược trương (Na^+^ ↓, không khát). Hạ – tăng Na^+^ → triệu chứng thần kinh, chỉnh chậm. Hạ – tăng K^+^ → liệt cơ, loạn nhịp. Thông số: thể tích tuần hoàn, nước tiểu, ASTT máu – nước tiểu, điện giải máu – nước tiểu. |
