---
title: Hóa học glucid
thoi-gian: 40 phút
muc-tieu:
- Trình bày được định nghĩa, cách phân loại và gọi tên monosaccharid; viết được dạng vòng của các monosaccharid hay gặp.
- Trình bày được tính khử và các dẫn xuất quan trọng của monosaccharid (acid aldonic, acid uronic, ester phosphat, đường amin, deoxy đường, acid sialic).
- Nêu được công thức, tính khử và nguồn gốc của saccharose, lactose, maltose.
- So sánh được tinh bột, glycogen và cellulose; nêu được cấu tạo của chitin.
- Trình bày được cấu tạo và vai trò của glycosaminoglycan, proteoglycan, glycoprotein và cơ sở glucid của nhóm máu ABO.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Phần "hóa học thuần" (Fischer, Haworth, α/β, phản ứng, disaccharid, tinh bột) đã học ở [bài Glucid môn Hóa (hc-08b)](#/bai/nam-1/hoa-hoc/hc-08b). Bài này thêm **góc nhìn của tế bào**.
> 2. Glucose được tế bào "sửa" thành nhiều **dẫn xuất**: ester phosphat (dạng hoạt hóa), acid uronic, đường amin, deoxy đường, acid sialic. Chính các dẫn xuất này xây nên glycosaminoglycan và glycoprotein.
> 3. **Glycosaminoglycan (GAG)** = chuỗi thẳng, lặp lại đơn vị **[acid uronic – hexosamin]**, tích điện âm dày đặc nên hút nước, tạo gel đàn hồi: acid hyaluronic, chondroitin sulfat, heparin, keratan sulfat.
> 4. **Proteoglycan** = protein nhỏ + rất nhiều GAG (đường chiếm phần lớn). **Glycoprotein** = protein là chính + chuỗi oligosaccharid ngắn, phân nhánh.
> 5. Nhóm máu **A, B, O** khác nhau chỉ ở **một gốc đường tận cùng** trên màng hồng cầu.

## 1. Đại cương và phân loại

Giáo trình dùng ba tên gần như đồng nghĩa: **glucid**, **carbohydrat**, **saccarid**. Tên "carbohydrat" xuất phát từ công thức thô (C.H~2~O)~n~ với n ≥ 3 (Giáo trình tr. 17). Vì sao công thức này không đủ để định nghĩa glucid, xem [hc-08b mục 1](#/bai/nam-1/hoa-hoc/hc-08b).

| Nhóm | Định nghĩa trong giáo trình Hóa sinh | Ví dụ |
|---|---|---|
| **Monosaccharid** (đường đơn) | Đơn vị cấu tạo, không thủy phân được nữa | Glucose, fructose, ribose |
| **Oligosaccharid** | Gồm **2–14** monosaccharid; hay gắn với protein (glycoprotein) hoặc lipid (glycolipid) | Saccharose, lactose, maltose; chuỗi đường trên màng tế bào |
| **Polysaccharid** | Phân tử lớn gồm rất nhiều monosaccharid | Tinh bột, glycogen, cellulose, chitin, GAG |

> [!bay] Hai giáo trình, hai con số
> - Giáo trình Hóa sinh (tr. 17): oligosaccharid gồm **2–14** gốc đường, và phân loại thành **3 nhóm** mono – oligo – poly.
> - Giáo trình Hóa học (bài hc-08b) chia **2 nhóm** (monose – polyose) và lấy mốc 2–10.
> - Khi thi môn nào, trả lời theo giáo trình môn đó.

**Vì sao hóa sinh quan tâm đến oligosaccharid gắn protein, lipid?** Vì đó là "lớp áo đường" (glycocalyx) phủ mặt ngoài màng tế bào. Lớp áo này giúp tế bào **nhận diện** nhau, làm thụ thể cho hormon, virus, và quyết định nhóm máu (mục 7). Xem thêm cấu tạo màng ở môn Sinh học (sh-02).

## 2. Monosaccharid

Monosaccharid là dẫn xuất aldehyd hoặc ceton của polyalcol, có **ít nhất 3 carbon**, không thủy phân được thành chất nhỏ hơn (Giáo trình tr. 17).

### 2.1. Phân loại, danh pháp, dãy D/L

Gọi tên theo hai tiêu chí (Giáo trình tr. 18):

- **Nhóm carbonyl**: aldehyd → **aldose** (glucose); ceton → **cetose** (fructose).
- **Số carbon**: triose (3C), tetrose, pentose, hexose, heptose… Ghép lại: glucose là *aldohexose*, ribulose là *cetopentose*.
- **Dãy D/L**: so –OH ở **C\* xa nhóm carbonyl nhất** với D-glyceraldehyd. Bên phải → D; bên trái → L. Đường dãy L "kém dồi dào" trong sinh vật (cơ thể người dùng gần như toàn đường dãy D; ngoại lệ đáng nhớ: **L-fucose**, **L-iduronic acid**).

**Họ D-aldose và họ D-cetose.** Giáo trình (hình 1.1, 1.2, tr. 18–19) vẽ cây gia phả: mỗi lần thêm 1 carbon ngay dưới nhóm carbonyl thì sinh ra 2 đường mới, khác nhau ở cấu hình carbon mới thêm.

| Bậc | Họ D-aldose (gốc: D-glyceraldehyd) | Họ D-cetose (gốc: dihydroxyaceton) |
|---|---|---|
| 4C | D-erythrose, D-threose | D-erythrulose |
| 5C | D-ribose, D-arabinose, D-xylose, D-lyxose | **D-ribulose**, **D-xylulose** |
| 6C | D-allose, D-altrose, **D-glucose**, **D-mannose**, D-gulose, D-idose, **D-galactose**, D-talose | D-psicose, **D-fructose**, D-sorbose, D-tagatose |

Các đường in đậm là đường có vai trò lớn trong chuyển hóa ở người. Ribulose và xylulose (dạng phosphat) là chất trung gian của **con đường pentose phosphat**.

**Số đồng phân quang học.** Với mạch n carbon (Giáo trình tr. 19):

- Aldose có **n − 2** C\* → 2^n−2^ đồng phân. Aldohexose: 2^4^ = 16.
- Cetose có **n − 3** C\* → 2^n−3^ đồng phân. Cetohexose: 2^3^ = 8.

Vì sao cetose ít hơn 1 C\*? Vì nhóm C=O nằm ở C2, nên cả C1 (CH~2~OH) lẫn C2 (C=O) đều không bất đối.

**Epimer** là hai đường chỉ khác nhau ở cấu hình của **một** C\* (Giáo trình tr. 18):

- D-glucose và D-mannose: epimer ở **C2**.
- D-glucose và D-galactose: epimer ở **C4**.
- D-mannose và D-galactose: **không** phải epimer, vì khác nhau ở hai carbon (C2 và C4).

> [!ung-dung] Epimer trong cơ thể: bệnh galactose huyết
> Galactose từ sữa muốn dùng được phải "đổi" cấu hình C4 để thành glucose. Quá trình này cần enzym **galactose-1-phosphat uridyltransferase (GALT)** và một enzym **epimerase** (đổi cấu hình C4). Trẻ **thiếu GALT bẩm sinh** bị **galactose huyết** (galactosemia): bú sữa thì nôn, vàng da, gan to, **đục thủy tinh thể**, chậm phát triển trí tuệ. Điều trị: **loại bỏ lactose và galactose** khỏi chế độ ăn ngay khi nghi ngờ. Chi tiết sẽ học ở chương Chuyển hóa glucid.

### 2.2. Cấu tạo vòng

Phần cơ chế (–OH ở C5 cộng vào nhóm carbonyl, sinh C anomer, α/β, công thức Haworth) đã có ở [hc-08b mục 2](#/bai/nam-1/hoa-hoc/hc-08b). Giáo trình Hóa sinh bổ sung các điểm sau (Giáo trình tr. 19–20):

- Aldose khép vòng tạo **hemiacetal**; cetose tạo **hemicetal**. Carbon carbonyl cũ trở thành C\* mới, nên sinh ra hai dạng **α** và **β**. Hai dạng này là cặp **diastereoisomer** (không phải đối ảnh), nên khác nhau về tính chất lý hóa.
- Góc quay riêng [α]~D~^20^: α-D-glucose **+112,2°**; β-D-glucose **+18,7°**. Hòa tan một dạng tinh khiết, góc quay thay đổi dần đến **+52,7°**. Lúc cân bằng: **36,4% α**, **63,6% β**, chỉ khoảng **0,1% mạch thẳng**.
- Tỷ lệ vòng 6 cạnh (pyranose) và vòng 5 cạnh (furanose) trong dung dịch:

| Đường | Pyranose | Furanose |
|---|---|---|
| Glucose | Gần như 100% | Không đáng kể |
| Fructose | 67% | 33% |
| Ribose | 75% | 25% |

> [!bay]
> - Trong **dung dịch**, fructose tự do chủ yếu là **pyranose**. Nhưng trong **saccharose** và trong các ester phosphat của chuyển hóa (fructose-6-phosphat, fructose-1,6-bisphosphat), fructose ở dạng **furanose**.
> - Ribose trong **RNA (ARN), ATP, NAD** cũng luôn ở dạng **furanose**, dù trong dung dịch tự do nó ưu tiên pyranose.
> - Dấu (+)/(−) chỉ chiều quay mặt phẳng ánh sáng phân cực, **không** liên quan tới D/L.

### 2.3. Tính khử và các dẫn xuất oxy hóa – khử

Mọi monosaccharid đều có tính khử, vì có nhóm aldehyd (hoặc ceton chuyển được thành dạng enediol). Khi khử ion kim loại nặng (Cu, Hg, Bi), đường bị **oxy hóa** (Giáo trình tr. 20–21).

![Hình 1. Các dẫn xuất chính của D-glucose. Nhóm thay đổi được tô màu](dan-xuat-glucose.svg)

| Dẫn xuất | Vị trí thay đổi | Ví dụ | Vai trò sinh học |
|---|---|---|---|
| **Acid aldonic** | C1: –CHO → –COOH | Acid gluconic | Sản phẩm của phản ứng khử thuốc thử. Glucono-δ-lacton là chất trung gian của con đường pentose phosphat |
| **Acid uronic** | C cuối mạch: –CH~2~OH → –COOH (nhóm CHO giữ nguyên) | Acid **D-glucuronic**, D-galacturonic, D-mannuronic | Thành phần của GAG; **liên hợp khử độc** ở gan |
| **Alcol đường (alditol)** | C1: –CHO → –CH~2~OH | Sorbitol (từ glucose), galactitol (từ galactose) | Tích tụ trong thủy tinh thể khi đường huyết cao kéo dài |
| **Đường amin** | C2: –OH → –NH~2~ | Glucosamin, galactosamin | Thành phần GAG, chitin, glycoprotein (mục 2.7) |

**Thuốc thử dùng tính khử** (Giáo trình tr. 20):

- **Nylander** (bismut nitrat kiềm): đường khử Bi^3+^ thành **bismut kim loại màu đen**.
- **Cu(OH)~2~** (Fehling, Benedict): tạo kết tủa **Cu~2~O đỏ gạch**.
- Tollens: xem [hc-08b mục 4.2](#/bai/nam-1/hoa-hoc/hc-08b).

> [!bay] Aldonic hay uronic?
> - Acid **aldonic** (gluconic): oxy hóa **C1** (nhóm aldehyd). Còn lại –CH~2~OH ở C6.
> - Acid **uronic** (glucuronic): oxy hóa **C6** (alcol bậc 1). Nhóm aldehyd ở C1 **vẫn còn**, nên acid uronic vẫn đóng vòng được và vẫn tham gia liên kết glycosid. Nhờ vậy nó mới nằm được trong chuỗi GAG.
> - Mẹo nhớ: "**on**ic – đầu **on**" (C1, đầu mạch); "**uro**nic – đuôi" (C6, cuối mạch).

> [!ung-dung] Acid glucuronic và chức năng khử độc của gan
> Gan gắn acid glucuronic (từ dạng hoạt hóa **UDP-glucuronat**) vào bilirubin, nhiều thuốc (paracetamol, morphin…) và hormon steroid. Sản phẩm là các **glucuronid**: tan trong nước hơn, nên dễ thải qua mật hoặc nước tiểu. Ví dụ quan trọng: **bilirubin liên hợp** (bilirubin trực tiếp) chính là bilirubin glucuronid. Khi enzym liên hợp này yếu (trẻ sơ sinh, hội chứng Gilbert), **bilirubin gián tiếp** tăng và gây vàng da.

> [!yhct] Hoạt chất dạng glucuronid trong dược liệu
> Một số hoạt chất chính của dược liệu có phần đường là **acid glucuronic**:
> - **Baicalin** của **Hoàng cầm** = baicalein gắn 1 gốc acid glucuronic.
> - **Glycyrrhizin** của **Cam thảo** = acid glycyrrhetinic gắn 2 gốc acid glucuronic.
>
> Phần lớn các chất này hấp thu kém ở dạng nguyên vẹn. Enzym **β-glucuronidase của vi khuẩn ruột** cắt bỏ phần đường, giải phóng aglycon để hấp thu. Đây là cơ chế đã được chứng minh qua nghiên cứu dược động học trên người. Với Cam thảo, chính aglycon (acid glycyrrhetinic) là chất gây tác dụng phụ giả cường aldosteron (cơ chế 11β-HSD2: xem khung YHCT ở bài *Hóa sinh hormon*, mã hs-14). Do đó tác dụng và độc tính của dược liệu có thể **thay đổi theo hệ vi khuẩn ruột** và khi dùng kháng sinh kéo dài. Đây là lý giải dược lý hiện đại, không thay cho quan niệm YHCT về tính vị, quy kinh. Phần glycosid nói chung và việc diệt enzym khi bào chế: xem [hc-08b](#/bai/nam-1/hoa-hoc/hc-08b).

> [!ung-dung] Sorbitol và biến chứng mắt của đái tháo đường
> Ở thủy tinh thể, thần kinh, thận, enzym **aldose reductase** khử glucose thành sorbitol. Khi đường huyết cao kéo dài, sorbitol tạo ra nhiều nhưng khó ra khỏi tế bào. Nó kéo nước vào theo thẩm thấu, góp phần gây **đục thủy tinh thể** và tổn thương thần kinh ở người đái tháo đường. Cơ chế tương tự (với galactitol) gây đục thủy tinh thể trong bệnh galactose huyết.

### 2.4. Tạo glycosid

–OH bán acetal (–OH hemiacetal) gắn với –OH của một alcol tạo **liên kết glycosid**. Khi alcol đó lại là một monosaccharid khác, ta được oligo- và polysaccharid (Giáo trình tr. 21). Chi tiết phản ứng: [hc-08b mục 4.2c](#/bai/nam-1/hoa-hoc/hc-08b).

Hóa sinh phân biệt hai loại liên kết glycosid:

- **O-glycosid**: C anomer nối với **O** (giữa các gốc đường; đường gắn vào Ser/Thr của protein).
- **N-glycosid**: C anomer nối với **N**. Ví dụ: ribose nối với base nitơ trong nucleotid (ATP, RNA); đường gắn vào **Asn** của protein (glycoprotein dạng N, mục 6).

### 2.5. Chuyển dạng lẫn nhau

Trong kiềm yếu (Ba(OH)~2~, Ca(OH)~2~), glucose, fructose và mannose chuyển qua lại với nhau qua dạng trung gian **enediol** (Giáo trình tr. 21). Trong tế bào, việc này do enzym làm, đặc hiệu và nhanh hơn nhiều. Ví dụ: enzym **phosphohexose isomerase** chuyển glucose-6-phosphat ⇌ fructose-6-phosphat ở bước 2 của đường phân. Bước này cũng đi qua một dạng enediol.

### 2.6. Dẫn xuất ester phosphat

–OH alcol của đường tạo ester với acid phosphoric. Giáo trình (tr. 21) liệt kê các ester quan trọng. Tất cả đều là chất trung gian chuyển hóa:

| Ester | Gặp ở con đường |
|---|---|
| Glucose-6-phosphat | Ngã ba của chuyển hóa glucose: đường phân, tổng hợp glycogen, pentose phosphat |
| Glucose-1-phosphat | Tổng hợp và thoái hóa glycogen |
| β-D-fructose-6-phosphat | Đường phân |
| Phosphoglyceraldehyd, phosphodihydroxyaceton | Đường phân (hai triose phosphat) |
| Ribose-5-phosphat, D-xylulose-5-phosphat, D-sedoheptulose-7-phosphat | Con đường pentose phosphat (ribose-5-P dùng để tổng hợp nucleotid) |

**Vì sao tế bào phải phosphoryl hóa đường ngay khi vào?**

1. **"Nhốt" đường trong tế bào.** Nhóm phosphat tích điện âm, không đi qua được chất vận chuyển glucose của màng.
2. **Hoạt hóa** phân tử để các enzym tiếp theo xử lý.
3. Giữ nồng độ glucose tự do trong tế bào thấp, nên glucose tiếp tục khuếch tán vào.

Ngoài ester phosphat, đường còn được hoạt hóa dạng **nucleotid-đường** (UDP-glucose, UDP-glucuronat, CMP-acid sialic…) để làm nguyên liệu xây glycogen, GAG, glycoprotein.

### 2.7. Đường amin, deoxy đường, acid sialic (bổ sung)

Giáo trình chỉ nhắc các chất này khi mô tả GAG (tr. 23–24). Tuy vậy, chúng là "viên gạch" của mọi glucid phức tạp ở người:

| Nhóm | Cấu tạo | Ví dụ | Có ở đâu |
|---|---|---|---|
| **Đường amin** (hexosamin) | –OH ở C2 thay bằng –NH~2~; thường bị acetyl hóa thành –NH–CO–CH~3~ | **Glucosamin**, **galactosamin**; N-acetylglucosamin (**GlcNAc**), N-acetylgalactosamin (**GalNAc**) | GAG, chitin, glycoprotein, nhóm máu A |
| **Deoxy đường** | Thiếu một nguyên tử O (–OH thay bằng –H) | **2-deoxy-D-ribose**; **L-fucose** (6-deoxy-L-galactose) | DNA (ADN); chuỗi đường nhóm máu (kháng nguyên H) |
| **Acid sialic** | Đường 9C có nhóm –COOH, tạo từ N-acetylmannosamin và phosphoenolpyruvat (PEP); dạng hay gặp nhất là acid **N-acetylneuraminic (NANA)** | NANA | **Đầu tận cùng** chuỗi đường của glycoprotein và ganglioside (lipid màng thần kinh) |
| **Acid uronic** | Xem mục 2.3 | Glucuronic, **L-iduronic** (epimer C5 của glucuronic) | GAG |

> [!ung-dung] Acid sialic, virus cúm và thuốc oseltamivir
> Acid sialic tích điện âm, nằm ở ngọn các chuỗi đường trên bề mặt tế bào. Virus cúm dùng hemagglutinin **bám vào acid sialic** để xâm nhập tế bào đường hô hấp. Khi virus mới ra khỏi tế bào, enzym **neuraminidase** của virus cắt acid sialic để virus tách ra và lây tiếp. **Oseltamivir** (Tamiflu) ức chế neuraminidase, nên virus bị "dính lại", không lan được.

> [!bay] Glucosamin trong dược phẩm
> Glucosamin và chondroitin sulfat bán làm thực phẩm chức năng "bổ khớp" vì chúng là nguyên liệu của sụn. Uống vào thì chúng bị tiêu hóa, chuyển hóa như các chất khác, **không** đi thẳng vào sụn. Các phân tích tổng hợp thử nghiệm lâm sàng cho thấy hiệu quả giảm đau thoái hóa khớp **nhỏ, không nhất quán**.

## 3. Oligosaccharid

Oligosaccharid hay gặp nhất là **disaccharid** (Giáo trình tr. 21). Hình công thức Haworth và tính chất chung: [hc-08b mục 5](#/bai/nam-1/hoa-hoc/hc-08b). Giáo trình Hóa sinh viết tên **hệ thống**, ghi số liệu góc quay và enzym thủy phân:

| | **Saccharose** (sucrose) | **Lactose** | **Maltose** |
|---|---|---|---|
| Tên hệ thống | O-α-D-glucopyranosyl-(1→2)-β-D-fructofuranosid | O-β-D-galactopyranosyl-(1→4)-D-glucopyranose | O-α-D-glucopyranosyl-(1→4)-glucopyranose |
| Liên kết | C1 glucose – C2 fructose (nối hai C anomer) | β(1→4) | α(1→4) |
| Tính khử | **Không** | Có (còn –OH bán acetal ở gốc glucose) | Có |
| Góc quay | +66,5° | +55,5° | — |
| Enzym thủy phân ở ruột | Saccarase (sucrase) | Lactase | Maltase |
| Nguồn | Mía, củ cải đường | Sữa người và động vật ("đường sữa") | Mầm lúa, kẹo mạch nha; sản phẩm thủy phân tinh bột |

**Hiện tượng "đảo cực"** (Giáo trình tr. 21). Saccharose quay phải (+66,5°). Thủy phân ra D-glucose (+52,7°) và D-fructose (**−92,4°**). Fructose quay trái mạnh hơn glucose quay phải, nên hỗn hợp quay trái.

> [!bay] Đọc tên hệ thống để suy tính khử
> - Tên kết thúc bằng **"-osid"** (saccharose: …fructofuranos**id**): cả hai C anomer đều đã bị "khóa" trong liên kết, nên **không** có tính khử.
> - Tên kết thúc bằng **"-ose"** (lactose, maltose: …glucopyran**ose**): gốc cuối còn –OH bán acetal tự do, nên **có** tính khử.

> [!ung-dung] Không dung nạp lactose
> Thiếu lactase thì lactose xuống đại tràng, bị vi khuẩn lên men, gây đầy hơi, tiêu chảy. Xem [hc-08b mục 5](#/bai/nam-1/hoa-hoc/hc-08b). Phân biệt với **galactose huyết** (mục 2.1): đây là bệnh thiếu enzym ở **gan** để chuyển hóa galactose đã hấp thu, nguy hiểm hơn nhiều.

## 4. Polysaccharid dự trữ và cấu trúc

Cấu tạo chi tiết, hình vẽ, phản ứng với iod: [hc-08b mục 6](#/bai/nam-1/hoa-hoc/hc-08b). Dưới đây là các **số liệu riêng** của giáo trình Hóa sinh (tr. 22–24) và phần chitin.

### 4.1. Tinh bột

Tinh bột nằm trong bào tương tế bào thực vật, dạng hạt nhỏ không tan, gồm hai thành phần:

- **α-Amylose** (12–25%): tan trong nước. Chuỗi thẳng hàng nghìn gốc glucose nối **α(1→4)**, cuộn thành **xoắn quay trái** đều đặn.
- **Amylopectin** (75–85%): không tan. Khoảng **10^6^** gốc glucose, phân nhánh như "bụi cây". Mạch chính nối α(1→4), điểm nhánh nối **α(1→6)**. Mỗi nhánh dài **24–30** gốc.

Tỷ lệ amylose/amylopectin khác nhau theo nguồn tinh bột. Ví dụ, gạo nếp gần như toàn amylopectin nên dẻo, dính.

> [!cap-nhat] Lỗi in trong giáo trình
> Giáo trình (tr. 22) viết: "Tinh bột là thức ăn dự trữ của **động vật**". Đúng phải là dự trữ của **thực vật**. Chất dự trữ của động vật là **glycogen** (mục 4.2). Chính câu tiếp theo trong sách cũng nói tinh bột ở "tế bào thực vật".

### 4.2. Glycogen ("tinh bột động vật")

- Gồm **2.400–24.000** gốc glucose. Có trong mọi tế bào, nhưng nhiều nhất ở **gan** (tới **10%** khối lượng gan) và **cơ xương** (khoảng **0,9%**). Nằm thành hạt trong bào tương.
- Cấu trúc giống amylopectin nhưng **nhiều nhánh hơn** và **nhánh ngắn hơn**: mỗi nhánh chỉ **8–12** gốc.

**Vì sao glycogen cần nhiều nhánh như vậy?**

1. Enzym thoái hóa (glycogen phosphorylase) chỉ cắt từ **đầu không khử** của mỗi nhánh. Nhiều nhánh nghĩa là nhiều đầu, nên huy động glucose **rất nhanh** khi cơ thể cần (đói, vận động).
2. Phân nhánh làm phân tử **tan tốt hơn** và gọn hơn.
3. Dự trữ ở dạng polymer thay vì glucose tự do giúp tránh tăng áp suất thẩm thấu trong tế bào.

> [!ung-dung] Glycogen gan và glycogen cơ khác vai trò
> - **Glycogen gan** dùng để **giữ đường huyết** giữa các bữa ăn. Gan có enzym glucose-6-phosphatase để trả glucose tự do vào máu.
> - **Glycogen cơ** chỉ để **cơ tự dùng** khi co. Cơ thiếu glucose-6-phosphatase nên không trả glucose ra máu được.
> - Thiếu bẩm sinh glucose-6-phosphatase gây **bệnh von Gierke** (bệnh tích glycogen type I): gan to, **hạ đường huyết** nặng khi đói. Sẽ học kỹ ở chương Chuyển hóa glucid.

### 4.3. Cellulose

Cellulose là thành phần chính của mô nâng đỡ thực vật. Khoảng **15.000** gốc **β-D-glucose** nối **β(1→4)**. Không tan trong nước, bị thủy phân trong acid sulfuric nóng (Giáo trình tr. 23).

Người và đa số động vật **không** tiêu hóa được cellulose. Động vật ăn cỏ tiêu hóa được nhờ vi sinh vật trong ống tiêu hóa tiết **cellulase**.

> [!cap-nhat] Cellulose "là đồng phân của amylose"?
> Giáo trình (tr. 23) viết cellulose "được coi là đồng phân của amylose". Hiểu đúng: hai chất có **cùng đơn vị** glucose và cùng kiểu nối 1→4, chỉ khác cấu hình **α** hay **β** của liên kết glycosid. Về mặt hóa học chặt chẽ, chúng **không** phải đồng phân vì số gốc (n) khác nhau. Bài hc-08b cũng đã lưu ý điểm này.

### 4.4. Chitin

Chitin là thành phần quan trọng của vỏ **giáp xác, sâu bọ, nhện**, và của thành tế bào **nấm**, tảo (Giáo trình tr. 23–24).

- Là **homopolymer** của **N-acetyl-D-glucosamin**, nối **β(1→4)**.
- So với cellulose: giống hệt, chỉ khác là –OH ở **C2** được thay bằng nhóm **acetamid** (–NH–CO–CH~3~).

**So sánh bốn polysaccharid** (mục tiêu 4 của giáo trình):

| | Tinh bột | Glycogen | Cellulose | Chitin |
|---|---|---|---|---|
| Đơn vị | α-D-glucose | α-D-glucose | β-D-glucose | N-acetyl-β-D-glucosamin |
| Liên kết | α(1→4) + α(1→6) ở amylopectin | α(1→4) + α(1→6) | β(1→4) | β(1→4) |
| Phân nhánh | Amylose: không. Amylopectin: nhánh 24–30 gốc | **Nhiều**, nhánh 8–12 gốc | Không | Không |
| Số gốc | Amylopectin ~10^6^ | 2.400–24.000 | ~15.000 | — |
| Vai trò | Dự trữ của **thực vật** | Dự trữ của **động vật** | Cấu trúc thực vật | Cấu trúc vỏ côn trùng, giáp xác, nấm |
| Người tiêu hóa được? | Có (amylase) | Có | Không (chất xơ) | Không |

## 5. Glycosaminoglycan (mucopolysaccharid)

### 5.1. Đặc điểm chung

Glycosaminoglycan (GAG), tên cũ là **mucopolysaccharid**, là chuỗi polymer **không phân nhánh**. Mỗi chuỗi gồm **acid uronic** và **hexosamin** xếp **xen kẽ** nhau (Giáo trình tr. 24). Tên gọi cũng nói lên thành phần: *glycos-amino-glycan* = polysaccharid có đường amin.

**Vì sao dung dịch GAG nhớt và đàn hồi?**

1. Mỗi đơn vị lặp lại mang nhóm **–COO^−^** (acid uronic), nhiều GAG còn có thêm **–SO~3~^−^** (sulfat). Do đó GAG **tích điện âm rất dày**.
2. Các điện tích âm **đẩy nhau**, làm chuỗi duỗi dài, chiếm thể tích lớn.
3. Điện tích âm hút ion Na^+^, kéo theo **rất nhiều nước**. Kết quả là một khối gel ngậm nước.
4. Khi bị ép, nước bị đẩy ra; khi thôi ép, gel hút nước trở lại. Đây là cơ chế **đệm, chịu lực** của sụn khớp.

Theo giáo trình, nhờ tính chất đó GAG có tác dụng **bảo vệ chống lại tác nhân cơ học, hóa học**. GAG tham gia cấu tạo **mô nâng đỡ** (xương, sụn), có trong **dịch nhầy** bôi trơn các ống (thực quản…) và bao bọc niêm mạc dạ dày.

### 5.2. Các GAG chính

| GAG | Đơn vị disaccharid lặp lại (theo giáo trình) | Có ở đâu | Đặc điểm, vai trò |
|---|---|---|---|
| **Acid hyaluronic** | Acid β-D-glucuronic + N-acetyl-β-glucosamin; trong đơn vị nối β(1→3), giữa các đơn vị nối β(1→4). **250–25.000** đơn vị | Mô liên kết, **dịch thủy tinh của mắt**, cuống rốn, dịch khớp, bao của một số vi khuẩn | **Không sulfat**, không gắn đồng hóa trị với protein. Bôi trơn khớp, giữ nước |
| **Chondroitin sulfat** (4- và 6-sulfat) | Acid β-D-glucuronic + N-acetyl-hexosamin sulfat hóa ở C4 hoặc C6; nối 1→3. **50–1.000** đơn vị | **Sụn**, mô liên kết, da, gân, van tim, thành động mạch | GAG nhiều nhất cơ thể. Chịu nén cho sụn |
| **Heparin** | Uronat-2-sulfat + N-sulfo-D-glucosamin-6-sulfat, nối α(1→4) | Hạt chế tiết của **tế bào mast** quanh mạch máu; nhiều ở **phổi, gan, da** | Tích điện âm mạnh nhất. **Chống đông máu** |
| **Keratan sulfat** | β-D-galactose + N-acetyl-D-glucosamin-6-sulfat | Giác mạc, sụn | Ngoại lệ: **không có acid uronic** (thay bằng galactose) |

![Hình 2. Sơ đồ phức hợp proteoglycan của sụn: các protein lõi mang chuỗi chondroitin sulfat và keratan sulfat, gắn trên sợi acid hyaluronic](proteoglycan.svg)

> [!cap-nhat] Hai chi tiết cấu tạo giáo trình ghi chưa chính xác
> - **Chondroitin sulfat.** Giáo trình (tr. 24) ghi đường amin là "N-acetyl β-**glucosamin**-4(6)-sulfat". Hiện nay đã xác định đó là **N-acetyl-galactosamin** (GalNAc) sulfat hóa ở C4 hoặc C6. Chính tên "chondroitin" có gốc *chondrosamin* = galactosamin.
> - **Heparin.** Giáo trình ghi đơn vị là "α-D-glucuronat-2-sulfat". Hiện nay biết acid uronic chiếm ưu thế trong heparin là acid **α-L-iduronic-2-sulfat** (epimer C5 của acid glucuronic). Acid D-glucuronic chỉ chiếm phần nhỏ.
> - Ngoài ra còn hai GAG giáo trình không nhắc: **dermatan sulfat** (da, mạch máu, van tim) và **heparan sulfat** (bề mặt tế bào, màng đáy).
>
> Đi thi: trả lời theo giáo trình nếu đề hỏi đúng câu chữ của sách.

> [!bay]
> - **Acid hyaluronic** là GAG duy nhất **không sulfat** và **không** gắn đồng hóa trị với protein.
> - **Keratan sulfat** là GAG duy nhất **không có acid uronic**.
> - "Mucopolysaccharid" là tên cũ của **GAG**, không phải tên của glycoprotein.

> [!ung-dung] Heparin, hyaluronidase và acid hyaluronic trong lâm sàng
> - **Heparin** gắn vào **antithrombin III** và làm chất này bất hoạt thrombin, yếu tố Xa nhanh hơn hàng nghìn lần. Vì vậy heparin dùng **điều trị và dự phòng huyết khối** (huyết khối tĩnh mạch sâu, nhồi máu phổi). Theo dõi heparin không phân đoạn bằng xét nghiệm **aPTT**. Tác dụng phụ chính là **chảy máu**; khi quá liều, trung hòa bằng **protamin sulfat** (protein tích điện dương). Ống nghiệm lấy máu có heparin (nắp xanh lá) cũng dùng tính chống đông này.
> - **Hyaluronidase** có ở một số vi khuẩn (liên cầu, tụ cầu), tinh dịch, **nọc rắn** (Giáo trình tr. 24). Enzym cắt acid hyaluronic, phá "chất gắn" mô liên kết, nên vi khuẩn và nọc độc **lan nhanh** trong mô. Vì thế enzym này được gọi là "yếu tố lan tỏa".
> - **Acid hyaluronic** được tiêm vào khớp gối thoái hóa, dùng trong phẫu thuật mắt (giữ khoang tiền phòng khi mổ đục thủy tinh thể) và trong mỹ phẩm, chất làm đầy.

> [!ung-dung] Bệnh tích mucopolysaccharid (MPS)
> GAG được thoái hóa trong **lysosom** nhờ một dãy enzym. Thiếu bẩm sinh một enzym thì GAG tích tụ trong tế bào. Ví dụ: hội chứng **Hurler** (thiếu α-L-iduronidase), hội chứng **Hunter** (thiếu iduronat-2-sulfatase, di truyền liên kết X). Bệnh nhân có nét mặt thô, gan lách to, biến dạng xương, có thể chậm phát triển trí tuệ. Xét nghiệm sàng lọc: **GAG niệu tăng**; chẩn đoán xác định bằng định lượng enzym.

## 6. Proteoglycan và glycoprotein

### 6.1. Theo giáo trình

Giáo trình (tr. 25) định nghĩa glycoprotein là **mucopolysaccharid liên kết với protein**, bằng liên kết đồng hóa trị hoặc không đồng hóa trị. Keratan sulfat và chondroitin sulfat thường gắn đồng hóa trị với protein. Nhiều loại protein tham gia cấu tạo glycoprotein có khối lượng phân tử **200–300 kDa**.

### 6.2. Cách phân biệt hiện nay

> [!cap-nhat] Proteoglycan khác glycoprotein
> Giáo trình gộp chung dưới tên "glycoprotein". Thực ra phức hợp "GAG + protein" mà sách mô tả ngày nay được gọi là **proteoglycan**. Còn **glycoprotein** là một nhóm khác, phổ biến hơn rất nhiều:

| | **Proteoglycan** | **Glycoprotein** |
|---|---|---|
| Thành phần chính | **Đường** (GAG) chiếm phần lớn, có thể tới ~95% | **Protein** là chính; đường chiếm từ khoảng 1% đến 60–70% (mucin) |
| Chuỗi đường | GAG: dài, thẳng, đơn vị lặp lại, nhiều điện tích âm | Oligosaccharid: ngắn (thường dưới 15–20 gốc), **phân nhánh**, không lặp lại |
| Đầu chuỗi | — | Thường tận cùng bằng **acid sialic** hoặc fucose |
| Ví dụ | Aggrecan của sụn (hình 2), syndecan trên màng tế bào | Hầu hết protein huyết tương (trừ albumin), **globulin miễn dịch**, collagen, hormon FSH, LH, **hCG**, TSH, erythropoietin, mucin, thụ thể màng, kháng nguyên nhóm máu |
| Vai trò | Chịu lực, giữ nước, bôi trơn, lọc | Nhận diện tế bào, thụ thể, miễn dịch, vận chuyển, hormon, bảo vệ niêm mạc |

**Đường gắn vào protein theo hai kiểu:**

- **Kiểu N** (N-glycosid): đường (GlcNAc) gắn vào nitơ nhóm amid của **asparagin (Asn)**. Quá trình gắn bắt đầu ở **lưới nội sinh chất**.
- **Kiểu O** (O-glycosid): đường (thường GalNAc) gắn vào –OH của **serin hoặc threonin**. Quá trình gắn diễn ra ở **bộ Golgi**. Chuỗi GAG của proteoglycan cũng gắn vào Ser theo kiểu O, qua một cầu nối có xylose.

> [!bay] Glycoprotein ≠ protein bị glycat hóa
> - **Glycosyl hóa** (tạo glycoprotein): **có enzym**, đúng vị trí, có chức năng sinh lý.
> - **Glycat hóa** (glycation): glucose gắn **không cần enzym** vào nhóm –NH~2~ của protein. Mức độ tăng theo nồng độ đường huyết. Ví dụ: **HbA1c**, dùng để theo dõi đường huyết trung bình 2–3 tháng (ngưỡng chẩn đoán đái tháo đường ≥ 6,5%; chi tiết ở [hs-03 mục 4.4](#/bai/nam-1/hoa-sinh/hs-03)). Sản phẩm glycat hóa bền (AGEs) góp phần gây biến chứng mạch máu.

## 7. Nhóm máu ABO — cơ sở glucid (bổ sung)

Giáo trình không có mục này, nhưng đây là ví dụ kinh điển cho vai trò "nhận diện" của chuỗi đường.

Trên màng hồng cầu có các chuỗi oligosaccharid gắn vào protein và lipid màng. Đầu của chuỗi quyết định nhóm máu:

1. **Kháng nguyên H** (nhóm O): enzym **fucosyltransferase** gắn **L-fucose** vào galactose tận cùng (nối α1→2). Gần như mọi người đều có H.
2. **Nhóm A**: gen A mã hóa **enzym A** (một glycosyltransferase). Enzym A gắn thêm **N-acetylgalactosamin (GalNAc)** vào chất H.
3. **Nhóm B**: gen B mã hóa **enzym B**, gắn thêm **galactose** vào chất H.
4. **Nhóm O**: gen O mã hóa enzym **không hoạt động**. Chất H giữ nguyên.
5. **Nhóm AB**: có cả hai enzym, nên có cả kháng nguyên A và B.

![Hình 3. Cơ sở glucid của nhóm máu ABO: một gốc đường tận cùng quyết định kháng nguyên](nhom-mau-abo.svg)

| Nhóm máu | Kháng nguyên trên hồng cầu | Kháng thể tự nhiên trong huyết thanh |
|---|---|---|
| A | A | Kháng B |
| B | B | Kháng A |
| AB | A và B | Không có |
| O | (chỉ H) | Kháng A và kháng B |

**Vì sao người nhóm O có sẵn kháng thể kháng A, kháng B dù chưa từng truyền máu?** Vi khuẩn đường ruột mang các cấu trúc đường rất giống kháng nguyên A, B. Từ nhỏ, hệ miễn dịch tạo kháng thể (chủ yếu IgM) chống lại những cấu trúc đường mà cơ thể **không** tự có.

> [!ung-dung] Truyền máu
> - Truyền nhầm nhóm ABO gây **tan máu cấp trong lòng mạch**, có thể tử vong. Vì vậy luôn phải định nhóm máu và **thử phản ứng chéo** trước khi truyền.
> - **Hồng cầu** nhóm O không mang A, B, nên trong cấp cứu có thể truyền cho mọi nhóm (khối hồng cầu O). Nhưng **huyết tương** nhóm O chứa kháng A, kháng B, nên không dùng làm "huyết tương cho tất cả".
> - **Nhóm Bombay** (hiếm): thiếu cả enzym tạo chất H, nên không có H, A, B. Huyết thanh có kháng H, kháng A, kháng B. Người này chỉ nhận được máu Bombay. Khi định nhóm thường quy, họ dễ bị nhầm là nhóm O.

> [!bay]
> Kháng nguyên A và B khác nhau **chỉ ở một gốc đường**: GalNAc (A) và galactose (B), chỉ khác nhau nhóm thế ở C2 (–NH–CO–CH~3~ so với –OH). Bản chất của kháng nguyên nhóm máu ABO là **glucid**; gen chỉ quy định **enzym** gắn đường.

## 8. Chức năng sinh học của glucid — tổng hợp

| Chức năng | Ví dụ |
|---|---|
| **Cung cấp năng lượng** | Glucose là nhiên liệu chính; hồng cầu phụ thuộc hoàn toàn vào glucose; não dùng glucose là chính (khi đói kéo dài mới dùng thêm thể ceton) |
| **Dự trữ năng lượng** | Glycogen (động vật), tinh bột (thực vật) |
| **Cấu trúc, nâng đỡ** | Cellulose, chitin; GAG và proteoglycan trong sụn, xương, gân, da |
| **Thành phần chất mang thông tin di truyền và coenzym** | Ribose (RNA, ATP, NAD, FAD, CoA), deoxyribose (DNA) |
| **Nhận diện, thông tin giữa tế bào** | Glycoprotein, glycolipid màng (glycocalyx); nhóm máu ABO; thụ thể của virus (acid sialic) |
| **Bảo vệ, bôi trơn** | Mucin của dịch nhầy, acid hyaluronic của dịch khớp |
| **Chống đông máu** | Heparin |
| **Khử độc** | Liên hợp với acid glucuronic ở gan |
| **Tiền chất tổng hợp** | Khung carbon cho acid amin (amino acid) không thiết yếu, glycerol, acid béo |

## Tóm tắt

| Chủ đề | Điểm phải nhớ |
|---|---|
| Phân loại | Mono, oligo (2–14 gốc theo giáo trình Hóa sinh), poly |
| Đồng phân | Aldose 2^n−2^, cetose 2^n−3^. Epimer: glucose–mannose (C2), glucose–galactose (C4); mannose–galactose không phải epimer |
| Dạng vòng | α-D-glucose +112,2°, β +18,7°, cân bằng +52,7° (36,4% α : 63,6% β : 0,1% mạch thẳng). Fructose 67% pyranose, ribose 75% pyranose |
| Tính khử | Nylander → Bi đen; Cu(OH)~2~ → Cu~2~O đỏ gạch |
| Dẫn xuất | Acid aldonic (C1), acid uronic (C6), alditol (sorbitol), ester phosphat, đường amin (C2), deoxy đường, acid sialic |
| Disaccharid | Saccharose không khử, +66,5°, đảo cực (fructose −92,4°); lactose khử, +55,5°; maltose khử |
| Tinh bột | Amylose 12–25% (thẳng, xoắn trái); amylopectin 75–85%, ~10^6^ gốc, nhánh 24–30 |
| Glycogen | 2.400–24.000 gốc; gan tới 10%, cơ 0,9%; nhánh 8–12 gốc |
| Cellulose, chitin | β(1→4); ~15.000 gốc β-glucose; chitin = GlcNAc (–OH ở C2 thay bằng acetamid) |
| GAG | Thẳng, [acid uronic – hexosamin], tích điện âm. Hyaluronic (không sulfat, 250–25.000 đơn vị), chondroitin sulfat (sụn, 50–1.000), heparin (chống đông), keratan sulfat (không có acid uronic) |
| Proteoglycan / glycoprotein | Proteoglycan: đường là chính, GAG dài. Glycoprotein: protein là chính, oligosaccharid ngắn phân nhánh, gắn kiểu N (Asn) hoặc O (Ser/Thr) |
| ABO | H = chất nền có fucose; A thêm GalNAc; B thêm galactose; O không thêm |

> [!vi-du] Câu hỏi ôn tập của giáo trình (tr. 25)
> 1. Viết tên hóa học và công thức cấu tạo của α-D-glucose, β-D-fructose → xem hình Haworth ở [hc-08b](#/bai/nam-1/hoa-hoc/hc-08b). Tên đầy đủ: α-D-glucopyranose; β-D-fructofuranose.
> 2. Trình bày tính khử của monosaccharid → mục 2.3.
> 3. Giống và khác nhau giữa saccharose và lactose → mục 3. Giống: đều là disaccharid, có gốc glucose, thủy phân cho 2 monosaccharid. Khác: thành phần (glucose + fructose so với galactose + glucose), liên kết (α1↔β2 so với β1→4), tính khử (không so với có), nguồn (mía so với sữa), enzym (saccarase so với lactase).
> 4. Giống và khác nhau giữa tinh bột, glycogen, cellulose → bảng so sánh ở mục 4.4.
