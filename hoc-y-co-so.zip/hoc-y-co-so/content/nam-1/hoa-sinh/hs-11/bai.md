---
title: Chuyển hóa acid nucleic
thoi-gian: 50 phút
muc-tieu:
- Trình bày được sự thoái hóa purin nucleotid đến acid uric và pyrimidin nucleotid đến β-alanin, β-aminoisobutyrat; nêu được ý nghĩa của acid uric máu và bệnh gout.
- Trình bày được hai con đường tổng hợp nucleotid (tân tạo và tận dụng): nguồn gốc nguyên tử nhân purin, các giai đoạn tạo IMP → AMP, GMP; tạo orotat → UMP → UTP → CTP; tạo deoxyribonucleotid; sự điều hòa.
- Kể được các enzym tham gia và các giai đoạn của quá trình tái bản bán bảo tồn DNA ở *E. coli*; các hệ thống sửa chữa DNA.
- Trình bày được các giai đoạn tổng hợp RNA (sao chép), các enzym, chất ức chế và quá trình hoàn thiện mRNA, tRNA, rRNA; sự sao chép ngược.
- Vận dụng được vào lâm sàng: gout và thuốc ức chế xanthin oxidase, hội chứng Lesch–Nyhan, thuốc chống ung thư kháng chuyển hóa, thuốc kháng virus nucleosid.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. **Purin** (A, G) thoái hóa thành **acid uric** — sản phẩm cuối ở người. Hai bước cuối (hypoxanthin → xanthin → acid uric) do **xanthin oxidase** xúc tác; **allopurinol, febuxostat** ức chế enzym này để trị **gout**.
> 2. **Pyrimidin** (C, U, T) thoái hóa ở gan thành **β-alanin** và **β-aminoisobutyrat**: tan tốt, không gây bệnh lắng đọng.
> 3. Tổng hợp nucleotid có 2 đường: **tân tạo** (từ chất nhỏ: acid amin/amino acid, CO~2~, formyl-THF) và **tận dụng** (gắn base có sẵn vào **PRPP**, ví dụ enzym **HGPRT**). Purin được **dựng trên ribose-5-P** → **IMP** → AMP, GMP; pyrimidin dựng **vòng trước** (orotat) rồi mới gắn PRPP → UMP → UTP → CTP.
> 4. **Tái bản DNA** (ADN) (*E. coli*): helicase (DnaB) mở xoắn, SSB giữ sợi đơn, gyrase tháo siêu xoắn, **primase** làm mồi RNA (ARN), **Pol III** kéo dài, **Pol I** cắt mồi và lấp chỗ trống, **ligase** nối. Sai sót chỉ khoảng 10^−9^–10^−11^ nhờ sửa sai và 4 hệ thống sửa chữa.
> 5. **Sao chép (phiên mã)**: RNA polymerase **không cần mồi**, bắt đầu ở **promoter**; ức chế bởi rifampicin, α-amanitin, actinomycin D. RNA mới là **tiền RNA**, phải hoàn thiện: **cắt intron, gắn mũ 5', gắn đuôi poly A** (mRNA).

Bài này nối tiếp hai bài đã học, không học lại:

> [!bay] Đọc kèm bài khác
> - Cấu tạo nucleotid, nucleosid, cách gọi tên, các loại RNA: bài **Hóa học acid nucleic** (Hóa sinh, hs-04). Vòng purin, pyrimidin và cách đánh số: bài **Hợp chất dị vòng** (Hóa học, hc-11).
> - Nguyên tắc tái bản (bán bảo tồn, 5'→3', sợi nhanh/sợi chậm, đoạn Okazaki), tái bản ở Eukaryota (sinh vật nhân thực), telomerase, phiên mã ở Prokaryota (sinh vật nhân sơ) và Eukaryota, cắt nối exon: bài **Cơ sở phân tử của hiện tượng di truyền** (Sinh học, sh-09). Bài Sinh học viết **ADN, ARN** và gọi tổng hợp RNA là **phiên mã**; giáo trình Hóa sinh viết **DNA, RNA** và gọi là **sao chép** — cùng một quá trình.
> - Ở đây chỉ đi sâu phần **hóa sinh**: chất nào, enzym nào, tốn gì, bị chặn ở đâu, bệnh gì.

## 1. Nucleotid trong cơ thể: từ đâu đến, đi về đâu

### 1.1. Vai trò của nucleotid

Theo giáo trình (tr. 170), nucleotid:

- là **đơn vị cấu tạo** của DNA và RNA;
- là thành phần của **coenzym** (NAD^+^, FAD, CoA);
- là **chất truyền tin thứ hai** (cAMP, cGMP);
- là dạng **dự trữ và vận chuyển năng lượng** (ATP, GTP).

### 1.2. Tiêu hóa acid nucleic của thức ăn

Acid nucleic trong thức ăn **không bị phá** bởi acid dạ dày. Chúng được thủy phân chủ yếu ở **tá tràng – ruột non**, qua nhiều bậc (Giáo trình tr. 170):

| Bậc | Enzym | Sản phẩm |
|---|---|---|
| 1 | **Nuclease** của tụy (DNase, RNase) và **phosphodiesterase** của ruột | Oligonucleotid, mononucleotid |
| 2 | **Nucleotidase** và **phosphatase** | Nucleosid + P~i~ |
| 3 | **Nucleosidase** hoặc **nucleosid phosphorylase** | Base tự do + ribose (hoặc ribose-1-phosphat) |

=> Nucleosid + H~2~O → base + ribose (nucleosidase)

=> Nucleosid + P~i~ → base + ribose-1-P (nucleosid phosphorylase)

**Vì sao phải cắt tới nucleosid?** Nucleotid mang nhóm phosphat tích điện âm nên **không qua được màng** tế bào ruột. Nucleosid thì được hấp thu, hoặc tiếp tục bị cắt thành base.

> [!bay]
> - Phân biệt hai enzym cắt nucleosid: **nucleosidase** dùng **nước** (cho ribose tự do); **phosphorylase** dùng **phosphat vô cơ** (cho **ribose-1-phosphat**, giữ lại được năng lượng liên kết).
> - Tế bào **tự tổng hợp đủ** nucleotid. Acid nucleic trong thức ăn **không phải chất dinh dưỡng thiết yếu** (tr. 179). Nhưng base purin của thức ăn vẫn bị thoái hóa thành acid uric, nên vẫn **ảnh hưởng đến acid uric máu** (mục 2.3).

## 2. Thoái hóa purin nucleotid — đích đến là acid uric

### 2.1. Các bước

Mọi con đường thoái hóa purin đều **hội tụ về xanthin**, rồi thành **acid uric** (Giáo trình tr. 170–171):

![Hình 1. Thoái hóa purin nucleotid thành acid uric. Hai bước do xanthin oxidase xúc tác (màu cam) là nơi allopurinol và febuxostat tác dụng. PNP: purin nucleosid phosphorylase](thoai-hoa-purin.svg)

**Nhánh adenin:**

1. AMP bị **5'-nucleotidase** cắt phosphat → **adenosin**.
2. Adenosin bị **adenosin deaminase (ADA)** khử amin → **inosin**. (Một đường khác: AMP bị **AMP deaminase** khử amin thành IMP trước, rồi IMP mới cắt phosphat thành inosin.)
3. Inosin bị **purin nucleosid phosphorylase (PNP)** cắt ribose → **hypoxanthin** + ribose-1-P.
4. Hypoxanthin bị **xanthin oxidase** oxy hóa → **xanthin**.

**Nhánh guanin:**

1. GMP → **guanosin** (5'-nucleotidase).
2. Guanosin → **guanin** + ribose-1-P (PNP; giáo trình có chỗ ghi là nucleosidase).
3. Guanin bị **guanin deaminase** (guanase) khử amin → **xanthin**.

**Bước chung:** xanthin bị **xanthin oxidase** oxy hóa → **acid uric**. Mỗi bước oxy hóa dùng O~2~ và nước, sinh ra **H~2~O~2~**.

> [!bay] Nhớ đúng thứ tự
> - **Hypoxanthin → xanthin → acid uric**: xanthin oxidase làm **cả hai** bước.
> - Adenin **không** đi thẳng thành xanthin: nó bị khử amin ở mức **nucleosid/nucleotid** (adenosin → inosin, hoặc AMP → IMP), rồi qua hypoxanthin. Còn guanin bị khử amin ở mức **base tự do** (guanin → xanthin).
> - Vòng purin **không bị mở** ở người. Acid uric vẫn còn nguyên khung purin 2 vòng (2,6,8-trioxopurin).

> [!ung-dung] Thiếu enzym thoái hóa purin gây suy giảm miễn dịch
> - **Thiếu ADA**: deoxyadenosin và dATP tích tụ trong tế bào lympho. dATP ức chế enzym tạo deoxyribonucleotid (mục 6.1), lympho không nhân lên được → **suy giảm miễn dịch kết hợp nặng (SCID)**. Đây là một trong những bệnh đầu tiên được thử **liệu pháp gen**.
> - **Thiếu PNP**: cơ chế tương tự (dGTP tích tụ), chủ yếu làm giảm **lympho T**.

### 2.2. Acid uric — sản phẩm cuối cùng ở người

Ở người, acid uric là **sản phẩm thoái hóa cuối cùng** của base purin (tr. 171). Khoảng 2/3 được thải qua **thận**, phần còn lại qua **ruột**.

| Chỉ số | Giáo trình (tr. 171) | Quy đổi SI |
|---|---|---|
| Acid uric máu bình thường | 2,2–8 mg/dL | **130–480 µmol/L** |
| Acid uric niệu | 0,3–0,8 g/24 giờ, thay đổi theo chế độ ăn | ≈ 1,8–4,8 mmol/24 giờ |

*Quy đổi: 1 mg/dL acid uric ≈ 59,5 µmol/L.*

> [!cap-nhat] Khoảng tham chiếu thường dùng hiện nay
> Giáo trình ghi một khoảng chung 130–480 µmol/L (chương Hóa sinh máu, tr. 316, lại ghi **190–420 µmol/L** — xem hs-19). Các phòng xét nghiệm ở Việt Nam hiện thường ghi **riêng theo giới**: nam khoảng **180–420 µmol/L**, nữ khoảng **150–360 µmol/L** (tham khảo, mỗi phòng xét nghiệm có khoảng riêng). Ngưỡng hay dùng để gọi **tăng acid uric máu** là **> 420 µmol/L (7 mg/dL)**, gần với giới hạn hòa tan của urat trong huyết tương ở 37 °C (≈ 6,8 mg/dL). Đi thi trả lời theo số liệu của giáo trình.

**Vì sao acid uric dễ kết tủa?** Acid uric và muối urat natri **rất ít tan** trong nước. Khi nồng độ trong máu vượt ngưỡng bão hòa, tinh thể **urat natri** hình kim lắng đọng ở mô ít mạch máu, nhiệt độ thấp (sụn, khớp ngón chân). Trong nước tiểu **acid** (pH thấp), urat chuyển thành acid uric **kém tan hơn nữa** → dễ tạo **sỏi acid uric**. Vì vậy người có sỏi urat được khuyên uống nhiều nước và **kiềm hóa nước tiểu**.

### 2.3. Bệnh gout (thống phong)

Theo giáo trình (tr. 171–172):

- Trong **gout** và trong **bệnh bạch cầu** (leukemia), acid uric máu tăng cao, **urat lắng đọng** ở sụn, bao gân, túi thanh dịch của khớp, đôi khi ở thận và cơ.
- Bệnh gặp khoảng **3/1000** người, chủ yếu ở **nam giới**, liên quan thói quen **ăn uống quá nhiều**.
- Nguyên nhân hay gặp nhất là **giảm bài tiết** acid uric. Ngoài ra có thể do **tăng tạo** acid uric trong các rối loạn chuyển hóa như **hội chứng Lesch–Nyhan** và **bệnh von Gierke**.
- Điều trị: **chế độ ăn** kết hợp **thuốc ức chế xanthin oxidase**. Khi enzym bị ức chế, sản phẩm cuối của purin là **xanthin và hypoxanthin**. Hai chất này **tan trong nước tốt hơn** acid uric và dễ thải qua nước tiểu.

**Vì sao bạch cầu cấp (và hóa trị) làm acid uric tăng?** Tế bào ác tính phân chia nhanh, chết nhiều. Khi hóa trị, hàng loạt tế bào bị phá hủy cùng lúc, giải phóng lượng lớn acid nucleic → purin → acid uric (**hội chứng ly giải u**), có thể gây suy thận cấp do urat.

> [!cap-nhat] Số liệu về gout
> - Giáo trình ghi tỉ lệ 3/1000. Các nghiên cứu dịch tễ hiện nay cho thấy gout phổ biến hơn nhiều, khoảng **1–4% người trưởng thành** ở nhiều nước, và đang tăng.
> - Ở trang 171 giáo trình ghi acid uric trong gout "có thể tăng tới **7–8 g/dl**". Đây là **lỗi in**: đúng là khoảng **7–8 mg/dL trở lên** (≈ 420–480 µmol/L), vì 7 g/dL là cao gấp 1000 lần, không thể tồn tại.
> - Chẩn đoán xác định gout hiện nay dựa vào **tìm thấy tinh thể urat** hình kim trong dịch khớp hoặc hạt tophi; acid uric máu có thể **bình thường** ngay trong cơn gout cấp.

> [!ung-dung] Thuốc trị gout và tăng acid uric — nhìn từ hóa sinh
> | Thuốc | Cơ chế | Lưu ý |
> |---|---|---|
> | **Allopurinol** | **Giống hypoxanthin**; bị enzym oxy hóa thành **oxypurinol**, chất này gắn chặt và khóa trung tâm hoạt động (chứa molybden) | Dị ứng da nặng liên quan gen **HLA-B\*58:01** (hay gặp ở người châu Á) |
> | **Febuxostat** | Ức chế xanthin oxidase, **không có cấu trúc purin** | Thận trọng ở người có bệnh tim mạch |
> | **Thuốc tăng thải** (probenecid, benzbromaron) | Giảm tái hấp thu urat ở ống thận | Không dùng khi có sỏi urat |
> | **Rasburicase** (urat oxidase tái tổ hợp) | Bổ sung enzym mà **người không có** (mục 2.4): acid uric → **allantoin** tan tốt | Dùng phòng/trị hội chứng ly giải u |
> | **Colchicin** | Chống viêm (gắn tubulin, giảm hoạt động bạch cầu) | **Không** làm giảm acid uric; trị cơn cấp |
>
> - **Tương tác nguy hiểm**: thuốc ức chế miễn dịch **azathioprin** và thuốc chống ung thư **6-mercaptopurin** được **xanthin oxidase** phân hủy. Dùng chung với allopurinol/febuxostat làm thuốc tích lũy → ức chế tủy xương nặng.
> - **Vì sao rượu bia, nước ngọt có fructose làm acid uric tăng?** Fructose được phosphoryl hóa rất nhanh ở gan, tiêu thụ nhiều ATP → AMP tăng → AMP bị thoái hóa thành acid uric. Rượu sinh **lactat**, cạnh tranh với urat ở ống thận nên giảm thải urat; bia còn chứa nhiều purin (guanosin). Thuốc lợi tiểu thiazid, furosemid và **aspirin liều thấp** cũng giảm thải urat.

> [!yhct] Chế độ ăn "kiêng" trong thống phong và các vị thuốc được nghiên cứu hạ acid uric
> - **Chế độ ăn:** thực phẩm **giàu purin** gồm **phủ tạng** (gan, thận, óc), **hải sản** (cá trích, cá mòi, tôm, sò), thịt đỏ, nước dùng thịt đậm, và **bia**. Nghiên cứu theo dõi lớn trên người cho thấy purin từ **thịt, hải sản** làm tăng nguy cơ gout, còn purin từ **rau, đậu, nấm** thì **không** làm tăng rõ. Kiêng quá mức các loại rau đậu là không cần thiết.
> - **Cơ chế đã chứng minh:** nhiều **flavonoid** (quercetin, luteolin, apigenin… có trong lá chè, hoa hòe, tía tô, cần tây) **ức chế xanthin oxidase trong ống nghiệm**. **Quercetin** có một thử nghiệm lâm sàng **nhỏ, ngắn hạn** trên người khỏe có acid uric hơi cao, cho thấy giảm acid uric máu **mức độ khiêm tốn**.
> - **Thổ phục linh** (*Smilax glabra*), **Ý dĩ** (*Coix lacryma-jobi*) và một số vị dùng trong các bài trị "thống phong, tý chứng" làm hạ acid uric trên **chuột gây tăng acid uric thực nghiệm**. **Chưa có** thử nghiệm lâm sàng đủ mạnh; **không thay thế** allopurinol khi có chỉ định.
> - Quan niệm YHCT (thấp nhiệt, đàm thấp…) và công dụng "trừ thấp, lợi niệu" là cách mô tả truyền thống, **không** đồng nghĩa với cơ chế ức chế xanthin oxidase.
> - **Cảnh báo:** đã có nhiều đợt thu hồi sản phẩm "thuốc nam trị gout" **trộn corticoid** (dexamethason…), giảm đau nhanh nhưng gây hội chứng Cushing, loãng xương, suy thượng thận. Bệnh nhân "khỏi đau rất nhanh" bằng thuốc không rõ nguồn gốc cần được nghĩ tới khả năng này.

### 2.4. Sản phẩm thoái hóa purin ở các loài

Các loài khác nhau dừng ở các mức khác nhau trên cùng một chuỗi phản ứng (Giáo trình tr. 172). Loài nào **càng thiếu nhiều enzym** thì sản phẩm cuối **càng phức tạp**:

=> Acid uric → (urat oxidase) → allantoin → (allantoinase) → acid allantoic → (allantoicase) → urê + glyoxylat → (urease) → CO~2~ + NH~4~^+^

| Loài | Sản phẩm cuối của purin |
|---|---|
| **Người**, vượn người, chim, bò sát, côn trùng | **Acid uric** |
| Phần lớn động vật có vú khác | **Allantoin** (có urat oxidase) |
| Cá xương | Acid allantoic |
| Lưỡng cư, cá sụn | **Urê** |
| Động vật biển không xương sống | **NH~4~^+^** |

> [!vi-du] Vì sao người "mất" urat oxidase lại dễ bị gout?
> Gen urat oxidase ở tổ tiên loài người bị **đột biến mất chức năng**. Vì vậy acid uric máu của người cao hơn nhiều so với chó, chuột. Đây là lý do gout gần như là bệnh **riêng của người**, và khi nghiên cứu thuốc hạ acid uric trên chuột, người ta phải **ức chế urat oxidase** (bằng kali oxonat) để gây tăng acid uric thực nghiệm.

## 3. Thoái hóa pyrimidin nucleotid

Giống purin, pyrimidin nucleotid lần lượt bị cắt phosphat, khử amin và cắt liên kết glycosid. Điểm khác: base uracil và thymin tiếp tục bị thoái hóa ở **gan** bằng **phản ứng khử** (cần NADPH), chứ **không** phải oxy hóa như purin (Giáo trình tr. 172–173). Và **vòng pyrimidin bị mở**.

| Bước | Từ cytosin/uracil | Từ thymin |
|---|---|---|
| 1. Cắt phosphat (nucleotidase) | CMP → cytidin; UMP → uridin | dTMP → deoxythymidin |
| 2. Khử amin (cytidin deaminase) | Cytidin → uridin | — |
| 3. Cắt ribose (uridin phosphorylase) | Uridin → **uracil** | → **thymin** |
| 4. Khử vòng (dihydrouracil dehydrogenase, NADPH) | → dihydrouracil | → dihydrothymin |
| 5. Mở vòng (hydropyrimidin hydratase) | → β-ureidopropionat | → β-ureidoisobutyrat |
| 6. Tách NH~4~^+^ + CO~2~ (β-ureidopropionase) | → **β-alanin** | → **β-aminoisobutyrat** |
| 7. Trao đổi amin, rồi gắn CoA | → malonyl-CoA | → methylmalonyl-CoA |

Sản phẩm cuối là các **acid amin β**, **tan tốt** trong nước, tiếp tục đi vào chuyển hóa chung (methylmalonyl-CoA → succinyl-CoA vào chu trình Krebs).

> [!bay]
> - Purin: **oxy hóa**, vòng **giữ nguyên**, sản phẩm **acid uric ít tan** → có bệnh do lắng đọng (gout).
> - Pyrimidin: **khử**, vòng **bị mở**, sản phẩm **β-alanin, β-aminoisobutyrat** tan tốt, giải phóng **NH~3~ và CO~2~** → **không** có bệnh lắng đọng tương tự.
> - β-aminoisobutyrat **chỉ đến từ thymin**, tức từ **DNA**. Nó tăng trong nước tiểu khi DNA bị phá hủy nhiều (bệnh bạch cầu, sau xạ trị, hóa trị).

> [!ung-dung] Thiếu enzym DPD và độc tính của 5-fluorouracil
> Enzym khử vòng ở bước 4 có tên hiện nay là **dihydropyrimidin dehydrogenase (DPD)**. Nó cũng phân hủy thuốc chống ung thư **5-fluorouracil (5-FU)** và capecitabin (thuốc uống chuyển thành 5-FU). Người **thiếu DPD** bẩm sinh không thải được thuốc → ngộ độc nặng, có thể tử vong (viêm niêm mạc, giảm bạch cầu). Nhiều nước đã khuyến cáo xét nghiệm DPD trước khi dùng nhóm thuốc này.

## 4. Tổng hợp purin nucleotid

### 4.1. Hai con đường: tân tạo và tận dụng

Giáo trình (tr. 173, 179) nêu hai con đường tổng hợp nucleotid:

| | Con đường **tân tạo** (de novo) | Con đường **tận dụng** (salvage) |
|---|---|---|
| Nguyên liệu | Phân tử nhỏ: acid amin (glycin, aspartat, glutamin), CO~2~, đơn vị một carbon (formyl-THF), ribose-5-P | **Base** hoặc nucleosid **có sẵn**, sinh ra từ thoái hóa |
| Năng lượng | **Tốn nhiều ATP** | **Tiết kiệm** |
| Nơi chủ yếu | **Gan** | Nhiều mô, đặc biệt **não**, tủy xương, lympho |
| Ví dụ enzym | Amidophosphoribosyl transferase | **HGPRT, APRT** (mục 6.2) |

**PRPP** (5-phosphoribosyl-1-pyrophosphat) là **"ribose hoạt hóa"** dùng chung cho **cả hai** con đường, cả purin lẫn pyrimidin. Nó được tạo từ **ribose-5-phosphat** (sản phẩm của con đường pentose phosphat) và ATP:

=> Ribose-5-P + ATP → PRPP + AMP (enzym: ribose phosphat pyrophosphokinase, còn gọi PRPP synthetase)

### 4.2. Nguồn gốc các nguyên tử trong nhân purin

Nhờ thí nghiệm đánh dấu đồng vị ^14^C, ^15^N, người ta biết 9 nguyên tử của nhân purin đến từ **5 nguồn** (Giáo trình tr. 174):

![Hình 2. Nguồn gốc các nguyên tử trong nhân purin. Glycin góp nguyên khối C4–C5–N7. Nhân purin được dựng dần trên ribose-5-phosphat, gắn ở N9](nguon-goc-purin.svg)

| Nguyên tử | Nguồn gốc |
|---|---|
| **N1** | Aspartat |
| **C2, C8** | Formyl (giáo trình ghi "acid formic"; dạng thật sự tham gia là **N^10^-formyl-tetrahydrofolat**) |
| **N3, N9** | Nhóm amid của **glutamin** |
| **C4, C5, N7** | **Glycin** (cả phân tử) |
| **C6** | **CO~2~** (HCO~3~^−^) |

> [!ghi-nho] Mẹo nhớ
> "**Gly** góp khúc giữa (4-5-7); **Gln** góp hai N dưới (3, 9); **Asp** góp N1 trên trái; **CO~2~** ở đỉnh (C6); **formyl** ở hai đầu (C2, C8)."
> Purin cần **3 acid amin**: glycin, aspartat, glutamin — và **folat** (2 lần). Vì vậy **thiếu acid folic** hoặc thuốc chặn folat làm giảm tổng hợp purin.

### 4.3. Tổng hợp IMP: 11 phản ứng, 4 giai đoạn

Điểm đặc trưng: nhân purin **không được tạo ra ở dạng base tự do**, mà được **dựng từng nguyên tử ngay trên ribose-5-phosphat** (gắn từ PRPP). Sản phẩm đầu tiên có nhân purin hoàn chỉnh là **IMP** (inosin monophosphat, base là hypoxanthin) (Giáo trình tr. 174–176).

| Giai đoạn | Phản ứng | Enzym | Góp gì |
|---|---|---|---|
| **1. Tạo GAR** | (1) Ribose-5-P → **PRPP** | Ribose phosphat pyrophosphokinase | ATP |
| | (2) PRPP → **β-5-phosphoribosylamin** | **Amidophosphoribosyl transferase** | N9 từ glutamin |
| | (3) → **GAR** (glycinamid ribotid) | GAR synthetase | Glycin (C4, C5, N7), ATP |
| **2. Tạo vòng imidazol** | (4) → FGAR | GAR transformylase | **C8** từ N^10^-formyl-THF |
| | (5) → FGAM | FGAM synthetase | **N3** từ glutamin, ATP |
| | (6) Đóng vòng 5 cạnh → **AIR** | AIR synthetase (FGAM cyclase) | ATP |
| **3. Tạo vòng 6 cạnh → IMP** | (7) → CAIR | AIR carboxylase | **C6** từ CO~2~ |
| | (8) → SAICAR | SAICAR synthetase | **Aspartat** (N1), ATP |
| | (9) → **AICAR** + fumarat | Adenylosuccinat lyase | Tách fumarat |
| | (10) → FAICAR | AICAR transformylase | **C2** từ N^10^-formyl-THF |
| | (11) Đóng vòng → **IMP** | IMP cyclohydrolase | Tách H~2~O |
| **4. IMP → AMP, GMP** | Xem mục 4.4 | | |

**Phản ứng (2)** là bước **cam kết** và **điều hòa chính**: từ đây PRPP chỉ còn đi vào tổng hợp purin.

**Vì sao vòng imidazol (5 cạnh) được dựng trước vòng 6 cạnh?** Các nguyên tử C4, C5, N7 của glycin, cùng C8 và N9, đã nằm sẵn trên ribose ngay từ đầu. Vòng 5 cạnh đóng trước (AIR), rồi phần còn lại (C6, N1, C2) mới được thêm vào để khép vòng 6 cạnh.

> [!bay]
> - Sản phẩm đầu tiên có nhân purin hoàn chỉnh là **IMP** (base: **hypoxanthin**), **không** phải AMP hay GMP.
> - Bước (9) và bước tạo AMP từ adenylosuccinat do **cùng một enzym** xúc tác: **adenylosuccinat lyase**, đều tách ra **fumarat**. Aspartat góp nhóm NH~2~ rồi để lại khung carbon dưới dạng fumarat — kiểu "cho amin" giống chu trình urê.
> - Hai bước dùng **formyl-THF** (4 và 10): đây là điểm tác động của các thuốc **kháng folat** (methotrexat).

### 4.4. Tạo AMP và GMP từ IMP

IMP là **ngã ba** (Giáo trình tr. 175, 177):

| | **IMP → AMP** | **IMP → GMP** |
|---|---|---|
| Bước 1 | IMP + **aspartat** → adenylosuccinat (adenylosuccinat synthetase), cần **GTP** | IMP bị **oxy hóa ở C2** → **XMP** (IMP dehydrogenase, coenzym **NAD^+^**) |
| Bước 2 | Tách **fumarat** → **AMP** (adenylosuccinat lyase) | Gắn nhóm amin của **glutamin** vào C2 → **GMP** (GMP synthetase), cần **ATP** |
| Kết quả | Nhóm =O ở C6 thay bằng **–NH~2~** | Thêm **–NH~2~** ở C2 |

**Vì sao tạo AMP cần GTP, còn tạo GMP cần ATP?** Đây là cơ chế **cân bằng chéo**: khi tế bào nhiều ATP thì đẩy tạo GMP, nhiều GTP thì đẩy tạo AMP. Nhờ vậy hai loại nucleotid được tạo ra với lượng **tương xứng** nhau.

AMP, GMP sau đó được các **kinase** phosphoryl hóa tiếp thành ADP, ATP và GDP, GTP.

### 4.5. Điều hòa tổng hợp purin

Giáo trình (tr. 175) nêu nguyên tắc: tổng hợp purin được điều hòa **ngược** — chính các purin nucleotid tạo ra **ức chế** các enzym của con đường. Cụ thể (bổ sung):

- **PRPP synthetase** bị ADP, GDP ức chế. **Amidophosphoribosyl transferase** (bước 2) bị **AMP, GMP, IMP** ức chế và được **PRPP hoạt hóa**.
- Ở ngã ba IMP: **AMP** ức chế nhánh tạo AMP (adenylosuccinat synthetase), **GMP** ức chế nhánh tạo GMP (IMP dehydrogenase).

**Hệ quả lâm sàng:** khi **PRPP tăng** (do PRPP synthetase hoạt động quá mức, do thiếu HGPRT không dùng hết PRPP, hoặc bệnh von Gierke) thì tổng hợp purin tân tạo **tăng vọt** → acid uric tăng → gout.

## 5. Tổng hợp pyrimidin nucleotid

### 5.1. Khác purin ở điểm nào?

Pyrimidin nucleotid được tạo từ **aspartat, PRPP và carbamoyl phosphat**. Quá trình **đơn giản hơn** purin: **vòng pyrimidin được tạo trước** dưới dạng **orotat**, sau đó mới gắn vào PRPP (Giáo trình tr. 175).

| | Purin | Pyrimidin |
|---|---|---|
| Vòng dựng ở đâu | **Trên ribose-5-P** (từ PRPP), từng nguyên tử | Vòng **tự do trước** (orotat), rồi mới gắn PRPP |
| Nguyên liệu | Glycin, aspartat, glutamin, CO~2~, formyl-THF | **Carbamoyl phosphat** (từ glutamin + CO~2~), **aspartat** |
| Sản phẩm đầu tiên | **IMP** | **UMP** |
| Số phản ứng tới sản phẩm đầu | 11 (kể cả tạo PRPP) | 6 |

### 5.2. Giai đoạn 1 — tạo orotat

1. **Carbamoyl phosphat** được tạo từ glutamin, HCO~3~^−^ và 2 ATP nhờ **carbamoyl phosphat synthetase II (CPS II)** trong **bào tương**.
2. Carbamoyl phosphat + **aspartat** → carbamoyl aspartat (**aspartat transcarbamoylase**, ATCase).
3. Đóng vòng, tách nước → **dihydroorotat** (dihydroorotase).
4. Oxy hóa → **orotat** (**dihydroorotat dehydrogenase**).

> [!bay] Hai enzym carbamoyl phosphat synthetase
> | | **CPS I** | **CPS II** |
> |---|---|---|
> | Dùng cho | **Chu trình urê** | **Tổng hợp pyrimidin** |
> | Vị trí | **Ty thể** (gan) | **Bào tương** (mọi tế bào phân chia) |
> | Nguồn N | **NH~3~** | **Glutamin** |
> | Chất hoạt hóa | N-acetylglutamat | (bổ sung) PRPP; bị **UTP** ức chế |

> [!cap-nhat] Coenzym của dihydroorotat dehydrogenase
> Giáo trình (tr. 175) viết enzym này dùng coenzym **NAD^+^**, nhưng hình 11.6 (tr. 178) của chính giáo trình lại vẽ chất nhận là **quinon**. Hiện nay đã biết: ở người, dihydroorotat dehydrogenase là **flavoprotein** nằm ở **mặt ngoài màng trong ty thể** (enzym duy nhất của con đường không ở bào tương), chuyển điện tử cho **ubiquinon (CoQ)** của chuỗi hô hấp. Thuốc ức chế miễn dịch **leflunomid** (trị viêm khớp dạng thấp) và **teriflunomid** (xơ cứng rải rác) ức chế enzym này, làm lympho đang tăng sinh thiếu pyrimidin. Đi thi nếu hỏi theo sách: ghi NAD^+^.

### 5.3. Giai đoạn 2 — tạo UMP, UTP, CTP

1. **Orotat + PRPP → OMP** (orotidin monophosphat) + PP~i~, enzym **orotat phosphoribosyl transferase**.
2. **OMP → UMP** + CO~2~, enzym **OMP decarboxylase** (khử carboxyl).
3. UMP được **kinase** phosphoryl hóa 2 lần → UDP → **UTP**.
4. **UTP + glutamin + ATP → CTP**, enzym **CTP synthetase** (giáo trình gọi cytidylat synthetase). Ở động vật, nhóm amin lấy từ **glutamin**; giáo trình ghi ở vi khuẩn là NH~4~^+^ (tr. 177, 179).

> [!bay]
> - Pyrimidin đầu tiên được tạo là **UMP**, không phải CMP.
> - **CTP được tạo từ UTP** (ở mức **triphosphat**), không phải từ UMP hay CMP.
> - Thymin (dTMP) **không** tạo trực tiếp từ con đường này mà từ **dUMP** (mục 6.1).

> [!ung-dung] Acid orotic niệu
> - **Acid orotic niệu di truyền**: thiếu enzym gộp của hai bước cuối (**UMP synthase**: orotat phosphoribosyl transferase + OMP decarboxylase). Orotat không chuyển được thành UMP, bị thải nhiều qua nước tiểu; trẻ **thiếu máu hồng cầu to không đáp ứng vitamin B~12~ và acid folic**, chậm lớn. Điều trị bằng **uridin**: uridin đi vào đường tận dụng thành UMP, đồng thời ức chế ngược (UTP ức chế CPS II) nên giảm tạo orotat.
> - Acid orotic niệu cũng gặp trong **thiếu ornithin transcarbamoylase** (rối loạn chu trình urê): carbamoyl phosphat của ty thể ứ lại, tràn ra bào tương và đi vào tổng hợp pyrimidin. Xét nghiệm orotic niệu giúp phân biệt các rối loạn chu trình urê.

## 6. Deoxyribonucleotid và con đường tận dụng

### 6.1. Tổng hợp deoxyribonucleotid

Deoxyribonucleotid **không được tổng hợp trực tiếp** từ nguyên liệu ban đầu. Chúng được tạo từ **ribonucleotid** tương ứng bằng cách **khử oxy ở vị trí C2'** của ribose (Giáo trình tr. 178).

*Phần sau là bổ sung, giáo trình không trình bày chi tiết nhưng cần cho phần thuốc:*

- Enzym **ribonucleotid reductase** khử ở mức **diphosphat**: ADP, GDP, CDP, UDP → dADP, dGDP, dCDP, dUDP. Hydro lấy từ **NADPH** qua protein **thioredoxin**. Enzym được điều hòa chặt (dATP ức chế toàn bộ — giải thích bệnh thiếu ADA ở mục 2.1).
- **dTMP** (thymidylat) được tạo bằng cách **methyl hóa dUMP** ở C5, enzym **thymidylat synthase**. Nhóm methyl lấy từ **N^5^,N^10^-methylen-THF**, chất này bị chuyển thành **dihydrofolat (DHF)**.
- DHF phải được **dihydrofolat reductase (DHFR)** khử trở lại thành **THF** (dùng NADPH) thì mới tái sử dụng được.

**Vì sao tế bào ung thư "sợ" thiếu dTMP?** dTTP là nguyên liệu **chỉ dùng cho DNA**. Tế bào muốn nhân đôi DNA thì bắt buộc phải có dTTP. Chặn được dTMP là chặn **riêng** sự tăng sinh, ít ảnh hưởng tổng hợp RNA.

![Hình 3. Tổng hợp nucleotid và vị trí tác dụng (màu cam) của các thuốc kháng chuyển hóa. DHODH: dihydroorotat dehydrogenase; IMPDH: IMP dehydrogenase; DHFR: dihydrofolat reductase. Mũi tên chấm: THF cũng cần cho hai bước của tổng hợp purin](tong-hop-nucleotid.svg)

### 6.2. Con đường tận dụng — enzym HGPRT

Giáo trình (tr. 179) chỉ nêu: con đường tận dụng dùng **base purin, pyrimidin sinh ra từ thoái hóa** để tổng hợp lại nucleotid, và **khác hẳn** con đường tân tạo. Phần chi tiết sau là bổ sung (rất hay gặp trong lâm sàng):

=> Hypoxanthin + PRPP → IMP + PP~i~ (HGPRT)

=> Guanin + PRPP → GMP + PP~i~ (HGPRT)

=> Adenin + PRPP → AMP + PP~i~ (APRT)

- **HGPRT** = hypoxanthin-guanin phosphoribosyl transferase; **APRT** = adenin phosphoribosyl transferase.
- **Vì sao tiết kiệm?** Một bước (dùng 1 PRPP) thay cho cả chục bước tốn ATP của đường tân tạo.
- Nhờ con đường này, phần lớn hypoxanthin, guanin sinh ra hằng ngày được **dùng lại** thay vì bị oxy hóa thành acid uric.

> [!ung-dung] Hội chứng Lesch–Nyhan
> - **Nguyên nhân:** thiếu **gần hoàn toàn HGPRT**, di truyền **lặn liên kết nhiễm sắc thể X** (gần như chỉ gặp ở trẻ trai).
> - **Vì sao acid uric tăng rất cao?** (1) Hypoxanthin, guanin không được tận dụng nên **đi hết vào xanthin oxidase** → acid uric. (2) **PRPP không được dùng** nên **tích tụ**, kích thích bước 2 của đường tân tạo. (3) IMP, GMP giảm nên **mất ức chế ngược**. Kết quả: tổng hợp purin tân tạo tăng vọt, càng tạo thêm acid uric.
> - **Biểu hiện:** tăng acid uric, sỏi thận, gout sớm; tổn thương thần kinh (chậm phát triển, múa vờn – loạn trương lực) và đặc biệt **hành vi tự cắn** môi, ngón tay. Não phụ thuộc nhiều vào đường tận dụng, nên thiếu HGPRT ảnh hưởng nặng tới não.
> - **Allopurinol** hạ được acid uric, tránh sỏi và suy thận, nhưng **không cải thiện** triệu chứng thần kinh.
> - Thiếu HGPRT **một phần** (hội chứng Kelley–Seegmiller) chỉ gây **gout và sỏi** ở người trẻ, không có triệu chứng thần kinh nặng.

> [!ung-dung] Thuốc chống ung thư và ức chế miễn dịch kháng chuyển hóa
> Tế bào ung thư (và lympho đang hoạt hóa) phân chia nhanh, cần rất nhiều nucleotid. Thuốc **kháng chuyển hóa** là các chất **giống** nguyên liệu, chen vào và **khóa enzym** của Hình 3:
>
> | Thuốc | Giống chất nào | Ức chế | Hậu quả |
> |---|---|---|---|
> | **Methotrexat** | Acid folic | **DHFR** | Thiếu THF → giảm cả **dTMP** và **purin** (bước 4, 10). Liều thấp trị viêm khớp dạng thấp, vảy nến |
> | **5-fluorouracil** | Uracil | Chuyển thành **FdUMP**, khóa **thymidylat synthase** | Thiếu dTMP → "chết vì thiếu thymin" |
> | **6-mercaptopurin**, azathioprin | Hypoxanthin | Cần **HGPRT** hoạt hóa thành thio-IMP, ức chế tổng hợp purin | Trị bạch cầu cấp; ức chế miễn dịch |
> | **Hydroxyure** | — | **Ribonucleotid reductase** | Thiếu dNTP; còn dùng trong bệnh hồng cầu hình liềm |
> | **Mycophenolat** | — | **IMP dehydrogenase** | Lympho thiếu GMP; chống thải ghép |
> | **Leflunomid** | — | **Dihydroorotat dehydrogenase** | Lympho thiếu pyrimidin; trị viêm khớp dạng thấp |
>
> - **Leucovorin** (acid folinic, một dạng THF có sẵn) được dùng để "giải cứu" tế bào lành sau methotrexat liều cao, vì nó **đi vòng qua** bước DHFR bị chặn.
> - Vì các thuốc này tấn công **mọi tế bào phân chia nhanh**, tác dụng phụ thường gặp ở **tủy xương** (giảm bạch cầu, tiểu cầu), **niêm mạc miệng – ruột**, **tóc**.

## 7. Thoái hóa acid nucleic

Tế bào **tự tổng hợp** acid nucleic cho mình. DNA **đổi mới chậm**, chủ yếu ở tế bào đang phân chia; lượng RNA thì thay đổi theo **tốc độ tổng hợp protein** (Giáo trình tr. 179).

Các **nuclease** thủy phân liên kết **phosphodiester**, gồm hai kiểu chung cho cả DNA và RNA:

| Kiểu | Vị trí cắt | Ví dụ trong giáo trình |
|---|---|---|
| **Exonuclease** | Cắt **từng nucleotid một ở đầu chuỗi** (đầu 5' hoặc đầu 3') | RNase II (3'→5'); RNase V (5'→3'); hoạt tính exonuclease của DNA polymerase |
| **Endonuclease** | Cắt **ở giữa chuỗi** | RNase I; **RNase P** (cắt tiền tRNA); **RNase H** (cắt RNA trong **thể lai RNA–DNA**) |

- Nuclease cắt DNA gọi là **deoxyribonuclease** (DNase); cắt RNA gọi là **ribonuclease** (RNase).
- Thời gian bán hủy các loại RNA **rất khác nhau** (mRNA vi khuẩn chỉ vài phút; rRNA, tRNA bền hơn nhiều).
- Exo- và endonuclease phối hợp, tạo **oligonucleotid** và **mononucleotid**. Mononucleotid hoặc được **tận dụng** để tổng hợp lại, hoặc **thoái hóa tiếp** đến sản phẩm cuối (mục 2, 3) (tr. 180).

> [!bay]
> **RNase H** cắt **phần RNA** trong thể lai RNA–DNA (H = *hybrid*). Nó có mặt trong **sao chép ngược** của retrovirus (mục 11) và trong loại bỏ mồi RNA khi tái bản.

## 8. Tổng hợp DNA — tái bản

Tái bản (*replication*) là **tổng hợp DNA**, bảo tồn thông tin di truyền cho thế hệ sau. Nguyên tắc **bán bảo tồn**, **bổ sung**, chạc ba tái bản chữ Y, **chuỗi nhanh** (liên tục) và **chuỗi chậm** (gián đoạn, đoạn Okazaki) đã học ở bài sh-09. Giáo trình Hóa sinh mô tả kỹ hơn **các enzym** ở *E. coli* (Giáo trình tr. 180–183).

### 8.1. Các enzym và protein tham gia

| Thành phần | Chức năng | Chi tiết cần nhớ |
|---|---|---|
| **DNA helicase** (protein **DnaB**) | **Mở xoắn** kép, tách hai chuỗi | Trượt theo chiều **5'→3'**, dùng năng lượng **thủy phân ATP** (có thể GTP, CTP, nhưng **không** UTP). Helicase khác: Rep, PriA (trượt 3'→5') |
| **SSB** (protein gắn chuỗi đơn) | Bám vào hai chuỗi đơn, **không cho chúng bắt cặp lại**, giữ làm khuôn cho Pol III | |
| **DNA gyrase** (một topoisomerase) | Ngăn DNA xoắn trở lại, tháo căng xoắn phía trước chạc ba | Bị **novobiocin, acid oxolinic** ức chế → ngừng tái bản (vi khuẩn) |
| **RNA primase** (protein **DnaG**) | Tổng hợp **mồi RNA** ngắn (giáo trình: **10–60 nucleotid**) bổ sung với khuôn | Thuộc nhóm RNA polymerase |
| **DNA polymerase I** (Pol I) | Kéo dài 5'→3'; **exonuclease 3'→5'** (sửa sai) và **5'→3'** (cắt mồi RNA) | **1 chuỗi 928 acid amin**; cần đủ **4 loại dNTP** và khuôn |
| **DNA polymerase II** (Pol II) | Giáo trình: chưa rõ | Có exonuclease 3'→5', **không** có 5'→3' |
| **DNA polymerase III** (Pol III) | **Enzym chính** kéo dài chuỗi mới 5'→3' | Chỉ có exonuclease **3'→5'**; phân tử lớn, **nhiều tiểu đơn vị** (giáo trình: 13) |
| **DNA ligase** | **Nối** các đoạn Okazaki: tạo liên kết phosphodiester giữa **3'-OH** của đoạn này và **5'-phosphat** của đoạn kia | Cần năng lượng; nối được cả hai đầu DNA đứt, khép DNA vòng |

**Vì sao cần exonuclease 3'→5'?** Khi polymerase lỡ gắn một nucleotid sai, cặp base lệch làm đầu 3' "lỏng" ra. Enzym lùi lại, **cắt đúng nucleotid sai vừa gắn** rồi gắn lại. Đây là cơ chế **"đọc sửa"** (proofreading), lý do tái bản chính xác hơn sao chép RNA rất nhiều.

> [!bay] Ba hoạt tính của Pol I — hay hỏi
> - **Polymerase 5'→3'**: kéo dài chuỗi (luôn gắn vào đầu **3'-OH**).
> - **Exonuclease 3'→5'**: **sửa sai** (đọc sửa).
> - **Exonuclease 5'→3'**: **cắt bỏ mồi RNA** (và đoạn DNA hỏng) phía trước.
> Pol III **không có** exonuclease 5'→3' nên **không** cắt được mồi.

> [!cap-nhat] Một vài chi tiết giáo trình chưa chính xác
> - Giáo trình (tr. 181) ghi **rifampicin ức chế cả RNA polymerase và primase**. Hiện nay biết primase DnaG của *E. coli* **không** nhạy với rifampicin; rifampicin chỉ ức chế **RNA polymerase** vi khuẩn (xem bài sh-09).
> - **DNA ligase** của *E. coli* lấy năng lượng từ **NAD^+^**; ligase của người và của phage T4 dùng **ATP** (giáo trình ghi chung là ATP).
> - **Pol II** hiện nay được biết tham gia **sửa chữa DNA** và tái khởi động chạc ba bị dừng.
> Đi thi trả lời theo giáo trình.

### 8.2. Các giai đoạn tái bản ở *E. coli* (theo Kornberg)

**Mở đầu — nhận diện điểm khởi đầu:**

- Điểm khởi đầu là đoạn **oriC** dài **245 base**.
- Protein **DnaA** (52 kD) gắn vào oriC, cùng **ATP** và protein **HU** (giống histon) tạo **phức hợp mở**: vùng **giàu A–T** của oriC được mở xoắn trước (A–T chỉ có 2 liên kết hydro, dễ tách).
- **DnaB~6~** (helicase) và **DnaC~6~** gắn vào → **phức hợp tiền mồi**; DnaC được giải phóng.
- SSB, gyrase và DnaB tiếp tục tháo xoắn **theo cả hai hướng**, tạo chỗ cho **primase** gắn vào tổng hợp **mồi RNA** theo nguyên tắc bổ sung.

**Kéo dài (trên chuỗi chậm):**

1. **Pol III** tổng hợp đoạn Okazaki nối tiếp mồi RNA, kéo dài tới mồi kế tiếp.
2. **Pol I** dùng exonuclease 5'→3' **cắt mồi RNA**, đồng thời kéo dài DNA **lấp chỗ** của mồi.
3. **DNA ligase** nối các đoạn Okazaki.

Song song, **chuỗi nhanh** được tổng hợp liên tục, cũng do **Pol III**.

**Kết thúc:**

- Vùng kết thúc nằm **đối diện oriC** trên DNA vòng, chứa các trình tự **Ter** (TerA, B, C, D, E, F), mỗi trình tự dài khoảng **23 cặp base**, **không đối xứng** (không phải palindrom).
- Các Ter xếp thành hai cụm ngược hướng, tạo một **"bẫy một chiều"**: chạc ba đi theo một chiều thì vượt qua được cụm này nhưng bị chặn ở cụm kia. Nhờ vậy hai chạc ba **gặp nhau** trong vùng kết thúc, không vượt quá.
- Cần **protein Tus** (309 acid amin) gắn vào Ter.
- Cuối cùng **topoisomerase** tách hai DNA con (đang móc vào nhau như hai mắt xích) khỏi nhau.

### 8.3. Sửa chữa DNA

Tái bản ở *E. coli* chỉ sai khoảng **10^−9^–10^−11^** mỗi nucleotid (tr. 184). DNA còn bị tổn thương do **hóa chất, tia tử ngoại, nhiệt độ, phóng xạ**. Tỉ lệ sai thấp như vậy là nhờ các hệ thống enzym sửa chữa, chia làm **4 nhóm**:

| Nhóm | Sửa gì | Bệnh khi hỏng (bổ sung) |
|---|---|---|
| 1. Sửa **cặp đôi không đúng** sau tái bản (*mismatch repair*) | Base gắn sai mà đọc sửa bỏ sót | **Hội chứng Lynch** (ung thư đại tràng di truyền không polyp) |
| 2. Sửa **từng base** (thiếu, thừa, sai) (*base excision*) | Base bị khử amin, oxy hóa, mất base | |
| 3. Sửa bằng **cắt đoạn nucleotid** (*nucleotide excision*) | Tổn thương lớn làm méo xoắn kép, ví dụ **dimer pyrimidin** do tia UV | **Khô da sắc tố** (xeroderma pigmentosum): ung thư da sớm khi phơi nắng |
| 4. Sửa **trực tiếp** | **Dimer pyrimidin** (enzym quang giải), **O^6^-methylguanin** (enzym chuyển methyl) | |

> [!vi-du] Vì sao O^6^-methylguanin nguy hiểm?
> Khi guanin bị gắn methyl ở O6, nó **bắt cặp nhầm với T** thay vì C → sau tái bản thành đột biến G–C → A–T. Enzym sửa trực tiếp lấy nhóm methyl ra và **tự hy sinh** (mỗi phân tử enzym chỉ dùng một lần). Thuốc chống u não temozolomid gây chính tổn thương này; khối u nào **tắt gen** enzym sửa chữa này thì **đáp ứng thuốc tốt hơn**.

## 9. Tổng hợp RNA (sao chép, phiên mã)

Tổng hợp RNA là quá trình chuyển thông tin di truyền từ DNA sang RNA. Giáo trình gọi là **sự sao chép** (Giáo trình tr. 184–185).

### 9.1. So với tái bản DNA

| | Tái bản DNA | Sao chép RNA |
|---|---|---|
| Chiều tổng hợp | 5'→3' | **5'→3'** (giống) |
| Năng lượng | Từ nucleosid triphosphat | Từ nucleosid triphosphat (giống) |
| Khuôn DNA | Hai sợi tách ra, mỗi sợi đi vào một DNA con | **Được bảo tồn hoàn toàn**: sợi khuôn sau đó xoắn lại như cũ |
| Hoạt tính nuclease (sửa sai) | **Có** (exonuclease 3'→5') | **Không** (giáo trình) |
| Mồi | **Cần** mồi RNA | **Không cần** mồi |
| Phạm vi | Toàn bộ bộ gen | Chỉ từng **gen** (từ promoter đến điểm kết thúc) |

> [!bay]
> Giáo trình viết năng lượng "do ATP cung cấp". Chính xác hơn: năng lượng đến từ **chính các nucleosid triphosphat** (NTP với RNA, dNTP với DNA) — mỗi lần gắn một nucleotid thì tách ra **PP~i~**, PP~i~ bị thủy phân tiếp làm phản ứng **không đảo ngược**.

### 9.2. Các enzym

- **RNA polymerase phụ thuộc RNA** (*replicase*): nhân đôi RNA của **virus** trong tế bào chủ — gọi là sự tái bản trực tiếp của virus RNA.
- **RNA polymerase phụ thuộc DNA**: tổng hợp RNA từ khuôn DNA:

=> (NMP)~n~ + NTP → (NMP)~n+1~ + PP~i~

- Ở *E. coli*: **một** loại RNA polymerase tổng hợp **cả mRNA, tRNA, rRNA**.
- Ở tế bào có nhân (Giáo trình tr. 185): **RNA polymerase I** → rRNA; **II** → mRNA; **III** → tRNA và snRNA. (Chi tiết hơn và bảng so sánh: bài sh-09.)

### 9.3. Các giai đoạn

**Promoter** là đoạn DNA quyết định **điểm bắt đầu và hướng** di chuyển của RNA polymerase, thường nằm trong khoảng **−70 đến +30** so với điểm bắt đầu (+1).

1. **Mở đầu:** RNA polymerase gắn vào promoter ở vùng **−35** → **phức hợp đóng**. Enzym dịch tới vùng **−10**, tháo xoắn khoảng **17 cặp base** → **phức hợp mở**. Nucleotid đầu tiên thường là **GTP hoặc ATP** (một **purin**). Nhóm **5'-triphosphat** của nucleotid đầu tiên **được giữ nguyên** suốt quá trình → chứng tỏ chuỗi kéo dài theo chiều **5'→3'**. Đoạn RNA mới (khoảng 12 nucleotid) tạm thời bắt cặp với DNA.
2. **Kéo dài:** enzym trượt dọc DNA, mở xoắn phía trước, RNA kéo dài **5'→3'** với các yếu tố kéo dài. DNA đã đọc xong **xoắn lại ngay**.
3. **Kết thúc:** sau khi tổng hợp một loạt **U**, đoạn RNA ngay trước đó (giàu G–C, có trình tự **tự bổ sung**) **gấp thành kẹp tóc**; có thể kèm **yếu tố Rho**. RNA polymerase rời DNA, được **khử phosphat** để bắt đầu chu kỳ mới.

**Vì sao kẹp tóc + chuỗi U làm dừng phiên mã?** Kẹp tóc làm enzym "khựng" lại, trong khi đoạn lai U–A (chỉ 2 liên kết hydro mỗi cặp) **rất lỏng**, nên RNA dễ bung ra khỏi khuôn.

> [!cap-nhat] Yếu tố nhận biết promoter ở vi khuẩn
> Giáo trình (tr. 185, hình 11.12) viết RNA polymerase gắn vào vùng −35 "với sự tham gia của các yếu tố sao chép **TFII**". Thực ra **TFII** (TFIID, TFIIB…) là yếu tố phiên mã của **tế bào có nhân** (RNA polymerase II, hộp TATA). Ở *E. coli*, vùng −35 và −10 được nhận biết bởi **tiểu đơn vị σ (sigma)** của RNA polymerase (xem bài sh-09).

### 9.4. Các chất ức chế tổng hợp RNA

| Chất | Tác dụng | Ý nghĩa |
|---|---|---|
| **Rifampicin** | Ức chế RNA polymerase **vi khuẩn** | Thuốc chống lao chủ lực |
| **α-amanitin** | Ức chế RNA polymerase **tế bào có nhân** (mạnh nhất với Pol II) | Độc tố nấm *Amanita* gây suy gan cấp |
| **Actinomycin D** | **Chen vào DNA**, cản RNA polymerase di chuyển | Thuốc chống ung thư (dactinomycin) |

Ứng dụng lâm sàng của rifampicin và α-amanitin đã nói kỹ ở bài sh-09.

## 10. Hoàn thiện RNA sau sao chép

RNA vừa tổng hợp là **tiền RNA** (*precursor*). Chúng được hoàn thiện thành RNA **trưởng thành** nhờ nhiều enzym, trong đó có enzym **bản chất là RNA (ribozym)** (Giáo trình tr. 186). Ba kiểu biến đổi: (1) **cắt intron**, biến đổi một số base; (2) **gắn mũ 5'**; (3) **gắn đuôi poly A 3'** (với mRNA).

### 10.1. Hoàn thiện mRNA

Tiền mRNA **lớn hơn** mRNA hoàn thiện. Ba bước:

**a) Cắt intron (splicing) — 3 nhóm** (tr. 186–187):

| Nhóm | Chất tham gia | Cơ chế |
|---|---|---|
| **Nhóm 1** | Một phân tử **guanosin tự do** (G nucleosid/nucleotid) | 3'-OH của G tấn công, gắn vào đầu 5' của intron; sau đó 3'-OH của exon trước nối với đầu 5' của exon sau, giải phóng intron. **Tự cắt** (ribozym) |
| **Nhóm 2** | Một **adenosin nằm ngay trong intron** | A của intron tạo cầu nối vòng giữa hai đầu intron (hình **thòng lọng**). **Tự cắt** |
| **Nhóm 3** | **snRNP** (ribonucleoprotein nhỏ của nhân) | snRNA + protein kết hợp với intron tạo **thể ghép nối (spliceosome)**, cần **ATP**; intron tách ra, hai exon nối liền. Đây là kiểu của **mRNA người** |

**b) Gắn mũ 7-methylguanosin ở đầu 5'** (tế bào có nhân):

1. Đầu 5' của mRNA là một **nucleosid triphosphat**. Enzym **phosphohydrolase** cắt bớt một phosphat → **diphosphat**.
2. **Guanylyltransferase** gắn **GMP** (lấy từ GTP, giải phóng PP~i~) vào đầu 5' bằng cầu **5'–5' triphosphat** (nối "ngược").
3. **Guanin-7-methyltransferase** gắn nhóm **methyl** vào **N7** của guanin (người cho methyl là S-adenosylmethionin).

**c) Gắn đuôi poly A ở đầu 3':**

- Đuôi poly A **không** đơn giản là gắn thêm vào đầu 3' của bản sao. Sao chép **chạy quá** điểm gắn đuôi; một **riboendonuclease cắt** để tạo đầu **3'-OH tự do**.
- Ngay sau đó **polyadenylat polymerase** gắn liên tiếp AMP:

=> RNA + n ATP → RNA–(AMP)~n~ + n PP~i~

- **n = 20–250** (giáo trình). Enzym **không cần khuôn**; mRNA đóng vai trò như **"mồi"** để kéo dài.

**Vì sao cần mũ và đuôi?** Mũ 5' và đuôi poly A **bảo vệ mRNA khỏi exonuclease** (mục 7) và giúp ribosom nhận diện mRNA khi dịch mã; mũ còn cần cho việc đưa mRNA ra tế bào chất.

> [!bay]
> - Mũ 5' là **7-methylguanosin**, nối với mRNA bằng cầu **5'–5'**, không phải 3'–5' như liên kết phosphodiester thường.
> - Poly A polymerase **không cần khuôn** DNA: trên gen **không có** đoạn poly T tương ứng.
> - Cắt intron nhóm 1, 2 là **RNA tự cắt** (ribozym), không cần protein; nhóm 3 cần **spliceosome** và ATP.

### 10.2. Hoàn thiện tRNA

Theo giáo trình (tr. 187):

1. Cắt bớt nucleotid ở **đầu 5'** bằng endonuclease **RNase P** (một ribozym); cắt nucleotid **đầu 3'** bằng exonuclease **RNase D**.
2. Cắt **intron** bằng endonuclease, rồi **ligase** nối hai exon.
3. Gắn thêm **CCA** ở đầu 3' (đặc trưng của mọi tRNA, nơi gắn acid amin) nhờ **tRNA nucleotidyltransferase** — **không cần khuôn**.
4. **Biến đổi base**: hơn 60 kiểu biến đổi base và ribose, do hơn 100 enzym khác nhau (tạo các base hiếm như pseudouridin, dihydrouridin — xem bài hs-04).

### 10.3. Hoàn thiện rRNA

| | Tiền rRNA | rRNA trưởng thành |
|---|---|---|
| **Tế bào có nhân** | **45S** | **18S, 5,8S, 28S** |
| **Tế bào không nhân** (vi khuẩn) | **30S** | **16S, 23S, 5S** và một số tRNA |

*Bổ sung:* ở tế bào có nhân, rRNA **5S** được tổng hợp **riêng** bởi RNA polymerase III, không đến từ tiền rRNA 45S.

## 11. Sao chép ngược — tổng hợp DNA từ RNA của virus

Một số virus động vật có RNA làm vật liệu di truyền nhưng mang theo **enzym sao chép ngược** (reverse transcriptase). Khi nhiễm vào tế bào, enzym này tổng hợp **DNA từ khuôn RNA** của virus (Giáo trình tr. 188). Enzym có **3 hoạt tính**:

1. **DNA polymerase phụ thuộc RNA**: từ RNA sợi đơn tạo **thể lai RNA–DNA**.
2. **RNase H**: phân hủy phần **RNA** trong thể lai → còn **DNA sợi đơn**.
3. **DNA polymerase phụ thuộc DNA**: từ DNA sợi đơn tạo **DNA sợi đôi**.

Với các **retrovirus**, DNA này có thể **hòa nhập vào bộ gen** của tế bào chủ — đây là cơ chế gây ung thư của một số virus. Các chất **ức chế sao chép ngược** được dùng làm thuốc, ví dụ **AZT** để điều trị HIV.

> [!cap-nhat] Hai chỗ cần sửa trong giáo trình (tr. 188)
> - Giáo trình lấy **adenovirus** làm ví dụ virus có sao chép ngược nhưng không hòa nhập bộ gen. Thực ra adenovirus là **virus DNA**, **không có** enzym sao chép ngược. Ví dụ đúng của virus dùng sao chép ngược mà **không** cần hòa nhập bộ gen là **virus viêm gan B** (HBV).
> - Tên đầy đủ của AZT (zidovudin) là **3'-azido-2',3'-dideoxy*thymidin*** (một nucleosid), không phải "dideoxythymine".
> - Hình sao chép ngược được đánh số trùng là "Hình 11.3"; đúng thứ tự phải là 11.13.

> [!ung-dung] Thuốc kháng virus nucleosid — "viên gạch giả" không có 3'-OH
> - **Nguyên lý:** polymerase luôn gắn nucleotid mới vào **nhóm 3'-OH** của nucleotid trước (mục 8.1). Thuốc có hình dạng **giống nucleosid** nhưng **không có 3'-OH**. Sau khi được phosphoryl hóa thành dạng triphosphat, nó bị polymerase của virus gắn vào chuỗi DNA → **chuỗi dừng lại** (kết thúc chuỗi).
> - **AZT** (giống thymidin, 3'-OH thay bằng **–N~3~**), **lamivudin**, **tenofovir**: ức chế **enzym sao chép ngược** của HIV; lamivudin, tenofovir, **entecavir** cũng dùng trị **viêm gan B**.
> - **Acyclovir** (giống guanosin, đường bị "cắt hở", không có 3'-OH) trị **Herpes**. Nó **chọn lọc** vì bước phosphoryl hóa đầu tiên cần **thymidin kinase của virus**; tế bào lành không có enzym này nên ít bị ảnh hưởng.
> - **Sofosbuvir** (giống uridin nucleotid) ức chế RNA polymerase phụ thuộc RNA của **virus viêm gan C**.
> - Lưu ý: **entecavir** và **sofosbuvir** vẫn **còn 3'-OH**; chúng dừng chuỗi nhờ nhóm thế làm polymerase không gắn tiếp được sau một vài nucleotid (kết thúc chuỗi "không bắt buộc"). Nguyên lý "thiếu 3'-OH" đúng hoàn toàn với AZT, lamivudin, tenofovir, acyclovir.
> - Một "nucleosid thiếu 3'-OH" từ tự nhiên là **cordycepin** của Đông trùng hạ thảo: xem khung YHCT ở bài *Hóa học acid nucleic* (mã hs-04).

## Tóm tắt

| Chủ đề | Điều cần nhớ |
|---|---|
| Tiêu hóa | Nuclease tụy → nucleotidase → nucleosidase/phosphorylase → base + ribose(-1-P). Acid nucleic **không thiết yếu** trong khẩu phần |
| Thoái hóa purin | AMP → adenosin → inosin → **hypoxanthin**; GMP → guanosin → **guanin** → xanthin; hypoxanthin → **xanthin** → **acid uric** (**xanthin oxidase**, cả 2 bước). Acid uric máu 130–480 µmol/L (2,2–8 mg/dL, giáo trình) |
| Gout | Urat lắng đọng ở khớp, thận; chủ yếu do **giảm thải**; có thể do **tăng tạo** (Lesch–Nyhan, von Gierke, bạch cầu cấp). Thuốc **allopurinol, febuxostat** ức chế xanthin oxidase → sản phẩm cuối là hypoxanthin, xanthin (dễ tan hơn) |
| Các loài | Người: acid uric (không có urat oxidase); phần lớn thú: allantoin; lưỡng cư: urê; động vật biển không xương sống: NH~4~^+^ |
| Thoái hóa pyrimidin | Ở gan, bằng **khử**, mở vòng → **β-alanin** (từ C, U), **β-aminoisobutyrat** (từ T) → malonyl-CoA, methylmalonyl-CoA |
| Nhân purin | N1: Asp; C2, C8: formyl-THF; N3, N9: Gln; C4, C5, N7: **Gly**; C6: CO~2~. Dựng **trên ribose-5-P** |
| Tổng hợp purin | PRPP → (bước cam kết: amidophosphoribosyl transferase) → … → **IMP** (11 phản ứng). IMP + Asp + **GTP** → AMP; IMP → XMP (NAD^+^) → GMP (+ Gln, **ATP**). Điều hòa ngược bởi AMP, GMP, IMP |
| Tổng hợp pyrimidin | Carbamoyl-P (**CPS II**, bào tương, Gln) + Asp → carbamoyl aspartat → dihydroorotat → **orotat** → (+ PRPP) OMP → **UMP** → UTP → **CTP** (+ Gln) |
| Deoxyribonucleotid | Khử C2' ở mức NDP (ribonucleotid reductase). dUMP → **dTMP** (thymidylat synthase + methylen-THF); DHF → THF (DHFR) |
| Tận dụng | Base + PRPP → nucleotid (**HGPRT**: hypoxanthin, guanin; APRT: adenin). Thiếu HGPRT → **Lesch–Nyhan** |
| Thuốc kháng chuyển hóa | Methotrexat ⊣ DHFR; 5-FU ⊣ thymidylat synthase; 6-MP; hydroxyure ⊣ ribonucleotid reductase; mycophenolat ⊣ IMPDH; leflunomid ⊣ DHODH |
| Thoái hóa acid nucleic | Exonuclease (cắt đầu chuỗi), endonuclease (cắt giữa); RNase P (tiền tRNA), RNase H (RNA trong thể lai RNA–DNA) |
| Tái bản (*E. coli*) | oriC 245 base, DnaA, HU → DnaB~6~/DnaC~6~ → primase (mồi RNA 10–60 nu) → **Pol III** kéo dài → **Pol I** cắt mồi + lấp → **ligase** nối. Kết thúc ở vùng **Ter** + protein **Tus**; topoisomerase tách DNA con. Gyrase bị novobiocin, acid oxolinic ức chế |
| Sửa chữa DNA | Sai 10^−9^–10^−11^. 4 hệ: cặp sai; từng base; cắt đoạn nucleotid; trực tiếp (dimer pyrimidin, O^6^-methylguanin) |
| Sao chép RNA | Không cần mồi; khuôn được bảo tồn; không có nuclease. Promoter −70 → +30; −35 phức hợp đóng, −10 phức hợp mở; base đầu là purin (GTP/ATP), giữ 5'-triphosphat; kết thúc: chuỗi U + kẹp tóc ± Rho. Ức chế: **rifampicin** (vi khuẩn), **α-amanitin** (nhân thật), **actinomycin D** (chen DNA) |
| Hoàn thiện RNA | mRNA: cắt intron (nhóm 1: G; nhóm 2: A trong intron; nhóm 3: snRNP/spliceosome + ATP), **mũ m^7^G 5'**, **poly A** 20–250 (không khuôn). tRNA: RNase P, RNase D, cắt intron, **CCA**, biến đổi base. rRNA: 45S → 18S, 5,8S, 28S; 30S → 16S, 23S, 5S |
| Sao chép ngược | RNA → thể lai RNA–DNA → (RNase H) → DNA sợi đơn → DNA sợi đôi. Retrovirus hòa nhập bộ gen. Thuốc: AZT và các nucleosid **thiếu 3'-OH** |
