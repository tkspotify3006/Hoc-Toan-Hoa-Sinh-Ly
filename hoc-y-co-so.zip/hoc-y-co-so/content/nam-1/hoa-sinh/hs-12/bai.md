---
title: Sinh tổng hợp protein
thoi-gian: 40 phút
muc-tieu:
- Kể được các yếu tố tham gia sinh tổng hợp protein (DNA, mRNA, tRNA, rRNA – ribosom, enzym, các yếu tố mở đầu – kéo dài – kết thúc, năng lượng, ion, acid amin) và phân tích được vai trò của từng yếu tố.
- Trình bày được bằng sơ đồ các giai đoạn sinh tổng hợp protein: hoạt hóa acid amin, mở đầu, kéo dài, kết thúc, hoàn thiện chuỗi; tính được năng lượng tiêu tốn cho mỗi liên kết peptid.
- So sánh được sinh tổng hợp protein ở tế bào nhân sơ và nhân thật; giải thích được cơ sở tác dụng chọn lọc của các kháng sinh ức chế dịch mã và cơ chế của một số độc tố (bạch hầu, ricin).
- Kể được các kiểu hoàn thiện chuỗi polypeptid sau dịch mã và phân biệt cách hoàn thiện protein bài xuất với protein ở lại trong tế bào.
- Phân tích được cơ chế điều hòa sinh tổng hợp protein ở tế bào nhân sơ (operon lactose, operon tryptophan) và ở tế bào nhân thật (hem, interferon qua eIF-2).
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Dịch mã = đổi trình tự codon trên **mRNA** (mARN) thành trình tự acid amin (amino acid), xảy ra ở **ribosom** trong bào tương. **5 giai đoạn**: hoạt hóa acid amin → mở đầu → kéo dài → kết thúc → hoàn thiện chuỗi.
> 2. **Aminoacyl-tRNA synthetase** gắn đúng acid amin vào đúng tRNA, tốn **1 ATP → AMP + PP~i~** (= 2 liên kết giàu năng lượng). Đây là nơi mã di truyền thật sự được "dịch".
> 3. Mỗi vòng kéo dài: **EF-Tu·GTP** đưa aa-tRNA vào **A** → **peptidyl transferase** (50S) tạo liên kết peptid → **EF-G·GTP** chuyển vị. Tổng cộng **4 liên kết giàu năng lượng cho một liên kết peptid**.
> 4. Nhân sơ: ribosom **70S**, mở đầu bằng **fMet**, mRNA **polycistron**. Nhân thật: **80S**, mở đầu bằng **Met**, mRNA **monocistron**, nhiều eIF hơn. Khác biệt 70S/80S là cơ sở của **kháng sinh** (tetracyclin, aminoglycosid – 30S; macrolid, cloramphenicol – 50S).
> 5. Chuỗi mới tổng hợp phải **hoàn thiện** (cắt fMet/Met, cắt peptid tín hiệu, phosphoryl hóa, gắn nhóm phụ, cắt tiền chất, tạo cầu disulfua). Điều hòa: nhân sơ qua **operon** (lac – cảm ứng; trp – kìm hãm); nhân thật qua **phosphoryl hóa eIF-2** (thiếu hem, interferon).

Theo giáo trình (tr. 189), một sinh vật đơn bào đã có hơn 3000 loại protein khác nhau. Mọi sai lệch trong cấu trúc protein, dù do gen hay do quá trình tổng hợp, đều có thể gây bệnh. Bài này nhìn dịch mã bằng con mắt **hóa sinh**: ai xúc tác, năng lượng lấy từ đâu, liên kết nào được tạo ra, và thuốc hay độc tố chặn ở bước nào.

> [!bay] Đọc kèm bài khác, không học lại
> - **Mã di truyền** (64 codon, AUG mở đầu, UAA–UAG–UGA kết thúc, tính thoái hóa), **phiên mã**, mô tả các bước dịch mã theo môn Sinh học và **mô hình operon** chi tiết: bài **Cơ sở phân tử của hiện tượng di truyền** (Sinh học, sh-09, mục 4–6).
> - Cấu trúc **tRNA** (hình lá chè ba, đầu CCA-3', đối mã), **rRNA**, **mRNA** (mũ, đuôi poly A): bài **Hóa học acid nucleic** (hs-04, mục 4).
> - **Liên kết peptid** và các bậc cấu trúc protein: bài **Hóa học acid amin, protein** (hs-03).
> - Lưới nội bào hạt, bộ Golgi và đường đi của protein tiết: bài **Màng tế bào và tế bào chất** (Sinh học, sh-02).

## 1. Các yếu tố tham gia

Giáo trình (tr. 189–191) liệt kê 8 nhóm yếu tố. Hiểu vai trò của từng yếu tố là trả lời được câu ôn tập số 1.

| Yếu tố | Vai trò |
|---|---|
| **DNA** (ADN) | Cơ sở vật chất di truyền; quyết định trình tự (và do đó chức năng) của protein. Đột biến DNA → protein thay đổi |
| **mRNA** | Bản sao thông tin từ DNA (ở nhân) mang ra bào tương; trình tự acid amin được quy định qua các **bộ ba mã** (codon) đọc liên tiếp, không chồng gối, ví dụ UAC GCU AAC GUU… |
| **tRNA** | "RNA hòa tan" trong bào tương; **gắn acid amin** ở đầu **–CCA** và **mang đối mã** (anticodon) khớp với codon. Giáo trình: tRNA có **6 vị trí chức năng**; đã biết **gần 60 loại** tRNA |
| **rRNA + protein → ribosom** | Nơi diễn ra dịch mã. Mọi ribosom gồm **2 tiểu đơn vị**: nhân sơ **30S + 50S = 70S**. Phần lớn ribosom **tự do** trong bào tương, một phần **gắn lưới nội bào**. Nhiều ribosom cùng đọc một mRNA → **polyribosom (polysom)** |
| **Enzym** | **Aminoacyl-tRNA synthetase**: tạo aa-tRNA, đặc hiệu với **cả acid amin lẫn tRNA**. **Peptidyl transferase**: tạo liên kết peptid |
| **Yếu tố protein** | Mở đầu: **IF1, IF2, IF3**. Kéo dài: **EF-T** (gồm **EF-Tu** và **EF-Ts**) và **EF-G**. Kết thúc: **RF1, RF2, RF3** |
| **Năng lượng, ion** | **ATP, GTP**; **Mg^2+^, NH~4~^+^, K^+^** (giữ cấu trúc và hoạt tính ribosom) |
| **Nguyên liệu** | **20 acid amin** |

> [!vi-du] Vì sao chỉ cần khoảng 60 loại tRNA cho 61 codon có nghĩa?
> Base thứ nhất của đối mã (đầu 5') bắt cặp với base thứ ba của codon (đầu 3') **không chặt chẽ** như hai base kia. Hiện tượng này gọi là **"lắc lư"** (wobble, Crick đề xuất 1966). Ví dụ G ở đối mã bắt cặp được với cả C và U; inosin (I, một base hiếm) bắt cặp được với U, C hoặc A. Nhờ vậy, một tRNA đọc được nhiều codon cùng mã hóa một acid amin. Đây cũng là lý do mã di truyền "thoái hóa" chủ yếu ở **base thứ ba**.

> [!bay] Phân biệt "EF-T" và "EF-Tu, EF-Ts"
> Giáo trình gọi chung **EF-T** gồm hai loại **EF-Tu** và **EF-Ts**. **EF-Tu** gắn GTP và chở aa-tRNA vào ribosom. **EF-Ts** không chở aa-tRNA mà **tái tạo** EF-Tu·GTP: nó đẩy GDP ra khỏi EF-Tu để GTP mới gắn vào. Giáo trình ghi "cả hai đều có hoạt tính GTPase"; thực ra chỉ **EF-Tu** thủy phân GTP, EF-Ts là yếu tố **trao đổi nucleotid**.

## 2. Hoạt hóa acid amin

Acid amin tự do **không tự gắn** được vào chuỗi peptid. Nhóm –COOH của nó phải được "kích hoạt" bằng cách gắn vào tRNA qua một **liên kết ester giàu năng lượng**. Phản ứng xảy ra ở **bào tương**, do **aminoacyl-tRNA synthetase** xúc tác, qua **2 bước** (Giáo trình tr. 191–192):

=> Bước 1: acid amin + ATP → aminoacyl-AMP (gắn với enzym) + PP~i~

=> Bước 2: aminoacyl-AMP + tRNA → aminoacyl-tRNA + AMP

=> Tổng: acid amin + tRNA + ATP → aminoacyl-tRNA + AMP + PP~i~ ; PP~i~ + H~2~O → 2 P~i~

- **Bước 1**: nhóm –COO^−^ của acid amin tấn công phosphat α của ATP, tạo **aminoacyl-adenylat** (aminoacyl-AMP). Đây là một **anhydrid hỗn hợp** (carboxylic – phosphoric) rất giàu năng lượng; nó nằm yên trong trung tâm hoạt động của enzym.
- **Bước 2**: gốc aminoacyl được chuyển sang nhóm –OH của **adenosin cuối cùng (đầu CCA-3')** của tRNA. Giáo trình mô tả **2 cách**: gắn vào **–OH 2'** rồi chuyển vị trí liên kết ester sang **–OH 3'** (cách 1), hoặc gắn thẳng vào **–OH 3'** (cách 2). Cuối cùng, dạng tham gia dịch mã có liên kết ester ở **3'-OH**.
- **PP~i~ bị pyrophosphatase thủy phân ngay**, kéo cân bằng về phía tạo aa-tRNA. Vì vậy, tuy chỉ dùng 1 phân tử ATP, tế bào thực chất tiêu tốn **2 liên kết phosphat giàu năng lượng** (ATP → AMP).

> [!ghi-nho] Trả lời câu ôn tập số 2 của giáo trình
> Hoạt hóa **một** acid amin tốn **1 ATP** nhưng bị cắt thành **AMP + PP~i~**, tức **2 liên kết giàu năng lượng**, tương đương **2 ATP** (khi quy về ATP → ADP).

**Vì sao enzym này quyết định độ chính xác?** Ribosom chỉ kiểm tra **đối mã có khớp codon hay không**, không kiểm tra acid amin mà tRNA chở. Nếu synthetase gắn nhầm, acid amin sai sẽ được đưa vào protein. Người có khoảng 20 loại synthetase chính trong bào tương, mỗi loại nhận **một acid amin** và **tất cả các tRNA** của acid amin đó. Một số synthetase có thêm **vị trí "biên tập"** (proofreading): ví dụ isoleucyl-tRNA synthetase thủy phân bỏ valin gắn nhầm (valin nhỏ hơn isoleucin đúng một nhóm –CH~2~). Nhờ vậy tỷ lệ sai khi dịch mã chỉ khoảng 1/10 000.

> [!vi-du] Thí nghiệm kinh điển chứng minh tRNA "không nhìn" acid amin
> Người ta gắn cystein lên tRNA^Cys^, rồi khử hóa học cystein thành alanin ngay trên tRNA (Cys-tRNA^Cys^ → Ala-tRNA^Cys^). Khi đưa vào hệ dịch mã, **alanin** được gắn vào đúng chỗ của codon **cystein**. Kết luận: ribosom chỉ đọc **đối mã**, nên độ chính xác phụ thuộc vào synthetase.

## 3. Các giai đoạn ở tế bào nhân sơ

### 3.1. Mở đầu chuỗi

Thông thường chuỗi bắt đầu bằng **methionin**, mã hóa bởi **AUG** (mã mở đầu). Ở nhân sơ, methionin mở đầu đi vào dưới dạng **fMet-tRNA** (N-formylmethionyl-tRNA). Nhóm formyl gắn vào nhóm –NH~2~ của Met, nên acid amin đầu tiên **không thể** tạo liên kết peptid bằng nhóm amin của nó. Nhờ vậy fMet chỉ đứng được ở **đầu N** của chuỗi.

Trình tự theo giáo trình (tr. 193):

1. Ribosom 70S **không hoạt động** khi để nguyên; nó phân ly thành **30S và 50S**.
2. **30S + IF3**, phức hợp này gắn **mRNA**, rồi gắn **IF1**.
3. **fMet-tRNA + GTP + IF2** tạo một phức hợp, gắn vào phức hợp **30S–IF3–mRNA–IF1** → **phức hợp mở đầu**. IF3 được giải phóng, cho phép 50S gắn vào.
4. **GTP trên IF2 bị thủy phân**, cung cấp năng lượng gắn 50S vào 30S, giải phóng IF1 và IF2 → **ribosom 70S hoạt động**.

**Kết quả**: fMet-tRNA nằm ở **vị trí P**, đúng với mã AUG; **vị trí A** trống, chờ aa-tRNA thứ hai.

> [!bay]
> - tRNA mở đầu là tRNA **duy nhất** vào thẳng vị trí **P**. Mọi aa-tRNA khác vào vị trí **A**.
> - Giai đoạn mở đầu tốn **1 GTP** (trên IF2), không phải ATP.
> - Có hai loại tRNA chở methionin: **tRNA^fMet^** (chỉ dùng mở đầu) và **tRNA^Met^** (đọc AUG nằm giữa chuỗi). Chỉ Met gắn trên tRNA^fMet^ mới bị formyl hóa.

> [!vi-du] Ribosom tìm đúng AUG mở đầu bằng cách nào?
> mRNA vi khuẩn có một đoạn giàu purin nằm khoảng **8–13 nucleotid trước AUG**, gọi là **trình tự Shine–Dalgarno**. Đoạn này bắt cặp bổ sung với đầu 3' của **rRNA 16S** trong tiểu đơn vị 30S, đặt AUG đúng vào vị trí P. Vì mỗi gen trong mRNA polycistron có trình tự Shine–Dalgarno riêng, ribosom vi khuẩn có thể bắt đầu dịch ở **nhiều điểm** trên cùng một mRNA.

### 3.2. Kéo dài chuỗi

Đây là quá trình lắp ráp các acid amin theo đúng trình tự mã hóa trên mRNA (Giáo trình tr. 193–195). Mỗi vòng thêm **một** acid amin, gồm **3 bước** (hình 1).

![Hình 1. Một vòng kéo dài chuỗi ở ribosom (vị trí E–P–A) và nơi tác động của kháng sinh, độc tố](keo-dai-chuoi.svg)

**Bước 1 — Gắn aa-tRNA vào vị trí A.** Ví dụ codon ở A là GCU (mã hóa Ala). **GTP + EF-Tu → EF-Tu·GTP**, phức hợp này gắn Ala-tRNA tạo **phức hợp bộ ba EF-Tu·GTP·Ala-tRNA**. Phức hợp đi vào vị trí A. Khi đối mã khớp codon, **GTP bị thủy phân**, **EF-Tu·GDP** rời ribosom. EF-Ts giúp EF-Tu nhả GDP để gắn GTP mới.

*Vì sao cần GTP ở đây?* Khoảng thời gian chờ GTP bị thủy phân là một "chốt kiểm tra". aa-tRNA khớp sai thường **rời đi** trước khi GTP bị cắt. Năng lượng GTP được dùng để **mua độ chính xác**, không dùng để tạo liên kết.

**Bước 2 — Tạo liên kết peptid.** **Peptidyl transferase** (thuộc tiểu đơn vị 50S) xúc tác: **nhóm –NH~2~ của aa-tRNA ở vị trí A** tấn công nhóm **C=O ester** của peptidyl-tRNA (lúc đầu là fMet-tRNA) ở vị trí P. Liên kết ester bị cắt, liên kết peptid –CO–NH– được tạo ra.

=> peptidyl-tRNA (ở P) + aminoacyl-tRNA (ở A) → tRNA rỗng (ở P) + peptidyl-tRNA dài thêm 1 gốc (ở A)

- Kết quả: chuỗi peptid (ví dụ fMet-Ala) chuyển sang gắn trên tRNA ở **vị trí A**; tRNA ở P trở thành tRNA "rỗng".
- Phản ứng **không cần GTP**. Năng lượng lấy từ **liên kết ester giàu năng lượng** của peptidyl-tRNA, tức năng lượng đã "nạp" từ ATP ở bước hoạt hóa.
- Chuỗi luôn mọc từ **đầu N sang đầu C**: acid amin mới luôn được gắn vào **đầu C** của chuỗi đang có.

**Bước 3 — Chuyển vị.** **EF-G** gắn GTP (giáo trình in nhầm thành "CTP"). GTP bị thủy phân, ribosom **trượt theo chiều 5'→3' đúng một codon**. Peptidyl-tRNA chuyển từ **A sang P**; tRNA rỗng chuyển sang **vị trí E** rồi rời ribosom. EF-G tách ra; vị trí A lại trống, sẵn sàng cho vòng kéo dài mới.

> [!bay] Ba vị trí, ba câu hỏi hay gặp
> - **A** (aminoacyl): nơi **aa-tRNA mới** đi vào. **P** (peptidyl): nơi giữ **peptidyl-tRNA**. **E** (exit): nơi **tRNA rỗng** đi ra.
> - Ngay sau bước 2, chuỗi peptid nằm ở **vị trí A**, chưa phải ở P. Nó chỉ về P sau bước chuyển vị.
> - Liên kết peptid lấy năng lượng từ **liên kết ester của aa-tRNA**, không trực tiếp từ GTP. Hai GTP của mỗi vòng dùng cho **EF-Tu** (đưa aa-tRNA vào) và **EF-G** (chuyển vị).

> [!cap-nhat] Peptidyl transferase là RNA, không phải protein
> Giáo trình xếp peptidyl transferase vào nhóm "enzym". Hiện nay đã rõ trung tâm tạo liên kết peptid được xây hoàn toàn bằng **rRNA 23S** (ở nhân thật là rRNA 28S), không có protein nào đủ gần để xúc tác. Ribosom vì vậy là một **ribozym** (RNA có hoạt tính xúc tác). Cấu trúc nguyên tử của ribosom được giải Nobel Hóa học **2009** (Ramakrishnan, Steitz, Yonath). Khi thi, vẫn gọi tên **peptidyl transferase** như giáo trình.

### 3.3. Kết thúc chuỗi

Khi vị trí A gặp một trong 3 **mã kết thúc UAG, UAA, UGA**, không có tRNA nào mang đối mã tương ứng (Giáo trình tr. 196). Thay vào đó, **yếu tố kết thúc** (RF1, RF2, RF3) gắn vào ribosom:

- RF làm peptidyl transferase **chuyển chuỗi peptid cho phân tử nước** thay vì cho một acid amin. Liên kết ester giữa chuỗi và tRNA cuối cùng bị **thủy phân**, đầu C của chuỗi trở thành **–COO^−^** tự do.
- Các thành phần tách rời: **chuỗi polypeptid**, **tRNA cuối cùng**, **mRNA**; ribosom 70S phân ly thành **30S và 50S** để dùng lại.
- RF1 nhận UAA, UAG; RF2 nhận UAA, UGA; RF3 là GTPase giúp giải phóng RF1/RF2 (chi tiết: sh-09 mục 5.1).

### 3.4. Năng lượng tiêu tốn

| Giai đoạn | Tiêu tốn | Số liên kết giàu năng lượng |
|---|---|---|
| Hoạt hóa acid amin | 1 ATP → AMP + PP~i~ | **2** |
| Gắn aa-tRNA vào A (EF-Tu) | 1 GTP → GDP | **1** |
| Chuyển vị (EF-G) | 1 GTP → GDP | **1** |
| **Cộng, cho mỗi liên kết peptid** | | **4** |
| Thêm một lần cho cả chuỗi | Mở đầu (IF2: 1 GTP), kết thúc (RF3: 1 GTP) | — |

> [!ghi-nho] Trả lời câu ôn tập số 3
> Lắp ghép **một** acid amin vào chuỗi cần **4 liên kết giàu năng lượng** (2 từ ATP ở bước hoạt hóa, 2 từ GTP ở bước kéo dài), thường gọi là **4 ATP**. Một protein 100 acid amin tốn khoảng 400 liên kết giàu năng lượng; tính thêm phần sửa sai và GTP mở đầu, kết thúc thì nhiều hơn. Tổng hợp protein là một trong những quá trình **tốn năng lượng nhất** của tế bào. Vì thế tế bào kiểm soát chặt việc khởi đầu dịch mã (mục 6).

> [!bay]
> - Liên kết peptid tự nó là liên kết **bền, nghèo năng lượng**. Năng lượng cần để tạo nó nhỏ hơn nhiều so với 4 liên kết giàu năng lượng mà tế bào bỏ ra. Phần dư là **giá của tốc độ và độ chính xác** (kiểm tra ở synthetase, chờ GTP của EF-Tu).
> - Đề hỏi "bao nhiêu **ATP** để hoạt hóa một acid amin": đáp án theo giáo trình là **1 ATP** (bị cắt thành AMP), **tương đương 2 ATP**. Đọc kỹ đề hỏi "số phân tử" hay "số liên kết giàu năng lượng".

## 4. Sinh tổng hợp protein ở tế bào nhân thật

Về tổng quát, quá trình giống ở nhân sơ, nhưng **nhiều yếu tố hơn** và các giai đoạn **phức tạp hơn** (Giáo trình tr. 196–197).

| | Nhân sơ | Nhân thật |
|---|---|---|
| Nơi phiên mã – dịch mã | **Cùng ở bào tương** → dịch mã có thể bắt đầu **khi phiên mã chưa kết thúc** | Phiên mã ở **nhân**, dịch mã ở **bào tương**; tách nhau bởi **màng nhân** |
| mRNA | Dùng ngay; **polycistron**: nhiều điểm xuất phát, làm khuôn cho **nhiều protein** liên quan (một operon) | Phải **hoàn thiện** (cắt intron, gắn mũ, gắn đuôi poly A) rồi mới ra bào tương; **monocistron**: một điểm xuất phát, **một protein** |
| Ribosom | **70S** (30S + 50S) | **80S** (40S + 60S) |
| Acid amin mở đầu | **fMet**-tRNA | **Met**-tRNA (không formyl hóa) |
| Yếu tố mở đầu | IF1, IF2, IF3 | Nhiều hơn: **eIF2, eIF3, eIF4a, eIF4b, eIF5, CBP** (protein gắn mũ)… |
| Kéo dài | EF-Tu, EF-Ts, EF-G | eEF-1 (tương đương EF-Tu, EF-Ts), **eEF-2** (tương đương EF-G) |
| Kết thúc | RF1, RF2, RF3 | eRF (eRF1 nhận cả 3 mã kết thúc) |

**Vì sao nhân thật có CBP?** mRNA nhân thật không có trình tự Shine–Dalgarno. **Protein gắn mũ** (CBP, nay gọi là eIF4E) nhận ra **mũ 7-methylguanosin** ở đầu 5', kéo tiểu đơn vị 40S vào. Tiểu đơn vị 40S mang **eIF2·GTP·Met-tRNA** rồi **trượt dò** dọc mRNA theo chiều 5'→3' đến **AUG đầu tiên** có bối cảnh thuận lợi. Đó là lý do mRNA nhân thật thường chỉ có một điểm xuất phát (monocistron). mRNA thiếu mũ thì dịch mã kém.

> [!ung-dung] Kháng sinh ức chế dịch mã — vì sao diệt khuẩn mà ít hại người?
> Ribosom vi khuẩn (70S) khác ribosom bào tương người (80S) về rRNA và protein. Thuốc gắn chọn lọc vào 70S nên chặn dịch mã của vi khuẩn (hình 1). sh-09 đã nêu khái quát; dưới đây đi sâu vào **cơ chế hóa sinh** và hệ quả lâm sàng.
>
> | Nhóm | Tiểu đơn vị | Bước bị chặn | Lưu ý lâm sàng |
> |---|---|---|---|
> | **Tetracyclin** (doxycyclin) | 30S | Chặn aa-tRNA gắn vào **vị trí A** | Tạo phức **chelat với Ca^2+^, Mg^2+^, Fe^2+^** → không uống cùng sữa, thuốc kháng acid, viên sắt. Lắng đọng ở xương, răng → **vàng răng** ở trẻ dưới 8 tuổi, tránh dùng khi có thai |
> | **Aminoglycosid** (gentamicin, amikacin, streptomycin) | 30S | Làm méo vị trí giải mã → **đọc sai mã**, tạo protein lỗi; ở nồng độ cao chặn cả mở đầu | Độc **tai** và **thận**; người mang đột biến **A1555G** ở rRNA 12S ty thể rất dễ **điếc** dù chỉ dùng một liều |
> | **Macrolid** (erythromycin, azithromycin, clarithromycin) | 50S | Gắn **đường hầm thoát** của chuỗi peptid → chuỗi bị kẹt, ribosom ngừng sau vài acid amin | Erythromycin, clarithromycin **ức chế CYP3A4** → tương tác thuốc |
> | **Cloramphenicol** (chloramphenicol) | 50S | Ức chế **peptidyl transferase** (bước tạo liên kết peptid) | Ức chế tủy xương; **hội chứng xám** ở trẻ sơ sinh (gan chưa liên hợp glucuronid được) |
> | Lincosamid (clindamycin), linezolid | 50S | Clindamycin gần vị trí của macrolid; linezolid chặn tạo phức hợp mở đầu 70S | — |
> | Acid fusidic | — | Giữ **EF-G·GDP** trên ribosom → chặn chuyển vị | Dùng tại chỗ cho nhiễm tụ cầu ngoài da |
>
> *Vì sao vẫn có tác dụng phụ trên người?* **Ribosom ty thể** của người (55S) có nguồn gốc vi khuẩn, giống 70S. Đó là lý do aminoglycosid gây điếc và cloramphenicol ức chế tủy xương phụ thuộc liều.
>
> **Puromycin** có cấu trúc giống đầu 3' của tyrosyl-tRNA. Nó chui vào vị trí A, nhận chuỗi peptid rồi rời ribosom → **chuỗi bị cắt cụt sớm**. Puromycin tác động lên **cả** 70S và 80S nên chỉ dùng trong nghiên cứu. **Cycloheximid** chỉ chặn ribosom 80S, cũng chỉ dùng trong phòng thí nghiệm.

> [!ung-dung] Độc tố bạch hầu — một phân tử giết một tế bào
> Vi khuẩn *Corynebacterium diphtheriae* (mang gen độc tố từ một phage) tiết ra độc tố gồm hai mảnh. **Mảnh B** gắn thụ thể trên tế bào người, đưa **mảnh A** vào bào tương. Mảnh A là một **enzym**: nó lấy **ADP-ribose từ NAD^+^** gắn vào một acid amin biến đổi đặc biệt của **eEF-2** (diphthamid, dẫn xuất của histidin).
> - eEF-2 bị **ADP-ribosyl hóa** thì mất hoạt tính → **không chuyển vị được** → dịch mã dừng → tế bào chết.
> - Vì là enzym, **một phân tử mảnh A đủ bất hoạt toàn bộ eEF-2** của một tế bào. Hệ quả: màng giả ở họng, viêm cơ tim, viêm dây thần kinh.
> - Độc tố tác động lên **eEF-2 của người** (80S); EF-G của vi khuẩn không có diphthamid nên không bị ảnh hưởng. Độc tố ngoại bào A của *Pseudomonas aeruginosa* có cùng cơ chế.
> - Điều trị: **huyết thanh kháng độc tố** (trung hòa độc tố còn lưu hành, chưa vào tế bào) + kháng sinh. Phòng bệnh: vaccin **giải độc tố** (toxoid) trong mũi DPT. Việt Nam vẫn ghi nhận các ổ dịch bạch hầu ở nơi tỷ lệ tiêm chủng thấp.

> [!yhct] Ricin của hạt Thầu dầu và trichosanthin của Thiên hoa phấn — "protein bất hoạt ribosom"
> - **Thầu dầu** (*Ricinus communis*; hạt là vị **Bì ma tử**) chứa **ricin**. Ricin gồm 2 chuỗi nối bằng cầu disulfua. **Chuỗi B** là lectin, gắn vào đường galactose trên bề mặt tế bào để đưa độc tố vào. **Chuỗi A** là một **N-glycosidase**: nó cắt bỏ **một base adenin** trong một vòng đặc biệt của **rRNA 28S** (tiểu đơn vị 60S). Vòng này là chỗ gắn của các yếu tố kéo dài, nên ribosom bị hỏng vĩnh viễn và **dịch mã dừng**. Một chuỗi A có thể bất hoạt khoảng nghìn ribosom mỗi phút. Đây là cơ chế **đã chứng minh rõ** ở mức phân tử.
> - **Cảnh báo độc:** **nhai** hạt Thầu dầu (nhất là trẻ em ăn nhầm) có thể gây nôn, tiêu chảy ra máu, mất nước, tổn thương gan thận, có thể tử vong. Không có thuốc giải đặc hiệu, chỉ điều trị hỗ trợ. Sách dược liệu xếp Bì ma tử vào vị **có độc**; YHCT chủ yếu **giã đắp ngoài**, không dùng uống hạt sống. **Dầu thầu dầu** dùng làm thuốc nhuận tràng thì **không chứa ricin**: ricin là protein, tan trong nước, ở lại trong bã ép và bị hủy khi xử lý nhiệt. Tác dụng tẩy của dầu là do **acid ricinoleic**.
> - **Thiên hoa phấn** (rễ củ *Trichosanthes kirilowii*) chứa **trichosanthin**, một protein bất hoạt ribosom cùng cơ chế với chuỗi A của ricin. Dạng **protein tinh chế tiêm** từng được dùng ở Trung Quốc để gây sẩy thai giữa thai kỳ (nó độc với tế bào lá nuôi của nhau thai). Điều này phù hợp với việc sách YHCT ghi **thận trọng hoặc kiêng dùng Thiên hoa phấn cho phụ nữ có thai**. Tuy vậy, đây là dữ liệu của protein tinh chế dùng đường tiêm. Không suy ra rằng thuốc sắc uống có cùng tác dụng, vì protein phần lớn bị biến tính khi sắc và bị tiêu hóa ở ruột.

## 5. Hoàn thiện chuỗi polypeptid sau dịch mã

Chuỗi vừa rời ribosom thường **chưa có hoạt tính**. Nó phải trải qua quá trình **hoàn thiện** (Giáo trình tr. 197). Giáo trình gọi mục này là "hoàn thiện sau **phiên mã**"; đúng ra là **sau dịch mã** (post-translational), vì đây là biến đổi trên chuỗi protein chứ không phải trên RNA.

### 5.1. Sáu kiểu hoàn thiện theo giáo trình

| # | Kiểu biến đổi | Ví dụ, ý nghĩa |
|---|---|---|
| 1 | **Cắt bỏ acid amin mở đầu**: fMet (nhân sơ), Met (nhân thật) và đôi khi vài acid amin ở đầu N, nhờ **deformylase** hoặc **aminopeptidase** | Deformylase chỉ bỏ nhóm formyl; methionin do aminopeptidase cắt. Vì vậy phần lớn protein trưởng thành **không** bắt đầu bằng Met |
| 2 | **Cắt peptid tín hiệu** (khoảng 15–22 acid amin ở đầu N) nhờ **peptidase** đặc hiệu, ở các protein được **bài xuất** ra ngoài tế bào | Peptid tín hiệu dẫn chuỗi vào lưới nội bào hạt, rồi bị cắt bỏ (mục 5.3) |
| 3 | **Biến đổi một số acid amin riêng biệt**: **phosphoryl hóa** nhóm –OH của **Ser, Thr, Tyr** | **Casein** của sữa có nhiều phosphoserin, nhờ đó gắn và chở Ca^2+^ |
| 4 | **Gắn nhóm phụ** (nhóm ngoại) | **Hem** vào globin (Hb), vào cytochrom |
| 5 | **Cắt bỏ một đoạn** để chuyển dạng tiền chất không hoạt động thành dạng hoạt động | **Tiền enzym → enzym** (trypsinogen → trypsin, pepsinogen → pepsin); **tiền hormon → hormon** (proinsulin → insulin, hình 2) |
| 6 | **Tạo liên kết ngang** trong chuỗi hoặc giữa các chuỗi để có cấu trúc không gian ổn định | **Cầu disulfua** giữa hai gốc cystein, liên kết hydro… |

![Hình 2. Hoàn thiện preproinsulin thành insulin: cắt peptid tín hiệu, tạo cầu disulfua, cắt C-peptid](insulin.svg)

> [!ung-dung] Insulin và xét nghiệm C-peptid
> Insulin được tổng hợp thành **preproinsulin** (110 acid amin). Trong lưới nội bào, peptid tín hiệu (24 acid amin) bị cắt, chuỗi gấp lại và tạo **3 cầu disulfua** → **proinsulin** (86 acid amin). Trong hạt tiết, enzym cắt bỏ đoạn nối (C-peptid 31 acid amin, cùng 4 acid amin kiềm ở hai đầu bị carboxypeptidase cắt tiếp) → **insulin** gồm chuỗi **A (21)** và **B (30)** nối bằng 2 cầu disulfua.
> - C-peptid và insulin được tiết ra **cùng lúc, cùng số phân tử**. Insulin bị gan giữ lại nhiều ở lần đi qua đầu tiên, còn C-peptid thì không và có thời gian bán thải dài hơn. Vì vậy **định lượng C-peptid** phản ánh lượng **insulin nội sinh** tốt hơn, kể cả ở người đang tiêm insulin (insulin thương mại không chứa C-peptid).
> - Ứng dụng: phân biệt đái tháo đường **typ 1** (C-peptid rất thấp) với **typ 2**; tìm nguyên nhân hạ đường huyết (u tiết insulin: insulin cao, C-peptid cao; tiêm insulin quá liều: insulin cao, C-peptid thấp).
> - Khoảng tham chiếu lúc đói thường dùng khoảng **0,3–1,3 nmol/L** (tham khảo, mỗi phòng xét nghiệm có khoảng riêng).

### 5.2. Các biến đổi quan trọng khác (bổ sung)

Giáo trình chỉ nêu 6 ý trên. Các biến đổi dưới đây thường gặp trong các môn sau và trong lâm sàng.

**a) Gấp nếp nhờ chaperon.** Trình tự acid amin quyết định cấu trúc không gian, nhưng trong bào tương đông đặc, chuỗi đang mọc dễ **dính nhầm** vào nhau qua các đoạn kỵ nước. **Chaperon** (protein "người kèm") gắn tạm vào các đoạn kỵ nước này, ngăn kết tụ và giúp chuỗi gấp đúng:
- **HSP70** gắn chuỗi ngay khi nó vừa ra khỏi ribosom.
- **Chaperonin** (HSP60) tạo một "buồng" hình thùng để chuỗi gấp nếp trong đó, cách ly với môi trường.
- Chaperon **tiêu tốn ATP**. Chúng tăng mạnh khi tế bào bị sốc nhiệt, nên được gọi là **protein sốc nhiệt** (heat shock protein, HSP).
- Trong lưới nội bào còn có enzym **protein disulfua isomerase** giúp các gốc cystein ghép đúng cặp khi tạo cầu disulfua.
- Protein gấp sai bị đánh dấu bằng **ubiquitin** và phân hủy trong **proteasom**. Khi cơ chế này quá tải, protein gấp sai **kết tụ** gây bệnh: amyloid, bệnh Alzheimer, prion (xem hs-03); xơ nang (protein CFTR gấp sai ở đột biến hay gặp nhất bị phân hủy, không lên được màng).

**b) Glycosyl hóa** (gắn chuỗi đường, tạo **glycoprotein**, xem hs-01):
- **Gắn N**: chuỗi oligosaccharid gắn vào nhóm amid của **asparagin** (Asn). Bắt đầu ngay trong **lưới nội bào hạt**, khi chuỗi còn đang được tổng hợp, rồi được "tỉa" và sửa tiếp ở **Golgi**.
- **Gắn O**: đường gắn vào nhóm –OH của **serin, threonin** (ở collagen là **hydroxylysin**); chủ yếu ở **Golgi**.
- Hầu hết protein huyết tương (trừ albumin), protein màng, kháng nguyên nhóm máu ABO đều là glycoprotein.

**c) Hydroxyl hóa — vitamin C và collagen.** Collagen chứa nhiều **hydroxyprolin** và **hydroxylysin**. Hai acid amin này **không có codon riêng**; chúng được tạo ra **sau dịch mã** khi enzym **prolyl hydroxylase** và **lysyl hydroxylase** gắn –OH vào các gốc prolin, lysin đã nằm sẵn trong chuỗi (trong lòng lưới nội bào). Enzym cần **Fe^2+^, O~2~, α-cetoglutarat** và **vitamin C (acid ascorbic)**. Vitamin C giữ sắt ở dạng **Fe^2+^** để enzym hoạt động.
- *Vì sao hydroxyprolin quan trọng?* Nó giúp **chuỗi xoắn ba** của collagen bền ở thân nhiệt. Hydroxylysin là chỗ gắn đường và chỗ tạo **liên kết ngang** giữa các phân tử collagen.

> [!ung-dung] Bệnh scorbut (thiếu vitamin C)
> Thiếu vitamin C kéo dài (thường sau 1–3 tháng ăn thiếu rau quả tươi) → collagen thiếu hydroxyprolin, xoắn ba kém bền, bị phân hủy nhanh → **thành mạch, nướu, da, xương yếu**:
> - **Chảy máu chân răng**, nướu sưng; **xuất huyết quanh nang lông**, dễ bầm tím; vết thương **lâu lành**, sẹo cũ có thể bục ra.
> - Trẻ nhỏ: đau xương, chảy máu dưới màng xương. Kèm thiếu máu (vitamin C còn giúp hấp thu sắt).
> - Nhóm nguy cơ: người nghiện rượu, người già ăn uống kém, chế độ ăn kiêng khắt khe, bệnh nhân lọc máu, trẻ chỉ uống sữa bò tiệt trùng không ăn dặm rau quả.
> - Nồng độ acid ascorbic huyết tương **dưới khoảng 11 µmol/L** gợi ý thiếu nặng (tham khảo, mỗi phòng xét nghiệm có khoảng riêng). Điều trị bằng vitamin C cho kết quả nhanh: chảy máu giảm trong vài ngày.

**d) Các biến đổi khác cần biết tên.** **γ-carboxyl hóa** gốc glutamat ở các yếu tố đông máu II, VII, IX, X (cần **vitamin K**, xem hs-03); **acetyl hóa, methyl hóa** histon (điều hòa gen); **gắn lipid** (giúp protein bám màng); **gắn ubiquitin** (đánh dấu để phân hủy).

> [!bay] Glycosyl hóa ≠ glycat hóa (HbA1c)
> - **Glycosyl hóa** do **enzym** xúc tác, có vị trí xác định, là biến đổi **sinh lý** cần cho chức năng protein.
> - **Glycat hóa** (glycation) là phản ứng **không cần enzym** giữa glucose và nhóm –NH~2~ tự do của protein. Tốc độ phụ thuộc vào **nồng độ glucose máu**. **HbA1c** là hemoglobin bị **glycat hóa**, nên phản ánh đường huyết trung bình 2–3 tháng. Không gọi HbA1c là "hemoglobin glycosyl hóa".

### 5.3. Protein bài xuất và protein ở lại trong tế bào (câu ôn tập số 5)

Ribosom nào cũng bắt đầu dịch mã trong bào tương. Số phận của chuỗi do **đoạn đầu N** của nó quyết định:

- **Protein bài xuất** (hormon peptid, enzym tiêu hóa, kháng thể, albumin), protein màng và protein lysosom có **peptid tín hiệu** kỵ nước ở đầu N. Ngay khi đoạn này ló ra khỏi ribosom, nó được **hạt nhận diện tín hiệu** (SRP) bắt lấy. Dịch mã tạm dừng, ribosom được kéo đến **lưới nội bào hạt** (vì thế lưới nội bào có "hạt"). Chuỗi vừa được tổng hợp vừa **luồn qua màng** vào lòng lưới; **peptidase tín hiệu** cắt bỏ peptid tín hiệu. Trong lòng lưới, chuỗi được **gấp nếp, tạo cầu disulfua, glycosyl hóa gắn N**. Sau đó protein đi qua **Golgi** (glycosyl hóa tiếp, cắt tiền chất), vào **túi tiết** rồi ra ngoài tế bào.
- **Protein ở lại trong bào tương** (enzym đường phân, hemoglobin, actin…) **không có** peptid tín hiệu, được tổng hợp trên **ribosom tự do**. Chúng vẫn được cắt Met đầu, gấp nếp nhờ chaperon, phosphoryl hóa, gắn nhóm phụ; nhưng **không** qua lưới nội bào – Golgi, nên **hiếm khi** có cầu disulfua hoặc glycosyl hóa gắn N.

| | Protein bài xuất | Protein bào tương |
|---|---|---|
| Ribosom | Gắn **lưới nội bào hạt** | **Tự do** |
| Peptid tín hiệu | Có, bị **cắt bỏ** | Không |
| Cầu disulfua, glycosyl hóa gắn N | Thường có | Hiếm |
| Cắt tiền chất | Thường gặp (proinsulin, trypsinogen) | Ít gặp |
| Giống nhau | Cùng bắt đầu dịch mã ở bào tương; cùng có thể bị cắt Met đầu, phosphoryl hóa, gắn nhóm phụ, cần gấp nếp đúng | |

> [!cap-nhat] Giả thuyết tín hiệu
> Ý tưởng "đoạn đầu N mang địa chỉ đến của protein" do **Günter Blobel** chứng minh, được giải Nobel Y học **1999**. Hiểu biết này có ý nghĩa trong sản xuất thuốc sinh học. Vi khuẩn **không glycosyl hóa** protein như người. Vì vậy các protein cần chuỗi đường để có tác dụng, như **kháng thể đơn dòng** và **erythropoietin**, phải được sản xuất trong tế bào động vật có vú (thường là tế bào buồng trứng chuột đồng, CHO). Insulin không có chuỗi đường nên có thể làm trong vi khuẩn *E. coli* hoặc nấm men; khi làm trong *E. coli*, người ta phải tạo cầu disulfua và cắt C-peptid **ngoài tế bào** bằng phương pháp hóa học, enzym.

## 6. Điều hòa sinh tổng hợp protein

Tế bào chỉ tổng hợp protein **khi cần, đủ lượng cần**, vì tổng hợp protein rất tốn năng lượng (mục 3.4).

### 6.1. Ở tế bào nhân sơ — mô hình operon

Giáo trình (tr. 197–200) dùng hai ví dụ ở *E. coli*. Cấu trúc operon (gen điều hòa R, vùng khởi động P, gen chỉ huy O, các gen cấu trúc) và các trường hợp điều hòa đã trình bày đầy đủ ở **sh-09 mục 6.1**. Ở đây chỉ hệ thống lại theo đúng cách trình bày của giáo trình Hóa sinh.

**a) Hiện tượng cảm ứng — operon lactose.** Nuôi *E. coli* trong môi trường có glucose, vi khuẩn phát triển bình thường. Thay glucose bằng lactose, lúc đầu vi khuẩn chậm phát triển; sau một thời gian, lượng **β-galactosidase** (thủy phân lactose thành galactose và glucose) **tăng rất cao** và vi khuẩn lại phát triển. **Lactose là chất cảm ứng** tổng hợp enzym.

- Operon lactose có **3 gen cấu trúc**: **Z** mã hóa **β-galactosidase**; **Y** mã hóa **permease** (đưa lactose qua màng); **A** mã hóa **acetylase** (transacetylase, vai trò sinh lý chưa rõ).
- **Không có lactose**: gen R tạo **chất kìm hãm I** ở dạng **hoạt động**, gắn vào gen chỉ huy **O**, ngăn RNA polymerase gắn vào **P** → không phiên mã.
- **Có lactose**: lactose gắn chất kìm hãm I tạo **phức hợp không hoạt động**, mất khả năng gắn O → operon được **"khử kìm hãm"**, RNA polymerase phiên mã cả 3 gen cấu trúc trên một mRNA chung.
- **Điều hòa dương bằng cAMP–CAP**: khi có cả glucose và lactose, vi khuẩn dùng glucose trước. Khi glucose cạn, **cAMP tăng** (tín hiệu "đói"); cAMP gắn **CAP** (catabolite activator protein). Phức hợp **cAMP–CAP** gắn cạnh vùng P, **tăng ái lực** của P với RNA polymerase → phiên mã tăng gấp nhiều lần.

**b) Hiện tượng kìm hãm — operon tryptophan.** Vi khuẩn tự tổng hợp được tryptophan nhờ một chuỗi enzym (E1, E2, E3…). Khi thêm tryptophan vào môi trường, lượng các enzym này **giảm**. **Tryptophan kìm hãm** tổng hợp chính các enzym tạo ra nó.

- **Không có tryptophan**: chất kìm hãm I ở dạng **không hoạt động**, không gắn được O → RNA polymerase phiên mã → tạo enzym tổng hợp tryptophan.
- **Thừa tryptophan**: tryptophan gắn chất kìm hãm tạo **phức hợp hoạt động**, gắn vào O → ngừng phiên mã. Đây là cơ chế **tiết kiệm năng lượng**: sản phẩm cuối đủ thì không làm thêm enzym.

> [!bay] Hai operon "ngược nhau"
> | | Operon lac | Operon trp |
> |---|---|---|
> | Loại hiện tượng | **Cảm ứng** | **Kìm hãm** |
> | Chất kìm hãm do R tạo ra, lúc chưa có phân tử nhỏ | **Hoạt động** → gen tắt | **Không hoạt động** → gen mở |
> | Phân tử nhỏ | Lactose (đúng ra là allolactose) **làm bất hoạt** chất kìm hãm | Tryptophan **hoạt hóa** chất kìm hãm (gọi là **chất đồng kìm hãm**) |
> | Ý nghĩa | Có cơ chất mới làm enzym phân giải | Đủ sản phẩm thì ngừng làm enzym tổng hợp |
>
> - Chú thích hình 12.8 của giáo trình ghi tryptophan tạo "phức hợp chất ức chế – **chất cảm ứng** hoạt động". Đúng ra tryptophan là **chất đồng kìm hãm** (corepressor), không phải chất cảm ứng. Hình đó cũng mượn ký hiệu gen Z, Y, A của operon lac; gen thật của operon trp là trpE, D, C, B, A.
> - Operon điều hòa ở mức **phiên mã** (tạo mRNA), không trực tiếp ở ribosom. Giáo trình xếp vào "điều hòa sinh tổng hợp protein" vì kết quả cuối cùng là lượng **enzym** thay đổi.
> - Jacob và Monod nhận giải Nobel Y học **1965** (cùng Lwoff).

### 6.2. Ở tế bào nhân thật — qua yếu tố mở đầu eIF-2

Giáo trình (tr. 201) nêu hai ví dụ, cùng chung một cơ chế: **phosphoryl hóa yếu tố mở đầu eIF-2** để tắt dịch mã.

![Hình 3. Điều hòa khởi đầu dịch mã qua phosphoryl hóa eIF-2 (hem, interferon)](eif2.svg)

**Cơ chế chung.** eIF-2 (gồm 3 tiểu đơn vị α, β, γ) gắn **GTP** và **Met-tRNA**, đưa Met-tRNA vào tiểu đơn vị 40S. Khi nhận ra AUG, GTP bị thủy phân, eIF-2 rời ra dưới dạng **eIF-2·GDP**. Muốn dùng lại, eIF-2 phải được **eIF-2B** đổi GDP thành GTP. Khi một **kinase** phosphoryl hóa **tiểu đơn vị α** của eIF-2, dạng eIF-2(α-P)·GDP **giữ chặt eIF-2B** thành "phức hợp chặt chẽ" (theo giáo trình). Lượng eIF-2B trong tế bào **ít hơn nhiều** so với eIF-2, nên chỉ cần phosphoryl hóa một phần eIF-2 là đủ "khóa" hết eIF-2B → **ngừng khởi đầu dịch mã**. Phosphatase gỡ nhóm phosphat để khôi phục.

**a) Hem điều hòa tổng hợp chuỗi globin** (ở tế bào tạo hồng cầu). Hồng cầu non phải làm **globin vừa đúng với lượng hem**, vì globin thừa hoặc hem thừa đều gây hại.
- **Đủ hem**: hem gắn vào **HCR** tạo phức hợp **HCR–hem không hoạt động** → eIF-2 không bị phosphoryl hóa → **tổng hợp globin** để tạo Hb.
- **Thiếu hem**: **HCR hoạt động** (là một eIF-2α kinase) → phosphoryl hóa eIF-2 → **ngừng tổng hợp globin**.

**b) Interferon chống virus.** Tế bào bị nhiễm virus tiết **interferon**. Interferon làm hoạt hóa một **protein kinase** phosphoryl hóa eIF-2 → eIF-2 bị khóa với eIF-2B → tế bào **không tổng hợp được protein** (cả protein của virus). Tế bào nhiễm có thể chết, nhưng **virus không nhân lên được**.

> [!cap-nhat] Tên gọi và cơ chế hiện nay
> - **HCR** (heme-controlled repressor) nay gọi là **HRI** (heme-regulated inhibitor), một eIF-2α kinase. Hình 12.9 của giáo trình ghi "tổng hợp **globulin**"; đúng là **globin**.
> - Interferon **không trực tiếp** hoạt hóa kinase. Interferon gây **cảm ứng tổng hợp** kinase **PKR** (ở dạng chưa hoạt động) trong chính tế bào nhiễm và các tế bào xung quanh; PKR chỉ được **hoạt hóa khi gặp RNA mạch kép** của virus. Nhờ vậy tế bào lành không tự tắt dịch mã, chỉ tế bào thực sự nhiễm virus mới tắt.
> - Người có **4 kinase** cùng phosphoryl hóa eIF-2α, ứng với 4 loại "stress": **HRI** (thiếu hem), **PKR** (virus), **PERK** (protein gấp sai ứ đọng trong lưới nội bào), **GCN2** (thiếu acid amin). Tất cả hội tụ vào một đáp ứng chung gọi là **đáp ứng stress tích hợp**.
> - Giáo trình kết luận điều hòa ở tế bào nhân thật "không phải qua tác động ức chế hoặc hoạt hóa gen mà thông qua các yếu tố mở đầu". Hiện nay biết điều hòa ở nhân thật diễn ra ở **nhiều tầng**: chủ yếu ở **phiên mã** (yếu tố phiên mã, enhancer, biểu sinh — xem sh-09 mục 6.2), cùng với hoàn thiện RNA, độ bền mRNA, **dịch mã** (eIF-2 là một ví dụ) và hoạt tính protein. Khi thi, trả lời theo giáo trình; hiểu đây là **ví dụ** điều hòa ở mức dịch mã.

> [!vi-du] Một ví dụ khác ở mức dịch mã: sắt và ferritin
> mRNA của **ferritin** (protein dự trữ sắt) có một vòng kẹp tóc ở đầu 5' gọi là **IRE** (iron-responsive element). Khi **thiếu sắt**, protein IRP gắn vào IRE, chặn tiểu đơn vị 40S → **không dịch mã ferritin** (không cần dự trữ). Khi **đủ sắt**, sắt gắn IRP làm nó rời mRNA → ferritin được tổng hợp để giữ sắt thừa. Tế bào điều chỉnh được lượng protein trong vài phút mà không cần phiên mã lại.

## Tóm tắt

| Chủ đề | Điểm then chốt |
|---|---|
| Yếu tố tham gia | DNA, mRNA (codon), tRNA (đầu CCA gắn aa, đối mã; gần 60 loại), ribosom (70S = 30S + 50S; polysom), enzym (aa-tRNA synthetase, peptidyl transferase), IF1–3, EF-Tu/EF-Ts/EF-G, RF1–3, ATP, GTP, Mg^2+^, NH~4~^+^, K^+^, 20 acid amin |
| Hoạt hóa | aa + ATP → aa-AMP + PP~i~; aa-AMP + tRNA → aa-tRNA + AMP; ester ở 3'-OH (qua 2'-OH hoặc trực tiếp); **2 liên kết giàu năng lượng**; synthetase quyết định độ chính xác |
| Mở đầu (nhân sơ) | 30S + IF3 + mRNA + IF1; fMet-tRNA·IF2·GTP; IF3 rời; GTP thủy phân → 50S gắn → 70S; fMet-tRNA ở **P** |
| Kéo dài | ① EF-Tu·GTP đưa aa-tRNA vào **A**; ② peptidyl transferase (thực chất rRNA) tạo liên kết peptid, chuỗi sang **A**, không tốn GTP; ③ EF-G·GTP chuyển vị A → P, P → E |
| Kết thúc | UAA, UAG, UGA ở A; RF1, RF2, RF3; thủy phân peptidyl-tRNA; 70S tách 30S + 50S |
| Năng lượng | **4 liên kết giàu năng lượng / 1 liên kết peptid** (2 ATP-hoạt hóa + 2 GTP) |
| Nhân thật | 80S (40S + 60S); Met (không formyl); mRNA monocistron, có mũ (CBP), phải hoàn thiện; eIF2, eIF3, eIF4a, eIF4b, eIF5; eEF-2; phiên mã và dịch mã tách biệt |
| Kháng sinh, độc tố | 30S: tetracyclin (chặn A), aminoglycosid (đọc sai). 50S: macrolid (đường hầm), cloramphenicol (peptidyl transferase). Bạch hầu: ADP-ribosyl hóa eEF-2. Ricin: cắt adenin của rRNA 28S |
| Hoàn thiện | Cắt fMet/Met; cắt peptid tín hiệu; phosphoryl hóa Ser/Thr/Tyr; gắn nhóm phụ (hem); cắt tiền chất (proinsulin → insulin + C-peptid); cầu disulfua. Bổ sung: chaperon, glycosyl hóa (N-Asn, O-Ser/Thr), hydroxyl hóa Pro/Lys cần vitamin C (scorbut) |
| Điều hòa | Nhân sơ: operon lac (cảm ứng; cAMP–CAP), operon trp (kìm hãm). Nhân thật: phosphoryl hóa eIF-2α (thiếu hem → HCR/HRI; interferon → PKR) khóa eIF-2B |
