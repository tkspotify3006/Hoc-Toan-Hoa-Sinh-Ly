---
title: Năng lượng sinh học
thoi-gian: 45 phút
muc-tieu:
- Nêu được ba bước thoái hóa glucid, lipid, protein trong cơ thể đến khi thu năng lượng dưới dạng ATP; phân biệt "đốt cháy" trong và ngoài cơ thể.
- Vẽ và trình bày được chuỗi vận chuyển điện tử (chuỗi hô hấp tế bào): thành phần các phức hợp, thứ tự, năng lượng giải phóng.
- Giải thích được cơ chế tạo ATP ở ty thể (thuyết hóa thẩm, ATP synthase), sự điều hòa, các chất ức chế và chất tách cặp.
- Phân biệt được phosphoryl oxy hóa với phosphoryl hóa mức cơ chất; liên kết phosphat giàu và nghèo năng lượng.
- Trình bày được chu trình acid citric: các phản ứng, enzym, năng lượng thu được, đặc điểm, ý nghĩa và điều hòa.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Hô hấp tế bào = đốt chất hữu cơ **từng bước, không ngọn lửa, ở 37 °C**. CO~2~ sinh ra do **khử carboxyl**; H~2~O sinh ra khi **hydro (H^+^ + e^−^) được chuyển tới O~2~**.
> 2. Chuỗi hô hấp trên **màng trong ty thể**: NADH → **I** → **CoQ** → **III** → **cyt c** → **IV** → O~2~. FADH~2~ (succinat) vào ở **phức hợp II** → CoQ.
> 3. Năng lượng của dòng e^−^ dùng để **bơm H^+^** ra khoảng gian màng. H^+^ chảy ngược qua **ATP synthase (F~o~F~1~)** thì tạo ATP: **thuyết hóa thẩm Mitchell**.
> 4. Giáo trình: NADH → **3 ATP**, FADH~2~ → **2 ATP**. Hiện nay: ≈ **2,5** và ≈ **1,5**.
> 5. **Chu trình acid citric** (Krebs) trong chất nền ty thể: mỗi acetyl-CoA cho **2 CO~2~ + 3 NADH + 1 FADH~2~ + 1 GTP** = **12 ATP** theo sách (≈ 10 theo số liệu hiện nay).

Bài này dựa trên hai bài đã học: cấu trúc ty thể (xem bài *Màng tế bào và tế bào chất*, mục 5 — môn Sinh học) và năng lượng tự do, ATP (xem bài *Sự biến đổi năng lượng ở cơ thể sống* — môn Vật lý). Ở đây ta nhìn từ góc độ hóa sinh: **chất nào, enzym nào, bao nhiêu năng lượng, bị chặn ở đâu**.

## 1. Khái quát: cơ thể "đốt" thức ăn như thế nào?

### 1.1. Đốt trong cơ thể khác đốt ngoài cơ thể

Glucid, lipid, protein (giáo trình viết tắt **G, L, P**) là ba nguồn năng lượng của thức ăn. Nếu chỉ xét **đầu vào và đầu ra**, đốt glucose trong lò hay trong tế bào đều giống nhau:

=> C~6~H~12~O~6~ + 6 O~2~ → 6 CO~2~ + 6 H~2~O + năng lượng

Nhưng **cách đốt** thì khác hẳn (Giáo trình tr. 84–85):

| | Ngoài cơ thể (đốt cháy) | Trong cơ thể (hô hấp tế bào) |
|---|---|---|
| Điều kiện | Nhiệt độ cao, có ngọn lửa | 37 °C, môi trường 2/3 là nước |
| Cách O~2~ tác dụng | **Trực tiếp** với C và H của chất hữu cơ | **Không** tiếp xúc trực tiếp; H được tách ra rồi chuyển dần đến O~2~ |
| Tốc độ | Nhanh, một lúc | **Từ từ, từng bước**, mỗi bước có enzym |
| Năng lượng | Tỏa ra hết một lần, chủ yếu thành nhiệt | Giải phóng **dần**, một phần lớn được **tích lại dưới dạng hóa năng (ATP)** |

**Vì sao phải đốt từng bước?** Nếu toàn bộ năng lượng của glucose tỏa ra một lúc, tế bào chỉ nhận được nhiệt và bị tổn thương. Chia nhỏ thành nhiều bậc giúp mỗi bậc giải phóng một lượng vừa đủ để "nạp" vào ATP. ATP sau đó dùng cho co cơ, dẫn truyền thần kinh, hấp thu, bài tiết, tổng hợp chất…

Giáo trình gọi chung quá trình này là **năng lượng sinh học**, **oxy hóa sinh học** hay **hô hấp tế bào**.

### 1.2. Ba bước thoái hóa

| Bước | Diễn ra thế nào | Năng lượng |
|---|---|---|
| **1** | Phân giải đại phân tử thành **đơn vị cấu tạo**: glucid → **glucose** (đường đơn); lipid → **acid béo + glycerol**; protein → **acid amin** (amino acid) | Không đáng kể |
| **2** | Đơn vị cấu tạo → **chất trung gian chung**: **pyruvat**, **acetyl-CoA** | Ít (riêng đường phân tạo một ít ATP) |
| **3** | Chất trung gian → **sản phẩm cuối** CO~2~, H~2~O (và NH~3~ từ acid amin) qua **chu trình acid citric** và **chuỗi hô hấp** | **Phần lớn** năng lượng |

Bước 1 và 2 của mỗi loại chất đi theo con đường riêng (học ở các chương chuyển hóa sau). **Bước 3 thì chung cho cả G, L, P**, nên chương này tập trung vào bước 3 (Giáo trình tr. 85–86).

> [!bay]
> Đường phân (bước 2 của glucid) cũng tạo ATP, nhưng **lượng rất nhỏ** và theo **cơ chế khác hẳn** (phosphoryl hóa mức cơ chất, mục 2.6). Phần lớn ATP được tạo ở bước 3 nhờ **phosphoryl oxy hóa**.

## 2. Bản chất của hô hấp tế bào

Tế bào dùng O~2~ và thải ra CO~2~, H~2~O ngay trong tế bào. Vì vậy quá trình này gọi là **hô hấp tế bào**, để phân biệt với hô hấp ở phổi (Giáo trình tr. 86).

### 2.1. CO~2~ và H~2~O được tạo ra như thế nào?

- **CO~2~** sinh ra do **phản ứng khử carboxyl** (tách nhóm –COOH), enzym là **decarboxylase**. Phản ứng này **giải phóng rất ít năng lượng**.

=> R–COOH → R–H + CO~2~

- **H~2~O** sinh ra qua một dây chuyền dài: **tách hydro** khỏi cơ chất (nhờ dehydrogenase, gắn lên NAD^+^ hoặc FAD), rồi **chuyển hydro qua nhiều chất trung gian** cho tới O~2~. Trên đường đi, hydro tách thành H^+^ và e^−^; oxy nhận e^−^ thành O^2−^. Hai loại ion này rất hoạt động, gặp nhau tạo H~2~O.
- **Năng lượng chủ yếu** được giải phóng ở giai đoạn chuyển hydro (điện tử) tới O~2~, không phải ở giai đoạn tạo CO~2~.

> [!bay]
> **O~2~ ta hít vào không đi vào CO~2~ ta thở ra.** CO~2~ đến từ carbon của chất hữu cơ (khử carboxyl), còn O~2~ chỉ là **chất nhận điện tử cuối cùng** và trở thành H~2~O.

### 2.2. Chuỗi vận chuyển điện tử (chuỗi hô hấp tế bào)

Chuỗi gồm **4 phức hợp protein** (I, II, III, IV) nằm trong màng trong ty thể và **2 chất vận chuyển di động**: **coenzym Q** (ubiquinon) và **cytochrom c** (Giáo trình tr. 86–90).

![Hình 1. Chuỗi hô hấp và ATP synthase trên màng trong ty thể. Mũi tên cam: đường đi của điện tử; số H⁺ bơm ra cho mỗi cặp điện tử theo giáo trình](chuoi-ho-hap.svg)

| Thành phần | Tên enzym | Nhóm vận chuyển e^−^ bên trong | Phản ứng tóm tắt |
|---|---|---|---|
| **Phức hợp I** | NADH-CoQ reductase (NADH dehydrogenase) | **FMN** (từ vitamin B~2~) → trung tâm **Fe-S** | NADH + H^+^ + CoQ → NAD^+^ + CoQH~2~ |
| **Phức hợp II** | Succinat-CoQ reductase (= **succinat dehydrogenase** của chu trình Krebs) | **FAD** → **Fe-S** | Succinat + CoQ → Fumarat + CoQH~2~ |
| **CoQ** (ubiquinon) | — | Quinon, nhận 2 H (2 e^−^ + 2 H^+^) | Q ⇌ QH^•^ (semiquinon) ⇌ QH~2~ |
| **Phức hợp III** | CoQH~2~-cytochrom c reductase | **cyt b** → **Fe-S** → **cyt c~1~** | CoQH~2~ + 2 cyt c (Fe^3+^) → CoQ + 2 H^+^ + 2 cyt c (Fe^2+^) |
| **Cytochrom c** | — | Hem (Fe^3+^ ⇌ Fe^2+^) | Mang 1 e^−^ mỗi lần |
| **Phức hợp IV** | **Cytochrom oxidase** | **cyt a** (Cu) → **cyt a~3~** (Cu) | 2 cyt c (Fe^2+^) + ½ O~2~ + 2 H^+^ → 2 cyt c (Fe^3+^) + H~2~O |

Cơ chế chuyển điện tử của từng nhóm:

- **NAD^+^** nhận hydro ở **vòng nicotinamid** (vitamin PP/B~3~): nhận 1 ion hydrid (H^−^ = H^+^ + 2 e^−^), giải phóng 1 H^+^ ra môi trường. Vì vậy viết là NADH + H^+^.
- **FMN, FAD** nhận hydro ở **vòng flavin** (vitamin B~2~).
- **Trung tâm sắt–lưu huỳnh (Fe-S)**: các nguyên tử Fe gắn với S vô cơ và S của cystein. Giáo trình mô tả hai dạng là 2Fe-2S và 4Fe-4S. Chúng chuyển e^−^ nhờ **đổi hóa trị của sắt** (Fe^3+^ ⇌ Fe^2+^).
- **CoQ (ubiquinon)**: phân tử nhỏ, **tan trong lipid**, có đuôi dài gồm 10 đơn vị isopren (nên gọi là CoQ~10~). Nhờ vậy nó **khuếch tán tự do trong màng trong**, là điểm hội tụ: nhận e^−^ từ cả phức hợp I và II rồi chuyển cho phức hợp III. CoQ nhận từng e^−^ một: quinon (Q) → semiquinon (QH^•^) → hydroquinon (QH~2~).
- **Cytochrom** là protein có nhóm ngoại **hem** (giống hem của hemoglobin, myoglobin). Sắt ở tâm hem chuyển e^−^ bằng phản ứng **Fe^3+^ + e^−^ ⇌ Fe^2+^**. Cytochrom c là protein nhỏ, tan trong nước, **di động ở mặt ngoài màng trong** (phía khoảng gian màng).
- **Cytochrom oxidase (IV)** chứa hem và **đồng** (Cu). Đây là nơi duy nhất trong chuỗi phản ứng trực tiếp với O~2~. O~2~ là **chất nhận điện tử cuối cùng**.

> [!bay]
> - **Phức hợp II là enzym của chu trình Krebs** (succinat dehydrogenase) và là enzym duy nhất của chu trình **gắn vào màng trong**. Mọi enzym khác của chu trình nằm trong chất nền.
> - Điện tử từ FADH~2~ (succinat) **bỏ qua phức hợp I**, vào chuỗi ở mức CoQ. Phức hợp II **không bơm H^+^**. Đó là lý do FADH~2~ cho ít ATP hơn NADH.
> - Hai chất vận chuyển **di động** là **CoQ** (trong lòng màng, tan trong lipid) và **cytochrom c** (ngoài màng, tan trong nước). Bốn phức hợp còn lại cố định trong màng.

### 2.3. Thứ tự sắp xếp và năng lượng giải phóng

**Quy luật sắp xếp:** điện tử luôn đi **từ chất có thế oxy hóa–khử (E°') thấp đến chất có E°' cao hơn**. Giống như nước chảy từ cao xuống thấp, "độ chênh" càng lớn thì càng nhiều năng lượng (Giáo trình tr. 89).

Năng lượng tự do giải phóng khi chuyển n điện tử qua độ chênh ΔE°':

=> ΔG°' = − n · F · ΔE°'

Với n là số e^−^, F là hằng số Faraday = 23,062 kcal/(V·mol), ΔE°' là chênh lệch thế giữa chất nhận và chất cho e^−^ (điều kiện chuẩn: pH 7, 25 °C).

Tính cho một cặp e^−^ đi từ NADH (E°' = −0,32 V) đến O~2~ (E°' = +0,82 V):

=> ΔG°' = −2 × 23,062 × [0,82 − (−0,32)] = **−52,6 kcal/mol**

Năng lượng này **không** tỏa ra một lần mà được giải phóng **dần qua từng chặng**. Một phần đủ để tổng hợp vài ATP (mỗi ATP cần **+7,3 kcal/mol**), phần còn lại tỏa thành **nhiệt**.

> [!vi-du] Hiệu suất của chuỗi hô hấp
> - Theo giáo trình: 3 ATP × 7,3 = 21,9 kcal trên 52,6 kcal, tức hiệu suất khoảng **42%** ở điều kiện chuẩn. Phần còn lại thành **nhiệt sơ cấp** giữ thân nhiệt (xem bài *Sự biến đổi năng lượng ở cơ thể sống*, mục nhiệt sơ cấp – thứ cấp).
> - Ở mỗi dòng của bảng trên, chất đứng sau luôn có E°' cao hơn chất đứng trước. Đó là lý do thứ tự NADH → FMN → Fe-S → CoQ → cyt b → cyt c~1~ → cyt c → cyt a → cyt a~3~ → O~2~ không thể đảo ngược.

### 2.4. Cơ chế tạo ATP ở ty thể

#### a) Nhắc lại cấu tạo ty thể

Ty thể có **hai màng** (chi tiết: bài *Màng tế bào và tế bào chất*, mục 5):

- **Màng ngoài**: cho các phân tử nhỏ và ion đi qua **tự do** (nhờ kênh porin).
- **Màng trong**: **không cho ion qua, kể cả H^+^**. Chứa các phức hợp của chuỗi hô hấp, hệ vận chuyển qua màng và **ATP synthase**.

Chính tính **không thấm H^+^** của màng trong là điều kiện để tạo ATP. Nếu màng bị "thủng" cho H^+^, năng lượng sẽ mất thành nhiệt (mục 2.6).

#### b) ATP synthase (F~o~F~1~)

ATP synthase gồm hai phần (Giáo trình tr. 91):

| Phần | Vị trí | Thành phần (theo giáo trình) | Chức năng |
|---|---|---|---|
| **F~o~** | Cắm **trong màng trong** | Các tiểu đơn vị a, b, c | Tạo **kênh cho H^+^ đi qua** |
| **F~1~** | **Nhô vào chất nền** (núm hình cầu) | **3 α + 3 β**, nối với F~o~ qua γ, δ, ε | **Tổng hợp ATP** (trung tâm hoạt động ở **β**) |

#### c) Thuyết hóa thẩm (thuyết thẩm thấu hóa học) của Mitchell

Do **Peter Mitchell** đề xuất năm 1961 (giải Nobel Hóa học 1978). Ý chính (Giáo trình tr. 91–93):

1. Năng lượng của dòng e^−^ trong chuỗi được dùng để **bơm H^+^** từ chất nền ra **khoảng gian màng**.
2. Màng trong không thấm H^+^, nên tạo ra **chênh lệch nồng độ H^+^** (chênh lệch pH; bên trong kiềm hơn) và **chênh lệch điện thế** (bên trong âm hơn).
3. Hai chênh lệch này hợp thành **lực đẩy proton** (proton-motive force, pmf), đẩy H^+^ quay trở lại chất nền:

=> pmf = Δψ − 59·ΔpH (mV, ở khoảng 25 °C)

Δψ là điện thế qua màng. Hệ số 59 mV là điện thế tương ứng với chênh lệch 1 đơn vị pH (gấp 10 lần nồng độ H^+^). Theo giáo trình, pmf ở ty thể lúc nghỉ khoảng **220 mV**.

4. Con đường duy nhất để H^+^ quay về là **kênh F~o~ của ATP synthase**. Dòng H^+^ này cung cấp năng lượng cho F~1~ gắn P~i~ vào ADP thành ATP.

> [!ghi-nho] Hình ảnh dễ nhớ: đập thủy điện
> Chuỗi hô hấp là **máy bơm** đưa nước (H^+^) lên hồ cao (khoảng gian màng). ATP synthase là **tua-bin**: nước chảy xuống qua tua-bin thì phát ra điện (ATP). Bơm và tua-bin **không nối trực tiếp** với nhau, mà nối qua **"hồ nước" H^+^**.

**Cơ chế quay (thay đổi gắn kết).** Ba tiểu đơn vị β lần lượt ở **ba cấu hình** khác nhau về ái lực với ADP, P~i~ và ATP:

1. Một β gắn **ADP + P~i~**.
2. Ở β đó, ADP + P~i~ kết hợp thành **ATP**.
3. Dòng H^+^ làm bộ phận quay **xoay 120°**, cấu hình cả ba β thay đổi, β đang giữ ATP **mở ra và nhả ATP**.

Chu trình lặp lại liên tục cho tới khi hết chênh lệch H^+^ hai bên màng (Giáo trình tr. 92). Điểm then chốt: năng lượng của dòng H^+^ được dùng chủ yếu để **giải phóng ATP** đã gắn chặt ở β, không phải để tạo liên kết.

> [!cap-nhat] Phần nào quay?
> Giáo trình mô tả "các phần α~3~β~3~ của F~1~ quay 120°". Hiện nay đã chứng minh trực tiếp (Boyer và Walker, Nobel Hóa học 1997): **vòng c của F~o~ cùng trục γ (và ε) mới là phần quay (rotor)**. Khối α~3~β~3~ được "cánh tay" b và δ giữ **đứng yên** (stator). Trục γ lệch tâm quay bên trong α~3~β~3~, lần lượt ép từng β đổi cấu hình. Ý chính của sách (mỗi lần quay 120° thì một β nhả ATP) vẫn đúng.

#### d) Bao nhiêu H^+^, bao nhiêu ATP?

Theo giáo trình (tr. 92–93), với mỗi cặp e^−^:

| Đoạn chuỗi | Số H^+^ bơm ra |
|---|---|
| Phức hợp **I** (NADH-CoQ reductase) | **4 H^+^** |
| Phức hợp **III** (CoQH~2~-cyt c reductase) | **4 H^+^** |
| Phức hợp **IV** (cytochrom oxidase) | **2 H^+^** |
| **Tổng từ NADH** | **10 H^+^** |
| **Tổng từ succinat/FADH~2~** (bỏ qua I) | **6 H^+^** |

Giáo trình cho rằng **3 H^+^** qua F~o~F~1~ tạo **1 ATP**. Từ đó:

- NADH → O~2~: **3 ATP** (3 vị trí "phát" ATP: I, III, IV).
- Succinat (FADH~2~) → O~2~: **2 ATP**.
- Từ cyt c → O~2~ (chỉ qua IV): **1 ATP**.

Tỉ số **P/O** = số phân tử P~i~ gắn vào ADP (số ATP tạo ra) cho mỗi nguyên tử O (½ O~2~) bị khử, tức cho mỗi cặp e^−^. Theo giáo trình: P/O của NADH = 3, của FADH~2~ = 2.

> [!cap-nhat] Tỉ số P/O và số ATP — "giáo trình ghi / hiện nay"
> - Số H^+^ bơm ra (10 với NADH, 6 với FADH~2~) giống giáo trình.
> - Nhưng để tạo **1 ATP** và đưa được nó ra bào tương cần **khoảng 4 H^+^**, không phải 3: khoảng 2,7 H^+^ cho ATP synthase (vòng c của người có 8 tiểu đơn vị: 8 H^+^ quay đủ một vòng, tạo 3 ATP) và thêm **1 H^+^** để vận chuyển P~i~ vào, đổi ATP ra (chất trao đổi ADP/ATP).
> - Vì vậy hiện nay: **P/O ≈ 2,5 với NADH, ≈ 1,5 với FADH~2~/succinat**. Số liệu không phải số nguyên vì bơm H^+^ và tạo ATP **không gắn cứng** với nhau, mà nối qua lực đẩy proton.
> - Hệ quả: mỗi vòng Krebs ≈ **10 ATP** (sách: 12); mỗi glucose oxy hóa hoàn toàn ≈ **30–32 ATP** (tài liệu cũ dùng P/O = 3 và 2 thì tính ra 36–38 ATP).
> - **Đi thi: trả lời theo giáo trình** (3 và 2; 12 ATP/vòng Krebs) trừ khi đề hỏi số liệu hiện nay.

Năng lượng của dòng e^−^ còn được tế bào dùng cho việc khác ngoài tạo ATP: **sinh nhiệt**, **vận chuyển Ca^2+^** vào ty thể… (Giáo trình tr. 93).

### 2.5. Điều hòa tổng hợp ATP: ADP là "công tắc"

Ty thể **chỉ sản xuất ATP theo nhu cầu**, và tín hiệu nhu cầu chính là **nồng độ ADP** (Giáo trình tr. 93–94):

- **ADP thấp** (tế bào nghỉ, ATP đầy đủ) → ATP synthase thiếu nguyên liệu, H^+^ không chảy về được, chênh lệch H^+^ tăng cao, "cản" việc bơm thêm → chuỗi hô hấp **chậm lại**, **giảm tiêu thụ O~2~**.
- **ADP tăng đột ngột** (ví dụ co cơ mạnh, nhanh làm thủy phân nhiều ATP) → H^+^ chảy qua ATP synthase, chênh lệch giảm → chuỗi **chạy nhanh**, **tăng tiêu thụ O~2~**, tạo ATP bù lại.

Thí nghiệm trên tế bào nuôi cấy: thêm ADP vào môi trường thì mức tiêu thụ O~2~ tăng vọt ngay (Hình 6.10 của giáo trình). Hiện tượng này gọi là **kiểm soát hô hấp** (respiratory control). Nhờ đó, **vận chuyển e^−^ và tạo ATP luôn đi kèm nhau** ở ty thể bình thường.

> [!ung-dung] Vì sao gắng sức thì thở nhanh?
> Co cơ tiêu ATP → ADP tăng → ty thể cơ tăng tốc chuỗi hô hấp → cần nhiều O~2~ và thải nhiều CO~2~ hơn → trung tâm hô hấp tăng nhịp thở. Khi O~2~ không đáp ứng kịp, cơ chuyển sang đường phân yếm khí, tạo **acid lactic**.

### 2.6. Chất ức chế chuỗi hô hấp và chất tách cặp

Hai nhóm chất này tác động **khác nhau về bản chất** (Giáo trình tr. 94):

- **Chất ức chế** chặn dòng e^−^ tại một điểm. Phía trước bị "ứ" ở dạng khử, phía sau ở dạng oxy hóa. Hậu quả: **ngừng tiêu thụ O~2~ và ngừng tạo ATP**.
- **Chất tách cặp** (phá ghép) **không chặn dòng e^−^**. Chúng tạo một "đường tắt" cho H^+^ về chất nền **không qua ATP synthase**. Hậu quả: oxy hóa (tiêu thụ O~2~) vẫn chạy, thậm chí **nhanh hơn**, nhưng **không tạo ATP**; năng lượng tỏa thành **nhiệt**.

| Chất | Tác động tại | Loại | Ghi chú |
|---|---|---|---|
| **Rotenon** | Giữa NADH và CoQ (**phức hợp I**) | Ức chế | Thuốc diệt côn trùng, thuốc cá có nguồn gốc thực vật. Succinat vẫn oxy hóa được (vào ở II) |
| **Antimycin A** | Giữa CoQ và cyt c (**phức hợp III**) | Ức chế | Kháng sinh phân lập từ *Streptomyces* |
| **CN^−^ (cyanid), CO, H~2~S (HS^−^)** | **Cytochrom oxidase** (cyt a, a~3~), chặn bước khử O~2~ | Ức chế | Chặn ở cuối chuỗi nên **cả NADH lẫn FADH~2~ đều tắc** |
| **Oligomycin** *(bổ sung)* | Kênh **F~o~** của ATP synthase | Ức chế ATP synthase | Chặn H^+^ về → ATP ngừng tạo, chuỗi cũng dừng theo (do kiểm soát hô hấp) |
| **Malonat** *(bổ sung)* | **Succinat dehydrogenase** (II) | Ức chế cạnh tranh | Giống succinat về cấu trúc (xem bài *Enzym*) |
| **2,4-dinitrophenol (DNP)** | Màng trong | **Tách cặp** | Acid yếu tan trong lipid, mang H^+^ xuyên màng |
| **Thermogenin (UCP1)** | Màng trong ty thể **mỡ nâu** | **Tách cặp nội sinh** | Kênh cho H^+^ về chất nền → sinh nhiệt |

> [!bay]
> - **Thứ tự chặn từ đầu đến cuối chuỗi: Rotenon (I) → Antimycin A (III) → Cyanid/CO (IV).** Câu hỏi ôn tập của giáo trình hỏi đúng vị trí của antimycin A và CN^−^.
> - **Chất tách cặp làm TĂNG tiêu thụ O~2~** (không như chất ức chế). Đây là điểm phân biệt hay ra thi.
> - **Oligomycin** chặn ATP synthase, nhưng tiêu thụ O~2~ cũng giảm theo. Lý do: H^+^ không về được, chênh lệch H^+^ lên quá cao, các bơm dừng. Nếu cho thêm DNP thì O~2~ lại được tiêu thụ (vẫn không tạo ATP).
> - Giáo trình in "CO^−^". CO (carbon monoxid) là **phân tử trung hòa**, không mang điện.

**Mỡ nâu và thermogenin** (Giáo trình tr. 94):

- **Mỡ nâu** là mỡ **sinh nhiệt**, còn **mỡ trắng** là mỡ **dự trữ**. Mỡ nâu có màu nâu vì chứa **rất nhiều ty thể** (giàu cytochrom chứa sắt).
- Màng trong ty thể mỡ nâu có **thermogenin** (khối lượng phân tử khoảng 33.000 Da). Đây là chất tách cặp **tự nhiên**: biến năng lượng của dòng e^−^ thành **nhiệt** thay vì ATP, giúp giữ thân nhiệt.
- Chuột đưa vào môi trường lạnh sẽ tăng tổng hợp thermogenin. Ở động vật xứ lạnh, thermogenin chiếm tới **15%** protein màng trong ty thể.
- **Trẻ sơ sinh** có nhiều mỡ nâu (gáy, quanh vai, quanh thận). Chúng rất cần thermogenin để giữ nhiệt, vì trung tâm điều hòa thân nhiệt và khả năng run để sinh nhiệt còn chưa hoàn chỉnh. **Người lớn ít mỡ nâu.**

> [!cap-nhat] Mỡ nâu ở người lớn
> - Giáo trình ghi người lớn ít mỡ nâu. Từ năm 2009, chụp PET/CT cho thấy nhiều người trưởng thành vẫn có **mỡ nâu hoạt động** ở vùng cổ, trên xương đòn, cạnh cột sống. Mỡ này được kích hoạt khi lạnh, và lượng mỡ nâu ở người béo phì thường ít hơn.
> - Thermogenin nay gọi là **UCP1** (uncoupling protein 1). Nó **đặc trưng cho mỡ nâu** (và mỡ "be" trong mô mỡ trắng). Cơ vân có protein họ hàng là **UCP3**, nhưng vai trò sinh nhiệt của UCP3 chưa rõ. Câu "ty thể tế bào cơ cũng chứa thermogenin" của giáo trình vì thế chưa chính xác.

> [!ung-dung] Ngộ độc cyanid, CO và "thuốc giảm cân" DNP
> - **Cyanid** (HCN, muối cyanid, glycosid sinh cyanid trong sắn, nhân hạt mơ, đào; khói cháy nhà) gắn Fe^3+^ của cytochrom a~3~ → tế bào **không dùng được O~2~** dù máu vẫn đủ O~2~. Máu tĩnh mạch đỏ tươi, **lactat máu tăng cao** (toan chuyển hóa). Thuốc giải đặc hiệu: **hydroxocobalamin** (gắn CN^−^ thành cyanocobalamin), **natri thiosulfat** (giúp enzym rhodanese chuyển CN^−^ thành thiocyanat ít độc), nitrit (tạo methemoglobin "hút" CN^−^ khỏi cytochrom). Xem thêm glycosid sinh cyanid ở bài *Glucid* (khung YHCT).
> - **CO** (khí than, bếp than tổ ong trong phòng kín, khí thải xe): tác hại **chủ yếu** là gắn hemoglobin mạnh gấp khoảng 200–250 lần O~2~ (tạo **HbCO**), làm máu mất khả năng chở O~2~. Ngoài ra CO còn ức chế cytochrom oxidase. Xét nghiệm **HbCO** trong máu: người không hút thuốc thường **< 3%** (tham khảo, mỗi phòng xét nghiệm có khoảng riêng). Điều trị bằng **thở O~2~ nồng độ cao** hoặc oxy cao áp.
> - **DNP** từng được bán làm thuốc giảm cân ở thập niên 1930 (đốt mỡ thành nhiệt). Nó bị cấm vì gây **tăng thân nhiệt ác tính và tử vong**, nhưng đến nay vẫn còn bán trái phép qua mạng.
> - **Lactat máu** (tham khảo): khoảng **0,5–2,2 mmol/L**, mỗi phòng xét nghiệm có khoảng riêng. Lactat tăng khi ty thể không dùng được O~2~ (thiếu O~2~, sốc, ngộ độc cyanid, bệnh ty thể).

> [!yhct] Chất ức chế chuỗi hô hấp có nguồn gốc cây cỏ
> - **Rotenon** có trong rễ cây **Dây mật** (dây thuốc cá, *Derris elliptica*), loại cây dân gian dùng để **duốc cá** và trừ sâu. Cơ chế đã chứng minh: ức chế **phức hợp I**. Cá rất nhạy vì rotenon hấp thu nhanh qua mang. Trên **động vật thí nghiệm**, phơi nhiễm rotenon kéo dài gây tổn thương nơron dopamin giống **bệnh Parkinson**, và đã trở thành mô hình nghiên cứu bệnh này. Không dùng làm thuốc uống.
> - **Berberin** (hoạt chất của **Hoàng liên**, **Hoàng bá**, **Vàng đắng**): nghiên cứu **in vitro và trên động vật** cho thấy berberin **ức chế nhẹ phức hợp I**. Tỉ lệ ATP/AMP giảm sẽ hoạt hóa **AMPK** và cải thiện chuyển hóa glucose. Đây là một giả thuyết cơ chế cho tác dụng hạ đường huyết của berberin; tác dụng này mới có thử nghiệm lâm sàng nhỏ. Quan niệm YHCT về Hoàng liên (thanh nhiệt, táo thấp) là một hệ thống giải thích khác, không đồng nhất với cơ chế này.

### 2.7. Tạo ATP ở mức cơ chất

Tế bào có **hai cơ chế tạo ATP khác hẳn nhau** (Giáo trình tr. 94):

| | **Phosphoryl oxy hóa** | **Phosphoryl hóa mức cơ chất** |
|---|---|---|
| Ở đâu | **Màng trong ty thể** | Giáo trình nêu ở **bào tương** (đường phân) |
| Cần gì | Chuỗi hô hấp, **gradient H^+^**, ATP synthase, **O~2~** | Một **cơ chất có liên kết giàu năng lượng** chuyển thẳng P cho ADP |
| Lượng ATP | **Phần lớn** | Ít |
| Bị cyanid, DNP ảnh hưởng | Có | Không trực tiếp |

Hai phản ứng mức cơ chất trong đường phân mà giáo trình nêu:

=> 1,3-diphosphoglycerat + ADP → 3-phosphoglycerat + ATP

=> Phosphoenolpyruvat + ADP → Pyruvat + ATP

> [!bay]
> Chu trình Krebs **cũng có một bước phosphoryl hóa mức cơ chất**, xảy ra **trong chất nền ty thể**: succinyl-CoA → succinat, tạo **GTP** (phản ứng 5, mục 4.2). Vậy câu "phosphoryl hóa mức cơ chất chỉ xảy ra ở bào tương" là **sai** nếu đề hỏi tổng quát. Điểm cốt lõi để nhận biết loại này: **không cần màng và gradient H^+^**.

## 3. Phosphoryl hóa và phosphoryl oxy hóa

### 3.1. Phosphoryl hóa là gì?

**Phosphoryl hóa** là gắn một gốc phosphat vào một chất hữu cơ (Giáo trình tr. 95):

=> R–H + HO–PO~3~H~2~ → R–PO~3~H~2~ + H~2~O

- Đây là phản ứng **tổng hợp**, nên **cần năng lượng** và cần enzym (giáo trình gọi chung là **phosphoryl kinase**; thường gọi là **kinase**).
- Phản ứng ngược lại (thủy phân, **khử phosphoryl**) **giải phóng đúng lượng năng lượng** đã dùng để tạo liên kết.

=> R–PO~3~H~2~ + H~2~O → R–H + H~3~PO~4~

Phosphoryl hóa là một trong những phản ứng **quan trọng bậc nhất** của chuyển hóa: nó **tích trữ, vận chuyển năng lượng** và **hoạt hóa** các chất (ví dụ glucose phải thành glucose-6-phosphat mới chuyển hóa tiếp được).

### 3.2. Liên kết phosphat nghèo và giàu năng lượng

Chia theo năng lượng giải phóng khi **thủy phân** liên kết phosphat (Giáo trình tr. 95–96):

| Loại | Năng lượng thủy phân | Ký hiệu | Ví dụ |
|---|---|---|---|
| **Nghèo năng lượng** | Chỉ **1.000–5.000 cal/mol** | R–Ⓟ (gạch thẳng) | **Ester phosphat**: glycerol-3-phosphat, glucose-6-phosphat |
| **Giàu năng lượng** | **> 7.000 cal/mol** | R∼Ⓟ (gạch sóng) | Bốn loại dưới đây |

Bốn loại liên kết phosphat giàu năng lượng:

| Loại | Tạo thành do H~3~PO~4~ kết hợp với… | Ví dụ (giáo trình) | ΔG thủy phân |
|---|---|---|---|
| **Acylphosphat** | Nhóm **acid** (–COOH) | Acid **1,3-diphosphoglyceric** (liên kết ở C1) | **−10,1 kcal/mol** |
| **Enolphosphat** | Nhóm **enol** | **Phosphoenolpyruvat** (PEP) | **−14,8 kcal/mol** (cao nhất) |
| **Amidphosphat** (phosphamid) | Nhóm **amin** | **Phosphocreatin** | **−10,3 kcal/mol** |
| **Anhydrid phosphat** (pyrophosphat) | Một **gốc phosphat khác** | **ATP** (hai liên kết ngoài cùng) | **−7,3 kcal/mol** |

> [!bay]
> - ATP **không** có liên kết giàu năng lượng nhất. PEP, 1,3-diphosphoglycerat, phosphocreatin đều "giàu" hơn ATP. Nhờ vậy chúng **chuyển được P cho ADP** để tạo ATP (mục 2.7). ATP đứng **giữa** thang năng lượng, nên vừa nhận được P từ chất "giàu" hơn, vừa cho được P cho chất "nghèo" hơn (như glucose). Đây là lý do ATP là "đồng tiền năng lượng".
> - Trong ATP chỉ có **2 liên kết giàu năng lượng** (giữa Pα–Pβ và Pβ–Pγ). Liên kết ribose–Pα là ester phosphat, **nghèo** năng lượng.
> - Giáo trình in "phosphocreatinin". Tên đúng là **phosphocreatin** (creatin phosphat). **Creatinin** là sản phẩm thải của nó, dùng làm xét nghiệm chức năng thận.
> - Số liệu ΔG ở các sách lệch nhau chút ít (ví dụ có sách ghi 1,3-diphosphoglycerat −11,8 kcal/mol). Đi thi dùng số của giáo trình.

> [!ung-dung] Phosphocreatin — "ắc quy dự phòng" của cơ
> Cơ dự trữ phosphocreatin để **tái tạo ATP tức thì** trong vài giây đầu gắng sức (enzym creatin kinase, CK). Khi tế bào cơ hoặc cơ tim bị tổn thương, CK thoát vào máu. Vì vậy **CK, CK-MB** từng là xét nghiệm của nhồi máu cơ tim và tổn thương cơ (nay chủ yếu dùng troponin cho tim). Creatin còn được dùng làm thực phẩm bổ sung cho vận động viên.

### 3.3. Phosphoryl oxy hóa

- Trong chuỗi hô hấp, e^−^ đi từ chất có thế oxy hóa–khử thấp đến cao: đó là các **phản ứng oxy hóa–khử**.
- Năng lượng giải phóng được dùng để **phosphoryl hóa ADP** thành ATP:

=> ADP + H~3~PO~4~ → ATP + H~2~O

- Hai quá trình này **luôn đi kèm nhau (gắn liền)** ở ty thể bình thường. Vì thế giáo trình ghép tên thành **phosphoryl oxy hóa** (oxidative phosphorylation) (Giáo trình tr. 96).

Nói gọn: **oxy hóa** (chuỗi hô hấp) cung cấp năng lượng, **phosphoryl hóa** (ATP synthase) tích năng lượng. "Khớp nối" giữa hai bên là **gradient H^+^**. Chất tách cặp chính là chất làm hỏng khớp nối này.

## 4. Chu trình acid citric (chu trình Krebs)

### 4.1. Khái quát và sự tạo acetyl-CoA từ pyruvat

Chu trình acid citric là **giai đoạn thoái hóa cuối cùng, chung** cho glucid, lipid và protein. Chất "nhiên liệu" đi vào chu trình là **acetyl-CoA** (2C). Glucid (và nhiều acid amin) thoái hóa chủ yếu thành **pyruvat**, nên trước hết pyruvat phải được chuyển thành acetyl-CoA (Giáo trình tr. 97).

Phản ứng **khử carboxyl oxy hóa** pyruvat xảy ra **trong ty thể**. Nó là **cầu nối** giữa đường phân (bào tương) và chu trình acid citric (ty thể):

=> Pyruvat + CoA-SH + NAD^+^ → Acetyl-CoA + CO~2~ + NADH + H^+^

Enzym là **phức hợp pyruvat dehydrogenase** (PDH), gồm 3 enzym:

| Enzym | Coenzym (theo giáo trình) | Việc làm |
|---|---|---|
| **E1**: pyruvat dehydrogenase | **TPP** (thiamin pyrophosphat, từ **vitamin B~1~**) | Khử carboxyl pyruvat → nhóm hydroxyethyl gắn TPP; giải phóng CO~2~ |
| **E2**: dihydrolipoyl transacetylase | **Lipoamid** (acid lipoic) | Chuyển nhóm acetyl sang **CoA** → acetyl-CoA |
| **E3**: dihydrolipoyl dehydrogenase | **FAD** | Tái oxy hóa lipoamid; e^−^ đi qua FAD sang **NAD^+^** → NADH |

> [!ghi-nho] 5 coenzym của phức hợp PDH — 5 vitamin
> **TPP** (B~1~), **acid lipoic**, **CoA** (acid pantothenic, B~5~), **FAD** (B~2~), **NAD^+^** (B~3~/PP). Phức hợp **α-cetoglutarat dehydrogenase** ở bước 4 của chu trình dùng **đúng bộ coenzym này**.

> [!ung-dung] Thiếu vitamin B~1~: beriberi và bệnh não Wernicke
> - Thiếu B~1~ → thiếu TPP → **E1 hoạt động kém** → **ứ đọng pyruvat** (và lactat) trong máu. Mô thần kinh sống gần như hoàn toàn bằng glucose nên bị ảnh hưởng nặng nhất: **viêm, thoái hóa thần kinh**, yếu cơ, liệt (**beriberi**, Giáo trình tr. 97). Beriberi ướt gây thêm suy tim.
> - Thực tế lâm sàng: người **nghiện rượu**, suy dinh dưỡng, nôn kéo dài dễ thiếu B~1~, gây **bệnh não Wernicke** (lú lẫn, rung giật nhãn cầu, đi loạng choạng). Nguyên tắc: **tiêm thiamin trước hoặc cùng lúc truyền glucose**. Nếu truyền glucose trước, lượng TPP ít ỏi còn lại bị tiêu hết, bệnh nặng thêm.
> - **Arsenit** (thạch tín) gắn hai nhóm –SH của lipoamid, làm tê liệt PDH và α-cetoglutarat dehydrogenase.

> [!bay]
> Phản ứng pyruvat → acetyl-CoA **không thuận nghịch**. Vì vậy cơ thể người **không biến acetyl-CoA (từ acid béo) thành glucose được**. Lipid có thể tạo từ glucid, nhưng acid béo không tạo ngược lại glucose (chỉ phần glycerol làm được). Điều này sẽ gặp lại ở bài chuyển hóa glucid và lipid.

### 4.2. Tám phản ứng của chu trình

![Hình 2. Chu trình acid citric: 8 phản ứng, enzym và sản phẩm. Số màu cam: 3 enzym điều hòa chính](chu-trinh-krebs.svg)

| Bước | Phản ứng | Enzym | Loại phản ứng | Sản phẩm năng lượng |
|---|---|---|---|---|
| **1** | Acetyl-CoA (2C) + **oxaloacetat** (4C) + H~2~O → **citrat** (6C) + CoA-SH | **Citrat synthase** | Ngưng tụ | — |
| **2** | Citrat → (cis-aconitat) → **isocitrat** | **Aconitase** | Đồng phân hóa (loại nước 2a rồi gắn nước 2b) | — |
| **3** | Isocitrat → (oxalosuccinat) → **α-cetoglutarat** (5C) | **Isocitrat dehydrogenase** (coenzym NAD^+^) | Khử carboxyl oxy hóa | **NADH**, **CO~2~** |
| **4** | α-cetoglutarat + CoA-SH → **succinyl-CoA** (4C) | **Phức hợp α-cetoglutarat dehydrogenase** (3 enzym) | Khử carboxyl oxy hóa (giống PDH) | **NADH**, **CO~2~** |
| **5** | Succinyl-CoA + GDP + P~i~ → **succinat** + GTP + CoA-SH | **Thiokinase** (succinyl-CoA synthetase) | **Phosphoryl hóa mức cơ chất** | **GTP** (≈ 1 ATP) |
| **6** | Succinat → **fumarat** | **Succinat dehydrogenase** (coenzym **FAD**) | Oxy hóa (tách 2H tạo nối đôi) | **FADH~2~** |
| **7** | Fumarat + H~2~O → **malat** | **Fumarase** | Hydrat hóa | — |
| **8** | Malat → **oxaloacetat** | **Malat dehydrogenase** (coenzym NAD^+^) | Oxy hóa | **NADH** |

Một số "vì sao" ở từng bước (Giáo trình tr. 98–99):

- **Bước 2 (aconitase)**: trong citrat, nhóm –OH gắn ở carbon bậc ba, **không oxy hóa được**. Aconitase chuyển –OH sang carbon bên cạnh (isocitrat có –OH ở carbon bậc hai). Phân tử citrat **cân đối, bền** trở thành isocitrat **kém bền**, dễ tham gia phản ứng tiếp theo.
- **Bước 3**: isocitrat bị tách 2H (về NAD^+^) thành oxalosuccinat (**3a**); oxalosuccinat mất CO~2~ thành α-cetoglutarat (**3b**). Giáo trình ghi bước 3b xảy ra **tự phát, không cần enzym**. Hiện nay biết rõ cả hai bước đều diễn ra **trên cùng enzym isocitrat dehydrogenase**, oxalosuccinat không rời khỏi enzym.
- **Bước 4**: phức tạp, diễn ra qua nhiều giai đoạn **giống hệt** pyruvat → acetyl-CoA (cùng 5 coenzym).
- **Bước 5**: năng lượng của liên kết **thioester giàu năng lượng** trong succinyl-CoA (ký hiệu ∼) được dùng tạo liên kết giàu năng lượng của **GTP** từ GDP + P~i~. GTP chuyển P cho ADP thành ATP (giáo trình ghi "GTP (ATP)").
- **Bước 6**: succinat dehydrogenase chính là **phức hợp II** của chuỗi hô hấp; FADH~2~ của nó chuyển e^−^ thẳng vào CoQ.
- **Bước 8** đóng vòng: tái tạo oxaloacetat để đón acetyl-CoA tiếp theo. Oxaloacetat hoạt động như **"chất mồi" dùng lại được**, nên một lượng nhỏ cũng đủ quay rất nhiều vòng.

> [!ghi-nho] Mẹo nhớ thứ tự 8 chất
> **O**xaloacetat → **C**itrat → **I**socitrat → **α**-cetoglutarat → **S**uccinyl-CoA → **S**uccinat → **F**umarat → **M**alat.
> Viết tắt để nhớ: **O – C – I – α – S – S – F – M**. Số carbon: 4 → **6 → 6 → 5 → 4** → 4 → 4 → 4. Hai lần mất CO~2~ ở **bước 3 và 4**.

> [!bay]
> - **Bốn bước tách hydro**: 3 (NAD), 4 (NAD), 6 (**FAD**), 8 (NAD). Chỉ bước 6 dùng FAD.
> - **Hai bước tạo CO~2~**: 3 và 4. Hai carbon thải ra dưới dạng CO~2~ trong một vòng **không phải** chính hai carbon của acetyl-CoA vừa vào; chúng đến từ phần oxaloacetat cũ. Tính tổng thì vẫn mất đúng 2C mỗi vòng.
> - **Bước duy nhất tạo trực tiếp liên kết phosphat giàu năng lượng**: bước 5 (thiokinase, GTP).
> - Fumarase **cộng nước**, không phải tách hydro.

### 4.3. Kết quả, đặc điểm và ý nghĩa

**Kết quả của một vòng** (một acetyl-CoA) (Giáo trình tr. 99):

=> Acetyl-CoA + 3 NAD^+^ + FAD + GDP + P~i~ + 2 H~2~O → 2 CO~2~ + 3 NADH + 3 H^+^ + FADH~2~ + GTP + CoA-SH

| Sản phẩm | Số lượng | ATP theo giáo trình | ATP theo số liệu hiện nay |
|---|---|---|---|
| NADH (bước 3, 4, 8) | 3 | 3 × 3 = 9 | 3 × 2,5 = 7,5 |
| FADH~2~ (bước 6) | 1 | 1 × 2 = 2 | 1 × 1,5 = 1,5 |
| GTP (bước 5) | 1 | 1 | 1 |
| **Tổng** | | **12 ATP** | **≈ 10 ATP** |

- **2 nguyên tử C** vào dưới dạng acetyl-CoA, **2 nguyên tử C** ra dưới dạng CO~2~ (bước 3 và 4).
- **4 cặp hydro** ra khỏi chu trình: 3 cặp dạng NADH, 1 cặp dạng FADH~2~. Chúng vào chuỗi hô hấp cho **11 ATP**; cộng 1 ATP từ GTP là **12 ATP**.
- **2 phân tử H~2~O** được sử dụng.

**Đặc điểm:** xảy ra **trong ty thể** (chất nền); chỉ chạy được trong điều kiện **ái khí**.

> [!bay] Chu trình không dùng O~2~ trực tiếp, sao lại "cần ái khí"?
> Không bước nào của chu trình phản ứng với O~2~. Nhưng chu trình cần NAD^+^ và FAD **ở dạng oxy hóa**. Chỉ chuỗi hô hấp (có O~2~ ở cuối) mới "xả" NADH, FADH~2~ trở lại thành NAD^+^, FAD. **Thiếu O~2~** → NADH ứ đọng, hết NAD^+^ → chu trình **dừng**.

**Ý nghĩa:**

1. **Giai đoạn thoái hóa chung, cuối cùng** của glucid, lipid, protein.
2. **Cung cấp nhiều năng lượng**: phần lớn dưới dạng NADH, FADH~2~ đưa vào chuỗi hô hấp.
3. **Cung cấp chất trung gian cho các con đường chuyển hóa khác** (vai trò **lưỡng hóa**, mục 4.5).

### 4.4. Điều hòa chu trình acid citric

Điều hòa chu trình chính là **điều hòa việc tạo ATP theo nhu cầu tế bào**. Có **3 điểm điều hòa** do các **enzym dị lập thể** xúc tác (Giáo trình tr. 100):

| Enzym (bước) | Bị ức chế bởi | Được kích thích bởi |
|---|---|---|
| **Citrat synthase** (1) | **ATP** (giáo trình); thêm NADH, succinyl-CoA, citrat | — |
| **Isocitrat dehydrogenase** (3) | **ATP**, NADH | **ADP** (và Ca^2+^) |
| **α-cetoglutarat dehydrogenase** (4) | **Succinyl-CoA**, **NADH** | (Ca^2+^) |

**Logic chung:** **ATP, NADH dồi dào** (tế bào "no năng lượng") → **phanh** chu trình. **ADP tăng** (tế bào "đói năng lượng") → **đạp ga**. Ca^2+^ tăng khi cơ co, nên cũng thúc chu trình chạy nhanh hơn.

> [!bay] Cách đánh số phản ứng trong mục điều hòa của giáo trình
> Ở mục điều hòa, giáo trình ghi: "phản ứng 1: ATP ức chế; **phản ứng 4**: ATP ức chế, ADP kích thích; **phản ứng 5**: succinyl-CoA và NADH ức chế". Nếu đối chiếu với cách đánh số 1–8 ở mục 4.2 thì lệch một bậc. Phản ứng "ATP ức chế, ADP kích thích" là **isocitrat dehydrogenase (bước 3)**. Phản ứng "succinyl-CoA, NADH ức chế" là **α-cetoglutarat dehydrogenase (bước 4)**. Bước 5 (thiokinase) không phải điểm điều hòa. Khi thi, hãy nhớ **theo tên enzym** để không bị nhầm số.

### 4.5. Vai trò lưỡng hóa của chu trình

Chu trình vừa **dị hóa** (đốt acetyl-CoA lấy năng lượng) vừa **đồng hóa** (cung cấp "nguyên liệu" để tổng hợp chất). Vì vậy gọi là chu trình **lưỡng hóa** (amphibolic). Giáo trình chỉ nêu ý "cung cấp chất trung gian cho các chuyển hóa khác"; dưới đây là các ví dụ sẽ gặp ở các chương sau:

| Chất trung gian | Được rút ra để tạo… |
|---|---|
| **Citrat** | Ra bào tương, cung cấp acetyl-CoA để **tổng hợp acid béo, cholesterol** |
| **α-cetoglutarat** | **Glutamat** và các acid amin liên quan (trao đổi amin) |
| **Succinyl-CoA** | **Hem** (cùng glycin) |
| **Oxaloacetat** | **Aspartat**; **glucose** (tân tạo glucose ở gan) |

Khi chất trung gian bị rút ra, chu trình sẽ thiếu oxaloacetat để quay tiếp. Cơ thể có các **phản ứng bổ sung** (anaplerotic) để bù lại. Quan trọng nhất là **pyruvat + CO~2~ → oxaloacetat** (enzym pyruvat carboxylase, coenzym **biotin**). Acid amin cũng có thể bổ sung α-cetoglutarat, oxaloacetat…

> [!ung-dung] Khi chu trình bị chặn
> - **Fluoroacetat** (một loại thuốc diệt chuột): vào cơ thể bị biến thành **fluorocitrat**, chất này **ức chế aconitase**. Chu trình tắc ở bước 2, citrat tích tụ, tế bào tim và não thiếu năng lượng. Hiện tượng chất ít độc bị chính enzym của cơ thể "biến" thành chất độc gọi là **"tổng hợp chết người"**.
> - **Bệnh ty thể** (đột biến ADN (DNA) ty thể hoặc gen nhân mã hóa protein chuỗi hô hấp). Ví dụ: **bệnh thần kinh thị giác di truyền Leber** (LHON, đột biến gen tiểu đơn vị phức hợp I), **MELAS** (bệnh não – cơ, toan lactic, cơn giống đột quỵ). Đặc điểm chung: tổn thương **cơ quan cần nhiều ATP** (não, cơ, tim, võng mạc), **lactat máu tăng**, **di truyền theo dòng mẹ** khi đột biến nằm ở ADN ty thể.

> [!yhct] Thương nhĩ tử (quả Ké đầu ngựa) và chất trao đổi ADP/ATP
> ATP tạo trong chất nền phải nhờ **chất trao đổi ADP/ATP** (adenin nucleotid translocase) trên màng trong mới ra được bào tương. **Carboxyatractylosid** và **atractylosid** ức chế đặc hiệu chất trao đổi này. Đây là cơ chế đã được chứng minh trên ty thể cô lập. Hai chất này có trong quả, hạt và cây mầm của **Ké đầu ngựa** (*Xanthium*), tức vị **Thương nhĩ tử**. Ngộ độc (gia súc ăn cây mầm; người dùng quá liều hoặc dùng hạt) gây **hạ đường huyết, tổn thương gan**, có thể tử vong. Vì vậy Thương nhĩ tử được xếp vào vị **có độc**: phải chế biến (sao, bỏ gai) và **dùng đúng liều**.

### 4.6. Toàn cảnh: từ thức ăn đến ATP

Ghép tất cả lại (theo sơ đồ tổng kết, Giáo trình tr. 100):

1. G, L, P thoái hóa thành **pyruvat, acid béo**. Các chất này vào ty thể, tạo **acetyl-CoA** (2C).
2. Acetyl-CoA bị đốt hoàn toàn trong **chu trình Krebs**: carbon ra dưới dạng **CO~2~** (thải qua phổi), hydro ra dưới dạng **NADH, FADH~2~**.
3. NADH, FADH~2~ trao e^−^ cho **chuỗi hô hấp** trên màng trong. Dòng e^−^ **bơm H^+^** ra khoảng gian màng; cuối chuỗi, e^−^ + H^+^ + O~2~ → **H~2~O**.
4. Màng trong không cho H^+^ tự do quay lại, tạo **chênh lệch H^+^**. H^+^ chỉ về được qua **ATP synthase**, và lực đẩy đó tạo **ATP**.
5. ATP ra bào tương, cung cấp năng lượng cho mọi hoạt động sống của tế bào.

> [!cap-nhat] Bao nhiêu ATP từ một phân tử glucose?
> Chương này không tính tổng ATP/glucose, phần đó học ở chương *Chuyển hóa glucid*. Các tài liệu cũ dùng P/O = 3 và 2 thì tính ra **36–38 ATP** (bài *Màng tế bào và tế bào chất* ghi 38 ATP theo giáo trình Sinh học). Với P/O hiện nay (2,5 và 1,5), con số là **khoảng 30–32 ATP**. Con số chính xác phụ thuộc NADH của đường phân vào ty thể qua "con thoi" nào (glycerol-phosphat cho ít hơn, malat-aspartat cho nhiều hơn).

## Tóm tắt

| Chủ đề | Điểm cần nhớ |
|---|---|
| Hô hấp tế bào | Đốt từng bước, có enzym, ở 37 °C; năng lượng tích vào ATP. CO~2~ từ khử carboxyl; H~2~O từ H chuyển tới O~2~ |
| Ba bước thoái hóa | (1) Đại phân tử → đơn vị; (2) → pyruvat, acetyl-CoA; (3) → CO~2~, H~2~O (Krebs + chuỗi hô hấp), **chung cho G, L, P** |
| Chuỗi hô hấp | NADH → **I** (FMN, Fe-S) → **CoQ** → **III** (b, Fe-S, c~1~) → **cyt c** → **IV** (a, a~3~, Cu) → O~2~. Succinat → **II** (FAD, Fe-S) → CoQ |
| Năng lượng | ΔG°' = −nFΔE°'; NADH → O~2~: **−52,6 kcal/mol**; e^−^ đi từ E°' thấp → cao |
| Tạo ATP | **Thuyết hóa thẩm Mitchell**: bơm H^+^ (I: 4, III: 4, IV: 2) → pmf → ATP synthase F~o~ (kênh H^+^) + F~1~ (α~3~β~3~, tạo ATP ở β), cơ chế quay |
| P/O | Sách: NADH **3**, FADH~2~ **2** (3 H^+^/ATP). Hiện nay: **≈ 2,5** và **≈ 1,5** |
| Điều hòa | **ADP** quyết định tốc độ chuỗi hô hấp và tiêu thụ O~2~ (kiểm soát hô hấp) |
| Chất ức chế | Rotenon (I), antimycin A (III), CN^−^/CO/H~2~S (IV), oligomycin (F~o~): **ngừng** tiêu thụ O~2~ |
| Chất tách cặp | DNP, **thermogenin (UCP1, mỡ nâu)**: **tăng** tiêu thụ O~2~, không tạo ATP, sinh nhiệt |
| Liên kết phosphat | Nghèo: 1–5 kcal (ester phosphat). Giàu: > 7 kcal: acylphosphat (1,3-DPG −10,1), enolphosphat (PEP −14,8), amidphosphat (phosphocreatin −10,3), pyrophosphat (ATP −7,3) |
| Mức cơ chất | 1,3-DPG → 3-PG; PEP → pyruvat (đường phân); succinyl-CoA → succinat (Krebs, GTP) |
| PDH | E1 (TPP), E2 (lipoamid), E3 (FAD) + CoA, NAD^+^; thiếu B~1~ → beriberi; không thuận nghịch |
| Krebs | OAA → citrat → isocitrat → α-KG → succinyl-CoA → succinat → fumarat → malat; NADH ở 3, 4, 8; FADH~2~ ở 6; GTP ở 5; CO~2~ ở 3, 4 |
| Năng lượng Krebs | 3 NADH + 1 FADH~2~ + 1 GTP = **12 ATP** (sách) / **≈ 10** (hiện nay) |
| Điều hòa Krebs | Citrat synthase, isocitrat DH, α-cetoglutarat DH: ATP/NADH ức chế; ADP kích thích |
| Lưỡng hóa | Citrat → acid béo; α-KG → glutamat; succinyl-CoA → hem; OAA → aspartat, glucose; bổ sung bằng pyruvat carboxylase |
