---
title: Hóa học lipid
thoi-gian: 45 phút
muc-tieu:
- Nêu được định nghĩa lipid, đặc điểm chung và vai trò sinh học của lipid.
- Trình bày được đặc điểm các thành phần cấu tạo chính của lipid: acid béo (bão hòa, không bão hòa, mang chức alcol, có vòng; đồng phân cis–trans) và các alcol (glycerol, alcol bậc cao, aminoalcol, sterol).
- Phân loại được lipid theo cấu tạo hóa học (lipid thuần, lipid tạp) và viết được công thức cấu tạo chung của từng loại.
- Mô tả được cấu tạo, sự phân bố và vai trò của các glycerophospholipid và sphingolipid chính trong cơ thể người.
- Liên hệ được cấu trúc lipid với một số vấn đề y học: chất béo trans, acid béo thiết yếu và omega-3, chất hoạt diện phổi, bệnh tích lũy sphingolipid.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Lipid là **ester (hoặc amid) của acid béo với alcol (hoặc aminoalcol)**; rất ít nhóm ưa nước nên **không tan trong nước**, tan trong dung môi hữu cơ. 1 g lipid cho khoảng **9,3 kcal**.
> 2. **Acid béo**: chuỗi 4–36 C. **No** (palmitic 16:0, stearic 18:0) hoặc **không no** (oleic 18:1, linoleic 18:2, linolenic 18:3, arachidonic 20:4). Trong tự nhiên nối đôi gần như luôn ở dạng **cis** → chuỗi **gấp khúc** → nhiệt độ nóng chảy thấp. Linoleic, linolenic là **acid béo thiết yếu**.
> 3. **Alcol** của lipid: **glycerol**, **alcol bậc cao**, **aminoalcol** (sphingosin, cholin, ethanolamin, serin), **sterol** (cholesterol).
> 4. **Lipid thuần** = acid béo + alcol: **glycerid** (glycerol), **cerid** (alcol bậc cao), **sterid** (sterol). **Lipid tạp** có thêm nhóm khác: **glycerophospholipid** (khung glycerol) và **sphingolipid** (khung sphingosin).
> 5. Glycerophospholipid = **acid phosphatidic + X** (cholin → lecithin; ethanolamin → cephalin; serin; inositol; glycerol). Sphingolipid = **ceramid + X** (phosphocholin → sphingomyelin; ose → cerebrosid; ose + sulfat → sulfatid; oligosaccharid + acid sialic → gangliosid).

## 1. Đại cương về lipid

### 1.1. Định nghĩa và đặc điểm chung

Lipid là thành phần cơ bản của sinh vật, ngang hàng với glucid và protein. Về cấu tạo, hầu hết lipid là **ester hoặc amid** được tạo từ **acid béo** và **alcol** (hoặc **aminoalcol**) (Giáo trình tr. 26).

- *Ester*: acid béo nối với –OH của alcol (glycerid, phospholipid có glycerol).
- *Amid*: acid béo nối với –NH~2~ của aminoalcol sphingosin (ceramid và các sphingolipid).

**Vì sao lipid không tan trong nước?** Phân tử lipid có rất ít nhóm ưa nước (–OH, –NH~2~, –COOH), trong khi phần lớn là chuỗi hydrocarbon dài **kỵ nước**. Vì vậy lipid hầu như không tan trong nước, nhưng tan tốt trong dung môi **kém phân cực** như ether, benzen, chloroform. Tính chất này là cơ sở để chiết lipid khỏi mô.

Trong ngôn ngữ thường ngày, lipid được gọi chung là **chất béo**, gồm **dầu** (lỏng ở nhiệt độ thường), **mỡ** và **sáp** (đặc).

> [!cap-nhat] Định nghĩa lipid hiện nay
> Giáo trình định nghĩa lipid theo **cấu tạo** (ester/amid của acid béo). Định nghĩa này không bao quát được cholesterol tự do, các vitamin tan trong dầu hay các terpen. Hiện nay lipid thường được định nghĩa theo **tính chất**: các phân tử nhỏ **kỵ nước hoặc lưỡng tính**, tan trong dung môi hữu cơ. Hệ thống phân loại quốc tế LIPID MAPS chia lipid thành 8 nhóm (acid béo và dẫn xuất, glycerolipid, glycerophospholipid, sphingolipid, sterol lipid, prenol lipid, saccharolipid, polyketid). Đi thi vẫn trả lời theo định nghĩa của giáo trình.

### 1.2. Vai trò sinh học

| Vai trò | Nội dung chính |
|---|---|
| **Năng lượng** | 1 g lipid cung cấp khoảng **9,3 kcal**, gấp hơn 2 lần glucid và protein. Triglycerid là dạng **dự trữ** năng lượng chính (ở mô mỡ). |
| **Cấu tạo màng** | Phospholipid, glycolipid, cholesterol là "bộ khung" của màng tế bào và màng ty thể. |
| **Bảo vệ, cách nhiệt** | Lớp mỡ dưới da và quanh các cơ quan giữ nhiệt và chống va đập. |
| **Dung môi, nguồn chất thiết yếu** | Chứa và giúp hấp thu **vitamin tan trong dầu A, D, E, K**; cung cấp **acid béo không no thiết yếu** mà cơ thể không tự tổng hợp được. |
| **Vận chuyển** | Lipid kết hợp với protein thành **lipoprotein**, vừa là thành phần của màng, vừa là dạng **chở lipid trong máu**. |

> [!bay] 9,3 hay 9,4 kcal?
> Giáo trình Hóa sinh ghi **9,3 kcal/g**; giáo trình Hóa học (bài *Acid carboxylic, ester*) ghi 9,4 kcal/g. Dinh dưỡng học hiện nay làm tròn là **9 kcal/g** (hệ số Atwater 9 – 4 – 4). Thi môn nào dùng số của sách môn đó.

## 2. Acid béo — thành phần chính của lipid

### 2.1. Định nghĩa, danh pháp và cách ký hiệu

Acid béo là **acid carboxylic có chuỗi hydrocarbon từ 4 đến 36 carbon** (Giáo trình tr. 26–27). Đa số có chuỗi **thẳng, không nhánh** và **số C chẵn** (vì cơ thể tổng hợp acid béo bằng cách nối dần từng mẩu 2C). Một số ít có nhánh, có vòng hoặc mang thêm nhóm –OH.

**Tên hệ thống** = tên hydrocarbon cùng số C + đuôi **-oic**. Ví dụ: octan (8C) → acid octanoic (acid caprylic); octadecen (18C, một nối đôi) → acid octadecenoic (acid oleic). Phần tên gọi và tính chất hóa học chung của acid carboxylic đã học ở bài *Acid carboxylic, ester* (môn Hóa học) — ở đây không nhắc lại.

**Đánh số mạch** (Hình 1):

- C của nhóm –COOH là **C1**; C2 gọi là **Cα**, C3 là **Cβ**…; C của nhóm CH~3~ cuối mạch gọi là **Cω**.
- **Ký hiệu số C : số nối đôi**, kèm vị trí nối đôi bằng **Δ** (đếm từ C1). Ví dụ: acid palmitic **16:0**; acid oleic **18:1 Δ^9^** (nối đôi giữa C9 và C10); acid linoleic **18:2 Δ^9,12^**.

![Hình 1. Hai cách đánh số acid béo (Δ từ đầu –COOH, ω từ đầu CH₃) và đồng phân cis/trans](acid-beo.svg)

> [!vi-du] Cách đếm ω (omega) — bổ sung để hiểu "omega-3, omega-6"
> Giáo trình chỉ nêu tên Cω. Trong dinh dưỡng và y học, người ta đếm **từ đầu CH~3~** (C cuối = ω1) và gọi tên acid béo theo **vị trí nối đôi đầu tiên tính từ đầu ω**.
> - Cách đổi: **vị trí ω = tổng số C − vị trí Δ cuối cùng**. Linoleic 18:2 Δ^9,12^ → 18 − 12 = **6** → **ω-6**. Linolenic (α-linolenic) 18:3 Δ^9,12,15^ → 18 − 15 = **3** → **ω-3**. Oleic 18:1 Δ^9^ → **ω-9**. Arachidonic 20:4 Δ^5,8,11,14^ → 20 − 14 = **6** → **ω-6**.
> - Ký hiệu tương đương: ω-3 = n-3.

### 2.2. Acid béo bão hòa (no)

Không có nối đôi; công thức chung **C~n~H~2n+1~COOH**. Bảng 2.1 của giáo trình (tr. 27):

| Tên thường | Công thức | Tên hệ thống | t° nóng chảy | Gặp trong |
|---|---|---|---|---|
| Lauric (12:0) | CH~3~(CH~2~)~10~COOH | n-dodecanoic | 44,2 °C | Dầu dừa |
| Myristic (14:0) | CH~3~(CH~2~)~12~COOH | n-tetradecanoic | 53,9 °C | Dầu dừa |
| **Palmitic (16:0)** | CH~3~(CH~2~)~14~COOH | n-hexadecanoic | 63,1 °C | Mỡ động vật, dầu thực vật |
| **Stearic (18:0)** | CH~3~(CH~2~)~16~COOH | n-octadecanoic | 69,6 °C | Mỡ động vật, dầu thực vật |
| Arachidic (20:0) | CH~3~(CH~2~)~18~COOH | n-eicosanoic | 76,5 °C | Dầu lạc, sáp |
| Lignoceric (24:0) | CH~3~(CH~2~)~22~COOH | tetracosanoic | 86,0 °C | Dầu lạc, sáp động – thực vật |

**Quy luật:** chuỗi **càng dài** thì nhiệt độ nóng chảy **càng cao**. Lý do: chuỗi no thẳng nằm sát nhau được, chuỗi càng dài thì lực hút van der Waals giữa các chuỗi càng lớn, cần nhiều nhiệt hơn để tách chúng.

### 2.3. Acid béo không bão hòa

Chuỗi thẳng (đôi khi có nhánh), có một hoặc nhiều nối đôi, **thường ở dạng cis** (Giáo trình tr. 27–28).

| Loại | Công thức chung | Ví dụ (giáo trình) | Ký hiệu | t° nóng chảy |
|---|---|---|---|---|
| Một nối đôi (*monounsaturated*) | C~n~H~2n−1~COOH | Palmitoleic | 16:1 Δ^9^ | −0,5 °C |
| | | **Oleic** | 18:1 Δ^9^ | 13,4 °C |
| Hai nối đôi (*polyunsaturated*) | C~n~H~2n−3~COOH | **Linoleic** | 18:2 Δ^9,12^ | −5 °C |
| Ba nối đôi | C~n~H~2n−5~COOH | **Linolenic** | 18:3 Δ^9,12,15^ | −11 °C |
| Bốn nối đôi | C~n~H~2n−7~COOH | **Arachidonic** | 20:4 Δ^5,8,11,14^ | −49,5 °C |

Nguồn theo giáo trình:

- **Oleic**: phổ biến nhất, có trong hầu hết dầu và mỡ. Chiếm khoảng **40%** mỡ dự trữ của bò, lợn và khoảng **80%** dầu ô liu.
- **Linoleic**: các hạt có dầu (ngũ cốc, lạc, bông, đậu nành).
- **Linolenic**: thường đi cùng linoleic, nhiều trong đậu nành.

**Vì sao càng nhiều nối đôi càng dễ chảy lỏng?** Mỗi nối đôi **cis** bẻ chuỗi thành một khúc gấp. Các chuỗi gấp khúc không xếp sát nhau được, lực hút giữa chúng yếu, nên nhiệt độ nóng chảy giảm mạnh (stearic 69,6 °C → oleic 13,4 °C → linoleic −5 °C). Vì thế dầu thực vật (giàu acid béo không no) lỏng, còn mỡ động vật (giàu acid béo no) đặc ở nhiệt độ phòng.

> [!cap-nhat] Acid arachidonic có ở đâu?
> Giáo trình ghi acid arachidonic "thấy chủ yếu trong dầu lạc". Thực ra dầu lạc gần như **không** chứa acid arachidonic. Dầu lạc (*Arachis hypogaea*) chứa acid **arachidic** (20:0, no) — hai tên dễ nhầm vì cùng gốc tên cây lạc. Hiện nay acid **arachidonic** (20:4 ω-6) được biết là thành phần của **phospholipid màng tế bào động vật**; thức ăn chứa nó là thịt, trứng, gan. Cơ thể cũng tự tạo được arachidonic từ acid linoleic.

**Acid béo thiết yếu.** Một số acid béo không no rất cần cho cơ thể nhưng cơ thể **không tự tổng hợp được**, phải lấy từ thức ăn. Giáo trình nêu ví dụ **acid linoleic, acid linolenic** (tr. 28).

*Vì sao không tổng hợp được?* Tế bào người có enzym tạo nối đôi ở vị trí Δ^9^ và các vị trí gần đầu –COOH hơn, nhưng **không có enzym tạo nối đôi vượt quá Δ^9^** về phía đầu ω (vị trí Δ^12^, Δ^15^). Do đó người không tạo ra được hai "mẹ" của họ ω-6 (linoleic) và họ ω-3 (α-linolenic).

> [!bay]
> - Acid **oleic** (18:1 ω-9) **không** thiết yếu: cơ thể tự tạo được từ acid stearic.
> - Acid **arachidonic** được xem là thiết yếu **có điều kiện**: bình thường cơ thể tạo ra từ linoleic, chỉ cần lấy từ ngoài khi thiếu linoleic.
> - Cẩn thận tên: **linoleic** (18:2, ω-6) ≠ **linolenic** (18:3, ω-3).

> [!ung-dung] Omega-3, omega-6 và dầu cá
> - Họ **ω-6**: linoleic → arachidonic. Họ **ω-3**: α-linolenic (ALA) → **EPA** (20:5) → **DHA** (22:6). Hai họ không chuyển đổi được sang nhau.
> - **DHA** tập trung nhiều ở **võng mạc và chất xám não**; vì vậy được chú ý trong dinh dưỡng bà mẹ mang thai và trẻ nhỏ.
> - Người chuyển ALA (từ thực vật) thành EPA, DHA **rất kém** (thường dưới 10%, DHA còn ít hơn). Nguồn EPA/DHA trực tiếp là **cá béo, dầu cá**.
> - EPA/DHA liều cao (khoảng 2–4 g/ngày, dạng thuốc) **giảm triglycerid máu** rõ; được dùng cho người tăng triglycerid. Lợi ích phòng bệnh tim mạch của viên dầu cá liều thấp dùng đại trà thì các nghiên cứu cho kết quả **không thống nhất**.

### 2.4. Acid béo mang chức alcol

Ví dụ của giáo trình: **acid cerebronic** CH~3~(CH~2~)~21~CH(OH)COOH — acid 24C có nhóm –OH ở **Cα** (tức acid 2-hydroxy-lignoceric). Nó có trong **lipid tạp của não** (cerebrosid, mục 6.3).

### 2.5. Acid béo có vòng — prostaglandin

**Acid prostanoic** là acid béo **20C có một vòng 5 cạnh** (nối C8 với C12) và hai chuỗi bên. Dẫn xuất của nó là **prostaglandin**, nhóm chất có vai trò dược lý và hóa sinh quan trọng. Trong cơ thể, prostaglandin được tổng hợp **từ acid arachidonic** (20C), ví dụ **prostaglandin E~2~ (PGE~2~)** (Giáo trình tr. 28).

> [!ung-dung] Eicosanoid và thuốc chống viêm
> Các chất 20C sinh ra từ acid arachidonic gọi chung là **eicosanoid** (*eikosi* = 20): **prostaglandin**, **thromboxan** (qua enzym cyclooxygenase, COX) và **leukotrien** (qua enzym lipoxygenase). Chúng gây viêm, sốt, đau, điều hòa đông máu, co thắt phế quản…
> - **Aspirin và các thuốc chống viêm không steroid** (NSAID) ức chế **COX** → giảm prostaglandin → hạ sốt, giảm đau, chống viêm; aspirin liều thấp giảm thromboxan → chống kết tập tiểu cầu. (Cấu tạo aspirin: bài *Acid carboxylic, ester*.)
> - **Corticoid** ức chế khâu sớm hơn là giải phóng arachidonic khỏi phospholipid màng (enzym phospholipase A~2~), nên chống viêm mạnh hơn.
> - Phần sinh tổng hợp eicosanoid sẽ học ở chương *Chuyển hóa lipid*.

### 2.6. Đồng phân của acid béo không bão hòa

Acid béo không bão hòa có hai kiểu đồng phân (Giáo trình tr. 29):

- **Đồng phân vị trí**: khác vị trí nối đôi trên chuỗi.
- **Đồng phân hình học (cis–trans)**: xét hai phần chuỗi carbon gắn ở hai đầu nối đôi. Cùng một phía → **cis**; hai phía ngược nhau → **trans**. Ví dụ: **acid oleic** là dạng **cis**, **acid elaidic** là dạng **trans** của cùng acid 18:1 Δ^9^ (Hình 1).

Acid béo không bão hòa chuỗi dài trong tự nhiên **hầu như đều là cis**, và chuỗi bị **uốn cong tại nối đôi**. Điều kiện chung để có đồng phân cis–trans đã học ở bài *Cấu trúc phân tử hợp chất hữu cơ — đồng phân* (môn Hóa học).

> [!ung-dung] Chất béo trans
> - **Nguồn**: chủ yếu sinh ra khi **hydro hóa một phần dầu thực vật** để làm bơ thực vật (margarin), shortening dùng cho bánh quy, bánh chiên, đồ ăn nhanh. Chiên đi chiên lại dầu ở nhiệt độ cao cũng tạo một ít. Mỡ sữa, thịt bò (động vật nhai lại) có một lượng nhỏ trans tự nhiên.
> - **Vì sao nguy hiểm?** Chuỗi trans **gần thẳng** như acid béo no (elaidic nóng chảy ở khoảng 44 °C, oleic chỉ 13,4 °C). Khi ăn vào, chất béo trans **làm tăng LDL-cholesterol** và **làm giảm HDL-cholesterol**, nên làm tăng nguy cơ **xơ vữa động mạch, bệnh mạch vành** — hại hơn cả chất béo no.
> - **Khuyến cáo**: Tổ chức Y tế Thế giới khuyên chất béo trans dưới **1% tổng năng lượng** và kêu gọi loại bỏ chất béo trans công nghiệp khỏi thực phẩm. Khi đọc nhãn, chú ý cụm "dầu hydro hóa một phần" (*partially hydrogenated oil*).

## 3. Alcol của lipid

Alcol trong lipid gồm 4 nhóm: **glycerol, alcol bậc cao, aminoalcol, sterol** (Giáo trình tr. 29). Ngoài ra có một số alcol không no là sắc tố, ví dụ **phytol** là một thành phần của **chlorophyll**.

### 3.1. Glycerol

Glycerol là **trialcol** (3 nhóm –OH): CH~2~OH–CHOH–CH~2~OH. Có trong cấu tạo của **glycerid** và **phosphatid** (glycerophospholipid). Ba carbon được đánh số **1, 2, 3** hoặc ký hiệu **α, β, α′**: hai C đầu mạch là α và α′, C giữa là β.

### 3.2. Alcol bậc cao

Alcol mạch dài, có trong thành phần **sáp (cerid)**. Ví dụ: alcol cetylic (C~16~), n-hexacosanol CH~3~(CH~2~)~24~CH~2~OH, n-octacosanol CH~3~(CH~2~)~26~CH~2~OH.

> [!bay] Công thức alcol cetylic
> Giáo trình in "C~16~H~36~OH" — **sai** (vượt quá số H tối đa). Alcol no 16C là **C~16~H~33~OH**, tức CH~3~(CH~2~)~15~OH (hexadecan-1-ol).

### 3.3. Aminoalcol

Có trong cấu tạo của **cerebrosid** và một số **phosphatid** (Giáo trình tr. 29–30):

| Aminoalcol | Công thức | Có trong |
|---|---|---|
| **Sphingosin** | CH~3~(CH~2~)~12~–CH=CH–CH(OH)–CH(NH~2~)–CH~2~OH | Mọi sphingolipid (18C, 1 nối đôi trans, 2 –OH, 1 –NH~2~) |
| **Ethanolamin** (colamin) | NH~2~–CH~2~–CH~2~OH | Cephalin |
| **Cholin** (ethanolamin trimethylamin) | (CH~3~)~3~N^+^–CH~2~–CH~2~OH | Lecithin, sphingomyelin |
| **Serin** | (acid amin (amino acid) có –OH) | Phosphatidylserin |

Giáo trình còn nêu **cerebrin** (có trong nấm men, hạt ngô).

### 3.4. Sterol — cholesterol

**Cholesterol** là sterol tiêu biểu của mô động vật (Giáo trình tr. 30). Đặc điểm cấu tạo cần nhớ:

- Khung **nhân steroid** gồm 4 vòng (3 vòng 6 cạnh A, B, C và 1 vòng 5 cạnh D), tổng cộng **27 C**.
- **–OH ở C3** (nhóm ưa nước duy nhất, rất nhỏ).
- **Nối đôi C5–C6**.
- Hai **nhóm methyl** ở **C10 và C13** (là C19 và C18).
- **Chuỗi nhánh 8 C ở C17**.

Cholesterol có trong hầu hết tế bào, đặc biệt nhiều ở **mô thần kinh, mật và sỏi mật, thể vàng buồng trứng**. Cholesterol có trong **chất béo động vật**, **không có trong chất béo thực vật**. Các sterol khác: **7-dehydrocholesterol**, **ergosterol** (ở nấm), **coprosterol** (trong phân).

**Vai trò của cholesterol** (phần lớn sẽ học kỹ ở chương *Chuyển hóa lipid*):

- **Thành phần màng tế bào**: chen giữa các phospholipid, điều chỉnh độ lỏng của màng (đã học ở bài *Màng tế bào*, môn Sinh học).
- **Tiền chất** của: **acid mật** (gan chuyển cholesterol thành acid cholic, chenodeoxycholic; muối mật giúp nhũ tương hóa và hấp thu lipid ở ruột), **hormon steroid** (cortisol, aldosteron, hormon sinh dục) và **vitamin D~3~** (7-dehydrocholesterol ở da + tia UV). Ergosterol của nấm chiếu UV cho **vitamin D~2~**.

> [!ung-dung] Cholesterol máu và sỏi mật
> - Mỡ máu được đánh giá bằng bộ xét nghiệm **cholesterol toàn phần, triglycerid, HDL-C, LDL-C**. Giá trị thường dùng (tham khảo, mỗi phòng xét nghiệm có khoảng riêng; mục tiêu LDL-C còn tùy mức nguy cơ tim mạch): cholesterol toàn phần **< 5,2 mmol/L**; triglycerid **< 1,7 mmol/L**; HDL-C **≥ 1,0 mmol/L** (nam), **≥ 1,3 mmol/L** (nữ); LDL-C **< 3,4 mmol/L**. Đổi đơn vị: cholesterol mmol/L × 38,7 = mg/dL; triglycerid mmol/L × 88,5 = mg/dL.
> - Cholesterol rất kém tan; trong mật nó được giữ tan nhờ **muối mật và lecithin**. Khi mật quá bão hòa cholesterol, cholesterol kết tủa thành **sỏi cholesterol** — loại sỏi túi mật phổ biến ở nhiều nước (ở Việt Nam còn hay gặp sỏi sắc tố trong đường mật). Đó là lý do giáo trình nhắc cholesterol "có trong sỏi mật".

> [!yhct] Phytosterol, ergosterol trong dược liệu — nói đúng mức
> - Thực vật không có cholesterol mà có **phytosterol** (β-sitosterol, stigmasterol, campesterol). Cấu trúc gần giống cholesterol nên chúng **cạnh tranh hấp thu cholesterol ở ruột**. Thử nghiệm lâm sàng cho thấy bổ sung khoảng **2 g phytosterol/ngày** (thực phẩm bổ sung) làm giảm LDL-C khoảng 8–10%.
> - Nhiều dược liệu có β-sitosterol, nhưng lượng trong một thang thuốc sắc **rất nhỏ** (sterol hầu như không tan trong nước). Không nên suy diễn tác dụng hạ mỡ máu của một vị thuốc chỉ vì "có chứa β-sitosterol".
> - **Ergosterol** có nhiều trong nấm, kể cả **Linh chi**, **Phục linh**. Đây là tiền chất vitamin D~2~ (cần chiếu UV); hiện chưa đủ bằng chứng để coi các vị này là nguồn vitamin D.

## 4. Phân loại lipid

Giáo trình phân lipid thành **lipid thuần** và **lipid tạp** (Giáo trình tr. 26, 30–31):

- **Lipid thuần**: chỉ gồm **acid béo + alcol** (ester). Gồm **glycerid**, **cerid**, **sterid**.
- **Lipid tạp**: ngoài acid béo và alcol còn có **nhóm hóa học khác** (acid phosphoric, base nitơ, ose…). Chia theo alcol: **glycerophospholipid** (alcol là glycerol) và **sphingolipid** (alcol là sphingosin).

Theo chức năng còn chia: **lipid dự trữ** (trung tính, triacylglycerol) và **lipid màng** (có cực: phospholipid, glycolipid) (Hình 11 của giáo trình, tr. 35).

![Hình 2. Sơ đồ phân loại lipid theo cấu tạo hóa học và theo chức năng](phan-loai.svg)

> [!bay] Phospholipid và glycolipid là cách chia "chéo"
> - **Phospholipid** = lipid có **acid phosphoric**: gồm **mọi glycerophospholipid** và **sphingomyelin** (một sphingolipid).
> - **Glycolipid** = lipid có **ose**: **cerebrosid, sulfatid, gangliosid** (đều là sphingolipid).
> - Vậy **sphingomyelin vừa là sphingolipid vừa là phospholipid**, nhưng **không** phải glycerophospholipid (không có glycerol).

## 5. Lipid thuần

### 5.1. Glycerid (acylglycerol)

Glycerid là **ester của glycerol với acid béo**, còn gọi là **chất béo trung tính** (Giáo trình tr. 30–31). Có trong hầu hết mô, nhiều nhất ở **mô mỡ (khoảng 90%)**. Thành phần acid béo của glycerid động vật và thực vật thường khác nhau.

- Có 1, 2 hay 3 nhóm –OH của glycerol được ester hóa → **mono-, di-, triglycerid** (monoacylglycerol, diacylglycerol, triacylglycerol). Trong tự nhiên mono- và diglycerid chiếm tỷ lệ **rất nhỏ**; dạng dự trữ là **triglycerid**.
- Ba gốc acid béo giống nhau → **glycerid thuần nhất** (ví dụ **tristearin**); khác nhau → **glycerid hỗn hợp** (ví dụ **1,2-distearopalmitin**: stearic ở C1 và C2, palmitic ở C3). Triglycerid chỉ chứa một loại acid béo chiếm tỷ lệ **rất nhỏ** trong tự nhiên.
- Khi gốc acid béo ở C1 và C3 khác nhau, C2 trở thành carbon bất đối, nên triglycerid có **hai dạng đồng phân** (giáo trình gọi là dạng I và dạng II); phần lớn triglycerid tự nhiên ở **dạng II**.

**Vì sao triglycerid là dạng dự trữ năng lượng lý tưởng?** Chuỗi hydrocarbon bị khử gần như hoàn toàn nên oxy hóa cho nhiều năng lượng nhất trên mỗi gam. Triglycerid lại **kỵ nước**, dự trữ ở dạng khan, không kéo theo nước như glycogen. Do đó mỗi gam mô mỡ chứa năng lượng gấp nhiều lần mỗi gam glycogen ngậm nước.

Phản ứng thủy phân, xà phòng hóa glycerid, chỉ số acid, sự ôi hóa dầu mỡ: xem bài *Acid carboxylic, ester* (môn Hóa học).

### 5.2. Cerid (sáp)

Cerid là **ester của acid béo chuỗi dài với alcol bậc cao** (giáo trình ghi 30–40 C) (Giáo trình tr. 31).

- **Động vật**: sáp ong, mỡ cá nhà táng. **Thực vật**: lớp mỏng phủ lá, thân, quả.
- **Vi khuẩn**: vỏ một số vi khuẩn có sáp, ví dụ **vi khuẩn lao** (giáo trình viết "vi khuẩn Kock", đúng là *Koch*). Lớp sáp giúp vi khuẩn **không bị tác dụng bởi acid và alcol**.
- Chức năng chung: **bảo vệ** các tổ chức. **Người và động vật cao cấp không chuyển hóa được cerid.**

> [!bay] Cerid hay serid?
> Giáo trình Hóa sinh viết **cerid**, giáo trình Hóa học viết **serid** — cùng một nhóm chất (sáp, từ Latinh *cera*). Cũng lưu ý: giáo trình ghi alcol của sáp có 30–40 C, nhưng chính ví dụ alcol cetylic chỉ có 16 C. Alcol của sáp tự nhiên dài khoảng 16–36 C.

> [!ung-dung] Vi khuẩn lao "kháng acid – cồn"
> Thành vi khuẩn lao (*Mycobacterium tuberculosis*) rất giàu lipid dạng sáp, chủ yếu là **acid mycolic** (acid béo mạch rất dài). Khi nhuộm **Ziehl–Neelsen**, vi khuẩn đã bắt màu fuchsin thì **không bị acid – cồn tẩy màu** — đây là cơ sở xét nghiệm tìm **AFB** (*acid-fast bacilli*) trong đờm để chẩn đoán lao. Lớp sáp này cũng làm vi khuẩn bền với nhiều thuốc sát khuẩn và thuốc kháng sinh thông thường.

### 5.3. Sterid

Sterid là **ester của acid béo với sterol**, tiêu biểu là cholesterol (Giáo trình tr. 31). Ví dụ: oleatcholesterol, palmitatcholesterol, stearatcholesterol (tên hiện nay: cholesteryl oleat…).

Khi –OH ở C3 bị ester hóa, cholesterol **mất nhóm ưa nước duy nhất**, trở nên **hoàn toàn kỵ nước**. Vì vậy sterid là dạng **dự trữ và vận chuyển** cholesterol: nằm trong giọt mỡ của tế bào và ở **lõi các lipoprotein** trong máu, không nằm ở màng.

## 6. Lipid tạp

### 6.1. Glycerophospholipid

#### 6.1.1. Cấu tạo chung — acid phosphatidic

Glycerophospholipid (glycerophosphatid, diacylphosphatid) là **dẫn xuất của acid phosphatidic** (Giáo trình tr. 32–33).

**Acid phosphatidic** = glycerol + **2 acid béo** (ở C1 và C2) + **1 acid phosphoric** (ester hóa –OH ở **C3**). Nó là một **diacylglycerol** có gắn phosphat ở C3.

- Acid béo ở **C1 thường no** (ví dụ palmitic); ở **C2 thường không no** (ví dụ oleic).
- Acid phosphatidic là **chất trung gian** khi tổng hợp triglycerid và glycerophospholipid, nhưng **có rất ít** ở dạng tự do trong mô.
- Gắn thêm nhóm **X** vào phosphat → các glycerophospholipid khác nhau.

![Hình 3. Phosphatidylcholin (lecithin): đầu phân cực (cholin, phosphat, glycerol) và hai đuôi acid béo kỵ nước; các phân tử tự xếp thành lớp kép trong nước](phospholipid.svg)

**Vì sao phospholipid tạo màng?** Phân tử có một **đầu phân cực** (phosphat mang điện âm, cùng nhóm X) và **hai đuôi kỵ nước** dài. Phân tử như vậy gọi là **lưỡng tính** (*amphipathic*). Trong nước, các đuôi tự quay vào nhau để tránh nước, còn các đầu hướng ra nước → tự xếp thành **lớp kép lipid** — nền của mọi màng sinh học. Đuôi C2 không no, gấp khúc, giúp màng **lỏng** ở thân nhiệt. Cấu trúc và tính chất màng đã học ở bài *Màng tế bào* (môn Sinh học).

Bảng 2.3 của giáo trình (tr. 32):

| Nhóm X | Glycerophospholipid | Điện tích ở pH 7 |
|---|---|---|
| –H | Acid phosphatidic | −1 |
| Cholin –CH~2~–CH~2~–N^+^(CH~3~)~3~ | **Phosphatidylcholin (lecithin)** | **0** |
| Ethanolamin –CH~2~–CH~2~–NH~2~ | **Phosphatidylethanolamin (cephalin)** | **0** |
| Serin –CH~2~–CH(NH~2~)–COO^−^ | Phosphatidylserin | −1 |
| Inositol (vòng 6C, nhiều –OH) | Phosphatidylinositol | −1 |
| Glycerol | Phosphatidylglycerol | −1 |
| Phosphatidylglycerol | **Cardiolipin** (diphosphatidylglycerol) | **−2** |

**Cách nhớ điện tích:** phosphat luôn góp **−1**. Cholin và ethanolamin góp **+1** → tổng **0** (lưỡng cực, trung hòa). Serin góp cả +1 (–NH~3~^+^) và −1 (–COO^−^) → tổng **−1**. Inositol, glycerol không mang điện → **−1**. Cardiolipin có **2 phosphat** → **−2**.

#### 6.1.2. Phosphatidylcholin (lecithin)

- X = **cholin**.
- Lecithin được chiết từ **lòng đỏ trứng** (năm 1843). Phổ biến trong tế bào động vật, đặc biệt ở **tế bào gan, não, lòng đỏ trứng**.
- Là phospholipid **nhiều nhất** của màng tế bào người.

> [!ung-dung] Chất hoạt diện phổi — DPPC
> - Chất hoạt diện phổi (*surfactant*) do **tế bào phế nang type II** tiết ra. Thành phần chính là một lecithin đặc biệt: **dipalmitoylphosphatidylcholin (DPPC)** — **cả C1 và C2 đều là acid palmitic** (no). Cơ chế vật lý (giảm sức căng bề mặt, định luật Laplace) đã học ở bài *Chuyển động trong cơ thể sống* (môn Vật lý).
> - **Vì sao phải là hai đuôi no?** Hai chuỗi palmitic thẳng xếp được rất khít ở mặt phân cách khí – nước. Khi phế nang nhỏ lại cuối thì thở ra, lớp DPPC bị nén chặt mà không bị đẩy ra, nên sức căng bề mặt giảm gần về 0 và phế nang không xẹp.
> - **Trẻ sinh non** thiếu surfactant → **hội chứng suy hô hấp sơ sinh** (bệnh màng trong). Phòng bằng **corticoid** tiêm cho mẹ trước sinh (thúc đẩy tế bào type II trưởng thành); điều trị bằng surfactant bơm vào khí quản.
> - Xét nghiệm kinh điển đánh giá phổi thai trưởng thành: **tỷ số lecithin/sphingomyelin (L/S) trong nước ối ≥ 2**.

> [!bay] "Acid béo ở C2 thường không no" — có ngoại lệ
> DPPC của surfactant có acid béo **no ở cả C1 và C2**. Đây là ngoại lệ có ý nghĩa chức năng, hay được hỏi trong câu tình huống.

#### 6.1.3. Phosphatidylethanolamin (cephalin)

- Khác lecithin ở chỗ X = **ethanolamin**.
- Được chiết đầu tiên **từ não**.
- Giáo trình nêu cephalin (cũng như lecithin) có **dạng α và dạng β**, tùy acid phosphoric–ethanolamin gắn vào **C α hay C β** của glycerol.

#### 6.1.4. Phosphatidylserin

- X = **serin** (một acid amin). Acid béo thường là **stearic và oleic**.
- Chiếm khoảng **5% glycerophospholipid của não**. Trong tự nhiên còn có phospholipid chứa acid amin **threonin**.

> [!ung-dung] Phosphatidylserin — tín hiệu "ăn tôi" và đông máu
> Bình thường phosphatidylserin nằm ở **lớp trong** của màng tế bào. Khi tế bào **chết theo chương trình** (apoptosis), nó bị lật ra **lớp ngoài**, làm tín hiệu cho đại thực bào đến dọn. Ở **tiểu cầu hoạt hóa**, phosphatidylserin lộ ra mặt ngoài tạo "bề mặt mang điện âm" để các yếu tố đông máu (cần Ca^2+^) tập hợp lại và hoạt động.

#### 6.1.5. Phosphatidylinositol

- X = **inositol** (vòng 6 cạnh, mỗi C mang một –OH). Có ở mô động vật (não) và thực vật (đậu tương, lạc, mầm lúa mì).
- Nhờ nhiều nhóm –OH nên đầu phân cực rất **ưa nước**.
- Ý nghĩa (bổ sung): dạng phosphoryl hóa của nó là **PIP~2~**. Khi hormon gắn thụ thể, enzym phospholipase C cắt PIP~2~ thành **IP~3~** và **diacylglycerol** — hai **chất truyền tin thứ hai** (học ở chương *Hormon*).

> [!bay] Inositol có mấy –OH tự do?
> Giáo trình viết "phosphatidyl có 6 gốc –OH". Inositol tự do có **6 –OH**; nhưng trong phosphatidylinositol, **1 –OH đã liên kết với phosphat**, nên chỉ còn **5 –OH tự do**.

#### 6.1.6. Diphosphatidylglycerol (cardiolipin)

- Gồm **2 acid phosphatidic** nối với nhau qua **1 glycerol** → có **4 gốc acid béo** và **2 phosphat** (điện tích −2).
- Có trong **ty thể**, **đặc trưng cho màng trong ty thể** (nơi có chuỗi hô hấp).

> [!ung-dung] Cardiolipin trong xét nghiệm
> - Kháng nguyên của xét nghiệm giang mai không đặc hiệu **VDRL/RPR** là hỗn hợp **cardiolipin – lecithin – cholesterol**: người nhiễm giang mai có kháng thể phản ứng với cardiolipin.
> - **Kháng thể kháng cardiolipin** là một xét nghiệm trong chẩn đoán **hội chứng kháng phospholipid** (huyết khối, sảy thai liên tiếp).

#### 6.1.7. Plasmalogen

- Chiếm khoảng **10% phospholipid của não và cơ**.
- Điểm khác biệt: ở **C1 (α)** không phải liên kết **ester** mà là liên kết **ether** giữa –OH của glycerol với một **gốc alcol không no** (dạng –O–CH=CH–R). C2 vẫn là ester với acid béo; X thường là cholin hoặc ethanolamin.

| | Glycerophospholipid thường | Plasmalogen |
|---|---|---|
| C1 | –O–CO–R (ester) | **–O–CH=CH–R (ether, không no)** |
| C2 | Ester với acid béo | Ester với acid béo |
| C3 | Phosphat–X | Phosphat–X |

### 6.2. Sphingolipid — cấu tạo chung

Sphingolipid có alcol là **sphingosin** (aminoalcol 18C). Chúng là thành phần quan trọng của **màng tế bào động vật và thực vật**, đặc biệt ở **mô não và mô thần kinh** (Giáo trình tr. 34–35).

- **Ceramid** = sphingosin + acid béo, nối qua **nhóm –NH~2~** của sphingosin bằng **liên kết amid**. Acid béo thường là **lignoceric** (24:0), **cerebronic**…
- **Ceramid là đơn vị cơ bản** của mọi sphingolipid. Gắn thêm nhóm **X** vào –OH ở **C1** của ceramid → các sphingolipid khác nhau.

**So sánh với glycerophospholipid:** phần "đầu" của sphingosin (C1–C3) giống khung glycerol; chuỗi hydrocarbon dài của sphingosin đóng vai trò **đuôi kỵ nước thứ nhất**, acid béo gắn qua liên kết amid là **đuôi thứ hai**. Vì vậy sphingolipid cũng có hình dạng "một đầu – hai đuôi" và tham gia tạo màng.

Bảng 2.4 của giáo trình (tr. 34):

| Nhóm X gắn vào C1 của ceramid | Sphingolipid | Nhóm |
|---|---|---|
| –H | **Ceramid** | Khung chung |
| Phosphocholin | **Sphingomyelin** | Phospholipid |
| Glucose (hoặc galactose) | **Cerebrosid** (glucosylcerebrosid, galactosylcerebrosid) | Glycolipid trung tính |
| Di-, tri- hoặc tetrasaccharid | Ví dụ **lactosylceramid** (Glc–Gal) | Glycolipid trung tính |
| Oligosaccharid có acid sialic | **Gangliosid** | Glycolipid có tính acid |

> [!bay] Ghi nhớ nhanh
> - Glycerophospholipid: acid béo nối với alcol bằng **liên kết ester**. Sphingolipid: acid béo nối với sphingosin bằng **liên kết amid**.
> - Ose phổ biến trong glycolipid: **galactose, glucose, galactosamin**.
> - Sulfatid là dẫn xuất sulfat của cerebrosid; gangliosid có thêm **acid sialic** — nên hai chất này mang điện âm.

### 6.3. Các sphingolipid chính

#### 6.3.1. Sphingomyelin

- **Ceramid + phosphocholin** gắn vào –OH bậc nhất ở **C1**.
- Thuộc nhóm **phospholipid**. Chiết được từ **phổi, lách, não và mọi tế bào thần kinh**; có nhiều trong **bao myelin**.

#### 6.3.2. Cerebrosid

- Gồm **sphingosin + acid béo cao phân tử + một ose (thường là galactose)**; **không có acid phosphoric**.
- Acid béo của cerebrosid thường **24C**: lignoceric, cerebronic, nervonic, hydroxynervonic. Tên cerebrosid theo acid béo: **kerasin** (chứa acid lignoceric), **cerebron** (chứa acid cerebronic)…
- Có chủ yếu ở **não và mô thần kinh**.

> [!bay] Galactose hay glucose?
> Phần lời của giáo trình nói cerebrosid chứa **galactose** (đó là **galactocerebrosid**, chủ yếu ở myelin của não). Bảng 2.4 lại lấy ví dụ **glucosylcerebrosid** (có nhiều ở mô ngoài thần kinh). Cả hai đều là cerebrosid — **một ose, không phosphat**. Bệnh Gaucher liên quan đến **glucocerebrosid** (xem dưới).

#### 6.3.3. Sulfatid

**Dẫn xuất sulfat của cerebrosid**: nhóm sulfat thường gắn ở **C3 của galactose**. Sulfatid có nhiều ở myelin.

#### 6.3.4. Gangliosid

- Là **glycosylceramid phức tạp**: sphingosin + acid béo 22 hoặc 24C + **acid neuraminic** và dẫn xuất (**acid N-acetylneuraminic = acid sialic**) + khoảng 3 ose (galactose, glucose, galactosamin).
- Chiếm khoảng **6% lipid màng của chất xám** não người; có ít hơn ở lách, hồng cầu.
- Có nhiều ở **đầu tận cùng dây thần kinh**, tham gia **dẫn truyền xung động thần kinh**.
- Gangliosid ví dụ trong Bảng 2.4 (Glc–Gal(–acid sialic)–GalNAc gắn trên ceramid) chính là **gangliosid GM2** — chất tích lũy trong bệnh Tay–Sachs.

> [!ung-dung] Bệnh tích lũy sphingolipid (sphingolipidosis)
> Sphingolipid được phân giải dần trong **lysosom**, mỗi bước cắt một nhóm nhờ một enzym riêng. **Thiếu bẩm sinh một enzym** → chất nền của enzym đó **ứ đọng** trong lysosom, tế bào phình to và tổn thương. Hầu hết di truyền **lặn trên nhiễm sắc thể thường** (riêng Fabry liên kết X).
>
> | Bệnh | Enzym thiếu | Chất tích lũy | Biểu hiện chính |
> |---|---|---|---|
> | **Gaucher** (hay gặp nhất) | **Glucocerebrosidase** (β-glucosidase acid) | **Glucocerebrosid** | **Gan, lách to**, tổn thương xương, thiếu máu, giảm tiểu cầu; "tế bào Gaucher" (đại thực bào chứa đầy lipid) |
> | **Tay–Sachs** | **Hexosaminidase A** | **Gangliosid GM2** | Thoái hóa thần kinh từ vài tháng tuổi, mù, **vết đỏ anh đào ở hoàng điểm**; không có gan lách to; thường tử vong sớm |
> | Niemann–Pick (A, B) | Sphingomyelinase | **Sphingomyelin** | Gan lách to; thể A tổn thương thần kinh nặng |
> | Loạn dưỡng chất trắng biến sắc | Arylsulfatase A | **Sulfatid** | Mất myelin |
> | Krabbe | Galactocerebrosidase | Galactocerebrosid | Mất myelin |
> | Fabry | α-galactosidase A | Globotriaosylceramid | Đau rát đầu chi, suy thận (liên kết X) |
>
> Điều trị: bệnh Gaucher type 1 được điều trị hiệu quả bằng **liệu pháp thay thế enzym** (truyền glucocerebrosidase tái tổ hợp). Tay–Sachs hiện chưa có điều trị đặc hiệu; phòng bằng **sàng lọc người mang gen** và tư vấn di truyền.

## Tóm tắt

| Chủ đề | Ghi nhớ |
|---|---|
| Định nghĩa | Ester/amid của **acid béo** với **alcol/aminoalcol**; không tan trong nước; 9,3 kcal/g |
| Acid béo no | C~n~H~2n+1~COOH; palmitic 16:0, stearic 18:0; chuỗi dài → t°nc cao |
| Acid béo không no | Oleic 18:1 Δ^9^ (ω-9) · linoleic 18:2 Δ^9,12^ (ω-6) · linolenic 18:3 Δ^9,12,15^ (ω-3) · arachidonic 20:4 Δ^5,8,11,14^ (ω-6); tự nhiên là **cis** → gấp khúc → t°nc thấp |
| Thiết yếu | **Linoleic, linolenic** (người không tạo nối đôi quá Δ^9^) |
| Acid béo đặc biệt | Cerebronic (–OH ở Cα, 24C, ở não); prostanoic (vòng 5 cạnh, 20C) → **prostaglandin** từ arachidonic |
| Trans | Elaidic; hydro hóa một phần dầu; ↑LDL, ↓HDL |
| Alcol | Glycerol (α, β, α′) · alcol bậc cao (sáp) · aminoalcol: **sphingosin, cholin, ethanolamin, serin** · sterol: **cholesterol** (27C, –OH C3, nối đôi C5–C6, CH~3~ ở C10 và C13, nhánh 8C ở C17) |
| Lipid thuần | **Glycerid** (glycerol; triglycerid dự trữ ở mô mỡ) · **cerid** (sáp; người không chuyển hóa) · **sterid** (cholesterol ester) |
| Glycerophospholipid | Acid phosphatidic (C1 no, C2 không no, PO~4~ ở C3) + X: **cholin → lecithin (0)**, **ethanolamin → cephalin (0)**, serin (−1), inositol (−1), glycerol (−1), **cardiolipin (−2, màng trong ty thể)**; **plasmalogen**: liên kết **ether** ở C1 |
| Sphingolipid | **Ceramid** (sphingosin + acid béo, **liên kết amid**) + X: phosphocholin → **sphingomyelin**; ose → **cerebrosid**; + sulfat → **sulfatid**; oligosaccharid + acid sialic → **gangliosid** |
| Y học | **DPPC** – surfactant, bệnh màng trong, tỷ số L/S · **Gaucher** (glucocerebrosid) · **Tay–Sachs** (GM2) · cardiolipin – VDRL · dầu cá ω-3 giảm TG · NSAID ức chế COX |
