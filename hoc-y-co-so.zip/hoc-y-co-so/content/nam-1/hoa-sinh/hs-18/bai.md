---
title: Hóa sinh thận và nước tiểu
thoi-gian: 45 phút
muc-tieu:
- Trình bày được chức năng bài tiết của thận — lọc ở cầu thận (áp lực lọc, các yếu tố quyết định chất nào qua được màng lọc) và tái hấp thu, bài tiết ở ống thận (glucose, nước, Na^+^, ure, acid uric, creatinin, protein).
- Trình bày được vai trò của thận trong thăng bằng acid – base qua 3 cơ chế bài tiết H^+^.
- Nêu được chức năng chuyển hóa và nội tiết của thận — hệ renin – angiotensin – aldosteron, erythropoietin, prostaglandin, vitamin D~3~, ANF.
- Nêu được tính chất chung, thành phần bình thường của nước tiểu và trình bày được các chất bất thường trong nước tiểu cùng ý nghĩa bệnh lý.
- Đọc được các xét nghiệm cơ bản về chức năng thận — ure, creatinin, độ thanh thải, eGFR, que thử nước tiểu 10 thông số.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Đơn vị chức năng là **nephron** (≈1 triệu/thận). Cầu thận **lọc** khoảng **180 L/ngày** nhờ áp lực lọc hiệu dụng **Pf = Pg − (Po + Pc) = 50 − (25 + 5) = 20 mmHg**; ống thận **tái hấp thu** gần hết, chỉ còn ≈1–1,5 L nước tiểu.
> 2. Màng lọc chặn chất theo **kích thước**, **điện tích** (màng tích điện **âm** đẩy albumin) và **hình dạng**. Protein lọc qua được ống lượn gần **tái hấp thu** (ẩm bào → lysosom), nên nước tiểu bình thường gần như **không có protein**.
> 3. **Glucose** tái hấp thu **hoàn toàn** (đồng vận chuyển với Na^+^); vượt **ngưỡng thận ≈1,7 g/L** thì xuất hiện glucose niệu. Nước tái hấp thu **99%**; phần cuối phụ thuộc **ADH**.
> 4. Thận chống toan bằng **3 cơ chế**: tái hấp thu HCO~3~^−^ (ống lượn gần), thải H^+^ dạng **muối acid** (HPO~4~^2−^ → H~2~PO~4~^−^) và dạng **muối amoni** (NH~3~ từ glutamin). Thận còn là tuyến nội tiết: **renin**, **erythropoietin**, **1,25-(OH)~2~D~3~**, prostaglandin.
> 5. Nước tiểu bất thường: **glucose, protein, thể ceton, sắc tố mật – muối mật, hồng cầu – hemoglobin, porphyrin, dưỡng chấp, nitrit**. Chức năng lọc đánh giá bằng **creatinin máu → eGFR**, kèm **albumin niệu**.

## 1. Thận — cấu tạo và các chức năng

### 1.1. Vài con số về thận

- Hai thận người trưởng thành nặng khoảng **300 g**, chỉ bằng **0,5%** khối lượng cơ thể, nhưng dùng tới **8–10% oxy** của toàn cơ thể (Giáo trình tr. 290).
- Mỗi ngày khoảng **1.000–1.500 lít máu** chảy qua thận. Chỉ **10%** để nuôi thận; **90%** phục vụ nhiệm vụ bài tiết.
- Mỗi thận có khoảng **1 triệu nephron**. Mỗi nephron gồm: **cầu thận** (búi mao mạch được bao **Bowman** bọc ngoài) và **ống thận** (ống lượn gần → quai Henle → ống lượn xa → ống góp).

**Vì sao một cơ quan nhỏ lại "ăn" nhiều oxy như vậy?** Thận lọc khoảng 180 L dịch mỗi ngày, rồi phải **bơm ngược** gần như toàn bộ Na^+^, glucose, acid amin (amino acid), HCO~3~^−^ về máu. Phần lớn các bước này dựa vào **bơm Na^+^-K^+^-ATPase**, nên tốn rất nhiều ATP (xem mục 1.3.4).

Giáo trình kể **4 chức năng** của thận:

| Chức năng | Nội dung chính | Mục |
|---|---|---|
| **Bài tiết** | Thải chất cặn bã bằng **lọc** (cầu thận) và **tái hấp thu – bài tiết** (ống thận) | 1.2, 1.3 |
| **Chuyển hóa** | Chuyển hóa glucid, lipid, protein; tổng hợp **acid hippuric**, **urocrom** | 1.4 |
| **Điều hòa acid – base** | Bài tiết H^+^, giữ HCO~3~^−^ | 1.5 |
| **Nội tiết** | Renin, erythropoietin, prostaglandin, vitamin D~3~ hoạt động | 1.6 |

![Hình 1. Sơ đồ một nephron: các đoạn và chất chính được lọc, tái hấp thu (↩, từ lòng ống về máu) hay bài tiết (↪, từ máu vào lòng ống). Màu nhấn: các bước chịu điều hòa của hormon.](nephron.svg)

### 1.2. Sự lọc ở cầu thận

#### a) Áp lực lọc hiệu dụng

Nước tiểu được tạo qua hai giai đoạn: **siêu lọc** ở cầu thận, rồi **tái hấp thu** (và bài tiết) ở ống thận. Mỗi ngày có tới **180 lít nước tiểu ban đầu** (dịch lọc trong bao Bowman).

Dịch bị đẩy qua màng lọc nhờ **áp lực lọc hiệu dụng Pf**:

=> Pf = Pg − (Po + Pc)

| Ký hiệu | Là gì | Tác dụng | Giá trị (giáo trình) |
|---|---|---|---|
| **Pg** | Áp suất thủy tĩnh trong mao mạch cầu thận | **Đẩy** nước vào bao Bowman | 50 mmHg |
| **Po** | Áp suất keo (do protein) của huyết tương | **Hút** nước giữ lại trong mạch | 25 mmHg |
| **Pc** | Áp suất thủy tĩnh trong bao Bowman | **Cản** dịch đi vào bao | 5 mmHg |

=> Pf = 50 − (25 + 5) = 20 mmHg

> [!ung-dung] Vì sao tụt huyết áp gây vô niệu?
> Pg xấp xỉ **một nửa huyết áp động mạch**. Khi huyết áp chỉ còn **60–70 mmHg**, Pg giảm còn 30–35 mmHg, tức gần bằng tổng Po + Pc. Lúc đó Pf ≈ 0 nên cầu thận **gần như ngừng lọc**, gây **vô niệu** (Giáo trình tr. 291). Đây là lý do bệnh nhân sốc (mất máu, bỏng nặng, sốc nhiễm khuẩn) phải được theo dõi **lượng nước tiểu mỗi giờ**: nước tiểu là "chỉ số" tưới máu thận.
>
> Bổ sung: trong khoảng huyết áp trung bình **≈ 80–180 mmHg**, thận **tự điều hòa** (cơ trơn tiểu động mạch đến co – giãn, phản hồi ống – cầu thận) nên lưu lượng máu thận và mức lọc gần như **không đổi**. Chỉ khi huyết áp xuống dưới ngưỡng này, Pg mới giảm theo huyết áp như mô tả ở trên.
>
> Suy luận ngược lại (về lý thuyết): **Po giảm** (protein máu thấp, như hội chứng thận hư, xơ gan) thì Pf tăng; **Pc tăng** (sỏi, u gây tắc đường tiểu) thì Pf giảm.

#### b) Chất nào qua được màng lọc?

Màng lọc cầu thận cho **nước và các chất phân tử nhỏ** qua dễ dàng nhưng **giữ lại phân tử lớn**. Vì thế **dịch lọc ban đầu có thành phần giống huyết tương, trừ protein**. Theo giáo trình, protein có trọng lượng phân tử (TLPT) khoảng **70.000** trở lên không qua được.

Màng lọc gồm **3 lớp** (Giáo trình tr. 292):

| Lớp | Đặc điểm |
|---|---|
| **Lớp nội mô** (endothelium) — sát lòng mao mạch | Có các **cửa sổ** đường kính 500–1000 Å |
| **Màng đáy** (lớp giữa) | Gồm 3 lớp, dày khoảng 3200 Å; mang nhiều **điện tích âm** |
| **Lớp biểu mô** (epithelium, tế bào có chân) — sát bao Bowman | Giữa các chân có **khe lọc** 250–500 Å |

Phân tử đi qua cửa sổ nội mô, qua màng đáy, rồi qua khe lọc. **Màng đáy và khe lọc** là hai chỗ cản trở chính.

Có **4 yếu tố** quyết định một phân tử lớn có lọc qua được hay không:

1. **Kích thước phân tử.** Người ta đo **hệ số lọc**: inulin có hệ số lọc = 1 (qua hoàn toàn). Dextran đường kính 20 Å cũng có hệ số = 1; kích thước tăng dần thì hệ số giảm dần, đến **42 Å thì gần bằng 0**.
2. **Huyết động tại chỗ (lưu lượng máu).** Lượng máu qua thận rất lớn: tính theo khối lượng mô, gấp **8 lần** qua mạch vành và **400 lần** qua cơ xương lúc nghỉ; vùng **vỏ** nhận nhiều máu hơn vùng tủy. Khi **giảm** lưu lượng máu cầu thận thì phân tử lớn lại **lọt qua nhiều hơn**. Thí nghiệm truyền angiotensin II cho chuột: lưu lượng máu thận giảm, độ thanh thải albumin tăng, gây protein niệu. Điều này giải thích **protein niệu ở người tăng huyết áp**.
3. **Điện tích.** Ở cùng kích thước (35 Å), hệ số lọc của **albumin chỉ 0,0375**, trong khi của **dextran trung tính là 0,24**. Albumin ở pH máu là một **polyanion** (mang điện âm), và hệ số lọc của nó gần bằng dextran sulfat (cũng mang điện âm). Thứ tự hệ số lọc: **dextran dương > trung tính > âm**.
4. **Hình dạng.** Phân tử **mềm dẻo**, dễ biến dạng thì lọc qua dễ hơn phân tử cứng cùng kích thước.

**Vì sao màng lọc "ghét" điện tích âm?** Màng đáy và bề mặt tế bào nội mô, biểu mô được phủ các phân tử **mang điện âm**: glycoprotein giàu **acid sialic** và đặc biệt là **proteoglycan heparan sulfat** (giáo trình ghi *heparin sulfat*). Lớp polyanion này **đẩy tĩnh điện** các protein mang điện âm như albumin. Như vậy màng lọc vừa là **rây lọc theo kích thước**, vừa là **hàng rào tĩnh điện**.

> [!bay]
> - Giáo trình lấy ví dụ: **hemoglobin** (TLPT ≈70.000 theo sách) tiêm tĩnh mạch được thải nhanh ra nước tiểu, trong khi **albumin** nhỏ hơn (68.000) lại không bị thải. Lý do sâu hơn: Hb tự do trong huyết tương **tách thành dimer αβ** (≈32.000) nhỏ hơn nhiều; còn albumin bị **điện tích âm** của màng giữ lại. Nghĩa là **không chỉ kích thước** quyết định.
> - **Inulin** có hệ số lọc = 1 và **không** được tái hấp thu, không bị bài tiết. Đừng nhầm "hệ số lọc" (tỷ lệ nồng độ dịch lọc/huyết tương) với "độ thanh thải" (mục 5.1).

> [!ung-dung] Khi hàng rào điện tích bị phá
> Trong nhiều bệnh cầu thận (điển hình là **hội chứng thận hư**), màng lọc **mất điện tích âm** hoặc tổn thương các chân tế bào biểu mô. Albumin lọt qua hàng loạt, gây **protein niệu nhiều** (> 3,5 g/24 giờ ở người lớn), protein máu giảm, Po giảm, nước thoát ra mô gây **phù**. Nước tiểu nhiều protein nên **nổi bọt** (mục 2.2).

### 1.3. Tái hấp thu và bài tiết ở ống thận

Ống thận được lót bởi một lớp tế bào có **diềm bàn chải** (nhung mao) giúp tăng diện tích hấp thu. Mỗi chất có "số phận" khác nhau trong ống thận. Giáo trình xếp thành **6 nhóm** (Giáo trình tr. 293–294):

#### 1.3.1. Chất không được tái hấp thu

**Inulin, mannitol, natri hyposulfit** (natri thiosulfat) được lọc qua cầu thận nhưng **không** được tái hấp thu. Vì vậy, đo **độ thanh thải** của chúng cho biết **mức lọc của cầu thận** (mục 5.1).

#### 1.3.2. Tái hấp thu hoàn toàn: glucose

- Cầu thận lọc khoảng **150 g glucose/24 giờ**, nhưng nước tiểu chỉ còn khoảng **6 mg/24 giờ**: hầu như **toàn bộ** được tái hấp thu ở **ống lượn gần**.
- Đây là **vận chuyển tích cực**, cần năng lượng (ATP), theo kiểu **đồng vận chuyển** (co-transport) **cùng với Na^+^**.
- Glucose **không bị phosphoryl hóa** và mạch carbon **không bị biến đổi** khi qua màng.
- Vị trí vận chuyển bị **ức chế cạnh tranh** bởi **D-galactose, D-mannose** và **phlorizin** (giáo trình viết *ploridin*).

**Vì sao có "ngưỡng thận"?** Số chất vận chuyển trên màng ống lượn gần có hạn. Khi glucose máu vượt khoảng **1,7 g/L** (≈ 9,4 mmol/L; nhiều tài liệu lấy ≈ 10 mmol/L), lượng glucose lọc ra vượt **khả năng tái hấp thu tối đa**, phần thừa "tràn" ra nước tiểu (mục 4.1).

> [!cap-nhat] Chất đồng vận chuyển Na^+^-glucose là SGLT
> Giáo trình viết tái hấp thu glucose "cần năng lượng là ATP". Hiện nay biết rõ đây là **vận chuyển chủ động thứ phát**: protein **SGLT2** (ở đầu ống lượn gần, tái hấp thu ≈90% glucose) và **SGLT1** (đoạn sau, ≈10%) đưa Na^+^ và glucose cùng vào tế bào. ATP chỉ dùng **gián tiếp** cho bơm Na^+^-K^+^ ở mặt đáy để duy trì gradient Na^+^. Glucose ra khỏi tế bào về máu qua **GLUT2** (khuếch tán thuận hóa). Cơ chế chung: xem sh-04 (*Vận chuyển vật chất qua màng tế bào*).
>
> Thú vị: **phlorizin** (glycosid có trong vỏ rễ cây táo) chính là "tổ tiên" của nhóm thuốc **ức chế SGLT2** (dapagliflozin, empagliflozin…). Các thuốc này cố ý gây **glucose niệu** để hạ đường huyết, và còn bảo vệ thận, tim. Vì vậy người dùng thuốc này có **glucose niệu dương tính dù đường huyết bình thường** — không phải dấu hiệu bệnh nặng thêm.

#### 1.3.3. Tái hấp thu 99%: nước

- **Ống lượn gần**: tái hấp thu khoảng **80%** nước (giáo trình), gọi là tái hấp thu **"bắt buộc"** vì nước đi **theo Na^+^**. Na^+^, Cl^−^ và nước được hấp thu theo tỷ lệ tương đương, nên dịch ở đây **không bị cô đặc hay pha loãng**.
- **Quai Henle và ống lượn xa** (và ống góp): tái hấp thu tiếp **90%** lượng nước còn lại. Phần này **phụ thuộc ADH** (hormon chống bài niệu), hormon gắn vào thụ thể đặc hiệu trên màng ống thận. Đây là tái hấp thu **"tùy nghi"**, giúp cơ thể điều chỉnh nước tiểu đặc hay loãng.

> [!bay]
> Nước tiểu ban đầu 180 L, nước tiểu cuối ≈1,5 L: thận tái hấp thu **≈99%** nước. Phần lớn (ống lượn gần) là **bắt buộc**, không điều hòa được; chỉ phần cuối (ống xa – ống góp) mới chịu **ADH**. Thiếu ADH (đái tháo nhạt) thì mất phần "tùy nghi" này, nước tiểu có thể lên tới hàng chục lít/ngày, **tỷ trọng rất thấp**. Sách hiện đại thường ghi ống lượn gần hấp thu ≈65–70% nước; đi thi dùng số của giáo trình (80%).

#### 1.3.4. Tái hấp thu phần lớn: Na^+^, Cl^−^, ure

**Natri**

- **Ống lượn gần** hấp thu khoảng **70%** muối, tương đương **16.800 mEq Na^+^/24 giờ**. Khi lưu lượng máu qua thận **giảm** (hạ huyết áp, giảm thể tích máu), ống lượn gần **tăng** tái hấp thu Na^+^ để giữ muối; và ngược lại.
- Nephron ở **vùng vỏ sâu** (gần tủy, áp lực động mạch thận thấp hơn) hấp thu muối nhiều hơn nephron vỏ nông (giáo trình gọi nephron vỏ nông là "nephron mất muối").
- **Ống lượn xa**: hấp thu hơn **10%** Na^+^, chịu ảnh hưởng của **renin, angiotensin II, aldosteron**.
- **Ống góp** cũng hấp thu Na^+^ dưới tác dụng của **aldosteron**.
- Cuối cùng nước tiểu chỉ còn **100–150 mEq Na^+^/24 giờ**.
- Tái hấp thu Na^+^ là quá trình tích cực, tốn năng lượng tương đương **24 g glucose/24 giờ**, chiếm **90% lượng oxy** thận tiêu thụ.

**Clo**: Cl^−^ được tái hấp thu **thụ động**, đi song song với Na^+^. Giáo trình viết: ở quai Henle, Na^+^ được tái hấp thu thụ động theo gradient điện thế do Cl^−^ tạo ra.

> [!cap-nhat] Nhánh lên dày của quai Henle hấp thu muối chủ động
> Hiện nay biết ở **nhánh lên dày quai Henle**, protein **đồng vận chuyển Na^+^-K^+^-2Cl^−^ (NKCC2)** đưa muối vào tế bào một cách **chủ động thứ phát** (nhờ gradient Na^+^ của bơm Na-K). Đoạn này **không thấm nước**, nên dịch trong ống bị pha loãng còn mô kẽ tủy thận trở nên ưu trương — nền tảng của khả năng **cô đặc nước tiểu**. Thuốc lợi tiểu mạnh **furosemid** chặn NKCC2. Ở ống lượn xa, **thiazid** chặn đồng vận chuyển Na^+^-Cl^−^; ở ống góp, **spironolacton** đối kháng aldosteron. Đi thi trả lời theo giáo trình.

**Ure** được tái hấp thu **40–50%**, hoàn toàn **thụ động**, phụ thuộc nồng độ ure trong máu (và lưu lượng nước tiểu). Nguồn gốc ure: chu trình ure ở gan (xem hs-09).

#### 1.3.5. Chất được lọc, bài tiết và tái hấp thu: acid uric, creatinin

- **Acid uric**: cầu thận lọc khoảng 6 mg/phút; ống thận cũng **bài tiết** thêm; rồi **95–98%** được tái hấp thu. Lượng thải ra khoảng **0,33 mg/phút**, giáo trình quy ra khoảng **600 mg/24 giờ** (tính đúng thì 0,33 × 1440 ≈ 475 mg; acid uric niệu người lớn thường khoảng 400–800 mg/24 giờ, khớp Bảng 18.1). Vì thận thải acid uric qua cả ba quá trình, nhiều thuốc và tình trạng (lợi tiểu thiazid, toan ceton, rượu) làm **giảm thải** acid uric, dễ gây cơn **gout**.
- **Creatinin**: được lọc qua cầu thận. Nồng độ creatinin được coi là **dấu hiệu theo dõi chức năng thận**.

> [!cap-nhat] Creatinin được bài tiết thêm, không phải tái hấp thu
> Giáo trình viết creatinin "cũng được tái hấp thu ở ống thận". Hiện nay đồng thuận: creatinin **hầu như không được tái hấp thu**, mà còn được ống lượn gần **bài tiết thêm** khoảng 10–20% (qua chất vận chuyển cation hữu cơ). Vì vậy **độ thanh thải creatinin hơi cao hơn** mức lọc cầu thận thật. Một số thuốc (trimethoprim, cimetidin, một số thuốc chống virus) cạnh tranh chỗ bài tiết này, làm creatinin máu **tăng nhẹ mà thận không hề tổn thương**.

#### 1.3.6. Tái hấp thu protein

- Thận tái hấp thu **phần lớn** protein đã lọc qua: **99% albumin** lọt qua cầu thận được tái hấp thu ở **ống lượn gần**.
- Protein **TLPT nhỏ** (chuỗi nhẹ lambda, kappa; lysozym; **β~2~-microglobulin**; hormon) lọc qua dễ, rồi cũng được tái hấp thu gần hết ở ống lượn gần.
- **Cơ chế**: protein gắn vào **diềm bàn chải** → được **ẩm bào** vào trong không bào → hòa vào **lysosom** → bị **hydrolase** của lysosom thủy phân thành acid amin → acid amin trở về máu. Quá trình kéo dài vài phút đến vài giờ.
- **Hệ quả chuyển hóa**: với albumin và protein lớn, lọc qua rất ít, nên **cắt bỏ hai thận** (thí nghiệm trên chuột) gần như **không đổi** thời gian bán hủy của chúng. Ngược lại, protein nhỏ lọc rất dễ, nên mất thận thì **thời gian bán hủy tăng rõ** — thận là "nơi tiêu hủy" chính của protein nhỏ.
- Nhờ tái hấp thu, nước tiểu người khỏe chứa rất ít protein; xét nghiệm thông thường **không phát hiện được** và coi là **không có protein**.

> [!vi-du] Protein niệu "cầu thận" hay "ống thận"?
> Từ hai bước lọc – tái hấp thu, có thể suy ra hai kiểu protein niệu:
> - **Tổn thương cầu thận**: màng lọc hở → **albumin** (protein lớn) lọt qua nhiều, vượt khả năng tái hấp thu. Protein niệu chủ yếu là albumin, có thể rất nhiều.
> - **Tổn thương ống thận** (ngộ độc kim loại nặng, một số thuốc, độc chất thực vật): cầu thận lọc bình thường nhưng ống lượn gần **không thu hồi được** protein nhỏ → nước tiểu có **β~2~-microglobulin**, chuỗi nhẹ, lysozym; lượng protein thường **ít**.
> - Còn **protein niệu "tràn"**: máu có quá nhiều protein nhỏ (đa u tủy xương sinh chuỗi nhẹ) vượt khả năng tái hấp thu → **protein Bence Jones** (mục 4.2).

### 1.4. Chức năng chuyển hóa

Chuyển hóa ở thận rất mạnh để cung cấp năng lượng cho chính thận (thận dùng ≈10% oxy cơ thể) (Giáo trình tr. 295):

- **Glucid**: chủ yếu theo con đường **đường phân**; chu trình pentose phosphat yếu. Các ester phosphoryl (hexose phosphat, triose phosphat) dễ bị **phosphatase** của thận cắt phosphat; acid phosphoric được bài xuất.
- **Lipid**: các lecithin bị khử phosphat nhờ **glycerophosphatase**; **thể ceton** được thận **thoái hóa hoàn toàn**.
- **Protein**: thận có nhiều enzym **khử amin**: enzym khử amin acid amin dạng **D** (dạng không có trong protein tự nhiên) và dạng **L**, tạo acid α-cetonic và giải phóng NH~3~ dưới dạng **NH~4~^+^** (xem cơ chế đào thải H^+^, mục 1.5).
- **Tổng hợp**: giống gan, thận có thể **khử nước creatin thành creatinin**, và **liên hợp acid benzoic với glycin** tạo **acid hippuric** — một cách khử độc acid benzoic (có trong thực phẩm, chất bảo quản natri benzoat).

> [!bay]
> Giáo trình xếp **tạo acid hippuric** và **urocrom** (sắc tố vàng của nước tiểu) vào chức năng **chuyển hóa – tổng hợp** của thận, không phải chức năng nội tiết.

### 1.5. Vai trò của thận trong thăng bằng acid – base

Chuyển hóa sinh ra liên tục các **acid không bay hơi**: acid lactic, **thể ceton**, **acid sulfuric** (từ acid amin chứa S của protein), **acid phosphoric** (từ phospholipid). Các acid này không thải qua phổi được. Khi vào máu chúng kết hợp với cation, chủ yếu là **Na^+^**. Thận **thải H^+^** và **giữ lại Na^+^** (cùng HCO~3~^−^) để trả lại cho máu (Giáo trình tr. 295–297).

Cả 3 cơ chế đều bắt đầu từ một phản ứng trong tế bào ống thận, nhờ enzym **carbonic anhydrase (CA)**:

=> CO~2~ + H~2~O → H~2~CO~3~ → H^+^ + HCO~3~^−^

H^+^ được **bài tiết** vào lòng ống (đổi lấy Na^+^); HCO~3~^−^ cùng Na^+^ đi **về máu**.

![Hình 2. Ba cơ chế bài tiết H^+^ của tế bào ống thận. Trong cả ba, mỗi H^+^ tiết ra đổi được một Na^+^ và một HCO~3~^−^ trở về máu; chỉ khác "người nhận" H^+^ trong lòng ống.](acid-base-than.svg)

| Cơ chế | Nơi chính | H^+^ trong lòng ống gặp… | Kết quả |
|---|---|---|---|
| **1. Tái hấp thu bicarbonat** | **Ống lượn gần** (≈ **90%** HCO~3~^−^ đã lọc) | HCO~3~^−^ đã lọc → H~2~CO~3~ → CO~2~ + H~2~O; CO~2~ khuếch tán lại vào tế bào | **Giữ lại** HCO~3~^−^ đã lọc (không tạo mới) |
| **2. Thải H^+^ dạng muối acid** | **Ống lượn xa** | **Na~2~HPO~4~** (phosphat dinatri) → **NaH~2~PO~4~** (phosphat mononatri) | Nước tiểu toan dần: pH **7,4 → 6,0**; 1 Na^+^ về máu |
| **3. Thải H^+^ dạng muối amoni** | **Ống lượn xa** | **NH~3~** (từ thủy phân **glutamin** nhờ **glutaminase**) khuếch tán thụ động ra lòng ống → **NH~4~^+^** | Thải 30–50 mEq H^+^/ngày dạng NH~4~^+^ |

Mỗi ngày thận thải khoảng **30–50 mEq H^+^ dưới dạng muối amoni** và **10–30 mEq dưới dạng các muối acid khác** (Giáo trình tr. 297). Cơ chế 2 và 3 mỗi lần thải một H^+^ là trả về máu một HCO~3~^−^ **mới**: đây mới là cách thận "nạp lại" kiềm dự trữ đã bị acid tiêu hao.

**Vì sao NH~4~^+^ bị "bẫy" trong lòng ống?** NH~3~ không mang điện, tan trong lipid nên **đi qua màng dễ dàng**. Khi gặp H^+^ trong lòng ống, nó thành **NH~4~^+^ mang điện**, không qua lại màng được nữa, nên bị thải ra (thường đi kèm Cl^−^ dạng NH~4~Cl).

Phần phân tích sâu (vì sao NH~4~^+^ là "van xả" chính khi toan kéo dài, các thông số khí máu, nhiễm toan – kiềm) đã có ở hs-16 (*Khí máu và thăng bằng acid — base*). Thận còn tham gia điều hòa nước – điện giải: xem hs-15 (Trao đổi muối – nước).

> [!ung-dung] Khi thận không còn thải được acid
> - **Suy thận mạn**: số nephron giảm, thận **không tạo đủ NH~4~^+^** → H^+^ tích lại, HCO~3~^−^ máu giảm → **nhiễm toan chuyển hóa**. Bệnh nhân thường được bù **natri bicarbonat** uống.
> - **Thuốc ức chế carbonic anhydrase** (acetazolamid) chặn ngay bước đầu của cả 3 cơ chế → thải nhiều HCO~3~^−^, nước tiểu **kiềm**, máu **toan nhẹ**. Thuốc dùng trong glôcôm, say độ cao.

### 1.6. Chức năng nội tiết

Thận tham gia điều hòa hằng định nội môi, thăng bằng nước – điện giải và **huyết áp**, chủ yếu qua hệ **renin – angiotensin – aldosteron (RAA)** (Giáo trình tr. 297–300).

#### 1.6.1. Hệ renin – angiotensin – aldosteron

- **Renin** là một **enzym** (protein, TLPT khoảng **40.000**) do **bộ máy cạnh cầu thận** tổng hợp và bài tiết, đổ vào tĩnh mạch thận.
- Trong máu, renin tác dụng đặc hiệu lên **angiotensinogen**, một **α-globulin do gan tổng hợp**. Renin cắt liên kết peptid giữa acid amin **thứ 10 và 11** (Leu–Leu), giải phóng **angiotensin I** (**10 acid amin**, **không** có tác dụng sinh học).
- **Enzym chuyển** (angiotensin-converting enzyme, ACE) cắt **2 acid amin ở đầu C** (**His–Leu**) của angiotensin I, tạo **angiotensin II** (**8 acid amin**). Angiotensin II có ba tác dụng:
  - **Co mạch**, tăng huyết áp mạnh — theo giáo trình **gấp 50 lần adrenalin**;
  - **Co cơ trơn**;
  - Kích thích **vỏ thượng thận** bài tiết **aldosteron**.
- Angiotensin II sống rất ngắn: **aminopeptidase** cắt **Asp ở đầu N**, tạo **angiotensin III** (**7 acid amin**). Angiotensin II và III đều có thụ thể ở **lớp cầu** vỏ thượng thận và chính chúng kiểm soát tổng hợp aldosteron.
- Cuối cùng **angiotensinase** cắt angiotensin III thành các mảnh **không hoạt động**.

![Hình 3. Chuỗi phân cắt angiotensinogen (trình tự theo giáo trình). Các vạch chỉ liên kết bị cắt và enzym tương ứng; enzym chuyển (ACE) là đích của thuốc hạ huyết áp nhóm "-pril".](renin-angiotensin.svg)

> [!cap-nhat] Trình tự angiotensinogen của người
> Giáo trình (và Hình 3) dùng trình tự kinh điển ...His^9^–**Leu^10^–Leu^11^**–Val–Tyr–Ser, vốn là trình tự của angiotensinogen **ngựa** (dùng trong các thí nghiệm đầu tiên). Ở **người**, đoạn này là ...His^9^–**Leu^10^–Val^11^**–Ile–His–Asn; renin cắt liên kết **Leu^10^–Val^11^**. Phần angiotensin I (10 acid amin đầu) thì **giống nhau**, nên angiotensin I, II, III không đổi. Đi thi trả lời theo giáo trình (cắt giữa aa 10 và 11).

**Điều hòa bài tiết renin**

| Yếu tố | Tác dụng lên renin |
|---|---|
| Kích thích **giao cảm**, catecholamin (qua thụ thể **β-adrenergic**) | **Tăng** |
| **Hạ huyết áp** tiểu động mạch, giảm lưu lượng máu đến thận | **Tăng** |
| **Tăng Na^+^** ở tế bào ống thận | **Giảm** (hạ Na^+^ thì ngược lại, tăng) |
| **Angiotensin II** | **Giảm** — ức chế ngược (feedback âm), rất quan trọng |

**Điều hòa tổng hợp aldosteron**

- **Natri máu giảm** → tăng aldosteron. Khi Na^+^ máu hạ hơn 10 mEq/L (so với bình thường), vỏ thượng thận tăng chuyển **corticosteron → aldosteron**.
- **Kali máu tăng** → kích thích bước **cholesterol → pregnenolon**, tăng aldosteron. (Aldosteron giữ Na^+^ và **thải K^+^**, nên đây là vòng điều hòa ngược hợp lý.)
- **Natri máu tăng** → áp suất thẩm thấu ngoại bào tăng → vùng dưới đồi tăng **ADH** → tăng tái hấp thu nước, và (theo giáo trình) **ức chế** bài tiết renin.

> [!ung-dung] Thuốc tác động lên hệ RAA
> - **Ức chế men chuyển** (captopril, enalapril, "-pril"): chặn bước angiotensin I → II. Vì ACE cũng phân hủy **bradykinin**, thuốc làm bradykinin tích lại, gây **ho khan** ở một số người.
> - **Chẹn thụ thể angiotensin II** (losartan, "-sartan"), **đối kháng aldosteron** (spironolacton).
> - Nhóm ức chế men chuyển/chẹn thụ thể **giảm protein niệu**, làm chậm suy thận ở người đái tháo đường — vì angiotensin II làm tăng lọc protein (mục 1.2b).
> - Các thuốc này làm **giữ K^+^**: cần theo dõi **kali máu** và **creatinin** khi bắt đầu dùng.

#### 1.6.2. Erythropoietin — yếu tố tạo hồng cầu của thận

Từ khoảng năm 1950, người ta thấy **thiếu oxy** liên quan trực tiếp với nồng độ một hormon trong huyết tương là **erythropoietin (Ep)**, chất kích thích **tế bào tiền thân** hồng cầu phát triển thành hồng cầu trưởng thành. Năm 1957 Jacobson phát hiện mối liên quan giữa Ep và thận.

Mô hình của giáo trình (tr. 299–300):

- Ep được tạo từ một **α~1~-globulin do gan tổng hợp** (tiền Ep).
- Tiền Ep chuyển thành Ep hoạt động nhờ **yếu tố tạo hồng cầu của thận** — **REF** (renal erythropoietic factor; hình của sách ghi *ERF*).
- REF là **glycoprotein**, tạo ra ở **tế bào kẽ gần ống lượn** dưới dạng **tiền REF** không hoạt động. Tiền REF được **phosphoryl hóa** thành dạng hoạt động nhờ **protein kinase**; protein kinase lại được hoạt hóa nhờ **AMP vòng**; và **PGE~2~** kích thích tạo AMP vòng (qua adenylat cyclase).
- Ep đã được sản xuất thành **thuốc**, dùng cho bệnh nhân **thẩm phân phúc mạc** (và lọc máu).

> [!cap-nhat] Thận tự tổng hợp erythropoietin
> Mô hình "REF hoạt hóa tiền Ep từ gan" là giả thuyết cũ. Hiện nay biết **erythropoietin là glycoprotein hormon do chính thận tổng hợp** — chủ yếu ở các **tế bào kẽ quanh ống thận vùng vỏ** — và chỉ khoảng 10% do gan (gan là nguồn chính ở thai nhi). Cảm biến oxy là **yếu tố cảm ứng thiếu oxy (HIF)**: khi thiếu oxy, HIF không bị phân hủy, đi vào nhân và **bật gen EPO**. Giải Nobel Y học 2019 trao cho phát hiện cơ chế này. Từ đó có nhóm thuốc mới uống được (ức chế HIF-prolyl hydroxylase, ví dụ roxadustat). Đi thi trả lời theo mô hình REF của giáo trình.

> [!ung-dung] Thiếu máu của suy thận mạn
> Thận suy thì **thiếu erythropoietin**, nên bệnh nhân suy thận mạn hầu như luôn có **thiếu máu đẳng sắc**, mức độ nặng dần theo suy thận. Điều trị bằng **erythropoietin tái tổ hợp** tiêm (kèm bù sắt). Ngược lại, ở **người sống vùng núi cao** hay **bệnh phổi mạn**, thiếu oxy kéo dài làm tăng Ep, tăng hồng cầu. Lạm dụng EPO là một dạng **doping** trong thể thao sức bền.

#### 1.6.3. Prostaglandin

Thận tạo **3 loại** prostaglandin: **PGE~2~, PGI~2~, TXA~2~**, ở các đoạn khác nhau của nephron và tế bào kẽ.

- **PGE~2~, PGI~2~**: **giãn mạch**, chống lại tác dụng co mạch của angiotensin II; tăng thải Na^+^, **lợi tiểu nhẹ**. PGE~2~ còn kích thích tạo **REF** qua adenylat cyclase → AMP vòng (mục 1.6.2).
- **TXA~2~**: **co mạch**.
- Prostaglandin tăng sản xuất khi **angiotensin II tăng** và khi thần kinh thận bị kích thích — tức là chúng "đỡ" cho thận khi cơ thể đang co mạch.

> [!ung-dung] Thuốc giảm đau chống viêm (NSAID) và thận
> NSAID (ibuprofen, diclofenac…) ức chế tạo prostaglandin. Người khỏe ít ảnh hưởng. Nhưng khi thận **đang dựa vào PGE~2~, PGI~2~ để giữ máu tới cầu thận** — mất nước, suy tim, xơ gan, người cao tuổi, đang dùng lợi tiểu và ức chế men chuyển — NSAID có thể gây **suy thận cấp**. Đây là lý do không tự ý dùng NSAID dài ngày cho người có bệnh thận.

#### 1.6.4. Vitamin D~3~

- **Cholecalciferol** (vitamin D~3~) là một **tiền hormon** tạo ra ở **da** nhờ tia tử ngoại.
- D~3~ vào huyết tương, được **protein gắn D~3~** (D-binding protein) chở đến **gan**, bị **hydroxyl hóa** thành **25-OH-D~3~**.
- 25-OH-D~3~ được protein gắn chở đến **thận** (giáo trình in nhầm "protein gắn 5-OH-D3"), ở đây được hydroxyl hóa tiếp thành **1,25-(OH)~2~-D~3~**, tức **calcitriol** — dạng **hoạt động**.
- Calcitriol **tăng hấp thu calci ở ruột** và **tăng tái hấp thu calci ở thận**.

> [!vi-du] Vì sao suy thận gây loãng xương, hạ calci?
> Bước hydroxyl hóa ở vị trí 1α xảy ra ở **ống lượn gần** (enzym **1α-hydroxylase**, được **PTH** kích thích). Thận suy → thiếu calcitriol → hấp thu calci ở ruột giảm, calci máu giảm, đồng thời thận giữ lại phosphat → **cường cận giáp thứ phát**, tổn thương xương (loạn dưỡng xương do thận). Vì thế bệnh nhân suy thận được dùng **calcitriol** (dạng đã hoạt động sẵn), chứ uống vitamin D thường không đủ.

#### 1.6.5. ANF — yếu tố bài niệu natri của tâm nhĩ

**ANF** (atrial natriuretic factor, nay thường gọi **ANP**) do tế bào cơ **tâm nhĩ** tiết ra (có thể cả tâm thất) khi tim bị căng giãn. ANF:

- **Tăng thải natri** (tăng lọc Na^+^ ở cầu thận, giảm tái hấp thu ở ống thận);
- **Đối lập với ADH** ở ống góp, làm giảm tái hấp thu nước;
- Giảm tái hấp thu NaCl ở ống góp.

Nói gọn: ANF là "van xả" muối – nước khi thể tích máu quá nhiều, ngược chiều với hệ RAA và ADH. Chi tiết điều hòa muối – nước: hs-15.

> [!yhct] Thận, thuốc YHCT và an toàn
> - **Tổn thương thận do acid aristolochic** (Quảng phòng kỷ, Quan mộc thông, Thanh mộc hương, Mã đâu linh; nhầm lẫn các vị trùng tên "phòng kỷ", "mộc thông") đã trình bày chi tiết ở bài *Đột biến* (mã sh-10, khung YHCT). Liên hệ với bài này: tổn thương chủ yếu ở **ống thận và mô kẽ**, nên dấu hiệu sớm là protein niệu **phân tử nhỏ** kiểu ống thận (mục 1.3.6) và glucose niệu dù đường huyết bình thường, trước khi creatinin tăng.
> - **Thuốc lợi niệu thảo dược** (nhóm lợi thủy thẩm thấp, Ngũ linh tán, Râu ngô…) và nguy cơ rối loạn điện giải: xem bài *Trao đổi muối — nước* (mã hs-15). Cam thảo và giả cường aldosteron: xem bài *Hóa sinh hormon* (mã hs-14).
> - **Khế chua** — điểm riêng của bài này. Quả khế (*Averrhoa carambola*) chứa nhiều **oxalat**. Đã có các **báo cáo ca bệnh và loạt ca** về **bệnh thận cấp do oxalat** (tinh thể oxalat calci lắng trong ống thận) sau khi uống nhiều nước khế, nhất là lúc đói hoặc đang mất nước; ở người **đã suy thận**, khế còn gây ngộ độc thần kinh (nấc, lú lẫn, co giật) do độc tố **caramboxin** không thải được. Người bệnh thận **không nên** dùng khế, kể cả dạng bài thuốc dân gian. Mức bằng chứng: **lâm sàng (ca bệnh)**, cơ chế oxalat đã rõ.

## 2. Nước tiểu — tính chất chung

Nước tiểu là dịch bài xuất quan trọng nhất, chứa phần lớn **chất cặn bã** của cơ thể. Thay đổi về chỉ số lý hóa, nhất là về **thành phần hóa học** của nước tiểu, phản ánh các **rối loạn chuyển hóa** (Giáo trình tr. 300).

### 2.1. Thể tích

- Người lớn: khoảng **1.000–1.400 mL/24 giờ**, tương đương **18–20 mL/kg** cân nặng. Tính theo cân nặng, **trẻ em** tiểu nhiều hơn người lớn.
- **Giảm sinh lý**: uống ít nước, làm việc trong môi trường nóng, ra nhiều mồ hôi.
- **Đa niệu** (> **2.500 mL/24 giờ**): **đái tháo đường** (glucose kéo nước theo — lợi niệu thẩm thấu), **đái tháo nhạt** (thiếu ADH).
- **Thiểu niệu, vô niệu** (giáo trình: < **750 mL/24 giờ**): viêm cầu thận cấp, viêm ống thận cấp do ngộ độc, **mất máu**, **bỏng nặng**.

> [!cap-nhat] Ngưỡng thiểu niệu, vô niệu
> Giáo trình lấy mốc < 750 mL/24 giờ. Lâm sàng hiện nay thường dùng: **thiểu niệu < 400–500 mL/24 giờ** (hoặc < 0,5 mL/kg/giờ ở người bệnh nặng); **vô niệu < 100 mL/24 giờ**. Cơ sở: người lớn cần thải khoảng 500–600 mOsm chất tan mỗi ngày, mà thận cô đặc tối đa ≈1.200 mOsm/L, nên dưới ≈500 mL thì chất cặn bã **bắt đầu ứ lại** trong máu.

### 2.2. Tính chất vật lý

| Tính chất | Bình thường | Thay đổi bệnh lý |
|---|---|---|
| **Màu** | Vàng nhạt đến vàng hổ phách, tùy lượng và độ đặc; sắc tố chính là **urocrom**, **urobilin** (sản phẩm oxy hóa urobilinogen), dẫn xuất **indoxyl** | **Nâu vàng** (bệnh gan mật — bilirubin); **hồng/đỏ** (có máu); **đục như nước vo gạo** (dưỡng chấp) |
| **Độ trong** | Trong suốt khi mới lấy; để lâu có **đám mây vẩn đục** (tế bào nội mô, urosomucoid); để lạnh có thể lắng **cặn** acid uric, urat, phosphat | — |
| **Độ sánh** | Hơi cao hơn nước | Sánh hơn, **nhiều bọt**: có máu, mủ, **protein**, dưỡng chấp |
| **Mùi** | Đặc trưng; để ngoài không khí có **mùi khai** (ure → NH~3~) | **Mùi ceton** (táo chín); mùi hôi (sốt cao, ung thư thận, bàng quang) |
| **Sức căng bề mặt** | **64–69 dyne/cm** (nước: 72) | **Giảm thêm** khi có **muối mật** (viêm gan, tắc mật) |
| **Tỷ trọng** (24 giờ, 15 °C) | **1,005–1,030**, trung bình 1,018 ± 0,022 | **Cao** (1,03–1,04) trong **đái tháo đường**; **thấp** trong **đái tháo nhạt** |
| **pH** | Hơi acid, **5–6**, trung bình **5,8** | Xem dưới |

**Phân biệt cặn urat và cặn phosphat**: **đun gần sôi** thì cặn **urat tan**. Cặn **phosphat** không tan trong môi trường trung tính hoặc kiềm, nhưng **tan trong acid nhẹ** (Giáo trình tr. 301).

**pH nước tiểu** (Giáo trình tr. 302):

- Nước tiểu hơi acid là nhờ có **acid acetoacetic, acid uric, phosphat acid** và **muối amoni**.
- **Ăn nhiều rau** → nước tiểu ít acid, có khi trung tính hoặc hơi kiềm. **Ăn nhiều thịt**, **lao động cơ bắp mạnh**, tập thể thao → nước tiểu **acid hơn**.
- **Đái tháo đường nặng** → nước tiểu **acid** do thải **thể ceton**.
- **Viêm bể thận, bàng quang** → nước tiểu **kiềm** do vi khuẩn **lên men amoniac** (phân hủy ure).
- **Viêm dạ dày tăng acid** → nước tiểu sau bữa ăn thường **kiềm** ("làn sóng kiềm" sau bữa ăn: dạ dày tiết nhiều HCl thì máu được trả lại HCO~3~^−^). Ở bệnh nhân **ung thư dạ dày**, pH nước tiểu hầu như **không đổi** trong ngày.

> [!ung-dung] Màu nước tiểu "giả" do thuốc, thức ăn
> Không phải nước tiểu đỏ nào cũng là có máu. Củ dền, thanh long ruột đỏ, thuốc **rifampicin** (đỏ cam), phenazopyridin cho màu đỏ cam; **vitamin B~2~** (riboflavin) làm nước tiểu vàng chói; **xanh methylen** làm nước tiểu xanh. Luôn kiểm tra bằng **que thử** và **soi cặn** (mục 5.4, 5.5) trước khi kết luận "đái máu".

## 3. Thành phần hóa học của nước tiểu bình thường

**Bảng 18.1. Thành phần trung bình trong nước tiểu 24 giờ** (Giáo trình tr. 302, đơn vị gam/24 giờ):

| Anion | g/24 h | Cation | g/24 h | Chất hữu cơ | g/24 h |
|---|---|---|---|---|---|
| Clorua | 6–12 | Na^+^ | 4,0–6,0 | **Ure** | **20–30** |
| Phosphat | 2,5–4,0 | K^+^ | 2,0–3,0 | **Creatinin** | 1,0–1,8 |
| Sulfat | 2,0–3,5 | Ca^2+^ | 0,15–0,25 | Acid uric | 0,4–0,8 |
| | | NH~4~^+^ | 0,3–1,2 | Acid amin | 2,0–4,0 |
| | | Mg^2+^ | 0,10–0,20 | Acid hippuric | 0,1–1,0 |

### 3.1. Chất vô cơ

- **Clorua**: phụ thuộc **chế độ ăn** (lượng muối). **Giảm** trong viêm thận, nhiễm trùng.
- **Phosphat**: **tăng** trong bệnh **nhuyễn xương**, **ưu năng tuyến giáp** và **thiểu năng cận giáp trạng**.

### 3.2. Chất hữu cơ

- **Ure**: nitơ của ure chiếm **80–85% nitơ toàn phần** của nước tiểu — ure là "dạng thải nitơ" chính của người (xem hs-09).
  - **Tăng**: ăn nhiều đạm, sốt cao, đái tháo đường, ưu năng tuyến thượng thận, nhiễm độc asen và phospho (tăng dị hóa protein).
  - **Giảm**: tổn thương biểu mô ống thận như viêm thận cấp do nhiễm độc (thận không thải được, ure ứ lại trong máu).
- **Creatinin**: nam trưởng thành thải trung bình **20–25 mg/kg** cân nặng/ngày. Giáo trình ghi creatinin niệu **tăng** trong **teo cơ, thoái hóa cơ** và ưu năng cận giáp. *Lưu ý: giai đoạn cơ đang bị phá hủy cấp (tiêu cơ vân) thì creatin, creatinin thải ra tăng; còn khi khối cơ đã **teo** (loạn dưỡng cơ, nằm lâu) thì thứ tăng trong nước tiểu là **creatin** (creatin niệu), còn **creatinin niệu giảm** theo khối cơ.*
- **Acid uric**: **tăng** khi ăn nhiều đạm, viêm thận, và bệnh **tăng chuyển hóa nucleoprotein** của tế bào như **bệnh bạch cầu** (nhiều tế bào chết, nhiều acid nucleic bị thoái hóa thành purin → acid uric).
- **Acid amin**: nước tiểu chứa **tất cả** acid amin, mỗi loại khoảng 10–30 mg/24 giờ; riêng **glycin và histidin** nhiều hơn (trên 100 mg/24 giờ). Ở phụ nữ, thải His cao nhất vào ngày 15–20 của chu kỳ kinh.
- **Hormon, vitamin, enzym**: có **amylase**; vitamin B~1~, PP, C và dẫn xuất; **hormon sinh dục** nam, nữ, hormon **vỏ thượng thận** dưới dạng **liên hợp glucuronid**.

> [!bay]
> **Creatinin niệu 24 giờ khá hằng định** ở mỗi người (tỷ lệ khối cơ). Vì vậy nó được dùng để **kiểm tra xem mẫu nước tiểu 24 giờ có lấy đủ không**, và làm "mẫu số" trong các tỷ số trên mẫu nước tiểu ngẫu nhiên (ví dụ **tỷ albumin/creatinin**, mục 5.3).

## 4. Các chất bất thường trong nước tiểu

"Chất bất thường" là những chất **chỉ xuất hiện (hoặc chỉ phát hiện được) khi có bệnh** (Giáo trình tr. 303–304). Đây là phần thường ra thi nhất của chương.

### 4.1. Glucid

- Nước tiểu bình thường có **một lượng nhỏ** các ose (glucose, fructose, arabinose, galactose…) nên có **tính khử yếu**, khó phát hiện bằng thuốc thử **Fehling**.
- **Đái tháo đường**: glucose máu vượt **ngưỡng thận (1,7 g/L)** → glucose bị đào thải ra nước tiểu.
- **Glucose niệu do thận**: glucose máu **bình thường**, nhưng **khả năng tái hấp thu của ống thận giảm** (ngưỡng thận thấp, tổn thương ống lượn gần) — cũng có glucose niệu.
- Một số **rối loạn enzym bẩm sinh**: nước tiểu xuất hiện **galactose** (galactosemia), **fructose**.

> [!bay] Đường huyết bình thường mà glucose niệu dương tính
> Nghĩ đến: (1) **glucose niệu do thận** (bẩm sinh; thai kỳ — lọc tăng; tổn thương ống thận); (2) đang dùng **thuốc ức chế SGLT2** (mục 1.3.2). Ngược lại, người đái tháo đường lâu năm có **xơ hóa cầu thận** thì ngưỡng thận **tăng**, glucose niệu có thể âm tính dù đường huyết rất cao. Vì thế **không dùng glucose niệu để chẩn đoán** đái tháo đường — phải đo **đường máu**/HbA1c.

### 4.2. Protein

- Nước tiểu bình thường có **50–100 mg protein/24 giờ**:
  - **55–60%** nguồn gốc **huyết thanh** — trong đó chỉ **40% là albumin**, còn lại là IgG, mảnh IgA, chuỗi nhẹ lambda, kappa;
  - khoảng **40%** là **glycoprotein** từ chính thận và đường dẫn niệu (chủ yếu **uromodulin**, tức protein Tamm–Horsfall).
  - Lượng này **xét nghiệm thông thường không phát hiện được** → coi là "không có protein".
- **Protein niệu > 150 mg/24 giờ** là **bệnh lý**:
  - **Sốt cao**: lượng vừa phải, khoảng **0,5–1,0 g/24 giờ**.
  - **Đái tháo đường** với **tổn thương thận sớm**: albumin rất ít, gọi là **albumin niệu vi lượng** (microalbuminuria).
  - **Bệnh hệ thống** (viêm đa động mạch, xơ cứng bì): albumin khoảng **1 g/24 giờ**.
  - **Bệnh paraprotein** (đa u tủy xương): protein TLPT thấp, protein **Bence Jones** (chuỗi nhẹ lambda, kappa) — đặc điểm: **tủa khi đun ấm và tan lại khi đun sôi 100 °C**.
  - **Suy tim** và đặc biệt **các bệnh thận**.

> [!cap-nhat] Albumin niệu và protein Bence Jones
> - Thuật ngữ "albumin niệu vi lượng" nay được thay bằng **albumin niệu tăng vừa** (KDIGO, nhóm **A2**): **tỷ albumin/creatinin niệu (ACR) 3–30 mg/mmol** (30–300 mg/g). Đây là dấu hiệu sớm nhất của bệnh thận do đái tháo đường và tăng huyết áp; người đái tháo đường được khuyến cáo xét nghiệm **ít nhất mỗi năm một lần**.
> - Giáo trình ghi protein Bence Jones "tủa ở 80–85 °C, tan ở 100 °C". Tài liệu kinh điển thường ghi **tủa ở khoảng 40–60 °C**, tan lại gần điểm sôi. Ngày nay protein Bence Jones được phát hiện bằng **điện di miễn dịch** nước tiểu và đo **chuỗi nhẹ tự do** trong huyết thanh, không còn dùng phản ứng nhiệt.

### 4.3. Thể ceton

- Bình thường nước tiểu chỉ có vài mg **acid acetoacetic**/L (giáo trình in "acid acetic") và vài trăm mg **acid β-hydroxybutyric**.
- **Tăng** khi: **đói lâu ngày**, **đái tháo đường** (nhất là thiếu insulin nặng → **toan ceton**), sau một số trường hợp **gây mê**. Ngoài ra: nôn nhiều, chế độ ăn rất ít glucid.
- Vì sao? Khi tế bào thiếu glucose (đói) hoặc không dùng được glucose (thiếu insulin), gan tăng β-oxy hóa acid béo → thừa acetyl-CoA → tạo **thể ceton**; vượt khả năng sử dụng của mô thì ra nước tiểu, làm nước tiểu **acid** và có **mùi ceton**.

### 4.4. Sắc tố mật, muối mật

- **Sắc tố mật** ở đây là **bilirubin liên hợp** (tan trong nước nên lọc qua cầu thận được; bilirubin tự do gắn albumin nên **không** ra nước tiểu).
- Sắc tố mật và muối mật xuất hiện trong nước tiểu khi **tổn thương gan và đường mật**, nhất là **vàng da do viêm gan** và **tắc mật**.
- Muối mật làm **giảm sức căng bề mặt** của nước tiểu (cơ sở của nghiệm pháp Hay: bột lưu huỳnh rắc lên nước tiểu bị chìm).

| Loại vàng da | Bilirubin niệu | Urobilinogen niệu |
|---|---|---|
| **Trước gan** (tan máu) | **Âm tính** (tăng bilirubin tự do) | **Tăng** |
| **Tại gan** (viêm gan) | Dương tính | Tăng hoặc bình thường |
| **Sau gan** (tắc mật hoàn toàn) | **Dương tính mạnh** | **Giảm / mất** (mật không xuống ruột) |

Cơ chế tạo bilirubin, urobilinogen và chu trình ruột – gan: xem **hs-10** (Chuyển hóa hemoglobin).

### 4.5. Hồng cầu và hemoglobin

- **Hồng cầu** trong nước tiểu (**đái máu**): **viêm thận cấp** (viêm cầu thận), **lao thận**, **ung thư thận**; ngoài ra sỏi, viêm bàng quang.
- **Hemoglobin** tự do (**hemoglobin niệu**): **tan máu trong lòng mạch** — **sốt rét ác tính** (sốt rét đái huyết sắc tố), **hoàng đản do tiêu huyết**, **bỏng nặng**.

> [!bay] Đái máu ≠ hemoglobin niệu
> Que thử "máu" dương tính với **cả** hồng cầu nguyên vẹn, hemoglobin tự do **và myoglobin** (tiêu cơ vân). Phải **soi cặn**: thấy nhiều hồng cầu → **đái máu**; que dương tính mà **không thấy hồng cầu** → nghĩ đến **hemoglobin niệu** (tan máu) hoặc **myoglobin niệu** (tiêu cơ vân do chấn thương, gắng sức quá mức, ngộ độc). Nước tiểu đái máu để lắng thì có **cặn đỏ** ở đáy, phần trên trong hơn; hemoglobin niệu thì **đỏ đều**, không lắng cặn.

### 4.6. Porphyrin

- Người bình thường hằng ngày thải một lượng nhỏ porphyrin (**coproporphyrin I và III**).
- Có **2 loại porphyrin niệu**:
  - **Vô căn** (nguyên phát): do **di truyền**, **thiếu một enzym** của quá trình **tổng hợp hem** ở tủy xương hoặc gan (các bệnh **porphyria**).
  - **Thứ phát**: do nhiễm **chất độc ức chế tổng hợp hem**, điển hình là **chì**.

> [!cap-nhat] Đơn vị porphyrin niệu
> Giáo trình in "50–200 **mg** porphyrin/ngày" và "copoporphyrin I và II". Đúng ra là khoảng **50–200 µg/24 giờ** (microgam), chủ yếu là **coproporphyrin I và III**. Tổng hợp hem: xem hs-10.

### 4.7. Dưỡng chấp

Nước tiểu **đục trắng như nước vo gạo** (**đái dưỡng chấp**) khi bệnh **giun chỉ** gây tổn thương **bạch mạch** thông với đường tiết niệu: bạch huyết giàu lipid (dưỡng chấp từ ruột) đổ vào nước tiểu.

### 4.8. Nitrit

Nước tiểu bình thường có **nitrat** (từ thức ăn) nhưng **không có nitrit**. Một số **vi khuẩn** có enzym **nitrat reductase** khử nitrat thành nitrit. Vậy **có nitrit trong nước tiểu** gợi ý **nhiễm trùng đường tiết niệu**.

> [!bay] Nitrit âm tính không loại trừ nhiễm trùng
> Phản ứng cần (1) vi khuẩn **có nitrat reductase** — phần lớn **trực khuẩn Gram âm** đường ruột (E. coli…), còn cầu khuẩn đường ruột (Enterococcus), tụ cầu hoại sinh **thường không**; (2) nước tiểu **ở trong bàng quang ≥ 4 giờ** (lấy nước tiểu **đầu buổi sáng**); (3) trong khẩu phần có rau (nitrat). Vì vậy nitrit có độ **đặc hiệu cao** nhưng độ **nhạy thấp**; nên đọc kèm **bạch cầu** (esterase).

## 5. Xét nghiệm đánh giá chức năng thận và nước tiểu *(phần bổ sung thực hành)*

Phần này không có trong chương của giáo trình nhưng là kiến thức nền cho mọi môn lâm sàng. Khoảng tham chiếu dưới đây chỉ để **tham khảo, mỗi phòng xét nghiệm có khoảng riêng**.

### 5.1. Độ thanh thải (clearance)

**Độ thanh thải** của một chất là **thể tích huyết tương** (mL) được thận **lọc sạch hoàn toàn** chất đó trong **1 phút**:

=> C = (U × V) / P

trong đó U là nồng độ chất trong nước tiểu, V là lưu lượng nước tiểu (mL/phút), P là nồng độ chất trong huyết tương.

| Chất | Thận xử lý thế nào | Độ thanh thải bằng… |
|---|---|---|
| **Inulin** | Chỉ lọc; không tái hấp thu, không bài tiết | **Mức lọc cầu thận (GFR)** ≈ 120–125 mL/phút — "chuẩn vàng" |
| **Creatinin** | Lọc + bài tiết thêm một ít | Hơi **cao hơn** GFR (10–20%) |
| **Ure** | Lọc + tái hấp thu 40–50% | **Thấp hơn** GFR |
| **Glucose** (bình thường) | Lọc + tái hấp thu hoàn toàn | **0** |
| **PAH** (acid para-aminohippuric) | Lọc + bài tiết gần hết | **Lưu lượng huyết tương thận** (≈650 mL/phút) |

> [!vi-du] Tính độ thanh thải creatinin
> Một nam giới thu được 1.440 mL nước tiểu/24 giờ, tức V = 1 mL/phút. Creatinin niệu U = 9.000 µmol/L, creatinin máu P = 80 µmol/L.
>
> => C = (9.000 × 1) / 80 ≈ 112 mL/phút — bình thường.
>
> Lưu ý **U và P phải cùng đơn vị**. Sai số lớn nhất của phép đo này nằm ở chỗ **lấy nước tiểu 24 giờ không đủ** — vì vậy ngày nay thường dùng **eGFR** tính từ creatinin máu.

> [!cap-nhat] Lưu lượng máu qua thận
> Giáo trình ghi "lượng máu qua thận khoảng 120 mL/phút" (tr. 292). Con số 120 mL/phút thực ra là **mức lọc cầu thận** (≈ 180 L/ngày, khớp với con số 180 L nước tiểu ban đầu). **Lưu lượng máu qua thận** là khoảng **1.000–1.200 mL/phút** (≈ 20–25% cung lượng tim, tức khoảng 1.500–1.700 lít/ngày), cùng bậc với "1.000–1.500 lít máu/ngày" mà giáo trình nêu ở tr. 290. Lưu lượng máu thận lớn gấp khoảng **10 lần** GFR: chỉ khoảng 1/5 **huyết tương** qua cầu thận được lọc (phân số lọc ≈ 20%).

### 5.2. Ure và creatinin máu, eGFR

| Xét nghiệm | Khoảng tham chiếu thường dùng | Ý nghĩa |
|---|---|---|
| **Ure máu** | **2,5–7,5 mmol/L** | Tăng khi suy thận, nhưng còn tăng do ăn nhiều đạm, **xuất huyết tiêu hóa**, sốt, mất nước; giảm khi suy gan (xem hs-09) |
| **Creatinin máu** | Nam **62–120 µmol/L**; nữ **53–100 µmol/L** | Ổn định hơn ure, tỷ lệ với **khối cơ**; dùng để tính eGFR |
| **eGFR** | **≥ 90 mL/phút/1,73 m²** | Ước tính mức lọc cầu thận từ creatinin, tuổi, giới (công thức **CKD-EPI**) |

Quy đổi: creatinin **mg/dL × 88,4 = µmol/L**; ure **mmol/L × 6 = mg/dL** (ure), hoặc BUN (mg/dL) × 0,357 = ure mmol/L.

**Vì sao creatinin, chứ không phải ure?** Creatinin sinh ra **gần như hằng định** từ cơ (xem hs-09) và gần như chỉ đi qua cầu thận. Ure thì phụ thuộc lượng đạm ăn vào, chức năng gan, tình trạng mất nước và bị tái hấp thu một phần.

> [!bay] Creatinin là chỉ số "chậm và thô"
> - Creatinin máu chỉ tăng rõ khi đã mất **khoảng một nửa** chức năng lọc (đường cong GFR – creatinin dạng hyperbol). Creatinin "còn trong giới hạn" **chưa chắc** thận bình thường, nhất là ở **người già, người gầy ít cơ**. Vì vậy phải **tính eGFR**.
> - Người **nhiều cơ**, ăn nhiều thịt, hoặc **uống creatin** (thực phẩm bổ sung tập gym) có creatinin cao hơn mà thận không bệnh. Khi đó có thể đo **cystatin C**.
> - **Ure tăng nhiều hơn creatinin** (tỷ ure/creatinin cao) gợi ý nguyên nhân **trước thận** (mất nước, xuất huyết tiêu hóa) hơn là tổn thương tại thận.

**Phân loại bệnh thận mạn theo eGFR** (KDIGO): bệnh thận mạn khi eGFR **< 60 mL/phút/1,73 m²** hoặc có dấu hiệu tổn thương thận (như **ACR ≥ 3 mg/mmol**) kéo dài **trên 3 tháng**.

| Giai đoạn | eGFR (mL/phút/1,73 m²) | Mô tả |
|---|---|---|
| G1 | ≥ 90 | Bình thường hoặc cao (cần có dấu hiệu tổn thương thận) |
| G2 | 60–89 | Giảm nhẹ |
| G3a | 45–59 | Giảm nhẹ – vừa |
| G3b | 30–44 | Giảm vừa – nặng |
| G4 | 15–29 | Giảm nặng |
| G5 | < 15 | **Suy thận** (cần lọc máu hoặc ghép thận) |

### 5.3. Albumin niệu

Đo **tỷ albumin/creatinin (ACR)** trên mẫu nước tiểu ngẫu nhiên (tốt nhất là buổi sáng): **A1 < 3 mg/mmol** (bình thường hoặc tăng nhẹ); **A2 3–30 mg/mmol** (tăng vừa); **A3 > 30 mg/mmol** (tăng nặng). Chia cho creatinin niệu để **loại bỏ ảnh hưởng của nước tiểu đặc hay loãng**.

### 5.4. Que thử nước tiểu 10 thông số

Que thử là một dải nhựa gắn 10 ô thuốc thử khô; nhúng vào nước tiểu tươi, đọc màu sau 1–2 phút (bằng mắt hoặc máy). Mỗi ô là một **phản ứng hóa sinh** đã học:

| Thông số | Nguyên lý | Bình thường | Ý nghĩa khi bất thường |
|---|---|---|---|
| **Glucose** | Enzym **glucose oxidase – peroxidase** (đặc hiệu cho glucose) | Âm tính | Đái tháo đường; glucose niệu do thận; thuốc ức chế SGLT2 |
| **Protein** | "Sai số protein" của chất chỉ thị pH (tetrabromophenol xanh) | Âm tính | Bệnh cầu thận… Que **nhạy với albumin**, **kém nhạy** với chuỗi nhẹ Bence Jones |
| **Thể ceton** | Natri **nitroprussid** | Âm tính | Đói, toan ceton đái tháo đường. Chỉ phát hiện **acetoacetat** (và aceton), **không** phát hiện β-hydroxybutyrat |
| **Bilirubin** | Phản ứng **diazo** | Âm tính | Viêm gan, tắc mật (bilirubin liên hợp) |
| **Urobilinogen** | Phản ứng Ehrlich hoặc diazo | Có lượng nhỏ (dương nhẹ) | Tăng: tan máu, viêm gan; mất: tắc mật hoàn toàn |
| **Máu** | Hoạt tính giống **peroxidase** của hem | Âm tính | Đái máu, hemoglobin niệu, myoglobin niệu |
| **Nitrit** | Phản ứng **Griess** | Âm tính | Nhiễm khuẩn Gram âm đường tiểu |
| **Bạch cầu** | **Esterase** của bạch cầu hạt trung tính | Âm tính | Nhiễm trùng, viêm đường tiết niệu |
| **pH** | Hai chất chỉ thị màu | 5–6 (4,5–8) | Xem mục 2.2 |
| **Tỷ trọng** | Polyelectrolyt đổi pKa theo nồng độ ion | 1,005–1,030 | Cao: mất nước, glucose niệu; thấp: uống nhiều, đái tháo nhạt |

> [!bay] Vitamin C và que thử
> **Acid ascorbic** liều cao (bổ sung vitamin C, một số nước ép trái cây) là **chất khử**, phá phản ứng oxy hóa – khử trên que → **âm tính giả** cho **glucose, máu, bilirubin, nitrit**. Ngược lại, nước tiểu **để lâu ở nhiệt độ phòng**: vi khuẩn sinh sôi → pH kiềm, nitrit dương giả; glucose bị vi khuẩn dùng hết; bilirubin, urobilinogen bị ánh sáng – oxy phân hủy. Quy tắc: **nước tiểu tươi, xét nghiệm trong vòng 1–2 giờ**.

### 5.5. Soi cặn nước tiểu

Ly tâm nước tiểu tươi, soi phần cặn dưới kính hiển vi:

- **Hồng cầu**: hồng cầu **biến dạng** gợi ý nguồn gốc **cầu thận**; hồng cầu hình dạng bình thường gợi ý chảy máu đường tiết niệu dưới (sỏi, u, viêm bàng quang).
- **Bạch cầu** (nhiều, kèm vi khuẩn): nhiễm trùng tiết niệu.
- **Trụ** — protein uromodulin đông lại trong lòng ống thận như "khuôn đúc": **trụ trong** (có thể gặp ở người bình thường, sau gắng sức), **trụ hồng cầu** (viêm cầu thận), **trụ bạch cầu** (viêm thận – bể thận), **trụ hạt** (tổn thương ống thận).
- **Tinh thể**: **acid uric/urat** (nước tiểu acid), **oxalat calci**, **phosphat** (nước tiểu kiềm). Gặp ở người bình thường, nhiều khi có nguy cơ **sỏi** (mục 2.2 — cách phân biệt urat và phosphat).

> [!vi-du] Đọc kết quả tổng hợp: ba tình huống
> 1. **Nam 55 tuổi, đái tháo đường 10 năm**: glucose niệu (+), protein que (±), **ACR 12 mg/mmol**, creatinin 110 µmol/L, **eGFR 65**. → Bệnh thận do đái tháo đường giai đoạn sớm (G2/A2). Cần kiểm soát đường huyết, huyết áp; cân nhắc ức chế men chuyển/chẹn thụ thể và ức chế SGLT2.
> 2. **Nữ 25 tuổi, tiểu buốt, tiểu rắt**: nitrit (+), bạch cầu (+++), máu (+), protein vết. → Nhiễm khuẩn đường tiết niệu dưới, vi khuẩn Gram âm.
> 3. **Bệnh nhân vàng da, phân bạc màu, ngứa**: bilirubin niệu (+++), **urobilinogen âm tính**. → Vàng da **tắc mật** (mục 4.4).

## Tóm tắt

| Chủ đề | Điểm chính |
|---|---|
| Thận | 300 g, 0,5% cơ thể, dùng 8–10% O~2~; ≈1 triệu nephron/thận; 180 L nước tiểu ban đầu/ngày |
| Áp lực lọc | **Pf = Pg − (Po + Pc) = 50 − (25 + 5) = 20 mmHg**; HA 60–70 mmHg → vô niệu |
| Màng lọc | 3 lớp (nội mô – màng đáy – biểu mô); chọn theo **kích thước** (42 Å ≈ 0), **điện tích** (âm khó qua: albumin 0,0375 vs dextran trung tính 0,24), **lưu lượng máu**, **hình dạng** |
| Không tái hấp thu | Inulin, mannitol, natri hyposulfit → đo mức lọc cầu thận |
| Glucose | Lọc 150 g/24 h, tái hấp thu **hoàn toàn** (đồng vận chuyển Na^+^, SGLT); ngưỡng **1,7 g/L**; phlorizin ức chế |
| Nước | 99%; ống lượn gần **80% bắt buộc**; phần cuối theo **ADH** |
| Na^+^ | Ống gần 70%; ống xa > 10% (renin, angiotensin II, aldosteron); tiêu tốn 90% O~2~ của thận |
| Ure / acid uric / creatinin | Ure tái hấp thu 40–50% thụ động; acid uric lọc + bài tiết + tái hấp thu 95–98%; creatinin theo dõi chức năng thận |
| Protein | 99% albumin lọt qua được ống lượn gần tái hấp thu (ẩm bào → lysosom) |
| Acid – base | CA; (1) tái hấp thu HCO~3~^−^ ở ống gần (90%); (2) muối acid HPO~4~^2−^ → H~2~PO~4~^−^, pH 7,4 → 6,0; (3) NH~4~^+^ từ glutamin (glutaminase), 30–50 mEq/ngày |
| Nội tiết | Renin cắt aa 10–11 (sách: Leu–Leu; người: Leu–Val) → angiotensin I (10 aa) → ACE cắt His-Leu → **angiotensin II (8 aa)** → aminopeptidase cắt Asp → angiotensin III (7 aa); Ep (REF); PGE~2~, PGI~2~ giãn mạch, TXA~2~ co mạch; 1,25-(OH)~2~D~3~; ANF thải Na^+^ |
| Nước tiểu | 1.000–1.400 mL/24 h; tỷ trọng 1,005–1,030; pH 5–6 (5,8); sức căng bề mặt 64–69 dyne/cm; ure 20–30 g/24 h (80–85% N niệu) |
| Chất bất thường | Glucose, protein (> 150 mg/24 h; Bence Jones), thể ceton, sắc tố – muối mật, hồng cầu – Hb, porphyrin, dưỡng chấp, nitrit |
| Xét nghiệm | C = U·V/P; creatinin → eGFR (CKD-EPI); ACR; que thử 10 thông số + soi cặn |

> [!vi-du] Câu hỏi ôn tập của giáo trình (tr. 304) và chỗ trả lời
> 1. Trình bày cơ chế lọc và tái hấp thu protein của thận → mục 1.2b và 1.3.6.
> 2. Trình bày vai trò của thận trong thăng bằng acid – base → mục 1.5 (và hs-16).
> 3. Trình bày các chất bất thường trong nước tiểu → mục 4.
