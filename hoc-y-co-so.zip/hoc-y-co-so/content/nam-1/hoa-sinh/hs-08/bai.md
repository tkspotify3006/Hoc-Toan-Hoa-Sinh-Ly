---
title: Chuyển hóa lipid và lipoprotein
thoi-gian: 60 phút
muc-tieu:
- Trình bày được sự thoái hóa acid béo bão hòa có số carbon chẵn (hoạt hóa, vận chuyển vào ty thể nhờ carnitin, bốn phản ứng β-oxy hóa) và tính được năng lượng thu được; nêu được điểm khác khi oxy hóa acid béo không bão hòa có một liên kết đôi.
- Trình bày được sự tạo thành thể ceton ở gan, sự sử dụng chúng ở mô ngoại vi và ý nghĩa (bình thường và bệnh lý).
- Trình bày được quá trình tổng hợp acid béo bão hòa ở bào tương (nguyên liệu, acetyl-CoA carboxylase, phức hợp acid béo synthase, sản phẩm) và ở ty thể; sự tạo liên kết đôi.
- Trình bày được sự thoái hóa và tổng hợp triglycerid và lecithin (glycerophospholipid).
- Nêu được nguồn gốc, các giai đoạn tổng hợp, điều hòa (HMG-CoA reductase) và đường đào thải cholesterol.
- Trình bày được cấu trúc, phân loại các lipoprotein huyết tương, đặc điểm và vai trò của từng loại; liên hệ rối loạn lipid máu, xơ vữa động mạch và xét nghiệm lipid máu.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. **Thoái hóa acid béo**: hoạt hóa thành acyl-CoA (tốn **2 ATP**) → vào ty thể nhờ **carnitin** (CPT I, CPT II) → **β-oxy hóa** 4 bước: khử H (**FAD**) → cộng nước → khử H (**NAD^+^**) → thiolase cắt ra **acetyl-CoA**. Palmitic (16C): 7 vòng, 8 acetyl-CoA, **129 ATP** theo sách (≈ 106 theo số liệu hiện nay).
> 2. **Thể ceton** (acetoacetat, β-hydroxybutyrat, aceton) do **gan** tạo từ acetyl-CoA (qua **HMG-CoA**), nhưng gan **không dùng**; cơ, tim, não (khi đói) dùng. Đói lâu, đái tháo đường thiếu insulin → tạo quá mức → **nhiễm toan ceton**.
> 3. **Tổng hợp acid béo** ở **bào tương**: acetyl-CoA (ra khỏi ty thể dưới dạng **citrat**) → **malonyl-CoA** (acetyl-CoA carboxylase, **biotin**) → phức hợp **acid béo synthase** (6 enzym + ACP), mỗi vòng thêm 2C, dùng **NADPH**, dừng ở **palmitic**.
> 4. **Cholesterol**: tổng hợp từ acetyl-CoA, bước điều hòa là **HMG-CoA reductase** (đích của **statin**); không bị đốt thành CO~2~, chỉ đào thải qua **mật** (acid mật, cholesterol).
> 5. **Lipoprotein**: **CM** (TG thức ăn, B-48) → **VLDL** (TG nội sinh từ gan, B-100) → IDL → **LDL** (giàu cholesterol, đưa cholesterol cho mô, "xấu") ; **HDL** (apoA-I, LCAT) đưa cholesterol **về gan** ("tốt").

Bài này dựa trên hai bài đã học, nên không nhắc lại: cấu tạo acid béo, triglycerid, phospholipid, cholesterol (bài *Hóa học lipid*); chu trình acid citric, chuỗi hô hấp và tỉ số P/O (bài *Năng lượng sinh học*). Ở đây ta xem lipid **được đốt, được tạo và được chở đi như thế nào**.

## 1. Lipid trong cơ thể: hai dạng, hai chức năng

Lipid trong cơ thể tồn tại ở hai dạng (Giáo trình tr. 126):

| | **Lipid dự trữ** | **Lipid màng** |
|---|---|---|
| Thành phần chính | **Triglycerid** (TG) | **Phospholipid** và **cholesterol** |
| Hàm lượng | **Thay đổi** (theo ăn uống, đói no, vận động) | **Hằng định**, khoảng **10% trọng lượng khô** |
| Vai trò | Kho năng lượng | Cấu trúc màng tế bào |

Ngoài **sinh năng lượng** và **cấu trúc**, lipid tạp còn quyết định đặc tính của màng; cholesterol là tiền chất **hormon steroid**; acid béo không no là tiền chất **prostaglandin**.

Nhu cầu lipid: **60–100 g/ngày** ở người trưởng thành, **30–80 g/ngày** ở trẻ em, chủ yếu dưới dạng triglycerid.

**Vì sao cơ thể dự trữ năng lượng bằng mỡ, không bằng glycogen?** Acid béo là chuỗi hydrocarbon **bị khử gần hết** nên khi oxy hóa cho nhiều năng lượng (khoảng 9 kcal/g, so với khoảng 4 kcal/g của glucid). Mỡ lại **kỵ nước**, dự trữ ở dạng khan; glycogen thì giữ rất nhiều nước. Cùng một lượng năng lượng, mỡ nhẹ hơn nhiều lần.

## 2. Thoái hóa lipid ở tế bào

Bước đầu tiên là **thủy phân triglycerid** nhờ **lipase**, cho **glycerol** và **acid béo** (chi tiết ở mục 2.5). Hai phần này đi theo hai con đường riêng.

### 2.1. Thoái hóa glycerol

Xảy ra ở **gan** và một số mô (thận, niêm mạc ruột, tuyến vú đang tiết sữa). **Mô mỡ không có glycerolkinase**, nên glycerol giải phóng từ mô mỡ phải theo máu về gan (Giáo trình tr. 126–127, 134).

=> Glycerol + ATP → Glycerol-3-phosphat + ADP

Enzym: *glycerolkinase*.

=> Glycerol-3-phosphat + NAD^+^ → Dihydroxyaceton phosphat + NADH + H^+^

Enzym: *glycerol-3-phosphat dehydrogenase*.

Dihydroxyaceton phosphat (DAP) được **isomerase** chuyển thành **glyceraldehyd-3-phosphat**, rồi đi tiếp theo đường phân → pyruvat → acetyl-CoA → chu trình acid citric (Giáo trình tr. 134–135). Ở gan, glycerol cũng có thể đi ngược lên để **tân tạo glucose**.

> [!bay]
> Trong cả phân tử triglycerid, **chỉ phần glycerol (3C) tạo được glucose**. Phần acid béo cho acetyl-CoA, mà pyruvat → acetyl-CoA không thuận nghịch (bài *Năng lượng sinh học*, mục 4.1). Vì vậy đói kéo dài, cơ thể vẫn phải phân giải protein cơ để có nguyên liệu tạo glucose.

### 2.2. Thoái hóa acid béo bão hòa có số carbon chẵn

#### a) Hoạt hóa acid béo

Acid béo tự do "trơ", phải gắn với **coenzym A** thành **acyl-CoA** mới chuyển hóa được (Giáo trình tr. 127):

=> R–COOH + ATP + CoA-SH → R–CO∼SCoA + AMP + PP~i~

Enzym: *acyl-CoA synthetase*.

- **Acyl-CoA synthetase** (còn gọi thiokinase) gồm nhiều isoenzym, đặc hiệu cho acid béo chuỗi ngắn, trung bình và dài; có ở **màng ngoài ty thể**.
- PP~i~ bị **pyrophosphatase** thủy phân ngay thành 2 P~i~. Phản ứng vì thế **kéo hẳn về một chiều**.
- AMP được tái tạo nhờ **adenylat kinase**: ATP + AMP ⇌ 2 ADP.

Kết quả: **hoạt hóa một acid béo tốn 2 ATP** (đúng hơn là tốn **2 liên kết phosphat giàu năng lượng**, vì ATP bị cắt đến AMP).

Giáo trình lưu ý thêm: trong ty thể cũng có một loại acyl-CoA synthetase hoạt hóa các acid béo nằm sẵn trong ty thể; enzym này dùng **GTP** chứ không dùng ATP (Giáo trình tr. 128).

#### b) Vận chuyển acid béo vào ty thể nhờ carnitin

β-oxy hóa xảy ra trong **chất nền (matrix) ty thể**. Nhưng acyl-CoA chuỗi dài **không đi qua được màng trong ty thể**. Chúng được đưa qua nhờ **carnitin**, một amin bậc 4 có chức alcol bậc hai, ester hóa được với acid béo (Giáo trình tr. 127–128):

1. **Carnitin acyltransferase I** (CPT I), ở **mặt ngoài màng trong**: chuyển gốc acyl từ CoA sang carnitin → **acyl-carnitin**.
2. Acyl-carnitin đi qua màng trong nhờ hệ vận chuyển **acyl-carnitin/carnitin** (đổi một acyl-carnitin vào lấy một carnitin ra).
3. **Carnitin acyltransferase II** (CPT II), ở **mặt trong màng trong**: trả gốc acyl về cho CoA của ty thể → acyl-CoA trong chất nền.
4. Carnitin tự do quay ra ngoài để chở chuyến tiếp theo.

**Vì sao phải "đổi xe" phức tạp như vậy?** Cơ chế này giữ cho **hai kho CoA và hai kho acid béo** ở trong và ngoài ty thể **tách biệt** nhau. Nhờ đó tế bào điều khiển được lượng acid béo đi vào để đốt.

> [!cap-nhat] Cửa ngõ CPT I là điểm điều hòa chính
> - Giáo trình không nêu điều hòa của β-oxy hóa. Hiện nay biết **CPT I là bước kiểm soát tốc độ**: nó bị **malonyl-CoA** ức chế. Malonyl-CoA là chất đầu tiên của con đường **tổng hợp** acid béo (mục 3.1). Khi tế bào no (insulin cao), malonyl-CoA tăng → khóa CPT I → acid béo vừa tạo **không bị đốt lại ngay**. Khi đói, malonyl-CoA giảm → CPT I mở → β-oxy hóa tăng.
> - Acid béo **chuỗi ngắn và trung bình** (dưới khoảng 12C) đi thẳng vào ty thể, **không cần carnitin**. Đó là một lý do dầu MCT (chứa acid béo chuỗi trung bình) được dùng cho người kém hấp thu mỡ hoặc rối loạn vận chuyển acid béo chuỗi dài.

#### c) Bốn phản ứng của β-oxy hóa

Gọi là **β-oxy hóa** vì carbon bị oxy hóa là **C~β~ (C3)**, tính từ nhóm carboxyl. Mỗi vòng gồm 4 phản ứng, cắt bỏ 2C ở đầu carboxyl dưới dạng **acetyl-CoA** (Giáo trình tr. 128–129).

![Hình 1. Một vòng β-oxy hóa trong chất nền ty thể. Màu cam: các sản phẩm mang năng lượng (FADH₂, NADH, acetyl-CoA)](beta-oxy-hoa.svg)

| Bước | Enzym | Coenzym | Sản phẩm |
|---|---|---|---|
| **1. Khử H lần 1** (nối đôi C~α~=C~β~) | **Acyl-CoA dehydrogenase** (4 loại theo độ dài chuỗi) | **FAD** | **trans-Δ^2^-enoyl-CoA** + FADH~2~ |
| **2. Cộng nước** | **Enoyl-CoA hydratase** | H~2~O | **L-3-hydroxyacyl-CoA** |
| **3. Khử H lần 2** (–OH thành ceto) | **β-hydroxyacyl-CoA dehydrogenase** | **NAD^+^** | **3-cetoacyl-CoA** + NADH |
| **4. Phân cắt** (giữa C~α~ và C~β~) | **Thiolase** (acyl-CoA acetyltransferase, β-cetothiolase) | **CoA-SH** | **Acetyl-CoA** + acyl-CoA ngắn đi 2C |

Một số chi tiết của sách:

- **Enoyl-CoA hydratase** đặc hiệu không gian: với nối đôi **trans**-Δ^2^ nó tạo dạng **L**; nó cũng cộng nước được vào nối đôi **cis**-Δ^2^ (của một số acid béo không no) nhưng khi đó tạo dạng **D**.
- **β-hydroxyacyl-CoA dehydrogenase** ít đặc hiệu với độ dài chuỗi, nhưng **đặc hiệu tuyệt đối với dạng L**.
- Acyl-CoA mới (ngắn đi 2C) lại vào vòng tiếp theo, cho đến khi chỉ còn một acetyl-CoA. Ví dụ **palmitic (16C)** → palmityl-CoA → **7 vòng** → **8 acetyl-CoA**.

> [!bay]
> - Thứ tự 4 bước: **khử H – cộng nước – khử H – cắt**. Nhớ: **"Oxy hóa – Hydrat hóa – Oxy hóa – Thiolase"**. Khử H lần 1 dùng **FAD**, lần 2 dùng **NAD^+^** (giống thứ tự succinat → fumarat → malat → oxaloacetat ở chu trình Krebs: FAD, cộng nước, NAD^+^).
> - Số vòng = (số C / 2) − 1, vì vòng cuối cùng cắt butyryl-CoA (4C) thành **2** acetyl-CoA. Palmitic: 7 vòng nhưng 8 acetyl-CoA.
> - Carnitin chỉ là **xe chở**, không tham gia 4 phản ứng.

> [!ung-dung] Khi β-oxy hóa bị tắc
> - **Thiếu MCAD** (acyl-CoA dehydrogenase chuỗi trung bình) là rối loạn oxy hóa acid béo hay gặp nhất, di truyền lặn. Trẻ khỏe mạnh bình thường, nhưng khi **nhịn đói** hoặc ốm nôn thì **hạ đường huyết** mà **ceton máu không tăng tương xứng** ("hạ đường huyết không ceton"), có thể hôn mê, đột tử. Vì sao không có ceton? Không đốt được acid béo thì **không có acetyl-CoA để tạo thể ceton**; gan cũng thiếu ATP để tân tạo glucose. Nhiều nước đưa bệnh này vào **sàng lọc sơ sinh** (đo acylcarnitin trong giọt máu khô). Xử trí: **không để đói lâu**, cung cấp glucose khi ốm.
> - **Thiếu carnitin** hoặc **thiếu CPT II**: yếu cơ, đau cơ, **tiêu cơ vân** khi gắng sức kéo dài hoặc nhịn đói (cơ sống nhờ acid béo khi vận động lâu).

#### d) Bilan năng lượng

Theo giáo trình (tr. 129), với acid béo có **2n** carbon:

| Nguồn | Số lượng | ATP theo giáo trình |
|---|---|---|
| Acetyl-CoA → chu trình Krebs (12 ATP mỗi phân tử) | n | 12n |
| FADH~2~ (bước 1) → chuỗi hô hấp | n − 1 | 2(n − 1) |
| NADH (bước 3) → chuỗi hô hấp | n − 1 | 3(n − 1) |
| Hoạt hóa | | − 2 |
| **Tổng** | | **12n + 5(n − 1) − 2 = 17n − 7** |

> [!vi-du] Tính cho acid palmitic (16C, n = 8)
> - 8 acetyl-CoA × 12 = 96
> - 7 FADH~2~ × 2 = 14 ; 7 NADH × 3 = 21
> - Trừ 2 ATP hoạt hóa
> - **= 129 ATP** (kiểm tra bằng công thức: 17 × 8 − 7 = 129).
>
> Acid stearic (C~18~, n = 9): 17 × 9 − 7 = **146 ATP**.

> [!cap-nhat] Palmitic cho bao nhiêu ATP — giáo trình ghi / hiện nay
> - **Giáo trình**: NADH = 3, FADH~2~ = 2, mỗi acetyl-CoA = 12 ATP → **129 ATP**.
> - **Hiện nay** (P/O ≈ 2,5 và 1,5; mỗi vòng Krebs ≈ 10 ATP, xem bài *Năng lượng sinh học*, mục 2.4): 8 × 10 + 7 × 1,5 + 7 × 2,5 − 2 = 80 + 10,5 + 17,5 − 2 = **106 ATP**.
> - Dù tính theo cách nào, **một palmitic (16C) cho năng lượng gấp khoảng 3,5 lần một glucose (6C)**. Tính trên mỗi carbon, acid béo vẫn "giàu" hơn, vì carbon của nó bị khử nhiều hơn.
> - **Đi thi: trả lời 129 ATP** (theo sách) trừ khi đề hỏi số liệu hiện nay.

### 2.3. Thoái hóa acid béo không bão hòa

Acid béo không bão hòa (ví dụ acid oleic) đi gần như cùng đường với acid béo bão hòa, nhưng gặp **hai vướng mắc** (Giáo trình tr. 129–131):

1. Nối đôi trong acid béo tự nhiên có dạng **cis**, còn chất trung gian của β-oxy hóa có nối đôi dạng **trans**.
2. Sau khi cắt dần từng mẩu 2C, nối đôi tự nhiên thường rơi vào vị trí **Δ^3^**, không phải Δ^2^ như chất trung gian bình thường.

**Acid oleic** (18:1, cis-Δ^9^):

1. Oleyl-CoA qua **3 vòng** β-oxy hóa → **3 acetyl-CoA** + **cis-Δ^3^-dodecenoyl-CoA** (12C).
2. Chất này **không** là cơ chất của enoyl-CoA hydratase (enzym chỉ tác dụng lên nối đôi trans-Δ^2^).
3. **Enoyl-CoA isomerase** chuyển cis-Δ^3^ thành **trans-Δ^2^-enoyl-CoA**, vốn là chất trung gian bình thường.
4. Từ đây β-oxy hóa tiếp tục (bắt đầu từ bước cộng nước) cho đến hết. Tổng cộng **9 acetyl-CoA**.

**Acid béo nhiều nối đôi** (ví dụ **acid linoleic**, 18:2 cis-Δ^9^,cis-Δ^12^) cần thêm enzym phụ: ngoài **enoyl-CoA isomerase** còn cần **2,4-dienoyl-CoA reductase**, enzym dùng **NADPH** để khử một trong hai nối đôi liền kề (Giáo trình tr. 131). Nhờ các enzym phụ này, **mọi acid béo không no** trong lipid tự nhiên đều được oxy hóa hoàn toàn.

> [!bay]
> - Oleic (18C, 1 nối đôi) và stearic (18C, no) đều cho **9 acetyl-CoA**. Nhưng ở vòng có nối đôi sẵn, **bước khử H lần 1 (FAD) bị bỏ qua**. Vì vậy oleic cho **ít hơn stearic 1 FADH~2~**: theo cách tính của sách là 146 − 2 = **144 ATP**.
> - Enzym phụ cho **1 nối đôi**: chỉ **isomerase**. Cho **nhiều nối đôi**: isomerase **+ 2,4-dienoyl-CoA reductase (NADPH)**.
> - Hình 8.3 của giáo trình ghi "β oxy hóa (5 vòng)" ở bước đầu, nhưng phần chữ (và số 3 acetyl-CoA) cho thấy đúng là **3 vòng**.

### 2.4. Thể ceton và sự oxy hóa chúng

#### a) Tạo thể ceton ở gan

Ở gan, acetyl-CoA từ β-oxy hóa có thể vào chu trình acid citric, hoặc tạo **thể ceton** để gửi đi cho các mô khác dùng. Thể ceton gồm **acetoacetat**, **D-β-hydroxybutyrat** và **aceton** (Giáo trình tr. 131–132). Quá trình xảy ra trong **ty thể tế bào gan**:

1. 2 acetyl-CoA → **acetoacetyl-CoA** + CoA-SH *(β-cetothiolase)*
2. Acetoacetyl-CoA + acetyl-CoA + H~2~O → **HMG-CoA** (β-hydroxy-β-methylglutaryl-CoA) + CoA-SH *(HMG-CoA synthase)*
3. HMG-CoA → **acetoacetat** + acetyl-CoA *(HMG-CoA lyase)*
4. Acetoacetat + NADH + H^+^ ⇌ **D-β-hydroxybutyrat** + NAD^+^ *(D-β-hydroxybutyrat dehydrogenase)*
5. Acetoacetat → **aceton** + CO~2~ (tự phát, không cần enzym, lượng rất ít ở người khỏe)

Acetoacetat và β-hydroxybutyrat **tan trong nước**, khuếch tán ra khỏi gan, theo máu tới **cơ xương, cơ tim, vỏ thượng thận**… Bình thường não dùng chủ yếu glucose. Khi **đói kéo dài**, não dùng β-hydroxybutyrat làm "chất đốt" chính; theo giáo trình, khoảng **75%** năng lượng của não lúc đó đến từ thể ceton (Giáo trình tr. 132).

#### b) Sử dụng thể ceton ở mô ngoại vi

1. D-β-hydroxybutyrat + NAD^+^ → acetoacetat + NADH + H^+^
2. Acetoacetat + **succinyl-CoA** → **acetoacetyl-CoA** + succinat *(β-cetoacyl-CoA transferase)*
3. Acetoacetyl-CoA + CoA-SH → **2 acetyl-CoA** *(thiolase)* → chu trình acid citric

(Giáo trình tr. 132–133.)

**Vì sao gan tạo thể ceton mà không tự dùng?** Gan **thiếu β-cetoacyl-CoA transferase** (bước 2 ở trên), nên không hoạt hóa lại được acetoacetat. Nhờ vậy thể ceton không bị "tiêu thụ tại chỗ", mà là **nhiên liệu tan trong nước gan xuất khẩu** cho các mô khác, đặc biệt cho não (acid béo gắn albumin không qua được hàng rào máu não).

> [!bay]
> - **HMG-CoA** là "ngã ba" của hai con đường: trong **ty thể** gan nó cho **thể ceton** (nhờ **HMG-CoA lyase**); trong **bào tương** nó cho **cholesterol** (nhờ **HMG-CoA reductase**, mục 4.2). Hai HMG-CoA synthase ở hai nơi là hai isoenzym khác nhau.
> - **Aceton không được dùng làm nhiên liệu**; nó bay hơi qua phổi (hơi thở mùi "táo chín", mùi aceton).
> - Acetoacetat và β-hydroxybutyrat là **acid** (gọi "thể ceton" theo thói quen, dù β-hydroxybutyrat không có nhóm ceto).

#### c) Thể ceton bệnh lý

Bình thường nồng độ thể ceton trong máu **rất thấp**. Khi **đói** hoặc **đái tháo đường**, thoái hóa glucid giảm, cơ thể phải đốt lipid dự trữ để bù. Thể ceton tăng cao trong máu và nước tiểu, đôi khi có **mùi aceton trong hơi thở** (Giáo trình tr. 133).

Giáo trình giải thích đây là hậu quả **mất cân đối giữa chuyển hóa glucid và lipid**, dẫn đến:

- **Thiếu NADPH** (tạo từ con đường hexose monophosphat), cần cho tổng hợp acid béo, nên acetyl-CoA không được dùng để tổng hợp lại acid béo.
- **Thiếu succinyl-CoA** (chất trung gian của chu trình acid citric), chất cung cấp CoA để hoạt hóa acetoacetat ở mô.

Tóm lại, thể ceton **ứ đọng** khi **tốc độ tạo ở gan vượt quá khả năng sử dụng ở mô ngoại vi**.

> [!cap-nhat] Cơ chế tạo thể ceton quá mức — cách giải thích hiện nay
> Hiện nay nhấn mạnh vai trò của **insulin thấp, glucagon cao**:
> 1. Lipase mô mỡ được hoạt hóa mạnh → **acid béo tự do** đổ về gan rất nhiều.
> 2. Malonyl-CoA trong gan giảm → **CPT I mở** → β-oxy hóa chạy tối đa, tạo rất nhiều acetyl-CoA.
> 3. Gan đang **tân tạo glucose** nên rút **oxaloacetat** ra khỏi ty thể. Thiếu oxaloacetat, acetyl-CoA **không vào được chu trình acid citric** và bị dồn sang tạo thể ceton.
>
> Ý cuối cùng của sách (tạo vượt quá dùng) vẫn đúng. Đi thi trình bày theo sách; có thể bổ sung các ý trên.

> [!ung-dung] Nhiễm toan ceton và xét nghiệm thể ceton
> - **Nhiễm toan ceton do đái tháo đường (DKA)**, hay gặp ở đái tháo đường **typ 1** (thiếu insulin tuyệt đối) hoặc khi bỏ tiêm insulin, nhiễm trùng. Biểu hiện: khát, tiểu nhiều, nôn, đau bụng, **thở nhanh sâu (Kussmaul)**, hơi thở mùi aceton, lơ mơ. Xét nghiệm: **toan chuyển hóa tăng khoảng trống anion** (thể ceton là acid).
> - Tiêu chuẩn chẩn đoán hay dùng (tham khảo, theo đồng thuận quốc tế gần đây): glucose máu **≥ 11,1 mmol/L** (hoặc đã biết đái tháo đường), **β-hydroxybutyrat máu ≥ 3,0 mmol/L**, **pH < 7,3** và/hoặc **HCO~3~^−^ < 18 mmol/L**. β-hydroxybutyrat máu bình thường **< 0,6 mmol/L** (tham khảo, mỗi phòng xét nghiệm có khoảng riêng).
> - **Que thử nước tiểu (phản ứng nitroprussid)** chỉ phát hiện **acetoacetat** (và aceton), **không** phát hiện β-hydroxybutyrat. Trong DKA, NADH dư thừa đẩy cân bằng về phía β-hydroxybutyrat (tỉ lệ có thể tới khoảng 10:1), nên que thử có thể **đánh giá thấp** mức độ nặng. Khi điều trị, β-hydroxybutyrat chuyển ngược về acetoacetat, que thử có thể "đậm lên" dù bệnh đang cải thiện. Vì vậy hiện nay ưu tiên **đo β-hydroxybutyrat máu**.
> - **Nhiễm ceton do đói** và chế độ ăn rất ít glucid ("keto"): thể ceton tăng vừa phải, insulin vẫn còn nên thường không toan nặng.
> - **Thuốc ức chế SGLT2** (nhóm "-gliflozin") có thể gây **nhiễm toan ceton với đường huyết gần bình thường**, dễ bị bỏ sót nếu chỉ nhìn đường huyết.

### 2.5. Thoái hóa triglycerid

**Lipase** thủy phân triglycerid **từng bước** (Giáo trình tr. 133–134):

1. Hai liên kết ester ở **C~1~ và C~3~** bị thủy phân **khá nhanh** → **2-monoglycerid**.
2. 2-monoglycerid bị thủy phân **chậm**; nó được **isomerase** chuyển thành 1-monoglycerid rồi lipase cắt tiếp → **glycerol**.

=> Triglycerid + 3 H~2~O → Glycerol + 3 acid béo

Enzym: *lipase*.

**Lipase nhạy cảm với hormon** khu trú ở tế bào mỡ. Enzym **hoạt động khi được phosphoryl hóa**, cần **protein kinase** và **ATP**:

=> Hormon → **cAMP** ↑ → protein kinase → **lipase-P** (hoạt động)

cAMP do **adenylat cyclase** tạo ra từ ATP khi hormon gắn thụ thể.

Hormon hoạt hóa lipase qua cAMP là **adrenalin, noradrenalin, glucagon** (khi đói, stress, vận động). **Insulin ức chế** quá trình này (lúc no, dự trữ mỡ). *(Phần tên hormon là bổ sung; giáo trình chỉ ghi "nhạy cảm với hormon".)*

Sản phẩm của thoái hóa triglycerid (Giáo trình tr. 134–135):

- **Glycerol** → máu → **gan** (mục 2.1).
- **Acid béo tự do** → máu, gắn với **albumin** huyết tương thành một dạng lipoprotein → đến các mô (cơ, tim, gan…) để β-oxy hóa.

> [!cap-nhat] Ba lipase của mô mỡ
> - Sơ đồ của giáo trình có ghi "Lipase → Phospholipase". Theo nội dung, đây là dạng **lipase đã phosphoryl hóa** (lipase-P), không phải enzym phospholipase.
> - Hiện nay biết phân giải mỡ trong tế bào mỡ cần **ba enzym nối tiếp**: **ATGL** (TG → diglycerid), **lipase nhạy cảm hormon, HSL** (diglycerid → monoglycerid) và **monoglycerid lipase** (→ glycerol). Protein kinase A phosphoryl hóa cả HSL lẫn **perilipin** (protein bọc giọt mỡ), mở đường cho lipase tiếp cận giọt mỡ.

### 2.6. Thoái hóa glycerophospholipid

Nhiều **phospholipase** có ở các mô; mỗi enzym cắt một liên kết ester riêng (Giáo trình tr. 135–136). Nhắc lại cấu tạo lecithin ở bài *Hóa học lipid*, mục 6.1.

| Enzym | Cắt liên kết | Sản phẩm |
|---|---|---|
| **Phospholipase A** | Ester ở **C~2~** (C~β~) | 1 acid béo + **lysophospholipid** |
| **Phospholipase B** | Ester ở **C~1~** và **C~2~** | 2 acid béo + glycerophosphat-base nitơ |
| **Lysophospholipase** | Ester ở **C~1~** của lysophospholipid | 1 acid béo |
| **Phospholipase C** (một phosphodiesterase) | Giữa **glycerol và acid phosphoric** | **Diglycerid** + base nitơ đã phosphoryl hóa (ví dụ phosphocholin) |
| **Phospholipase D** (gặp ở thực vật) | Giữa **acid phosphoric và base nitơ** | **Acid phosphatidic** + base nitơ |
| **Phosphomonoesterase** (phosphatase) | Thủy phân tiếp sản phẩm của phosphodiesterase | Ví dụ phosphocholin → cholin + acid phosphoric |

**Lysophospholipid** thường gặp: **lysolecithin** (lysophosphatidylcholin) và **lysocephalin**. Chúng là **chất tẩy** mạnh, phá màng tế bào, gây **vỡ hồng cầu**. **Nọc rắn, nọc ong** và **dịch tụy** giàu phospholipase A (Giáo trình tr. 135–136).

**Lecithin-cholesterol acyltransferase (LCAT)** có ở gan và huyết tương: chuyển gốc acyl ở **C~2~ của lecithin** sang cholesterol, tạo **cholesterol ester** và **lysolecithin** (Giáo trình tr. 136). Enzym này sẽ gặp lại ở HDL (mục 5.2).

=> Lecithin + Cholesterol → Lysolecithin + Cholesterol ester

Enzym: *LCAT*.

> [!ung-dung] Phospholipase trong y học
> - **Rắn cắn**: phospholipase A của nọc tạo lysolecithin, gây **tan máu**, tổn thương cơ và mạch máu tại chỗ.
> - **Viêm tụy cấp**: phospholipase A và lipase của tụy được hoạt hóa ngay trong tụy, "tự tiêu" mô tụy và mỡ quanh tụy. Xét nghiệm hay dùng là **lipase** (và amylase) máu tăng cao.
> - Tên gọi hiện nay: enzym cắt ở C~2~ là **phospholipase A~2~**, cắt ở C~1~ là phospholipase A~1~. Phospholipase A~2~ của màng tế bào giải phóng **acid arachidonic**, nguyên liệu tạo prostaglandin (đích gián tiếp của thuốc corticoid). **Phospholipase C** cắt phosphatidylinositol tạo **IP~3~ và diacylglycerol**, hai "chất truyền tin thứ hai" của nhiều hormon.

## 3. Tổng hợp lipid ở tế bào

### 3.1. Tổng hợp acid béo bão hòa ở bào tương

Acid béo được tổng hợp ở mọi mô, mạnh nhất ở **gan, mô mỡ, ruột** và **tuyến vú** đang tiết sữa. Có ít nhất **3 hệ thống**: ở **bào tương**, ở **ty thể** và ở **microsom**; trong đó **bào tương đóng vai trò chủ yếu**. Tổng hợp và thoái hóa acid béo đi theo **hai con đường khác nhau**, ở **hai nơi khác nhau**, với **hai bộ enzym khác nhau** (Giáo trình tr. 136–137).

#### a) Nguyên liệu: acetyl-CoA từ ty thể ra bào tương

Acetyl-CoA được tạo trong **ty thể** (từ pyruvat, từ một số acid amin/amino acid, từ β-oxy hóa) nhưng màng trong không cho nó đi qua. Nó được đưa ra bào tương bằng hai cách (Giáo trình tr. 137):

1. **Hệ vận chuyển tricarboxylat (citrat)**:

=> Trong ty thể: Acetyl-CoA + Oxaloacetat → Citrat + CoA-SH

=> Bào tương: Citrat + ATP + CoA-SH → Oxaloacetat + ADP + P~i~ + Acetyl-CoA

Ở bào tương, oxaloacetat được khử thành **malat** (dùng NADH), malat chuyển thành **pyruvat** rồi pyruvat quay về ty thể. Bước malat → pyruvat (do **enzym malic**) tạo thêm **NADPH** cho tổng hợp acid béo.

2. **Nhờ carnitin**: acetyl-CoA → acetyl-carnitin → qua màng → acetyl-CoA (cũng nhờ carnitin acyltransferase I và II, như mục 2.2b nhưng theo chiều ngược lại).

**Vì sao "citrat" lại là tín hiệu tổng hợp mỡ?** Citrat chỉ dư thừa ra bào tương khi chu trình acid citric đã đủ nhiên liệu, tức tế bào **thừa năng lượng**. Lúc đó cơ thể cất phần thừa thành mỡ.

#### b) Malonyl-CoA: chất trung gian then chốt

**Acetyl-CoA carboxylase** gắn CO~2~ vào acetyl-CoA tạo **malonyl-CoA** (3C) (Giáo trình tr. 138). Enzym có **3 vùng chức năng**:

- **Protein mang biotin** (biotin là coenzym, vitamin B~7~/H);
- **Biotin carboxylase**: hoạt hóa CO~2~ (từ HCO~3~^−^) bằng cách gắn vào nguyên tử N của vòng biotin, phản ứng cần **ATP**;
- **Transcarboxylase**: chuyển CO~2~ đã hoạt hóa từ biotin sang acetyl-CoA.

=> Acetyl-CoA + HCO~3~^−^ + ATP → Malonyl-CoA + ADP + P~i~

Enzym: *acetyl-CoA carboxylase* (coenzym **biotin**).

> [!cap-nhat] Acetyl-CoA carboxylase là bước điều hòa của tổng hợp acid béo
> Giáo trình không nêu điều hòa. Hiện nay biết đây là **bước giới hạn tốc độ**:
> - **Citrat** hoạt hóa (dị lập thể); **palmitoyl-CoA** (sản phẩm cuối) ức chế.
> - **Insulin** hoạt hóa (khử phosphoryl enzym); **glucagon, adrenalin** và **AMPK** (khi tế bào thiếu năng lượng) **phosphoryl hóa, làm bất hoạt** enzym.
> - Sản phẩm malonyl-CoA đồng thời **ức chế CPT I** (mục 2.2b): tế bào **không vừa tổng hợp vừa đốt** acid béo cùng lúc.

#### c) Phức hợp acid béo synthase

Chuỗi phản ứng tổng hợp do một **phức hợp đa enzym** gọi là **acid béo synthase** xúc tác. Phức hợp gồm **6 enzym** và **1 protein không có hoạt tính enzym** (Giáo trình tr. 138):

| Viết tắt | Enzym | Việc làm |
|---|---|---|
| **AT** | ACP-acyltransferase | Nạp nhóm acetyl |
| **MT** | ACP-malonyltransferase | Nạp nhóm malonyl lên ACP |
| **KS** | β-cetoacyl-ACP synthase | **Ngưng tụ** |
| **KR** | β-cetoacyl-ACP reductase | **Khử lần 1** (NADPH) |
| **HD** | β-hydroxyacyl-ACP dehydratase | **Khử nước** |
| **ER** | Enoyl-ACP reductase | **Khử lần 2** (NADPH) |
| **ACP** | Protein mang nhóm acyl (acyl carrier protein) | Mang chuỗi đang kéo dài |

Phức hợp có **2 nhóm –SH**:

- **–SH trung tâm**: thuộc **ACP** (đầu phosphopantethein, giống phần hoạt động của CoA). Đây là "cánh tay" dài đưa chuỗi acyl lần lượt qua các enzym.
- **–SH ngoại vi**: thuộc **cystein** của enzym **KS**.

#### d) Các phản ứng (Giáo trình tr. 138–139)

1. **Nạp nguyên liệu**: nhóm **acetyl** ester hóa với **–SH ngoại vi** (KS), nhóm **malonyl** ester hóa với **–SH trung tâm** (ACP).
2. **Ngưng tụ** (KS): nhóm acetyl được chuyển đến C~2~ của nhóm malonyl, **đồng thời khử carboxyl** (giải phóng CO~2~) → **acetoacetyl-ACP** (4C).
3. **Khử lần 1** (KR, NADPH) → **β-hydroxybutyryl-ACP**.
4. **Khử nước** (HD) → **crotonyl-ACP** (enoyl-ACP, có nối đôi).
5. **Khử lần 2** (ER, NADPH) → **butyryl-ACP** (4C, bão hòa).
6. Nhóm butyryl được chuyển sang **–SH của KS**, để ACP **nhận một malonyl mới** từ malonyl-CoA. Chuỗi phản ứng lặp lại, mỗi vòng thêm 2C.

Sau **7 vòng** thu được **palmityl-ACP** (16C). Gốc palmityl được **thioesterase** giải phóng thành **acid palmitic** tự do, hoặc chuyển sang CoA thành palmityl-CoA. Ở hầu hết sinh vật, tổng hợp ở bào tương **dừng ở palmitic**, có lẽ do KS chỉ nhận gốc acyl đến độ dài nhất định (Giáo trình tr. 139).

Phương trình tổng quát (bổ sung để tính toán):

=> Acetyl-CoA + 7 Malonyl-CoA + 14 NADPH + 14 H^+^ → Palmitat + 7 CO~2~ + 8 CoA-SH + 14 NADP^+^ + 6 H~2~O

Cộng thêm **7 ATP** để tạo 7 malonyl-CoA.

> [!bay]
> - CO~2~ gắn vào ở bước acetyl-CoA carboxylase **lại bị tách ra** ở bước ngưng tụ. Vì vậy **carbon của CO~2~ không đi vào acid béo**: cả 16C của palmitic đều đến từ acetyl-CoA. CO~2~ chỉ là "chất xúc tác" giúp phản ứng ngưng tụ thuận lợi về năng lượng.
> - Chỉ **2 carbon đầu mạch (C15, C16, phía đầu methyl)** đến trực tiếp từ acetyl-CoA "mồi"; 14C còn lại đến từ **malonyl-CoA**.
> - Tổng hợp dùng **NADPH**, không dùng NADH. NADPH đến chủ yếu từ **con đường hexose monophosphat** (pentose phosphat, bài *Chuyển hóa glucid*) và từ **enzym malic**.

**So sánh tổng hợp và thoái hóa acid béo**

| | **β-oxy hóa** | **Tổng hợp (bào tương)** |
|---|---|---|
| Nơi xảy ra | **Chất nền ty thể** | **Bào tương** |
| Chất mang gốc acyl | **CoA** | **ACP** |
| Đơn vị 2C | Tách ra dạng **acetyl-CoA** | Thêm vào từ **malonyl-CoA** (3C, mất CO~2~) |
| Coenzym oxy hóa–khử | **FAD, NAD^+^** (nhận H) | **NADPH** (cho H) |
| Chất trung gian 3-hydroxy | Dạng **L** | Dạng **D** *(bổ sung)* |
| Enzym | Các enzym **riêng rẽ** | **Phức hợp đa enzym** |
| Vận chuyển qua màng ty thể | Acyl đi **vào** nhờ **carnitin** | Acetyl đi **ra** dưới dạng **citrat** |
| Thời điểm | Đói, vận động (glucagon, adrenalin) | No, thừa glucid (insulin) |

### 3.2. Tổng hợp acid béo ở ty thể

Ty thể **kéo dài** mạch acid béo có sẵn, tiền chất là **acid palmitic**. Cơ chế giống **β-oxy hóa chạy ngược**, chất mang gốc acyl là **coenzym A** (Giáo trình tr. 140):

1. **Ngưng tụ**: acyl-CoA (nC) + acetyl-CoA → β-cetoacyl-CoA (n+2 C) *(β-cetothiolase)*
2. **Khử lần 1**: → β-hydroxyacyl-CoA *(β-cetoacyl-CoA reductase, **NADH**)*
3. **Khử nước**: → trans-Δ^2^-enoyl-CoA *(crotonase)*
4. **Khử lần 2**: → acyl-CoA (n+2 C) *(trans-Δ^2^-enoyl-CoA reductase, **NADPH**)*

Câu hỏi ôn tập của giáo trình hỏi **liên quan giữa tổng hợp ở bào tương và ở ty thể**: bào tương tạo **palmitic** từ đầu (de novo, qua malonyl-CoA); ty thể nhận palmitic và **kéo dài** thêm (qua acetyl-CoA).

> [!cap-nhat] Kéo dài mạch và vận chuyển acetyl-CoA
> - Hiện nay biết hệ kéo dài mạch **chủ yếu** nằm ở **lưới nội bào** (microsom), dùng **malonyl-CoA** và NADPH (các enzym "elongase"). Hệ ở ty thể chỉ đóng góp nhỏ.
> - Con đường đưa acetyl-CoA ra bào tương để tổng hợp acid béo **chủ yếu là citrat** (enzym ở bào tương tên là **ATP-citrat lyase**). Con đường carnitin (acetyl-carnitin) có tồn tại nhưng đóng góp ít.

### 3.3. Tổng hợp acid béo không bão hòa có một liên kết đôi

Ở động vật, **acid palmitic** và **acid stearic** là tiền chất của hai acid béo một nối đôi phổ biến: **acid palmitoleic 16:1(Δ^9^)** và **acid oleic 18:1(Δ^9^)** (Giáo trình tr. 140–141).

- Xảy ra ở **lưới nội bào** của gan và mô mỡ, nhờ một hệ **mono-oxygenase** (gọi là **Δ^9^-desaturase**).
- **Một phân tử O~2~ nhận 2 cặp điện tử**: một cặp từ acid béo bão hòa (tạo nối đôi), một cặp từ **NADPH**. Cả hai nguyên tử oxy thành 2 H~2~O.
- Điện tử từ NADPH đi qua **chuỗi vận chuyển điện tử của microsom**: **cytochrom b~5~ reductase (FAD)** → **cytochrom b~5~** → desaturase.

=> Stearoyl-CoA + NADPH + H^+^ + O~2~ → Oleoyl-CoA + NADP^+^ + 2 H~2~O

> [!bay]
> Người và động vật có vú chỉ tạo được nối đôi **từ Δ^9^ trở về phía nhóm carboxyl**; **không** tạo được nối đôi ở **Δ^12^ và Δ^15^** (phía đầu methyl). Vì vậy **acid linoleic** (ω-6) và **acid α-linolenic** (ω-3) là **acid béo thiết yếu**, phải lấy từ thức ăn (bài *Hóa học lipid*, mục 2.3). Cơ thể vẫn kéo dài và tạo thêm nối đôi trên nền hai acid này, ví dụ linoleic → **arachidonic**.

### 3.4. Tổng hợp triglycerid

Triglycerid được tổng hợp mạnh ở **gan** và **mô mỡ** của động vật có xương sống, và ở thực vật bậc cao. Hai tiền chất chính là **glycerol-3-phosphat** và **acyl-CoA** (Giáo trình tr. 141–142).

**Glycerol-3-phosphat** có hai nguồn:

1. Từ **dihydroxyaceton phosphat** (sản phẩm đường phân) nhờ **glycerol-3-phosphat dehydrogenase** (NADH) ở bào tương.
2. Từ **glycerol tự do** nhờ **glycerolkinase** (có ở **gan, thận**).

**Các bước:**

1. Glycerol-3-phosphat + 2 acyl-CoA → **acid phosphatidic** + 2 CoA-SH *(acyltransferase)*
2. Acid phosphatidic + H~2~O → **1,2-diglycerid** + P~i~ *(phosphatidat phosphatase)*
3. 1,2-diglycerid + acyl-CoA → **triglycerid** + CoA-SH *(acyltransferase)*

**Ở niêm mạc ruột**, trong lúc hấp thu mỡ, con đường khác chiếm ưu thế: **monoglycerid** (sản phẩm tiêu hóa) được **acyl hóa trực tiếp** nhờ **monoglycerid palmityltransferase**, **không qua acid phosphatidic**. Triglycerid trong mỡ dự trữ thường là **triglycerid hỗn hợp** (3 gốc acid béo khác nhau).

> [!bay]
> - **Acid phosphatidic** (và diglycerid) là **chất trung gian chung** của tổng hợp **triglycerid** và **glycerophospholipid**.
> - **Mô mỡ không có glycerolkinase** → không dùng được glycerol tự do. Muốn tạo glycerol-3-phosphat, tế bào mỡ phải có **glucose** (qua đường phân → DAP). Đây là lý do **insulin** (giúp glucose vào tế bào mỡ qua GLUT4) cần cho việc **tích mỡ**, và glycerol từ phân giải mỡ **không bị tế bào mỡ dùng lại** mà về gan.

### 3.5. Tổng hợp glycerophospholipid

Glycerophospholipid của màng tế bào và của lipoprotein đều được tổng hợp từ **acid phosphatidic** (qua diglycerid), với **cytidin nucleotid** (CTP → CDP-base) làm **chất vận chuyển** base nitơ. Các enzym thường **gắn chặt vào màng lưới nội bào** (Giáo trình tr. 142–143).

#### a) Tổng hợp phosphatidylethanolamin (cephalin)

=> Ethanolamin + ATP → Phosphoethanolamin + ADP

Enzym: *ethanolamin kinase*.

=> Phosphoethanolamin + CTP → **CDP-ethanolamin** + PP~i~

Enzym: *phosphoethanolamin cytidyltransferase*.

=> CDP-ethanolamin + 1,2-diglycerid → **Cephalin** + CMP

Enzym: *phosphoethanolamin transferase*.

#### b) Tổng hợp phosphatidylcholin (lecithin)

Ở động vật, lecithin tạo theo **hai con đường** (Giáo trình tr. 143):

1. **Methyl hóa cephalin**: nhóm amin của cephalin nhận **3 nhóm methyl** từ **S-adenosylmethionin (SAM)** → lecithin + S-adenosylhomocystein *(phosphatidylethanolamin methyltransferase; chủ yếu ở gan)*.
2. **Dùng cholin** từ thức ăn hoặc từ thủy phân lecithin, đi theo đường giống hệt cephalin: cholin → **phosphocholin** (cholin kinase, ATP) → **CDP-cholin** (phosphocholin cytidyltransferase, CTP) → + diglycerid → **lecithin** (phosphocholin transferase, giải phóng CMP).

> [!ung-dung] Cholin, methionin và gan nhiễm mỡ
> Gan cần lecithin để "đóng gói" triglycerid vào **VLDL** đưa ra máu (mục 5.2). Thiếu **cholin** hoặc thiếu **methionin** (nguồn nhóm methyl của SAM) → gan không tạo đủ lecithin → triglycerid ứ lại trong gan → **gan nhiễm mỡ**. Vì vậy cholin, methionin được gọi là **yếu tố hướng mỡ** (lipotropic). Nuôi dưỡng tĩnh mạch kéo dài thiếu cholin cũng có thể gây gan nhiễm mỡ.

## 4. Chuyển hóa cholesterol

### 4.1. Nguồn gốc, vai trò và đào thải

Cholesterol cần cho **cấu tạo màng tế bào** và là tiền chất của **hormon steroid**; ngoài ra còn tạo **acid mật** và **vitamin D** (cấu tạo và phân bố: bài *Hóa học lipid*, mục 3.4). Cholesterol có hai nguồn (Giáo trình tr. 143):

| Nguồn | Lượng | Ghi chú |
|---|---|---|
| **Ngoại sinh** (thức ăn) | Khoảng **300–500 mg/ngày** | Thịt, **gan, não, lòng đỏ trứng** |
| **Nội sinh** (tế bào tự tổng hợp, chủ yếu ở **gan**) | Khoảng **1 g/ngày** | Có điều hòa ngược theo lượng ăn vào |

**Đào thải**: khoảng **50%** cholesterol được bài xuất qua **phân dưới dạng acid mật**; phần còn lại thải dưới dạng **steroid trung tính** (cholesterol và dẫn xuất).

**Vì sao cholesterol không được "đốt" để lấy năng lượng?** Người **không có enzym mở vòng nhân steroid**. Cholesterol không bị oxy hóa thành CO~2~ và H~2~O như glucid hay acid béo; con đường duy nhất để loại bỏ nó là **gan thải vào mật**. Cholesterol thừa vì thế dễ **tích tụ** (thành mạch, sỏi mật).

### 4.2. Tổng hợp cholesterol và điều hòa

Cholesterol được tổng hợp chủ yếu ở **gan, ruột**; ngoài ra ở **thượng thận, tinh hoàn, buồng trứng, da và hệ thần kinh**. Nguyên liệu là **acetyl-CoA** (cả 27 carbon), quá trình diễn ra ở **bào tương** và lưới nội bào. Giáo trình mô tả **25 bước, chia 4 giai đoạn** (Giáo trình tr. 143):

| Giai đoạn | Biến đổi | Ghi chú |
|---|---|---|
| **1** | Acetyl-CoA → **acid mevalonic** (6C) | Qua acetoacetyl-CoA → **HMG-CoA**; bước HMG-CoA → mevalonat do **HMG-CoA reductase** (NADPH) xúc tác |
| **2** | Acid mevalonic → **isopren hoạt hóa** (5C) | Tốn ATP, mất CO~2~ |
| **3** | **6 đơn vị isopren** hoạt hóa → **squalen** (30C) | Chuỗi hydrocarbon mạch thẳng |
| **4** | Squalen → **nhân steroid 4 vòng** → cholesterol (27C) | Đóng vòng (qua lanosterol), cắt bớt 3C |

**Điều hòa** (theo sơ đồ Hình 8.17 của giáo trình, ở tế bào gan):

- **HMG-CoA reductase** là enzym điều hòa chính.
- **Cholesterol** (của thức ăn và do tế bào tạo ra) **ức chế** HMG-CoA reductase (điều hòa ngược).
- **Insulin hoạt hóa**, **glucagon ức chế** HMG-CoA reductase. (Sơ đồ còn ghi **estrogen** ức chế HMG-CoA synthase.)
- **ACAT** (acyl-CoA cholesterol acyltransferase) ester hóa cholesterol thừa trong tế bào thành **cholesterol ester** để dự trữ.

> [!bay]
> - **ACAT** (trong tế bào) và **LCAT** (trong huyết tương, trên HDL) đều tạo cholesterol ester nhưng **khác chất cho acyl**: ACAT lấy acyl từ **acyl-CoA**, LCAT lấy acyl từ **C~2~ của lecithin**.
> - Hình 8.17 của giáo trình ghi chất đầu là "Acyl CoA"; đúng ra là **acetyl-CoA**.
> - Tổng hợp cholesterol dùng **HMG-CoA ở bào tương**; tạo thể ceton dùng **HMG-CoA ở ty thể** (mục 2.4).

> [!ung-dung] Statin — thuốc hạ cholesterol hàng đầu
> - **Statin** (atorvastatin, rosuvastatin, simvastatin, lovastatin…) có phần giống HMG-CoA, **ức chế cạnh tranh HMG-CoA reductase** (bài *Enzym*, mục chất ức chế).
> - **Vì sao ức chế tổng hợp mà LDL máu giảm mạnh?** Cholesterol trong tế bào gan giảm → tế bào **tăng tổng hợp thụ thể LDL** trên màng (qua yếu tố phiên mã SREBP-2) → gan **bắt LDL từ máu** nhiều hơn. Statin liều trung bình–cao giảm LDL-C khoảng **30–50% hoặc hơn**, và đã được chứng minh **giảm nhồi máu cơ tim, đột quỵ, tử vong** trong nhiều thử nghiệm lớn.
> - **Tác dụng phụ**: đau cơ, hiếm gặp **viêm cơ, tiêu cơ vân** (theo dõi **CK**); tăng men gan (**ALT**); tăng nhẹ nguy cơ đái tháo đường. **Chống chỉ định khi có thai** (cholesterol cần cho phát triển thai).
> - Simvastatin, lovastatin, atorvastatin chuyển hóa qua **CYP3A4**: tránh dùng chung với chất ức chế CYP3A4 mạnh (một số kháng sinh macrolid, thuốc kháng nấm azol, **nước bưởi chùm**) vì tăng nguy cơ tổn thương cơ (bài *Enzym*).
> - Cholesterol được tổng hợp mạnh **về đêm**, nên các statin **thời gian bán thải ngắn** (simvastatin, lovastatin) thường uống **buổi tối**. Atorvastatin, rosuvastatin bán thải dài, uống giờ nào cũng được.

> [!yhct] Hồng khúc và các vị thuốc "hạ mỡ máu" — đâu là bằng chứng?
> - **Hồng khúc** (gạo men đỏ, gạo lên men nấm *Monascus purpureus*) chứa **monacolin K**, có cấu trúc **giống hệt lovastatin**. Cơ chế đã chứng minh: **ức chế HMG-CoA reductase**, đúng như statin (xem thêm bảng dược liệu ức chế enzym ở bài *Enzym*, mã hs-05). Mức bằng chứng **lâm sàng**: nhiều thử nghiệm ngẫu nhiên cho thấy giảm LDL-C; một thử nghiệm lớn ở Trung Quốc với chế phẩm Hồng khúc ở bệnh nhân sau nhồi máu cơ tim cho thấy giảm biến cố mạch vành.
> - Vì **chính là một statin**, Hồng khúc có **tác dụng phụ của statin** (đau cơ, tăng CK, tăng men gan), **không dùng chung với statin**, không dùng khi có thai, cũng chịu tương tác qua CYP3A4. Hàm lượng monacolin **rất khác nhau** giữa các sản phẩm, và quá trình lên men có thể sinh **citrinin**, một độc tố nấm **độc với thận**. Châu Âu đã giới hạn lượng monacolin trong thực phẩm bổ sung từ năm 2022 vì lý do an toàn.
> - **Sơn tra** (ở Trung Quốc là quả *Crataegus*; ở Việt Nam thường là quả **táo mèo** *Docynia indica*) và **Trạch tả** (*Alisma*, hoạt chất nhóm alisol): tác dụng giảm lipid máu chủ yếu thấy trên **động vật và in vitro**; thử nghiệm ở người **ít, nhỏ, kết quả không thống nhất**. Chưa đủ để thay thuốc hạ lipid.
> - **Tách bạch hai tầng**: công năng YHCT (Sơn tra "tiêu thực tích, hóa ứ"; Trạch tả "lợi thủy, thẩm thấp") là hệ thống giải thích riêng, không đồng nghĩa với "hạ cholesterol". Khi bệnh nhân có nguy cơ tim mạch cao, thuốc chuẩn (statin) vẫn là lựa chọn có bằng chứng giảm tử vong.

### 4.3. Acid mật — đường thải chính của cholesterol *(bổ sung)*

Giáo trình chỉ nêu cholesterol được bài xuất dưới dạng acid mật. Vài ý cơ bản về con đường này:

- Ở gan, **cholesterol 7α-hydroxylase** (một cytochrom P450) là **bước giới hạn tốc độ**; enzym bị chính acid mật ức chế ngược.
- **Acid mật nguyên phát**: **acid cholic** và **acid chenodeoxycholic**. Chúng được **liên hợp với glycin hoặc taurin** thành **muối mật**, chất có cả phần ưa nước và kỵ nước, giúp **nhũ tương hóa mỡ** và tạo micelle để hấp thu lipid, vitamin tan trong dầu.
- Vi khuẩn ruột biến đổi chúng thành **acid mật thứ phát** (deoxycholic, lithocholic).
- **Chu trình gan–ruột**: khoảng **95%** muối mật được tái hấp thu ở **hồi tràng** và quay về gan; chỉ phần nhỏ mất theo phân mỗi ngày, gan tổng hợp bù lại từ cholesterol.

> [!ung-dung] Ứng dụng của chu trình acid mật
> - **Cholestyramin** (nhựa gắn acid mật) giữ acid mật lại trong ruột → gan phải lấy thêm cholesterol để tạo acid mật mới → tăng thụ thể LDL → LDL máu giảm.
> - **Sỏi mật cholesterol**: hình thành khi mật có quá nhiều cholesterol so với muối mật và lecithin.
> - Cắt đoạn hồi tràng hoặc bệnh Crohn ở hồi tràng làm mất muối mật → kém hấp thu mỡ, phân mỡ.

> [!yhct] Hùng đởm (mật gấu) và acid ursodeoxycholic
> Acid mật đặc trưng của mật gấu là **acid ursodeoxycholic (UDCA)**, chủ yếu ở dạng liên hợp taurin. UDCA ưa nước hơn các acid mật khác, làm mật **ít tạo sỏi** hơn và bảo vệ tế bào đường mật. Ngày nay UDCA **được tổng hợp** và là thuốc chính thức (bằng chứng **lâm sàng**) để làm tan một số **sỏi cholesterol nhỏ** và điều trị **viêm đường mật nguyên phát** (PBC). Như vậy, phần cơ chế có cơ sở của Hùng đởm đã có sẵn dưới dạng thuốc tổng hợp, chuẩn hàm lượng. Pháp luật Việt Nam **cấm khai thác, buôn bán mật gấu** (gấu là loài được bảo vệ); khi đã có UDCA chuẩn hàm lượng, không có lý do y học nào để dùng mật gấu thật.

## 5. Lipoprotein — dạng vận chuyển lipid

Lipid **không tan trong nước**. Muốn đi trong máu, cholesterol, triglycerid, phospholipid phải kết hợp với protein đặc hiệu gọi là **apoprotein (apo)**, tạo thành **lipoprotein** tan được trong nước. Riêng **acid béo tự do** được chở bằng **albumin** (Giáo trình tr. 144).

### 5.1. Cấu trúc và apoprotein

Lipoprotein được **Macheboeuf** mô tả năm **1929**. Theo **mô hình của Shen (1977)** (Giáo trình tr. 144–145):

- Hình **cầu**, đường kính khoảng **100–500 Å** (10–50 nm). Lipid và protein liên kết chủ yếu bằng **lực Van der Waals** (tương tác kỵ nước), không bằng liên kết cộng hóa trị.
- **Vỏ ngoài** (dày khoảng 1 nm, **phân cực**): **apoprotein** và **phospholipid**, giúp hạt tan trong huyết tương.
- **Lõi** (**không phân cực**): **triglycerid** và **cholesterol ester**.
- **Cholesterol tự do** nằm **giữa** hai phần (trong lớp vỏ).

**Vì sao cấu trúc như vậy?** Giống một giọt dầu được bọc xà phòng: phần kỵ nước nhất (TG, cholesterol ester) trốn vào trong; phần lưỡng cực (phospholipid, cholesterol tự do có –OH, apo) quay ra nước.

**Apoprotein** khác nhau do cấu trúc chuỗi peptid; có ít nhất **9 loại** trong huyết tương người. Phần protein quyết định **nhận diện** lipoprotein ở màng tế bào (gắn thụ thể) và **hoạt hóa enzym** (Giáo trình tr. 144, Bảng 8.1):

| Apo | Có trong | Chức năng chính |
|---|---|---|
| **A-I** | HDL | **Hoạt hóa LCAT** |
| A-II, A-IV | HDL (A-IV cả ở CM) | |
| **B-48** | **Chylomicron** (duy nhất) | Cấu trúc CM (tạo ở ruột) |
| **B-100** | **VLDL, IDL, LDL** | **Gắn thụ thể LDL** |
| C-I | VLDL, HDL | |
| **C-II** | CM, VLDL, HDL | **Hoạt hóa lipoprotein lipase** |
| **C-III** | CM, VLDL, HDL | **Ức chế lipoprotein lipase** |
| D | HDL | |
| **E** | CM, VLDL, IDL, HDL | Gắn thụ thể ở gan để **thu hồi CM tàn dư**, IDL *(bổ sung)* |

> [!bay]
> - **B-48 = dấu hiệu của chylomicron (ruột)**; **B-100 = dấu hiệu của lipoprotein do gan tạo** (VLDL → IDL → LDL). B-48 và B-100 do **cùng một gen**; ở ruột, mRNA (mARN) bị "biên tập" tạo mã kết thúc sớm nên protein chỉ dài khoảng **48%** của B-100.
> - **C-II hoạt hóa**, **C-III ức chế** lipoprotein lipase: dễ đảo ngược khi thi.
> - Bảng 8.1 của giáo trình có **hai dòng "Apo D"**; dòng thứ hai (khối lượng 34.145, có ở CM, VLDL, HDL) thực chất là **apo E**.

### 5.2. Phân loại và chức năng

Bằng **siêu ly tâm phân tích**, lipoprotein được chia theo **tỷ trọng**. Lipid nhẹ hơn nước, protein nặng hơn; vì vậy **càng nhiều TG thì càng nhẹ và càng to**, **càng nhiều protein thì càng nặng và càng nhỏ** (Giáo trình tr. 144–146).

| Loại | Thành phần nổi bật (khoảng, theo Bảng 8.2) | Apo chính | Nơi tạo | Chức năng |
|---|---|---|---|---|
| **Chylomicron (CM)** | **TG ≈ 90%**, protein ≈ 1–2% | **B-48**, C-II, E, A | **Ruột** (lưới nội bào tế bào niêm mạc) | Chở **TG ngoại sinh** (thức ăn) |
| **VLDL** (tỷ trọng rất thấp) | **TG ≈ 65%**, cholesterol ≈ 20% | **B-100**, C-I, C-II, C-III, E | **Gan** | Chở **TG nội sinh** |
| **IDL** (tỷ trọng trung gian) | TG ≈ 30%, cholesterol ≈ 35% | B-100, E | Từ VLDL trong máu | Chuyển tiếp thành LDL |
| **LDL** (tỷ trọng thấp) | **Cholesterol ≈ 50%** (phần lớn ester) | **B-100** | Từ VLDL, IDL trong máu | Chở **cholesterol cho các mô** |
| **HDL** (tỷ trọng cao) | **Protein ≈ 50%** | **A-I**, C, E | **Gan, ruột non** | Chở cholesterol **từ mô về gan** |

![Hình 2. Ba con đường vận chuyển lipid bằng lipoprotein. Màu cam: enzym (LPL, LCAT)](van-chuyen-lipoprotein.svg)

**Chylomicron.** Lipoprotein **lớn nhất**, giàu TG nhất. Chỉ có trong huyết tương **một thời gian ngắn sau bữa ăn nhiều mỡ**, làm huyết tương **đục như sữa**; biến mất sau vài giờ, nên huyết tương người bình thường **lúc đói thì trong**. Trong mao mạch mô mỡ, tim, cơ xương, **apoC-II hoạt hóa lipoprotein lipase (LPL)** thủy phân TG của CM, giải phóng acid béo cho các mô. Phần còn lại (giàu cholesterol, còn apoE và B-48) là **CM tàn dư**, theo máu về **gan** và bị thoái hóa trong **lysosom** (Giáo trình tr. 144–145).

**VLDL.** Tạo ở **gan**, chở **TG nội sinh** (gan tạo từ glucid, acid béo thừa) vào tuần hoàn. Đến mô mỡ, cơ: LPL (do apoC-II hoạt hóa) thủy phân TG, giải phóng acid béo. VLDL còn lại tiếp tục bị thoái hóa (Giáo trình tr. 145).

**IDL.** VLDL sau khi mất TG, **nhận thêm cholesterol ester** và **mất apoC** thành IDL; IDL nhanh chóng chuyển thành LDL (Giáo trình tr. 146).

**LDL.** Sản phẩm thoái hóa của VLDL trong máu, **rất giàu cholesterol và cholesterol ester**, apo chính là **B-100**. Chức năng chính là **chở cholesterol đến các mô**: LDL gắn **thụ thể đặc hiệu** trên màng tế bào rồi được đưa vào trong tế bào. Cholesterol của LDL được coi là **cholesterol "xấu"** vì tham gia hình thành **mảng vữa xơ** ở thành động mạch (Giáo trình tr. 145).

**HDL.** Tạo ở **gan và ruột non**, ban đầu là **HDL mới sinh hình đĩa**, sau đó chuyển thành **HDL~3~ → HDL~2~** nhờ **LCAT** (do apoA-I hoạt hóa). HDL giàu protein, apo chính là **A-I**. HDL chở cholesterol từ mô ngoại vi **về gan** (**vận chuyển cholesterol "trở về"**), tại gan cholesterol được chuyển thành acid mật. Cholesterol của HDL là cholesterol **"tốt"** vì bảo vệ thành mạch. Theo giáo trình, **HDL-cholesterol càng thấp (< 0,3 g/L) thì nguy cơ vữa xơ động mạch càng cao** (Giáo trình tr. 146).

**Vì sao LCAT giúp HDL "hút" cholesterol?** Cholesterol tự do từ màng tế bào chuyển sang lớp vỏ HDL. LCAT ester hóa nó thành **cholesterol ester kỵ nước**, chất này chui vào **lõi**. Lớp vỏ lại trống chỗ để nhận thêm cholesterol tự do. HDL vì vậy **phồng dần** từ hình đĩa thành hình cầu (HDL~3~ nhỏ → HDL~2~ lớn hơn).

> [!bay]
> - Giáo trình viết CM "vận chuyển triglycerid ngoại sinh từ ruột **tới gan**". Thực ra phần lớn TG của CM được **LPL ở mô mỡ, cơ** lấy đi trước; **gan chỉ nhận CM tàn dư** (giàu cholesterol). Hình 2 vẽ theo trình tự này.
> - Thứ tự **tỷ trọng tăng dần**: CM < VLDL < IDL < LDL < HDL. **Kích thước** thì ngược lại.
> - Giàu TG nhất: **CM**. Giàu cholesterol nhất: **LDL**. Giàu protein nhất: **HDL**.
> - **Acid béo tự do** chở bằng **albumin**, không nằm trong 5 loại lipoprotein trên.

### 5.3. Rối loạn lipid máu và xơ vữa động mạch

> [!ung-dung] Từ LDL đến mảng xơ vữa
> - LDL (nhất là khi nồng độ cao, kéo dài) **thấm vào lớp áo trong** của động mạch và bị **oxy hóa**.
> - Đại thực bào ăn LDL oxy hóa qua **thụ thể "dọn rác"** (scavenger receptor). Thụ thể này **không bị điều hòa ngược** theo lượng cholesterol, nên đại thực bào ăn mãi, đầy giọt cholesterol ester, thành **tế bào bọt**.
> - Tế bào bọt tích tụ thành **vệt mỡ**, rồi thành **mảng xơ vữa** có vỏ xơ. Mảng **vỡ** → cục máu đông → **nhồi máu cơ tim, nhồi máu não**.
> - HDL làm ngược lại: lấy cholesterol từ tế bào bọt mang về gan.

> [!ung-dung] Một số rối loạn lipid máu thường gặp
> - **Tăng cholesterol máu gia đình** (đột biến **thụ thể LDL**, di truyền trội): LDL không được gan thu hồi, LDL-C rất cao từ nhỏ, có **u vàng ở gân** (gân gót, gân duỗi bàn tay), cung giác mạc sớm, nhồi máu cơ tim sớm. Dạng **đồng hợp tử** có thể nhồi máu cơ tim từ tuổi thiếu niên. Đây là bệnh giúp **Brown và Goldstein** phát hiện con đường thụ thể LDL (Nobel Y học 1985).
> - **Thiếu lipoprotein lipase hoặc apoC-II** (di truyền lặn, hiếm): CM không được thủy phân, tồn tại cả lúc đói → **huyết tương đục như sữa**, TG rất cao, đau bụng, **viêm tụy cấp**, u vàng phát ban. Mẫu huyết tương để tủ lạnh qua đêm nổi **lớp "kem"** (CM) ở trên.
> - **Rối loạn lipid máu thứ phát** (hay gặp hơn nhiều): đái tháo đường, béo phì, **suy giáp**, **hội chứng thận hư**, ứ mật, **rượu**, một số thuốc (corticoid, lợi tiểu thiazid…). Khi phát hiện rối loạn lipid, phải tìm các nguyên nhân này.
> - **TG rất cao** (khoảng **≥ 10 mmol/L**) là nguy cơ **viêm tụy cấp**.

> [!ung-dung] Xét nghiệm lipid máu (bộ "mỡ máu")
> Khoảng tham chiếu **tham khảo, mỗi phòng xét nghiệm có khoảng riêng** (thường gặp ở các bệnh viện Việt Nam):
>
> | Xét nghiệm | Khoảng thường dùng | Đổi đơn vị |
> |---|---|---|
> | **Cholesterol toàn phần** | **3,9–5,2 mmol/L** | mmol/L × 38,7 = mg/dL |
> | **Triglycerid** | **0,46–1,88 mmol/L** (mức mong muốn < 1,7) | mmol/L × 88,5 = mg/dL |
> | **HDL-C** | **≥ 1,0 mmol/L (nam), ≥ 1,3 mmol/L (nữ)** là mức mong muốn (có phòng xét nghiệm ghi chung ≥ 0,9) | mmol/L × 38,7 = mg/dL |
> | **LDL-C** | **≤ 3,4 mmol/L** (đích điều trị tùy mức nguy cơ) | mmol/L × 38,7 = mg/dL |
>
> - Nhiều phòng xét nghiệm **tính** LDL-C bằng **công thức Friedewald** (đơn vị mmol/L): **LDL-C = Cholesterol TP − HDL-C − TG/2,2**. Công thức **không dùng được khi TG > 4,5 mmol/L**; khi đó phải đo LDL-C trực tiếp.
> - Muốn đánh giá TG chính xác nên lấy máu **lúc đói 9–12 giờ** (sau bữa ăn có CM, TG tăng).
> - **Đích LDL-C** theo hướng dẫn châu Âu (ESC/EAS 2019): nguy cơ **rất cao** < 1,4 mmol/L; **cao** < 1,8; **trung bình** < 2,6; **thấp** < 3,0.

> [!cap-nhat] HDL "tốt" và LDL "xấu" — hiểu cho đúng
> - **LDL**: các nghiên cứu di truyền và thử nghiệm thuốc (statin, ezetimib, thuốc ức chế PCSK9) đều cho thấy **hạ LDL-C thì giảm biến cố tim mạch**, và giảm càng nhiều càng có lợi. LDL được coi là **nguyên nhân** gây xơ vữa.
> - **HDL**: HDL-C thấp vẫn là **dấu hiệu nguy cơ**, nhưng các thuốc **làm tăng HDL-C** (niacin, thuốc ức chế CETP) **không làm giảm** biến cố tim mạch. Vì vậy hiện nay **không đặt đích điều trị cho HDL-C**; chức năng của HDL quan trọng hơn con số.
> - Ngưỡng của giáo trình "HDL-C < 0,3 g/L" (≈ 0,78 mmol/L) **thấp hơn** ngưỡng nguy cơ hiện dùng: **< 1,0 mmol/L (40 mg/dL) ở nam, < 1,3 mmol/L (50 mg/dL) ở nữ**.
> - Giáo trình ghi đường kính lipoprotein 100–500 Å. Thực tế **chylomicron lớn hơn nhiều** (có thể tới khoảng 1 µm), còn HDL nhỏ nhất (khoảng 7–12 nm).

## Tóm tắt

| Chủ đề | Điểm cần nhớ |
|---|---|
| Lipid trong cơ thể | Dự trữ (TG, thay đổi) và màng (phospholipid, cholesterol, hằng định ≈ 10% trọng lượng khô). Nhu cầu 60–100 g/ngày |
| Glycerol | Glycerolkinase (gan, thận; **mô mỡ không có**) → glycerol-3-P → DAP → đường phân hoặc tạo glucose |
| Hoạt hóa acid béo | Acyl-CoA synthetase, ATP → AMP + PP~i~: **tốn 2 ATP** |
| Carnitin | CPT I (mặt ngoài màng trong) → acyl-carnitin qua màng → CPT II (mặt trong); bị **malonyl-CoA** ức chế (cập nhật) |
| β-oxy hóa | Acyl-CoA dehydrogenase (**FAD**) → enoyl-CoA hydratase (H~2~O, dạng L) → β-hydroxyacyl-CoA dehydrogenase (**NAD^+^**) → thiolase (CoA) → acetyl-CoA |
| Năng lượng | C~2n~: **17n − 7 ATP**; palmitic: 7 vòng, 8 acetyl-CoA, **129 ATP** (sách) / **106 ATP** (hiện nay) |
| Acid béo không no | 1 nối đôi: **enoyl-CoA isomerase** (cis-Δ^3^ → trans-Δ^2^); nhiều nối đôi: thêm **2,4-dienoyl-CoA reductase** (NADPH) |
| Thể ceton | Ty thể gan: thiolase → **HMG-CoA synthase** → **HMG-CoA lyase** → acetoacetat ⇌ β-hydroxybutyrat; aceton tự phát. Mô ngoại vi dùng nhờ **succinyl-CoA** (gan thiếu transferase) |
| Nhiễm toan ceton | Tạo nhanh hơn dùng: đói, **đái tháo đường thiếu insulin**. Đo **β-hydroxybutyrat** máu; que thử nitroprussid chỉ thấy acetoacetat |
| Thoái hóa TG | Lipase cắt C~1~, C~3~ nhanh, 2-monoglycerid chậm; **lipase nhạy cảm hormon** hoạt động khi **phosphoryl hóa** (cAMP, protein kinase); acid béo tự do gắn **albumin** |
| Phospholipase | A: C~2~ (→ lysophospholipid, nọc rắn, vỡ hồng cầu); B: C~1~ + C~2~; C: glycerol–phosphat; D: phosphat–base. **LCAT**: lecithin + cholesterol → lysolecithin + cholesterol ester |
| Tổng hợp acid béo | **Bào tương**; acetyl-CoA ra ngoài dạng **citrat**; **acetyl-CoA carboxylase (biotin)** → malonyl-CoA; **acid béo synthase** (AT, MT, KS, KR, HD, ER + ACP; –SH trung tâm của ACP, –SH ngoại vi của KS); ngưng tụ → khử → khử nước → khử (**NADPH**); dừng ở **palmitic** |
| Ty thể, microsom | Ty thể: kéo dài từ palmitic (như β-oxy hóa ngược, acyl-CoA). Lưới nội bào: **Δ^9^-desaturase** (O~2~, NADPH, cyt b~5~) → palmitoleic, oleic; không tạo được Δ^12^, Δ^15^ → linoleic, linolenic **thiết yếu** |
| Tổng hợp TG | Glycerol-3-P + 2 acyl-CoA → **acid phosphatidic** → diglycerid → TG. Ruột: acyl hóa trực tiếp monoglycerid |
| Tổng hợp phospholipid | Diglycerid + **CDP-ethanolamin** → cephalin; + **CDP-cholin** → lecithin; hoặc **methyl hóa cephalin bằng SAM** |
| Cholesterol | Ăn 300–500 mg, tự tạo ≈ 1 g/ngày; 4 giai đoạn (mevalonat → isopren → squalen → nhân steroid); **HMG-CoA reductase** (cholesterol, glucagon ức chế; insulin hoạt hóa; **statin** ức chế); thải ≈ 50% dạng **acid mật** |
| Lipoprotein | Vỏ: apo + phospholipid (+ cholesterol tự do); lõi: TG + cholesterol ester. **CM** (B-48, TG thức ăn) → **VLDL** (B-100, TG gan) → IDL → **LDL** (cholesterol cho mô, "xấu"); **HDL** (A-I, LCAT, về gan, "tốt"). **C-II hoạt hóa, C-III ức chế LPL** |
| Xét nghiệm | Cholesterol TP 3,9–5,2; TG 0,46–1,88; HDL-C ≥ 1,0 (nam), ≥ 1,3 (nữ); LDL-C ≤ 3,4 mmol/L (tham khảo). Friedewald: LDL = TC − HDL − TG/2,2 |
