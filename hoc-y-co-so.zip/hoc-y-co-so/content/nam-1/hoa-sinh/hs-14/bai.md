---
title: Hóa sinh hormon
thoi-gian: 60 phút
muc-tieu:
- Phân loại được hormon theo cấu tạo hóa học (peptid–protein, dẫn xuất acid amin, steroid, eicosanoid) và theo vị trí thụ thể; trình bày được cơ chế tác dụng của hai nhóm.
- Kể được các chất thông tin thứ hai (cAMP, cGMP, IP~3~/DAG, Ca^2+^) và cơ chế thụ thể tyrosin kinase; vẽ được sơ đồ dòng thác cAMP của epinephrin.
- Nêu được cấu tạo (số acid amin, đặc điểm) và tác dụng chính của các hormon peptid–protein: vùng dưới đồi, tuyến yên, rau thai, cận giáp, tụy, tiêu hóa.
- Vẽ được sơ đồ tổng hợp, thoái hóa catecholamin và hormon tuyến giáp.
- Viết được nhân steroid, kể tên và nhóm carbon của các hormon steroid đại diện (vỏ thượng thận, sinh dục nam, nữ).
- Giải thích được điều hòa ngược theo trục dưới đồi – tuyến yên – tuyến đích và đọc được một số xét nghiệm hormon cơ bản.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Hormon là "thư" hóa học do tuyến nội tiết gửi qua máu tới **cơ quan đích**; nồng độ rất thấp (ng–pg/mL), tác dụng qua **thụ thể đặc hiệu**.
> 2. Theo cấu tạo: **peptid–protein**, **dẫn xuất acid amin** (amino acid) (catecholamin, T~3~/T~4~ — đều từ **tyrosin**), **steroid** (từ cholesterol: C18 estrogen, C19 androgen, C21 corticoid + progesteron), **eicosanoid**.
> 3. Hormon **tan trong lipid** (steroid, T~3~/T~4~) vào trong tế bào, gắn **thụ thể nội bào** → điều hòa **phiên mã gen**. Hormon **tan trong nước** (peptid, catecholamin) gắn **thụ thể màng** → **chất thông tin thứ hai**.
> 4. Chất thông tin thứ hai: **cAMP** (Gs → adenylyl cyclase → PKA), **cGMP**, **IP~3~/DAG** (phospholipase C), **Ca^2+^**–calmodulin; insulin dùng **thụ thể tyrosin kinase**.
> 5. Tuyến dưới bị tuyến trên điều khiển (dưới đồi → tuyến yên → tuyến đích), và hormon tuyến đích **ức chế ngược** tuyến trên → giữ nồng độ ổn định.

## 1. Đại cương

### 1.1. Hormon là gì

Hormon là những chất hữu cơ được tế bào **tuyến nội tiết** tạo ra với lượng rất nhỏ, đổ **thẳng vào máu** rồi được đưa tới **cơ quan đích** ở xa. Ở đó hormon gây ra những biến đổi hóa lý giúp cơ thể giữ **hằng định nội môi** (Giáo trình tr. 222).

Thông qua cơ quan đích, hormon kiểm soát gần như mọi chức năng: phát triển tế bào và mô, tim mạch – huyết áp, co bóp ống tiêu hóa, tiết sữa, sinh sản, chức năng thận… Nói gọn, hormon là một dạng **tín hiệu giữa các tế bào**.

Dựa vào **khoảng cách** từ nơi tiết tới nơi tác dụng, tín hiệu giữa các tế bào chia làm 3 kiểu:

| Kiểu tín hiệu | Tác dụng lên | Ví dụ |
|---|---|---|
| **Nội tiết** (endocrine) | Tế bào ở **xa**, qua máu | Insulin, cortisol, thyroxin |
| **Tại chỗ** (paracrine) | Tế bào **gần kề** tế bào tiết | Chất dẫn truyền thần kinh; eicosanoid |
| **Tự thân** (autocrine) | **Chính** tế bào đã tiết ra | Nhiều yếu tố tăng trưởng; tế bào khối u tự kích thích tăng sinh |

Giáo trình phân biệt thêm hai khái niệm gần với hormon (tr. 223–224):

- **Hormon thần kinh** (neurohormone): do **tế bào thần kinh** tạo ra nhưng **tiết vào máu**. Ví dụ: vasopressin.
- **Chất dẫn truyền thần kinh** (neurotransmitter): cũng do tế bào thần kinh tạo ra nhưng tiết vào **khe synap**, tác động lên tế bào kế bên. Ví dụ: norepinephrin, acetylcholin.

> [!bay]
> **Norepinephrin** "đóng hai vai": ở tận cùng thần kinh giao cảm nó là **chất dẫn truyền thần kinh**; nhưng **tủy thượng thận** cũng tiết nó thẳng vào máu nên nó **cũng là hormon** theo định nghĩa cổ điển. Vì vậy giáo trình nhấn mạnh: thần kinh và nội tiết thực chất là **một hệ thống thống nhất** (hệ thần kinh – nội tiết).

### 1.2. Các tuyến nội tiết chính

| Tuyến | Hormon chính | Bản chất |
|---|---|---|
| Vùng dưới đồi | CRH, TRH, GnRH, GH-RH, somatostatin; sản xuất ADH, oxytocin | Peptid |
| Tuyến yên trước | GH, prolactin, FSH, LH, TSH, ACTH | Protein, glycoprotein, peptid |
| Tuyến yên sau | ADH (vasopressin), oxytocin (chỉ dự trữ và giải phóng) | Peptid 9 acid amin |
| Tuyến giáp | T~4~, T~3~ (tế bào nang); calcitonin | Dẫn xuất tyrosin; peptid |
| Cận giáp | PTH | Polypeptid |
| Tụy nội tiết (đảo Langerhans) | Insulin (β), glucagon (α), somatostatin (D) | Peptid |
| Tủy thượng thận | Epinephrin, norepinephrin | Dẫn xuất tyrosin |
| Vỏ thượng thận | Aldosteron, cortisol, androgen thượng thận | Steroid |
| Tinh hoàn / buồng trứng | Testosteron / estrogen, progesteron | Steroid |
| Rau thai | HCG, HPL; estrogen, progesteron | Glycoprotein; steroid |
| Dạ dày – ruột | Gastrin, secretin, CCK | Peptid |

### 1.3. Đặc điểm bài tiết hormon

- **Theo nhịp sinh học**: nồng độ trong máu dao động theo chu kỳ (Giáo trình tr. 224). Theo **giờ**: LH, testosteron. Theo **ngày**: cortisol. Theo **tháng**: hormon sinh dục nữ. Theo **mùa**: thyroxin.
- **Nồng độ cực thấp**: cỡ **nanogam đến picogam** mỗi mL. Vì vậy định lượng hormon cần kỹ thuật **rất nhạy** (miễn dịch phóng xạ, miễn dịch hóa phát quang) và thiết bị đắt tiền.

> [!ung-dung] Lấy mẫu xét nghiệm hormon đúng giờ
> Vì có nhịp ngày đêm, **cortisol** cao nhất vào sáng sớm và thấp nhất quanh nửa đêm. Phải lấy máu xét nghiệm cortisol vào khoảng **8 giờ sáng** và ghi giờ lấy mẫu. Khoảng tham chiếu cortisol 8 giờ sáng thường gặp: khoảng **140–690 nmol/L** (tham khảo, mỗi phòng xét nghiệm có khoảng riêng). Kết quả lúc chiều không so được với khoảng tham chiếu buổi sáng.

## 2. Phân loại hormon

### 2.1. Theo cấu tạo hóa học

**a) Hormon peptid và protein.** Dài từ **3 acid amin** (TRH) đến **hơn 200 acid amin**. Gồm hormon vùng dưới đồi, tuyến yên, tụy (insulin, glucagon)…

**b) Hormon là amin (dẫn xuất acid amin).** Phân tử nhỏ, đều là **dẫn xuất của tyrosin**:

- Hormon **tủy thượng thận** (adrenalin, noradrenalin): **tan tốt trong nước**.
- Hormon **tuyến giáp** (T~3~, T~4~): **ít tan trong nước**.

Nhiều tác giả gộp hai nhóm a và b thành một nhóm "hormon protein" (Giáo trình tr. 224). Hormon peptid được tổng hợp dưới dạng tiền chất lớn **preprohormon**. Đầu N của preprohormon có **đoạn tín hiệu** (signal peptide, thường **16–22 acid amin**), bị cắt bỏ khi chuỗi vào lưới nội bào, còn lại **prohormon**. Prohormon được trữ trong **túi tiết**, rồi cắt tiếp thành hormon khi cần giải phóng. Ví dụ điển hình: preproinsulin → proinsulin → insulin (đã học ở hs-12, mục 5.1).

**c) Hormon steroid.** Gồm hormon **vỏ thượng thận** và **tuyến sinh dục**. Tất cả đều **bắt nguồn từ cholesterol** (hs-08), có chung nhân steroid. Chia theo số carbon:

- **C18**: estrogen.
- **C19**: androgen.
- **C21**: glucocorticoid (corticoid chuyển hóa đường), mineralocorticoid (chuyển hóa muối), progestin.

**d) Eicosanoid.** Không thuộc ba nhóm trên nhưng hoạt động giống hormon. Đó là dẫn xuất của **acid arachidonic** (acid béo 20C, 4 nối đôi). Có 3 phân nhóm: **prostaglandin, leukotrien, thromboxan**. Chúng kém bền, không tan trong nước và chủ yếu tác dụng **tại chỗ** (tr. 225).

**So sánh hai nhóm lớn (đây là điểm hay thi):**

| Đặc điểm | Peptid – protein, catecholamin | Steroid, T~3~/T~4~ |
|---|---|---|
| Tính tan | Tan trong nước | Tan trong lipid (T~3~/T~4~ ít tan trong nước) |
| Dự trữ trong tuyến | **Có** (túi tiết) | Steroid: **không** dự trữ, tổng hợp xong khuếch tán ra ngay (T~4~ thì trữ trong thyroglobulin) |
| Vận chuyển trong máu | **Dạng tự do** (trừ T~3~, T~4~) | Gắn **protein vận chuyển** đặc hiệu; chỉ dạng **tự do** mới có hoạt tính |
| Thời gian bán hủy | **Ngắn** (vài phút) | Dài hơn (giờ – ngày) |
| Thụ thể | **Màng tế bào** | **Nội bào** (bào tương hoặc nhân) |
| Cơ chế | Chất thông tin thứ hai | Điều hòa phiên mã gen |
| Tốc độ đáp ứng | Nhanh (giây – phút) | Chậm (giờ – ngày), kéo dài |

**Vì sao như vậy?** Tất cả bắt nguồn từ **tính tan**. Phân tử tan trong nước thì đi tự do trong huyết tương nhưng không xuyên qua được lớp lipid kép, nên phải "bấm chuông" ở thụ thể màng. Phân tử tan trong lipid thì khó đi trong máu (cần "xe chở" là protein vận chuyển), nhưng lại lách qua màng dễ dàng để gặp thụ thể bên trong. Khi gắn protein vận chuyển, hormon cũng được bảo vệ khỏi bị thoái hóa và đào thải, nên sống lâu hơn.

### 2.2. Theo cơ chế tác dụng

Mọi hormon đều tác dụng qua **thụ thể (receptor) đặc hiệu** ở tế bào đích. Căn cứ vào vị trí thụ thể (Giáo trình tr. 225):

- **Nhóm 1 – gắn thụ thể nội bào**: hormon **steroid** và hormon **tuyến giáp**.
- **Nhóm 2 – gắn thụ thể ở màng tế bào**: hormon **peptid** và **amin tan trong nước** (catecholamin). Nhóm này lại chia nhỏ theo **chất thông tin thứ hai** mà nó dùng.

> [!bay]
> - T~3~/T~4~ và catecholamin **cùng là dẫn xuất tyrosin** nhưng **khác nhóm cơ chế**: T~3~/T~4~ gắn **thụ thể nội bào** (giống steroid), còn catecholamin gắn **thụ thể màng**.
> - T~3~/T~4~ là hormon "dẫn xuất acid amin" duy nhất **gắn protein vận chuyển** trong máu.

## 3. Cơ chế tác dụng của hormon

### 3.1. Hormon steroid và hormon tuyến giáp — điều khiển gen

Các bước (Giáo trình tr. 225–226):

1. Hormon đi trong máu nhờ **protein vận chuyển**; dạng tự do tách ra.
2. Hormon **khuếch tán đơn thuần** qua màng tế bào.
3. Gắn **thụ thể** trong **bào tương** hoặc trong **nhân**, tạo **phức hợp hormon – thụ thể**. Phức hợp ở bào tương sẽ **chuyển vào nhân**.
4. Phức hợp gắn vào một vùng đặc hiệu của DNA (ADN), gọi là **vùng nhạy cảm với hormon** (hormone response element, HRE).
5. Gen đích được **tăng phiên mã** nhờ **RNA (ARN) polymerase** → tăng mRNA → tăng tổng hợp **protein mới đặc hiệu** (enzym, protein vận chuyển…). Protein mới này tạo ra tác dụng của hormon.

Thụ thể của **glucocorticoid** nằm chủ yếu ở **bào tương**, được giữ bởi protein sốc nhiệt (HSP90); khi gắn hormon thì nhả HSP90 và chuyển vào nhân. Thụ thể của **T~3~** (cũng như vitamin D, acid retinoic) thì nằm sẵn **trong nhân**, gắn trên DNA ngay cả khi chưa có hormon. Tất cả thuộc cùng một **họ thụ thể nhân** (*bổ sung*).

**Vì sao chậm nhưng bền?** Phải qua phiên mã, dịch mã để tạo protein mới, nên đáp ứng mất **hàng giờ** mới xuất hiện. Đổi lại, protein mới tồn tại lâu nên tác dụng **kéo dài**. Ví dụ: cortisol tăng tổng hợp các enzym tân tạo glucose ở gan.

### 3.2. Hormon peptid và amin — dùng chất thông tin thứ hai

Hormon tan trong nước gắn vào **thụ thể trên mặt ngoài màng**. Bản thân hormon không vào tế bào. Sự gắn này làm xuất hiện trong tế bào một **chất thông tin thứ hai** (second messenger); hormon được xem là chất thông tin thứ nhất. Chất thông tin thứ hai **khuếch đại** tín hiệu bằng cách hoạt hóa các enzym nội bào (Giáo trình tr. 226). Chất được biết rõ nhất là **AMP vòng (cAMP)**.

**Protein G và adenylyl cyclase (AC)**

Giữa thụ thể và AC có một trung gian là **protein G kích thích (Gs**, s = stimulating). Gs nằm ở mặt trong màng, gồm 3 tiểu đơn vị **α, β, γ**:

- **Bất hoạt**: tiểu đơn vị α gắn **GDP**, cả 3 tiểu đơn vị dính nhau.
- Hormon (vd epinephrin) gắn thụ thể → thụ thể **đổi cấu hình**, kể cả phần nằm trong tế bào → phần này xúc tác cho Gs **đổi GDP lấy GTP**.
- **Hoạt động**: **Gsα·GTP** tách khỏi β·γ, đến gắn và **hoạt hóa AC**. AC chuyển **ATP → cAMP** (+ PP~i~).
- **Tự tắt**: α có hoạt tính **GTPase**, tự thủy phân GTP → GDP + P~i~, rồi gắn lại với β·γ, trở về dạng bất hoạt.

![Hình 1. Cơ chế tác dụng qua cAMP: thụ thể – Gs – adenylyl cyclase – PKA](camp.svg)

Giáo trình tóm lại truyền tin qua AC gồm **2 bước khuếch đại** (tr. 227):

1. Một phân tử hormon gắn một thụ thể → hoạt hóa **nhiều** phân tử Gs.
2. Mỗi Gsα hoạt hóa một AC → AC tạo ra **nhiều** phân tử cAMP.

cAMP sống rất ngắn vì bị enzym **phosphodiesterase** (PDE) phân hủy nhanh thành **5'-AMP** (không còn tác dụng). Nhờ vậy tín hiệu tắt ngay khi hormon không còn.

**Protein G ức chế (Gi).** Một số hormon làm **giảm** cAMP. Ví dụ: **somatostatin** gắn thụ thể của nó → Gi **ức chế AC** → cAMP giảm, giảm phosphoryl hóa protein. Tác dụng này đối trọng với epinephrin.

> [!ung-dung] Độc tố vi khuẩn "khóa" protein G
> Giáo trình nêu hai độc tố biến đổi **không thuận nghịch** protein G (tr. 227):
> - **Độc tố tả** (cholera toxin) gắn ADP-ribose vào Gsα, làm nó **mất khả năng tự tắt** (không thủy phân được GTP). AC hoạt động liên tục → cAMP tế bào ruột tăng cao → tế bào bơm Cl^−^ và nước vào lòng ruột → **tiêu chảy mất nước ồ ạt** (phân "nước vo gạo"). Vì vậy điều trị chính là **bù nước – điện giải** (ORS, truyền dịch).
> - **Độc tố ho gà** (pertussis toxin) gắn ADP-ribose vào **Gi**, làm Gi không ức chế được AC → cAMP cũng tăng.

### 3.3. Các chất thông tin thứ hai

#### a) AMP vòng (cAMP)

cAMP là chất thông tin thứ hai của nhiều hormon: **glucagon, epinephrin, ACTH, TSH, FSH, LH** (Giáo trình tr. 228). cAMP được tạo từ **ATP**. Về cấu tạo, gốc phosphat nối **cùng lúc** vào –OH ở C3' và C5' của ribose, tạo một vòng (adenosin 3',5'-monophosphat vòng).

> [!bay]
> Trong danh sách hormon dùng cAMP, giáo trình ghi "hormon tuyến giáp" (tr. 228). Ở đây phải hiểu là **TSH** (hormon **kích thích** tuyến giáp). Chính giáo trình xếp **T~3~/T~4~** vào nhóm gắn **thụ thể nội bào** (tr. 225), không dùng cAMP.

**cAMP tác dụng qua protein kinase A (PKA).** PKA bất hoạt là một tứ phân **R~2~C~2~**: 2 tiểu đơn vị **điều hòa (R)** "ôm" 2 tiểu đơn vị **xúc tác (C)**. Khi cAMP tăng, **4 cAMP** gắn vào 2 tiểu đơn vị R (mỗi R gắn 2 cAMP). R đổi cấu hình, **nhả 2 C** ra. C tự do có hoạt tính, dùng ATP để **phosphoryl hóa** gốc Ser/Thr của các protein đích, làm thay đổi chuyển hóa của tế bào (tr. 229).

**Ví dụ kinh điển: epinephrin làm tăng glucose máu.** Cơ chế này do **Sutherland** khám phá (thập niên 1950). Ở tế bào gan (Giáo trình tr. 229–230, hình 14.6):

=> Epinephrin → thụ thể → Gs → AC → cAMP → PKA → phosphorylase b kinase → glycogen phosphorylase b → a → glycogen → glucose-1-phosphat → glucose máu

Mỗi tầng nhân số phân tử lên nhiều lần. Theo hình của giáo trình, từ **x** phân tử epinephrin có thể tạo ra khoảng **10.000x** phân tử glucose. Đó là lý do một lượng hormon cực nhỏ (ng/mL) vẫn gây được đáp ứng lớn. Chi tiết về phosphorylase a/b và việc PKA đồng thời **tắt glycogen synthase**: xem hs-07, mục 3.3.

#### b) GMP vòng (cGMP)

cGMP là chất thông tin thứ hai ở một số tế bào như **ruột, tim, mạch máu, não, ống góp thận**. cGMP được **guanylat cyclase** (GC) tạo ra từ **GTP**, tác dụng qua **protein kinase G** (PKG, cũng có tiểu đơn vị R và C như PKA) (Giáo trình tr. 230–231). Có hai loại GC:

| Loại GC | Chất hoạt hóa | Tác dụng |
|---|---|---|
| GC **gắn màng** (chính là thụ thể) | **ANF** (yếu tố bài niệu natri của tâm nhĩ), do tế bào cơ **tâm nhĩ** tiết ra | Ở thận: tăng thải **natri và nước** |
| GC **hòa tan**, chứa **hem** (cơ tim, cơ trơn mạch máu) | **NO** (oxyd nitric, tạo ra từ **arginin**) | **Giãn cơ trơn, giãn mạch** |

> [!ung-dung] Thuốc tác động lên đường NO – cGMP
> - **Nitroglycerin**, isosorbid (chữa cơn đau thắt ngực) giải phóng **NO** → tăng cGMP → giãn mạch.
> - **Sildenafil** ức chế **phosphodiesterase typ 5** (enzym phân hủy cGMP) → cGMP tồn tại lâu hơn. **Không được** dùng chung với nitrat: hai thuốc cộng hưởng gây **tụt huyết áp nặng**.

#### c) IP~3~ và DAG (từ phosphatidyl inositol)

Loại thụ thể thứ ba nối qua một protein G khác, gọi là **Gq**, với **phospholipase C** (PLC, dạng PLC-β). PLC cắt **phosphatidyl inositol 4,5-bisphosphat** (PIP~2~) trên màng thành **hai** chất thông tin thứ hai (Giáo trình tr. 231–232):

- **Diacylglycerol (DAG)**: ở lại trong màng, hoạt hóa **protein kinase C** (PKC, cần Ca^2+^). PKC phosphoryl hóa gốc **Ser, Thr** của protein đích.
- **Inositol 1,4,5-triphosphat (IP~3~)**: tan trong nước, khuếch tán tới **lưới nội bào**, gắn vào **kênh Ca^2+^ nhạy cảm IP~3~**. Kênh mở ra, Ca^2+^ tràn vào bào tương, làm nồng độ Ca^2+^ bào tương tăng **khoảng 100 lần**.

Ví dụ hormon dùng cơ chế này: **vasopressin** tác dụng lên tế bào gan; **TRH** tác dụng lên tế bào tuyến yên.

> [!ghi-nho] Ba loại protein G cần nhớ (bổ sung tên gọi hiện nay)
> - **Gs** → hoạt hóa adenylyl cyclase → **cAMP tăng** (thụ thể β-adrenergic, glucagon, ACTH, TSH, FSH, LH; thụ thể V~2~ của ADH ở ống góp thận).
> - **Gi** → ức chế adenylyl cyclase → **cAMP giảm** (somatostatin, thụ thể α~2~-adrenergic).
> - **Gq** → hoạt hóa phospholipase C → **IP~3~ + DAG**, Ca^2+^ tăng (thụ thể α~1~-adrenergic, thụ thể V~1~ của vasopressin ở gan và mạch máu, TRH, GnRH).
> - Cùng một hormon có thể dùng **protein G khác nhau** tùy loại thụ thể: epinephrin qua β (Gs), α~2~ (Gi), α~1~ (Gq); vasopressin qua V~2~ (Gs, giữ nước) và V~1~ (Gq, co mạch).

> [!bay]
> Giáo trình có chỗ in "**Inosin** triphosphat (IP3)" (tr. 231). Đúng là **inositol** 1,4,5-triphosphat. Inositol là một polyalcol vòng 6 cạnh; còn inosin là một nucleosid (base hypoxanthin + ribose), hoàn toàn khác.

#### d) Ca^2+^

Bình thường Ca^2+^ trong bào tương rất thấp (khoảng **0,2 µM**, theo giáo trình tr. 232). Mức thấp này được giữ nhờ các **bơm Ca^2+^** ở lưới nội bào, ty thể và màng tế bào. Khi có kích thích, Ca^2+^ đi vào qua kênh ở màng hoặc được giải phóng từ lưới nội bào và ty thể. Ca^2+^ tăng sẽ hoạt hóa nhiều enzym thông qua **calmodulin**, một protein acid có **4 vị trí gắn Ca^2+^**. Khi gắn Ca^2+^, calmodulin đổi cấu hình và gắn được vào các protein đích để điều hòa hoạt động của chúng.

#### e) Thụ thể loại tyrosin kinase — insulin

Insulin dùng một cơ chế khác hẳn (Giáo trình tr. 233). Thụ thể insulin gồm **2 chuỗi α** ở **mặt ngoài** màng (nơi gắn insulin) và **2 chuỗi β** xuyên màng. Phần trong tế bào của chuỗi β mang **hoạt tính tyrosin kinase**.

1. Insulin gắn chuỗi α.
2. Hai chuỗi β **tự phosphoryl hóa** ở các gốc **tyrosin**.
3. Vùng tyrosin kinase được hoạt hóa, phosphoryl hóa các protein trong bào tương, mở đầu một **dòng thác phosphoryl hóa** làm thay đổi chuyển hóa tế bào đích.

Các yếu tố tăng trưởng như **EGF** (yếu tố phát triển biểu mô) và **PDGF** (yếu tố phát triển nguồn gốc tiểu cầu) cũng tác dụng theo cách này.

> [!vi-du] Bổ sung: insulin đưa glucose vào tế bào như thế nào
> Dòng thác từ thụ thể insulin làm các túi chứa **GLUT4** (kênh vận chuyển glucose) trong bào tương **di chuyển ra gắn vào màng** tế bào **cơ và mô mỡ**. Số kênh trên màng tăng → glucose vào nhiều hơn. Gan dùng **GLUT2** có sẵn trên màng, nên glucose vào gan **không cần insulin** (giáo trình cũng nêu ý này, tr. 238). Ở đái tháo đường typ 2, khâu sau thụ thể này bị "kém nhạy" (kháng insulin).

**Bảng tổng hợp chất thông tin thứ hai**

| Hệ thống | Enzym tạo ra | Đích | Ví dụ hormon |
|---|---|---|---|
| **cAMP** | Adenylyl cyclase (qua Gs; Gi ức chế) | PKA | Tăng: glucagon, epinephrin (β), ACTH, TSH, FSH, LH. Giảm (Gi): somatostatin, epinephrin (α~2~) |
| **cGMP** | Guanylat cyclase | PKG | ANF; NO |
| **IP~3~ + DAG** | Phospholipase C (qua **Gq**) | IP~3~ → Ca^2+^; DAG → PKC | Vasopressin (ở gan), TRH; epinephrin (α~1~) |
| **Ca^2+^** | (kênh, IP~3~) | Calmodulin | Nhiều hormon thần kinh |
| **Tyrosin kinase** | Chính thụ thể | Protein đích (Tyr-P) | Insulin, EGF, PDGF |

## 4. Hormon protein – polypeptid

### 4.1. Hormon tuyến yên trước

**Hormon tăng trưởng (GH, STH, somatotropin)** (Giáo trình tr. 233–234)

- Polypeptid **191 acid amin**, **2 cầu disulfua** (giữa acid amin 53–165 và 182–189). Cấu trúc rất giống **prolactin** và **hormon lactogen rau thai**.
- Tác dụng lên chuyển hóa **glucid, lipid, protid và điện giải** ở cơ, mô mỡ, gan; kích thích **phát triển cơ thể**. **Thiếu GH → lùn**.
- Thời gian bán hủy khoảng **20–30 phút**; nồng độ trung bình ở người lớn **2–4 ng/mL**.

**Prolactin (PRL, LTH)**: chuỗi **199 acid amin**, phân tử lượng khoảng **23.000 Da**; giống GH và hormon tạo sữa rau thai. Tác dụng chủ yếu lên **tuyến vú** để **tạo sữa sau sinh**.

**Nhóm glycoprotein: FSH, LH, TSH (và HCG của rau thai)**

Bốn hormon này có cấu tạo giống nhau: đều là **glycoprotein** gồm **2 tiểu đơn vị α và β**.

- Chuỗi **α gần như giống nhau** ở cả 4 hormon, gồm **92 acid amin**.
- Chuỗi **β khác nhau** và quyết định **tính đặc hiệu** của từng hormon.

| Hormon | Phân tử lượng | Nồng độ (theo giáo trình) | Tác dụng chính |
|---|---|---|---|
| **FSH** (kích thích nang trứng) | 32.000 Da | 2–5 mU/mL; lúc rụng trứng 5–10 mU/mL | Làm nang trứng chín nhanh, tăng tiết estrogen ở nữ; ở nam làm to tinh hoàn |
| **LH** (kích thích hoàng thể) | 28.500 Da | Cơ bản 2–5 mU/mL; đỉnh lúc rụng trứng 16–25 mU/mL | Cùng FSH gây **rụng trứng**, phát triển **hoàng thể**, kích thích tiết estrogen và progesteron |
| **TSH** (kích thích tuyến giáp) | 28.000 Da (α 92 + β 112 acid amin) | Khoảng 3 ng/mL | Kích thích nhiều giai đoạn tổng hợp hormon giáp |

> [!cap-nhat] FSH ở nam giới và đơn vị TSH
> - Giáo trình ghi FSH ở nam "làm to tinh hoàn nhưng không làm tăng số lượng tinh trùng" (tr. 234). Hiện nay đã rõ FSH tác động lên **tế bào Sertoli** và **cần cho quá trình sinh tinh**; LH kích thích **tế bào Leydig** tiết testosteron. Vì vậy FSH (cùng hCG/LH) được dùng điều trị vô sinh nam do suy tuyến yên.
> - TSH ngày nay được báo cáo theo đơn vị hoạt tính **mIU/L** (= µIU/mL). Khoảng tham chiếu thường dùng ở người lớn khoảng **0,4–4,0 mIU/L** (tham khảo, mỗi phòng xét nghiệm có khoảng riêng). TSH là xét nghiệm **sàng lọc đầu tiên** cho bệnh tuyến giáp.

**ACTH (hormon kích thích vỏ thượng thận)** (Giáo trình tr. 235)

- Polypeptid **39 acid amin**, phân tử lượng **4.500 Da**.
- **24 acid amin đầu** giống nhau ở người và nhiều loài động vật, mang **toàn bộ hoạt tính**. Đoạn còn lại thay đổi theo loài và không có tác dụng sinh học.
- Kích thích vỏ thượng thận tiết **glucocorticoid**. Đoạn acid amin **6–10** của ACTH giống **α-MSH**, nên ACTH cũng có hoạt tính **kích thích tạo melanin**.

> [!ung-dung] Vì sao bệnh Addison làm da sạm?
> Bệnh **Addison** là suy vỏ thượng thận **nguyên phát** (tổn thương tại tuyến). Cortisol thấp → mất ức chế ngược → tuyến yên tăng tiết **ACTH rất cao**. ACTH có đoạn giống MSH nên kích thích tế bào hắc tố → **da và niêm mạc sạm đen** (nếp gấp bàn tay, lợi, sẹo). Nếu suy thượng thận do **tuyến yên** (ACTH thấp) thì da **không** sạm. Đây là ví dụ đẹp về cách dùng cấu trúc phân tử để giải thích triệu chứng.

### 4.2. Hormon tuyến yên giữa

Thùy giữa tiết **α-MSH** (hormon kích thích hắc tố bào). Ở **người trưởng thành**, thùy giữa tuyến yên gần như **không có**, nên không có α-MSH trong máu và tuyến yên (Giáo trình tr. 235).

### 4.3. Hormon tuyến yên sau

Thùy sau chứa hai hormon peptid: **vasopressin** và **oxytocin**. Đây là hai hormon peptid đầu tiên được tách chiết, tinh chế và **tổng hợp nhân tạo** (Vincent du Vigneaud, giải Nobel). Chúng **không** do thùy sau tạo ra. Thực ra chúng được tổng hợp ở **tế bào thần kinh vùng dưới đồi**, đi dọc **bó trên thị – tuyến yên** xuống thùy sau, được dự trữ ở đó và giải phóng khi có kích thích (tr. 236).

| | **Vasopressin (ADH)** | **Oxytocin** |
|---|---|---|
| Cấu tạo | **9 acid amin**, có cầu disulfua (vòng Cys1–Cys6), đầu C là Gly-NH~2~ | **9 acid amin**, khác vasopressin ở vị trí **3 và 8** |
| Acid amin 3 / 8 | Phe / **Arg** | Ile / **Leu** |
| Tác dụng | **Chống bài niệu**: tăng tái hấp thu nước ở ống thận; **co mạch** → tăng huyết áp | **Co cơ trơn tử cung** lúc chuyển dạ; co cơ quanh nang tuyến vú → **tiết sữa** khi con bú |
| Thiếu hormon | **Đái tháo nhạt**: tiểu **5–10 L/ngày**, tỷ trọng nước tiểu rất thấp **1,001–1,005** | |

> [!bay]
> - Giáo trình ghi năm giải Nobel của du Vigneaud là 1954 (tr. 236). Thực tế ông nhận **giải Nobel Hóa học năm 1955**. Câu hỏi thi thường chỉ hỏi "là hormon peptid đầu tiên được tổng hợp", không hỏi năm.
> - **Đái tháo nhạt** (thiếu ADH, nước tiểu loãng, **không có glucose**) khác hẳn **đái tháo đường** (thiếu/kháng insulin, nước tiểu có glucose, tỷ trọng **cao**). Cả hai đều tiểu nhiều.

### 4.4. Hormon rau thai

**HCG** (gonadotropin rau thai người) xuất hiện trong máu và nước tiểu phụ nữ **ngay những ngày đầu** có thai. Nồng độ cao nhất vào **tháng thứ 2–3**, rồi biến mất vài ba ngày sau sinh (Giáo trình tr. 236).

- Là **glycoprotein**: chuỗi **α giống** α của LH, FSH, TSH; chuỗi **β đặc hiệu**, quyết định hoạt tính riêng của HCG.
- Tác dụng giống **LH**: duy trì hoàng thể và kích thích tiết **estrogen, progesteron** trong thời gian đầu thai kỳ.
- Rau thai còn tiết **HPL** (hormon kích thích tạo sữa rau thai), prolactin rau thai và **HCT** (hormon kích thích tuyến giáp rau thai).

> [!ung-dung] Que thử thai và xét nghiệm β-hCG
> Que thử thai và xét nghiệm máu dùng kháng thể đặc hiệu với **chuỗi β** của hCG. Nếu dùng kháng thể với chuỗi α thì sẽ phản ứng chéo với LH, FSH, TSH (vì chuỗi α giống nhau). β-hCG còn dùng để theo dõi **chửa trứng**, **ung thư nguyên bào nuôi** và một số **u tế bào mầm** tinh hoàn.

### 4.5. Hormon vùng dưới đồi

Vùng dưới đồi tiết các **hormon thần kinh** dạng peptid ngắn, điều hòa sự bài tiết của tuyến yên trước (Giáo trình tr. 236–237):

| Hormon | Cấu tạo | Tác dụng chính |
|---|---|---|
| **CRH** (giải phóng corticotropin) | 41 acid amin | Kích thích tiết **ACTH** |
| **TRH** (giải phóng thyrotropin) | **Tripeptid** (3 acid amin) | Kích thích tiết **TSH** |
| **GnRH** (giải phóng gonadotropin) | 10 acid amin | Kích thích tiết **FSH, LH** |
| **PIF** (yếu tố ức chế prolactin) | Theo giáo trình: chuỗi 56 acid amin | **Ức chế** tiết PRL |
| **GH-RH** (giải phóng GH) | 3 dạng: 37, 40, 44 acid amin | Kích thích tiết **GH** |
| **GH-IH** (ức chế GH, = somatostatin) | 14 acid amin | **Ức chế** tiết **GH** |

> [!cap-nhat] Yếu tố ức chế prolactin là dopamin
> Giáo trình ghi PIF là một peptid 56 acid amin (tr. 237). Hiện nay đã thống nhất: chất ức chế prolactin **chủ yếu là dopamin** (một catecholamin, mục 5.1) từ vùng dưới đồi. Vì vậy các thuốc **chẹn thụ thể dopamin** (vd metoclopramid, nhiều thuốc chống loạn thần) có thể gây **tăng prolactin máu** (chảy sữa, rối loạn kinh nguyệt). Ngược lại, thuốc **đồng vận dopamin** (bromocriptin, cabergolin) dùng để chữa u tiết prolactin. Đi thi, nếu hỏi theo bảng 14.1 thì trả lời theo giáo trình.

### 4.6. Hormon cận giáp (PTH) và calcitonin

Hai hormon này cùng với **vitamin D** điều hòa chuyển hóa **Ca^2+^** (Giáo trình tr. 237). Tuyến cận giáp người dài 6–7 mm, nặng khoảng 140 mg.

| | **PTH** | **Calcitonin (CT)** |
|---|---|---|
| Cấu tạo | **84 acid amin**; tiền chất prepro-PTH 115, pro-PTH 90 acid amin; **34 acid amin đầu** đã đủ hoạt tính | **32 acid amin** |
| Ca^2+^ máu | **Tăng** | **Giảm** (cả phosphat) |
| Xương | **Tăng hủy xương**, giải phóng Ca^2+^ | **Ức chế** giải phóng Ca^2+^ từ xương |
| Thận | **Tăng** tái hấp thu Ca^2+^; **giảm** tái hấp thu phosphat (tăng thải phosphat) | Giảm tái hấp thu Ca^2+^ ở ống thận |
| Ruột | Tăng hấp thu Ca^2+^, **phối hợp vitamin D** | — |
| Dự trữ | Theo giáo trình: không dự trữ, tổng hợp và tiết liên tục | |

> [!cap-nhat] Nơi tiết calcitonin
> Giáo trình viết calcitonin được tiết từ "tế bào của tuyến cận giáp và tuyến giáp" (tr. 237). Hiện nay xác định calcitonin do **tế bào C** (tế bào cận nang) của **tuyến giáp** tiết ra. Tế bào C có nguồn gốc phôi riêng, nằm xen giữa các nang giáp. Calcitonin máu tăng cao là **chất chỉ điểm** của **ung thư biểu mô tuyến giáp thể tủy**.

> [!ung-dung] Đọc nhanh rối loạn calci
> Calci toàn phần huyết thanh bình thường khoảng **2,15–2,55 mmol/L** (tham khảo, mỗi phòng xét nghiệm có khoảng riêng).
> - **Cường cận giáp** (thường do u tuyến): **Ca^2+^ tăng, phosphat giảm**, loãng xương, **sỏi thận**.
> - **Suy cận giáp** (vd lỡ cắt bỏ khi mổ tuyến giáp): Ca^2+^ giảm, phosphat tăng → **tê bì, co quắp cơ (tetani)**.

### 4.7. Hormon tuyến tụy

Chức năng nội tiết của tụy nằm ở **đảo Langerhans**.

**Insulin** (tế bào **β**) (Giáo trình tr. 237–239)

- **51 acid amin**, gồm **chuỗi A (21)** và **chuỗi B (30)**, nối với nhau bằng **2 cầu disulfua**; chuỗi A còn **1 cầu disulfua trong chuỗi**. Cấu trúc bậc 1 do **Sanger** xác định; cấu trúc bậc 2, 3 xác định năm 1969.
- Tiền chất: preproinsulin → **proinsulin** (một chuỗi, bắt đầu bằng chuỗi B, nối với chuỗi A qua đoạn peptid nối) → cắt bỏ **peptid C** → insulin. Quá trình này và ý nghĩa xét nghiệm **C-peptid** đã học ở hs-12 (mục 5.1).
- Insulin, proinsulin, peptid C lưu hành **tự do** trong huyết tương, không gắn protein. Insulin bị **protease** thoái hóa chủ yếu ở **gan và thận**.

> [!bay]
> Giáo trình in "Sanger (năm 1933)" (tr. 237). Đó là lỗi in: Sanger giải trình tự insulin vào **đầu những năm 1950** (hoàn tất 1955) và nhận **giải Nobel Hóa học 1958**. Insulin là **protein đầu tiên** được xác định trình tự acid amin.

**Tác dụng của insulin: làm giảm glucose máu** bằng cách:

- **Tăng tính thấm** của màng tế bào với glucose, đồng thời tăng vận chuyển **K^+^** và **phosphat vô cơ** vào tế bào. Một số mô **không phụ thuộc insulin** để lấy glucose: **thần kinh, bạch cầu, phổi, thận**, đặc biệt là **gan**.
- **Hoạt hóa glycogen synthase** → tăng tổng hợp glycogen.
- Tăng tổng hợp **glucokinase** ở gan; **ức chế** tổng hợp enzym tân tạo glucose (vd **pyruvat carboxylase**); **giảm** tác dụng của **glucose-6-phosphatase**.
- **Ức chế phân giải lipid**, nên tế bào tăng đốt glucose.
- Về cơ chế: insulin làm **giảm cAMP** trong tế bào đích, ngược với adrenalin và glucagon.

> [!ung-dung] Insulin và kali máu
> Vì insulin đưa **K^+^ vào tế bào**, truyền **insulin + glucose** là một biện pháp cấp cứu **tăng kali máu** (kali "chui" vào tế bào trong vài chục phút). Ngược lại, khi điều trị **nhiễm toan ceton đái tháo đường** bằng insulin, K^+^ máu có thể **tụt nhanh** → phải theo dõi và bù kali. Kali máu bình thường khoảng **3,5–5,0 mmol/L** (tham khảo).

**Glucagon** (tế bào **α**)

- Peptid **29 acid amin**, có nhiều đoạn giống **secretin**. Bị thoái hóa chủ yếu ở **gan**.
- Giống adrenalin, glucagon làm tăng **cAMP** ở tế bào đích → hoạt hóa **phosphorylase ở gan**. Glucagon **không** hoạt hóa phosphorylase ở **cơ** (cơ không có thụ thể glucagon).
- Kích thích **phân giải mỡ**: cAMP hoạt hóa **lipase** → giải phóng glycerol và acid béo.

**Somatostatin (GIH)**: peptid **14 acid amin**, tiết ở **vùng dưới đồi** và **tế bào D** của tụy. Ức chế bài tiết **GH, insulin và glucagon**.

| | **Insulin** | **Glucagon** |
|---|---|---|
| Tế bào tiết | β | α |
| Số acid amin | 51 (2 chuỗi) | 29 (1 chuỗi) |
| Glucose máu | **Giảm** | **Tăng** |
| Cơ chế | Thụ thể **tyrosin kinase**; giảm cAMP | Gs → **cAMP** → PKA |
| Glycogen | Tăng tổng hợp | Tăng phân giải (gan) |
| Lipid | Tăng dự trữ, ức chế phân giải | Tăng phân giải |
| Tình trạng ưu thế | Sau ăn | Lúc đói |

Toàn bộ điều hòa đường huyết bằng cặp insulin/glucagon (và adrenalin, cortisol, GH) đã được trình bày ở **hs-07** (mục 4.2 và 5.6). Ở đây chỉ cần nắm cấu tạo và cơ chế phân tử.

### 4.8. Hormon tiêu hóa

Là những polypeptid do các tế bào nội tiết đặc biệt của đường tiêu hóa tiết ra (Giáo trình tr. 239):

| Hormon | Nơi tiết, lúc nào | Cấu tạo | Tác dụng |
|---|---|---|---|
| **Gastrin** | Vùng **hang vị** dạ dày, khi tiêu hóa protein | **17 acid amin**; gastrin 2 có thêm gốc **sulfat** ở **tyrosin 12**; **4 acid amin cuối** (14–17) đủ hoạt tính | Kích thích **tiết dịch vị** và co bóp dạ dày |
| **Secretin** | Niêm mạc **đầu ruột (tá tràng)**; hormon đầu tiên được phát hiện (Bayliss và Starling, 1902) | **27 acid amin**, có phần giống glucagon | Kích thích tụy tiết **nước và bicarbonat** |
| **Cholecystokinin (CCK)** | Niêm mạc tá tràng, khi tiêu hóa **mỡ và protein** | **33 acid amin** | Kích thích tụy tiết **enzym** (amylase…); làm co túi mật |

> [!ung-dung] Hội chứng Zollinger–Ellison
> Một **u tiết gastrin** (thường ở tụy hoặc tá tràng) làm dạ dày **tiết acid quá mức** → **loét tá tràng** nhiều ổ, khó lành, hay tái phát. Giáo trình dùng ví dụ này để chứng minh tác dụng gây loét của gastrin.

## 5. Hormon dẫn xuất acid amin

### 5.1. Hormon tủy thượng thận — catecholamin

Tủy thượng thận có hai loại tế bào: một loại tiết **adrenalin** (epinephrin), một loại tiết **noradrenalin** (norepinephrin). Gọi chung là **catecholamin**, vì đều là dẫn xuất của **catechol** (vòng benzen mang 2 nhóm –OH kề nhau, tức 1,2-dihydroxybenzen) (Giáo trình tr. 239–240).

- **Norepinephrin**: catechol – CHOH – CH~2~ – **NH~2~**.
- **Epinephrin**: catechol – CHOH – CH~2~ – **NH–CH~3~** (thêm một nhóm methyl ở N).

**Tổng hợp**: từ **phenylalanin** (acid amin cần thiết) qua 5 bước:

![Hình 3. Tổng hợp và thoái hóa catecholamin](catecholamin.svg)

| Bước | Phản ứng | Enzym | Cần |
|---|---|---|---|
| 1 | Phenylalanin → **tyrosin** | Phenylalanin hydroxylase | O~2~, **tetrahydrobiopterin** (BH~4~) |
| 2 | Tyrosin → **DOPA** (dihydroxyphenylalanin) | **Tyrosin hydroxylase** (bước giới hạn tốc độ) | O~2~, BH~4~, Fe^2+^ |
| 3 | DOPA → **dopamin** (khử carboxyl) | DOPA decarboxylase | **Pyridoxal phosphat** (vitamin B~6~) |
| 4 | Dopamin → **norepinephrin** | Dopamin β-hydroxylase | O~2~, **vitamin C**, Cu |
| 5 | Norepinephrin → **epinephrin** (methyl hóa) | Phenylethanolamin N-methyltransferase (PNMT) | **S-adenosylmethionin** (SAM) cho –CH~3~ |

- Norepinephrin được tổng hợp và dự trữ ở **tận cùng dây thần kinh** (giao cảm). Bước methyl hóa thành epinephrin xảy ra ở **tủy thượng thận**, trong các **tế bào ưa crom**.
- Tỷ lệ bài tiết ở tủy thượng thận: **norepinephrin / epinephrin = 1/4** (epinephrin chiếm ưu thế).

> [!vi-du] Một đường, nhiều sản phẩm
> - **Dopamin** vừa là chất trung gian, vừa là chất dẫn truyền thần kinh ở não. Bệnh **Parkinson** là do thiếu dopamin ở thể vân. Dopamin không qua được hàng rào máu não, nên người ta cho uống **L-DOPA** (tiền chất của bước 3). L-DOPA vào não rồi được khử carboxyl thành dopamin.
> - **Tyrosin** cũng là nguyên liệu tạo **melanin** và **hormon giáp** (mục 5.2). Thiếu phenylalanin hydroxylase gây **phenylceton niệu** (hs-09, mục 8).

**Thoái hóa** (chủ yếu ở **gan**) nhờ hai enzym (Giáo trình tr. 241–242):

- **MAO** (monoamin oxidase): có cả ở tận cùng thần kinh; xúc tác **khử amin oxy hóa**, tạo acid 3,4-dihydroxymandelic.
- **COMT** (catechol-O-methyltransferase): chuyển gốc **–CH~3~** từ **SAM** vào nhóm –OH phenol (vị trí 3), tạo 3-methoxy-epinephrin (**metanephrin**), 3-methoxy-norepinephrin (normetanephrin).
- Sản phẩm cuối chủ yếu: **acid vanylmandelic (VMA**, acid 3-methoxy-4-hydroxymandelic). Các sản phẩm thoái hóa không còn hoạt tính, thải qua **nước tiểu** dưới dạng liên hợp với acid **glucuronic** và **sulfuric**.

**Tác dụng** của epinephrin và norepinephrin (tr. 241):

| | **Epinephrin** | **Norepinephrin** |
|---|---|---|
| Mạch máu | **Giãn** mạch ở cơ xương, tim; **co** mạch ở da, tạng ổ bụng | **Co mạch toàn thân** → tăng huyết áp mạnh |
| Chuyển hóa | Tăng phân giải **glycogen** ở gan và cơ (qua **cAMP**) → **tăng glucose máu**; tăng **phân giải lipid** → acid béo, glycerol | Tác dụng chuyển hóa yếu hơn |

> [!cap-nhat] Xét nghiệm u tủy thượng thận (pheochromocytoma)
> U tủy thượng thận tiết nhiều catecholamin, gây **tăng huyết áp từng cơn** kèm đau đầu, vã mồ hôi, tim nhanh. Giáo trình nêu **VMA niệu** là sản phẩm thoái hóa chính để đánh giá. Hiện nay xét nghiệm được khuyến cáo đầu tay là **metanephrin tự do trong huyết tương** hoặc **metanephrin phân đoạn trong nước tiểu 24 giờ**, vì nhạy hơn VMA nhiều. Lý do là chính tế bào u liên tục chuyển catecholamin thành metanephrin nhờ COMT, nên metanephrin tăng đều, kể cả giữa các cơn.

### 5.2. Hormon tuyến giáp

Tuyến giáp có hai phần (Giáo trình tr. 242):

- Các **nang giáp** tiết hormon có iod: **thyroxin (T~4~)** và **triiodothyronin (T~3~)**.
- Các **tế bào cận nang** tiết **calcitonin** (mục 4.6).

Hoạt động của tuyến giáp phụ thuộc vào lượng **iod** (một nguyên tố hiếm) ăn vào. Mối liên quan này biết từ lâu qua **bệnh bướu cổ địa phương** ở vùng thức ăn, nước uống thiếu iod.

**Cấu tạo.** Hormon giáp là **dẫn xuất có iod của tyrosin**. Khung gồm **2 vòng benzen nối qua cầu –O–** (cấu tạo chi tiết của thyroxin như một dẫn xuất halogen tự nhiên: xem hc-06, mục 6.2).

| Chất | Số iod | Vai trò |
|---|---|---|
| **MIT** (monoiodotyrosin) | 1 | Tiền chất |
| **DIT** (diiodotyrosin) | 2 | Tiền chất |
| **T~3~** (triiodothyronin) = DIT + MIT | 3 | Hoạt tính **mạnh hơn** |
| **T~4~** (thyroxin) = DIT + DIT | 4 | Lượng **nhiều hơn** hẳn |

**Tổng hợp: 4 giai đoạn** (Giáo trình tr. 243–244)

1. **Thu nhận và cô đặc iodua.** Iod vào cơ thể qua thức ăn, nước uống (khoảng 50–200 µg/ngày), được ruột hấp thu dưới dạng **iodua (I^−^)**. Tế bào tuyến giáp **bắt giữ I^−^** từ máu và cô đặc lại. Tuyến giáp chỉ nặng khoảng 25 g nhưng giữ khoảng **1/3 lượng iod** toàn cơ thể. Giai đoạn này được **TSH kích thích**. Nó bị các anion **thiocyanat (SCN^−^)** và **perclorat (ClO~4~^−^)** ức chế cạnh tranh.
2. **Oxy hóa iod.** **Peroxidase** ở màng (thyroperoxidase) oxy hóa I^−^ thành dạng iod hoạt động. Các chất **thioure, thiouracil** và anion cyanua CN^−^ **ức chế** enzym này, nên chặn được quá trình.
3. **Gắn iod vào thyroglobulin.** **Thyroglobulin** là một glycoprotein lớn, là thành phần chính của chất keo trong lòng nang. Iod được gắn vào các gốc **tyrosin** của thyroglobulin, tạo **MIT và DIT** (cũng nhờ peroxidase). Sau đó các gốc này **ngưng tụ** ngay trên phân tử thyroglobulin: **DIT + DIT → T~4~** (chủ yếu), **DIT + MIT → T~3~**.
4. **Thủy phân thyroglobulin.** Khi cần, **protease** thủy phân thyroglobulin, giải phóng **T~3~, T~4~ vào máu** (cũng do **TSH kích thích**). MIT và DIT chứa tới 2/3 lượng iod của thyroglobulin nhưng **không vào máu**. Enzym **iodotyrosin dehalogenase** (giáo trình gọi là *halogenase*; khác với các deiodinase khử iod T~4~ ở mô ngoại vi) tách iod khỏi chúng; I^−^ được **tái sử dụng** trong tuyến (chu trình iod trong tuyến giáp).

> [!bay]
> Giáo trình viết "clorat ClO~4~^−^" (tr. 243). Ion ClO~4~^−^ là **perclorat**; clorat là ClO~3~^−^. Perclorat ức chế **bơm thu nhận iodua**, khác với thiouracil ức chế **peroxidase**.

**Vận chuyển trong máu** (tr. 244):

- T~4~ gắn chủ yếu với **TBG** (thyroxin binding globulin) **70–75%**, với **TBPA** (thyroxin binding prealbumin, nay gọi là **transthyretin**) **15–20%**, phần nhỏ còn lại với **albumin**.
- Trong máu: T~4~ chiếm **90%**, T~3~ chiếm **10%**.
- Chỉ khoảng **0,03% T~4~ ở dạng tự do**, và chính dạng **tự do** mới có hoạt tính. Các protein gắn đóng vai trò **kho dự trữ** T~3~, T~4~ trong máu.

**Thoái hóa** (gan, thận…):

- **Khử iod** nhờ **deiodinase**.
- Khử amin, khử carboxyl chuỗi alanin, hoặc **liên hợp** nhóm –OH phenol với acid glucuronic, sulfuric. Sản phẩm liên hợp tạo ở gan được đổ theo **mật** xuống ruột. Vi khuẩn ruột có **β-glucuronidase** cắt liên hợp, giải phóng hormon; một phần được hấp thu lại (**chu trình ruột – gan**).

**Tác dụng** (tr. 244). Hầu hết tế bào cơ thể là đích của hormon giáp (giáo trình ghi: trừ não và tinh hoàn người trưởng thành):

- **Glucid**: tăng hấp thu glucose ở ruột, tăng phân giải glycogen.
- **Lipid**: tăng phân giải, nhất là triglycerid, phospholipid và **cholesterol**.
- **Protein**: tăng tổng hợp, trực tiếp qua hoạt hóa **RNA polymerase** hoặc gián tiếp qua kích thích tiết GH.
- **Năng lượng**: tăng tiêu thụ oxy, **tăng chuyển hóa cơ sở**, **sinh nhiệt**.

> [!cap-nhat] T~3~ mới là dạng hoạt động chính
> Giáo trình nêu T~3~ mạnh hơn T~4~ còn T~4~ nhiều hơn. Hiện nay biết thêm: tuyến giáp tiết **chủ yếu T~4~**; khoảng **80% T~3~** trong máu được tạo ở **mô ngoại vi** (gan, thận, cơ) do **deiodinase** tách 1 iod khỏi T~4~. Thụ thể trong nhân gắn **T~3~** mạnh hơn T~4~ khoảng 10 lần. Vì vậy có thể xem T~4~ là "tiền hormon" lưu hành, còn T~3~ là dạng tác dụng.

> [!ung-dung] Iod, bướu cổ và thuốc kháng giáp
> - **Thiếu iod** → tuyến giáp không làm đủ T~4~ → mất ức chế ngược → **TSH tăng** → TSH kích thích tuyến **phì đại** → **bướu cổ** (mục 7). Thiếu iod khi mang thai gây tổn thương não thai nhi. Việt Nam phòng bệnh bằng **muối iod**. Nhu cầu iod người lớn theo WHO khoảng **150 µg/ngày**, phụ nữ có thai, cho con bú khoảng 250 µg/ngày.
> - **Thuốc kháng giáp** nhóm thioamid (**propylthiouracil**, **methimazol**/thiamazol) ức chế **peroxidase** (giai đoạn 2–3). Đây chính là cơ chế của nhóm "thioure, thiouracil" giáo trình nêu. Propylthiouracil còn ức chế thêm **deiodinase typ 1** ở mô ngoại vi (giảm chuyển T~4~ → T~3~). Thuốc **không** ngăn giải phóng hormon đã dự trữ sẵn, nên tác dụng lâm sàng xuất hiện sau vài tuần.
> - Xét nghiệm thường dùng: **TSH** và **FT~4~** (T~4~ tự do). **Suy giáp nguyên phát**: TSH ↑, FT~4~ ↓. **Cường giáp** (Basedow): TSH ↓, FT~4~ ↑. Khoảng tham chiếu FT~4~ thường dùng khoảng **12–22 pmol/L** (tham khảo, mỗi phòng xét nghiệm có khoảng riêng).

## 6. Hormon steroid

Gồm hormon **vỏ thượng thận**, hormon **sinh dục nữ** và **sinh dục nam**.

### 6.1. Danh pháp — nhân steroid

Mọi hormon steroid đều có nhân cơ bản **cyclopentanoperhydrophenanthren** (nhân **gonan**): **17C**, gồm **3 vòng 6 cạnh** và **1 vòng 5 cạnh**, gọi tên các vòng là **A, B, C, D** (Giáo trình tr. 244–245). Tùy số nhóm methyl và mạch nhánh gắn thêm, chia làm 3 nhóm:

| Nhóm | Nhân cơ bản | Đặc điểm cấu tạo | Hormon |
|---|---|---|---|
| **18C** | **Estran** | Thêm –CH~3~ (C18) ở **C13** | Hormon sinh dục **nữ** (estrogen) |
| **19C** | **Androstan** | –CH~3~ ở **C13** (C18) và **C10** (C19) | Androgen **vỏ thượng thận** và sinh dục **nam** |
| **21C** | **Pregnan** | Hai –CH~3~ như trên + mạch nhánh **–CH~2~–CH~3~** (C20, C21) ở **C17** | **Progesteron**, glucocorticoid, mineralocorticoid |

> [!ghi-nho] Mẹo nhớ số carbon
> **Đi từ lớn xuống nhỏ theo đường tổng hợp**: cholesterol (27C) → cắt mạch nhánh → **pregnan 21C** (progesteron, corticoid) → cắt tiếp 2C ở C17 → **androgen 19C** → mất C19 (vòng A thơm hóa) → **estrogen 18C**. Vậy "nữ ít carbon nhất" vì estrogen được làm **từ** androgen.

**Tổng hợp chung (bổ sung để nối với hs-08).** Giáo trình chỉ ghi nguyên liệu là "mẩu 2C (acetat)" (tr. 247), tức là đi qua **cholesterol** (con đường tổng hợp cholesterol từ acetyl-CoA: hs-08, mục 4.2). Bước đầu tiên và quyết định là **cắt mạch nhánh cholesterol** trong **ty thể** thành **pregnenolon** (21C). Bước này được **ACTH** (ở vỏ thượng thận) hoặc **LH** (ở tuyến sinh dục) kích thích. Từ pregnenolon, mỗi tuyến dùng bộ enzym riêng (các hydroxylase thuộc họ cytochrom P450) để tạo ra hormon của mình.

*Sơ đồ rút gọn (bổ sung, giáo trình không trình bày):*

| Bước | Enzym | Vị trí trong tế bào | Ghi chú |
|---|---|---|---|
| Cholesterol → **pregnenolon** (21C) | **Enzym cắt mạch nhánh** (CYP11A1, desmolase); cholesterol được protein **StAR** đưa vào màng trong ty thể | Ty thể | **Bước giới hạn tốc độ**, nơi ACTH, LH tác động |
| Pregnenolon → **progesteron** | 3β-hydroxysteroid dehydrogenase | Lưới nội bào | Chuyển vòng A thành dạng 3-ceto, Δ^4^ |
| → 11-deoxycorticosteron → corticosteron → **aldosteron** | **21-hydroxylase**, 11β-hydroxylase, aldosteron synthase | Lưới nội bào → ty thể | Chỉ **lớp cầu** có aldosteron synthase |
| → 17-OH-progesteron → 11-deoxycortisol → **cortisol** | **17α-hydroxylase**, **21-hydroxylase**, **11β-hydroxylase** | Lưới nội bào → ty thể | **Lớp bó** |
| 17-OH-pregnenolon → **DHEA** → androstendion → **testosteron** | 17,20-lyase, 3β-HSD, 17β-HSD | Lưới nội bào | Lớp lưới, tế bào Leydig |
| Androgen → **estrogen** | **Aromatase** | Lưới nội bào | Buồng trứng, rau thai, mô mỡ |

> [!ung-dung] Tăng sản thượng thận bẩm sinh — thiếu 21-hydroxylase
> Thể hay gặp nhất là **thiếu 21-hydroxylase** (di truyền lặn). Không tạo đủ **cortisol** và **aldosteron** → ACTH tăng do mất ức chế ngược → tuyến phì đại, tiền chất **17-OH-progesteron** ứ lại và bị đẩy sang đường **androgen**. Hệ quả: **nam hóa** (trẻ gái có bộ phận sinh dục ngoài không rõ giới tính), thể nặng **mất muối** ở sơ sinh (hạ Na^+^, tăng K^+^). Xét nghiệm đặc trưng: **17-OH-progesteron máu tăng cao**. Đây là ví dụ đọc sơ đồ: chặn ở đâu thì chất **trước** chỗ chặn ứ lại và "tràn" sang nhánh còn mở.

### 6.2. Hormon vỏ thượng thận

Người ta chiết được khoảng **50 steroid** từ vỏ thượng thận, nhưng chỉ khoảng **10 chất** có hoạt tính hormon, chia 3 nhóm (Giáo trình tr. 245–246):

| Nhóm | Hormon | Số C | Nơi tiết | Tác dụng chính |
|---|---|---|---|---|
| **Mineralocorticoid** (chuyển hóa muối – nước) | **Aldosteron**, 11-deoxycorticosteron (DOC) | 21 | **Lớp cầu** | Aldosteron mạnh nhất: tăng **tái hấp thu Na^+^** ở **ống lượn xa**, tăng **thải K^+^** → **giữ nước** |
| **Glucocorticoid** (chuyển hóa đường) | **Cortisol**, cortison, corticosteron | 21; có **O ở C11** nên gọi là **11-oxysteroid** | **Lớp bó** | Tăng **tân tạo glucose**, tăng dự trữ glycogen ở gan, tăng **glucose-6-phosphatase** → **tăng glucose máu**; tăng thoái hóa protein cơ; **chống stress, chống viêm, chống dị ứng** |
| **Androgen vỏ thượng thận** | **DHEA**, androstendion, 11-cetoandrostendion (androstentrion), 11β-hydroxyandrostendion | **19** | Lớp lưới | Giống hormon sinh dục nam nhưng **yếu hơn** |

- Aldosteron có nhóm **–CHO ở C18** (aldehyd, vì thế có tên "aldo-steron").
- Cortisol = 11β,17,21-trihydroxy-pregn-4-en-3,20-dion. **Cortison** là dạng **11-ceto** (11-dehydrocortisol), kém hoạt tính hơn cortisol.
- **Thoái hóa**: chủ yếu ở **gan**, bằng phản ứng oxy hóa khử, tạo sản phẩm hết hoạt tính, liên hợp rồi thải qua nước tiểu; chỉ **1–5%** thải ở dạng tự do (tr. 247).

Nhờ tác dụng chống viêm, cortisol và các dẫn xuất tổng hợp (prednisolon, dexamethason…) được dùng điều trị **viêm khớp**, **bệnh tạo keo** (bệnh hệ thống), hen, dị ứng nặng (Giáo trình tr. 247).

> [!yhct] Cam thảo và "giả cường aldosteron"
> Đây là ví dụ hiếm có, trong đó cơ chế hóa sinh của một tác dụng phụ dược liệu đã được **chứng minh rõ trên người** (cơ chế enzym đã nêu ngắn ở bài *Enzym*, mã hs-05, mục 10).
> - **Cơ sở hóa sinh.** Thụ thể mineralocorticoid ở ống thận gắn **cortisol** mạnh ngang **aldosteron**, trong khi cortisol máu cao hơn aldosteron hàng trăm lần. Thận "lọc" được tín hiệu nhờ enzym **11β-HSD2** (11β-hydroxysteroid dehydrogenase typ 2). Enzym này biến **cortisol → cortison** (dạng 11-ceto, **không** gắn được thụ thể) ngay tại tế bào ống thận.
> - **Cam thảo** chứa **glycyrrhizin**. Vi khuẩn ruột thủy phân glycyrrhizin thành **acid glycyrrhetinic**, chất này **ức chế 11β-HSD2**. Cortisol không bị bất hoạt nên chiếm thụ thể, tác động **như aldosteron**: giữ Na^+^ và nước, **thải K^+^** → **tăng huyết áp, phù, hạ kali máu** (yếu cơ, rối loạn nhịp tim), kiềm chuyển hóa. Đặc trưng xét nghiệm là **renin và aldosteron đều thấp**, nên gọi là **giả cường aldosteron**.
> - **Mức bằng chứng**: có nhiều báo cáo ca bệnh và nghiên cứu trên người; tác dụng phụ thuộc **liều và thời gian dùng**, khác nhau giữa từng người. Ủy ban khoa học về thực phẩm của châu Âu đề nghị lượng glycyrrhizin **không quá khoảng 100 mg/ngày** khi dùng thường xuyên; hàm lượng glycyrrhizin trong rễ Cam thảo dao động lớn (vài % khối lượng), nên vài gam dược liệu mỗi ngày đã có thể đạt mức này. **Chích cam thảo** (tẩm mật sao) vẫn chứa glycyrrhizin. Chế phẩm cam thảo **đã loại glycyrrhizin** (DGL) ít gây tác dụng này.
> - **Ý nghĩa khi kê đơn**: Cam thảo có mặt trong rất nhiều bài thuốc. Cần thận trọng khi dùng **liều cao, kéo dài**, ở người **tăng huyết áp, suy tim, suy thận**, người đang dùng **lợi tiểu thải kali** (furosemid, thiazid; cộng dồn hạ K^+^) hoặc **digoxin** (hạ K^+^ làm tăng độc tính digoxin). Nên hỏi về huyết áp, phù, và khi cần thì kiểm tra **kali máu**.
> - **Tách bạch**: tác dụng "điều hòa các vị thuốc", "bổ tỳ ích khí" là **quan niệm YHCT**; cơ chế giữ muối – nước nêu trên là **hóa sinh đã chứng minh**. Hai điều này không thay thế nhau.

### 6.3. Hormon sinh dục nam

- Chất chính là **testosteron** (17β-hydroxy-androst-4-en-3-on), do **tế bào kẽ (Leydig)** của tinh hoàn tiết ra (Giáo trình tr. 247).
- **Androsteron** là sản phẩm thoái hóa của testosteron ở gan, hoạt tính chỉ bằng **1/6** testosteron.
- **Tổng hợp** từ **cholesterol**.
- **Thoái hóa**: sản phẩm đầu tiên là **androstendion**. Sau đó testosteron (từ tinh hoàn) và androstendion (từ vỏ thượng thận) đi chung một đường, tạo **androsteron, etiocholanolon** và một ít **epiandrosteron**. Các chất này chiếm khoảng **80%** các **17-cetosteroid trung tính** thải qua nước tiểu, dưới dạng liên hợp glucuronic hoặc sulfuric.
- **17-cetosteroid niệu** (theo giáo trình tr. 248): trẻ em khoảng **2,5 mg/24 giờ**, tăng dần ở tuổi dậy thì; người lớn **nam 13 ± 2**, **nữ 9 ± 2 mg/24 giờ**, rồi giảm dần theo tuổi.

> [!bay]
> - Giáo trình in nhầm tên **"aldrosteron"** ở trang 247 (dưới hình và trong bài). Thực ra đó là **androsteron** (5α-androstan-3-ol-17-on), một **androgen 19C**. Đừng nhầm với **aldosteron**, một **mineralocorticoid 21C** của vỏ thượng thận.
> - Nữ cũng có 17-cetosteroid niệu (9 ± 2 mg/24 giờ) vì phần lớn chất này đến từ **androgen vỏ thượng thận**, không chỉ từ tinh hoàn.

### 6.4. Hormon sinh dục nữ

Gồm 2 nhóm: **estrogen** (folliculin) và **progesteron**. Lượng tiết phụ thuộc giai đoạn phát triển của nang trứng: **giai đoạn nang** tiết **estrogen**; **giai đoạn hoàng thể** tiết cả **estrogen và progesteron** (Giáo trình tr. 248).

**Cấu tạo**

- **Estrogen** (18C): gồm **estron, estradiol, estriol**. Đây là các **steroid phenol**, vì **vòng A là vòng thơm** mang –OH ở C3. Chất lưu hành chính trong máu là **estradiol**.
  - Estron: 3-OH, **17-ceto**.
  - Estradiol: 3-OH, **17β-OH** (2 nhóm OH).
  - Estriol: 3-OH, **16α-OH, 17β-OH** (3 nhóm OH).
- **Progesteron** (21C, nhân pregnan): pregn-4-en-**3,20-dion**.

**Tổng hợp**

- Buồng trứng, tinh hoàn, vỏ thượng thận và rau thai đều tổng hợp được **estron và estradiol từ testosteron và androstendion** (phản ứng thơm hóa vòng A, nhờ enzym **aromatase**).
- Quá trình được **FSH, LH** của tuyến yên kích thích; khi có thai còn được **HCG** kích thích.
- Progesteron được tạo nhiều nhất ở **hoàng thể** và **rau thai**.

**Thoái hóa**

- Estrogen: sản phẩm chính trong nước tiểu là **estriol**, chủ yếu ở dạng liên hợp glucuro- hoặc sulfo-, gọi chung là **phenolsteroid**.
- Progesteron: thoái hóa ở gan thành **pregnandiol**, thải qua nước tiểu dạng liên hợp.

Estrogen niệu ở người bình thường (giáo trình tr. 249): **thấp nhất trước ngày kinh** (5–10 µg/24 giờ); **cao nhất ngày rụng trứng** (50–100 µg/24 giờ); giảm rồi đạt **đỉnh thứ 2** ở thời kỳ hoàng thể (30–40 µg/24 giờ).

> [!yhct] Phytoestrogen — isoflavon đậu nành và Cát căn
> - **Phytoestrogen** là chất thực vật có cấu trúc giống estradiol một phần: đều có vòng **phenol** với khoảng cách hai nhóm –OH tương tự. Nhờ vậy chúng gắn được **thụ thể estrogen** (ưu tiên **ERβ**), nhưng hoạt tính **rất yếu**, kém estradiol hàng trăm đến hàng nghìn lần. Nhóm quan trọng nhất là **isoflavon**: **genistein, daidzein** (đậu nành), **puerarin** và daidzin (rễ **Cát căn**, *Pueraria lobata*/*P. montana*). Daidzein có thể được vi khuẩn ruột chuyển thành **equol** (mạnh hơn), nhưng chỉ khoảng 30–60% người (tùy quần thể) có hệ vi khuẩn làm được việc này.
> - **Mức bằng chứng**:
>   - Isoflavon **đậu nành**: nhiều thử nghiệm lâm sàng và phân tích gộp cho thấy **giảm nhẹ cơn bốc hỏa** sau mãn kinh, kém hơn liệu pháp hormon. Hiệu quả không đều giữa các nghiên cứu. Bằng chứng về bảo vệ xương **không thống nhất**.
>   - **Cát căn**: dữ liệu về "tác dụng estrogen" chủ yếu từ **in vitro và động vật**; thử nghiệm trên người ít, cỡ nhỏ. Cần **phân biệt** với *Pueraria mirifica* (một loài khác, ở Thái Lan) chứa **miroestrol**, chất có hoạt tính estrogen **mạnh** và đã có báo cáo tác dụng phụ.
> - **Thận trọng**: người có **ung thư phụ thuộc estrogen** (vú, nội mạc tử cung) không nên tự dùng **chế phẩm chiết xuất isoflavon liều cao**. Ăn **đậu nành dạng thực phẩm** ở mức thông thường không thấy làm tăng nguy cơ trong các nghiên cứu quan sát.
> - **Tách bạch**: theo YHCT, Cát căn là vị thuốc **giải cơ, thoái nhiệt, sinh tân, chỉ khát** (bài Cát căn thang). Việc dùng Cát căn để "bổ sung nội tiết tố nữ" là cách hiểu theo dược lý hiện đại, chưa đủ bằng chứng lâm sàng.

### 6.5. Eicosanoid

Ngoài ba nhóm hormon chính, cơ thể còn có các **eicosanoid**, xếp vào loại **hormon tại chỗ**. Chúng được tổng hợp từ acid béo nhiều nối đôi, tiền chất chính là **acid arachidonic** (20C, 4 nối đôi) (Giáo trình tr. 249):

| Eicosanoid | Nơi có | Tác dụng |
|---|---|---|
| **Prostaglandin** | Nhiều mô | Kích thích **co bóp cơ trơn** |
| **Leukotrien** | Bạch cầu, lách | **Co thắt phế quản** |
| **Thromboxan** | Các mô, tiểu cầu, bạch cầu | Điều hòa **đông máu**, **co mạch** |

> [!ung-dung]
> **Aspirin** và các thuốc chống viêm không steroid ức chế enzym **cyclooxygenase** (COX), làm giảm tổng hợp prostaglandin và thromboxan → **giảm đau, hạ sốt, chống viêm, chống kết tập tiểu cầu** (xem hs-05, mục 10). Thuốc **kháng leukotrien** (montelukast) dùng trong **hen phế quản**.

## 7. Điều hòa bài tiết hormon — điều hòa ngược

Giáo trình không có mục riêng về điều hòa ngược, nhưng các ý nằm rải rác trong chương (bảng 14.1; TSH và iod; ACTH và Addison). Phần này gom chúng lại, vì đây là chìa khóa để **đọc xét nghiệm hormon**.

### 7.1. Hệ thống thứ bậc và điều hòa ngược âm

Nhiều tuyến nội tiết được tổ chức thành **trục 3 tầng**:

=> Vùng dưới đồi (hormon giải phóng) → tuyến yên trước (hormon kích thích) → tuyến đích (hormon tác dụng)

Hormon của tuyến đích quay lại **ức chế** tuyến yên và vùng dưới đồi. Đó là **điều hòa ngược âm** (negative feedback). Nhờ vậy nồng độ hormon được giữ quanh một "điểm đặt", giống như bộ ổn nhiệt của máy điều hòa: phòng nóng thì máy chạy, đủ lạnh thì máy tắt.

![Hình 2. Trục dưới đồi – tuyến yên – vỏ thượng thận và điều hòa ngược âm](truc-hpa.svg)

| Trục | Vùng dưới đồi | Tuyến yên | Tuyến đích → hormon | Ức chế ngược |
|---|---|---|---|---|
| Thượng thận | CRH | ACTH | Vỏ thượng thận (lớp bó) → **cortisol** | Cortisol ức chế CRH, ACTH |
| Giáp | TRH | TSH | Tuyến giáp → **T~4~, T~3~** | T~3~/T~4~ ức chế TRH, TSH |
| Sinh dục | GnRH | FSH, LH | Buồng trứng / tinh hoàn → **estrogen, progesteron / testosteron** | Hormon sinh dục ức chế GnRH, FSH, LH |
| GH | GH-RH (+), somatostatin (−) | GH | Gan → IGF-1 | IGF-1, GH |

**Điều hòa ngược dương** (positive feedback) hiếm gặp hơn. Ví dụ: giữa chu kỳ kinh, **estrogen tăng cao kéo dài** lại **kích thích** tuyến yên, gây **đỉnh LH** dẫn tới **rụng trứng** (khớp với số liệu LH đỉnh 16–25 mU/mL ở mục 4.1).

### 7.2. Điều hòa trực tiếp bởi chất chuyển hóa

Một số tuyến **không** nằm dưới trục tuyến yên mà "đo" trực tiếp chất trong máu:

| Tín hiệu trong máu | Hormon đáp ứng |
|---|---|
| Glucose máu **tăng** | **Insulin** tăng, glucagon giảm (hs-07) |
| Ca^2+^ máu **giảm** | **PTH** tăng (calcitonin khi Ca^2+^ tăng) |
| **K^+^** máu tăng, angiotensin II tăng (do huyết áp, thể tích giảm) | **Aldosteron** tăng |
| Áp lực thẩm thấu máu **tăng** | **ADH** tăng |

### 7.3. Dùng điều hòa ngược để đọc xét nghiệm

**Quy tắc:** nếu bệnh **ở tuyến đích** thì hormon tuyến yên đi **ngược chiều** hormon tuyến đích. Nếu bệnh **ở tuyến yên** thì hai hormon đi **cùng chiều**.

| Kết quả | Gợi ý |
|---|---|
| TSH **↑**, FT~4~ **↓** | **Suy giáp nguyên phát** (tại tuyến giáp: viêm giáp Hashimoto, thiếu iod) |
| TSH **↓**, FT~4~ **↑** | **Cường giáp nguyên phát** (Basedow, nhân độc) |
| Cortisol **↓**, ACTH **↑** | **Addison** (suy thượng thận nguyên phát) → da sạm |
| Cortisol **↓**, ACTH **↓** | Suy tuyến yên, hoặc **đang/vừa ngừng corticoid** dùng lâu (trục bị ức chế) |
| Cortisol **↑**, ACTH **↓** | U vỏ thượng thận tự tiết cortisol (hội chứng Cushing do tuyến) |

> [!ung-dung] Corticoid trộn lẫn trong "thuốc nam", "thuốc gia truyền" — cảnh báo
> - Cơ quan quản lý dược nhiều lần phát hiện các sản phẩm quảng cáo là "thuốc nam", "thuốc gia truyền", "cao xương khớp", "thuốc tăng cân", "thuốc trị hen" có **trộn corticoid** (hay gặp nhất là **dexamethason**). Người dùng thấy **hết đau, ăn ngon, tăng cân, đỡ khó thở nhanh** và tin là thuốc hay, nên dùng kéo dài.
> - **Hậu quả theo đúng cơ chế đã học**:
>   - Dùng lâu → **hội chứng Cushing do thuốc**: mặt tròn, béo thân, rạn da tím, **tăng glucose máu** (do tân tạo glucose), tăng huyết áp, **loãng xương**, teo cơ (thoái hóa protein), dễ **nhiễm trùng**, loét dạ dày.
>   - Corticoid ngoại sinh **ức chế ngược** CRH và ACTH (hình 2) → **lớp bó vỏ thượng thận teo**. Nếu **ngừng đột ngột** → **suy thượng thận cấp** (mệt lả, tụt huyết áp, hạ glucose máu, có thể tử vong).
>   - Xét nghiệm: **cortisol máu thấp và ACTH thấp** dù bệnh nhân có biểu hiện Cushing. Dexamethason **không** được đo bằng xét nghiệm cortisol thông thường.
> - **Với người hành nghề YHCT**: khi bệnh nhân đáp ứng "quá nhanh, quá đẹp" với một sản phẩm không rõ nguồn gốc, hoặc có dấu hiệu Cushing, phải nghĩ tới corticoid trộn lẫn. **Không tự ý cắt ngay**; chuyển khám nội tiết để **giảm liều dần** dưới theo dõi. Chỉ dùng dược liệu và thành phẩm có nguồn gốc rõ ràng, được cấp phép.

## Tóm tắt

| Chủ đề | Điểm cốt lõi |
|---|---|
| Định nghĩa | Chất hữu cơ do tuyến nội tiết tiết vào máu, tác dụng lên cơ quan đích; nội tiết – tại chỗ – tự thân; hormon thần kinh (vasopressin) ≠ chất dẫn truyền thần kinh |
| Phân loại cấu tạo | Peptid–protein (3 đến > 200 aa); amin từ tyrosin (catecholamin tan trong nước; T~3~/T~4~ ít tan); steroid C18 estrogen, C19 androgen, C21 corticoid + progesteron; eicosanoid từ acid arachidonic |
| Phân loại cơ chế | Thụ thể nội bào: steroid, T~3~/T~4~ → HRE → tăng phiên mã. Thụ thể màng: peptid, catecholamin → chất thông tin thứ hai |
| Protein G | Gs (αβγ): GDP → GTP, Gsα hoạt hóa AC; Gi ức chế AC (somatostatin); Gq hoạt hóa phospholipase C; độc tố tả (Gs), ho gà (Gi) |
| cAMP | ATP → cAMP (AC); PKA R~2~C~2~ + 4 cAMP → 2 C hoạt động; PDE → 5'-AMP; glucagon, epinephrin, ACTH, TSH, FSH, LH; khuếch đại khoảng 10.000 lần |
| Chất khác | cGMP (ANF; NO – GC chứa hem; PKG); PLC: PIP~2~ → IP~3~ (Ca^2+^ từ lưới nội bào) + DAG (PKC); Ca^2+^–calmodulin (4 vị trí); tyrosin kinase (insulin α~2~β~2~, EGF, PDGF) |
| Tuyến yên | GH 191 aa (2 S–S); PRL 199 aa; FSH, LH, TSH, HCG: α chung 92 aa, β đặc hiệu; ACTH 39 aa (24 đầu có hoạt tính; 6–10 giống MSH); ADH, oxytocin 9 aa (khác vị trí 3, 8) |
| Dưới đồi | CRH 41, TRH 3, GnRH 10, GH-IH (somatostatin) 14 aa; PIF (nay: dopamin) |
| Ca^2+^ | PTH 84 aa ↑ Ca^2+^, ↓ phosphat; calcitonin 32 aa ↓ Ca^2+^ (tế bào C tuyến giáp) |
| Tụy | Insulin 51 aa (A21 + B30; 3 S–S), ↓ glucose, tyrosin kinase; glucagon 29 aa, cAMP, ↑ glucose; somatostatin 14 aa |
| Tiêu hóa | Gastrin 17 aa (Zollinger–Ellison); secretin 27 aa (bicarbonat); CCK 33 aa (enzym tụy) |
| Catecholamin | Phe → Tyr → DOPA (tyrosin hydroxylase) → dopamin (PLP) → NE (vitamin C) → E (SAM); thoái hóa MAO, COMT → VMA; NE/E = 1/4 |
| Hormon giáp | Thu iodua (TSH; SCN^−^, ClO~4~^−^ ức chế) → oxy hóa (peroxidase; thiouracil ức chế) → MIT, DIT trên thyroglobulin → T~4~, T~3~ → thủy phân; TBG 70–75%, TBPA 15–20%; 0,03% T~4~ tự do |
| Nhân steroid | Gonan 17C (A, B, C, D); estran 18C, androstan 19C, pregnan 21C |
| Vỏ thượng thận | Lớp cầu: aldosteron (giữ Na^+^, thải K^+^); lớp bó: cortisol (↑ glucose, chống viêm); lớp lưới: DHEA, androstendion (19C) |
| Sinh dục | Testosteron (Leydig) → androsteron, 17-cetosteroid niệu; estrogen phenol 18C (estron, estradiol, estriol) từ androgen; progesteron → pregnandiol |
| Điều hòa ngược | Dưới đồi → tuyến yên → tuyến đích, hormon tuyến đích ức chế ngược; bệnh tại tuyến đích: hai hormon ngược chiều |
| YHCT | Cam thảo ức chế 11β-HSD2 → giả cường aldosteron; phytoestrogen yếu, bằng chứng hạn chế; cảnh giác corticoid trộn lẫn |
