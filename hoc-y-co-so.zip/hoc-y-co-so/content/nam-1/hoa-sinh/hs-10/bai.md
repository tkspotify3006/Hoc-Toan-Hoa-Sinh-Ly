---
title: Chuyển hóa hemoglobin
thoi-gian: 45 phút
muc-tieu:
- Vẽ và giải thích được sơ đồ thoái hóa hemoglobin ngoài mạch: hem → biliverdin → bilirubin tự do → bilirubin liên hợp → urobilinogen, stercobilin; nêu được chu trình ruột – gan.
- Mô tả được số phận của hemoglobin khi tan máu trong lòng mạch (haptoglobin, hemopexin, hemosiderin).
- Giải thích được cơ chế vàng da trước gan, tại gan, sau gan và phân biệt được chúng bằng xét nghiệm bilirubin máu, nước tiểu, phân; nêu được vàng da sơ sinh, hội chứng Gilbert, Crigler–Najjar.
- Trình bày được 8 bước tổng hợp hem, cách điều hòa qua ALA synthase và các bệnh porphyria do thiếu enzym.
- Nêu được cơ chế tổng hợp globin và phân biệt bệnh hemoglobin (sai về chất) với thalassemia (sai về lượng).
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Hồng cầu sống khoảng **120 ngày**; khi già bị bắt giữ ở **lách – hệ võng nội mô** (~90% Hb thoái hóa ngoài mạch). Globin → acid amin (amino acid); sắt → transferrin, dùng lại.
> 2. **Hem → biliverdin** (hem oxygenase, giải phóng **CO** và Fe) **→ bilirubin tự do** (biliverdin reductase). Bilirubin tự do không tan trong nước, đi trong máu nhờ **albumin**.
> 3. Ở gan, **UDP-glucuronyl transferase** gắn acid glucuronic → **bilirubin liên hợp** (tan trong nước) → mật → ruột: vi khuẩn biến thành **urobilinogen → stercobilin** (màu phân). Một phần urobilinogen quay về gan (**chu trình ruột – gan**), một ít ra nước tiểu.
> 4. Vàng da **trước gan** (tan máu): tăng bilirubin **tự do**. **Tại gan**: tăng cả hai. **Sau gan** (tắc mật): tăng bilirubin **liên hợp**, phân bạc màu, nước tiểu sẫm.
> 5. Tổng hợp hem qua **8 bước** (ty thể – bào tương – ty thể), bước đầu do **ALA synthase** là bước điều hòa (hem ức chế ngược). Thiếu enzym ở các bước sau gây **porphyria**; chì ức chế ALA dehydratase và ferrochelatase.

Hemoglobin (Hb) gồm phần **hem** và phần **globin**. Cấu trúc, tính chất và các loại Hb đã học ở **hoa-sinh/hs-03, mục 4**. Bài này theo dõi Hb trong hai chiều: **bị phá hủy** (thoái hóa, mục 1–2) và **được tạo ra** (tổng hợp, mục 3). Thoái hóa hem liên quan đến **vàng da**; rối loạn tổng hợp hem gây **porphyria**; sai sót tổng hợp globin gây **bệnh hemoglobin** và **thalassemia** (Giáo trình tr. 163).

## 1. Thoái hóa hemoglobin

### 1.1. Thoái hóa ngoài mạch — con đường chính

Hồng cầu sống trung bình khoảng **120 ngày**. Hồng cầu già có màng kém đàn hồi, bị các đại thực bào ở **lách** (và gan, tủy xương — gọi chung là **hệ liên võng nội mô**) bắt giữ và phá hủy. Bình thường khoảng **90%** lượng Hb được thoái hóa theo đường này, tức là **ngoài hệ tuần hoàn** (Giáo trình tr. 163).

**Bước 1 — tách hem và globin.** Hb bị thủy phân thành hem và globin.

- **Globin** là protein, được thủy phân thành acid amin. Phần lớn acid amin được dùng lại để tổng hợp protein mới; phần còn lại đi vào thoái hóa acid amin chung (xem hs-09).
- **Hem** đi tiếp vào con đường tạo sắc tố mật.

**Bước 2 — mở vòng hem: hem → biliverdin.**

- Enzym **hem oxygenase** (giáo trình ghi *hemoxygenase*), nằm ở **microsom** (lưới nội bào), cắt vòng porphyrin ở **cầu methenyl alpha**.
- Phản ứng cần **O~2~** và **NADPH**. Điện tử từ NADPH được chuyển đến qua hệ khử của cytochrom P-450 (NADPH-cytochrom P-450 reductase).
- Sản phẩm: **biliverdin** (màu **xanh lục**), **CO** và **ion sắt** (giáo trình ghi Fe^3+^). Sắt gắn vào **transferrin** để chở về tủy xương dùng lại.
- Enzym **đặc hiệu với hem**, vì chính nguyên tử sắt của hem tham gia vào cơ chế mở vòng.

=> Hem + O~2~ + NADPH → Biliverdin + CO + Fe + NADP^+^

> [!vi-du] Vì sao chim và bò sát không bị "vàng da"?
> Ở chim và bò sát, quá trình dừng ở **biliverdin**; biliverdin xuống ruột và thải ra phân. Ở người và nhiều động vật có vú, biliverdin bị **khử tiếp** thành bilirubin (Giáo trình tr. 164). Vết bầm tím đổi màu từ tím (Hb) → xanh lục (biliverdin) → vàng (bilirubin) chính là con đường này diễn ra ngay dưới da.

**Bước 3 — biliverdin → bilirubin.** Enzym **biliverdin reductase** khử biliverdin thành **bilirubin** (màu vàng cam), coenzym là **NADPH** (bị oxy hóa thành NADP^+^).

=> Biliverdin + NADPH + H^+^ → Bilirubin + NADP^+^

![Hình 1. Thoái hóa hem thành bilirubin và chu trình ruột – gan của urobilinogen. Bước liên hợp ở gan (màu nhấn) là bước quyết định bilirubin "tự do" hay "liên hợp".](thoai-hoa-hem.svg)

> [!vi-du] Số liệu để hình dung
> Mỗi ngày người trưởng thành phá hủy khoảng **6 g Hb**, tạo ra khoảng **250–300 mg bilirubin**. Khoảng 80% bilirubin đến từ Hb của hồng cầu già; phần còn lại từ các hemoprotein khác (cytochrom, myoglobin…) và từ hồng cầu non bị hủy ngay trong tủy xương. Các số này không có trong giáo trình, chỉ để tham khảo.

#### a) Bilirubin tự do trong máu

Bilirubin vừa tạo thành là **bilirubin tự do** (còn gọi bilirubin **gián tiếp**, bilirubin **chưa liên hợp**):

- **Không tan trong nước**, nhưng có **ái lực cao với lipid**. Vì vậy nó dễ chui vào màng tế bào và gây hại, đặc biệt cho **hệ thần kinh**.
- Trong máu, bilirubin tự do được **albumin** huyết thanh chở đi. Mỗi phân tử albumin có **hai vị trí** gắn bilirubin (Giáo trình tr. 164).
- Phức hợp bilirubin – albumin quá lớn nên **không lọc qua cầu thận**. Vì thế bilirubin tự do **không có trong nước tiểu**, dù nồng độ trong máu cao.

#### b) Liên hợp ở gan

Đến gan, bilirubin **tách khỏi albumin** rất nhanh và đi vào tế bào gan. Tại đây nó gắn với **acid glucuronic**:

- Chất cho glucuronat: **UDP-glucuronat** (acid UDP-glucuronic).
- Enzym: **UDP-glucuronyl transferase** (UGT; giáo trình gọi *glucuronyl transferase*).
- Sản phẩm chính là **bilirubin diglucuronid** = **bilirubin liên hợp** (còn gọi bilirubin **trực tiếp**). Hai nhóm glucuronat làm phân tử **tan được trong nước**.

=> Bilirubin + 2 UDP-glucuronat → Bilirubin diglucuronid + 2 UDP

Bilirubin liên hợp được **tiết vào đường mật**, xuống túi mật. Nó là thành phần chính của **sắc tố mật**. Phản ứng glucuronid hóa này cũng là cách gan "đóng gói" nhiều thuốc và hormon steroid để thải ra ngoài (xem hs-01, mục acid glucuronic).

> [!bay] Vì sao gọi "trực tiếp" và "gián tiếp"?
> - Tên gọi đến từ **phản ứng van den Bergh** với **thuốc thử diazo** (giáo trình ghi "Van der Bergh"). Bilirubin **liên hợp** tan trong nước nên phản ứng **ngay (trực tiếp)** tạo màu azo. Bilirubin **tự do** phải được hòa tan trước bằng cồn/chất gia tốc mới phản ứng, nên gọi là **gián tiếp**.
> - Ghi nhớ cặp đôi: **tự do = gián tiếp = chưa liên hợp = không tan trong nước = gắn albumin = không ra nước tiểu**. **Liên hợp = trực tiếp = tan trong nước = có thể ra nước tiểu** khi tăng trong máu.
> - Máy xét nghiệm thường đo **bilirubin toàn phần** và **bilirubin trực tiếp**; bilirubin gián tiếp = toàn phần − trực tiếp.

#### c) Ở ruột: urobilinogen và stercobilin

Bilirubin liên hợp theo mật xuống ruột. Ở đó, **enzym của vi khuẩn đường ruột** làm hai việc:

1. **Cắt bỏ glucuronat** (thủy phân).
2. **Khử** bilirubin thành **urobilinogen** (không màu). Urobilinogen tiếp tục bị khử thành **stercobilinogen**.

Ở đoạn cuối ruột và khi ra ngoài, urobilinogen và stercobilinogen bị **oxy hóa** thành **urobilin** và **stercobilin**. Hai sắc tố này tạo **màu vàng nâu của phân** bình thường.

> [!cap-nhat] Chiều oxy hóa – khử ở ruột
> Giáo trình (tr. 165) viết "urobilinogen tiếp tục **oxy hóa** thành stercobilinogen" và hai chất này "bị **khử** thành urobilin và stercobilin". Thực ra chiều phản ứng ngược lại: bilirubin → urobilinogen → stercobilinogen là các bước **khử** (thêm hydro — chính sơ đồ của giáo trình ghi "+ 8H"); còn urobilinogen → urobilin, stercobilinogen → stercobilin là **oxy hóa** (các chất "-ogen" không màu, khi gặp không khí bị oxy hóa thành sắc tố có màu). Khi thi, nắm đúng **thứ tự các chất**; chiều phản ứng nên hiểu theo hóa sinh hiện đại.

#### d) Chu trình ruột – gan

- Khoảng **10–20%** urobilinogen (giáo trình ghi khoảng **20%**, gồm cả stercobilinogen) được **tái hấp thu** qua niêm mạc ruột, theo **tĩnh mạch cửa** về gan. Gan lấy lại phần lớn và **tiết trở lại vào mật**. Vòng này gọi là **chu trình ruột – gan**.
- Một phần nhỏ thoát qua gan vào tuần hoàn chung, được **lọc qua thận**. Trong nước tiểu, urobilinogen bị oxy hóa thành **urobilin**, góp phần tạo màu vàng của nước tiểu bình thường (Giáo trình tr. 165).
- Ở ruột, bilirubin liên hợp cũng có thể bị enzym **β-glucuronidase** cắt thành bilirubin tự do và được hấp thu trở lại. Điều này đặc biệt quan trọng ở trẻ sơ sinh (mục 2.2).

> [!bay] Bình thường trong nước tiểu có gì?
> - **Urobilinogen**: có, nhưng chỉ **vết** (lượng nhỏ).
> - **Bilirubin**: **không có**. Bilirubin tự do không lọc được; bilirubin liên hợp trong máu quá thấp.
> - Vì vậy, thấy **bilirubin niệu dương tính** nghĩa là **bilirubin liên hợp trong máu tăng** (vàng da tại gan hoặc sau gan), không bao giờ do tăng bilirubin tự do đơn thuần.

#### e) Trẻ sơ sinh và người dùng kháng sinh

Trẻ sơ sinh những ngày đầu **chưa có vi khuẩn đường ruột**. Bilirubin xuống ruột không được khử thành urobilinogen, một phần bị oxy hóa thành **biliverdin**, nên phân có thể có **màu xanh**. Người dùng kháng sinh làm mất vi khuẩn ruột cũng có thể gặp phân xanh như vậy (Giáo trình tr. 165).

> [!cap-nhat] Một số câu của giáo trình cần đọc lại
> - Giáo trình (tr. 164) ghi rằng "bilirubin kết hợp chặt chẽ với albumin mà không thể tách được gặp trong **hội chứng Gilbert**". Hiện nay, dạng bilirubin gắn **cộng hóa trị** với albumin gọi là **delta-bilirubin**; nó xuất hiện khi **bilirubin liên hợp tăng kéo dài** (ứ mật, tắc mật), không phải trong Gilbert. Delta-bilirubin có đời sống dài như albumin (~3 tuần), nên khi đã giải quyết tắc mật, bilirubin máu và vàng da vẫn giảm chậm.
> - Giáo trình (tr. 165) nhắc phân xanh "gặp trong hội chứng Crigler–Najjar". Phân xanh ở sơ sinh và người dùng kháng sinh là do **thiếu vi khuẩn ruột**; còn trong Crigler–Najjar gan liên hợp kém nên sắc tố mật xuống ruột **ít** hơn, phân có thể **nhạt** màu.

### 1.2. Thoái hóa trong lòng mạch (tan máu nội mạch)

Bình thường chỉ **dưới 10%** Hb được giải phóng **thẳng vào máu** (do hồng cầu vỡ trong lòng mạch). Cơ thể có hệ thống "thu gom" để không mất sắt qua thận (Giáo trình tr. 165):

| Bước | Điều xảy ra | Ý nghĩa |
|---|---|---|
| 1 | Hb tự do phân ly thành các **dimer αβ** | Dimer đủ nhỏ để lọc qua cầu thận |
| 2 | Dimer gắn với **haptoglobin** (protein huyết tương) → phức hợp lớn | **Không lọc qua thận**; được chở về **gan** để thoái hóa như mục 1.1 |
| 3 | Khi **haptoglobin cạn** (tan máu nhiều): dimer lọc qua cầu thận, được ống thận **tái hấp thu** | Sắt tích lại trong tế bào ống thận dưới dạng **hemosiderin** |
| 4 | Khi Hb tự do **trên khoảng 5 g/ngày** | Xuất hiện **hemoglobin niệu** và **methemoglobin niệu** (nước tiểu đỏ – nâu) |
| 5 | Hb không gắn được haptoglobin bị oxy hóa thành methemoglobin hoặc tách ra **hem tự do** | Hem tự do gắn **hemopexin** → về gan thoái hóa |
| 6 | Hem nhiều quá khả năng của hemopexin | Hem gắn tạm vào **albumin** (methemalbumin), chờ chuyển sang hemopexin |

> [!ung-dung] Xét nghiệm khi nghi tan máu
> - **Haptoglobin huyết thanh giảm** là dấu hiệu nhạy của **tan máu** (nhất là tan máu nội mạch), vì haptoglobin bị tiêu thụ khi gom Hb.
> - **Hemoglobin niệu** (nước tiểu đỏ nâu, que thử "máu" dương tính nhưng soi không thấy hồng cầu) và **hemosiderin niệu** (sau vài ngày) gợi ý tan máu nội mạch: truyền nhầm nhóm máu, sốt rét nặng, thiếu G6PD gặp chất oxy hóa (xem sinh-hoc/sh-08).
> - Kèm theo: **LDH tăng**, **bilirubin gián tiếp tăng**, **hồng cầu lưới tăng**.

## 2. Ý nghĩa lâm sàng — vàng da

### 2.1. Bilirubin máu và nguyên nhân vàng da

Nồng độ bilirubin huyết thanh là kết quả của **cân bằng** giữa tốc độ **tạo ra** (thoái hóa hem) và khả năng **liên hợp, bài tiết** của gan (Giáo trình tr. 165).

| Chỉ số | Giáo trình | Đổi sang đơn vị SI (×17,1) |
|---|---|---|
| Bilirubin toàn phần | **dưới 1 mg%** | dưới khoảng **17 µmol/L** |
| Bilirubin tự do (gián tiếp) | khoảng **0,8 mg%** | khoảng 14 µmol/L |
| Bilirubin liên hợp (trực tiếp) | **dưới 0,2 mg%** | dưới khoảng **3,4 µmol/L** |

*Khoảng tham chiếu chỉ để tham khảo; mỗi phòng xét nghiệm có khoảng riêng (nhiều phòng xét nghiệm ở Việt Nam lấy bilirubin toàn phần ≤ 17–21 µmol/L, trực tiếp ≤ 5 µmol/L). Quy đổi: 1 mg/dL (mg%) = 17,1 µmol/L.*

**Vàng da** (jaundice) là khi bilirubin máu tăng làm da, **củng mạc mắt**, niêm mạc nhuộm vàng. Thường thấy rõ ở củng mạc khi bilirubin toàn phần vượt khoảng **2–3 mg/dL (34–50 µmol/L)**. Giáo trình chia nguyên nhân vàng da thành **ba nhóm**: trước gan, tại gan, sau gan.

> [!ghi-nho] Cách suy luận thay cho học thuộc
> Hãy tự hỏi: **"tắc ở khâu nào của Hình 1?"**
> - Khâu **tạo** bilirubin quá nhiều (trước gan) → ứ **bilirubin tự do**.
> - Khâu **liên hợp / tiết** trong tế bào gan hỏng (tại gan) → ứ **tự do**, hoặc **cả hai**.
> - Khâu **dẫn mật** xuống ruột bị chặn (sau gan) → bilirubin liên hợp **trào ngược vào máu**; ruột **thiếu** sắc tố mật.
> Sau đó suy ra: chất nào tan trong nước thì ra **nước tiểu**; thiếu bilirubin xuống ruột thì **phân bạc màu** và **mất urobilinogen**.

### 2.2. Vàng da trước gan (prehepatic jaundice)

**Cơ chế:** hồng cầu bị phá hủy **quá nhiều** (tan máu, *hemolysis*). Bilirubin tự do được tạo ra nhanh hơn khả năng liên hợp của gan, nên **bilirubin tự do tăng**. Hầu hết trường hợp **chức năng gan bình thường** (Giáo trình tr. 166).

Nguyên nhân:

- **Tan máu mắc phải**: **truyền nhầm nhóm máu**, hóa chất, một số loại ung thư, thuốc gây tan máu.
- **Tan máu di truyền**: có nhiều hồng cầu bất thường (bệnh hemoglobin, thalassemia, bệnh màng hồng cầu, thiếu enzym hồng cầu). Hồng cầu bất thường bị hủy nhanh, kể cả ngay trong **tủy xương**, nên chỉ rất ít hồng cầu mới vào được máu ngoại vi (tạo hồng cầu không hiệu quả).
- **Tăng phá hủy các hem không thuộc Hb** (cytochrom, myoglobin…) ở gan và mô khác.

Hệ quả xét nghiệm: gan liên hợp **hết công suất**, nên lượng bilirubin liên hợp xuống ruột **nhiều hơn bình thường** → **urobilinogen niệu tăng**, **phân sẫm màu** (nhiều stercobilin). **Không có bilirubin niệu**.

#### Vàng da ở trẻ sơ sinh

Giáo trình xếp vàng da sơ sinh vào nhóm **trước gan**, do ba yếu tố cộng lại (Giáo trình tr. 166):

1. **Tăng tan máu** sau sinh: trẻ có nhiều hồng cầu chứa HbF, đời sống hồng cầu ngắn hơn.
2. **Gan chưa trưởng thành**: thiếu tạm thời enzym **glucuronyl transferase** cả về lượng lẫn chức năng.
3. **Tăng tái hấp thu bilirubin tự do từ ruột**: ruột chưa có vi khuẩn để khử bilirubin, β-glucuronidase cắt bilirubin liên hợp thành bilirubin tự do, rồi bilirubin được hấp thu trở lại.

Số liệu của giáo trình:

- Ở trẻ bình thường, bilirubin **cao nhất vào ngày thứ 2–3** sau sinh, sau đó giảm nhanh.
- Nghĩ tới **bệnh lý** (ví dụ **bất đồng nhóm máu Rh**) khi bilirubin toàn phần **trên 15 mg%** (≈ 257 µmol/L) vài ngày sau sinh, hoặc **trên 10 mg%** (≈ 171 µmol/L) khi trẻ đã được **hai tuần**, hoặc khi bilirubin cao **kéo dài trên hai tuần** hay vẫn **tiếp tục tăng**.

> [!cap-nhat] Vàng da sơ sinh theo thực hành hiện nay
> - Giáo trình ghi bilirubin "trở về bình thường ở trẻ dưới bảy tuần". Thực hành nhi khoa hiện nay: vàng da **sinh lý** xuất hiện **sau 24 giờ**, đỉnh ngày **3–5**, thường hết trong khoảng **1 tuần** ở trẻ đủ tháng và **2 tuần** ở trẻ non tháng.
> - Dấu hiệu **bệnh lý**: vàng da xuất hiện **trong 24 giờ đầu**, bilirubin tăng nhanh, vàng da **kéo dài quá 2 tuần**, hoặc **bilirubin trực tiếp tăng** (phải loại trừ teo đường mật — kèm phân bạc màu). Ngưỡng điều trị không dùng một con số cố định mà tra **biểu đồ theo giờ tuổi** và yếu tố nguy cơ.
> - Khi thi, dùng số liệu của giáo trình.

> [!ung-dung] Vàng da nhân và chiếu đèn
> - Bilirubin **tự do** tan trong lipid. Khi nó vượt quá khả năng gắn của albumin, phần **không gắn** đi qua **hàng rào máu – não** (còn non ở sơ sinh), lắng ở các nhân xám đáy não gây **vàng da nhân** (*kernicterus*): li bì, bú kém, co giật, di chứng vĩnh viễn.
> - Thuốc **đẩy bilirubin khỏi albumin** (sulfonamid, ceftriaxon, salicylat…) làm tăng nguy cơ này ở sơ sinh. Lưu ý với dược liệu chứa **berberin** đã nêu ở **sinh-hoc/sh-08** (thiếu G6PD).
> - **Chiếu đèn ánh sáng xanh lam** biến bilirubin trong da thành đồng phân tan trong nước, thải ra **không cần gan liên hợp** — cơ chế quang học xem **vat-ly/vl-08**. Ca nặng phải **thay máu**.

### 2.3. Vàng da tại gan (hepatic jaundice)

Giáo trình chia hai nhóm (tr. 166):

**a) Khiếm khuyết vận chuyển hoặc liên hợp** → tăng chủ yếu **bilirubin tự do**:

| | **Hội chứng Gilbert** | **Crigler–Najjar typ I** | **Crigler–Najjar typ II** |
|---|---|---|---|
| Enzym UGT (UGT1A1) | Giảm nhẹ (còn khoảng 30%) | **Mất hoàn toàn** | Giảm nặng (dưới 10%) |
| Bilirubin tự do | Tăng nhẹ, dao động (thường dưới 3–4 mg%) | Rất cao (thường trên 20 mg%) | Cao vừa |
| Biểu hiện | Lành tính; vàng da nhẹ khi **nhịn đói**, gắng sức, ốm, stress | **Vàng da nhân** từ sơ sinh, rất nặng | Thường sống đến tuổi trưởng thành |
| Phenobarbital (cảm ứng UGT) | Giảm bilirubin (ít khi cần) | **Không đáp ứng** | **Đáp ứng** |
| Di truyền | Lặn, rất phổ biến (vài % dân số) | Lặn, rất hiếm | Lặn, hiếm |

*Phân typ, mức enzym và số liệu trong bảng là phần bổ sung; giáo trình chỉ nêu cả hai bệnh đều do thiếu hụt glucuronyl transferase.*

**b) Tế bào gan bị hủy hoại** hoặc **tiết mật bị tổn thương**: viêm gan virus, nhiễm độc (rượu, thuốc), khối u gan; giáo trình nêu cả **hội chứng Rotor** (rối loạn bài tiết bẩm sinh). Trong nhóm này, bilirubin **liên hợp** tăng nhiều hơn.

Vì sao trong viêm gan **cả hai loại** đều tăng? Tế bào gan bị tổn thương vừa **liên hợp kém** (ứ bilirubin tự do), vừa **tiết mật kém**, đồng thời các vi quản mật bị chèn ép, bilirubin liên hợp **trào ngược** vào máu. Gan bệnh cũng không thu hồi được urobilinogen từ tĩnh mạch cửa, nên **urobilinogen niệu thường tăng**.

> [!ung-dung] Gilbert trong đời thực
> - Người trẻ khỏe, men gan **bình thường**, không thiếu máu, chỉ có **bilirubin gián tiếp tăng nhẹ**, rõ hơn sau nhịn ăn hoặc ốm: nghĩ đến Gilbert, không cần điều trị.
> - Thuốc trị ung thư **irinotecan** được thải qua UGT1A1; người mang biến thể giảm hoạt tính UGT1A1 dễ bị độc tính nặng (giảm bạch cầu, tiêu chảy). Ngày nay có xét nghiệm gen UGT1A1 trước khi dùng.
> - **Dubin–Johnson** (bổ sung) là bệnh bẩm sinh khác, tăng bilirubin **liên hợp** do khiếm khuyết bơm tiết bilirubin vào mật, gan có màu sẫm đặc trưng; cùng nhóm với Rotor.

### 2.4. Vàng da sau gan (posthepatic jaundice)

Còn gọi là **vàng da tắc mật**: mật không xuống được ruột. Nguyên nhân hay gặp: **sỏi đường mật**, **u đầu tụy**, u các cơ quan khác chèn vào đường mật (Giáo trình tr. 166).

- Bilirubin liên hợp vẫn được tạo ra nhưng **ứ lại**, trào ngược vào máu → **bilirubin liên hợp tăng** là chính.
- Bilirubin liên hợp tan trong nước, lọc qua thận → **bilirubin niệu (+)**, nước tiểu **vàng sẫm** như nước chè.
- Không có bilirubin xuống ruột → **phân bạc màu** (màu đất sét), **urobilinogen niệu giảm hoặc mất**.
- Acid mật cũng ứ lại → **ngứa**; thiếu mật ở ruột → kém hấp thu mỡ và vitamin tan trong dầu (A, D, E, **K** → rối loạn đông máu).
- Tắc mật **kéo dài** làm tổn thương gan, khả năng liên hợp giảm. Khi đó bilirubin liên hợp vẫn tăng nhưng **không cao bằng** trường hợp tắc mật với chức năng gan còn tốt (Giáo trình tr. 166).

### 2.5. Bảng phân biệt ba loại vàng da

| Xét nghiệm | **Trước gan** (tan máu) | **Tại gan** (viêm gan) | **Sau gan** (tắc mật hoàn toàn) |
|---|---|---|---|
| Bilirubin **tự do** (gián tiếp) máu | **↑↑** | ↑ | Bình thường hoặc ↑ nhẹ |
| Bilirubin **liên hợp** (trực tiếp) máu | Bình thường | ↑ | **↑↑** |
| **Bilirubin niệu** | **Âm tính** | Dương tính | **Dương tính** |
| **Urobilinogen niệu** | **↑** | ↑ (hoặc bình thường) | **Giảm / mất** |
| Màu **phân** | **Sẫm** (nhiều stercobilin) | Bình thường hoặc nhạt | **Bạc màu** |
| Màu nước tiểu | Bình thường hoặc sẫm do urobilin | Sẫm | Sẫm như nước chè |
| Xét nghiệm kèm theo | Hb ↓, hồng cầu lưới ↑, LDH ↑, haptoglobin ↓ | **AST, ALT ↑↑** | **ALP, GGT ↑↑** |

*Bảng tổng hợp theo cơ chế ở các mục 2.2–2.4 (giáo trình mô tả bằng lời, không có bảng). Hội chứng Gilbert, Crigler–Najjar giống cột "trước gan" về bilirubin (chỉ tăng bilirubin tự do, không có bilirubin niệu), nhưng urobilinogen không tăng và không có dấu hiệu tan máu.*

> [!bay]
> - **Nước tiểu sẫm màu ≠ tắc mật chắc chắn.** Phải hỏi: sẫm do **bilirubin** (tắc mật, viêm gan) hay do **urobilin, hemoglobin** (tan máu)? Que thử nước tiểu tách được bilirubin và urobilinogen.
> - **Urobilinogen niệu mất** là dấu hiệu của **tắc mật hoàn toàn** (không có bilirubin xuống ruột). Dùng kháng sinh phổ rộng kéo dài cũng làm urobilinogen giảm (mất vi khuẩn ruột).
> - **Vàng da sơ sinh sinh lý** tăng bilirubin **tự do**. Trẻ sơ sinh vàng da mà **bilirubin trực tiếp tăng** và **phân bạc màu** là dấu hiệu nguy hiểm (teo đường mật), không phải vàng da sinh lý.

> [!yhct] Nhân trần, Chi tử trong chứng "hoàng đản"
> - YHCT gọi vàng da là **hoàng đản**. Thể **dương hoàng** (thấp nhiệt: vàng tươi, sốt, nước tiểu vàng sẫm) có bài kinh điển **Nhân trần cao thang** (*Thương hàn luận*): Nhân trần, Chi tử, Đại hoàng.
> - **Bằng chứng về cơ chế, chủ yếu trên động vật:** hoạt chất của nhân trần Trung Quốc (*Artemisia capillaris*), như **scoparon** (6,7-dimethylesculetin), và **genipin** (aglycon của geniposid trong **Chi tử**, *Gardenia jasminoides*) có tác dụng **lợi mật** (tăng tiết mật) trên chuột. Một nghiên cứu trên chuột còn cho thấy scoparon hoạt hóa thụ thể nhân **CAR**, làm tăng biểu hiện UGT1A1 và tăng thải bilirubin. **Thử nghiệm lâm sàng chất lượng cao còn thiếu**; không suy ra rằng thuốc thay thế được điều trị hiện đại.
> - **Cẩn thận tên gọi:** vị "**Nhân trần**" thường dùng ở Việt Nam là cây *Adenosma* (chủ yếu *A. caeruleum*; họ Hoa mõm chó theo cách xếp cũ, nay xếp vào họ Mã đề), **khác chi, khác họ** với *Artemisia capillaris* (Nhân trần hao, Ân trần) trong các nghiên cứu nói trên. Kết quả của loài này không áp dụng thẳng cho loài kia.
> - **Thận trọng:** (1) vàng da **sau gan** do sỏi, u cần chẩn đoán hình ảnh và can thiệp; thuốc lợi mật **không giải quyết** được tắc nghẽn cơ học. (2) **Không** tự cho trẻ sơ sinh vàng da uống nước nhân trần hay thuốc nam thay cho đo bilirubin và chiếu đèn. (3) Geniposid liều cao gây độc gan ở chuột; dùng chế phẩm có Chi tử **nhiều năm** đã được báo cáo liên quan đến **xơ hóa tĩnh mạch mạc treo** (loạt ca ở Nhật Bản).

## 3. Tổng hợp hemoglobin

Hb được tổng hợp ở **hồng cầu non trong tủy xương**. Quá trình cần đủ ba thứ: **sắt**, **hem** và **globin** (Giáo trình tr. 167).

### 3.1. Tổng hợp hem

Mọi tế bào có hemoprotein (cytochrom…) đều tổng hợp được hem, nhưng mạnh nhất ở **tủy xương** (cho Hb) và **gan** (cho cytochrom P-450). Quá trình đi qua **ty thể → bào tương → ty thể**. Việc vận chuyển chất qua màng ty thể phức tạp và cũng là chỗ dễ gây gián đoạn (Giáo trình tr. 167).

![Hình 2. Tám bước tổng hợp hem, enzym của từng bước và porphyria do thiếu enzym tương ứng. Bước 1 (màu nhấn) là bước điều hòa; hem ức chế ngược ALA synthase.](tong-hop-hem.svg)

| Bước | Phản ứng | Enzym | Nơi xảy ra |
|---|---|---|---|
| 1 | **Succinyl-CoA + glycin** → **acid δ-aminolevulinic (ALA)** + CO~2~ + CoA-SH | **ALA synthase** (coenzym **pyridoxal phosphat** — vitamin B6) | **Ty thể** |
| 2 | 2 ALA → **porphobilinogen (PBG)** + 2 H~2~O | **ALA dehydratase** | Bào tương |
| 3 | 4 PBG → **hydroxymethylbilan** (mạch thẳng 4 pyrrol) | **PBG deaminase** | Bào tương |
| 4 | Hydroxymethylbilan → **uroporphyrinogen III** (khép vòng) | **Uroporphyrinogen III synthase** | Bào tương |
| 5 | Uroporphyrinogen III → **coproporphyrinogen III** (khử carboxyl) | **Uroporphyrinogen decarboxylase** | Bào tương |
| 6 | Coproporphyrinogen III → **protoporphyrinogen IX** (khử carboxyl oxy hóa: 2 nhóm propionat → 2 nhóm vinyl, mất 2 CO~2~; giáo trình ghi "2 CO~2~ và 2 hydro", thực tế mất 4 H) | **Coproporphyrinogen oxidase** | **Ty thể** |
| 7 | Protoporphyrinogen IX → **protoporphyrin IX** | **Protoporphyrinogen oxidase** | Ty thể |
| 8 | Protoporphyrin IX + **Fe^2+^** → **HEM** | **Ferrochelatase** | Ty thể |

> [!bay]
> - **Nguyên liệu**: succinyl-CoA (từ chu trình Krebs, xem hs-06) và **glycin**. Không phải acetyl-CoA, không phải glutamat.
> - Không có enzym bước 4, hydroxymethylbilan **tự khép vòng** thành **uroporphyrinogen I** — đồng phân **vô dụng**, không đi tiếp thành hem (nhánh nét đứt trong Hình 2).
> - Các chất "**-ogen**" (porphyrinogen) **không màu**. Khi bị oxy hóa thành **porphyrin** (uroporphyrin, coproporphyrin) thì có màu đỏ tím và **phát huỳnh quang** dưới ánh sáng; đó là lý do porphyria thể da gây **nhạy cảm ánh sáng**.
> - Fe gắn vào ở **bước cuối cùng** (ferrochelatase), dạng **Fe^2+^**.

**Điều hòa tổng hợp hem** (Giáo trình tr. 167):

- Điểm điều hòa chính là **ALA synthase** (bước 1, bước chậm nhất).
- Theo cơ chế **điều khiển ngược**: hem trong gan **tăng** thì tổng hợp ALA synthase **giảm**; hem **giảm** thì ALA synthase **tăng**. (Hem còn ức chế trực tiếp enzym này và cản enzym đi vào ty thể.)
- Tốc độ tổng hợp hem còn phụ thuộc **nhu cầu hemoprotein** trong gan (ví dụ cần nhiều cytochrom P-450), số lượng hồng cầu non trong tủy, các enzym khác trên con đường và tốc độ giữ sắt của tế bào.

> [!vi-du] Vì sao thuốc có thể "kích phát" cơn porphyria?
> Các thuốc được chuyển hóa qua gan như **barbiturat**, một số thuốc chống động kinh, cùng với **rượu**, làm gan tổng hợp nhiều **cytochrom P-450**. Hem bị tiêu thụ để làm P-450, hem tự do trong gan giảm → **mất ức chế ngược** → ALA synthase tăng mạnh. Nếu một enzym phía sau bị thiếu (porphyria), các chất trung gian phía trước (**ALA, PBG**) dồn ứ và gây cơn cấp. **Nhịn đói** cũng làm tăng ALA synthase ở gan. Ngược lại, truyền **glucose** liều cao và **hemin** (hem tiêm tĩnh mạch) làm giảm ALA synthase, nên được dùng để điều trị cơn cấp.

### 3.2. Rối loạn tổng hợp hem — porphyria

Thiếu hụt **di truyền** hoặc **mắc phải** một enzym làm các **tiền chất của hem** (porphyrin và tiền chất) ứ đọng trong **tủy xương** hoặc **gan**. Nhóm bệnh này gọi là **porphyria**. Các chất trung gian tăng trong **máu, nước tiểu và phân**. Theo giáo trình, mỗi bước thiếu enzym (trừ **ALA synthase**) đều có một bệnh tương ứng (Giáo trình tr. 168).

| Enzym thiếu | Bệnh (viết tắt theo giáo trình) | Nhóm |
|---|---|---|
| ALA dehydratase | **PP** — "porphyria chì" (porphyria do thiếu ALAD) | Gan, cơn cấp |
| PBG deaminase | **AIP** — porphyria cấp từng đợt (giáo trình: "đợt porphyria cấp") | Gan, cơn cấp — **hay gặp nhất** trong thể cấp |
| Uroporphyrinogen III synthase | **CEP** — porphyria tủy xương bẩm sinh (bệnh Günther) | Tủy xương, da |
| Uroporphyrinogen decarboxylase | **PCT** — porphyria da muộn (giáo trình: "nhiễm sắc tố da chậm"); **HEP** — porphyria gan – tủy xương | Gan, da |
| Coproporphyrinogen oxidase | **HCP** — coproporphyria di truyền | Gan, cấp + da |
| Protoporphyrinogen oxidase | **VP** — porphyria hỗn hợp (variegate) | Gan, cấp + da |
| Ferrochelatase | **EP** — porphyria tủy xương (protoporphyria) | Tủy xương, da |

Có thể nhớ theo **hai kiểu biểu hiện** (phần bổ sung):

- **Thể cấp – thần kinh** (thiếu enzym ở **đầu** đường, ứ **ALA và PBG**, là những chất **không màu, không phát quang** nhưng **độc thần kinh**): cơn **đau bụng dữ dội**, nôn, táo bón, rối loạn thần kinh – tâm thần, mạch nhanh. Nước tiểu để ngoài ánh sáng **sẫm màu dần** (PBG chuyển thành porphobilin). Ví dụ điển hình: **AIP**.
- **Thể da** (thiếu enzym ở **cuối** đường, ứ **porphyrin** phát quang): **nhạy cảm ánh sáng**, bọng nước, sẹo ở vùng da hở. Ví dụ: **PCT** (hay gặp nhất, thường **mắc phải**, liên quan rượu, ứ sắt, viêm gan C), **EP**, **CEP** (nước tiểu và răng màu đỏ).

> [!ung-dung] Ngộ độc chì — "porphyria mắc phải"
> Chì gắn vào nhóm –SH, ức chế **ALA dehydratase** và **ferrochelatase**. Hậu quả: **ALA niệu tăng**, **kẽm protoporphyrin hồng cầu tăng** (protoporphyrin không gắn được Fe nên gắn Zn), **thiếu máu**, và triệu chứng thần kinh, đau bụng giống porphyria cấp. Cơ chế hóa vô cơ và xét nghiệm đã học ở **hoa-hoc/vc-02** (Hình 3 bài đó). Đó là lý do giáo trình gọi bệnh thiếu ALAD là "porphyria chì".

> [!cap-nhat] Porphyria và ALA synthase
> - Giáo trình ghi mọi bước trừ ALA synthase đều có bệnh tương ứng. Hiện nay biết thêm: đột biến **tăng hoạt tính** ALA synthase dạng hồng cầu (ALAS2) gây **protoporphyria liên kết X** (XLP); còn đột biến **giảm hoạt tính** ALAS2 gây **thiếu máu nguyên bào sắt** liên kết X (không phải porphyria; một số ca đáp ứng vitamin B6).
> - Điều trị dự phòng cơn **porphyria gan cấp** tái phát hiện có **givosiran** (siRNA làm giảm ALAS1 ở gan, được phê duyệt từ 2019). Khi thi, trả lời theo giáo trình.

### 3.3. Tổng hợp globin

- Globin được tổng hợp theo cơ chế **dịch mã protein** chung ở **bào tương** (xem sinh-hoc/sh-09). **Hem** từ ty thể ra bào tương và gắn vào chuỗi globin (Giáo trình tr. 168).
- Hem có thể gắn khi chuỗi đã rời ribosom hoặc ngay trong lúc tổng hợp. Chuỗi **α** rời polysom và kết hợp với chuỗi **β** còn đang gắn trên polysom; chuỗi β chỉ tách ra khi đã ghép với α thành **dimer αβ**. Hai dimer αβ kết hợp thành **α~2~β~2~**.
- **Gen**: nhóm gen chuỗi **α** nằm trên **nhiễm sắc thể 16**; nhóm gen các chuỗi **không phải α** (β, γ, δ, ε) nằm trên **nhiễm sắc thể 11**.

### 3.4. Sai sót trong tổng hợp globin

| | **Bệnh hemoglobin** (hemoglobinopathies) | **Thalassemia** |
|---|---|---|
| Sai sót | Về **chất**: chuỗi globin **sai một acid amin** | Về **lượng**: **giảm hoặc mất** tổng hợp một loại chuỗi |
| Hậu quả | Hb đổi tính chất, giảm hoặc mất khả năng chở O~2~ | Chuỗi mất cân bằng; chuỗi thừa **tủa lại** phá hủy hồng cầu non ngay trong tủy (tạo máu không hiệu quả); hồng cầu **nhỏ, nhược sắc** |
| Ví dụ | **HbS** (β6 Glu → Val; tỷ lệ cao ở châu Phi, Nam Mỹ), **HbC** (β6 Glu → Lys), HbD, **HbE** | **α-thalassemia** (thiếu chuỗi α), **β-thalassemia** (thiếu chuỗi β) |

Hậu quả hóa sinh chi tiết (HbA~2~, HbH, Hb Bart's, điện di Hb) đã học ở **hoa-sinh/hs-03, mục 4.5**; cơ chế đột biến ở **sinh-hoc/sh-10**.

> [!cap-nhat] Thalassemia di truyền trội hay lặn?
> Giáo trình (tr. 169) viết "thalassemia là bệnh di truyền **trội**". Hiện nay: thalassemia di truyền **lặn trên nhiễm sắc thể thường**. Người mang **một** gen bệnh (dị hợp) thường chỉ thiếu máu nhẹ hoặc không triệu chứng; bệnh nặng khi nhận gen bệnh từ **cả bố và mẹ**. Đây là cơ sở của **sàng lọc tiền hôn nhân, trước sinh** ở Việt Nam.

> [!cap-nhat] "Hb chiếm 34%"
> Giáo trình (tr. 163) ghi Hb chiếm **34% tổng lượng protein** trong hồng cầu. Con số 34% thực ra gần với **nồng độ Hb trong hồng cầu** (khoảng 33–34 g/dL, tức chỉ số MCHC). Tính theo protein, Hb chiếm **khoảng 95%** protein tan của hồng cầu.

## Tóm tắt

| Chủ đề | Điểm cần nhớ |
|---|---|
| Nơi thoái hóa | ~90% ngoài mạch (lách – hệ võng nội mô); dưới 10% trong lòng mạch |
| Hem → biliverdin | **Hem oxygenase** (microsom; O~2~, NADPH); giải phóng **CO** và Fe → transferrin |
| Biliverdin → bilirubin | **Biliverdin reductase** (NADPH) |
| Bilirubin tự do | Gián tiếp, không tan trong nước, gắn **albumin**, **không** ra nước tiểu; độc thần kinh (vàng da nhân) |
| Liên hợp ở gan | **UDP-glucuronyl transferase** + UDP-glucuronat → bilirubin **diglucuronid** (trực tiếp, tan trong nước) |
| Ở ruột | Vi khuẩn: cắt glucuronat, khử → **urobilinogen → stercobilinogen**; oxy hóa → **urobilin, stercobilin** (màu phân) |
| Chu trình ruột – gan | ~10–20% urobilinogen tái hấp thu về gan; một ít ra nước tiểu |
| Tan máu nội mạch | **Haptoglobin** (gom dimer Hb), **hemopexin** (gom hem), hemosiderin; > 5 g/ngày → Hb niệu |
| Bilirubin máu (giáo trình) | Toàn phần < 1 mg% (≈ 17 µmol/L); tự do 0,8; liên hợp < 0,2 mg% |
| Trước gan | Tự do ↑↑, bilirubin niệu (−), urobilinogen niệu ↑, phân sẫm |
| Tại gan | Cả hai ↑, bilirubin niệu (+), AST/ALT ↑↑; Gilbert, Crigler–Najjar: chỉ tự do ↑ (thiếu UGT) |
| Sau gan | Liên hợp ↑↑, bilirubin niệu (+), urobilinogen (−), **phân bạc màu**, ALP/GGT ↑ |
| Vàng da sơ sinh | Tan máu + thiếu UGT + tái hấp thu ruột; bệnh lý nếu > 15 mg% vài ngày sau sinh, > 10 mg% sau 2 tuần, kéo dài |
| Tổng hợp hem | Succinyl-CoA + glycin; **8 bước**, ty thể → bào tương → ty thể; bước 1 **ALA synthase** (B6) điều hòa, hem ức chế ngược; bước 8 ferrochelatase gắn Fe^2+^ |
| Porphyria | Thiếu enzym bước 2–8; AIP (PBG deaminase) thể cấp; PCT, EP thể da; chì ức chế ALAD và ferrochelatase |
| Globin | Gen α: NST (nhiễm sắc thể) 16; gen không-α: NST 11; bệnh Hb = sai về chất; thalassemia = sai về lượng |
