---
title: Hóa sinh máu
thoi-gian: 55 phút
muc-tieu:
- Kể được các chức năng sinh lý và các hằng số lý hóa của máu (tỷ trọng, độ nhớt, áp suất thẩm thấu, chỉ số khúc xạ, pH).
- Trình bày được thành phần hóa học cơ bản của máu — huyết cầu và huyết tương (khí, chất vô cơ, chất hữu cơ) — và vai trò của từng thành phần.
- Nêu được cấu tạo chung, chức năng và giá trị bình thường của các protein huyết thanh chính (albumin, các globulin, protein pha cấp, kháng thể).
- Giải thích được một số thay đổi bệnh lý điển hình của protein huyết thanh và đọc được hình ảnh điện di protein cơ bản (thận hư, xơ gan, viêm cấp, đa u tủy).
- (Bổ sung) Mô tả được dòng thác đông máu, vai trò của vitamin K và cơ chế của warfarin, heparin.
---

> [!ghi-nho] Cả bài trong 5 dòng
> 1. Máu ≈ **1/13 trọng lượng cơ thể** (4–5 lít): **huyết tương 55–60%**, **huyết cầu 40–45%**. Tỷ trọng 1,050–1,060; độ nhớt gấp **4–5 lần** nước; ASTT ≈ **300 mosm/L**; pH **7,38–7,42**.
> 2. Hồng cầu giàu **K^+^** (gấp 20–30 lần huyết tương), chứa ≈ **15 g Hb/dL máu**; huyết tương giàu **Na^+^, Cl^−^**. Tổng cation = tổng anion = **155 mEq/L**.
> 3. Protein toàn phần ≈ **60–80 g/L**; **albumin** (MW 66.000) > 1/2, tạo **áp suất keo** và chở mọi thứ "khó tan". Điện di chia 5 phân đoạn: **albumin, α~1~, α~2~, β, γ**.
> 4. **Protein pha cấp** (CRP, fibrinogen, haptoglobin, ceruloplasmin, AAT, AAG) **tăng** khi viêm; albumin, prealbumin, transferrin **giảm**. Haptoglobin **giảm** khi tan máu; ceruloplasmin **giảm** trong bệnh Wilson.
> 5. **Đa u tủy**: tăng protein toàn phần, **đỉnh M hẹp ở vùng γ**, protein **Bence Jones** trong nước tiểu. Đông máu (bổ sung): dòng thác enzym → **thrombin** cắt **fibrinogen** thành fibrin; II, VII, IX, X cần **vitamin K** (đích của **warfarin**); **heparin** hoạt hóa **antithrombin**.

Chương này tập hợp những gì đã gặp rải rác ở nhiều bài. Để tránh lặp lại, các phần sau chỉ nhắc ngắn và dẫn chéo:

- Cấu trúc **hemoglobin**, đường cong phân ly oxy, các loại Hb: **hs-03, mục 4**.
- Thoái hóa Hb, **bilirubin**, haptoglobin – hemopexin khi tan máu: **hs-10**.
- Vận chuyển khí, hệ đệm, **pH và khí máu**: **hs-16**.
- Điện giải, **áp lực thẩm thấu**, áp lực keo, phù: **hs-15**.
- Lipoprotein: **hs-08**; gan tổng hợp albumin, yếu tố đông máu, nghiệm pháp vitamin K: **hs-17**.

Ở đây ta nhìn máu như một **"bảng xét nghiệm sống"**: thành phần nào, bao nhiêu, do đâu sinh ra, và thay đổi khi nào.

## 1. Chức năng sinh lý của máu

Máu là một mô lỏng lưu thông trong hệ tuần hoàn. Nó nối mọi cơ quan với nhau và với môi trường bên ngoài (Giáo trình tr. 305). Giáo trình nêu 5 nhóm chức năng:

| Chức năng | Nội dung |
|---|---|
| **Dinh dưỡng** | Chở chất dinh dưỡng từ ống tiêu hóa đến các mô |
| **Bài tiết** | Chở chất cặn bã (sản phẩm thoái hóa) từ mô đến **thận, da, phổi, ruột** để thải ra ngoài |
| **Hô hấp** | Đưa O~2~ từ phổi đến mô, đưa CO~2~ từ mô về phổi |
| **Bảo vệ** | Bạch cầu, kháng thể, kháng độc tố chống tác nhân nhiễm khuẩn; **hệ đông máu** và **hệ chống đông** luôn cân bằng nhau |
| **Điều hòa** | Chở **hormon**; giữ **thăng bằng acid – base**; điều hòa **thăng bằng nước** (trao đổi nước giữa lòng mạch và dịch mô); điều hòa **thân nhiệt** |

**Vì sao xét nghiệm máu có giá trị?** Máu là **môi trường nội môi**, thành phần hóa học khá **ổn định**. Vì thế khi một chỉ số lệch khỏi khoảng bình thường, đó thường là tín hiệu một cơ quan nào đó đang rối loạn (Giáo trình tr. 306).

**Một số con số** (Giáo trình tr. 306):

- Khối lượng máu ≈ **1/13 trọng lượng cơ thể**, tức khoảng **4–5 lít**.
- Máu tập trung nhiều ở **cơ (40%)**, **thận (7,5%)**, **phổi (6,5%)**; phân bố thay đổi theo trạng thái sinh lý.
- **Huyết tương 55–60%** thể tích máu; **huyết cầu** (hồng cầu, bạch cầu, tiểu cầu) **40–45%**.

> [!bay] Huyết tương hay huyết thanh?
> - **Huyết tương** (plasma): phần lỏng của máu **đã chống đông** (ống có EDTA, citrat, heparin) → **còn fibrinogen** và các yếu tố đông máu.
> - **Huyết thanh** (serum): phần lỏng còn lại **sau khi máu đã đông** → **mất fibrinogen** (đã thành fibrin trong cục máu) và phần lớn yếu tố V, VIII.
> - Hệ quả: điện di **huyết tương** có thêm một vạch fibrinogen ở vùng β – γ (giáo trình ghi fibrinogen chạy tới **vùng β**, tr. 314). Điện di **huyết thanh** thì không có vạch này.

## 2. Tính chất lý hóa của máu

| Hằng số | Giá trị theo giáo trình (tr. 306–307) | Phụ thuộc vào / ý nghĩa |
|---|---|---|
| **Tỷ trọng** | Máu toàn phần **1,050–1,060** (TB 1,056); huyết tương **1,024**; huyết cầu **1,093** | Huyết cầu nặng hơn → **lắng xuống** khi ly tâm (cơ sở đo hematocrit) |
| **Độ nhớt** | Gấp **4–5 lần** nước (38 °C) | Phụ thuộc **số lượng huyết cầu** và **nồng độ protein**. Thiếu máu: có khi chỉ còn **1,7 lần**; đa hồng cầu, tăng bạch cầu: có thể tới **24 lần** |
| **Áp suất thẩm thấu** | Đo trực tiếp **7,2–8,1 atm** (37 °C); đo gián tiếp **292–308 mosm/L** huyết tương | Do các **ion** (chủ yếu Na^+^, Cl^−^, HCO~3~^−^) và phân tử hữu cơ nhỏ |
| **Chỉ số khúc xạ** huyết tương | **1,3487–1,3517** | Phụ thuộc muối vô cơ và **chủ yếu là protein** → dùng khúc xạ kế ước tính **protein huyết thanh** |
| **pH** | **7,38–7,42** | Giữ bằng **hệ đệm** + **phổi** + **thận** (xem hs-16) |

**Đo áp suất thẩm thấu (ASTT) như thế nào?**

- **Trực tiếp** (áp suất thật, tính bằng atm): phức tạp, ít dùng.
- **Gián tiếp**: dựa vào **độ hạ điểm đông** của huyết thanh/huyết tương. Lý do: cả ASTT lẫn độ hạ điểm đông đều **tỷ lệ thuận với số tiểu phân** hòa tan. Máy đo dùng nguyên lý này gọi là **áp suất thẩm thấu kế** (osmometer). Giáo trình còn nêu cách ước tính qua **độ dẫn điện** của huyết tương (tr. 306).

> [!vi-du] Vì sao độ nhớt quan trọng?
> Lưu lượng máu qua mạch nhỏ **tỷ lệ nghịch với độ nhớt** (định luật Poiseuille, xem phần vật lý chất lỏng). Bệnh **đa hồng cầu** (hematocrit > 55–60%) hay **đa u tủy** (protein huyết thanh rất cao) làm máu "đặc", chảy chậm trong mao mạch → nhức đầu, mờ mắt, dễ tắc mạch. Đây gọi là **hội chứng tăng độ nhớt**. Ngược lại, người thiếu máu nặng có máu "loãng", tim phải bơm nhanh hơn để bù.

> [!cap-nhat] Khoảng áp suất thẩm thấu bình thường
> Giáo trình ghi **292–308 mosm/L** (và 305 mosm/L ở tr. 310). Hiện nay khoảng tham chiếu thường dùng là **275–295 mOsm/kg nước** (đo bằng độ hạ băng điểm). Khi tính: **≈ 2 × Na^+^ + glucose + ure** (mmol/L) — xem **hs-15, mục 3.3**. Đi thi trả lời theo số của giáo trình.

## 3. Thành phần huyết cầu

Thành phần hóa học của máu toàn phần, huyết tương và huyết cầu **rất khác nhau** (Giáo trình tr. 307):

| | Nước (%) | Chất khô (%) |
|---|---|---|
| Máu toàn phần | 76–85 | 15–24 |
| **Huyết tương** | **90–91** | **9–10** |
| **Huyết cầu** | **57–68** | **32–43** |

Huyết cầu "đặc" hơn huyết tương nhiều vì chứa đầy **hemoglobin**.

### 3.1. Hồng cầu

**Số lượng và đời sống** (Giáo trình tr. 307):

- Nam **4,5–5 triệu/mm^3^**; nữ **4–4,5 triệu/mm^3^**.
- Người sống ở **vùng núi cao**: tới **7–8 triệu/mm^3^**, để thích nghi với không khí loãng (ít O~2~ → thận tiết **erythropoietin** → tủy tăng sinh hồng cầu).
- Hồng cầu trưởng thành **không có nhân**, sống khoảng **120–130 ngày** (giáo trình; các sách hiện nay và hs-03, hs-10 lấy ≈ 120 ngày), bị phá hủy ở **lách** và **hệ võng nội mô**.

**Chức năng:** chính là **hô hấp** (chở O~2~ và CO~2~). Ngoài ra tham gia **điều hòa acid – base**, **trao đổi muối nước**, **khử độc H~2~O~2~** và nhiều quá trình chuyển hóa khác.

**Thành phần hóa học:**

- **57–68% là nước**, còn lại là chất khô.
- **Hemoglobin** chiếm khoảng **95% chất hữu cơ** của hồng cầu, tương ứng khoảng **15 g Hb/dL máu**. Lượng Hb thay đổi theo tuổi và có nhiều loại Hb (xem **hs-03**).
- Ngoài Hb còn có các **enzym**, protein cấu trúc (màng) và sản phẩm chuyển hóa.
- **Lipid** chủ yếu là **lecithin** (3,3–3,7 g/L), **cholesterol** (1,3–1,6 g/L) và các phospholipid khác.
- **Điện giải**: **80% phospho** của máu nằm trong hồng cầu. **K^+^ trong hồng cầu cao gấp 20–30 lần** huyết tương (450–480 mg%). Na 50–110 mg%, Mg 5 mg%, Fe 100 mg%, Cu 1,5 mg%.
- **Màng hồng cầu** mang các **chất quyết định nhóm máu** — phức hợp glycoprotein và glycolipid, trong đó **phần glucid** quyết định tính đặc hiệu (nhóm máu ABO: xem **hs-01**).

> [!ung-dung] Vì sao mẫu máu bị tan huyết cho kết quả kali "giả tăng"?
> K^+^ trong hồng cầu cao gấp 20–30 lần huyết tương. Nếu lấy máu qua kim quá nhỏ, lắc mạnh, để lâu chưa ly tâm hoặc để tủ lạnh nguyên ống, hồng cầu vỡ và đổ K^+^ ra huyết thanh → **kali máu tăng giả**. Huyết thanh tan huyết có màu **hồng đỏ**; phòng xét nghiệm sẽ ghi chú và yêu cầu lấy lại mẫu. Cùng lý do đó, **LDH, AST, phospho** cũng tăng giả khi tan huyết.

#### Chuyển hóa của hồng cầu *(bổ sung — giáo trình chỉ nêu "khử độc H~2~O~2~ và nhiều quá trình chuyển hóa khác")*

Hồng cầu trưởng thành **không có nhân, không có ty thể**. Vì vậy:

| Con đường | Tỷ lệ glucose | Sản phẩm | Để làm gì |
|---|---|---|---|
| **Đường phân yếm khí** (Embden–Meyerhof) | ≈ 90% | **ATP** (2/glucose), **lactat**, **NADH** | ATP chạy **bơm Na^+^–K^+^-ATPase** (giữ K^+^ cao bên trong, giữ hình đĩa lõm); NADH cho **methemoglobin reductase** |
| **Shunt Rapoport–Luebering** (nhánh của đường phân) | một phần | **2,3-BPG** (2,3-DPG) | Giảm ái lực Hb với O~2~ → nhả O~2~ cho mô (xem hs-03, hs-16) |
| **Con đường pentose phosphat** | ≈ 10% | **NADPH** | Giữ **glutathion** ở dạng khử (GSH) → glutathion peroxidase phá **H~2~O~2~** → bảo vệ màng và Hb khỏi oxy hóa |

- **Methemoglobin reductase** (cytochrom b~5~ reductase) dùng **NADH** khử Fe^3+^ của methemoglobin trở về Fe^2+^. Nhờ vậy bình thường MetHb < 1–2%.
- **Thiếu G6PD** (enzym đầu của con đường pentose phosphat) → thiếu NADPH → không giữ được GSH → gặp chất oxy hóa (một số thuốc, đậu tằm) thì **tan máu cấp**. Đã học kỹ ở **hs-07, mục pentose phosphat**.
- Thiếu **pyruvat kinase** (enzym đường phân) → thiếu ATP → bơm ion hỏng, hồng cầu mất hình dạng, bị lách phá hủy sớm → **thiếu máu tan máu** bẩm sinh.

> [!vi-du] Vì sao hồng cầu "không được phép" có ty thể?
> Hồng cầu là "xe chở oxy". Nếu nó có ty thể và chuỗi hô hấp, nó sẽ **tiêu thụ chính số O~2~ mình đang chở**. Bỏ ty thể, hồng cầu chịu sống bằng đường phân yếm khí (kém hiệu quả về ATP) để giao trọn O~2~ cho mô. Cái giá phải trả: không có ty thể, không có nhân → không tự sửa chữa được → đời sống chỉ khoảng 120 ngày.

### 3.2. Bạch cầu

- Khoảng **7.000/mm^3^** ở nam, **6.800/mm^3^** ở nữ (Giáo trình tr. 308).
- Khác hồng cầu: **có nhân, có ty thể**, nồng độ **acid nucleic cao**, có **phosphoryl oxy hóa**. Chứa nhiều **glycogen**, protein, enzym chuyển hóa đường.
- Chức năng: **bảo vệ** cơ thể qua **miễn dịch tế bào** và **miễn dịch dịch thể**.
- **Acid folic** cần cho sự trưởng thành của bạch cầu (tổng hợp nucleotid). Vì vậy trong **bệnh bạch cầu** (leukemia) người ta dùng thuốc **kháng acid folic** (ví dụ **methotrexat**, ức chế dihydrofolat reductase — xem hs-11) để điều trị.

### 3.3. Tiểu cầu

- Là tế bào đặc biệt **không có nhân** (giáo trình ghi "không có acid nucleic").
- Thành phần: **protein 57%**, **lipid 19%**, glucid rất ít.
- Chức năng cơ bản: tham gia **đông máu** — bám dính, ngưng tập tạo nút tiểu cầu, và cung cấp **bề mặt phospholipid** (phosphatidylserin, xem hs-02) cho các phức hợp enzym đông máu (mục 7).

## 4. Thành phần huyết tương — khí và chất vô cơ

Huyết tương gồm **91% nước** và **9% chất khô** (Giáo trình tr. 308).

### 4.1. Thành phần khí

| Khí | Lượng trong 100 mL máu | Dạng tồn tại |
|---|---|---|
| **O~2~** (máu động mạch) | **18–20 mL** | Chỉ **0,3 mL hòa tan**; còn lại gắn **Hb** |
| **CO~2~** | **45–50 mL** | **75% ở huyết tương**, 25% ở hồng cầu; 3 dạng: **hòa tan**, **HCO~3~^−^**, **gắn Hb** (carbamin) |

Chi tiết cơ chế vận chuyển khí: **hs-16, mục 1**.

### 4.2. Các chất vô cơ — ba cách biểu thị nồng độ

Chất vô cơ huyết thanh gồm **cation** (Na^+^, K^+^, Ca^2+^, Mg^2+^…), **anion** (Cl^−^, HCO~3~^−^, SO~4~^2−^, PO~4~^3−^…) và **nguyên tố vi lượng** (I, Cu, Fe, Zn…). Chúng ở dạng **ion tự do** hoặc **gắn với protein** (Giáo trình tr. 308).

#### a) Theo khối lượng (mg% = mg/100 mL) — cách cũ, ít dùng

| Chất | mg% | Chất | mg% |
|---|---|---|---|
| Na^+^ | 300–340 | Cl^−^ | 300–380 |
| K^+^ | 15–20 | Phospho vô cơ | 5 |
| Ca^2+^ | 9–11 | Phospho toàn phần | 10–15 |
| Mg^2+^ | 1,7–2 | Fe, Cu | vết |

#### b) Theo đương lượng (mEq/L)

**1 mEq** = khối lượng ion (mg) tính theo nguyên tử khối **chia cho hóa trị**:

=> 1 mEq Na^+^ = 23/1 = 23 mg  ;  1 mEq Cl^−^ = 35,5/1 = 35,5 mg  ;  1 mEq Ca^2+^ = 40/2 = 20 mg

**Vì sao mEq "đúng" hơn mg%?** Hoạt động hóa học và điện học của ion **không tỷ lệ với khối lượng** mà tỷ lệ với **số điện tích**. 1 mEq của ion này luôn trung hòa vừa đúng 1 mEq của ion kia. Ví dụ của giáo trình (tr. 309): tính theo khối lượng thì Cl^−^ (3650) trông **nhiều hơn** Na^+^ (3260). Nhưng tính theo mEq thì Na^+^ **142** > Cl^−^ **103**: 103 mEq Na^+^ đi cặp với Cl^−^, còn **39 mEq Na^+^** đi cặp với anion khác (chủ yếu HCO~3~^−^).

**Ionogram huyết thanh** (Giáo trình tr. 309):

| Cation | mEq/L | Anion | mEq/L |
|---|---|---|---|
| Na^+^ | **142** | Cl^−^ | **103** |
| K^+^ | 5 | HCO~3~^−^ | **27** |
| Ca^2+^ | 5 | HPO~4~^2−^ | 2 |
| Mg^2+^ | 3 | SO~4~^2−^ | 1 |
| | | Protein | **16** |
| | | Acid hữu cơ | 6 |
| **Tổng** | **155** | **Tổng** | **155** |

Tổng cation **bằng đúng** tổng anion: huyết tương **trung hòa điện**. Cách biểu thị theo mEq còn cho thấy **cân bằng Donnan** giữa trong và ngoài tế bào:

=> Anion trong TB / Anion ngoài TB = Cation ngoài TB / Cation trong TB

(Hiệu ứng Donnan và vai trò bơm Na^+^–K^+^: xem **hs-15, mục 3.1**.)

> [!ung-dung] Khoảng trống anion — ứng dụng trực tiếp của bảng trên
> Trong bảng, protein (16) và acid hữu cơ (6) là các anion **thường không đo**. Lâm sàng tính **khoảng trống anion** = Na^+^ − (Cl^−^ + HCO~3~^−^) = 142 − (103 + 27) = **12**. Khi máu tích acid hữu cơ (**lactat**, **thể ceton** trong đái tháo đường mất bù, chất độc như methanol), khoảng trống này **tăng**. Xem **hs-16, mục 3.1**.

#### c) Theo áp suất thẩm thấu (mosm/L)

**1 osmol** chứa **6,02 × 10^23^ tiểu phân**. Giáo trình ghi máu toàn phần có ASTT **305 mosm/L**, trong đó: Na 142, Cl 103, K 5, Ca 10, glucose 5,5 (≈ 1 g/L), urê 5 (≈ 0,3 g/L) (tr. 310).

- **Na^+^ và Cl^−^** gần như quyết định toàn bộ ASTT.
- **Glucose và urê** bình thường đóng góp **ít**. Nhưng khi chúng **tăng cao** (đái tháo đường mất bù, suy thận) thì ASTT tăng theo.

#### d) Thay đổi bệnh lý (Giáo trình tr. 310)

| Ion | Tăng trong | Giảm trong |
|---|---|---|
| **Na^+^** | Viêm thận | **Thiểu năng vỏ thượng thận (Addison)** — thiếu aldosteron, mất Na^+^ qua thận |
| **Cl^−^** | Choáng phản vệ, viêm thận mạn (kèm urê máu cao), thận nhiễm mỡ | **Tắc môn vị, nôn nhiều**, ỉa chảy, tắc mật, Addison |
| **Ca^2+^** | **Cường cận giáp** | **Thiểu năng cận giáp**, còi xương, mềm xương |
| **Phospho** | **Thiểu năng cận giáp**, viêm thận (suy thận) | Còi xương, **cường cận giáp** |

> [!bay] "Giáp trạng" hay "cận giáp"?
> Giáo trình viết Ca tăng trong "cường giáp trạng", giảm trong "thiểu năng giáp trạng". Hormon điều hòa Ca – P là **PTH của tuyến cận giáp** (xem hs-14, hs-15). Nên hiểu là **cận giáp**: PTH **tăng Ca^2+^**, **giảm phospho** máu (tăng thải P qua thận). Vì vậy Ca và P thường **thay đổi ngược chiều** trong bệnh cận giáp — đây là điểm hay hỏi.

> [!ung-dung] Nôn kéo dài làm mất Cl^−^
> Dịch vị chứa nhiều **HCl**. Nôn nhiều (hẹp môn vị) mất cả H^+^ lẫn Cl^−^ → **Cl^−^ máu giảm**, HCO~3~^−^ tăng → **nhiễm kiềm chuyển hóa giảm clo**. Xem hs-16, mục 3.2.

## 5. Protein huyết tương

### 5.1. Protein toàn phần

- Giáo trình: **73,10 ± 6,06 g/L** (tr. 310). Khoảng tham chiếu thường dùng hiện nay: **60–80 g/L** (tham khảo).
- Chức năng chung: duy trì **áp suất keo** (áp lực keo) — lực giữ nước trong lòng mạch, **chống mất dịch ra mô** (xem hs-15: cân bằng Starling).
- Lượng protein toàn phần chịu ảnh hưởng của dinh dưỡng, chức năng **gan** (nơi tổng hợp), **thận** (nơi có thể mất), rối loạn chuyển hóa.
- Giáo trình nhấn mạnh: **trị số protein toàn phần ít giá trị**, trị số **từng phân đoạn** mới dao động nhiều và có **giá trị chẩn đoán** (tr. 310).

| Tăng protein toàn phần | Giảm protein toàn phần |
|---|---|
| **Mất nước** (mọi phân đoạn đều tăng do cô đặc máu): giảm hấp thu nước, Addison, đái tháo đường, ỉa chảy nặng | **Mất protein**: **hội chứng thận hư** (albumin thoát qua thận tổn thương), mất máu, **bỏng nặng** |
| **Đa u tủy xương** (tăng một phân đoạn — kháng thể đơn dòng) | **Giảm cung cấp**: đói, giảm hấp thu |
| | **Pha loãng**: truyền dịch nhanh hơn tốc độ bù protein |

### 5.2. Điện di protein huyết thanh *(phần hình và tỷ lệ là bổ sung)*

Ở **pH 8,6** (cao hơn pI của hầu hết protein huyết thanh), các protein đều tích điện **âm** và chạy về **cực dương**. Protein nào **âm hơn, nhỏ hơn** thì chạy **xa hơn**. Albumin (pI ≈ 4,7, nhỏ) chạy xa nhất; γ-globulin (pI cao, lớn) gần như đứng yên. Nguyên lý pI và điện di: **hc-10, mục 3.5** và **hs-03**.

![Hình 1. Điện di protein huyết thanh: năm phân đoạn và đỉnh M trong đa u tủy (tỷ lệ % là khoảng tham khảo)](dien-di-protein.svg)

| Phân đoạn | % (tham khảo) | Protein chính (theo vị trí giáo trình nêu) |
|---|---|---|
| **Albumin** | 55–65 | Albumin; **prealbumin** chạy **trước** albumin (vạch rất mờ) |
| **α~1~** | 2–5 | **α~1~-antitrypsin (≈ 90% vạch α~1~)**, α~1~-acid glycoprotein, HDL (α-lipoprotein) |
| **α~2~** | 7–12 | **Haptoglobin**, **α~2~-macroglobulin**, **ceruloplasmin** |
| **β** | 8–14 | **Transferrin**, **hemopexin** (β~1~), **LDL** (β-lipoprotein), bổ thể C3; fibrinogen (chỉ trong huyết tương) |
| **γ** | 12–20 | **Kháng thể** (IgG chủ yếu; IgA, IgM trải từ β đến γ); CRP |

**Tỷ số A/G** (albumin/globulin) bình thường khoảng **1,2–1,8** (tham khảo). A/G **đảo ngược** (< 1) khi albumin giảm và/hoặc globulin tăng (xơ gan, đa u tủy).

> [!ung-dung] Đọc 5 kiểu điện di bệnh lý hay gặp
> | Bệnh cảnh | Hình ảnh điện di | Vì sao |
> |---|---|---|
> | **Viêm cấp** (nhiễm khuẩn, bỏng, chấn thương) | **α~1~, α~2~ tăng**; albumin giảm nhẹ | Gan tăng tổng hợp **protein pha cấp** (AAT, haptoglobin…) và giảm tổng hợp albumin |
> | **Hội chứng thận hư** | **Albumin giảm mạnh**, **α~2~ tăng rõ**, γ giảm | Protein **nhỏ** (albumin, IgG) lọt qua cầu thận; **α~2~-macroglobulin** quá lớn nên ở lại và còn được gan tăng tổng hợp |
> | **Xơ gan** | Albumin giảm; **γ tăng đa dòng** (rộng), có thể **"cầu nối β–γ"** | Gan suy giảm tổng hợp albumin; kháng nguyên từ ruột không được gan lọc → kích thích tương bào sinh nhiều IgA, IgG |
> | **Đa u tủy xương** | **Đỉnh M hẹp, nhọn** ở vùng γ (đôi khi β); protein toàn phần **tăng**; các Ig bình thường giảm | **Một dòng** tương bào ác tính tiết **một loại** kháng thể (hoặc chỉ chuỗi nhẹ) |
> | **Thiếu α~1~-antitrypsin** | Vạch **α~1~ gần như mất** | AAT chiếm ≈ 90% vạch α~1~ |
>
> **Đa u tủy** ở người lớn tuổi thường biểu hiện: đau xương, gãy xương bệnh lý, thiếu máu, **tăng Ca^2+^ máu**, suy thận, **tốc độ máu lắng rất cao**. Xét nghiệm định hướng: **điện di protein huyết thanh** (tìm đỉnh M), **điện di miễn dịch cố định** (xác định loại IgG/IgA, chuỗi κ/λ), **chuỗi nhẹ tự do** huyết thanh, **protein Bence Jones** nước tiểu.

> [!bay] Đỉnh đơn dòng và tăng đa dòng
> - **Đơn dòng** (monoclonal): đỉnh **hẹp, cao**, như "tháp nhọn" — một dòng tế bào → một loại phân tử giống hệt nhau → chạy cùng một tốc độ. Gợi ý **u tủy**, bệnh Waldenström, hoặc MGUS (bệnh gammaglobulin đơn dòng chưa xác định ý nghĩa).
> - **Đa dòng** (polyclonal): vùng γ **rộng, bè** — nhiều dòng tế bào → nhiều loại kháng thể có điện tích hơi khác nhau. Gợi ý **viêm mạn, nhiễm khuẩn, xơ gan, bệnh tự miễn, lao**.

### 5.3. Albumin

- **Trọng lượng phân tử ≈ 66.000**; chiếm **hơn một nửa** protein toàn phần; do **gan** tổng hợp (Giáo trình tr. 311).
- **Áp suất keo của máu chủ yếu do albumin**. Vì sao albumin chứ không phải globulin? Áp suất keo phụ thuộc **số phân tử**, không phụ thuộc khối lượng. Albumin vừa nhiều về khối lượng, vừa **nhỏ** hơn globulin, nên **số phân tử nhiều nhất**. Albumin lại tích điện âm, kéo theo cation (Na^+^) và nước (hiệu ứng Donnan).
- **Chở các chất kém tan**: **acid béo** tự do, **bilirubin** tự do, **hormon** (thyroxin, steroid), **Ca^2+^** (≈ 40% Ca máu gắn protein, phần lớn là albumin), kim loại, **thuốc**, vitamin.
- Giáo trình: albumin nam **56,67 ± 5,28**, nữ **53,72 ± 4,26** (in là "g/dL"; đúng đơn vị phải là **g/L**). Khoảng tham chiếu thường dùng hiện nay: **35–50 g/L** (tham khảo).

| Albumin giảm | Albumin tăng |
|---|---|
| **Bệnh gan** (giảm sản xuất), **bệnh thận** (tăng đào thải — hội chứng thận hư), suy dinh dưỡng, **hội chứng giảm albumin di truyền** (gen không tạo được albumin) | **Mất nước** (cô đặc máu), truyền albumin |

Nhiều protein huyết tương tồn tại ở **dạng đa hình** (polymorphism) do đa dạng gen qua tái tổ hợp (tr. 311).

> [!ung-dung] Albumin, phù và thuốc
> - Albumin < khoảng 25 g/L → áp suất keo giảm → nước thoát ra mô → **phù**, cổ trướng (xơ gan, thận hư, suy dinh dưỡng thể Kwashiorkor).
> - Thuốc gắn albumin mạnh (**warfarin**, phenytoin, sulfonamid, NSAID): khi albumin thấp, **phần thuốc tự do** (phần có tác dụng) **tăng** → dễ quá liều dù liều "bình thường". Hai thuốc cùng tranh vị trí gắn albumin cũng đẩy nhau ra (ví dụ sulfonamid đẩy bilirubin ở trẻ sơ sinh — xem hs-10).
> - Albumin có bán hủy ≈ **20 ngày** → phản ánh tình trạng **mạn tính**, không dùng để theo dõi suy gan cấp (xem hs-17).

### 5.4. Các protein vận chuyển khác

| Protein | Vị trí điện di · MW | Chức năng | Thay đổi bệnh lý |
|---|---|---|---|
| **Prealbumin** (transthyretin, "prealbumin gắn thyroxin") | Chạy **trước** albumin · ≈ 54.000 | Chở **thyroxin (T~4~), T~3~**; cùng RBP chở vitamin A | **Chỉ điểm rất nhạy về dinh dưỡng** vì bán hủy **rất ngắn** (≈ 2 ngày); giảm trong **bệnh gan**; có thể **tăng** trong bệnh thận khi cầu thận không lọc được |
| **Protein gắn retinol (RBP)** | Chạy nhanh hơn albumin | Phối hợp với prealbumin chở **vitamin A (retinol)** tới tế bào đích | (Phức hợp với prealbumin giúp RBP nhỏ không bị lọc mất qua thận) |
| **Haptoglobin** | **α~2~** · glycoprotein, đa hình | Gắn **Hb tự do** → chở về **hệ võng nội mô** thoái hóa. Phức hợp Hb–Hp quá lớn, **không lọc qua cầu thận** → bảo vệ thận | **Giảm khi tan máu** (bị tiêu thụ); **tăng** như một APR (viêm nhiễm, chấn thương, ung thư) |
| **Hemopexin** | **β~1~** | Chở **hem tự do** về gan; tại gan hem được giải phóng để tạo **bilirubin** | Ít khi định lượng |
| **Ceruloplasmin** | **α~2~** · có **6 nguyên tử Cu** gắn rất chặt (màu xanh nhạt) | Chở **≈ 90% đồng** huyết tương (10% còn lại gắn albumin); hoạt tính **oxidase** (oxy hóa Fe^2+^ → Fe^3+^ để sắt gắn được transferrin) | **Tăng**: là APR — viêm, xơ gan, ung thư cấp, Hodgkin, hen, **có thai, thuốc tránh thai**. **Giảm**: **bệnh Wilson**, suy dinh dưỡng, viêm gan mạn |
| **Transferrin** | **β** · glycoprotein | Chở **sắt** (từ thoái hóa hem hoặc từ thức ăn) đến **tủy xương** tạo hồng cầu. Giáo trình: **25–50 µmol/L** | **Tăng** trong **thiếu máu thiếu sắt** (cơ thể bù), thai nghén, dùng estrogen. **Giảm**: bỏng, nhiễm khuẩn, ung thư, bệnh gan, thận, di truyền |

> [!ung-dung] Bệnh Wilson
> Bệnh di truyền lặn do đột biến gen **ATP7B**: tế bào gan **không bài tiết được đồng vào mật** và không gắn được Cu vào ceruloplasmin. Đồng **ứ đọng ở gan, não, thận, hồng cầu** (và giác mạc — **vòng Kayser–Fleischer**). Xét nghiệm: **ceruloplasmin huyết thanh giảm**, đồng niệu 24 giờ tăng. Bệnh nhân trẻ có viêm gan không rõ nguyên nhân kèm run, rối loạn tâm thần thì phải nghĩ tới Wilson.

> [!bay] Transferrin và thiếu sắt
> Thiếu sắt thì transferrin **tăng** chứ không giảm (cơ thể "tăng xe" để đi gom sắt), nhưng **độ bão hòa transferrin giảm** và **ferritin giảm**. Ngược lại, khi viêm mạn, transferrin **giảm** (là APR âm) và ferritin **tăng** (là APR dương). Đây là cách phân biệt thiếu máu thiếu sắt với thiếu máu do bệnh mạn tính.

### 5.5. Protein pha cấp (APR) và các chất ức chế protease

**Protein pha cấp** (*acute phase reactant/protein*, APR) là nhóm protein huyết tương **tăng cao trong phản ứng viêm cấp**: nhiễm khuẩn, bỏng, chấn thương, ung thư (Giáo trình tr. 312).

- **Vì sao?** Đại thực bào ở ổ viêm tiết **cytokin** (IL-6, IL-1, TNF-α). Cytokin đến **gan**, "ra lệnh" tăng tổng hợp APR (để chống nhiễm khuẩn, khoanh vùng tổn thương, ức chế protease) và **giảm** tổng hợp albumin, prealbumin, transferrin.
- Do tăng trong nhiều bệnh, định lượng APR **ít giá trị chẩn đoán** nguyên nhân mà có giá trị **theo dõi và điều trị**.
- Khi APR tăng thì **albumin, prealbumin, transferrin giảm** ("APR âm"), nên **protein toàn phần không đổi hoặc chỉ tăng chút ít**.

| Protein | Đặc điểm theo giáo trình (tr. 311–314) |
|---|---|
| **α~1~-antitrypsin (AAT)** — α~1~-antiprotease | Thuộc nhóm **ức chế serine protease**; gan tổng hợp. Bất hoạt **elastase, collagenase** → bảo vệ mô liên kết khỏi elastase do **bạch cầu** giải phóng ở ổ viêm. Có nhiều dạng phân tử (xác định bằng **điện di đẳng điện**). **Thiếu AAT** → **bệnh gan ở trẻ em** và **khí phế thũng** ở tuổi **20–30**. Là APR. Chiếm ≈ **90% vạch α~1~** |
| **α~1~-acid glycoprotein (AAG)** — orosomucoid | MW ≈ **44.000**; gan tổng hợp. **Bất hoạt progesteron**; **gắn thuốc kiềm tính** → ảnh hưởng chuyển hóa thuốc. Là APR: tăng trong viêm, phản ứng tự miễn (**hen phế quản, lupus ban đỏ**), ung thư, bỏng, chấn thương. **Giảm**: suy dinh dưỡng, tổn thương gan, viêm thận, **thuốc tránh thai uống** |
| **α~2~-macroglobulin (AMG)** | Một trong những protein **lớn nhất** huyết tương; **ức chế protease**: trypsin, chymotrypsin, **thrombin**, elastase, kallikrein, **plasmin** → tham gia điều hòa **đông máu và tiêu fibrin**. **Không phải APR** (ở người). Giảm: hen phế quản, viêm cột sống, điều trị **streptokinase**. Tăng: **có thai**, dùng **estrogen**, bệnh gan, **đái tháo đường**, viêm ống thận |
| **C-reactive protein (CRP)** | Tên gọi do phản ứng với **C-polysaccharid** thành tế bào **phế cầu**. Là **APR**, gan tổng hợp; **không đặc hiệu**: tăng trong viêm, chấn thương, ung thư. Dùng **theo dõi điều trị** và tiến triển bệnh. Tham gia **hoạt hóa bổ thể**, thực bào, giải phóng lymphokin. Định lượng bằng miễn dịch enzym (EIA) hoặc đo độ tán xạ |
| **Fibrinogen** | Glycoprotein **hòa tan**, gan tổng hợp; **cơ chất của thrombin** trong đông máu. Là **APR**. **Giảm**: **đông máu rải rác trong lòng mạch (DIC)**, bệnh gan, bệnh di truyền giảm fibrinogen. Điện di huyết tương: chạy tới **vùng β** |

> [!ung-dung] CRP trong thực hành
> - CRP tăng **nhanh** (sau 6–8 giờ) và giảm **nhanh** khi hết viêm (bán hủy ≈ 19 giờ), nên rất hợp để **theo dõi đáp ứng kháng sinh**. Nhiễm khuẩn thường làm CRP tăng cao hơn nhiễm virus, nhưng **không** dùng một mình để phân biệt.
> - **CRP siêu nhạy (hs-CRP)** đo ở nồng độ rất thấp (< 1 đến > 3 mg/L), dùng đánh giá **nguy cơ tim mạch** (viêm mạn mức thấp trong xơ vữa).
> - **Tốc độ máu lắng** tăng chủ yếu do **fibrinogen** và **globulin** tăng: các protein lớn, không đối xứng làm hồng cầu dễ xếp chồng thành "chuỗi tiền" và lắng nhanh.

### 5.6. Kháng thể (immunoglobulin)

- Là thành phần **chủ yếu** của protein huyết thanh **không do gan tổng hợp** mà do **dòng tế bào lympho B** (tương bào) tạo ra (Giáo trình tr. 314).
- Cấu trúc: **2 chuỗi nặng + 2 chuỗi nhẹ** giống hệt nhau từng đôi, giữ bằng **cầu disulfid** (tetramer).
- Có **5 loại**: IgG, IgA, IgM, IgD, IgE. Tham gia trực tiếp **phản ứng kháng nguyên – kháng thể**.
- **Giảm** trong suy giảm miễn dịch di truyền. **Tăng** chia 2 kiểu: **đơn dòng** (từ một dòng tế bào) hoặc **đa dòng** (từ nhiều dòng) — phát hiện bằng **điện di**.

| | **IgG** | **IgA** | **IgM** | **IgD / IgE** |
|---|---|---|---|---|
| MW | ≈ **150.000** | ≈ **160.000** | ≈ **900.000** (lớn nhất) | — |
| Nồng độ người lớn (giáo trình) | **13,68 ± 0,93 g/L** — **cao nhất** | **3,26 ± 0,11 g/L** | **0,93 ± 0,17 g/L** | Cộng lại **< 1%** tổng kháng thể; IgE ≈ 0,44 ± 0,17 mg/L |
| Đặc điểm | **Khuếch tán ra ngoài thành mạch**, **qua được rau thai**; trung hòa độc chất, gắn kháng nguyên, hoạt hóa bổ thể | Có trong **nước bọt, nước mắt, dịch mũi, dịch ruột**: dạng **dimer** + **thành phần tiết** (bền với protease) → bảo vệ **bề mặt** niêm mạc; trong huyết tương là **monomer**. **Không qua rau thai** | Kháng thể **đầu tiên** của đáp ứng miễn dịch và **đầu tiên** bào thai tự sản xuất; **chỉ ở trong máu** (quá lớn để ra khỏi mạch) | IgD: chức năng chưa rõ. **IgE** gắn **tế bào mast** → **dị ứng** |
| Trẻ em | Sơ sinh: IgG là **của mẹ** truyền qua rau thai; 3 tháng: 350–400 mg/dL; 1 tuổi: 700–800 mg/dL; tăng dần đến **16 tuổi** | Máu cuống rốn **< 1 mg/dL**; đạt mức người lớn ở tuổi 16 | 4 tháng ≈ 50% người lớn; **8 tuổi** bằng người lớn; cuống rốn **< 20 mg/dL** | |
| Tăng đa dòng khi | Bệnh gan, bệnh collagen tự miễn, **lao**, nhiễm khuẩn | **Xơ gan**, viêm gan mạn, hen phế quản, **lao phổi** | Xơ gan, **sốt rét**, nhiễm khuẩn | IgE: dị ứng, nhiễm ký sinh trùng |

> [!vi-du] "Khoảng trống miễn dịch" ở trẻ 3–6 tháng
> IgG của mẹ (qua rau thai) giảm dần sau sinh (bán hủy ≈ 3 tuần), trong khi trẻ tự sản xuất còn ít. Vì vậy quanh **3–6 tháng tuổi** nồng độ IgG của trẻ **thấp nhất** (giáo trình: 350–400 mg/dL lúc 3 tháng). Đây là lý do lịch tiêm chủng bắt đầu sớm và **sữa mẹ** (giàu **IgA tiết**) bảo vệ niêm mạc ruột của trẻ.
> Ngược lại, **IgM máu cuống rốn cao** (> 20 mg/dL) gợi ý thai **tự** đáp ứng với một **nhiễm trùng trong tử cung** (rubella, CMV, toxoplasma, giang mai), vì IgM của mẹ không qua được rau thai.

**Rối loạn tổng hợp kháng thể đơn dòng** (Giáo trình tr. 315): gặp trong u ác hoặc u lành, **thường gặp nhất là u đa tủy**. Biểu hiện:

- Xuất hiện kháng thể bất thường, trong đó có **protein Bence Jones** (là **chuỗi nhẹ tự do** κ hoặc λ, đủ nhỏ để lọc qua cầu thận) → có trong **nước tiểu**.
- **Protein toàn phần tăng** (giáo trình ghi tới **10–12 g/dL**) và **tăng phân đoạn γ**.

> [!bay] Protein Bence Jones
> - Là **chuỗi nhẹ** (không phải chuỗi nặng, không phải IgM nguyên vẹn).
> - Que thử nước tiểu thông thường (nhạy với albumin) **thường bỏ sót** Bence Jones. Phải làm **điện di protein niệu** hoặc định lượng chuỗi nhẹ tự do.
> - Đặc tính cổ điển: **tủa ở 40–60 °C, tan lại khi đun sôi** (khác hẳn protein thường — đông vón không hồi phục, xem hs-03).

### 5.7. β~2~-microglobulin (β~2~M)

- MW nhỏ ≈ **11.800**; là **chuỗi nhẹ của kháng nguyên HLA** (HLA lớp I) trên bề mặt hầu hết tế bào có nhân (Giáo trình tr. 315).
- Khi tế bào chết, β~2~M vào máu → **lọc tự do qua cầu thận** → **tái hấp thu và thoái hóa ở ống lượn gần**.
- Vì vậy β~2~M **huyết thanh** phản ánh **tốc độ sản xuất** (tăng trong u lympho, u tủy, bệnh bạch cầu — dùng như **dấu ấn ung thư**) và **mức lọc cầu thận**. β~2~M **niệu** tăng khi **ống lượn gần** tổn thương (test nhạy).
- Giáo trình: huyết thanh **0,7–3,4 mg/dL**; nước tiểu **0–300 µg/L**. *(Khoảng thường dùng hiện nay của huyết thanh khoảng 0,8–2,4 mg/**L**; đơn vị in trong sách có thể nhầm — tham khảo.)*

## 6. Chất hữu cơ khác: lipid, glucid, chất N phi protein, enzym

### 6.1. Lipid

- **Lipid toàn phần** huyết thanh **4–7 g/L**: triglycerid, phospholipid, steroid… (Giáo trình tr. 316).
- Lipid không tan trong nước nên đi dưới dạng **lipoprotein**: **lõi** không phân cực (triglycerid, cholesterol este hóa), **vỏ** phân cực (phospholipid, cholesterol tự do, **apoprotein**). Tỷ trọng của hạt phụ thuộc **phần protein (apoprotein)**: càng nhiều protein càng nặng.

| Lipoprotein | Tên theo điện di | Đặc điểm (giáo trình) |
|---|---|---|
| **HDL** (tỷ trọng cao) | **α-lipoprotein** (chạy cùng α~1~-globulin) | Giàu **phospholipid và protein**. Giáo trình: nam 1,25–4,25 g/L; nữ 2,5–6,5 g/L |
| **LDL** (tỷ trọng thấp) | **β-lipoprotein** | Giàu **cholesterol**; giáo trình ≈ 3–4,5 g/L |
| **VLDL** (tỷ trọng rất thấp) | **Pre-β-lipoprotein** (nằm giữa α và β) | Dạng vận chuyển chủ yếu **triglycerid nội sinh** (từ gan) |
| **Chylomicron** | **Không di chuyển** khi điện di (ở điểm chấm mẫu) | Tạo ở **thành ruột** khi hấp thu triglycerid, cholesterol **ngoại sinh** → bạch mạch → ống ngực → máu |

Chi tiết chuyển hóa lipoprotein: **hs-08**.

**Cholesterol** gồm 2 dạng: **tự do** và **este hóa**, đều nằm trong lipoprotein. Cholesterol toàn phần (giáo trình): **1,5–2,0 g/L** hay 4,0–6,5 mmol/L. Tỷ số **cholesterol este / cholesterol toàn phần** bình thường **0,6–0,75**; tỷ số này dùng **đánh giá chức năng gan** (gan tạo enzym LCAT este hóa cholesterol; suy gan → tỷ số giảm — xem hs-17).

> [!cap-nhat] Một số số liệu lipid trong giáo trình cần đọc lại
> - Giáo trình (tr. 316) viết LDL "di chuyển điện di cùng với **α**-globulin". Đúng ra LDL chính là **β**-lipoprotein, chạy cùng **β**-globulin (chính giáo trình gọi nó là β-lipoprotein ngay câu đó). Đây là lỗi in.
> - Giáo trình ghi cholesterol tự do 1,1–1,6 g/L và este 0,35–0,9 g/L, mâu thuẫn với tỷ số este/toàn phần 0,6–0,75 cùng trang. Thực tế **cholesterol este chiếm khoảng 2/3** cholesterol toàn phần; hai con số tự do và este nhiều khả năng bị **in đảo**.
> - Số HDL, LDL tính bằng g/L trong sách là **khối lượng cả hạt lipoprotein**. Hiện nay xét nghiệm thường quy đo **cholesterol trong hạt** (HDL-C, LDL-C) bằng **mmol/L**: HDL-C mong muốn **≥ 1,0 mmol/L** (nam), **≥ 1,3 mmol/L** (nữ); LDL-C mục tiêu tùy nguy cơ tim mạch (người nguy cơ thấp thường < 3,0–3,4 mmol/L); cholesterol toàn phần mong muốn **< 5,2 mmol/L**; triglycerid **< 1,7 mmol/L** (tham khảo).
> - Đi thi: trả lời theo số của giáo trình khi câu hỏi hỏi số liệu sách.

### 6.2. Glucid

- Glucid máu là **glucose**. Giáo trình: **80–120 mg%** hay **4,95 ± 0,63 mmol/L** (tr. 316).
- Điều hòa bởi **hệ thống hormon** (insulin hạ; glucagon, adrenalin, cortisol, GH tăng — xem hs-14) và **gan** (xem hs-17).
- **Tăng nhẹ** sau bữa ăn, sau stress (sinh lý).
- **Tăng bệnh lý**: **đái tháo đường** do nhiều nguyên nhân — tụy (thiếu insulin), tuyến yên (GH), tuyến giáp, tuyến thượng thận (cortisol, adrenalin).
- **Giảm**: thiếu ăn, **đái tháo thận** (ngưỡng thận thấp → mất glucose qua nước tiểu), thiểu năng **tuyến yên** và **thượng thận**.

> [!cap-nhat] Ngưỡng glucose máu hiện nay
> Giáo trình ghi khoảng bình thường 80–120 mg% (4,4–6,7 mmol/L). Hiện nay (Bộ Y tế, ADA): glucose **lúc đói** bình thường khoảng **3,9–5,5 mmol/L** (nhiều phòng xét nghiệm Việt Nam ghi 3,9–6,4); **5,6–6,9** là **rối loạn glucose lúc đói**; **≥ 7,0 mmol/L** (hai lần) là tiêu chuẩn chẩn đoán **đái tháo đường**. HbA1c **≥ 6,5%** cũng là tiêu chuẩn chẩn đoán.

### 6.3. Các chất chứa nitơ phi protein (NPN)

Giáo trình gọi là "các chất nitơ không phải protid" (tr. 316–317):

| Chất | Giá trị giáo trình | Nguồn gốc · ý nghĩa |
|---|---|---|
| **Urê** | (in "3,537 mmol/L" — có lẽ là **3,5–7 mmol/L**) | Sản phẩm cuối của **chuyển hóa acid amin** (amino acid) ở **gan** (chu trình urê, hs-09) → thải qua thận. Tăng: suy thận, ăn nhiều đạm, xuất huyết tiêu hóa; giảm: suy gan nặng |
| **Acid uric** | **190–420 µmol/L** (chương purin, tr. 171, lại ghi 2,2–8 mg/dL ≈ 130–480 µmol/L — xem hs-11) | Sản phẩm cuối của **thoái hóa purin** (hs-11). Tăng: **gout**, suy thận, hóa trị ung thư |
| **Bilirubin** | Tự do **2–8 mg/L**; toàn phần **10 mg/L** (≈ 17 µmol/L) | Từ **thoái hóa hem** (hs-10). Tăng → vàng da |
| **Creatinin** | Nam **83,33 ± 20,50 µmol/L**; nữ **64,95 ± 19,80 µmol/L** | Từ **creatin phosphat của cơ**, tạo với tốc độ khá hằng định, **lọc qua cầu thận, hầu như không tái hấp thu** → chỉ số tốt đánh giá **mức lọc cầu thận** |
| **Creatin** | 1–1,5 mg/L (giáo trình) | Dự trữ năng lượng ở cơ (xem bài Hóa sinh cơ) |
| **NH~3~** | Bình thường **rất ít** | Rất độc với não; gan chuyển thành urê. Tăng trong **suy gan** (bệnh não gan) |

> [!vi-du] Vì sao creatinin "tốt" hơn urê để đánh giá thận?
> **Urê** phụ thuộc nhiều yếu tố ngoài thận: ăn nhiều đạm, sốt, xuất huyết tiêu hóa (máu bị tiêu hóa → tăng acid amin) làm urê tăng; suy gan làm urê giảm. Urê lại được **tái hấp thu một phần** ở ống thận. **Creatinin** sinh ra đều đặn từ khối cơ và gần như chỉ đi qua cầu thận, nên phản ánh **mức lọc cầu thận** sát hơn. Lưu ý: người **ít cơ** (già, suy kiệt) có creatinin "bình thường" dù thận đã suy — vì vậy ngày nay dùng **eGFR** (tính từ creatinin, tuổi, giới).

### 6.4. Enzym trong máu

Giáo trình chia enzym huyết thanh thành **2 nhóm** (tr. 317):

| Nhóm | Ví dụ | Đặc điểm |
|---|---|---|
| **Enzym có chức năng trong huyết thanh** | Các enzym của **dòng thác đông máu** (thrombin, các yếu tố đông máu), tiêu fibrin, lipoprotein lipase, bổ thể | Do gan tiết vào máu và **hoạt động ngay trong máu**; nồng độ trong máu **cao hơn** trong mô |
| **Enzym không có chức năng trong huyết thanh** | **Phosphatase kiềm (ALP)**, **amylase**, **LDH**, **GOT (AST)**, GPT (ALT), CK… | Vốn ở **trong tế bào**; chỉ "rò" vào máu khi tế bào **bị hủy** hoặc tăng sinh. Nồng độ tăng có giá trị **chẩn đoán, theo dõi, tiên lượng** bệnh của cơ quan tương ứng |

> [!bay]
> Enzym **có** chức năng huyết tương (yếu tố đông máu, cholinesterase huyết thanh) **giảm** khi gan bị bệnh — vì gan sản xuất ít đi. Enzym **không** chức năng (ALT, AST) thì **tăng** khi gan bị hủy hoại. Cùng là "bệnh gan" nhưng hai nhóm thay đổi **ngược chiều**. Xem hs-05 (enzym huyết thanh) và hs-17 (xét nghiệm gan).

## 7. Đông máu *(phần bổ sung — giáo trình chỉ nêu fibrinogen, tiểu cầu, α~2~-macroglobulin và "các enzym trong chu trình đông máu")*

Đông máu là một **dòng thác enzym** (*coagulation cascade*): mỗi yếu tố khi được hoạt hóa là một **serine protease** cắt và hoạt hóa yếu tố tiếp theo. Phần lớn yếu tố đông máu lưu hành ở dạng **tiền enzym (zymogen)**, đúng như cơ chế hoạt hóa bằng cắt peptid đã học ở **hs-05**.

**Vì sao phải là "thác"?** Mỗi bậc khuếch đại tín hiệu nhiều lần: một vài phân tử yếu tố mô ban đầu có thể sinh ra **rất nhiều** thrombin trong vài phút. Đồng thời mỗi bậc là một **điểm kiểm soát** để hãm lại khi cần.

### 7.1. Các yếu tố đông máu

| Yếu tố | Tên | Ghi chú |
|---|---|---|
| **I** | **Fibrinogen** | Cơ chất cuối, bị thrombin cắt thành fibrin |
| **II** | **Prothrombin** | Zymogen của **thrombin**; **phụ thuộc vitamin K** |
| **III** | **Yếu tố mô** (thromboplastin mô, TF) | Protein màng tế bào dưới nội mô; khởi động đường ngoại sinh |
| **IV** | **Ca^2+^** | Cầu nối các yếu tố Gla với phospholipid màng |
| **V** | Proaccelerin | Đồng yếu tố (không phải enzym) của Xa |
| **VII** | Proconvertin | **Phụ thuộc vitamin K**; bán hủy **ngắn nhất** (≈ 6 giờ) |
| **VIII** | Yếu tố chống ưa chảy máu A | Đồng yếu tố của IXa; thiếu → **hemophilia A** |
| **IX** | Yếu tố Christmas | **Phụ thuộc vitamin K**; thiếu → **hemophilia B** |
| **X** | Yếu tố Stuart–Prower | **Phụ thuộc vitamin K**; điểm hội tụ hai đường |
| **XI** | Tiền thromboplastin huyết tương | |
| **XII** | Yếu tố Hageman | Hoạt hóa khi tiếp xúc bề mặt **tích điện âm** (thủy tinh, collagen) |
| **XIII** | Yếu tố ổn định fibrin | Một **transglutaminase**: nối chéo các sợi fibrin bằng liên kết **Gln–Lys** |

(Không có yếu tố VI: tên này từng dùng cho Va rồi bỏ.)

### 7.2. Dòng thác đông máu

![Hình 2. Dòng thác đông máu kinh điển và vị trí tác dụng của warfarin, heparin](dong-thac-dong-mau.svg)

- **Đường ngoại sinh**: mạch máu tổn thương → **yếu tố mô (III)** tiếp xúc máu, gắn **VIIa** → phức hợp **TF–VIIa** hoạt hóa **X** (và cả IX).
- **Đường nội sinh**: **XII** hoạt hóa khi tiếp xúc bề mặt âm → XIa → **IXa**; IXa + **VIIIa** + Ca^2+^ + phospholipid (**"tenase"**) hoạt hóa **X**.
- **Đường chung**: **Xa + Va + Ca^2+^ + phospholipid** (= **prothrombinase**, trên màng tiểu cầu) cắt **prothrombin → thrombin**. **Thrombin** cắt **fibrinogen** bỏ các fibrinopeptid A, B → **fibrin đơn phân** tự trùng hợp thành sợi → **XIIIa** nối chéo → **cục đông bền**.
- **Thrombin** còn **hoạt hóa ngược** V, VIII, XI và tiểu cầu → khuếch đại mạnh (vòng dương).

**Xét nghiệm tương ứng** (tham khảo, mỗi phòng xét nghiệm có khoảng riêng):

| Xét nghiệm | Khảo sát | Bình thường | Kéo dài khi |
|---|---|---|---|
| **PT** (thời gian prothrombin) / **INR** | Ngoại sinh + chung (VII, X, V, II, I) | PT ≈ 11–14 giây; INR ≈ 0,8–1,2 | Thiếu vitamin K, **suy gan**, **dùng warfarin** (theo dõi bằng INR) |
| **aPTT** (thời gian thromboplastin từng phần hoạt hóa) | Nội sinh + chung (XII, XI, IX, VIII, X, V, II, I) | ≈ 25–35 giây | **Hemophilia A, B**, **dùng heparin** không phân đoạn |
| **Fibrinogen** | Yếu tố I | ≈ 2–4 g/L | Giảm: DIC, suy gan; tăng: viêm (APR) |

> [!cap-nhat] Mô hình "tế bào" của đông máu
> Sơ đồ hai đường nội sinh – ngoại sinh vẫn dùng để **hiểu xét nghiệm** (PT, aPTT). Hiện nay người ta mô tả đông máu **trong cơ thể** theo **mô hình dựa trên tế bào**: (1) **khởi đầu** trên tế bào mang yếu tố mô — TF–VIIa tạo một ít thrombin; (2) **khuếch đại** — lượng thrombin nhỏ này hoạt hóa tiểu cầu, V, VIII, XI; (3) **lan rộng** — trên màng tiểu cầu, tenase (IXa–VIIIa) và prothrombinase (Xa–Va) tạo "bùng nổ" thrombin. Bằng chứng: người **thiếu XII** có aPTT rất dài nhưng **không chảy máu**, trong khi thiếu VIII, IX thì chảy máu nặng.

### 7.3. Vitamin K và các yếu tố "Gla"

Các yếu tố **II, VII, IX, X** (và protein chống đông **C, S**) cần thêm một bước **sửa đổi sau dịch mã** ở gan: enzym **γ-glutamyl carboxylase** gắn thêm một nhóm –COOH vào các gốc **Glu** ở đầu N, tạo **γ-carboxyglutamat (Gla)** (đã giới thiệu ở hs-03, mục 1).

- Hai nhóm COO^−^ cạnh nhau của Gla **kẹp Ca^2+^**, rồi Ca^2+^ làm cầu nối gắn yếu tố đông máu vào **phosphatidylserin** (mang điện âm) trên màng tiểu cầu hoạt hóa. Không có Gla → yếu tố vẫn được tạo ra nhưng **không gắn màng**, gần như **mất hoạt tính**.
- Bước carboxyl hóa cần **vitamin K dạng khử** (hydroquinon), đồng thời vitamin K bị oxy hóa thành **vitamin K epoxid**. Enzym **vitamin K epoxid reductase (VKORC1)** khử epoxid trở lại để dùng tiếp → **chu trình vitamin K**.

**Thiếu vitamin K** gặp khi: **trẻ sơ sinh** (ruột chưa có vi khuẩn, sữa mẹ ít vitamin K — vì vậy tiêm **vitamin K~1~** ngay sau sinh để phòng xuất huyết não – màng não), **tắc mật** (thiếu muối mật, kém hấp thu vitamin tan trong dầu — hs-17), dùng kháng sinh kéo dài (diệt vi khuẩn ruột tạo vitamin K~2~), kém hấp thu.

### 7.4. Hệ chống đông tự nhiên và tiêu fibrin

Giáo trình nhấn mạnh hệ đông máu và **hệ chống đông** luôn **cân bằng** (tr. 305).

| Cơ chế | Cách hoạt động |
|---|---|
| **Antithrombin** (antithrombin III) | Chất ức chế serine protease, bất hoạt **thrombin, Xa** (và IXa, XIa, XIIa). **Heparin** tăng tốc phản ứng này lên hàng nghìn lần |
| **Protein C + protein S** (phụ thuộc vitamin K) | Thrombin gắn thrombomodulin ở nội mô bình thường → hoạt hóa protein C → cắt bất hoạt **Va, VIIIa** |
| **TFPI** | Ức chế phức hợp TF–VIIa–Xa |
| **α~2~-macroglobulin** (giáo trình, tr. 312) | "Bẫy" nhiều protease: **thrombin, plasmin**, kallikrein, trypsin… |
| **Tiêu fibrin** | **Plasminogen → plasmin** (nhờ **tPA** của nội mô, urokinase; thuốc **streptokinase**) → plasmin cắt fibrin thành các mảnh, trong đó có **D-dimer**. α~2~-antiplasmin và α~2~-macroglobulin hãm plasmin |

> [!ung-dung] D-dimer
> D-dimer là mảnh chỉ sinh ra khi **fibrin đã nối chéo** bị plasmin phân hủy. D-dimer **âm tính** giúp **loại trừ** huyết khối tĩnh mạch sâu, thuyên tắc phổi ở bệnh nhân nguy cơ thấp. D-dimer **dương tính** thì **không đặc hiệu** (tăng cả sau mổ, có thai, viêm, ung thư, DIC).

### 7.5. Thuốc chống đông — warfarin và heparin

| | **Warfarin** (kháng vitamin K) | **Heparin** |
|---|---|---|
| Bản chất | Dẫn xuất **coumarin** (giống cấu trúc vitamin K) | **Glycosaminoglycan** sulfat hóa mạnh, tích điện âm nhiều nhất cơ thể (hs-01) |
| Cơ chế | Ức chế **VKORC1** → hết vitamin K dạng khử → gan tạo II, VII, IX, X (và C, S) **thiếu Gla**, mất hoạt tính | Gắn **antithrombin**, đổi cấu hình, tăng tốc bất hoạt **thrombin** và **Xa**. Heparin trọng lượng phân tử thấp (enoxaparin) chủ yếu **anti-Xa** |
| Tác dụng in vitro | **Không** (chỉ tác dụng ở gan) | **Có** — dùng làm chất chống đông ống nghiệm |
| Khởi phát | **Chậm** 3–5 ngày (phải chờ các yếu tố cũ hết: VII hết trước, II bán hủy ≈ 60 giờ hết sau cùng) | **Ngay lập tức** (tiêm tĩnh mạch hoặc dưới da) |
| Đường dùng | Uống | Tiêm (phân tử lớn, tích điện → không hấp thu qua ruột) |
| Theo dõi | **PT/INR** (đích thường **2–3**) | **aPTT** (heparin không phân đoạn); anti-Xa (heparin TLPT thấp) |
| Giải độc | **Vitamin K~1~**; nặng: huyết tương tươi, phức hợp prothrombin | **Protamin sulfat** (protein base, tích điện dương → trung hòa heparin âm) |
| Thai kỳ | **Qua rau thai**, gây dị tật (xem sh-12) | **Không qua rau thai** → ưu tiên khi có thai |

> [!bay]
> - **Thiếu vitamin K** và **dùng warfarin** đều làm **PT kéo dài trước** (vì VII có bán hủy ngắn nhất), aPTT kéo dài sau.
> - Warfarin có **khoảng điều trị hẹp**, gắn **albumin ≈ 99%** và chuyển hóa qua **CYP2C9** (hs-17). Rất nhiều thuốc, **thức ăn giàu vitamin K** (rau lá xanh đậm) và **dược liệu** làm INR dao động.
> - Ống nghiệm chống đông: **EDTA, citrat, oxalat** chống đông bằng cách **tạo phức với Ca^2+^** (yếu tố IV); **heparin** chống đông qua antithrombin. Citrat dùng cho xét nghiệm đông máu vì tác dụng **thuận nghịch** (thêm Ca^2+^ lại là máu đông).

> [!yhct] Thuốc hoạt huyết hóa ứ và thuốc chống đông
> - Nhóm **hoạt huyết hóa ứ** trong YHCT (chữa "huyết ứ": đau cố định, khối u cục, kinh nguyệt có máu cục, chấn thương…) gồm nhiều vị đã được nghiên cứu về tác dụng trên **tiểu cầu và đông máu**. Phải tách hai tầng: khái niệm "huyết ứ" của YHCT **rộng hơn** và **không đồng nhất** với "tăng đông" của y học hiện đại; còn tác dụng dược lý thì đo được, với **mức bằng chứng khác nhau**:
>   - **Đan sâm** (*Salvia miltiorrhiza*): acid salvianolic, tanshinon **ức chế ngưng tập tiểu cầu** (in vitro, động vật). Có **nhiều báo cáo ca** bệnh nhân đang dùng **warfarin** bị **INR tăng vọt, chảy máu** sau khi dùng Đan sâm; nghiên cứu trên động vật cho thấy Đan sâm làm giảm thải trừ warfarin. Đây là tương tác được ghi nhận **rõ nhất** trong nhóm.
>   - **Đương quy** (*Angelica sinensis*): chứa dẫn xuất **coumarin** và acid ferulic; có **báo cáo ca** (ít, chủ yếu một ca kinh điển) INR tăng gấp đôi khi phối hợp warfarin; dữ liệu trên động vật ít và **chưa thống nhất**. Mức bằng chứng **thấp hơn** Đan sâm.
>   - **Xuyên khung** (*Ligusticum chuanxiong*): **tetramethylpyrazin** (ligustrazin) và acid ferulic ức chế ngưng tập tiểu cầu (thực nghiệm; một số nghiên cứu lâm sàng ở Trung Quốc, chất lượng hạn chế). Dữ liệu tương tác trên người **ít**, chủ yếu là **suy luận từ cơ chế**.
>   - **Tam thất** (*Panax notoginseng*): YHCT xếp vào thuốc **chỉ huyết** nhưng "cầm máu mà không gây ứ" — thực nghiệm cho thấy có thành phần **cầm máu** (dencichin) lẫn saponin (notoginsenosid) **chống ngưng tập tiểu cầu**. Hướng tác dụng ròng khi phối hợp thuốc chống đông **chưa rõ**, nên vẫn cần thận trọng.
> - Ngoài ra **nghệ** (curcumin), **gừng**, **tỏi**, **bạch quả** cũng có dữ liệu chống ngưng tập tiểu cầu. **Thủy điệt** (con đỉa) chứa **hirudin** ức chế trực tiếp thrombin (xem bài *Hóa học acid amin, protein và hemoglobin*, mã hs-03, mục 2).
> - **Thực hành an toàn**: luôn **hỏi bệnh nhân có dùng warfarin, thuốc chống đông đường uống mới, aspirin, clopidogrel** không trước khi kê thang có các vị trên; nếu bắt buộc phối hợp thì phải **thông báo bác sĩ điều trị** để theo dõi **INR** sát, nhất là lúc **bắt đầu và lúc ngừng** thang thuốc; thường khuyên **ngừng thảo dược ảnh hưởng đông máu khoảng 2 tuần trước phẫu thuật** (khuyến cáo thận trọng chung, không dựa trên thử nghiệm lớn). Bằng chứng hiện có chủ yếu là **báo cáo ca, động vật, in vitro**; chưa có thử nghiệm lâm sàng lớn lượng hóa nguy cơ.

## 8. Bảng hằng số sinh hóa máu thường dùng *(tham khảo)*

Khoảng dưới đây là khoảng **thường gặp ở các phòng xét nghiệm Việt Nam** (người lớn). **Mỗi phòng xét nghiệm có khoảng tham chiếu riêng**; khi đi thi dùng số của giáo trình (cột phải).

| Xét nghiệm | Khoảng tham khảo hiện nay | Giáo trình ghi |
|---|---|---|
| Glucose lúc đói | 3,9–5,5 mmol/L (nhiều phòng xét nghiệm ghi đến 6,4) | 80–120 mg%; 4,95 ± 0,63 mmol/L |
| Urê | 2,5–7,5 mmol/L | "3,537 mmol/L" (lỗi in) |
| Creatinin | Nam 62–120; nữ 53–100 µmol/L | Nam 83,33 ± 20,50; nữ 64,95 ± 19,80 µmol/L |
| Acid uric | Nam 180–420; nữ 150–360 µmol/L | 190–420 µmol/L |
| Bilirubin toàn phần / trực tiếp | ≤ 17 (có nơi 21) / ≤ 5 µmol/L | Toàn phần 10 mg/L; tự do 2–8 mg/L |
| Protein toàn phần | 60–80 g/L | 73,10 ± 6,06 g/L |
| Albumin | 35–50 g/L | 56,67 ± 5,28 (nam) |
| Cholesterol toàn phần | < 5,2 mmol/L (mong muốn) | 1,5–2,0 g/L; 4,0–6,5 mmol/L |
| Triglycerid | < 1,7 mmol/L | — |
| Na^+^ / K^+^ / Cl^−^ | 135–145 / 3,5–5,0 / 98–106 mmol/L | 142 / 5 / 103 mEq/L |
| Ca toàn phần / Ca ion hóa | 2,15–2,55 / 1,1–1,3 mmol/L | 9–11 mg%; 5 mEq/L |
| HCO~3~^−^ | 22–28 mmol/L | 27 mEq/L |
| Áp lực thẩm thấu | 275–295 mOsm/kg | 292–308 mosm/L |
| AST, ALT (37 °C) | ≤ 40 U/L | — |
| CRP | < 5 mg/L (tùy kỹ thuật, có nơi < 10) | — |
| Fibrinogen | 2–4 g/L | — |
| Transferrin | 2–4 g/L (≈ 25–50 µmol/L) | 25–50 µmol/L |
| PT / INR / aPTT | 11–14 giây / 0,8–1,2 / 25–35 giây | — |

> [!bay] Đơn vị — nguồn gây lỗi số 1
> - **mg% = mg/dL**; muốn đổi sang **mg/L** thì **nhân 10**. Giáo trình (tr. 309) viết "Na^+^ 3260 mg%" — đúng ra là **3260 mg/L** (= 326 mg%, khớp với bảng 300–340 mg% ở tr. 308).
> - **mg/dL → mmol/L**: chia cho phân tử khối rồi nhân 10. Glucose: 90 mg/dL ÷ 180 × 10 = **5 mmol/L** (nhanh: chia 18). Cholesterol: chia **38,7**. Creatinin: mg/dL × **88,4** = µmol/L.
> - Với ion hóa trị 1, **mEq/L = mmol/L**; với Ca^2+^, Mg^2+^ thì **mEq/L = 2 × mmol/L** (Ca^2+^ 5 mEq/L = 2,5 mmol/L).

## Tóm tắt

| Chủ đề | Điểm chính |
|---|---|
| Chức năng | Dinh dưỡng, bài tiết, hô hấp, bảo vệ (bạch cầu, kháng thể; cân bằng đông – chống đông), điều hòa (hormon, acid – base, nước, thân nhiệt) |
| Số lượng | 1/13 trọng lượng (4–5 L); huyết tương 55–60%, huyết cầu 40–45%; cơ 40%, thận 7,5%, phổi 6,5% |
| Lý hóa | Tỷ trọng 1,050–1,060 (HT 1,024; HC 1,093); độ nhớt 4–5 lần nước; ASTT 7,2–8,1 atm, 292–308 mosm/L; khúc xạ 1,3487–1,3517 (theo protein); pH 7,38–7,42 |
| Nước / chất khô | Máu 76–85 / 15–24%; huyết tương 90–91 / 9–10%; huyết cầu 57–68 / 32–43% |
| Hồng cầu | 4,5–5 (nam), 4–4,5 triệu/mm³ (nữ); sống 120–130 ngày; Hb ≈ 95% chất hữu cơ, 15 g/dL; **K^+^ gấp 20–30 lần**; 80% phospho máu; màng mang kháng nguyên nhóm máu. Bổ sung: đường phân yếm khí (ATP, 2,3-BPG), pentose phosphat (NADPH → GSH) |
| Bạch cầu, tiểu cầu | BC ≈ 7.000/mm³, có nhân, giàu acid nucleic; acid folic → thuốc kháng folic trị bệnh bạch cầu. TC không nhân: protein 57%, lipid 19%; đông máu |
| Khí | O~2~ 18–20 mL/100 mL (0,3 hòa tan); CO~2~ 45–50 mL (75% huyết tương) |
| Vô cơ | 3 cách biểu thị: mg%, **mEq/L** (hợp lý nhất), mosm/L. Cation = anion = **155 mEq/L** (Na 142; Cl 103, HCO~3~^−^ 27, protein 16). Na giảm trong Addison; Cl giảm khi nôn, tắc môn vị; Ca – P ngược chiều trong bệnh cận giáp |
| Protein toàn phần | 73 ± 6 g/L; áp suất keo; tăng khi mất nước, đa u tủy; giảm khi thận hư, đói, mất máu, bỏng |
| Albumin | MW 66.000, > 1/2 protein; áp suất keo; chở acid béo, bilirubin, hormon, Ca, thuốc; giảm: gan, thận, di truyền |
| Điện di (pH 8,6) | Albumin → α~1~ (AAT) → α~2~ (haptoglobin, AMG, ceruloplasmin) → β (transferrin, hemopexin, LDL) → γ (Ig). Đỉnh M hẹp = đơn dòng (u tủy); γ rộng = đa dòng |
| Protein khác | Prealbumin (T~4~, dinh dưỡng); RBP (vitamin A); haptoglobin **giảm khi tan máu**; hemopexin (hem); ceruloplasmin (6 Cu, 90% Cu; **giảm ở Wilson**); transferrin (sắt; **tăng khi thiếu sắt**); β~2~M (HLA; thận, ung thư) |
| APR | Tăng: CRP, fibrinogen, haptoglobin, ceruloplasmin, AAT, AAG. Giảm: albumin, prealbumin, transferrin. AMG **không phải** APR. Thiếu AAT → khí phế thũng tuổi 20–30, bệnh gan trẻ em |
| Kháng thể | Lympho B; 2 nặng + 2 nhẹ; IgG cao nhất, qua rau thai; IgA tiết ở niêm mạc; IgM lớn nhất, đầu tiên; IgE dị ứng. U tủy: Bence Jones (chuỗi nhẹ) niệu |
| Lipid, glucid, NPN | Lipid 4–7 g/L (HDL = α, VLDL = pre-β, LDL = β, chylomicron không di chuyển); cholesterol este/toàn phần 0,6–0,75 (gan); glucose 4,95 ± 0,63 mmol/L; urê, acid uric, bilirubin, creatinin, NH~3~ |
| Enzym | Có chức năng (đông máu) vs không chức năng (ALP, amylase, LDH, AST) |
| Đông máu (bổ sung) | Thác zymogen → Xa + Va → **thrombin** → fibrin → XIIIa nối chéo. II, VII, IX, X cần **vitamin K** (Gla). Warfarin ức chế VKORC1 (PT/INR; giải độc vitamin K); heparin + antithrombin (aPTT; giải độc protamin). Thảo dược hoạt huyết (Đan sâm, Đương quy…) có thể tăng nguy cơ chảy máu khi dùng cùng |
