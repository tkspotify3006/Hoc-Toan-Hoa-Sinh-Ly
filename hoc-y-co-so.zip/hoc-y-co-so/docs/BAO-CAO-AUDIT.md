# Báo cáo audit toàn hệ thống — v0.3.0 (10/2026)

## 1. Nội dung
- 4 môn Năm 1: Sinh học (16 bài), Hóa vô cơ & hữu cơ (17), Vật lý – Lý sinh (10), Hóa sinh (22) — 65 bài, 190 hình SVG, 2.390 câu quiz.
- Mỗi bài qua 2 lượt: soạn theo giáo trình → rà soát độc lập đối chiếu từng trang sách.
- **Sinh học (sách 2008)**: thêm lượt cập nhật kiến thức hiện hành, có kiểm chứng nguồn (NIH/NHGRI, GENCODE, WHO, NOAA/WMO, UN WPP, FDA/EMA, HFEA, Thông tư 12/2026/TT-BYT…). Nhật ký từng thay đổi kèm nguồn: `docs/CAP-NHAT-SINH-HOC.md`.
- **Nhất quán toàn app**: thống nhất khoảng tham chiếu xét nghiệm (glucose, creatinin, acid uric, HDL, Ca, áp lực thẩm thấu…), số ATP, tỉ lệ nước cơ thể, thuật ngữ (glycat hóa; ADN = DNA…); bỏ các câu dễ lỗi thời theo thời gian; sửa ~25 tên bài trong câu dẫn chéo.
- **Khung YHCT**: 96 khung; chủ đề trùng (Cam thảo, colchicin, acid aristolochic, CaCO₃, Mã tiền…) giữ 1 khung đầy đủ, bài khác dẫn chéo. Danh sách để lương y duyệt: `docs/YHCT-CAN-DUYET.md` (101 điểm ⚠).

## 2. Quiz
- Trước audit: 55% câu có đáp án đúng là phương án dài nhất (đoán mẹo được). Sau audit: **15%** (ngẫu nhiên ≈ 25%); đáp án đúng cũng không bị lệch sang ngắn nhất.
- Không còn lời giải nhắc chữ cái phương án, không còn câu trùng đề. Mức độ: Nhớ 600 · Hiểu 1.149 · Vận dụng 641.
- Kiểm tra tự động: `python3 scripts/thong-ke-quiz.py`.

## 3. Ứng dụng
- Kiểm thử đầu-cuối bằng trình duyệt tự động trên 360 px và 1280 px, sáng/tối, cả dưới đường dẫn con như GitHub Pages: 65 bài hiển thị đúng; chấm đúng 100% của 2.390 câu; ôn tập ngắt quãng, tra cứu (1.566 liên kết mục), sao lưu/khôi phục, offline đều chạy.
- Sửa: phím Enter trong quiz, độ tương phản giao diện tối, nhãn cho trình đọc màn hình, tên file sao lưu theo giờ Việt Nam, cập nhật bản mới nhanh hơn + thông báo "Đã có bản cập nhật — Tải lại", tra cứu ưu tiên khớp trọn từ.
- Tải lần đầu ≈ 123 KB; dựng chỉ mục tra cứu ≈ 0,35 s.

## 4. Việc nên làm tiếp
1. Lương y duyệt `docs/YHCT-CAN-DUYET.md`.
2. Đối chiếu đề cương chi tiết học phần của Học viện (chương nào học/thi).
3. Sinh viên dùng thử trên điện thoại thật 1–2 tuần, ghi lại chỗ khó hiểu.
4. Audit lại trước mỗi năm học hoặc khi có giáo trình/đề cương mới.
