# Danh sách khung YHCT cần lương y duyệt

Cập nhật: 13/10/2026 (sau đợt rà soát nhất quán toàn app). Tổng số: **96 khung `> [!yhct]`** trong 63 bài.

Cách dùng tài liệu:

- Mỗi khung ghi: **tiêu đề** (dòng trong file `bai.md`), tóm tắt 1–2 dòng, và các điểm **⚠ cần thầy thuốc YHCT xác nhận** (công năng, chủ trị, cách chế, quy loại theo lý luận YHCT, tên vị – loài dùng ở Việt Nam). Phần cơ chế hóa sinh, dược lý đã được đối chiếu với tài liệu hiện hành.
- **KHUNG ĐẦY ĐỦ**: chủ đề lặp ở nhiều bài chỉ được trình bày đầy đủ ở một bài; các bài khác rút gọn 1–2 câu và dẫn chéo "(xem bài …, mã …)". Duyệt khung đầy đủ là đủ cho chủ đề đó.
- Nguyên tắc chung đã áp dụng: tách "cơ chế đã chứng minh" và "quan niệm YHCT"; ghi rõ mức bằng chứng (in vitro / động vật / lâm sàng); không ghi liều trừ khi trích Dược điển (DĐVN, DĐ Trung Quốc); ghi rõ vị có độc.
- Đường dẫn file: `content/nam-1/<môn>/<mã bài>/bai.md`, số dòng ghi trong ngoặc.

Chủ đề dùng chung (khung đầy đủ → bài rút gọn):

| Chủ đề | Khung đầy đủ | Bài chỉ nhắc ngắn / dẫn chéo |
|---|---|---|
| Colchicin, Ngót nghẻo, vinca, taxan | sh-05 | sh-01, sh-02, sh-03, sh-06, hc-10 |
| Saponin và màng | sh-02 | sh-04 |
| Glycosid tim | sh-04 | hc-08b |
| Mã tiền, strychnin | hc-11 | hs-21, hc-07 |
| Cam thảo, glycyrrhizin, giả cường aldosteron | hs-14 | hs-01, hs-05, hs-15, hs-16, hs-18, hs-20 |
| CaCO₃: Ô tặc cốt, Mẫu lệ, Ngõa lăng tử | vc-05 | hs-16, hs-22, sh-16 |
| Acid aristolochic | sh-10 | sh-07, sh-16, hs-18 |
| Berberin | hs-07 (đường huyết) | hc-10, hc-11, hs-05, hs-06, hs-13, hs-17, sh-08 (mỗi bài một khía cạnh riêng) |
| Hồng khúc | hs-08 | hs-05 |
| Thủy điệt, hirudin | hs-03 | hs-19, sh-16 |
| Soi bột, vi phẫu | vl-10 | sh-01 |
| Vị kỵ thai | sh-12 | sh-11 |
| Điện châm | vl-04 (tần số), vl-05 (điện cực, an toàn) | vl-01 |
| Ma hoàng | hc-01 | hc-10, hc-11 (chỉ nhắc cấu trúc) |

## Hóa vô cơ & hữu cơ

### vc-01 — Kim loại khối s (IA, IIA)

**Thạch cao sống và Thạch cao nung — cùng một chất, hai cách dùng** (dòng 455)

- Thạch cao sống (CaSO₄·2H₂O) uống, thanh nhiệt tả hỏa (quân dược Bạch hổ thang), sắc trước; Thạch cao nung dùng ngoài, thu thấp liễm sang; cơ chế hạ sốt chưa rõ.
- ⚠ Thành phần Bạch hổ thang và quy tắc "sống uống, nung dùng ngoài".

**Mang tiêu và Hoạt thạch — hai khoáng dược chứa Na, Mg** (dòng 462)

- Mang tiêu (Na₂SO₄·10H₂O) tả hạ thẩm thấu, hòa vào nước thuốc (Đại thừa khí thang), Huyền minh phấn là dạng khan; Hoạt thạch (talc) lợi thủy, dùng ngoài; cảnh báo talc lẫn amiăng.
- ⚠ Mang tiêu khi có thai: DĐ Trung Quốc ghi "thận trọng", nhiều sách ghi "kiêng" — chọn cách ghi.
- ⚠ Tỉ lệ Lục nhất tán (Hoạt thạch 6 : Cam thảo 1).

### vc-02 — Kim loại khối p (IIIA, IVA)

**Bạch phàn và Khô phàn — hóa học của vị "thu liễm"** (dòng 187)

- Bạch phàn/Khô phàn (phèn phi): nung vừa khô xốp, không quá lửa; Al³⁺ làm se, cầm máu; Xích thạch chi; phèn chủ yếu dùng ngoài, uống liều DĐ Trung Quốc 0,6–1,5 g/ngày.
- ⚠ Liều uống Bạch phàn theo DĐVN (khung đang trích DĐ Trung Quốc).

**Duyên đan, Mật đà tăng — vị thuốc chứa chì** (dòng 409)

- Duyên đan (Pb₃O₄), Mật đà tăng (PbO) — vị thuốc chứa chì, chỉ dùng ngoài (cao dán đen: xà phòng chì); cảnh báo ngộ độc chì, thuốc cam trẻ em.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### vc-03 — Kim loại khối d (chuyển tiếp)

**Chu sa (HgS) — vì sao "kỵ hỏa"?** (dòng 456)

- Chu sa (HgS) kỵ hỏa vì đun nóng giải phóng hơi Hg; chỉ chế thủy phi; tích lũy Hg ở thận, não; DĐ Trung Quốc cấm dùng cho người có thai, suy gan thận.
- ⚠ Liều và dạng dùng Chu sa theo DĐVN.

**Từ thạch (Fe₃O₄) và Lô cam thạch (ZnCO₃)** (dòng 462)

- Từ thạch (Fe₃O₄) trọng trấn an thần, chế nung tôi giấm, cơ chế chưa rõ; Lô cam thạch (ZnCO₃ → ZnO) chỉ dùng ngoài, có thể lẫn chì, cadimi.
- ⚠ Công năng Từ thạch (bình can tiềm dương, nạp khí bình suyễn).

### vc-04 — Các nguyên tố phi kim

**Lưu hoàng và xông diêm sinh dược liệu** (dòng 402)

- Lưu hoàng (S) chủ yếu dùng ngoài; xông diêm sinh tẩy trắng, chống mốc nhưng để lại dư lượng SO₂, biến đổi paeoniflorin; DĐ Trung Quốc giới hạn SO₂ ≤ 150/400 mg/kg.
- ⚠ Quy định giới hạn SO₂ của DĐVN (nếu có).

**Hùng hoàng (As₄S₄) — vì sao "kỵ hỏa"** (dòng 575)

- Hùng hoàng (As₄S₄) kỵ hỏa vì đun nóng tạo As₂O₃ (thạch tín); chỉ chế thủy phi; liều DĐ Trung Quốc 0,05–0,1 g/ngày dạng hoàn tán; cấm khi có thai; tích lũy arsen.
- ⚠ Tục rượu Hùng hoàng Đoan ngọ — cách diễn đạt cảnh báo.

### vc-05 — Hợp chất vô cơ: oxide, acid, base, muối

**Xếp khoáng dược vào bảng phân loại của bài này** (dòng 306)

- Bảng xếp khoáng dược (Bạch phàn, Mang tiêu, Thạch cao, CaCO₃, Lô cam thạch, Từ thạch, Duyên đan, Chu sa, Hùng hoàng) vào loại hợp chất, kèm mã bài và mục chi tiết.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

**Vị thuốc chứa CaCO₃ và nước vôi trong bào chế** (dòng 374)

- KHUNG ĐẦY ĐỦ về CaCO₃: Ô tặc cốt, Mẫu lệ, Ngõa lăng tử "chế toan chỉ thống" = trung hòa HCl; Bán hạ sống có độc, chế với Cam thảo + nước vôi (Pháp bán hạ) hoặc phèn, gừng.
- ⚠ Quy trình chế Pháp bán hạ, Thanh bán hạ, Khương bán hạ.

### hc-01 — Cấu trúc phân tử hợp chất hữu cơ — đồng phân

**Tinh dầu: đồng phân quyết định mùi và tác dụng** (dòng 266)

- α/β-pinen (tinh dầu thông) là đồng phân vị trí; menthol của Bạc hà (*Mentha arvensis*) có 3 C\*, cây tạo chủ yếu (−)-menthol; cảnh báo menthol đậm đặc gần mũi trẻ nhỏ.
- ⚠ Tên khoa học Bạc hà dùng ở VN là *M. arvensis* (DĐVN) — xác nhận.

**Ma hoàng: ephedrin và pseudoephedrin là đồng phân dia** (dòng 426)

- Ephedrin/pseudoephedrin của Ma hoàng là đồng phân dia; tác dụng giao cảm; cảnh báo tăng huyết áp, loạn nhịp, FDA cấm Ma hoàng trong TPCN 2004; chỉ dùng đúng chứng biểu thực vô hãn.
- ⚠ Công năng "phát hãn giải biểu, tuyên phế bình suyễn" và chống chỉ định (hư chứng, ra nhiều mồ hôi).

### hc-02 — Danh pháp hóa học hữu cơ

**Tinh dầu và tên hóa học của chúng** (dòng 341)

- Hoạt chất tinh dầu vị cay ấm thơm là monoterpen/phenylpropanoid; tinh dầu dễ bay hơi nên hậu hạ; Long não chỉ dùng ngoài, không uống (co giật ở trẻ).
- ⚠ Quy tắc "hậu hạ" cho các vị Quế, Đinh hương, Hồi, Sả, Bạc hà, Hương nhu.

### hc-03 — Hiệu ứng cấu trúc

**Alkaloid là base — cơ sở hóa học của "chế với giấm"** (dòng 292)

- Alkaloid là base yếu, tạo muối tan với acid — cách giải thích chế giấm Diên hồ sách (tetrahydropalmatin); bằng chứng tăng hiệu quả lâm sàng còn ít.
- ⚠ Mục đích chế giấm Diên hồ sách theo sách bào chế YHCT.

### hc-04 — Phản ứng của hợp chất hữu cơ

**Polyphenol, flavonoid của dược liệu — mạnh trong ống nghiệm, thận trọng khi suy rộng** (dòng 581)

- Polyphenol (chè xanh, Hoa hòe, Hoàng cầm, Đan sâm, Nghệ) bắt gốc tự do mạnh in vitro nhưng hấp thu kém; chưa đủ bằng chứng lâm sàng; chiết xuất EGCG liều cao gây hại gan.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

**Dầu, tinh dầu bị "ôi" cũng là phản ứng gốc tự do — hệ quả cho bảo quản** (dòng 586)

- Dầu béo, tinh dầu tự oxy hóa theo cơ chế gốc tự do (ôi, hydroperoxid gây dị ứng); vị nhiều dầu (Bá tử nhân, Đào nhân, Hạnh nhân) dễ "ra dầu"; bảo quản kín, tối, mát.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### hc-05 — Hydrocarbon

**Vaselin trong cao xoa và thuốc mỡ** (dòng 153)

- Cao xoa = menthol, camphor, tinh dầu trong vaselin + parafin; thuốc mỡ dùng vaselin thay mỡ lợn, dầu vừng; phân biệt "cao" dạng bôi và "cao" dịch chiết cô đặc.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

**Terpen trong tinh dầu dược liệu: Trần bì và Gấc** (dòng 360)

- Trần bì chứa limonen, hesperidin (lý khí kiện tỳ, táo thấp hóa đàm); để lâu giảm tinh dầu là giải thích hợp lý nhưng chưa chứng minh đủ; dầu Gấc giàu β-caroten, lycopen, dễ oxy hóa.
- ⚠ Lý luận "trần" (để lâu bớt tính táo, cay nóng) của Trần bì.

### hc-06 — Dẫn xuất halogen

**Hải tảo, Côn bố và bướu cổ — liên hệ có cơ sở với iod** (dòng 350)

- Hải tảo (*Sargassum*), Côn bố (*Laminaria*) giàu iod — cơ sở rõ cho bướu cổ do thiếu iod; thừa iod làm nặng cường giáp; Hải tảo phản Cam thảo.
- ⚠ Tên khoa học Côn bố (*Laminaria*/*Ecklonia*) và quy tắc thập bát phản.

### hc-07 — Alcol, phenol, ether

**Ethanol là dung môi chiết — "độ rượu" quyết định chiết được gì** (dòng 273)

- Độ cồn quyết định chiết chất phân cực hay kém phân cực; rượu thuốc 30–40 độ; tửu chế; cảnh báo rượu ngâm Ô đầu, Phụ tử sống, Mã tiền (aconitin, strychnin) gây chết người, rượu pha methanol.
- ⚠ Giải thích tác dụng "dẫn thuốc" của tửu chế (Đương quy, Đại hoàng).

**Phenol trong dược liệu: eugenol, thymol và tannin** (dòng 514)

- Eugenol (Đinh hương), thymol (Xạ hương) là phenol thật; ứng dụng nha khoa; tinh dầu Đinh hương nguyên chất gây bỏng niêm mạc, độc gan trẻ nhỏ; tannin tóm tắt, dẫn chéo hc-09.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### hc-08a — Aldehyd và ceton

**Aldehyd, ceton trong tinh dầu — đọc tính chất bào chế từ phản ứng** (dòng 486)

- Cinnamaldehyd (Quế), citral (Sả chanh) dễ bị oxy hóa; menthon → menthol; long não → borneol (Băng phiến = Borneolum); phân biệt với "băng phiến" naphthalen rất độc.
- ⚠ Vị Băng phiến dùng ở VN là borneol (tự nhiên hay tổng hợp).

### hc-08b — Glucid

**Glycosid — "chìa khóa" của hóa học dược liệu** (dòng 163)

- Các nhóm glycosid: saponin (Cam thảo, Nhân sâm, Tam thất), flavonoid (Hoa hòe), anthraglycosid (Đại hoàng, Phan tả diệp, Muồng trâu), glycosid tim (Trúc đào — rất độc), glycosid sinh cyanid (Khổ hạnh nhân — có độc nhỏ, Đào nhân, sắn); bào chế diệt enzym (Hoàng cầm chưng/đồ).
- ⚠ Cách chế Hoàng cầm (chưng/đồ, tránh ngâm nước lạnh).
- ⚠ Mức độc của Khổ hạnh nhân, Đào nhân theo DĐVN.

**Mạch nha, Giao di và tinh bột trong dược liệu** (dòng 237)

- Mạch nha chứa amylase (một phần cơ sở tiêu thực); Giao di (maltose) là vị chính của Tiểu kiến trung thang; polysaccharid Hoàng kỳ, Linh chi mới có bằng chứng thực nghiệm.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

**Mật ong trong bào chế hoàn mật** (dòng 259)

- Mật ong = fructose + glucose; luyện mật để bay nước, diệt enzym, tăng dính; viên hoàn mật dễ hút ẩm nếu luyện chưa đạt.
- ⚠ Tiêu chuẩn luyện mật (non/vừa/già) nếu muốn bổ sung.

### hc-09 — Acid carboxylic, ester, hợp chất tạp chức

**Dầu thực vật, sáp ong làm tá dược — vì sao bền, vì sao hỏng** (dòng 400)

- Dầu vừng, dầu lạc là glycerid làm tá dược; sáp ong (Hoàng lạp) là serid bền, dùng làm lạp hoàn, vỏ bọc viên hoàn; dầu hỏng do thủy phân và oxy hóa.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

**Acid hữu cơ và tannin trong dược liệu: Ô mai, Sơn tra, Ngũ bội tử** (dòng 553)

- Ô mai giàu acid citric, malic (vị chua — liễm phế, sáp trường, sinh tân); Sơn tra (VN: táo mèo *Docynia indica*/*Malus doumeri*); Ngũ bội tử giàu gallotannin; tannin kỵ sắt, tủa alkaloid.
- ⚠ Nguồn gốc loài Sơn tra dùng ở VN.
- ⚠ Công năng Ô mai, Sơn tra ghi trong khung.

### hc-10 — Amin, amid, amino acid

**Cao động vật (A giao, Lộc giác giao, cao xương): hóa học của collagen** (dòng 517)

- A giao, Lộc giác giao, cao xương: collagen thủy phân thành gelatin, peptid; tác dụng "bổ huyết, bổ thận" chủ yếu bằng chứng thực nghiệm; gelatin thiếu tryptophan.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

**Chiết alkaloid bằng acid và kiềm** (dòng 581)

- Chiết alkaloid bằng kiềm hóa – dung môi – acid; ngoại lệ berberin (amoni bậc IV, tan nước) và colchicin (N amid, gần như không base).
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### hc-11 — Hợp chất dị vòng

**Alkaloid dị vòng trong dược liệu: đọc tên nhân, hiểu tính chất** (dòng 300)

- Bảng alkaloid theo nhân dị vòng: berberin (Hoàng liên), rotundin (Bình vôi), quinin (Canh-ki-na), cafein, nicotin, strychnin (Mã tiền — rất độc), reserpin (Ba gạc); berberin hấp thu kém (ion bậc 4 + P-gp).
- ⚠ Bộ phận dùng: Hoàng liên (thân rễ), Bình vôi (củ), Ba gạc (rễ), Mã tiền (hạt).

**Mã tiền: vì sao bắt buộc phải chế biến** (dòng 316)

- KHUNG ĐẦY ĐỦ về Mã tiền (*Strychnos nux-vomica*): strychnin chặn thụ thể glycin, cực độc; quy trình chế (ngâm, cạo vỏ lông, bỏ mầm, sao cát hoặc tẩm dầu vừng sao); chế chỉ giảm một phần độc tính; đã chế vẫn là thuốc độc.
- ⚠ Quy trình chế Mã tiền theo DĐVN/sách bào chế hiện hành.
- ⚠ Chỉ định truyền thống (xoa bóp, phong thấp, tê bại).

## Hóa sinh

### hs-01 — Hóa học glucid

**Hoạt chất dạng glucuronid trong dược liệu** (dòng 120)

- Baicalin, glycyrrhizin là glucuronid; vi khuẩn ruột cắt đường giải phóng aglycon (acid glycyrrhetinic gây giả cường aldosteron); dẫn chéo hs-14, hc-08b.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### hs-02 — Hóa học lipid

**Phytosterol, ergosterol trong dược liệu — nói đúng mức** (dòng 198)

- Phytosterol cạnh tranh hấp thu cholesterol (2 g/ngày dạng bổ sung giảm LDL 8–10%) nhưng lượng trong thuốc sắc rất nhỏ; ergosterol của Linh chi, Phục linh chưa phải nguồn vitamin D.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### hs-03 — Hóa học acid amin, protein và hemoglobin

**Thủy điệt (con đỉa) và hirudin — một peptid chống đông** (dòng 213)

- KHUNG ĐẦY ĐỦ về Thủy điệt: hirudin (≈ 65 aa) ức chế trực tiếp thrombin — cơ chế đã chứng minh; vị thuốc đã chế giữ hoạt tính bao nhiêu chưa rõ; cấm khi có thai, chảy máu, đang dùng chống đông.
- ⚠ Xếp loại "phá huyết trục ứ" và cách chế Thủy điệt.

### hs-04 — Hóa học acid nucleic

**Đông trùng hạ thảo và cordycepin — một "nucleosid thiếu 3'-OH" từ tự nhiên** (dòng 318)

- Cordycepin (3'-deoxyadenosin) của Đông trùng hạ thảo/*C. militaris* ức chế tổng hợp RNA in vitro; chưa có bằng chứng lâm sàng; "bổ phế thận" là quan niệm YHCT; dùng làm chỉ tiêu kiểm nghiệm.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### hs-05 — Enzym

**Enzym trong dược liệu: vì sao Sinh mạch nha và Sao mạch nha khác nhau?** (dòng 450)

- Amylase của mạch nha bị bất hoạt khi sao và khi sắc; sinh mạch nha giữ enzym tốt nhất; công năng tiêu thực chưa chứng minh là do amylase.
- ⚠ Phân biệt công năng sinh mạch nha, sao mạch nha, tiêu mạch nha.

**Hoạt chất dược liệu ức chế enzym — ví dụ chính xác và mức bằng chứng** (dòng 574)

- Bảng: Hồng khúc (monacolin K = lovastatin), Tang diệp (1-DNJ), Thạch tùng răng cưa (huperzin A), Cam thảo (11β-HSD2), berberin (CYP) kèm mức bằng chứng; tách cơ chế hóa sinh và công năng YHCT.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### hs-06 — Năng lượng sinh học

**Chất ức chế chuỗi hô hấp có nguồn gốc cây cỏ** (dòng 249)

- Rotenon (Dây mật, *Derris*) ức chế phức hợp I, gây mô hình Parkinson trên động vật, không dùng uống; berberin ức chế nhẹ phức hợp I → AMPK (in vitro, động vật).
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

**Thương nhĩ tử (quả Ké đầu ngựa) và chất trao đổi ADP/ATP** (dòng 449)

- Carboxyatractylosid, atractylosid của Thương nhĩ tử ức chế chất trao đổi ADP/ATP; ngộ độc gây hạ đường huyết, tổn thương gan; vị có độc, phải chế và đúng liều.
- ⚠ Cách chế Thương nhĩ tử (sao, bỏ gai).

### hs-07 — Chuyển hóa glucid

**"Tiêu khát", berberin, Hoài sơn và người bệnh ĐTĐ** (dòng 554)

- KHUNG ĐẦY ĐỦ về berberin – đường huyết: giảm tân tạo glucose qua AMPK (thực nghiệm), thử nghiệm nhỏ giảm HbA1c khiêm tốn; tương tác CYP, hạ đường huyết khi phối hợp, tránh cho trẻ sơ sinh; Hoài sơn giàu tinh bột; hoàn mật có đường.
- ⚠ Đối chiếu chứng "tiêu khát" với ĐTĐ theo biện chứng YHCT.

### hs-08 — Chuyển hóa lipid và lipoprotein

**Hồng khúc và các vị thuốc "hạ mỡ máu" — đâu là bằng chứng?** (dòng 492)

- KHUNG ĐẦY ĐỦ về Hồng khúc: monacolin K giống hệt lovastatin, có thử nghiệm lâm sàng; tác dụng phụ statin, citrinin độc thận, EU giới hạn 2022; Sơn tra, Trạch tả chủ yếu bằng chứng động vật.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

**Hùng đởm (mật gấu) và acid ursodeoxycholic** (dòng 512)

- Acid ursodeoxycholic của mật gấu nay là thuốc tổng hợp (sỏi cholesterol nhỏ, PBC); pháp luật cấm khai thác mật gấu.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### hs-09 — Chuyển hóa acid amin

**Thuốc YHCT có thể gây tổn thương gan: theo dõi bằng ALT** (dòng 610)

- Hà thủ ô đỏ (*Reynoutria multiflora*) gây viêm gan do thuốc (ca bệnh, kể cả dạng chế); Thổ tam thất (*Gynura japonica*) chứa pyrrolizidin gây tắc xoang gan, dễ nhầm với Tam thất; theo dõi ALT.
- ⚠ Phương pháp chế Hà thủ ô và khuyến cáo theo dõi khi dùng dài ngày.

### hs-10 — Chuyển hóa hemoglobin

**Nhân trần, Chi tử trong chứng "hoàng đản"** (dòng 239)

- Nhân trần cao thang trị dương hoàng; scoparon, genipin lợi mật trên chuột; Nhân trần VN (*Adenosma*) khác *Artemisia capillaris*; Chi tử dài năm liên quan xơ hóa tĩnh mạch mạc treo.
- ⚠ Loài Nhân trần dùng ở VN (*A. caeruleum*) và thể bệnh hoàng đản.

### hs-11 — Chuyển hóa acid nucleic

**Chế độ ăn "kiêng" trong thống phong và các vị thuốc được nghiên cứu hạ acid uric** (dòng 133)

- Purin từ thịt, hải sản làm tăng gout, purin rau đậu thì không; flavonoid ức chế xanthin oxidase in vitro; Thổ phục linh, Ý dĩ hạ acid uric trên chuột; cảnh báo "thuốc nam" trộn corticoid.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### hs-12 — Sinh tổng hợp protein

**Ricin của hạt Thầu dầu và trichosanthin của Thiên hoa phấn — "protein bất hoạt ribosom"** (dòng 185)

- Ricin (Bì ma tử — có độc) cắt adenin của rRNA 28S; dầu thầu dầu không chứa ricin; trichosanthin của Thiên hoa phấn cùng cơ chế, phù hợp kiêng dùng khi có thai.
- ⚠ Mức kiêng Thiên hoa phấn khi có thai (cấm hay thận trọng).

### hs-13 — Hóa sinh màng tế bào

**Dược liệu và P-glycoprotein — tương tác qua "bơm đẩy thuốc"** (dòng 371)

- Ban Âu cảm ứng P-gp/CYP3A4 (lâm sàng rõ); piperin ức chế P-gp, CYP3A4 (bằng chứng hạn chế); berberin là cơ chất P-gp; hỏi thuốc tây đang dùng.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### hs-14 — Hóa sinh hormon

**Cam thảo và "giả cường aldosteron"** (dòng 543)

- KHUNG ĐẦY ĐỦ về Cam thảo: acid glycyrrhetinic ức chế 11β-HSD2 → giả cường aldosteron (tăng huyết áp, hạ K⁺); EU khuyến nghị glycyrrhizin ≤ 100 mg/ngày; Chích cam thảo vẫn có glycyrrhizin; thận trọng với lợi tiểu, digoxin.
- ⚠ Cách diễn đạt công năng "điều hòa các vị thuốc, bổ tỳ ích khí".

**Phytoestrogen — isoflavon đậu nành và Cát căn** (dòng 588)

- Isoflavon (đậu nành, Cát căn) gắn ER rất yếu; đậu nành giảm nhẹ bốc hỏa; Cát căn chủ yếu dữ liệu in vitro, động vật; phân biệt *Pueraria mirifica*; thận trọng ung thư phụ thuộc estrogen.
- ⚠ Loài Cát căn dùng ở VN và công năng giải cơ, thoái nhiệt, sinh tân.

### hs-15 — Trao đổi muối — nước

**Thuốc "lợi thủy thẩm thấp" và điện giải** (dòng 538)

- Nhóm lợi thủy thẩm thấp (Phục linh, Trư linh, Trạch tả, Ngũ linh tán) lợi niệu chủ yếu trên động vật, yếu hơn furosemid; Râu ngô giàu kali; nguy cơ rối loạn điện giải.
- ⚠ Thành phần Ngũ linh tán và khái niệm "thẩm thấp".

### hs-16 — Khí máu và thăng bằng acid — base

**Vị thuốc "chế toan" chứa CaCO₃ và kiềm chuyển hóa** (dòng 361)

- Dẫn chéo thành phần CaCO₃ (vc-05); riêng bài này: calci carbonat liều cao kéo dài có thể gây hội chứng sữa – kiềm (chưa có báo cáo riêng cho các vị thuốc).
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### hs-17 — Hóa sinh gan

**Thảo dược và cytochrom P450: tương tác có thật, mức bằng chứng khác nhau** (dòng 376)

- Ban Âu cảm ứng CYP3A4 (lâm sàng rõ, khác Cỏ ban VN *H. japonicum*); bưởi chùm, bưởi ta ức chế CYP3A4; pyrrolizidin cần CYP3A4 hoạt hóa; hỏi thuốc có khoảng điều trị hẹp.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### hs-18 — Hóa sinh thận và nước tiểu

**Thận, thuốc YHCT và an toàn** (dòng 294)

- Acid aristolochic tổn thương ống thận – mô kẽ (dẫn chéo sh-10); lợi niệu thảo dược (dẫn chéo hs-15); khế chua giàu oxalat gây bệnh thận cấp, caramboxin độc thần kinh ở người suy thận.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### hs-19 — Hóa sinh máu

**Thuốc hoạt huyết hóa ứ và thuốc chống đông** (dòng 504)

- Đan sâm (tương tác warfarin rõ nhất), Đương quy (ca bệnh ít), Xuyên khung, Tam thất (vừa cầm máu vừa chống ngưng tập); "huyết ứ" không đồng nhất với tăng đông; theo dõi INR, ngừng 2 tuần trước mổ.
- ⚠ Xếp Tam thất vào nhóm chỉ huyết ("cầm máu không gây ứ").

### hs-20 — Hóa sinh cơ

**Thược dược Cam thảo thang và chuột rút** (dòng 440)

- Thược dược Cam thảo thang (Bạch thược + Chích cam thảo) trị cước loan cấp; thử nghiệm nhỏ ở Nhật cho chuột rút; cam thảo liều cao gây hạ K⁺, tiêu cơ vân.
- ⚠ Lý luận "toan cam hóa âm, hoãn cấp chỉ thống".

### hs-21 — Hóa sinh thần kinh

**Mã tiền — strychnin chặn thụ thể glycin** (dòng 160)

- Rút gọn: strychnin chặn thụ thể glycin (cơ chế đã chứng minh); không còn dùng làm thuốc kích thích; dẫn chéo khung đầy đủ hc-11.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

**Dược liệu tác động lên synap cholinergic** (dòng 268)

- Cà độc dược (*Datura metel*, rất độc) chứa scopolamin, hyoscyamin chẹn muscarinic — hội chứng kháng cholinergic; Thạch tùng răng cưa (huperzin A) ức chế AChE, dẫn chéo hs-05.
- ⚠ Bộ phận dùng và liều dùng Cà độc dược (hoa, lá) trong YHCT.

### hs-22 — Hóa sinh các dịch sinh vật

**Thuốc "thông sữa" và "hồi sữa" — quan niệm và bằng chứng** (dòng 280)

- Thiếu sữa: thể khí huyết hư, can uất khí trệ; Vương bất lưu hành, Thông thảo, Lậu lô, móng giò; Mạch nha sao liều cao hồi sữa; bằng chứng chủ yếu kinh nghiệm; Xuyên sơn giáp bị cấm.
- ⚠ Biện chứng thiếu sữa và các vị thông nhũ, hồi sữa.

**Ô tặc cốt, Mẫu lệ — "chế toan"** (dòng 392)

- Rút gọn: CaCO₃ trung hòa acid đã tiết, không giảm tiết, không diệt *H. pylori*; dẫn chéo vc-05, hs-16.
- ⚠ Bài Ô bối tán (Ô tặc cốt + Bối mẫu).

## Sinh học

### sh-01 — Học thuyết tế bào. Các phương pháp nghiên cứu tế bào

**Kính hiển vi trong kiểm nghiệm dược liệu** (dòng 177)

- Rút gọn: soi bột, vi phẫu để xác định dược liệu; dẫn chéo khung đầy đủ vl-10.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

**Colchicin — alkaloid từ cây thuốc dùng trong nuôi cấy tế bào** (dòng 281)

- Rút gọn: colchicin giữ tế bào nuôi cấy ở kỳ giữa; Ngót nghẻo rất độc; dẫn chéo sh-05.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### sh-02 — Màng tế bào và tế bào chất

**Saponin và màng tế bào** (dòng 74)

- KHUNG ĐẦY ĐỦ về saponin: gắn cholesterol màng, làm tan hồng cầu (chỉ số phá huyết), không tiêm; uống ít hấp thu; lưu ý "phá huyết" dược liệu học ≠ "phá huyết" YHCT.
- ⚠ Cách phân biệt thuật ngữ "phá huyết".

**Alkaloid thực vật tác động lên ống vi thể** (dòng 632)

- Rút gọn: colchicin, vinca ức chế trùng hợp tubulin; paclitaxel làm ống vi thể quá bền; dẫn chéo sh-05.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### sh-03 — Nhân tế bào Eukaryota

**Colchicin — từ cây thuốc đến phòng xét nghiệm NST** (dòng 203)

- Rút gọn: colchicin/colcemid dùng làm NST đồ; Ngót nghẻo rất độc; dẫn chéo sh-05.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### sh-04 — Vận chuyển vật chất qua màng tế bào

**Saponin và tính thấm của màng** (dòng 90)

- Rút gọn: saponin tăng tính thấm màng, tan hồng cầu; dẫn chéo sh-02.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

**Glycosid tim trong dược liệu** (dòng 203)

- KHUNG ĐẦY ĐỦ về glycosid tim: Trúc đào (oleandrin), Thông thiên (thevetin), *Strophanthus*/Sừng dê (uabain), Thiềm tô (bufadienolid) — tất cả rất độc; ngộ độc cóc.
- ⚠ Tên Việt – tên khoa học: Sừng dê (*S. divaricatus*), Thông thiên (*Thevetia peruviana*).

### sh-05 — Phân chia tế bào và sự hình thành giao tử ở người

**Alkaloid từ cây tác động lên thoi vô sắc: colchicin, vinca, taxan** (dòng 325)

- KHUNG ĐẦY ĐỦ về colchicin (Ngót nghẻo *Gloriosa superba*, *Colchicum autumnale*): cơ chế tubulin, lập karyotype, gây đa bội, trị gút; độc tính, củ rất độc; vinblastin/vincristin (Dừa cạn), paclitaxel (Thông đỏ); không suy ra cho vị thuốc thô.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### sh-06 — Sự vận động của tế bào

**Cao động vật: một ví dụ sol – gel hai chiều quen thuộc** (dòng 50)

- Gelatin của A giao, Quy bản giao, Cao ban long là hệ sol – gel thuận nghịch; chỉ là liên hệ lý hóa; dẫn chéo hc-10.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

**Colchicin: alkaloid tác động lên ống vi thể** (dòng 200)

- Rút gọn: colchicin giảm di chuyển bạch cầu trung tính trong gút; dẫn chéo sh-05.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### sh-07 — Di truyền học: nội dung, phương pháp nghiên cứu

**Dược liệu cũng có thể tác động lên vật liệu di truyền** (dòng 152)

- Rút gọn: acid aristolochic là ví dụ dược liệu gây đột biến ADN; dẫn chéo sh-10.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### sh-08 — Các nguyên lý và quy luật cơ bản của sự di truyền

**Thiếu G6PD: thận trọng với một số dược liệu** (dòng 672)

- Thiếu G6PD: đậu tằm, naphthalen; berberin (Hoàng liên, Hoàng bá) đẩy bilirubin khỏi albumin (động vật) — tránh dùng cho trẻ sơ sinh; gây tan máu trực tiếp chưa chứng minh chắc.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### sh-09 — Cơ sở phân tử của hiện tượng di truyền

**Hoạt chất từ cây ức chế topoisomerase** (dòng 664)

- Camptothecin (Hỷ thụ) ức chế topoisomerase I → irinotecan, topotecan; podophyllotoxin (*Podophyllum*, Bát giác liên *Dysosma* — rất độc) → etoposid ức chế topoisomerase II.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### sh-10 — Đột biến

**Aflatoxin trong dược liệu bị mốc — vì sao phải bảo quản đúng** (dòng 485)

- Aflatoxin B₁ (*Aspergillus*) gây ung thư gan (IARC nhóm 1, đột biến *TP53* codon 249); dược liệu hạt, nhân dễ nhiễm; sắc không phá hủy được; không dùng dược liệu mốc.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

**Acid aristolochic — khi nhầm vị thuốc trở thành nhầm chất gây đột biến** (dòng 491)

- KHUNG ĐẦY ĐỦ về acid aristolochic (IARC nhóm 1, chữ ký A→T): vụ Quảng phòng kỷ ở Bỉ, Quan mộc thông; Trung Quốc loại bỏ các vị chứa AA; Tế tân chỉ dùng rễ, thân rễ; định danh đúng loài.
- ⚠ Danh sách vị trùng tên cần phân biệt: Phòng kỷ, Mộc thông, Mộc hương; tình trạng sử dụng ở VN.

### sh-11 — Quá trình phát triển cá thể

**Liên hệ: thuốc "kỵ thai" trong Dược học cổ truyền** (dòng 216)

- Rút gọn: nhóm cấm dùng và thận trọng khi có thai; dẫn chéo sh-12.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

**"Thận khí" và các mốc đời người trong Nội kinh** (dòng 468)

- Chu kỳ 7 năm (nữ), 8 năm (nam) của thận khí, thiên quý (Tố vấn, Thượng cổ thiên chân luận) tương ứng dậy thì – mãn kinh; là mô hình mô tả, không phải cơ chế sinh học.
- ⚠ Trích dẫn các mốc tuổi trong Thượng cổ thiên chân luận.

### sh-12 — Cơ chế điều khiển phát triển phôi và các nhân tố ảnh hưởng

**Vị thuốc "kỵ thai" (thai kỵ) theo Dược học cổ truyền** (dòng 334)

- KHUNG ĐẦY ĐỦ về thai kỵ: bảng cấm dùng (Xạ hương, Ba đậu, trục thủy, phá huyết, Ban miêu, Hùng hoàng, Thạch tín) và thận trọng (hoạt huyết, hành khí phá trệ, công hạ, tân nhiệt, hoạt lợi); bằng chứng dị tật chưa đủ.
- ⚠ Xếp mức cấm/thận trọng của từng vị (Hồng hoa, Phụ tử, Ngưu tất…) theo DĐVN.

### sh-13 — Một số vấn đề về sinh quyển

**Cây thuốc trong lưới thức ăn: bảo tồn nguồn dược liệu tự nhiên** (dòng 311)

- Cây thuốc bị khai thác cạn (Sâm Ngọc Linh, Hoàng liên chân gà, Bảy lá một hoa — Sách Đỏ); trồng theo GACP; cây họ Đậu (Cam thảo, Hoàng kỳ, Cát căn) có nốt sần cố định đạm.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### sh-14 — Loài người và môi trường ngoại cảnh

**Lục dâm: quan niệm truyền thống của YHCT về tác động của thời tiết** (dòng 36)

- Lục khí → lục dâm (phong, hàn, thử, thấp, táo, hỏa) khi thái quá, bất cập, trái thời; là hệ quan điểm bệnh nguyên, không phải mô hình sinh lý.
- ⚠ Định nghĩa lục khí/lục dâm.

**"Thiên nhân hợp nhất" (quan niệm truyền thống): con người tương ứng với trời đất** (dòng 287)

- "Thiên nhân tương ứng": sinh lý thay đổi theo ngày đêm, bốn mùa; tương đồng về hướng với nhịp sinh học; tý ngọ lưu chú chưa được chứng minh.
- ⚠ Cách diễn đạt "xuân hạ dưỡng dương, thu đông dưỡng âm".

### sh-16 — Tiến hóa của hệ thống sinh giới

**Tên khoa học giúp tránh nhầm dược liệu** (dòng 142)

- Tên Việt/Hán trùng nhau (Phòng kỷ: *Stephania* hay *Aristolochia*), nên dược điển ghi tên La tinh; dẫn chéo sh-10.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

**Động vật làm thuốc — xếp theo ngành** (dòng 399)

- Động vật làm thuốc theo ngành: Thân mềm (Mẫu lệ, Thạch quyết minh, Ô tặc cốt — CaCO₃), Giun đốt (Địa long, Thủy điệt — hirudin, dẫn chéo hs-03), Tiết túc (Toàn yết, Ngô công — có độc, Thuyền thoái).
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

## Vật lý — Lý sinh

### vl-01 — Đơn vị đo lường. Một số quy luật cơ bản

**Điện châm và ngưỡng cảm giác** (dòng 456)

- Điện châm phải vượt ngưỡng cảm giác, dưới ngưỡng đau; thích nghi nên phải chỉnh cường độ; "đắc khí" là khái niệm YHCT.
- ⚠ Mô tả cảm giác đắc khí.

### vl-02 — Sự biến đổi năng lượng ở cơ thể sống

**Cứu ngải và chườm nóng/lạnh — phần nào là vật lý?** (dòng 544)

- Cứu ngải truyền nhiệt bằng bức xạ hồng ngoại, dẫn nhiệt → giãn mạch tại chỗ; "ôn thông kinh lạc" là quan niệm YHCT; bằng chứng lâm sàng hạn chế; chườm nóng/lạnh.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### vl-03 — Chuyển động trong cơ thể sống (vận chuyển chất, máu, khí)

**Ngâm và sắc thuốc: mao dẫn và khuếch tán** (dòng 440)

- Ngâm, sắc thuốc: mao dẫn, trương nở, khuếch tán (Fick); thái mỏng, sắc nhiều lần tăng chiết; sắc nhanh vị tinh dầu vì dễ bay hơi; không giải thích tác dụng.
- ⚠ Kinh nghiệm sắc lâu vị bổ, sắc nhanh vị giải biểu.

**Giác hơi — áp suất âm** (dòng 923)

- Giác hơi tạo áp suất âm (pV/T), gây xung huyết tại chỗ; "hành khí hoạt huyết" là quan niệm; giảm đau ngắn hạn, chất lượng nghiên cứu hạn chế; chống chỉ định rối loạn đông máu.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### vl-04 — Dao động và sóng — âm và siêu âm

**Điện châm và "tần số" của dòng xung** (dòng 332)

- Điện châm 2 Hz ↔ enkephalin, β-endorphin; 100 Hz ↔ dynorphin (chủ yếu nhóm Han Jisheng, động vật); gán tần số với bổ/tả là quan niệm YHCT.
- ⚠ Quy ước sóng/tần số với phép bổ – tả trên máy điện châm VN.

**Siêu âm hỗ trợ chiết xuất dược liệu** (dòng 716)

- Chiết xuất hỗ trợ siêu âm (20–40 kHz) nhờ cavitation; rút ngắn thời gian, giảm dung môi; dịch chiết có thể khác thang sắc.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### vl-05 — Điện và sự sống

**Điện châm — kim châm làm điện cực** (dòng 579)

- Kim châm làm điện cực; xung hai pha tránh điện phân; không cho dòng qua tim, thận trọng người mang máy tạo nhịp; dẫn chéo vl-04.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

**Máy dò huyệt — đo điện trở da** (dòng 638)

- Máy dò huyệt đo điện trở da; giả thuyết điện trở huyệt thấp còn tranh cãi, phụ thuộc lực ấn, mồ hôi; chỉ là công cụ hỗ trợ.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### vl-07 — Bản chất của ánh sáng — laser

**Laser châm — đâu là vật lý, đâu là quan niệm** (dòng 500)

- Laser châm công suất thấp (He-Ne 632,8 nm, hồng ngoại gần); photobiomodulation là giả thuyết; bằng chứng lâm sàng không nhất quán; huyệt, kinh lạc chưa có cấu trúc vật lý tương ứng.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### vl-08 — Tác dụng của ánh sáng lên cơ thể sống

**Dược liệu chứa furocoumarin — gây nhạy cảm ánh sáng** (dòng 322)

- Furocoumarin (Bạch chỉ, Bổ cốt chỉ, Độc hoạt, Xà sàng tử, vỏ chanh bưởi) gây viêm da quang độc với UVA; PUVA trị bạch biến, vảy nến; tránh nắng khi dùng liều cao.
- ⚠ Công năng Bạch chỉ, Bổ cốt chỉ; dân gian bôi Bổ cốt chỉ trị bạch biến.

**Phơi dược liệu: UV và nhiệt tác động lên hoạt chất** (dòng 390)

- Phơi nắng = nhiệt + UV phá liên kết đôi liên hợp (sắc tố, tinh dầu); vị giàu tinh dầu và hoa phơi âm can hoặc sấy thấp; rễ, thân gỗ phơi nắng được.
- ⚠ Danh sách vị cần phơi âm can (Bạc hà, Kinh giới, Tía tô, Hương nhu, Kim ngân hoa).

### vl-09 — Bức xạ ion hóa và cơ thể sống

**Chiếu xạ khử khuẩn dược liệu và "chất chống phóng xạ" từ thực vật** (dòng 500)

- Chiếu xạ γ (⁶⁰Co) khử khuẩn dược liệu không làm dược liệu phóng xạ nhưng có thể biến đổi hoạt chất; "chất chống phóng xạ" thực vật chủ yếu bằng chứng thực nghiệm.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

### vl-10 — Ứng dụng vật lý kỹ thuật trong y học (hiển vi, quang phổ, X-quang, MRI, phóng xạ)

**Soi bột và vi phẫu — kiểm nghiệm dược liệu bằng kính hiển vi** (dòng 221)

- KHUNG ĐẦY ĐỦ về soi bột, vi phẫu: đặc điểm mảnh, thước trắc vi, kính phân cực (calci oxalat, tinh bột lưỡng chiết), huỳnh quang UV 365 nm; chỉ định danh, không định lượng.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

**Định lượng hoạt chất dược liệu bằng quang phổ và sắc ký** (dòng 382)

- Đo quang UV-Vis định lượng nhóm chất (flavonoid toàn phần, polyphenol toàn phần), HPLC định lượng chất chỉ điểm; hàm lượng cao không đồng nghĩa tác dụng mạnh.
- ⚠ Không có điểm lý luận YHCT riêng cần xác nhận (nội dung thuần dược lý/hóa – lý).

