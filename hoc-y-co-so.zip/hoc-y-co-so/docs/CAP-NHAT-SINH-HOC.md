# Nhật ký cập nhật kiến thức — môn Sinh học

Ghi lại các chỗ đã sửa/cập nhật/bổ sung so với giáo trình Sinh học (Bộ Y tế 2008), kèm nguồn kiểm chứng.

# Nhật ký cập nhật sh-01 — Học thuyết tế bào, phương pháp nghiên cứu tế bào (2026-10-13)

Rà soát toàn bộ bai.md, quiz.json (33 câu cũ), 3 SVG: không phát hiện khẳng định sai mà chưa có khung cập nhật; các khung [!cap-nhat] cũ (Hooke/kính phức, TEM–cryo-EM–STM–SEM, siêu phân giải) đều đúng.

- [cập nhật] Khung "Ai phát minh kính hiển vi": thêm *omnis cellula e cellula* và vai trò của Robert Remak trước Virchow (1855) — Alberts MBoC 7th; lịch sử học thuyết tế bào.
- [cập nhật] Khung hiển vi hiện đại: ghi tên người nhận Nobel Hóa học 2014 (Betzig, Hell, Moerner); MINFLUX tới vài nm; GFP (Nobel Hóa học 2008); cryo-EM đạt ≈ 1,2 Å; cryo-ET chụp trong tế bào (đã đông lạnh) — nobelprize.org (2008, 2014, 2017); Nakane/Yip, Nature 2020.
- [bổ sung] Kính đối pha — Zernike, Nobel Vật lý 1953; kính đồng tiêu (confocal); đèn thủy ngân nay thay bằng LED/laser — nobelprize.org 1953.
- [bổ sung] Đánh dấu không phóng xạ BrdU/EdU thay ^3^H-thymidin — sách phương pháp tế bào học hiện hành.
- [bổ sung] Chẩn đoán trước sinh hiện nay: NIPT (ADN tự do, từ ≈ tuần 10, chỉ là sàng lọc), sinh thiết gai nhau tuần 10–13, QF-PCR/FISH/CMA; iPSC (Nobel Y học 2012), organoid — ACOG Practice Bulletin 226 (2020); nobelprize.org 2012.
- [bổ sung] Phương pháp hiện đại: flow cytometry (đếm CD4), NGS, single-cell RNA-seq, CRISPR-Cas9 (Nobel Hóa học 2020) — nobelprize.org 2020.
- [quiz] Thêm q34 (siêu phân giải – Nobel 2014), q35 (cryo-EM, GFP, BrdU/EdU), q36 (NIPT là sàng lọc, cần khẳng định) — đều ghi "(kiến thức hiện nay)".
- [quiz] Rà 33 câu cũ: đáp án đúng theo giáo trình, không nhắc chữ cái phương án.

# Nhật ký cập nhật sh-02 — Màng tế bào và tế bào chất (2026-10-13)

Rà soát toàn bộ bai.md (661 dòng), quiz.json (40 câu), 3 SVG. Các khung [!cap-nhat] cũ (ba lớp màng, band 3 ≈ 14 đoạn xuyên màng, rARN là ribozym, protein gấp nếp ở RER, peroxysom/uricase, lục lạp, 30–32 ATP, hệ gen ty thể 37 gen/13 protein/UGA = Trp, ty thể tinh trùng, trung thể, tubulin–GTP) đã kiểm tra: đúng. MitoCarta3.0 (1.136 gen) khớp con số "1000–1500 loại protein ty thể" của khung cũ.

- [bổ sung] Mô hình màng hiện nay: bè lipid (Simons & Ikonen 1997; định nghĩa Keystone 2006: 10–200 nm), caveolae, protein bị "rào" bởi khung actin, cholesterol là chất đệm tính lỏng — Pike, J Lipid Res 2006 (https://doaj.org/article/da14f5e7c55541d2900fca574c8e6811); Alberts MBoC 7th.
- [cập nhật] Kênh/chất mang hầu hết là protein xuyên màng nhiều lần; protein xuyên 1 lần thường là receptor (giáo trình ghi kênh xuyên 1 lần dẫn phân tử lớn) — Alberts MBoC 7th.
- [cập nhật] Fibronectin là glycoprotein chất nền ngoại bào, bám màng qua integrin — Alberts MBoC 7th.
- [cập nhật] Ribosom người ≈ 80 protein (≈ 33 + ≈ 47; giáo trình 33 + 49), rARN 28S ≈ 5000 nu; Nobel Hóa học 2009 (Ramakrishnan, Steitz, Yonath) — BioNumbers ID 102478 (https://bionumbers.hms.harvard.edu/bionumber.aspx?id=102478); Anger et al., Nature 2013.
- [bổ sung] Giả thuyết tín hiệu: SRP – receptor SRP – translocon Sec61 – peptidase tín hiệu (Blobel, Nobel Y học 1999); chuỗi peptid không tự luồn qua lipid — nobelprize.org 1999.
- [bổ sung] ERAD/proteasom và UPR khi protein gấp sai — Alberts MBoC 7th.
- [bổ sung] Túi COPII/COPI/clathrin, SNARE (Nobel Y học 2013: Rothman, Schekman, Südhof) — nobelprize.org 2013.
- [bổ sung] Tự thực bào (Ohsumi, Nobel Y học 2016; gen ATG; mitophagy; bệnh thoái hóa thần kinh), tiêu thể – mTORC1 — nobelprize.org 2016.
- [bổ sung] Bệnh tiêu thể: ≈ 70 bệnh, gộp ≈ 1/5.000–1/8.000; ERT, giảm cơ chất (miglustat), liệu pháp gen — StatPearls NBK563270 (https://www.ncbi.nlm.nih.gov/books/NBK563270/).
- [bổ sung] Peroxysom: gen PEX (Zellweger), X-ALD do hỏng ABCD1 — Thompson & Thompson 9th.
- [bổ sung] Bệnh ty thể: heteroplasmy/ngưỡng; đột biến gen nhân (MitoCarta3.0 1.136 gen — https://www.broadinstitute.org/mitocarta); liệu pháp thay ty thể: luật Anh 2015, 8 trẻ công bố 7/2025 (NEJM), một số còn ADN đột biến mức thấp; Úc – Maeve's Law 2022; cytochrom c – apoptosis — HFEA 16/7/2025 (https://www.hfea.gov.uk/about-us/news-and-press-releases/2025/hfea-comments-on-the-news-that-eight-babies-have-been-born-after-mitochondrial-donation-treatment); EMJ 24/7/2025 (https://www.emjreviews.com/reproductive-health/news/eight-babies-born-after-mitochondrial-donation-in-groundbreaking-ivf-procedure/).
- [bổ sung] Protein vận động kinesin (+)/dynein (−)/myozin; hội chứng Kartagener, ciliopathy (thận đa nang) — Alberts MBoC 7th.
- [bổ sung] Progeria: progerin còn farnesyl; lonafarnib FDA 20/11/2020 — Drugs.com approval history (https://www.drugs.com/history/zokinvy.html).
- [sửa sai] Không có khẳng định sai mới ngoài các điểm đã có khung; sửa cách viết một đoạn để tránh lỗi hiển thị chữ nghiêng.
- [quiz] Thêm q41 (autophagy – Nobel 2016), q42 (bè lipid, protein bị rào, SRP–Sec61, protein xuyên nhiều lần), q43 (liệu pháp thay ty thể), q44 (kinesin/dynein). Rà 40 câu cũ: đáp án theo giáo trình, không có câu lỗi thời cần sửa.

# Nhật ký cập nhật sh-03 — Nhân tế bào, nhiễm sắc thể (2026-10-13)

Rà soát bai.md, quiz.json (35 câu), 3 SVG. Các khung cũ (hủy xương từ dòng mono bào – đại thực bào; lamin ≠ laminin; topoisomerase II/condensin; sợi 30 nm; NOR = Nucleolus Organizer Region) đúng.

- [bổ sung] Progeria: đột biến c.1824C>T ở LMNA → progerin (giữ farnesyl); lonafarnib FDA 20/11/2020 — https://www.drugs.com/history/zokinvy.html.
- [bổ sung] Lỗ màng nhân hiện nay: > 100 MDa, ≈ 30 loại nucleoporin, đối xứng bậc 8; cấu trúc gần toàn bộ 2022 (cryo-ET + AlphaFold); hàng rào FG, < ≈ 40 kDa khuếch tán, importin/exportin, NLS, Ran-GTP — Alberts MBoC 7th; Mosalaganti et al./Fontana et al., Science 2022.
- [cập nhật] Khung sợi 30 nm: ChromEMT (Ou et al., Science 28/7/2017) — chromatin 5–24 nm gấp khúc trong nhân và NST kỳ giữa; 30 nm thấy ở nhân hồng cầu gà tách chiết; ghi rõ "còn tranh luận" — LabMedica 9/8/2017 (https://labmedica.com/bioresearch/articles/294770352/imaging-technique-reveals-3d-structure-of-dna-and-chromatin.html).
- [bổ sung] Tổ chức 3 chiều: lãnh thổ NST, ngăn A/B, TAD (Hi-C 2009; Dixon 2012), cohesin đùn vòng – CTCF; phá ranh giới TAD gây dị tật chi (Lupiáñez, Cell 2015) — Alberts MBoC 7th.
- [bổ sung] Nucleosom 146–147 bp, ≈ 1,65 vòng, ADN nối ≈ 10–80 bp; biến đổi histon, methyl hóa ADN (biểu sinh), CENP-A — https://en.wikipedia.org/wiki/Nucleosome (tổng hợp từ Luger 1997, Davey 2002); Alberts MBoC 7th.
- [cập nhật] Danh pháp HMG1/2 → HMGB1/2, HMG14/17 → HMGN1/2; HMGB1 là DAMP; HMGB chủ yếu ở nhân (giáo trình ghi ở tế bào chất) — HGNC.
- [bổ sung] Telomere TTAGGG (≈ 5–15 kb), shelterin, giới hạn Hayflick; telomerase bật lại ở ≈ 85% ung thư, ALT; Nobel Y học 2009 (Blackburn, Greider, Szostak); bệnh telomere — Cell Mol Life Sci 2016 (https://link.springer.com/article/10.1007/s00018-016-2146-9); nobelprize.org 2009.
- [bổ sung] Bộ gen: T2T-CHM13 (Science, 31/3/2022) ≈ 3,05 Gb, lấp ≈ 8% còn thiếu (chủ yếu ADN lặp ở phần tâm, nhánh p NST tâm đầu); ≈ 19.000–20.000 gen mã hóa protein (GENCODE 41: 19.370), < 2% bộ gen; E. coli K-12 ≈ 4,6 Mb — Nurk et al., Science 2022; Amaral et al. 2023 "The status of the human gene catalogue" (https://arxiv.org/abs/2303.13996).
- [cập nhật] Hạch nhân tan rã từ cuối kỳ đầu (giáo trình: kỳ giữa); FC/DFC/GC; tách pha lỏng – lỏng — Alberts MBoC 7th; Feric et al., Cell 2016.
- [sửa hình] cac-muc-xoan.svg: thêm chú thích nhỏ dưới mục ③ "mô hình kinh điển, nay còn tranh luận" (đã render kiểm tra, không đè chữ).
- [quiz] Thêm q36 (telomerase), q37 (30 nm/TAD/CTCF/acetyl hóa/lãnh thổ NST), q38 (T2T, số gen), q39 (NLS–importin–Ran). Rà 35 câu cũ: không cần sửa.

# Nhật ký cập nhật sh-04 — Vận chuyển qua màng (2026-10-13)

Rà soát bai.md, quiz.json (35 câu), 3 SVG. Các khung cũ (kênh/chất mang, GLUT1, AE1; SGLT – vận chuyển chủ động thứ phát; Ca^2+^ ra qua thụ thể ryanodin) đúng.

- [cập nhật] Band3/AE1 người dài 911 acid amin (giáo trình ≈ 930) — UniProt P02730.
- [bổ sung] Kênh ion: chọn lọc, cổng điện thế/chất gắn/cơ học (Piezo – Nobel Y học 2021); patch clamp (Neher & Sakmann, Nobel Y học 1991); Nobel Hóa học 2003 (Agre – aquaporin; MacKinnon – kênh K^+^); aquaporin-2 – ADH – đái tháo nhạt do thận — nobelprize.org 1991, 2003, 2021.
- [bổ sung] Họ SLC (> 400 gen, 66 họ) và ABC (48 gen, 7 phân họ); P-gp/ABCB1 kháng đa thuốc; ABCG2 – acid uric – gút — HGNC blog 31/3/2023 (https://blog.genenames.org/hgnc/2023/3/31/Solute_Carriers); ABC 48 gen/7 phân họ (https://authorea.com/doi/full/10.22541/au.164001179.92800452/v1).
- [bổ sung] Xơ nang: F508del gấp sai bị ER giữ lại; hiếm ở người châu Á — Thompson & Thompson 9th.
- [bổ sung] CFTR thuộc họ ABC (ABCC7); corrector/potentiator; Trikafta FDA 21/10/2019 (≥ 12 tuổi), mở rộng ≥ 2 tuổi; Alyftrek (vanzacaftor/tezacaftor/deutivacaftor) FDA 12/2024; mở rộng nhãn 1/4/2026 cho mọi biến thể tạo protein CFTR (≈ 95% người bệnh ở Hoa Kỳ) — HCPLive 1/4/2026 (https://www.hcplive.com/view/fda-expands-cftr-modulator-labels-covering-95-of-us-cystic-fibrosis-patients); Healio 23/12/2024 (https://cm.healio.com/news/pulmonology/20241223/fda-approves-alyftrek-for-cystic-fibrosis-treatment).
- [bổ sung] Bơm Na^+^-K^+^: Jens Skou phát hiện 1957, Nobel Hóa học 1997; ATPase type P (phosphoryl hóa tạm thời) — nobelprize.org 1997.
- [bổ sung] PCSK9 và thuốc ức chế (evolocumab, alirocumab, inclisiran) — Alberts MBoC 7th; nhãn thuốc FDA.
- [bổ sung] Dynamin, caveolae, macropinocytosis; virus mượn nhập bào — Alberts MBoC 7th.
- [bổ sung] SNARE và Nobel Y học 2013 trong khung độc tố botulinum — nobelprize.org 2013.
- [bổ sung] Bảng thuốc: thêm hàng ức chế PCSK9 và điều biến CFTR (ghi "bổ sung").
- [quiz] Sửa lời giải q01, q02, q28 (đang nhắc chữ cái phương án B, D, A, E — vi phạm quy ước vì đáp án xáo trộn); q35 đổi nhãn đề thành "(kiến thức hiện nay)".
- [quiz] Thêm q36 (Nobel 2003 aquaporin/kênh K^+^), q37 (cơ chế elexacaftor/tezacaftor/ivacaftor), q38 (SLC/ABC/aquaporin-2/kênh chọn lọc), q39 (PCSK9).

# sh-05 – Phân chia tế bào, tạo giao tử – nhật ký cập nhật (2026-10-13)

- [cập nhật] Mở rộng khung điểm kiểm soát: cyclin–CDK (Nobel 2001 Hartwell, Hunt, Nurse), Rb là "phanh" G1, trục p53→p21 ức chế CDK, 3 checkpoint — Nobel Prize 2001; Alberts MBoC 7th
- [bổ sung] Thuốc ức chế CDK4/6: palbociclib (FDA 02/2015), ribociclib (03/2017), abemaciclib (09/2017) cho ung thư vú HR+/HER2− — AACR, https://www.aacr.org/patients-caregivers/progress-against-cancer/molecularly-targeted-therapeutic-breast-cancer-abemaciclib-verzenio/
- [cập nhật] Down theo tuổi mẹ: thêm số liệu nguy cơ khi sinh 1/1.250 (25t), 1/400 (35t), 1/100 (40t), 1/30 (45t) — GLOWM, https://glowm.com (bảng nguy cơ theo tuổi mẹ)
- [sửa sai] "Sàng lọc được khuyến cáo cho mọi thai phụ (… chọc ối)" → sàng lọc (double test, NIPT) nên được tư vấn cho mọi thai phụ; nguy cơ cao phải chẩn đoán xác định bằng chọc ối/sinh thiết gai nhau (bỏ chọc ối khỏi danh sách "sàng lọc") — ACOG/thực hành hiện hành
- [bổ sung] Khung cohesin: cohesin nạp từ thời bào thai, hao dần khi noãn chờ ở kỳ đầu I → lệch bội theo tuổi mẹ — "Age-related loss of cohesion: causes and effects", PMC5536066 (2017)
- [bổ sung] Khung vốn noãn: noãn bào I xuất hiện từ ≈ tháng 3, đỉnh 6–7 triệu tế bào mầm ở tháng 5, 1–2 triệu lúc sinh, 300.000–400.000 lúc dậy thì, ≈ 400–500 noãn rụng cả đời — Langman's Medical Embryology; pathologystudent.com/female-germ-cells
- [bổ sung] Apoptosis: Li-Fraumeni (TP53), họ BCL-2 (BCL-2/BAX/BAK), venetoclax (FDA 2016, CLL), Nobel 2002 (Brenner, Horvitz, Sulston) — Nobel Prize 2002; FDA 2016
- [kiểm tra] Các khung [!cap-nhat] cũ (bán bảo toàn/Meselson–Stahl 1958; PAR1 luôn có ≥1 trao đổi chéo; caspase, 2 đường apoptosis, phosphatidylserin, p53 ≈ 50% ung thư) — đúng, giữ nguyên
- [kiểm tra] Hình chu-ky-te-bao.svg, giao-tu.svg, nst-adn.svg — nhãn đúng, không sửa
- [quiz] Thêm q36 (cyclin–CDK), q37 (thuốc ức chế CDK4/6), q38 (cohesin & tuổi mẹ), q39 (tf: p53–p21, venetoclax, NIPT là sàng lọc, vốn noãn lúc sinh); câu cũ không có đáp án lỗi thời

# sh-06 – Vận động tế bào – nhật ký cập nhật (2026-10-13)

- [cập nhật] PCD: chủ yếu lặn NST thường, ≈ 1/7.500 người, >50 gen, hay gặp DNAH5/DNAH11 — MedlinePlus Genetics, https://medlineplus.gov/genetics/condition/primary-ciliary-dyskinesia
- [sửa sai] "Khoảng một nửa bệnh nhân PCD bị đảo ngược phủ tạng" → "khoảng 40–50%" — MedlinePlus Genetics (≈ 40%)
- [bổ sung] Khung lông nguyên phát (9 + 0, không vận động, "ăng-ten" tín hiệu/Hedgehog) và ciliopathy (thận đa nang trội – polycystin, Bardet–Biedl, Joubert, tế bào que/nón); chẩn đoán PCD (NO mũi, video tần số đập, TEM, gen) — Alberts MBoC 7th (2022); MedlinePlus
- [bổ sung] Khung protein vận động kinesin/dynein bào tương/myozin, vận chuyển dọc sợi trục — Alberts MBoC 7th (2022)
- [bổ sung] Bệnh cơ tim phì đại (≈ 1/500; MYH7, MYBPC3) và mavacamten (ức chế myozin tim, FDA 2022) — FDA 04/2022; Thompson & Thompson 9th
- [kiểm tra] Các khung [!cap-nhat] cũ (chân giả: actin/integrin/myozin II; roi vi khuẩn flagellin, động cơ chạy bằng dòng H^+^; CAM: cadherin, integrin, selectin, Ig; LAD) — đúng, giữ nguyên
- [kiểm tra] Hình chan-gia.svg, long-roi-9-2.svg, troponin-tropomyozin.svg — nhãn đúng
- [quiz] Thêm q33 (lông nguyên phát 9 + 0), q34 (multi: ciliopathy), q35 (tf: PCD >50 gen, kinesin, 40–50% đảo phủ tạng, mavacamten)

# sh-07 – Di truyền học: nội dung, phương pháp – nhật ký cập nhật (2026-10-13)

- [bổ sung] Watson–Crick 1953 dựa vào ảnh nhiễu xạ của Rosalind Franklin; Nobel 1962 (Watson, Crick, Wilkins); phiên mã ngược: Temin và Baltimore độc lập 1970 (Nobel 1975) — Nobel Prize
- [cập nhật] Khung bản đồ gen: NST Y hoàn chỉnh 62.460.029 bp, Nature 23/8/2023, thêm >30 Mb — NIST/Rhie et al. 2023, https://www.nist.gov/publications/complete-sequence-human-y-chromosome
- [bổ sung] Pangenome người: bản nháp 47 người, Nature 10–11/5/2023, thêm >100 triệu base — Liao et al. 2023; https://www.sci.news/genetics/human-pangenome-11908.html
- [cập nhật] CRISPR: cơ chế ARN dẫn đường + Cas9; Nobel Hóa học 2020 (Charpentier, Doudna); Casgevy: MHRA 11/2023, FDA 8/12/2023 (SCD), 16/1/2024 (TDT); cơ chế chỉnh enhancer BCL11A → bật HbF; chỉnh sửa tế bào soma — Drugs.com FDA history https://drugs.com/history/casgevy.html; Nobel Prize 2020
- [cập nhật] HLA-B*15:02: SJS/TEN; FDA khung cảnh báo 2007 khuyên xét nghiệm ở người tổ tiên châu Á; tần số alen người Việt ≈ 12–15% (11,88% miền Nam; 15,11% miền Bắc), OR SJS ≈ 12–13 — Frontiers in Pharmacology 2023, https://www.frontiersin.org/journals/pharmacology/articles/10.3389/fphar.2023.1217516/full; GenomeWeb 2007
- [bổ sung] CYP2C9/VKORC1 & warfarin: nhãn FDA 08/2007, bảng liều theo kiểu gen 01/2010; gen giải thích 30–35% biến thiên liều; người châu Á cần liều thấp hơn do VKORC1 — ADLM Pearls of Laboratory Medicine 2011
- [cập nhật] Giá giải trình tự 1 bộ gen: "≈ 1.000 USD hoặc thấp hơn" → "≈ 500 USD (NHGRI, 2022)"; thêm công nghệ đọc đoạn dài — NHGRI cost data (datahub.io/technology/genome-sequencing-costs)
- [bổ sung] WES/WGS: ACMG 2021 khuyến cáo xét nghiệm hàng đầu/hàng hai cho dị tật bẩm sinh, chậm phát triển, khuyết tật trí tuệ; hiệu suất chẩn đoán ≈ 1/4–1/3 — ACMG (Manickam et al., Genet Med 2021)
- [bổ sung] NIPT: ADN tự do (chủ yếu bánh nhau), từ ≈ tuần 10, phát hiện >99% Down, là sàng lọc, cần khẳng định bằng chọc ối/sinh thiết gai nhau — ACOG 2020
- [bổ sung] Sàng lọc ở Việt Nam: Luật Dân số 113/2025/QH15; Thông tư 12/2026/TT-BYT (ban hành 15/5/2026, hiệu lực 1/7/2026): 70 bệnh/nhóm bệnh trước sinh, >30 bệnh sơ sinh (gồm G6PD, suy giáp bẩm sinh, CAH, PKU, thalassemia, SMA, SCID, giảm thính lực, tim bẩm sinh); MS/MS trên giọt máu khô — https://thuvienphapluat.vn/van-ban/The-thao-Y-te/Thong-tu-12-2026-TT-BYT-Danh-muc-benh-bam-sinh-can-sang-loc-truoc-sinh-va-so-sinh-705765.aspx; daibieunhandan.vn
- [kiểm tra] Khung cũ: T2T 2022 ≈ 3,05 tỷ bp, Y 2023, 19.000–20.000 gen mã hóa protein, Maxam–Gilbert/Sanger 1977 — đúng; chỉ ghi thêm nguồn
- [kiểm tra] Hình pcr.svg, ky-hieu-pha-he.svg, pha-he-mau.svg — đúng
- [quiz] Escape HLA-B\*15:02; thêm q38 (HLA-B*15:02 trước carbamazepin), q39 (Casgevy), q40 (tf: NIPT, exome, T2T), q41 (Nobel Hóa 2020 CRISPR)

# sh-08 – Các quy luật di truyền – nhật ký cập nhật (2026-10-13)

- [bổ sung] Cơ sở phân tử ABO (glycosyltransferase; alen O mất 1 nucleotid lệch khung) và hệ Rh (RHD, Rh âm thường mất cả 2 bản; kháng thể kháng D là miễn dịch; Rh âm ở VN ≈ 0,04–0,07%, châu Âu ≈ 15%; tan máu sơ sinh, anti-D) — Thompson & Thompson 9th; Vinmec https://www.vinmec.com/vie/bai-viet/xet-nghiem-nhom-mau-rh-duong-tinh-nhung-dieu-can-luu-y-vi
- [bổ sung] Độ thâm nhập & mức biểu hiện: BRCA1 nguy cơ ung thư vú suốt đời 55–72%; NF1 biểu hiện thay đổi — NCI BRCA fact sheet; Thompson & Thompson 9th
- [bổ sung] Mô hình ngưỡng, GWAS, PRS: chiều cao 12.111 SNP trên ≈ 5,4 triệu người, giải thích ≈ 40% biến thiên ở người châu Âu, 10–20% ở tổ tiên khác → PRS kém chính xác ở người châu Á — Yengo et al., Nature 2022, https://rti.org/publication/saturated-map-common-genetic-variants-associated-human-height
- [cập nhật] G6PD: "khá phổ biến" → số liệu: ≈ 0,5% Kinh phía Bắc, 8,7–14% nhóm phía Nam, 9,7–31% dân tộc thiểu số vùng núi phía Bắc (Malaria Journal 2009, https://link.springer.com/doi/10.1186/1475-2875-8-152); sàng lọc sơ sinh Hà Nội 4,4% nguy cơ cao (Medlatec, VJOL https://vjol.info.vn/most/article/download/88896/75502); có trong danh mục sàng lọc sơ sinh TT 12/2026/TT-BYT; WHO khuyến cáo xét nghiệm G6PD trước primaquin/tafenoquin
- [bổ sung] In dấu bộ gen (methyl hóa ADN, ≈ 100–200 gen): Prader-Willi (mất đoạn 15q11–q13 của bố ≈ 70%, UPD mẹ ≈ 25%), Angelman (mất đoạn của mẹ ≈ 70%, UBE3A 10–20%) — MedlinePlus Genetics (Prader-Willi, Angelman)
- [cập nhật] Liệu pháp thay thế ty thể: Anh hợp pháp 2015, Úc 2022; NEJM 16/7/2025: 8 trẻ ra đời (pronuclear transfer), 3/8 còn 5–16% mtDNA đột biến của mẹ — Newcastle Hospitals NHS https://www.newcastle-hospitals.nhs.uk/news/eight-babies-born-mitochondrial-donation-treatment/; Scientific American 2025
- [sửa sai] Hình pha-he.svg: "Mẹ truyền cho mọi con" → "Mẹ truyền cho con (cả trai, gái)" (không phải mọi con đều nhận đủ mức đột biến do dị tế bào chất); đã render kiểm tra
- [kiểm tra] Khung cũ: Sturtevant 1913, ≈ 20.000 gen, SRY, PAR1/PAR2 & SHOX, mtDNA 16.569 bp/37 gen, mõm chó (liều gen), G6PD–berberin — đúng, giữ nguyên
- [quiz] Thêm q41 (in dấu PWS/AS), q42 (thâm nhập không hoàn toàn BRCA1), q43 (tf: Rh), q44 (tf: GWAS/PRS), q45 (vận dụng: sàng lọc sơ sinh G6PD)

# Nhật ký cập nhật sh-09 — Cơ sở phân tử của hiện tượng di truyền

- [cập nhật] Khung "Số gen người": số gen mã hóa protein ≈19.400 (GENCODE 49, 2025), ≈36.000 gen lncARN, ≈7.500 gen ARN nhỏ, ≈14.700 gen giả; giữ "31.780 gen" của sách để thi — GENCODE human stats (qua Wikipedia "GENCODE", truy cập 10/2026), https://en.wikipedia.org/wiki/GENCODE
- [bổ sung] Bộ gen T2T-CHM13 hoàn chỉnh 2022, ≈3,055 tỷ bp, lấp ≈8% còn thiếu — Nurk và cs., Science 2022 (PMC9186530)
- [sửa sai] E. coli: giáo trình ≈3000 gen → hiện nay K-12 ≈4,6 Mb, ≈4.300 gen mã hóa protein — Blattner và cs., Science 1997
- [bổ sung] ENCODE 2012 (80% "hoạt tính hóa sinh") và tranh cãi (ước ≈10% chịu chọn lọc); thêm LINE/SINE/Alu — ENCODE Consortium, Nature 2012; Wikipedia "Human genome"
- [cập nhật] Ghép nối thay thế: "phần lớn gen" → ≈95% gen nhiều exon; bổ sung nusinersen sửa ghép nối SMN2 (teo cơ tủy sống) — Pan và cs. Nat Genet 2008; FDA 2016
- [bổ sung] miARN: lin-4 (Ambros 1993), Ruvkun – lin-14, let-7 (2000); Nobel Y học 2024; người ≈2.000 gen miARN — ASBMB Today 10/2024, https://www.asbmb.org/asbmb-today/people/100724/2024-nobel-medicine-ambros-ruvkun ; Wikipedia "Human genome"
- [cập nhật] Bảng ARN polymerase Eukaryota: pol II phiên mã cả tiền thân miARN, lncARN; snARN U6 do pol III — Alberts MBoC 7th ed. (2022)
- [cập nhật] Khung mới "Vị trí E và ribosom là ribozym": 3 vị trí A–P–E; peptidyl transferase là rARN 23S/28S; Nobel Hóa học 2009 — Alberts MBoC 7th; NobelPrize.org 2009
- [bổ sung] In dấu bộ gen: Prader-Willi (mất 15q11–q13 nguồn bố) / Angelman (nguồn mẹ) — Thompson & Thompson Genetics in Medicine 9th
- [bổ sung] CRISPR thế hệ mới: base editing (Liu 2016), prime editing (2019); ca chỉnh sửa base cá thể hóa đầu tiên (thiếu CPS1, NEJM 5/2025); dữ liệu lâm sàng prime editing đầu tiên (u hạt mạn tính, 2025) — NIH news release 15/5/2025, https://www.nih.gov/news-events/news-releases/infant-rare-incurable-disease-first-successfully-receive-personalized-gene-therapy-treatment ; Wikipedia "Prime editing"
- [kiểm tra – giữ nguyên] Khung Casgevy (MHRA 11/2023; FDA 12/2023 HCHL, 1/2024 β-thal), vắc xin mARN Nobel 2023 (Karikó, Weissman), mã ty thể, phân công pol ε/δ, Chi tiết DnaA/gyrase: đúng, có nguồn/năm.
- [quiz] q40: đổi nhãn đề thành "(Kiến thức hiện nay)"
- [quiz] Thêm q41 (số gen mã hóa protein), q42 (cơ chế miARN – Nobel 2024), q43 (base editing không cắt hai mạch), q44 (mARN vắc xin – N1-methylpseudouridin, Nobel 2023)
- [hình] Rà 5 SVG (xoắn kép, chạc tái bản, trung tâm, operon lac, gen Eukaryota): không có nhãn lỗi thời, không sửa.
- [sửa ký hiệu] Đổi dấu ~ mang nghĩa "khoảng" thành ≈ trong bai.md (vd ARN mồi ≈10 nt, ≈75 nt, poly A ≈200) và quiz q10

# Nhật ký cập nhật sh-10 — Đột biến

- [cập nhật] Khung mới ISCN 2024: phiên bản hiện hành (Karger 12/2024), "cytogenomic", quy tắc dấu phẩy/không dấu cách, khảm "/", ký hiệu microarray "arr … x1/x3" — Karger media release 10/12/2024, https://karger.com/pages/newsroom-media-release-ISCN-2024
- [bổ sung] Khung CNV & microarray (CMA): giới hạn karyotype ≈5–10 Mb; vi mất đoạn 22q11.2; CMA xét nghiệm đầu tay từ 2010, hiệu suất 15–20% so với ≈5% karyotype; CMA không thấy chuyển đoạn cân bằng — Miller và cs., Am J Hum Genet 2010;86:749 (tóm tắt ScienceDaily 13/5/2010, https://www.sciencedaily.com/releases/2010/05/100513123712.htm)
- [bổ sung] Khung danh pháp HGVS (c./p./g., Ter, del, fs); HbS = HBB c.20A>T p.Glu7Val; HbE = c.79G>A p.Glu27Lys; CFTR c.1521_1523del p.Phe508del; giải thích lệch 1 do đếm Met — NCBI ClinVar NM_000518.5 (https://www.ncbi.nlm.nih.gov/clinvar/variation/15333/); HGVS nomenclature (varnomen.hgvs.org)
- [bổ sung] Mục 3.2b "Đột biến động – lặp ba nucleotid": Huntington HTT CAG 10–35 / 36–39 / ≥40, khởi phát thiếu niên >60, giãn qua bố; X dễ gãy FMR1 CGG ≈5–40 / tiền đột biến 55–200 / >200 methyl hóa, giãn qua mẹ, 1/4.000 nam – 1/8.000 nữ; khung ghi-nhớ hiện tượng di truyền tiên phát (anticipation) — MedlinePlus Genetics (Huntington disease; Fragile X syndrome), https://medlineplus.gov/genetics/condition/huntington-disease/ , https://medlineplus.gov/genetics/condition/fragile-x-syndrome/
- [bổ sung] Khung "Đột biến soma và ung thư": gen tiền ung thư (tăng chức năng, 1 alen) vs gen ức chế khối u (mất chức năng, 2 alen – Knudson); TP53, RB1, BRCA1/2, KRAS, HER2, BCR-ABL; chữ ký đột biến (UV C>T, aflatoxin/BaP G>T, AA A>T) — Alberts MBoC 7th; Thompson & Thompson 9th; Alexandrov và cs., Nature 2013/2020
- [sửa sai] Bảng tác nhân: UV "nối hai thymin" → nối hai pyrimidin kề nhau (dimer T–T hay gặp nhất; C>T, CC>TT) — Alberts MBoC 7th
- [bổ sung] Khung YHCT aflatoxin (khung có sẵn): điểm nóng TP53 codon 249 (AGG→AGT, R249S); IARC nhóm 1 (khẳng định lại Monograph 100F, 2012) — IARC Monographs 100F
- [bổ sung] Khung YHCT acid aristolochic (khung có sẵn): IARC nhóm 1, Monograph 100A (2012) cho cả AA và cây chứa AA; chữ ký A>T (SBS22), cả ở ung thư đường niệu trên và một phần ung thư gan châu Á — IARC Monograph 100A (2012); Ng và cs., Sci Transl Med 2017
- [kiểm tra – giữ nguyên] Khung CpG/5-methylcytosin, khung HbE (giáo trình nhầm GUA/GUG), rob(14;21) theo ISCN, Philadelphia/imatinib, Down 1/700, 45,X ≈99% sẩy, Bloom SCE ≈10×: đúng.
- [cập nhật] Bảng tóm tắt: sửa "dimer thymin" → "dimer pyrimidin", thêm acid aristolochic; thêm dòng "Bổ sung hiện nay".
- [quiz] q29: đổi nhãn thành "(Kiến thức hiện nay, khác chi tiết giáo trình)"; q34: lời giải sửa "dimer thymin" → "dimer pyrimidin (hay gặp nhất dimer thymin)"
- [quiz] Thêm q36 (CMA đầu tay), q37 (Huntington – anticipation, giãn qua bố), q38 (tf: oncogene/gen ức chế khối u/đột biến soma/chữ ký A>T), q39 (HGVS p.Glu7Val vs β6)
- [hình] Rà 3 SVG (không phân ly, cấu trúc, chuyển đoạn): đúng, không sửa.

# Nhật ký cập nhật sh-11 — Quá trình phát triển cá thể

- [cập nhật] Khung mới "Lặp lại lịch sử chủng loại – hiểu cho đúng": định luật Haeckel theo nghĩa đen không còn được chấp nhận; cách hiểu von Baer/evo-devo (phôi giống phôi, gen Hox), cung hầu không phải mang — Gilbert & Barresi, Developmental Biology 12th (2020); Langman's Medical Embryology 15th (2023)
- [bổ sung] Khung phôi người: thêm thuật ngữ "hoạt hóa bộ gen hợp tử" (ZGA), giai đoạn 4–8 tế bào, phân hủy mARN mẹ — Langman 15th; Alberts MBoC 7th
- [bổ sung] Bảng mốc phát triển phôi người theo tuần (ngày 1 thụ tinh → ngày 4–5 phôi nang → ngày 6–7 làm tổ → tuần 2 hai lá → tuần 3 ba lá → tim đập ≈ ngày 22 → ống thần kinh khép ≈ ngày 25/28 → tuần 3–8 thời kỳ phôi → tuần 9 thời kỳ thai; +2 tuần theo KKC) — Langman's Medical Embryology 15th ed. (2023)
- [bổ sung] iPSC: Yamanaka 2006 (chuột) / 2007 (người), Nobel 2012 cùng Gurdon; ứng dụng thử nghiệm (biểu mô sắc tố võng mạc, tế bào dopamin – Parkinson) — NobelPrize.org 2012
- [cập nhật] Acid folic: 400 µg/ngày từ ≥1 tháng trước thai; 4 mg/ngày nếu từng có con dị tật ống thần kinh — CDC, https://www.cdc.gov/folic-acid/about/index.html (truy cập 10/2026)
- [cập nhật] Ong chúa giao phối "khoảng 10–20 ong đực (có khi nhiều hơn)" — Winston, The Biology of the Honey Bee; Tarpy & Nielsen 2002
- [kiểm tra – giữ nguyên] Tinh dịch đồ WHO 2021 (16 triệu/mL, di động tiến tới 30%, hình dạng 4%); Kartagener/dynein; chửa trứng toàn phần 46,XX nguồn bố; u quái nguồn trứng; ống thần kinh khép ≈ ngày 28; dây sống – lá giữa trục; mào thần kinh; trứng thú "rất ít noãn hoàng": đúng, có ghi "đi thi theo giáo trình".
- [cập nhật] Bảng tóm tắt: chú thích cách hiểu hiện nay về "lặp lại chủng loại"; thêm dòng mốc phôi người.
- [quiz] q29, q30: thêm nhãn "(Kiến thức hiện nay)" vì là kiến thức bổ sung ngoài sách; q29 lời giải thêm liều 400 µg / 4 mg
- [quiz] Thêm q36 (tim đập ≈ ngày 22, ống thần kinh ≈ ngày 28), q37 (iPS vs tế bào gốc phôi), q38 (tf: ZGA 4–8 tế bào, lá nuôi theo vị trí, làm tổ ngày 6–7, Haeckel)
- [hình] Rà 4 SVG (tinh trùng, loại trứng, phân cắt, lá phôi): nhãn đúng theo giáo trình; "Dây sống (theo giáo trình)" đã ghi rõ; không sửa.

# Nhật ký cập nhật sh-12 — Cơ chế điều khiển phát triển phôi và các nhân tố ảnh hưởng

- [cập nhật] Bảng tác nhân – valproat: thêm ≈10% dị tật lớn, 30–40% rối loạn phát triển thần kinh; chương trình phòng tránh thai EU 2018 — MHRA/EMA 2018, https://www.ema.europa.eu/en/medicines/human/referrals/valproate-related-substances-0
- [cập nhật] Bảng tác nhân – rượu: thuật ngữ rối loạn phổ rượu bào thai (FASD), hội chứng rượu bào thai là thể nặng nhất; không ngưỡng/không thời điểm an toàn — CDC FASD; Langman 15th
- [bổ sung] Bảng tác nhân – Zika tách dòng riêng: hội chứng Zika bẩm sinh; Brazil 2015; PHEIC WHO 1/2/2016–18/11/2016; ca đầu tiên ở Việt Nam (Đắk Lắk, xác nhận 30/10/2016) — WHO 18/11/2016 https://www.who.int/news/item/18-11-2016-fifth-meeting-of-the-emergency-committee-under-the-international-health-regulations-(2005)-regarding-microcephaly-other-neurological-disorders-and-zika-virus ; Viet Nam News 31/10/2016 https://vietnamnews.vn/society/345333/vn-confirms-first-zika-tied-birth-defect-case.html
- [bổ sung] CMV: nhiễm trùng bẩm sinh hay gặp nhất, nguyên nhân hàng đầu gây điếc bẩm sinh không do di truyền — CDC CMV
- [cập nhật] Acid folic: ≥1 tháng trước thai; 4 mg/ngày nếu từng có con dị tật ống thần kinh — CDC https://www.cdc.gov/folic-acid/about/index.html
- [bổ sung] Khung mới "Phân loại A/B/C/D/X đã bị FDA bỏ": PLLR ban hành 12/2014, hiệu lực 30/6/2015; mục 8.1/8.2/8.3; Úc vẫn dùng A/B1–B3/C/D/X — Federal Register 79(233), 4/12/2014 https://www.govinfo.gov/content/pkg/FR-2014-12-04/html/2014-28241.htm (trang FDA PLLR bị giới hạn truy cập 429 khi kiểm chứng)
- [cập nhật] Khung liệu pháp gen: Luxturna (FDA 19/12/2017), Zolgensma (FDA 24/5/2019), Casgevy (11/2023, 12/2023); vụ sửa gen phôi CCR5 ở Trung Quốc 2018 — ASGCT 5/2019 https://asgct.org/research/news/may-2019/fda-approves-zolgensma-gene-therapy ; NPR 19/12/2017
- [bổ sung] Khung Dolly: nêu công bố trên Nature (2/1997); nhân bản khỉ bằng SCNT (Trung Quốc 2018) — Liu và cs., Cell 2018
- [bổ sung] Khung mới "Phôi tổng hợp" (SCBEM): chuột 2022, người 2023; ISSCR cập nhật 11/8/2025 (mọi SCBEM phải qua hội đồng, cấm chuyển vào tử cung, cấm ectogenesis); quy tắc 14 ngày với phôi thật (Anh) — ISSCR https://www.isscr.org/isscr-news/the-isscr-releases-targeted-update-to-the-guidelines-for-stem-cell-research-and-clinical-translation ; PET https://www.progress.org.uk/isscr-requires-expanded-oversight-of-embryo-models-bans-ectogenesis/
- [kiểm tra – giữ nguyên] Khung ZGA người 4–8 phôi bào; Spemann–Mangold 1924, Nobel 1935; Gurdon 1962 (ruột nòng nọc), Yamanaka 2006/2007, Nobel 2012; Hox, Nobel 1995; IVF Louise Brown 1978, Edwards Nobel 2010; thalidomid ngày 20–36, >10.000 trẻ; X-quang <50–100 mGy; mốc tách sinh đôi: đúng.
- [cập nhật] Bảng tóm tắt: bổ sung tác nhân, dòng nhãn thuốc thai kỳ, dòng thực nghiệm phôi hiện nay.
- [quiz] q27–q31: đổi nhãn "(Kiến thức bổ sung)" → "(Kiến thức hiện nay)"
- [quiz] Thêm q36 (PLLR bỏ A/B/C/D/X), q37 (xử trí phụ nữ dùng valproat muốn có thai), q38 (Zika – tật đầu nhỏ), q39 (tf: phôi tổng hợp, ISSCR, FASD, PLLR)
- [hình] Rà 2 SVG (tiềm năng – cảm ứng; giai đoạn nhạy cảm): nhãn đúng, đã ghi "theo giáo trình" cho histon; không sửa.

# sh-13 – Một số vấn đề về sinh quyển — nhật ký cập nhật (2026-10-13)
[cập nhật] Khung CO₂: CO₂ toàn cầu 2024 ≈ 423,9 ppm (>150% tiền công nghiệp), tăng kỷ lục ≈ 3,5 ppm; Mauna Loa 9/2026 ≈ 426 ppm — WMO Greenhouse Gas Bulletin 2025 (https://public.wmo.int/node/32882); NOAA GML (https://gml.noaa.gov/ccgg/trends/)
[cập nhật] Thêm nhiệt độ: 2024 ≈ 1,55 ± 0,13 °C trên 1850–1900, năm đầu vượt 1,5 °C; mục tiêu Paris tính theo nhiều thập kỷ — WMO 2025 (https://wmo.int/media/news/wmo-confirms-2024-warmest-year-record-about-155degc-above-pre-industrial-level); IPCC AR6; axit hóa đại dương pH −0,1
[cập nhật] Khung ENSO: định nghĩa Niño-3.4 ±0,5 °C / 5 thời đoạn; NOAA chuyển sang RONI (2026), ngưỡng giữ nguyên — NOAA CPC (https://www.cpc.ncep.noaa.gov/products/analysis_monitoring/enso/roni/announcement.php)
[cập nhật] El Nino 2023–24, La Nina yếu 2024–25; cảnh báo El Nino mạnh–rất mạnh cuối 2026–đầu 2027 — NOAA CPC ENSO Diagnostic Discussion 8/10/2026
[bổ sung] Khung "hiểm họa sinh quyển": IPBES 2019 (≈1 triệu loài bị đe dọa, 75% đất liền, 66% đại dương bị biến đổi, 5 nguyên nhân); Nghị định thư Montreal & phục hồi ozon — IPBES Global Assessment 2019; WMO/UNEP Ozone Assessment 2023
[cập nhật] Khung cố định nitơ: thêm nguồn tổng quan — Fowler et al., Phil Trans R Soc B 2013
[quiz] Thêm q36 (CO₂ 2024), q37 (tf: 1,55 °C, Paris, ENSO), q38 (IPBES 1 triệu loài) — nguồn như trên

# sh-14 – Loài người và môi trường ngoại cảnh — nhật ký cập nhật (2026-10-13)
[cập nhật] PM2.5: WHO 2021 (5/15 µg/m³) giữ nguyên; thêm 99% dân số vượt mức, ≈ 7 triệu tử vong sớm/năm do ô nhiễm không khí ngoài trời + trong nhà — WHO (https://www.who.int/teams/environment-climate-change-and-health/air-quality-and-health/health-impacts/exposure-air-pollution)
[cập nhật] Liều nền UNSCEAR 2,4 mSv/năm, radon ≈ 1,3 mSv — UNSCEAR 2008 (kiểm tra lại qua tổng hợp)
[bổ sung] Giới hạn liều ICRP: nghề nghiệp 20 mSv/năm (TB 5 năm, ≤50 mSv/năm), công chúng 1 mSv/năm; liều X-quang ngực, CT — ICRP Publication 103 (2007)
[cập nhật] Dân số thế giới 8,2 tỷ (2024), đỉnh ≈ 10,3 tỷ giữa thập niên 2080, tuổi thọ TG 73,3 — UN WPP 2024
[cập nhật] Việt Nam 2025: 102,3 triệu, TFR 1,93, tuổi thọ 74,7, SRB 110 (Cục Thống kê, công bố 3/2026; nhandan.vn/...post946357.html); ghi chú TCTK đổi tên thành Cục Thống kê
[cập nhật] Thiếu đói: ≈ 645 triệu người năm 2025 (≈ 8%) — FAO và cs., SOFI 2026 (thay "≈ 700 triệu, đầu 2020s")
[bổ sung] Khung AMR + One Health: GRAM 2021 1,14 triệu chết trực tiếp/4,71 triệu liên quan; >39 triệu 2025–2050 — GRAM, The Lancet 2024 (https://healthdata.org/node/12106); định nghĩa One Health 2021 — WHO/FAO/WOAH/UNEP (https://www.who.int/news/item/01-12-2021-tripartite-and-unep-support-ohhlep-s-definition-of-one-health); Hiệp định Đại dịch WHO 2025
[bổ sung] Khung vi nhựa: định nghĩa <5 mm, nano <1 µm; phát hiện trong máu, nhau thai, mảng xơ vữa; NEJM 2024 (Marfella et al.) chỉ là liên quan, chưa nhân quả; BPA, phthalat
[cập nhật] Khung "Cả bài" (dòng 4) và bảng Tóm tắt: thêm số AMR, VN ≈ 102,3 triệu (2025)
[quiz] Thêm q36 (AMR 1,14 triệu), q37 (One Health), q38 (tf dân số TG & VN) — nguồn như trên

# sh-15 – Tiến hóa của chất sống — nhật ký cập nhật (2026-10-13)
[cập nhật] Khung thế giới ARN: thêm Nobel Hóa 2009 (cấu trúc ribosom); ribozym QT45 (45 nt) tự tổng hợp bản sao và mạch bổ sung, hiệu suất ≈0,2%/72 ngày — Science 2026 (https://astrobiology.com/2026/02/16/a-small-polymerase-ribozyme-that-can-synthesize-itself-and-its-complementary-strand/); sửa câu "ARN tự sao chép chưa tạo được" cho chính xác
[bổ sung] Mẫu tiểu hành tinh Ryugu (uracil) và Bennu (14/20 acid amin, đủ 5 base) — Glavin et al. Nature Astronomy & McCoy et al. Nature, 1/2025 (https://www.sci.news/space/amino-acids-salts-asteroid-bennu-samples-13624.html)
[sửa sai] "Vi khuẩn có ≈10 000 protein" (giáo trình) → E. coli ≈ 4.300 protein; tế bào tối thiểu JCVI-syn3.0 473 gen — Hutchison et al., Science 2016 (giữ ý sách, thêm khung cap-nhat)
[cập nhật] Nội cộng sinh: tế bào chủ là Asgard archaea (phát hiện 2015, nuôi cấy 2020, Eme et al. Nature 2023 xếp nhân thực trong Asgard/Heimdallarchaeia) — https://doi.org/10.1038/s41586-023-06186-2; sửa nhãn hình noi-cong-sinh.svg "Tế bào chủ (Asgard archaea)"
[bổ sung] LUCA ≈ 4,2 tỷ năm, yếm khí, có CRISPR — Moody et al., Nature Ecology & Evolution 2024; ranh giới Cambri 538,8 triệu năm — ICS
[bổ sung] Khung "Sau thuyết tổng hợp": thuyết trung tính (Kimura 1968), truyền gen ngang, Tổng hợp tiến hóa mở rộng (Laland et al. 2015, còn tranh luận), biểu sinh ≠ Lamarck
[cập nhật] Bảng Tóm tắt: hàng Sau tế bào, Nội cộng sinh, Thuyết tiến hóa
[quiz] Thêm q36 (Asgard), q37 (LUCA 4,2 tỷ năm), q38 (tf Bennu, thuyết trung tính)

# sh-16 – Tiến hóa của hệ thống sinh giới — nhật ký cập nhật (2026-10-13)
[cập nhật] Khung 3 lĩnh vực: Woese phát hiện Archaea 1977, đề xuất 3 lĩnh vực 1990; thêm quan điểm "hai lĩnh vực" (Asgard archaea, Eme et al. Nature 2023) — https://doi.org/10.1038/s41586-023-06186-2
[cập nhật] Hình cay-phat-sinh.svg: nhãn "Eukarya nảy ra từ trong Archaea (Asgard)*", chú thích *quan điểm 2023 (đã render kiểm tra)
[cập nhật] Khung chi Homo: Jebel Irhoud ≈ 300.000 (315.000) năm — Hublin et al., Nature 2017; lai giống Neanderthal ≈ 47.000 năm trước — Iasi et al. Science 2024, Sümer et al. Nature 2024 (https://www.eva.mpg.de/press/news/press-kits/2024/2024-12-12-1041-unraveling-human-history/); hộp sọ Cáp Nhĩ Tân là Denisova (≥146.000 năm) — Science & Cell, 6/2025; H. luzonensis (Nature 4/2019, 50–67 nghìn năm) — CNRS; Pääbo Nobel 2022; Hominidae gồm vượn lớn, tông Hominini
[bổ sung] Phân loại virus ICTV: realm (≈10 realm, bản 2025), >16.000 loài, danh pháp kép từ 2021 (Betacoronavirus pandemicum) — ICTV; Virus classification (tổng hợp, 2026)
[bổ sung] Nấm gần động vật hơn thực vật (Opisthokonta) — liên hệ độc tính thuốc kháng nấm
[quiz] Thêm q36 (Jebel Irhoud 300.000 năm), q37 (Pääbo Nobel 2022), q38 (tf Asgard, ICTV, danh pháp kép virus, ADN Neanderthal)
