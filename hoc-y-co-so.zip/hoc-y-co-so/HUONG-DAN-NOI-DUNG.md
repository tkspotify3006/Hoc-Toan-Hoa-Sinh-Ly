# Hướng dẫn thêm và sửa nội dung

Toàn bộ nội dung nằm trong thư mục `content/`. Khi thêm hoặc sửa bài, **không cần đụng vào code**.

## 1. Thêm một bài mới

1. Mở `content/catalog.json` và tìm bài trong danh sách (đã có sẵn theo mục lục giáo trình).
2. Tạo thư mục trùng mã bài, ví dụ `content/nam-1/hoa-hoc/hc-09/`. Trong đó tạo 2 file `bai.md` và `quiz.json`. Có thể chép từ bài mẫu `hc-08b` rồi sửa.
3. Trong `catalog.json`, thêm `"ready": true` vào bài đó:
   ```json
   { "id": "hc-09", "title": "Acid carboxylic…", "pages": "190–211", "ready": true }
   ```
4. Chạy `node scripts/kiem-tra.mjs`. Nếu báo **0 lỗi** thì đưa lên GitHub.

## 2. Viết bài học (`bai.md`)

Bài viết bằng Markdown, phần đầu là thông tin bài:

```markdown
---
title: Glucid
thoi-gian: 30 phút
muc-tieu:
- Mục tiêu 1
- Mục tiêu 2
---

## 1. Tiêu đề mục lớn         ← hiện thành nút trong mục lục của bài
### 1.1. Mục nhỏ

Chữ **đậm**, *nghiêng*, bảng | a | b |, danh sách - …
```

**Ký hiệu hóa học, toán học:**

| Gõ | Hiển thị |
|---|---|
| `H~2~SO~4~` | H₂SO₄ (chỉ số dưới) |
| `Fe^3+^`, `2^4^` | Fe³⁺, 2⁴ (chỉ số trên) |
| `=> A + B → C` | phương trình, canh giữa trong khung |

**Hình:** `![Chú thích hình](ten-hinh.svg)`. Đặt file hình vào cùng thư mục với bài. Ưu tiên SVG dùng `currentColor`, để hình tự đổi màu khi bật giao diện tối.

**Khung nổi bật** (dùng đúng các mã sau):

```markdown
> [!ghi-nho] Tiêu đề (có thể bỏ trống)
> Nội dung…

> [!bay]        Bẫy hay gặp / dễ nhầm khi thi
> [!ung-dung]   Ứng dụng thực tế, lâm sàng
> [!yhct]       Liên hệ Y học cổ truyền, dược liệu, bào chế
> [!cap-nhat]   Kiến thức mới hơn hoặc khác giáo trình
> [!vi-du]      Ví dụ, đào sâu
```

**Nguyên tắc biên soạn:**

- Bám mục lục và trọng tâm của giáo trình.
- Diễn đạt lại bằng lời của mình, không chép nguyên văn sách.
- Khi kiến thức mới khác giáo trình, ghi cả hai: "giáo trình ghi… / hiện nay…". Đi thi trả lời theo giáo trình.
- Mỗi mục lớn nên có ít nhất một "vì sao" (giải thích bản chất) và một ứng dụng thực tế.

## 3. Viết câu hỏi (`quiz.json`)

```json
{
  "questions": [
    { "id": "q01", "type": "mcq", "level": 1,
      "q": "Câu hỏi…",
      "options": ["A", "B", "C", "D"],
      "answer": 1,
      "explain": "Vì sao đúng / vì sao các đáp án khác sai",
      "ref": "Giáo trình tr. 178" },

    { "id": "q02", "type": "multi", "q": "Chọn tất cả…", "options": ["…"], "answer": [0, 2], "explain": "…" },

    { "id": "q03", "type": "tf", "q": "Xét các nhận định:",
      "statements": [
        { "s": "Nhận định 1", "a": true },
        { "s": "Nhận định 2", "a": false, "why": "Giải thích riêng cho ý này" }
      ],
      "explain": "…" }
  ]
}
```

- `answer` **đếm từ 0**: A = 0, B = 1, C = 2, D = 3. Thứ tự đáp án sẽ được xáo trộn khi hiển thị.
- `"fixed": true` giữ nguyên thứ tự đáp án (dùng khi có lựa chọn "Tất cả đều đúng", hoặc các đáp án là dãy số tăng dần).
- `level`: 1 = Nhớ, 2 = Hiểu, 3 = Vận dụng. Nên có đủ cả 3 mức.
- **Không đổi `id` của câu đã đăng.** Tiến độ ôn tập của người học gắn với `id`. Có thể sửa nội dung câu thoải mái.
- Nên có 20–35 câu mỗi bài, mỗi câu đều có `explain`.

## 4. Thêm năm học mới (năm 2, 3…)

Trong `catalog.json`, thêm một phần tử vào `years`:

```json
{ "id": "nam-2", "title": "Năm 2", "subjects": [ … ] }
```

Sau đó tạo thư mục `content/nam-2/…` theo cùng quy ước. Mọi chức năng (ôn tập, tra cứu, tiến độ) tự áp dụng cho năm mới.

## 5. Khi sửa code giao diện

Nếu sửa `index.html`, `style.css` hoặc `js/`, hãy tăng số phiên bản trong **`js/version.js`** (ví dụ `0.2.0` → `0.2.1`). Như vậy điện thoại người dùng mới tải bản giao diện mới. Sửa nội dung trong `content/` thì không cần: bài học luôn được lấy bản mới khi có mạng.
