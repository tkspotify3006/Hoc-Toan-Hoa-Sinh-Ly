/* Service worker — cho phép dùng offline.
   Phiên bản lấy từ js/version.js (sửa ở đó, không sửa ở đây). */
importScripts('js/version.js');
const VERSION = self.APP_VERSION;
const SHELL = `shell-${VERSION}`;
const CONTENT = 'content';
const SHELL_FILES = [
  './', 'index.html', 'style.css', 'manifest.webmanifest',
  'js/version.js', 'vendor/marked.min.js', 'js/store.js', 'js/content.js', 'js/views.js', 'js/quiz.js', 'js/app.js',
  'icons/icon.svg', 'icons/icon-192.png', 'icons/icon-512.png', 'icons/icon-maskable-512.png', 'icons/apple-touch-icon.png', 'icons/favicon-32.png'
];
const NET_TIMEOUT = 3500; // mạng yếu quá 3,5 giây thì dùng bản đã lưu

self.addEventListener('install', e => {
  // cache: 'reload' để không lấy nhầm bản cũ trong bộ nhớ đệm HTTP của trình duyệt
  e.waitUntil(caches.open(SHELL)
    .then(c => c.addAll(SHELL_FILES.map(u => new Request(u, { cache: 'reload' }))))
    .then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(
    keys.filter(k => k.startsWith('shell-') && k !== SHELL).map(k => caches.delete(k))
  )).then(() => self.clients.claim()));
});

// Lưu bản sao vào cache; trả về promise để waitUntil chờ ghi xong (SW không bị tắt giữa chừng)
function store(cacheName, req, res) {
  if (res && res.ok && res.type === 'basic') {
    const copy = res.clone();
    return caches.open(cacheName).then(c => c.put(req, copy)).catch(() => {});
  }
  return Promise.resolve();
}

self.addEventListener('fetch', e => {
  const req = e.request;
  const url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== location.origin) return;

  if (url.pathname.includes('/content/')) {
    // Nội dung: ưu tiên bản mới từ mạng; mạng chậm/mất thì dùng bản đã lưu
    const net = fetch(req);
    e.waitUntil(net.then(res => store(CONTENT, req, res)).catch(() => {}));
    e.respondWith(new Promise(resolve => {
      let done = false;
      const fallback = () => caches.match(req).then(c => { if (c && !done) { done = true; resolve(c); } return c; });
      const timer = setTimeout(fallback, NET_TIMEOUT);
      net.then(res => { clearTimeout(timer); if (!done) { done = true; resolve(res); } })
        .catch(() => { clearTimeout(timer); fallback().then(c => { if (!c && !done) { done = true; resolve(Response.error()); } }); });
    }));
    return;
  }

  // Giao diện: dùng bản lưu cho nhanh, cập nhật ngầm
  const isNav = req.mode === 'navigate';
  const cachedP = caches.match(isNav ? 'index.html' : req, { ignoreSearch: true });
  const net = fetch(req);
  e.waitUntil(net.then(res => store(SHELL, isNav ? 'index.html' : req, res)).catch(() => {}));
  e.respondWith(cachedP.then(cached => cached || net.catch(() => isNav ? caches.match('./') : Response.error())));
});
