# Học Y Cơ Sở

Ứng dụng web (PWA) để **học, làm quiz và ôn tập** kiến thức cơ sở cho sinh viên Y Dược học Cổ truyền.
Năm 1, Module 1 gồm: Sinh học (16 bài), Hóa vô cơ & hữu cơ (17), Vật lý – Lý sinh (10), Hóa sinh (22) — 65 bài, 190 hình, 2.390 câu quiz.

- Miễn phí, chạy trên **GitHub Pages**. Không cần máy chủ, không cần đăng nhập.
- Cài được lên điện thoại như một app ("Thêm vào màn hình chính") và **dùng được khi không có mạng**.
- Tiến độ học lưu ngay trên máy người dùng. Có thể sao lưu và khôi phục bằng file `.json`.

## Tính năng

| | |
|---|---|
| **Học** | Bài giảng ngắn gọn, có hình cấu tạo, khung *Ghi nhớ*, *Bẫy hay gặp*, *Ứng dụng thực tế*, *Liên hệ YHCT*, *Cập nhật kiến thức*. Mỗi bài ghi số trang giáo trình để đối chiếu. |
| **Quiz** | Ba dạng câu hỏi: trắc nghiệm 1 đáp án, nhiều đáp án, và Đúng/Sai theo từng ý. Mỗi câu có giải thích và nguồn. |
| **Ôn tập** | Câu làm sai, hoặc đúng nhưng tick "chưa chắc", tự vào **Sổ câu sai**. Câu đó được hỏi lại sau 1 → 3 → 7 → 14 ngày; đúng liên tiếp thì thành "Đã thuộc", sai thì quay lại từ đầu. Có thể đánh dấu ★ câu muốn xem lại. |
| **Tra cứu** | Tìm trong toàn bộ bài học, gõ không dấu cũng được. |

## Đưa lên GitHub (làm một lần)

GitHub chỉ cho tải lên dưới 100 file mỗi lần, mà app có hơn 350 file. Vì vậy ta **chỉ tải lên 1 file zip**, GitHub tự giải nén và đăng app.

1. Tạo repository **Public** (ví dụ `hoc-y`).
2. **Add file → Upload files** → kéo file `hoc-y-co-so.zip` (để nguyên, không giải nén) → **Commit changes**.
3. **Add file → Create new file** → ô tên gõ đúng `.github/workflows/deploy.yml` → dán nội dung file `deploy.yml` (có trong zip tại `.github/workflows/deploy.yml`) → **Commit changes**.
4. **Settings → Pages** → mục *Source* chọn **GitHub Actions**.
5. Vào tab **Actions**, chờ dòng chạy có dấu ✓ xanh (1–2 phút). App chạy tại `https://<tên-tài-khoản>.github.io/<tên-repo>/`.

**Cập nhật về sau:** Upload files → kéo file zip mới **cùng tên** `hoc-y-co-so.zip` (ghi đè) → Commit. App tự cập nhật.

## Chạy thử trên máy

```bash
python3 -m http.server 8000     # rồi mở http://localhost:8000
node scripts/kiem-tra.mjs       # kiểm tra lỗi nội dung trước khi đưa lên
python3 scripts/thong-ke-quiz.py  # thống kê chất lượng quiz
```

## Cấu trúc thư mục

```
index.html, style.css          giao diện
js/                            mã chương trình (không cần sửa khi thêm bài)
  version.js  số phiên bản (tăng khi sửa giao diện/code)
  store.js    lưu tiến độ + thuật toán ôn tập
  content.js  đọc mục lục, bài học (Markdown), quiz (JSON), tra cứu
  quiz.js     làm bài trắc nghiệm
  views.js    các màn hình
  app.js      điều hướng
sw.js, manifest.webmanifest    chạy offline / cài như app
vendor/marked.min.js           thư viện đọc Markdown (marked v12, MIT)
content/
  catalog.json                 MỤC LỤC: năm → môn → phần → bài
  nam-1/<môn>/<mã-bài>/
      bai.md                   nội dung bài học
      quiz.json                câu hỏi
      *.svg                    hình
scripts/
  kiem-tra.mjs                 kiểm tra nội dung
  hinh_glucid.py               ví dụ sinh hình cấu tạo bằng code
```

Tài liệu kèm theo: `docs/BAO-CAO-AUDIT.md` (kết quả audit), `docs/CAP-NHAT-SINH-HOC.md` (nhật ký cập nhật kiến thức Sinh học), `docs/YHCT-CAN-DUYET.md` (khung YHCT cần lương y duyệt).

Muốn **thêm bài, sửa bài, thêm năm học mới**, xem [HUONG-DAN-NOI-DUNG.md](HUONG-DAN-NOI-DUNG.md).

## Bản quyền nội dung

Bài học được **biên soạn lại**, không sao chép nguyên văn giáo trình. Có ghi tên sách và số trang để sinh viên đối chiếu với sách gốc.
**Không đưa file PDF giáo trình lên repository công khai.**
