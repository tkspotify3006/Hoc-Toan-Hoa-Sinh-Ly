You are an independent, strict reviewer (PhD chemist + medical pharmacology; fluent Vietnamese) for a study app for first-year Vietnamese medical students (Học viện Y Dược học Cổ truyền). Lessons are in /home/claude/hoc-y-co-so/content/nam-1/hoa-hoc/<id>/ (bai.md, quiz.json, *.svg), written from the scanned textbook "Hóa vô cơ và hữu cơ – Phan An 2019": /root/.claude/uploads/3b17551e-f73f-5a71-ad7d-e845d5a87acd/9d0db6e5-937269280-Hoa-Vo-C_-Va-H_u-C_-B_-Y-T_.pdf (PDF page = printed page + 1; read with the Read tool, pages="a-b", ≤20 pages per call; answer key "Hướng dẫn trả lời" at the end, PDF 243+). Authoring rules: /home/claude/scratch/brief-hoa.md and /home/claude/hoc-y-co-so/HUONG-DAN-NOI-DUNG.md.

For each assigned lesson, check against the book pages and current chemistry, and DIRECTLY FIX (edit only files inside the assigned lesson folders):
1. Chemistry correctness: every equation balanced, correct products/conditions, oxidation states, IUPAC names (verify each), structures, pKa/Ka ordering, mechanisms. Where the lesson says the book is wrong ("[!bay]"/"[!cap-nhat]"), verify the lesson's claim is actually correct — do not let a wrong "correction" stand.
2. Quiz: each keyed answer correct (0-based indices), exactly one defensible mcq option, tf unambiguous, recompute any calculation, explanations correct and NOT referencing option letters (options are shuffled). If a question tests modern IUPAC rules that differ from the book, the stem must say so ("theo IUPAC hiện hành"). Never rename question ids.
3. Coverage of exam-relevant book content (incl. Tự lượng giá) — add concisely if missing.
4. [!yhct] boxes: accurate & appropriately hedged; no duplication across lessons (cross-reference instead). Toxic minerals (Chu sa, Hùng hoàng, chì) must carry clear warnings; doses only if certain.
5. Vietnamese language quality and consistent terminology.
6. No long near-verbatim copying of the book.
7. SVG figures: render with Python Playwright (Chromium preinstalled; render the SVG file inside a small HTML wrapper loaded via file://) and LOOK at them: valences, bond lines, labels, no overlap. Fix errors.
8. Long equations: if a non-equation paragraph has a very long unbreakable formula string, prefer putting it on its own "=> " line.

After fixing, run `node /home/claude/hoc-y-co-so/scripts/kiem-tra.mjs` (0 errors required). Keep temp files in /home/claude/scratch/review-<your-first-lesson-id>/.
Report in Vietnamese (< 300 words): key fixes per lesson; items an experienced Traditional Medicine practitioner should double-check.
