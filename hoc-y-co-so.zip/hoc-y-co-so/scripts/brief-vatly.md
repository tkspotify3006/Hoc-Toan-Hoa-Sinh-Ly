# Brief soạn bài cho app "Học Y Cơ Sở" (sinh viên năm 1, Học viện Y Dược học Cổ truyền VN)

Bạn soạn MỘT bài học (bai.md + quiz.json + hình SVG nếu cần) cho môn Vật lý – Lý sinh, theo giáo trình
"Vật lý – Lý sinh y học — Bộ môn Y Vật lý, ĐH Y Hà Nội; Nguyễn Văn Thiện, Phan Sỹ An (đồng chủ biên), NXB Y học 2010" (sách đào tạo bác sĩ đa khoa).

## Đọc trước (bắt buộc)
- Quy ước nội dung: /home/claude/hoc-y-co-so/HUONG-DAN-NOI-DUNG.md
- Bài mẫu chuẩn (học theo phong cách, độ sâu, cách dùng khung):
  /home/claude/hoc-y-co-so/content/nam-1/hoa-hoc/hc-08b/bai.md và quiz.json
- Giáo trình là bản SCAN: /mnt/user-data/uploads/Vật Lý - Lý Sinh Y Học.pdf
  Lớp chữ của PDF bị MẤT DẤU tiếng Việt và lỗi ký tự; bản trích chữ của bài bạn ở /home/claude/scratch/vl/<mã-bài>.txt chỉ để định vị/đọc nhanh.
  BẮT BUỘC đọc ẢNH trang bằng Read tool (pages="a-b", tối đa 20 trang/lần) để lấy đúng nội dung, công thức, số liệu, hình. Đọc hết các trang của bài (kể cả câu hỏi lượng giá cuối bài nếu có).
  QUY ĐỔI: số trang in trên sách = số trang PDF + 3.
- Dùng SỐ TRANG IN TRÊN SÁCH khi ghi nguồn: "Giáo trình tr. 178".

## Yêu cầu nội dung — bai.md
- Frontmatter: title, thoi-gian, muc-tieu (bám MỤC TIÊU của sách, diễn đạt lại).
- Mở đầu bằng khung `> [!ghi-nho] Cả bài trong 5 dòng`.
- Chia `## 1. ...`, `### 1.1 ...` theo trình tự của sách. Bao phủ ĐỦ các ý có thể ra thi (định nghĩa, phân loại, cấu trúc, chức năng, số liệu, ví dụ của sách).
- VIẾT LẠI bằng lời của mình (không chép nguyên văn câu dài của sách — vấn đề bản quyền), dễ hiểu, có "vì sao" (bản chất), câu ngắn gọn, tiếng Việt chuẩn có dấu. Thuật ngữ: giữ cách viết của sách; đơn vị SI chuẩn (ghi đúng ký hiệu: Pa, J, W, Gy, Sv, Bq, dB…) và có thể ghi thuật ngữ tiếng Anh trong ngoặc lần đầu.
- Dùng bảng để so sánh khi hợp lý. Dùng khung:
  - `[!bay]` điểm dễ nhầm khi thi;
  - `[!ung-dung]` ứng dụng y học/lâm sàng (bệnh lý liên quan, thuốc, xét nghiệm);
  - `[!cap-nhat]` khi kiến thức sách (2008) đã cũ: ghi "Giáo trình ghi… / Hiện nay…" — chỉ dùng khi bạn CHẮC chắn về kiến thức mới (đồng thuận khoa học); đi thi vẫn trả lời theo sách;
  - `[!yhct]` CHỈ khi có liên hệ thật sự, chính xác và nêu mức bằng chứng thận trọng: ví dụ châm cứu – điện châm, máy dò huyệt (điện trở da), cứu ngải (nhiệt, hồng ngoại), giác hơi (áp suất âm), xoa bóp – bấm huyệt (cơ học), laser châm (laser công suất thấp), thủy châm, nhiệt trị liệu, sắc thuốc (nhiệt, khuếch tán, thẩm thấu khi ngâm dược liệu), cô cao (bay hơi, áp suất), siêu âm/vi sóng chiết xuất dược liệu, phơi sấy dược liệu (UV, nhiệt). Phải nói rõ cái gì là cơ chế vật lý đã chứng minh, cái gì là quan niệm YHCT. KHÔNG gượng ép; 0–2 khung/bài.
  - `[!vi-du]` đào sâu/ví dụ.
- Cuối bài: `## Tóm tắt` dạng bảng hoặc danh sách ngắn.
- Ký hiệu: H~2~O, Ca^2+^ ; dòng phương trình bắt đầu bằng `=> `.
- Ghi nguồn bằng số trang in trên sách.

## Hình (khuyến khích 1–3 hình SVG cho các cấu trúc quan trọng)
- Tự vẽ bằng SVG (viết tay hoặc script Python sinh ra), đặt trong thư mục bài, chèn bằng `![Hình n. Chú thích](ten.svg)`.
- Dùng `currentColor` cho nét/chữ chính để tự đổi màu sáng/tối; màu nhấn duy nhất `#d97706`; có thể dùng `fill="none"` hoặc fill rất nhạt bằng `fill-opacity`. Font: `font-family="Georgia, 'Times New Roman', serif"`.
- viewBox rộng tối đa 560, chữ ≥ 12px, không chồng lấn. Có <title>.
- KIỂM TRA hình bằng Playwright (Python, đã cài; Chromium sẵn): render, chụp màn hình, tự xem (Read file png) và sửa đến khi sạch. Không sao chép hình của sách; vẽ sơ đồ của riêng mình, đúng khoa học.

## quiz.json
- 25–35 câu (bài ngắn ~20–25). Trộn: mcq (đa số), tf (4–6 câu, mỗi câu 4 ý), multi (2–3 câu). level 1/2/3 đều có, ~30% vận dụng/tình huống y học.
- Mỗi câu có "explain" giải thích vì sao đúng và vì sao các phương án nhiễu sai; "ref": "Giáo trình tr. X" hoặc "Bài học mục Y".
- id: "q01", "q02"… Chỉ đúng 1 đáp án bảo vệ được cho mcq; tránh "tất cả đều đúng" (nếu có thì "fixed": true).
- Bám sát nội dung sách (đó là cái sẽ thi); câu "cập nhật" thì phải ghi rõ trong stem.

## Kiểm tra trước khi xong
1. `node /home/claude/hoc-y-co-so/scripts/kiem-tra.mjs` — bài của bạn phải không có lỗi (lỗi ở bài KHÁC đang được người khác soạn thì bỏ qua).
2. Tự soát lại kiến thức từng câu quiz một lần (đáp án đúng chỉ số 0-based!).
3. KHÔNG sửa file nào ngoài thư mục bài của bạn (đặc biệt không sửa catalog.json, js/, style.css).

## Báo cáo khi xong (ngắn, < 200 từ)
Số mục, số hình, số câu quiz; các điểm [!cap-nhat] đã thêm; điểm nào trong sách bạn thấy sai/mâu thuẫn; điều gì chưa chắc chắn.



## Riêng môn Vật lý – Lý sinh
- Mỗi công thức viết rõ tên đại lượng + đơn vị. Công thức trên một dòng riêng bắt đầu bằng `=> ` (vd `=> F = −η·S·dv/dx`). Dùng ký hiệu Unicode (Δ, η, λ, ω, ∝, √, ≈, ·, ², ³) hoặc `^ ^`/`~ ~`; KHÔNG dùng LaTeX.
- Quiz nên có 25–30% câu tính toán đơn giản (tự giải lại 2 lần; đáp án nhiễu là lỗi thường gặp: quên đổi đơn vị, nhầm bình phương…), còn lại hiểu bản chất và ứng dụng y học.
- Ứng dụng y học là trọng tâm: đo huyết áp, Poiseuille và hẹp mạch, siêu âm Doppler, ECG/EEG, an toàn điện, tật khúc xạ và kính, laser, X-quang/CT/MRI, xạ trị, an toàn bức xạ (Gy/Sv, ALARA)…
- [!cap-nhat] với số liệu/kỹ thuật cũ (sách 2010): giới hạn liều nghề nghiệp (ICRP: 20 mSv/năm trung bình 5 năm; công chúng 1 mSv/năm), đơn vị cũ (rad, rem, Ci, R) ↔ SI, kỹ thuật hình ảnh hiện đại — chỉ khi chắc chắn.
- Hình SVG: sơ đồ nguyên lý (dòng chảy, đường sức, quang hình có tia sáng, mạch điện, sóng…), vẽ chính xác hình học (vd tia qua thấu kính hội tụ đúng quy tắc).
- Có thể chạy `python3 -m http.server <cổng riêng 89xx>` để xem bài trong app — nhưng catalog CHƯA đánh dấu "ready": copy repo sang /home/claude/scratch/<mã-bài>/repo (cp -r), thêm "ready": true vào bản sao catalog rồi kiểm tra/xem trên bản sao. KHÔNG sửa catalog thật. File tạm để trong /home/claude/scratch/<mã-bài>/.
