# Brief soạn bài cho app "Học Y Cơ Sở" (sinh viên năm 1, Học viện Y Dược học Cổ truyền VN)

Bạn soạn MỘT bài học (bai.md + quiz.json + hình SVG nếu cần) cho môn Sinh học, theo giáo trình
"Sinh học — Bộ Y tế, NXB Giáo dục 2008" (sách đào tạo bác sĩ đa khoa).

## Đọc trước (bắt buộc)
- Quy ước nội dung: /home/claude/hoc-y-co-so/HUONG-DAN-NOI-DUNG.md
- Bài mẫu chuẩn (học theo phong cách, độ sâu, cách dùng khung):
  /home/claude/hoc-y-co-so/content/nam-1/hoa-hoc/hc-08b/bai.md và quiz.json
- Văn bản giáo trình của bài bạn được giao: /home/claude/scratch/sh/<mã-bài>.txt
  (có đánh dấu "[Trang PDF n]"; bản có ghi chú tay của người dùng trước như "???", "chắc học lại" — BỎ QUA các ghi chú đó).
- PDF gốc (để xem hình vẽ của sách nếu cần): /root/.claude/uploads/3b17551e-f73f-5a71-ad7d-e845d5a87acd/21126da7-Sinh_H_c_-_B__Y_T__-_Testyhoc.vn_.pdf
  (Read tool với pages="a-b", tối đa 20 trang/lần).

## Yêu cầu nội dung — bai.md
- Frontmatter: title, thoi-gian, muc-tieu (bám MỤC TIÊU của sách, diễn đạt lại).
- Mở đầu bằng khung `> [!ghi-nho] Cả bài trong 5 dòng`.
- Chia `## 1. ...`, `### 1.1 ...` theo trình tự của sách. Bao phủ ĐỦ các ý có thể ra thi (định nghĩa, phân loại, cấu trúc, chức năng, số liệu, ví dụ của sách).
- VIẾT LẠI bằng lời của mình (không chép nguyên văn câu dài của sách — vấn đề bản quyền), dễ hiểu, có "vì sao" (bản chất), câu ngắn gọn, tiếng Việt chuẩn có dấu. Thuật ngữ: giữ cách viết của sách (ADN, ARN, ribosom, ty thể, lưới nội sinh chất…) và có thể ghi thuật ngữ tiếng Anh trong ngoặc lần đầu.
- Dùng bảng để so sánh khi hợp lý. Dùng khung:
  - `[!bay]` điểm dễ nhầm khi thi;
  - `[!ung-dung]` ứng dụng y học/lâm sàng (bệnh lý liên quan, thuốc, xét nghiệm);
  - `[!cap-nhat]` khi kiến thức sách (2008) đã cũ: ghi "Giáo trình ghi… / Hiện nay…" — chỉ dùng khi bạn CHẮC chắn về kiến thức mới (đồng thuận khoa học); đi thi vẫn trả lời theo sách;
  - `[!yhct]` CHỈ khi có liên hệ thật sự, chính xác và nêu mức bằng chứng thận trọng (vd: alkaloid colchicin từ cây và thoi vô sắc; thuốc tác động lên vi ống như vinblastin từ cây Dừa cạn; saponin và màng tế bào…). KHÔNG gượng ép; 0–2 khung/bài là đủ.
  - `[!vi-du]` đào sâu/ví dụ.
- Cuối bài: `## Tóm tắt` dạng bảng hoặc danh sách ngắn.
- Ký hiệu: H~2~O, Ca^2+^ ; dòng phương trình bắt đầu bằng `=> `.
- Không có số trang sách gốc; khi cần nguồn dùng "Giáo trình tr. <số trang PDF>".

## Hình (khuyến khích 1–3 hình SVG cho các cấu trúc quan trọng)
- Tự vẽ bằng SVG (viết tay hoặc script Python sinh ra), đặt trong thư mục bài, chèn bằng `![Hình n. Chú thích](ten.svg)`.
- Dùng `currentColor` cho nét/chữ chính để tự đổi màu sáng/tối; màu nhấn duy nhất `#d97706`; có thể dùng `fill="none"` hoặc fill rất nhạt bằng `fill-opacity`. Font: `font-family="Georgia, 'Times New Roman', serif"`.
- viewBox rộng tối đa 560, chữ ≥ 12px, không chồng lấn. Có <title>.
- KIỂM TRA hình bằng Playwright (Python, đã cài; Chromium sẵn): render, chụp màn hình, tự xem (Read file png) và sửa đến khi sạch. Không sao chép hình của sách; vẽ sơ đồ của riêng mình, đúng khoa học.

## quiz.json
- 25–35 câu (bài ngắn ~20–25). Trộn: mcq (đa số), tf (4–6 câu, mỗi câu 4 ý), multi (2–3 câu). level 1/2/3 đều có, ~30% vận dụng/tình huống y học.
- Mỗi câu có "explain" giải thích vì sao đúng và vì sao các phương án nhiễu sai; "ref": "Giáo trình tr. X" hoặc "Bài học mục Y".
- id: "q01", "q02"… Chỉ đúng 1 đáp án bảo vệ được cho mcq; tránh "tất cả đều đúng" (nếu có thì "fixed": true).
- Bám sát nội dung sách (đó là cái sẽ thi); câu "cập nhật" thì phải ghi rõ trong stem.

## Kiểm tra trước khi xong
1. `node /home/claude/hoc-y-co-so/scripts/kiem-tra.mjs` — bài của bạn phải không có lỗi (lỗi ở bài KHÁC đang được người khác soạn thì bỏ qua).
2. Tự soát lại kiến thức từng câu quiz một lần (đáp án đúng chỉ số 0-based!).
3. KHÔNG sửa file nào ngoài thư mục bài của bạn (đặc biệt không sửa catalog.json, js/, style.css).

## Báo cáo khi xong (ngắn, < 200 từ)
Số mục, số hình, số câu quiz; các điểm [!cap-nhat] đã thêm; điểm nào trong sách bạn thấy sai/mâu thuẫn; điều gì chưa chắc chắn.

## Bổ sung (đợt 2)
- Đã có 6 bài Sinh học Chương 1 hoàn chỉnh trong /home/claude/hoc-y-co-so/content/nam-1/sinh-hoc/sh-01…sh-06 — xem 1 bài để thống nhất văn phong. Có thể dẫn chéo "xem bài Phân chia tế bào" khi cần thay vì lặp lại.
- Đừng lặp lại khung YHCT về colchicin/Ngót nghẻo (đã có ở 3 bài). Liên hệ YHCT chỉ khi thực sự có ý nghĩa.
- Với di truyền học: ký hiệu kiểu gen in nghiêng không cần; dùng chữ thường/hoa (Aa, XᴬXᵃ có thể viết X^A^X^a^). Sơ đồ lai trình bày bằng bảng Punnett (bảng Markdown).
- Kiểm tra trong app: server tĩnh có thể chạy `python3 -m http.server <cổng riêng 87xx>` tại /home/claude/hoc-y-co-so rồi mở `#/bai/nam-1/sinh-hoc/<mã>` bằng Playwright để xem bài hiển thị đúng (tắt server khi xong).
