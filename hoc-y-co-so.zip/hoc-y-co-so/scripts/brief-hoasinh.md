# Brief soạn bài cho app "Học Y Cơ Sở" (sinh viên năm 1, Học viện Y Dược học Cổ truyền VN)

Bạn soạn MỘT bài học (bai.md + quiz.json + hình SVG nếu cần) cho môn Hóa sinh, theo giáo trình
"Hóa sinh — Bộ Y tế / ĐH Y Hà Nội (Tạ Thành Văn và cs.), NXB Y học" (sách đào tạo bác sĩ đa khoa).

## Đọc trước (bắt buộc)
- Quy ước nội dung: /home/claude/hoc-y-co-so/HUONG-DAN-NOI-DUNG.md
- Bài mẫu chuẩn (học theo phong cách, độ sâu, cách dùng khung):
  /home/claude/hoc-y-co-so/content/nam-1/hoa-hoc/hc-08b/bai.md và quiz.json
- Giáo trình là bản SCAN (không có lớp chữ, có watermark "Doctor Plus Club" — bỏ qua): /mnt/user-data/uploads/Hoa_Sinh___40_B_K__41__-_Bo_Y_Te.pdf
  Đọc ẢNH trang bằng Read tool (pages="a-b", tối đa 20 trang/lần). Đọc HẾT các trang của chương, kể cả MỤC TIÊU và CÂU HỎI ÔN TẬP cuối chương. Một vài trang scan bị lộn ngược — vẫn đọc được.
  QUY ĐỔI: số trang in trên sách = số trang PDF + 5 (ví dụ sách tr. 26 = PDF 21).
- Dùng SỐ TRANG IN TRÊN SÁCH khi ghi nguồn: "Giáo trình tr. 178".

## Yêu cầu nội dung — bai.md
- Frontmatter: title, thoi-gian, muc-tieu (bám MỤC TIÊU của sách, diễn đạt lại).
- Mở đầu bằng khung `> [!ghi-nho] Cả bài trong 5 dòng`.
- Chia `## 1. ...`, `### 1.1 ...` theo trình tự của sách. Bao phủ ĐỦ các ý có thể ra thi (định nghĩa, phân loại, cấu trúc, chức năng, số liệu, ví dụ của sách).
- VIẾT LẠI bằng lời của mình (không chép nguyên văn câu dài của sách — vấn đề bản quyền), dễ hiểu, có "vì sao" (bản chất), câu ngắn gọn, tiếng Việt chuẩn có dấu. Thuật ngữ: giữ cách viết của sách (enzym, coenzym, glucid, lipid, acid amin, ADN/DNA… theo đúng sách); tên enzym có thể kèm tiếng Anh lần đầu và có thể ghi thuật ngữ tiếng Anh trong ngoặc lần đầu.
- Dùng bảng để so sánh khi hợp lý. Dùng khung:
  - `[!bay]` điểm dễ nhầm khi thi;
  - `[!ung-dung]` ứng dụng y học/lâm sàng (bệnh lý liên quan, thuốc, xét nghiệm);
  - `[!cap-nhat]` khi kiến thức sách (2008) đã cũ: ghi "Giáo trình ghi… / Hiện nay…" — chỉ dùng khi bạn CHẮC chắn về kiến thức mới (đồng thuận khoa học); đi thi vẫn trả lời theo sách;
  - `[!yhct]` CHỈ khi có liên hệ thật sự, chính xác và nêu mức bằng chứng thận trọng (in vitro / động vật / lâm sàng). Ví dụ hợp lý: berberin và chuyển hóa glucid–lipid (AMPK, có thử nghiệm lâm sàng nhỏ); Hồng khúc (monacolin K = lovastatin, ức chế HMG-CoA reductase; cảnh báo citrinin); Cam thảo và giả cường aldosteron (ức chế 11β-HSD2 → hạ K⁺, tăng huyết áp); bưởi/Ban Âu và CYP; enzym trong dược liệu (amylase của Mạch nha); Hà thủ ô và tổn thương gan; thuốc lợi tiểu thảo dược và điện giải; cao động vật (collagen). Phải tách rõ cơ chế đã chứng minh với quan niệm YHCT. KHÔNG gượng ép; 0–2 khung/bài; không lặp khung đã có ở môn khác (dẫn chéo).
  - `[!vi-du]` đào sâu/ví dụ.
- Cuối bài: `## Tóm tắt` dạng bảng hoặc danh sách ngắn.
- Ký hiệu: H~2~O, Ca^2+^ ; dòng phương trình bắt đầu bằng `=> `.
- Ghi nguồn bằng số trang in trên sách.

## Hình (khuyến khích 1–3 hình SVG cho các cấu trúc quan trọng)
- Tự vẽ bằng SVG (viết tay hoặc script Python sinh ra), đặt trong thư mục bài, chèn bằng `![Hình n. Chú thích](ten.svg)`.
- Dùng `currentColor` cho nét/chữ chính để tự đổi màu sáng/tối; màu nhấn duy nhất `#d97706`; có thể dùng `fill="none"` hoặc fill rất nhạt bằng `fill-opacity`. Font: `font-family="Georgia, 'Times New Roman', serif"`.
- viewBox rộng tối đa 560, chữ ≥ 12px, không chồng lấn. Có <title>.
- KIỂM TRA hình bằng Playwright (Python, đã cài; Chromium sẵn): render, chụp màn hình, tự xem (Read file png) và sửa đến khi sạch. Không sao chép hình của sách; vẽ sơ đồ của riêng mình, đúng khoa học.

## quiz.json
- 25–35 câu (bài ngắn ~20–25). Trộn: mcq (đa số), tf (4–6 câu, mỗi câu 4 ý), multi (2–3 câu). level 1/2/3 đều có, ~30% vận dụng/tình huống y học.
- Mỗi câu có "explain" giải thích vì sao đúng và vì sao các phương án nhiễu sai; "ref": "Giáo trình tr. X" hoặc "Bài học mục Y".
- id: "q01", "q02"… Chỉ đúng 1 đáp án bảo vệ được cho mcq; tránh "tất cả đều đúng" (nếu có thì "fixed": true).
- Bám sát nội dung sách (đó là cái sẽ thi); câu "cập nhật" thì phải ghi rõ trong stem.

## Kiểm tra trước khi xong
1. `node /home/claude/hoc-y-co-so/scripts/kiem-tra.mjs` — bài của bạn phải không có lỗi (lỗi ở bài KHÁC đang được người khác soạn thì bỏ qua).
2. Tự soát lại kiến thức từng câu quiz một lần (đáp án đúng chỉ số 0-based!).
3. KHÔNG sửa file nào ngoài thư mục bài của bạn (đặc biệt không sửa catalog.json, js/, style.css).

## Báo cáo khi xong (ngắn, < 200 từ)
Số mục, số hình, số câu quiz; các điểm [!cap-nhat] đã thêm; điểm nào trong sách bạn thấy sai/mâu thuẫn; điều gì chưa chắc chắn.



## Riêng môn Hóa sinh
- Đã có bài liên quan ở môn khác — DẪN CHÉO, không viết lại: Glucid (content/nam-1/hoa-hoc/hc-08b), Amin–amino acid (hoa-hoc/hc-10), Acid carboxylic–lipid đơn giản (hoa-hoc/hc-09), Dị vòng–base nucleic (hoa-hoc/hc-11), Cơ sở phân tử di truyền & sinh tổng hợp protein (sinh-hoc/sh-09), Màng tế bào & vận chuyển (sinh-hoc/sh-02, sh-04), Điện thế màng (vat-ly/vl-05). Ở Hóa sinh tập trung vào góc nhìn HÓA SINH (cấu trúc → chức năng → chuyển hóa → điều hòa → bệnh lý & xét nghiệm).
- Sơ đồ chuyển hóa (đường phân, chu trình Krebs, β-oxy hóa, chu trình ure, chuỗi hô hấp…) vẽ SVG rõ ràng: tên chất, enzym chính (in nghiêng hoặc màu nhấn #d97706 cho bước điều hòa/không thuận nghịch), số ATP/NADH. Kiểm tra từng bước đúng hóa sinh hiện đại. Chia sơ đồ lớn thành 2 hình nếu cần để đọc được trên điện thoại (viewBox rộng ≤ 560).
- Số liệu xét nghiệm: ghi đơn vị SI Việt Nam dùng (mmol/L, µmol/L, U/L) và khoảng tham chiếu thường dùng, ghi rõ "tham khảo, mỗi phòng xét nghiệm có khoảng riêng".
- Quiz nên có câu tình huống lâm sàng – xét nghiệm (vd đái tháo đường, gout, vàng da, suy thận, toan chuyển hóa), câu "enzym nào xúc tác bước…", "thiếu enzym X gây bệnh gì".
- Ghi nguồn bằng số trang in trên sách: "Giáo trình tr. N".
- catalog.json CHƯA đánh dấu "ready" — KHÔNG sửa catalog. Để kiểm tra: copy repo sang /home/claude/scratch/<mã-bài>/repo (cp -r), thêm "ready": true vào bản sao catalog rồi chạy `node scripts/kiem-tra.mjs` và xem bài bằng `python3 -m http.server <cổng riêng 90xx>` trên bản sao. File tạm để trong /home/claude/scratch/<mã-bài>/.
- Validator cũng kiểm tra SVG hợp lệ: trong chữ của SVG phải viết `&lt;` `&gt;` `&amp;`, mọi thẻ <tspan> phải đóng. Ký hiệu dấu sao (C*, NAD*) phải viết `\*` trong markdown/JSON.
