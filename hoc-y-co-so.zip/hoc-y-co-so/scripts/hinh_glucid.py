"""Sinh các hình SVG cho bài Glucid (chạy: python3 scripts/hinh_glucid.py).
Hình dùng currentColor nên tự đổi màu theo giao diện sáng/tối."""
import math, os
OUT = os.path.join(os.path.dirname(__file__), '..', 'content', 'nam-1', 'hoa-hoc', 'hc-08b')
HL = '#d97706'
FONT = 'font-family="Georgia, \'Times New Roman\', serif"'

def T(x, y, s, anchor='middle', size=15, color='currentColor', weight='normal'):
    return f'<text x="{x}" y="{y}" text-anchor="{anchor}" font-size="{size}" fill="{color}" font-weight="{weight}">{s}</text>'
def L(x1, y1, x2, y2, w=1.6, color='currentColor'):
    return f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{color}" stroke-width="{w}" stroke-linecap="round"/>'
SUB = lambda n: f'<tspan font-size="11" dy="4">{n}</tspan><tspan dy="-4"></tspan>'
CH2OH = f'CH{SUB(2)}OH'

def svg(w, h, body, title, name):
    s = f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" width="{w}" role="img" aria-label="{title}" {FONT}>\n<title>{title}</title>\n' + '\n'.join(body) + '\n</svg>\n'
    open(os.path.join(OUT, name), 'w', encoding='utf-8').write(s)

# ---------- Hình 1: Fischer ----------
def fischer(cx, top, rows, label):
    out = []; dy = 38
    for i, (left, mid, right, hl) in enumerate(rows):
        y = top + i * dy
        out.append(T(cx - 70, y + 5, str(i + 1), size=11))
        out.append(T(cx, y + 5, mid))
        if left: out += [L(cx - 9, y, cx - 22, y), T(cx - 25, y + 5, left, 'end')]
        if right:
            c = HL if hl else 'currentColor'
            out += [L(cx + 9, y, cx + 22, y, 1.6, c), T(cx + 25, y + 5, right, 'start', color=c, weight='bold' if hl else 'normal')]
        if i < len(rows) - 1: out.append(L(cx, y + 9, cx, y + dy - 12))
    out.append(T(cx, top + len(rows) * dy + 8, label, size=14, weight='bold'))
    return out
glc = [('', 'CHO', '', 0), ('H', 'C', 'OH', 0), ('HO', 'C', 'H', 0), ('H', 'C', 'OH', 0), ('H', 'C', 'OH', 1), ('', CH2OH, '', 0)]
fru = [('', CH2OH, '', 0), ('', 'C', '', 0), ('HO', 'C', 'H', 0), ('H', 'C', 'OH', 0), ('H', 'C', 'OH', 1), ('', CH2OH, '', 0)]
body = fischer(120, 30, glc, 'D-glucose (aldohexose)') + fischer(360, 30, fru, 'D-fructose (cetohexose)')
body += [L(368, 66, 382, 66), L(368, 71, 382, 71), T(386, 74, 'O', 'start')]
body += [T(240, 330, 'Nhóm –OH ở C5 (C* cuối cùng) nằm bên PHẢI → dãy D', size=13, color=HL)]
svg(480, 345, body, 'Công thức Fischer của D-glucose và D-fructose', 'fischer.svg')

# ---------- Hình 2: Haworth ----------
def shrink(p, q, k=11):
    dx, dy = q[0] - p[0], q[1] - p[1]; d = math.hypot(dx, dy)
    return (p[0] + dx * k / d, p[1] + dy * k / d)
def ring(P, o, front):
    out = []; n = len(P)
    for i in range(n):
        A, B = P[i], P[(i + 1) % n]
        if i == o: A = shrink(P[i], P[(i + 1) % n])
        if (i + 1) % n == o: B = shrink(P[(i + 1) % n], P[i])
        out.append(L(*A, *B, 4.5 if i in front else 1.8))
    out.append(T(P[o][0], P[o][1] + 5, 'O', weight='bold'))
    return out
def sub(x, y, up=None, down=None, hl=None, ul=22, down_anchor='middle'):
    out = []
    if up:
        c = HL if hl == 'up' else 'currentColor'
        out += [L(x, y, x, y - ul, 1.6, c), T(x, y - ul - 4, up, color=c, weight='bold' if c != 'currentColor' else 'normal')]
    if down:
        c = HL if hl == 'down' else 'currentColor'
        dx = 4 if down_anchor == 'start' else 0
        out += [L(x, y, x, y + ul, 1.6, c), T(x + dx, y + ul + 14, down, down_anchor, color=c, weight='bold' if c != 'currentColor' else 'normal')]
    return out
def num(x, y, n, dx): return T(x + dx, y + 4, n, size=10)

def pyranose(ox, oy, beta):
    P = [(ox + 40, oy), (ox + 110, oy), (ox + 145, oy + 40), (ox + 110, oy + 80), (ox + 40, oy + 80), (ox + 5, oy + 40)]
    C5, O, C1, C2, C3, C4 = P
    out = ring(P, 1, {2, 3, 4})
    out += sub(*C5, CH2OH, None, ul=24)  # H ở C5 lược bỏ cho gọn (như giáo trình)
    out += sub(*C1, 'OH', 'H', hl='up') if beta else sub(*C1, 'H', 'OH', hl='down')
    out += sub(*C2, 'H', 'OH') + sub(*C3, 'OH', 'H') + sub(*C4, 'H', 'OH')
    out += [num(*C1, '1', 9), num(*C2, '2', 9), num(*C3, '3', -9), num(*C4, '4', -10), num(*C5, '5', -9)]
    return out
def furanose(ox, oy):
    P = [(ox + 10, oy + 30), (ox + 75, oy), (ox + 140, oy + 30), (ox + 115, oy + 80), (ox + 35, oy + 80)]
    C5, O, C2, C3, C4 = P
    out = ring(P, 1, {2, 3, 4})
    out += sub(*C5, CH2OH, 'H', ul=24) + sub(*C2, 'OH', '(C1) ' + CH2OH, hl='up', down_anchor='start')
    out += sub(*C3, 'OH', 'H') + sub(*C4, 'H', 'OH')
    out += [num(*C2, '2', 9), num(*C5, '5', -10)]
    return out
body = pyranose(15, 70, False) + [T(90, 230, 'α-D-glucopyranose', size=14, weight='bold'), T(90, 248, '–OH ở C1 ngược phía CH₂OH', size=12)]
body += pyranose(215, 70, True) + [T(290, 230, 'β-D-glucopyranose', size=14, weight='bold'), T(290, 248, '–OH ở C1 cùng phía CH₂OH', size=12)]
body += furanose(420, 70) + [T(495, 230, 'β-D-fructofuranose', size=14, weight='bold'), T(495, 248, 'dạng có trong saccharose; C anomer = C2', size=12)]
body += [T(310, 282, 'Quy tắc: –OH bên PHẢI trong Fischer → hướng XUỐNG trong Haworth. Nét đậm = cạnh gần người xem.', size=12.5, color=HL)]
svg(680, 295, body, 'Công thức Haworth của alpha-, beta-glucose và beta-fructose', 'haworth.svg')

# ---------- Hình 3: Disaccharid ----------
def hexa(cx, cy, r, label):
    pts = [(cx + r * math.cos(math.radians(a)), cy + r * 0.62 * math.sin(math.radians(a))) for a in range(0, 360, 60)]
    return [f'<path d="M{" L".join(f"{x:.1f},{y:.1f}" for x, y in pts)}Z" fill="none" stroke="currentColor" stroke-width="1.8"/>', T(cx, cy + 5, label, size=13, weight='bold')]
def penta(cx, cy, r, label):
    pts = [(cx + r * math.cos(math.radians(a - 90)), cy + r * 0.75 * math.sin(math.radians(a - 90))) for a in range(0, 360, 72)]
    return [f'<path d="M{" L".join(f"{x:.1f},{y:.1f}" for x, y in pts)}Z" fill="none" stroke="currentColor" stroke-width="1.8"/>', T(cx, cy + 6, label, size=13, weight='bold')]
rows = [('Maltose', 'Glc', 'Glc', 'α(1→4)', True, 'mạch nha'), ('Lactose', 'Gal', 'Glc', 'β(1→4)', True, 'sữa'), ('Saccharose', 'Glc', 'Fru', 'α1 ↔ β2', False, 'mía, củ cải đường')]
body = [T(70, 24, 'Đường đôi', size=12, weight='bold'), T(255, 24, 'Cấu tạo', size=12, weight='bold'), T(500, 24, 'Tính khử?', size=12, weight='bold')]
for i, (name, a, b, link, red, src) in enumerate(rows):
    y = 70 + i * 82
    body += [T(70, y, name, size=15, weight='bold'), T(70, y + 18, src, size=12)]
    body += hexa(190, y, 34, a) + (penta(320, y, 34, b) if b == 'Fru' else hexa(320, y, 34, b))
    body += [L(224, y, 286, y, 2.2, HL), T(255, y - 8, link, size=12.5, color=HL, weight='bold')]
    if red: body += [L(354, y, 372, y), T(378, y + 4, 'OH', 'start', size=12), T(378, y + 18, 'hemiacetal tự do', 'start', size=11)]
    body += [T(500, y + 5, 'CÓ' if red else 'KHÔNG', size=14, weight='bold', color='currentColor' if red else HL)]
body += [T(280, 300, 'Còn –OH hemiacetal tự do ⇒ mở vòng được ⇒ có tính khử (tráng bạc, Fehling).', size=12.5)]
svg(560, 315, body, 'Cấu tạo maltose, lactose, saccharose', 'disaccharid.svg')

# ---------- Hình 4: Polysaccharid ----------
def dot(x, y): return f'<circle cx="{x}" cy="{y}" r="7" fill="none" stroke="currentColor" stroke-width="1.6"/>'
def chain(x0, y, n, step=19):
    out = []
    for k in range(n):
        x = x0 + k * step; out.append(dot(x, y))
        if k: out.append(L(x - step + 7, y, x - 7, y, 1.4))
    return out
def branch(x, y_from, y_to, n):
    return [L(x, y_from - 7, x, y_to + 7, 1.6, HL)] + chain(x, y_to, n)
body = [T(16, 40, 'Amylose', 'start', 14, weight='bold'), T(16, 57, 'α(1→4), mạch thẳng, cuộn xoắn', 'start', 11.5)] + chain(210, 45, 16)
body += [T(16, 120, 'Amylopectin', 'start', 14, weight='bold'), T(16, 137, 'α(1→4) + nhánh α(1→6)', 'start', 11.5), T(16, 152, 'cứ khoảng 24–30 gốc', 'start', 11.5)]
body += chain(210, 140, 16) + branch(267, 140, 106, 6) + branch(400, 140, 106, 6)
body += [T(16, 225, 'Glycogen', 'start', 14, weight='bold'), T(16, 242, 'như amylopectin nhưng', 'start', 11.5), T(16, 257, 'nhánh dày hơn (8–12 gốc)', 'start', 11.5)]
body += chain(210, 245, 16)
for bx in (229, 324, 419):
    body += branch(bx, 245, 211, 3)
for bx in (267, 362):
    body += branch(bx, 211, 177, 2)
body += [T(16, 310, 'Cellulose', 'start', 14, weight='bold'), T(16, 327, 'β(1→4), mạch thẳng, các gốc lật xen kẽ', 'start', 11.5), T(16, 342, '→ sợi bền, người không tiêu hóa được', 'start', 11.5)]
for k in range(16):
    x = 210 + k * 19; yy = 318 + (6 if k % 2 else -6)
    body.append(f'<rect x="{x-7}" y="{yy-5}" width="14" height="10" rx="2" fill="none" stroke="currentColor" stroke-width="1.6"/>')
    if k: body.append(L(x - 12, 318 + (-6 if k % 2 else 6), x - 7, yy, 1.4))
body += [dot(210, 380), T(224, 384, '= 1 gốc glucose', 'start', 12), L(345, 380, 365, 380, 1.6, HL), T(371, 384, '= nhánh α(1→6)', 'start', 12, HL)]
svg(530, 395, body, 'Sơ đồ amylose, amylopectin, glycogen, cellulose', 'polysaccharid.svg')
print('Đã tạo 4 hình')
