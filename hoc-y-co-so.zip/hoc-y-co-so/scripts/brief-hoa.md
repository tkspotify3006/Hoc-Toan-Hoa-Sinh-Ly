# Brief soạn bài cho app "Học Y Cơ Sở" (sinh viên năm 1, Học viện Y Dược học Cổ truyền VN)

Bạn soạn MỘT bài học (bai.md + quiz.json + hình SVG nếu cần) cho môn Hóa vô cơ & hữu cơ, theo giáo trình
"Hóa vô cơ và hữu cơ — PGS.TSKH. Phan An (chủ biên), NXB Giáo dục Việt Nam 2019" (sách đào tạo bác sĩ đa khoa).

## Đọc trước (bắt buộc)
- Quy ước nội dung: /home/claude/hoc-y-co-so/HUONG-DAN-NOI-DUNG.md
- Bài mẫu chuẩn (học theo phong cách, độ sâu, cách dùng khung):
  /home/claude/hoc-y-co-so/content/nam-1/hoa-hoc/hc-08b/bai.md và quiz.json
- Giáo trình là bản SCAN (không có lớp chữ): /root/.claude/uploads/3b17551e-f73f-5a71-ad7d-e845d5a87acd/9d0db6e5-937269280-Hoa-Vo-C_-Va-H_u-C_-B_-Y-T_.pdf
  Đọc bằng Read tool với pages="a-b" (tối đa 20 trang/lần; đọc HẾT các trang của bài, kể cả phần Tự lượng giá).
  QUY ĐỔI: số trang in trên sách = số trang PDF − 1 (ví dụ sách tr. 178 = PDF trang 179).
  Phần "Hướng dẫn trả lời câu hỏi và bài tập" ở cuối sách (sách tr. 242 trở đi = PDF 243+) — xem phần của bài mình để đối chiếu đáp án tự lượng giá.
- Dùng SỐ TRANG IN TRÊN SÁCH khi ghi nguồn: "Giáo trình tr. 178".

## Yêu cầu nội dung — bai.md
- Frontmatter: title, thoi-gian, muc-tieu (bám MỤC TIÊU của sách, diễn đạt lại).
- Mở đầu bằng khung `> [!ghi-nho] Cả bài trong 5 dòng`.
- Chia `## 1. ...`, `### 1.1 ...` theo trình tự của sách. Bao phủ ĐỦ các ý có thể ra thi (định nghĩa, phân loại, cấu trúc, chức năng, số liệu, ví dụ của sách).
- VIẾT LẠI bằng lời của mình (không chép nguyên văn câu dài của sách — vấn đề bản quyền), dễ hiểu, có "vì sao" (bản chất), câu ngắn gọn, tiếng Việt chuẩn có dấu. Thuật ngữ & danh pháp: giữ cách viết của sách (danh pháp IUPAC tiếng Anh như sách: acid, alcol, aldehyd, ceton, ester, amin… ; tên nguyên tố theo sách) và có thể ghi thuật ngữ tiếng Anh trong ngoặc lần đầu.
- Dùng bảng để so sánh khi hợp lý. Dùng khung:
  - `[!bay]` điểm dễ nhầm khi thi;
  - `[!ung-dung]` ứng dụng y học/lâm sàng (bệnh lý liên quan, thuốc, xét nghiệm);
  - `[!cap-nhat]` khi kiến thức sách (2008) đã cũ: ghi "Giáo trình ghi… / Hiện nay…" — chỉ dùng khi bạn CHẮC chắn về kiến thức mới (đồng thuận khoa học); đi thi vẫn trả lời theo sách;
  - `[!yhct]` CHỈ khi có liên hệ thật sự, chính xác và nêu mức bằng chứng thận trọng. Môn Hóa có nhiều liên hệ THẬT: khoáng vật làm thuốc (Thạch cao CaSO~4~·2H~2~O, Mang tiêu Na~2~SO~4~·10H~2~O, Phèn chua, Chu sa HgS, Hùng hoàng As~4~S~4~, Mẫu lệ/Long cốt/Thạch quyết minh ~ CaCO~3~, Từ thạch Fe~3~O~4~, Hoạt thạch, Duyên đan Pb~3~O~4~, Lô cam thạch ZnCO~3~…) kèm cảnh báo độc kim loại nặng; nhóm hoạt chất dược liệu theo nhóm chức (tinh dầu – terpen, aldehyd, phenol; tannin; alkaloid – amin dị vòng; acid hữu cơ; glycosid; coumarin…); cơ sở hóa học của bào chế (sao, tẩm, chế với giấm/rượu/mật, cô cao). KHÔNG gượng ép; 0–2 khung/bài; không lặp lại khung đã có ở bài Glucid.
  - `[!vi-du]` đào sâu/ví dụ.
- Cuối bài: `## Tóm tắt` dạng bảng hoặc danh sách ngắn.
- Ký hiệu: H~2~O, Ca^2+^ ; dòng phương trình bắt đầu bằng `=> `.
- Ghi nguồn bằng số trang in trên sách.

## Hình (khuyến khích 1–3 hình SVG cho các cấu trúc quan trọng)
- Tự vẽ bằng SVG (viết tay hoặc script Python sinh ra), đặt trong thư mục bài, chèn bằng `![Hình n. Chú thích](ten.svg)`.
- Dùng `currentColor` cho nét/chữ chính để tự đổi màu sáng/tối; màu nhấn duy nhất `#d97706`; có thể dùng `fill="none"` hoặc fill rất nhạt bằng `fill-opacity`. Font: `font-family="Georgia, 'Times New Roman', serif"`.
- viewBox rộng tối đa 560, chữ ≥ 12px, không chồng lấn. Có <title>.
- KIỂM TRA hình bằng Playwright (Python, đã cài; Chromium sẵn): render, chụp màn hình, tự xem (Read file png) và sửa đến khi sạch. Không sao chép hình của sách; vẽ sơ đồ của riêng mình, đúng khoa học.

## quiz.json
- 25–35 câu (bài ngắn ~20–25). Trộn: mcq (đa số), tf (4–6 câu, mỗi câu 4 ý), multi (2–3 câu). level 1/2/3 đều có, ~30% vận dụng/tình huống y học.
- Mỗi câu có "explain" giải thích vì sao đúng và vì sao các phương án nhiễu sai; "ref": "Giáo trình tr. X" hoặc "Bài học mục Y".
- id: "q01", "q02"… Chỉ đúng 1 đáp án bảo vệ được cho mcq; tránh "tất cả đều đúng" (nếu có thì "fixed": true).
- Bám sát nội dung sách (đó là cái sẽ thi); câu "cập nhật" thì phải ghi rõ trong stem.

## Kiểm tra trước khi xong
1. `node /home/claude/hoc-y-co-so/scripts/kiem-tra.mjs` — bài của bạn phải không có lỗi (lỗi ở bài KHÁC đang được người khác soạn thì bỏ qua).
2. Tự soát lại kiến thức từng câu quiz một lần (đáp án đúng chỉ số 0-based!).
3. KHÔNG sửa file nào ngoài thư mục bài của bạn (đặc biệt không sửa catalog.json, js/, style.css).

## Báo cáo khi xong (ngắn, < 200 từ)
Số mục, số hình, số câu quiz; các điểm [!cap-nhat] đã thêm; điểm nào trong sách bạn thấy sai/mâu thuẫn; điều gì chưa chắc chắn.


## Riêng môn Hóa
- Bài mẫu chuẩn của CHÍNH môn này: content/nam-1/hoa-hoc/hc-08b (Glucid) và hình mẫu sinh bằng code ở scripts/hinh_glucid.py — có thể học theo/tái sử dụng hàm vẽ.
- Hình cấu tạo hóa học: vẽ SVG cẩn thận (công thức cấu tạo, vòng benzen, cơ chế phản ứng SN1/SN2/AE…, cấu hình electron, bảng so sánh). Mỗi nét liên kết phải đúng hóa trị. Kiểm tra bằng Playwright và tự nhìn lại.
- Phương trình phản ứng phải cân bằng; điều kiện phản ứng ghi rõ. Tự kiểm tra lại mọi hệ số, mọi số oxi hóa, mọi tên IUPAC.
- Quiz nên có câu gọi tên IUPAC, câu nhận biết/phân biệt bằng thuốc thử, câu so sánh tính acid/base, câu cơ chế — đúng trọng tâm "Tự lượng giá" của sách.
- Ứng dụng y học: thuốc, độc chất, xét nghiệm (vd NaHCO~3~ kháng acid, BaSO~4~ cản quang, I~2~ sát khuẩn, NO thuốc giãn mạch, paracetamol – phenol, aspirin – ester…).
- Có thể chạy `python3 -m http.server <cổng riêng 88xx>` ở /home/claude/hoc-y-co-so để xem bài trong app (`#/bai/nam-1/hoa-hoc/<mã>`), tắt server khi xong. File tạm của bạn để trong thư mục riêng /home/claude/scratch/<mã-bài>/ (không dùng tên file chung).
- catalog.json CHƯA đánh dấu "ready" cho bài của bạn — KHÔNG sửa catalog. Để chạy validator: copy repo sang /home/claude/scratch/<mã-bài>/repo (cp -r), thêm "ready": true vào bản sao catalog rồi chạy node scripts/kiem-tra.mjs trong bản sao. Có thể xem bài trong app bằng server chạy trên bản sao đó.
