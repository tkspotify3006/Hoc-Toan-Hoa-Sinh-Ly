/* =========================================================
   quiz.js — làm bài trắc nghiệm (dùng cho cả Quiz bài học và Ôn tập)
   Loại câu hỏi:
     mcq   : 1 đáp án đúng        { q, options:[], answer: 0 }
     multi : nhiều đáp án đúng    { q, options:[], answer: [0,2] }
     tf    : Đúng/Sai từng ý      { q, statements:[{ s, a:true, why }] }
   ========================================================= */
(function () {
  const { esc, mdInline } = window.Content;
  const LETTERS = 'ABCDEFGH';

  // Chỉ một phiên quiz được hoạt động tại một thời điểm (tránh phím tắt của phiên cũ còn sót)
  let active = null;
  function stop() { if (active) { active.abort(); active = null; } }

  function shuffle(a) { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }

  /**
   * items: [{ key, q, lesson }]
   * opts : { title, mode: 'lesson'|'review', onFinish(results), backHref }
   */
  function run(root, items, opts = {}) {
    stop();
    const ac = new AbortController();
    active = ac;
    let queue = shuffle(items).map(it => ({ ...it, perm: permFor(it.q) }));
    const requeued = new Set();
    const results = [];
    let i = 0;
    let cleanup = () => {};

    function permFor(q) {
      if (q.type === 'tf') return null;
      const idx = q.options.map((_, k) => k);
      return q.fixed ? idx : shuffle(idx);
    }

    function show() {
      cleanup();
      if (i >= queue.length) return finish();
      const it = queue[i], q = it.q;
      const total = queue.length;
      const flagged = !!(Store.q(it.key) || {}).flag;
      const typeLabel = q.type === 'tf' ? 'Đúng / Sai' : q.type === 'multi' ? 'Chọn nhiều đáp án' : 'Chọn 1 đáp án';
      root.innerHTML = `
        <div class="quiz-top">
          <span class="small muted" style="font-variant-numeric:tabular-nums">${i + 1}/${total}</span>
          <div class="bar"><i style="width:${(i / total) * 100}%"></i></div>
        </div>
        <div class="qcard">
          <div class="q-meta">
            <span class="chip">${typeLabel}</span>
            ${q.levelLabel ? `<span class="chip">${esc(q.levelLabel)}</span>` : q.level ? `<span class="chip">${['', 'Nhớ', 'Hiểu', 'Vận dụng'][q.level] || ''}</span>` : ''}
            ${opts.mode === 'review' && it.lesson ? `<span class="chip accent">${esc(it.lesson.title)}</span>` : ''}
            ${it.again ? '<span class="chip warn">Làm lại</span>' : ''}
          </div>
          <div class="q-text">${mdInline(q.q)}</div>
          <div id="answers"></div>
          <label class="unsure"><input type="checkbox" id="unsure"> Mình chưa chắc (đoán) — đưa vào ôn tập</label>
          <div id="feedback" aria-live="polite"></div>
          <div class="quiz-actions">
            <button class="btn flag-btn" id="flag" aria-pressed="${flagged}" title="Đánh dấu để xem lại">${flagged ? '★' : '☆'} Đánh dấu</button>
            <button class="btn primary" id="check" disabled>Kiểm tra</button>
          </div>
        </div>`;
      const ans = root.querySelector('#answers');
      const checkBtn = root.querySelector('#check');
      let selected = q.type === 'multi' ? new Set() : q.type === 'tf' ? q.statements.map(() => null) : null;
      let graded = false;

      const ready = () => q.type === 'mcq' ? selected !== null
        : q.type === 'multi' ? selected.size > 0 : selected.every(v => v !== null);

      if (q.type === 'tf') {
        ans.innerHTML = q.statements.map((st, k) => `
          <div class="tf-row" data-k="${k}">
            <div class="s"><b>${String.fromCharCode(97 + k)})</b> ${mdInline(st.s)}</div>
            <div class="tf-btns">
              <button data-v="1" aria-pressed="false">Đúng</button>
              <button data-v="0" aria-pressed="false">Sai</button>
            </div>
          </div>`).join('');
        ans.querySelectorAll('.tf-row').forEach(row => {
          row.querySelectorAll('button').forEach(b => b.onclick = () => {
            if (graded) return;
            selected[+row.dataset.k] = b.dataset.v === '1';
            row.querySelectorAll('button').forEach(x => x.setAttribute('aria-pressed', x === b));
            checkBtn.disabled = !ready();
          });
        });
      } else {
        ans.className = 'opts';
        ans.innerHTML = it.perm.map((orig, k) => `
          <button class="opt" data-orig="${orig}" aria-pressed="false">
            <span class="key">${LETTERS[k]}</span><span>${mdInline(q.options[orig])}</span>
          </button>`).join('');
        ans.querySelectorAll('.opt').forEach(b => b.onclick = () => {
          if (graded) return;
          const o = +b.dataset.orig;
          if (q.type === 'mcq') {
            selected = o;
            ans.querySelectorAll('.opt').forEach(x => x.setAttribute('aria-pressed', x === b));
          } else {
            selected.has(o) ? selected.delete(o) : selected.add(o);
            b.setAttribute('aria-pressed', selected.has(o));
          }
          checkBtn.disabled = !ready();
        });
      }

      root.querySelector('#flag').onclick = e => {
        const f = Store.toggleFlag(it.key);
        e.currentTarget.setAttribute('aria-pressed', f);
        e.currentTarget.innerHTML = (f ? '★' : '☆') + ' Đánh dấu';
        App.toast(f ? 'Đã đánh dấu câu này' : 'Bỏ đánh dấu');
      };

      checkBtn.onclick = () => {
        if (!graded) {
          graded = true;
          grade();
          checkBtn.textContent = i + 1 < queue.length ? 'Câu tiếp →' : 'Xem kết quả';
          checkBtn.disabled = false;
        } else { i++; show(); window.scrollTo(0, 0); }
      };

      function grade() {
        let correct;
        const unsure = root.querySelector('#unsure').checked;
        root.querySelector('#unsure').disabled = true;
        if (q.type === 'tf') {
          correct = true;
          ans.querySelectorAll('.tf-row').forEach(row => {
            const k = +row.dataset.k, truth = !!q.statements[k].a;
            row.querySelectorAll('button').forEach(b => {
              const v = b.dataset.v === '1';
              if (v === truth) b.classList.add('correct');
              else if (selected[k] === v) b.classList.add('wrong');
              b.disabled = true;
            });
            if (selected[k] !== truth) correct = false;
          });
        } else {
          const truth = q.type === 'mcq' ? new Set([q.answer]) : new Set(q.answer);
          const sel = q.type === 'mcq' ? new Set([selected]) : selected;
          correct = truth.size === sel.size && [...truth].every(x => sel.has(x));
          ans.querySelectorAll('.opt').forEach(b => {
            const o = +b.dataset.orig;
            if (truth.has(o)) b.classList.add('correct');
            else if (sel.has(o)) b.classList.add('wrong');
            b.disabled = true;
          });
        }
        // Câu làm lại ngay trong phiên: đúng thì không tính lên hộp (tránh "học vẹt ngắn hạn")
        if (!(it.again && correct)) Store.record(it.key, { correct, unsure });
        results.push({ ...it, correct, unsure });

        // Ôn tập: câu sai được hỏi lại 1 lần cuối phiên
        if (!correct && opts.mode === 'review' && !requeued.has(it.key)) {
          requeued.add(it.key);
          queue.push({ ...it, again: true, perm: permFor(q) });
        }

        const cls = !correct ? 'bad' : unsure ? 'warn' : 'ok';
        const verdict = !correct ? 'Chưa đúng — câu này đã vào Sổ câu sai'
          : unsure ? 'Đúng, nhưng bạn chưa chắc — sẽ ôn lại' : 'Chính xác!';
        const whys = q.type === 'tf' ? q.statements.filter(s => s.why)
          .map((s) => `<p><b>${String.fromCharCode(97 + q.statements.indexOf(s))})</b> ${s.a ? 'Đúng' : 'Sai'} — ${mdInline(s.why)}</p>`).join('') : '';
        root.querySelector('#feedback').innerHTML = `
          <div class="feedback ${cls}">
            <div class="verdict">${verdict}</div>
            ${whys}
            ${q.explain ? `<p>${mdInline(q.explain)}</p>` : ''}
            ${q.warn ? `<p class="warn-note">⚠ ${mdInline(q.warn)}</p>` : ''}
            ${q.ref ? `<p class="small muted">Nguồn: ${esc(q.ref)}</p>` : ''}
            ${q.see && window.Theory ? `<p><button class="linkish" id="see">📖 Xem lý thuyết liên quan</button></p>` : ''}
          </div>`;
        const see = root.querySelector('#see');
        if (see) see.onclick = () => Theory.open(q.see.lesson, q.see.h);
      }

      const onKey = e => {
        if (!checkBtn.isConnected) return;
        // ô "chưa chắc" (checkbox) vẫn cho dùng phím tắt; chỉ bỏ qua ô nhập chữ
        if (e.target.closest && e.target.closest('textarea, select, input:not([type=checkbox])')) return;
        if (e.key === 'Enter') {
          // Enter trên đáp án ĐÃ chọn (vừa bấm chuột) = Kiểm tra; trên nút/link khác: để trình duyệt xử lý nút đó
          const onPicked = e.target.closest && e.target.closest('.opt[aria-pressed="true"], .tf-btns button[aria-pressed="true"]');
          if (!onPicked && e.target.id !== 'unsure' && e.target.closest && e.target.closest('button, a, label') && e.target !== checkBtn) return;
          if (!checkBtn.disabled) { e.preventDefault(); checkBtn.click(); }
          return;
        }
        const n = parseInt(e.key, 10);
        if (!graded && n >= 1 && q.type !== 'tf') { const b = ans.querySelectorAll('.opt')[n - 1]; if (b) b.click(); }
      };
      document.addEventListener('keydown', onKey, { signal: ac.signal });
      cleanup = () => document.removeEventListener('keydown', onKey);
    }

    function finish() {
      cleanup();
      // điểm tính trên lần trả lời đầu tiên của mỗi câu
      const first = new Map();
      for (const r of results) if (!first.has(r.key)) first.set(r.key, r);
      const list = [...first.values()];
      const right = list.filter(r => r.correct).length;
      const pct = list.length ? Math.round((right / list.length) * 100) : 0;
      const wrong = list.filter(r => !r.correct || r.unsure);
      if (opts.onFinish) opts.onFinish({ pct, right, total: list.length });

      const msg = pct >= 90 ? 'Xuất sắc!' : pct >= 70 ? 'Khá tốt — ôn thêm vài chỗ là chắc.' : pct >= 50 ? 'Tạm ổn — nên đọc lại phần chưa vững.' : 'Cần học lại bài trước khi làm tiếp.';
      root.innerHTML = `
        <div class="card stack" style="text-align:center">
          <div class="muted small">${esc(opts.title || 'Kết quả')}</div>
          <div class="result-score">${pct}%</div>
          <div>${right}/${list.length} câu đúng ngay lần đầu · ${esc(msg)}</div>
        </div>
        ${wrong.length ? `
        <div class="section-title">Cần xem lại (${wrong.length})</div>
        <div class="card"><ul class="wrong-list">
          ${wrong.map(r => `<li>${r.correct ? '<span class="chip warn">Chưa chắc</span>' : '<span class="chip bad">Sai</span>'}
            <div style="margin-top:4px">${mdInline(r.q.q)}</div>
            <div class="small muted">Đáp án: ${answerText(r.q)}</div>
            ${r.q.explain && opts.showExplain ? `<div class="small muted">${mdInline(r.q.explain)}</div>` : ''}</li>`).join('')}
        </ul></div>` : ''}
        <div class="stack" style="margin-top:16px">
          ${wrong.length ? `<button class="btn primary block" id="redo">Làm lại ${wrong.length} câu cần xem lại</button>` : ''}
          ${opts.backHref ? `<a class="btn block" href="${opts.backHref}">${esc(opts.backText || 'Về bài học')}</a>` : ''}
          <a class="btn block" href="#/on-tap">Đến trang Ôn tập</a>
        </div>`;
      const redo = root.querySelector('#redo');
      if (redo) redo.onclick = () => run(root, wrong.map(({ key, q, lesson }) => ({ key, q, lesson, again: true })), { ...opts, onFinish: null, title: 'Làm lại câu sai' });
      window.scrollTo(0, 0);
    }

    show();
  }

  function answerText(q) {
    if (q.type === 'tf') return q.statements.map((s, k) => `${String.fromCharCode(97 + k)}) ${s.a ? 'Đ' : 'S'}`).join(', ');
    const arr = q.type === 'mcq' ? [q.answer] : q.answer;
    return arr.map(k => mdInline(q.options[k])).join('; ');
  }

  window.Quiz = { run, stop, answerText };
})();
