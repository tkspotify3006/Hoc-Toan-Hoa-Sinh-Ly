/* =========================================================
   app.js — điều hướng (hash router), cài đặt giao diện, PWA
   Đường dẫn:
     #/                         trang chủ
     #/mon/<năm>/<môn>          danh sách bài
     #/bai/<năm>/<môn>/<bài>    bài học   (?h=<mục> để nhảy tới mục)
     #/quiz/<năm>/<môn>/<bài>   quiz
     #/on-tap                   ôn tập    (?mon=&xem=)
     #/on-tap/phien?loc=due     phiên ôn
     #/tra-cuu?q=               tra cứu
     #/cai-dat                  cài đặt
   ========================================================= */
(function () {
  const App = {
    VERSION: self.APP_VERSION || '?',
    seq: 0, // tăng mỗi lần chuyển trang; màn hình tải chậm sẽ tự hủy nếu đã cũ
    setTop(title, backHref) {
      document.getElementById('topbar-title').textContent = title;
      document.title = title === App.appTitle ? title : `${title} · ${App.appTitle}`;
      const back = document.getElementById('btn-back');
      back.hidden = !backHref;
      back.onclick = () => { location.hash = backHref; };
    },
    appTitle: 'Học Y Cơ Sở',
    toast(msg) {
      const t = document.getElementById('toast');
      t.textContent = msg; t.classList.add('show');
      clearTimeout(t._h); t._h = setTimeout(() => t.classList.remove('show'), 2200);
    },
    applySettings() {
      const s = Store.settings();
      const root = document.documentElement;
      if (s.theme === 'auto') root.removeAttribute('data-theme'); else root.setAttribute('data-theme', s.theme);
      root.style.setProperty('--fs', (s.fs || 16) + 'px');
    },
    updateDuePill() {
      const n = Store.counts().due;
      const pill = document.getElementById('due-pill');
      pill.hidden = !n; pill.textContent = `${n} câu cần ôn`;
    }
  };
  window.App = App;

  async function route() {
    App.seq++;
    Quiz.stop();
    const raw = location.hash.replace(/^#/, '') || '/';
    const [path, qs] = raw.split('?');
    const params = new URLSearchParams(qs || '');
    let seg = [];
    try { seg = path.split('/').filter(Boolean).map(decodeURIComponent); } catch (e) { seg = ['?']; }
    const tab = seg[0] === 'on-tap' ? 'on-tap' : seg[0] === 'tra-cuu' ? 'tra-cuu' : seg[0] === 'cai-dat' ? 'cai-dat' : 'hoc';
    document.querySelectorAll('.tabbar a').forEach(a => {
      const on = a.dataset.tab === tab;
      a.classList.toggle('active', on);
      if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
    const keepScroll = seg[0] === 'tra-cuu';
    const my = App.seq;
    try {
      if (!seg.length) await Views.home();
      else if (seg[0] === 'mon' && seg.length === 3) await Views.subject(seg[1], seg[2]);
      else if (seg[0] === 'bai' && seg.length === 4) await Views.lesson(seg.slice(1).join('/'), params.get('h'));
      else if (seg[0] === 'quiz' && seg.length === 4) await Views.quiz(seg.slice(1).join('/'));
      else if (seg[0] === 'on-tap' && seg[1] === 'phien') await Views.reviewSession(params);
      else if (seg[0] === 'on-tap') await Views.review(params);
      else if (seg[0] === 'tra-cuu') await Views.search(params);
      else if (seg[0] === 'cai-dat') await Views.settings();
      else Views.notFound();
    } catch (e) {
      console.error(e);
      document.getElementById('view').innerHTML = `<div class="empty">Không tải được nội dung (${Content.esc(e.message)}).<br>Kiểm tra kết nối mạng rồi thử lại.</div>`;
    }
    if (my !== App.seq) return;
    if (!params.get('h') && !keepScroll) window.scrollTo(0, 0);
    // chuyển tiêu điểm cho trình đọc màn hình (trừ trang tra cứu đang gõ)
    if (!keepScroll) document.getElementById('view').focus({ preventScroll: true });
    App.updateDuePill();
    const tb = document.querySelector('.topbar');
    document.documentElement.style.setProperty('--topbar-h', tb.offsetHeight + 'px');
  }

  App.applySettings();
  Content.loadCatalog().then(c => { App.appTitle = c.appTitle; }).catch(() => {});
  window.addEventListener('hashchange', route);
  route();

  // PWA: chạy offline
  if ('serviceWorker' in navigator && location.protocol !== 'file:') {
    window.addEventListener('load', () => navigator.serviceWorker.register('sw.js', { updateViaCache: 'none' }).catch(() => {}));
    // Có bản mới: service worker mới đã tiếp quản → mời người dùng tải lại
    const hadController = !!navigator.serviceWorker.controller;
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (!hadController || document.getElementById('update-bar')) return;
      const bar = document.createElement('div');
      bar.id = 'update-bar'; bar.className = 'update-bar'; bar.setAttribute('role', 'status');
      bar.innerHTML = '<span>Đã có bản cập nhật mới.</span><button class="btn primary" type="button">Tải lại</button>';
      bar.querySelector('button').onclick = () => location.reload();
      document.body.appendChild(bar);
    });
  }
})();
